﻿
param($logfile)
Function create-logfile($logfile, $Value){
if(-not(Test-Path -Path $logfile))
{
New-Item -Path $logfile -ItemType File
Out-File -FilePath $logfile -InputObject ("{" + (Get-Date) + "}" + "$value") -Append -Encoding ascii

}
}
create-logfile -logfile "c:\test.log" -Value "mounika"
s