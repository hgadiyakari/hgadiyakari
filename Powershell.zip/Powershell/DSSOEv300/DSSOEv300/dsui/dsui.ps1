#requires -version 5.0
# This script loads DSSOE GUI window that allows users to make setup related selections
# and kick off the installation process
# Script name: dsui.ps1
# Created    : 21-March-2017
# Author     : Umesh Thakur
# Copyright  : @Platform Wintel SOE, DXC.
# Modified   : Jun-2016; Tarun Rajvanshi
# -------------------------------------------------------------------------------------------------------------
[cmdletbinding()]
param(
)

#Load WPF type library and Windows Forms library, specially to use MsgBox function
Add-Type -AssemblyName presentationframework 
[System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms") | Out-Null

# for local/domain account validation related functions.. Test-DSCredentials
Add-Type -AssemblyName System.DirectoryServices.AccountManagement

# !!! IMPORTANT POINT TO REMEMBER !!!
# ==============================================================================================================
# XAML/WPF is case sensitive. You must use same case for control names as well as their properties and methods.
# ==============================================================================================================

#region script level variables that will be used in multiple functions
$credDeplOpValid = $False # indicate that credentials for domain deployment ops are invalid by-default
$forest = $null # forest is blank bydefault
$promoOpCreds = '' | Select-Object domain, user, rights, isrootdomain
# click event for Windows controls.. will be used to trigger event for given controls in code in the script
$evt = new-object -TypeName System.Windows.RoutedEventArgs([System.Windows.Controls.RadioButton]::ClickEvent)
#endregion

#region script level functions that cannot be moved to or defined in a module due to UI control dependency
# This function will set network interface and IP related controls with their detected values
# It should be called when script has launched 
# --------------------------------------------------------------------------------------------
Function Set-DSNetworkInterfaces {
    Add-Indent -Header "enter -> Set-DSNetworkInterfaces" # increase indent in log file
    # get interface index of those adapters that are IPEnabled
    Write-dsLog -level info -Message "Identifying network interfaces that are IPEnabled"
    $netadp = Get-DSNetworkAdapters 
    $naconf = Get-WmiObject win32_networkAdapterConfiguration -Filter "IPEnabled=True" 
    $netadp = $netadp | Where-Object { $_.InterfaceIndex -in @($naconf.interfaceIndex) }
    Write-dsLog -level info -Message "Adding these interfaces to combo box for user selection"
    Add-DSNetAdaptersToUIControl -ContralName $cboNetAdapter -NetworkAdaptersList $netadp
    
    Remove-Indent -Footer "exit -> Set-DSNetworkInterfaces" # decrease indent in log file
}

# Function to display IP details of selected network adapter
# ----------------------------------------------------------
Function Show-DSNetAdapterDetails($InterfaceIndex) {
    Add-Indent -Header "enter -> Show-DSNetAdapterDetails" # increase indent in log file
    Write-dsLog -level info -Message "Binding to network interface with interface index $InterfaceIndex"
    
    $nif = (Get-WmiObject Win32_NetworkAdapterConfiguration | Where-Object { $_.InterfaceIndex -eq $InterfaceIndex})
    if($nif -ne $null) {
        Write-dsLog -level info -Message "binding successful"
        # blank text fields before displaying current interface details
        $tbIPAddress, $tbSubnet, $tbGateway, $tbDNS, $tbNetDNSSuffix | foreach { $_.Text = "" }
        #deleted $tbWins from the list

        # display Network adapter IP configuration details
        Write-dsLog -level info -Message "displaying IP details of the interface"
        # Show IP address
        Set-DSControl -Control $tbIPAddress -Property 'Text' -Value ($nif.IPAddress -join ',') `
            -When ($nif.IPAddress.count -ge 1)
        # Show IP Subnet
        Set-DSControl -Control $tbSubnet -Property 'Text' -Value ($nif.IPSubnet -join ',') `
            -When ($nif.IPSubnet.count -ge 1)
        # Show IP Gateway
        Set-DSControl -Control $tbGateway -Property 'Text' -Value ($nif.DefaultIPGateway -join ',') `
            -When ($nif.DefaultIPGateway.count -ge 1)
        # Show DNS servers
        Set-DSControl -Control $tbDNS -Property 'Text' -Value ($nif.DNSServerSearchOrder -join ',') `
            -When ($nif.DNSServerSearchOrder.count -ge 1)
        # Show WINS Servers 
        #$winsIPs = ("$($nif.WINSPrimaryServer),$($nif.WINSSecondaryServer)")
        #Set-DSControl -Control $tbWins -Property 'Text' -Value $winsIPs -When ($winsIPs -ne ',')
        # Show Network Adapter DNS Suffix 
        Set-DSControl -Control $tbNetDNSSuffix -Property 'Text' -Value ($nif.DNSDomain) -When ($nif.DNSDomain.Length -ge 1)
        # check/uncheck LMHosts lookup check box
        if($nif.WINSEnableLMHostsLookup) { $cbEnableLMHosts.IsChecked = $true } else { $cbEnableLMHosts.IsChecked = $false }
    }
    else {
        Write-dsLog -level warning -Message "could not bind to given network interface"
    }
    Remove-Indent -Footer "exit -> Show-DSNetAdapterDetails" # decrease indent in log file
}


# This function checks whether given name is a valid email address format or not
# used here to check username@domain.name format
# -------------------------------------------------------------------------------
function Test-DSEmailAddress($Address) {  
    return ([bool]($Address -as [Net.Mail.MailAddress]))
} 

# This function will add given items in given combo box control
# --------------------------------------------------------------
Function Add-DSComboItems($Combo, $ItemsToAdd, [switch] $ClearExistingItems) {
    Add-Indent -Header "enter -> Add-DSComboItems" # increase indent in log file
    Write-DSLog -Level info -Message "adding given items to combo $($Combo.Name)"

    if($ClearExistingItems) { 
        Write-DSLog -Level info -Message "Clearning existing items of combo $($Combo.Name)"
        $Combo.Items.Clear() | Out-Null 
    }
    # now run thru loo and add items in given combo box
    foreach($i in $ItemsToAdd) {
        Write-DSLog -Level info -Message "Adding item $i"
        $li = new-Object Windows.Controls.ComboBoxItem
        $li.Content = $i
        $Combo.Items.Add($li) | Out-Null    
    }
    Remove-Indent -Footer "exit -> Add-DSComboItems" # decrease indent in log file
}


# This function will add given items in given list box control
# --------------------------------------------------------------
Function Add-DSListItems($List, $ItemsToAdd, [switch] $ClearExistingItems) {
    Add-Indent -Header "enter -> Add-DSListItems" # increase indent in log file
    Write-DSLog -Level info -Message "adding given items to list box $($List.Name)"

    if($ClearExistingItems) { 
        Write-DSLog -Level info -Message "Clearning existing items of list box $($List.Name)"
        $List.Items.Clear() | Out-Null 
    }
    # now run thru loop and add items in given List box
    foreach($i in $ItemsToAdd) {
        Write-DSLog -Level info -Message "Adding item $i"
        $li = new-Object Windows.Controls.ListBoxItem
        $li.Content = $i
        $List.Items.Add($li) | Out-Null    
    }
    Remove-Indent -Footer "exit -> Add-DSListItems" # decrease indent in log file
}


# This function will return index #of given combox box item based on its content
# ------------------------------------------------------------------------------
Function Get-CBOItemIndex($Combo, $Content) {
    Add-Indent -Header "enter -> Get-CBOItemIndex" # increase indent in log file

    Write-DSLog -Message "given combo $($combo.name) has $($combo.items.count) items"
    Write-DSLog -Message "searching for item with content [$Content]"

    for($i=0;$i -lt $Combo.items.Count; $i++) { 
        if($Combo.Items.GetItemAt($i).content -eq $Content) { break } # terminate the loop after item is found
    }

    if($i -lt $Combo.items.Count) { Write-DSLog -Message "item found at index $i" }
    else { Write-DSLog -Message "item not found"; $i = -1 } # indicate item not found
    
    Remove-Indent -Footer "exit -> Get-CBOItemIndex" # decrease indent in log file
    
    return $i # return index of identified value or -1 if not found
}

# this function will add supported forest and domain functional modes to corresponding combo controls
# ----------------------------------------------------------------------------------------------------
Function Set-DSFunctionalModeControls {
    Add-Indent -Header "enter -> Set-DSFunctionalModeControls" # increase indent in log file

    # Get forest and domain functional modes supported by DSSOE. Then add them to respective combo boxes
    Write-DSLog -Level info -Message "Getting list of DSSOE supported forest and corresponding domain modes"
    if((Test-OSIsWindowsServer2016)) { # supported forest functional modes
        $fmodes = (Get-DSSupportedForestModes)
        $dmodes = (Get-DSSupportedDomainModes -ForestModeNumber '7') 
    }
    else { # get all supported forest and domain modes
        $fmodes = (Get-DSSupportedForestModes) 
        $dmodes = (Get-DSSupportedDomainModes -ForestMode 'Windows2008Forest')
    } # get all modes for rest of OSes
    
    <#
    if((Test-OSIsWindowsServer2012R2)) { # supported forest functional modes, skip win2003 as its not supported
        $fmodes = (Get-DSSupportedForestModes) | Where-Object { $_.ForestMode -ne "Windows2003Forest" }
        $dmodes = (Get-DSSupportedDomainModes -ForestMode 'Windows2008Forest') 
    }
    else { # get all supported forest and domain modes
        $fmodes = (Get-DSSupportedForestModes) 
        $dmodes = (Get-DSSupportedDomainModes -ForestMode 'Windows2003Forest')
    } # get all modes for rest of OSes
    #>

    # add them to combo controls
    Write-DSLog -Level info -Message "Adding identified forest and domain modes to combo boxes"
    Add-DSComboItems -Combo $cboForestFuncLevel -ItemsToAdd @($fmodes.ModeDisplayName) -ClearExistingItems
    Add-DSComboItems -Combo $cboDomainFuncLevel -ItemsToAdd @($dmodes.ModeDisplayName) -ClearExistingItems

    Remove-Indent -Footer "exit -> Set-DSFunctionalModeControls" # decrease indent in log file
}

# this function will populate 'existing domain' combo with given domain name (valid for additional dc only)
# Username is taken from "User Name" text box for the purpose of extracting given domain name (to add to combo)
# --------------------------------------------------------------------------------------------------------------
Function Set-DSExistingDomainCombo {
    Add-Indent -Header "enter -> Set-DSExistingDomainCombo" # increase indent in log file
    $uinfo = $tbUserName.Text -as [mailaddress] # extract domain portion from it to add into combo
    Write-DSLog -Level info -Message "Adding $($uinfo.Host) as domain name in Existing domain name combo box"
    Add-DSComboItems -Combo $cboExistingDomainName -ItemsToAdd @($uinfo.Host) -ClearExistingItems
    $cboExistingDomainName.SelectedIndex = 0 # auto-select the domain name
    Remove-Indent -Footer "exit -> Set-DSExistingDomainCombo" # decrease indent in log file
    return $cboExistingDomainName.SelectedItem.Content # return the domain name that was set
}

# This function sets visibility of DS deployment types radio buttons based on given credential
# for example, if local admin cred is given then only 'new forest' option is provided
# --------------------------------------------------------------------------------------------
Function Set-DSBuildTypeControlsVisibility {
    Add-Indent -Header "enter -> Set-DSBuildTypeControlsVisibility" # increase indent in log file
    Write-DSLog -Level info -Message "given credential type is $($promoOpCreds.rights)"
    switch($promoOpCreds.rights) {
        'LocalAdmin' { # enable forest build option only
            Write-DSLog -Level info -Message "enabling option for new forest creation only"
            $rbNewForest.IsEnabled = $true
            $rbAdditionalDC, $rbNewChildDomain,$rbNewTreeDomain | foreach { $_.IsEnabled = $false }
            $dopTab.Visibility = "Visible"
        }
        'DomainAdmins' { # enable additonal dc option only and select it as well
            Write-DSLog -Level info -Message "enabling option for additional dc only"
            $rbAdditionalDC.IsEnabled = $true
            $rbNewForest, $rbNewChildDomain,$rbNewTreeDomain | foreach { $_.IsEnabled = $false }
            $dopTab.Visibility = "Visible"
        }
        'EnterpriseAdmins' { # enable child/tree domain options only, select child option by-default
            Write-DSLog -Level info -Message "enabling options for new child domain and new tree domain only"
            $rbNewChildDomain.IsEnabled = $true
            $rbNewTreeDomain.IsEnabled = $true
            $rbAdditionalDC, $rbNewForest | foreach { $_.IsEnabled = $false } # disable these two options
            # if given domain is forest root domain as well then enable additinal dc control
            if($promoOpCreds.isrootdomain) {
                Write-DSLog -Level info -Message "enabling option for additional dc as given domain is forest root domain and entadm cred is specified"
                $rbAdditionalDC.IsEnabled = $true
            }
            
            $dopTab.Visibility = "Visible"
            # note that new tree domain options are same as new child domain so it does both
        }
        default { # disable all doamin ops radio buttons and un-select them as well
            Write-DSLog -Level info -Message "Invalid credential type is specified, disabling all build type options" 
            $rbNewForest, $rbAdditionalDC, $rbNewChildDomain,$rbNewTreeDomain | foreach { 
                $_.IsEnabled = $false 
                $_.IsChecked = $false
                $dopTab.Visibility = "Collapsed" # hide tab control
            }
            Set-DSBuildDependentTabsVisibility -Status Disabled # enable dependent build tabs
        }
    }

    Remove-Indent -Footer "exit -> Set-DSBuildTypeControlsVisibility" # decrease indent in log file 
}

# This function will enable or disable controls specific to 'Additional DC' option
# --------------------------------------------------------------------------------
Function Set-DSADCControlsStatus {
param([validateset('enabled','disabled')] [string] $Status)
    Add-Indent -Header "enter -> Set-DSADCControlsStatus" # increase indent in log file
    # fire events of 'install from media' and 'replicate data from existing dc' to set related controls 
    Write-DSLog -Level info -Message "enabling/disabling controls related to additional dc operation"
    $cbReplicateFromExistingDC.IsChecked = $false # uncheck it
    $cbIFM.IsChecked = $false # uncheck it
    $cbReplicateFromExistingDC.RaiseEvent($evt)
    $cbIFM.RaiseEvent($evt)

    $cbRODC, $cbReplicateFromExistingDC, $cbIFM, $cbCriticalReplOnly | foreach { $_.IsEnabled = ($Status -eq 'enabled') } 

    # for additional dc, 'place domain controller in specific ou' option will be greyed out
    $cbDCPlacementOU.IsEnabled = ($Status -eq 'enabled')
    $cbDCPlacementOU.IsChecked = $false # uncheck it
    $cbDCPlacementOU.RaiseEvent($evt) # raise event for the control so that corresponding controls are set by event

    # for additional DC, domain/domain controller security policies should be disabled and unchecked
    # for rest, it should be enabled and by-default checked
    $cbDomainSecPol,$cbDCSecPol | foreach { 
        if($Status -eq 'disabled') { # disable ADC controls.. here, enable and check these checkboxes
            $_.IsEnabled = $true
            $_.IsChecked = $true # check them
        }
        elseif($Status -eq 'enabled') { # enable ADC controls.., here uncheck and disabble these
            $_.IsEnabled = $false
            $_.IsChecked = $false # check them
        }
    }

    # disable OU structure creation controls when additional dc
    'lblAccountType','cboAccountType','lblAccountCode','tbAccountCode','cbConfigureADDelegation' | foreach {  
        $dsui.FindName($_).IsEnabled = ($Status -eq 'disabled') 
    }
    $cbConfigureADDelegation.IsChecked = $false #set delegation checkbox to $false
    Remove-Indent -Footer "exit -> Set-DSADCControlsStatus" # decrease indent in log file 
}

# This function will enable or disable controls specific to 'subnet site association checkbox'
# --------------------------------------------------------------------------------------------
Function Set-DSSiteSubnetAssocControlsStatus {
param([validateset('enabled','disabled')] [string] $Status)
    Add-Indent -Header "enter -> Set-DSSiteSubnetAssocControlsStatus" # increase indent in log file
    Write-DSLog -Level info -Message "setting status of site/subnet association related controls to $Status"
    'lblSiteSubnetMask','tbSiteSubnetMask','lblSiteSubnetMaskDesc','lblEntAdminUserName','tbEntAdminUserName', `
    'lblEntAdminUserNameDesc','lblEntAdminPassword','tbEntAdminPassword' | foreach { 
        $dsui.FindName($_).IsEnabled = ($Status -eq 'enabled') 
    } 
    Remove-Indent -Footer "exit -> Set-DSSiteSubnetAssocControlsStatus" # decrease indent in log file 
}

# This function will collapse or make visible all tabs except installation type, DC Build type n static ip
# ---------------------------------------------------------------------------------------------------------
function Set-DSBuildDependentTabsVisibility {
param([validateset('Enabled','Disabled')] [string] $Status)
    Add-Indent -Header "enter -> Set-DSBuildDependentTabsVisibility" # increase indent in log file
    if($Status -eq 'Enabled') { $htext = "enabling" } else { $htext = 'disabling' }
    Write-DSLog -Level info -Message "$htext dependent build tab controls"
    'tiPromoOptions','tiBuildTypeOptions','tiPreBuildOptions','tiPostBuildOptions','tiReviewAndInstall' | foreach {
        $dsui.FindName($_).IsEnabled =  ($Status -eq 'enabled') 
    }
    Remove-Indent -Footer "exit -> Set-DSBuildDependentTabsVisibility" # decrease indent in log file
}

# this function will add all sites of detected forest into sites combo box
# -------------------------------------------------------------------------
Function Set-DSSitesCombo {
    Add-Indent -Header "enter -> Set-DSSitesCombo" # increase indent in log file
    $sites = @(Get-DSADForestSites)
    Write-DSLog -Level info -Message "Detected $($sites.Count) sites in given AD domain, adding them to sites combo"
    Add-DSComboItems -Combo $cboSiteName -ItemsToAdd $sites -ClearExistingItems
    Remove-Indent -Footer "exit -> Set-DSSitesCombo" # decrease indent in log file
}

# this function will add the available volumes in the volume path combo box
# -------------------------------------------------------------------------
Function Set-DSBackupVolumePathCombo {
    Add-Indent -Header "enter -> Set-DSBackupVolumePathCombo" # increase indent in log file
    $drives = [System.IO.DriveInfo]::GetDrives() | Where-Object { $_.DriveType -eq 'Fixed' }
    $df = @($drives | Select-Object Name, @{Name='VolumeInfo';Expression={$_.Name + ' (' + ([math]::round($_.TotalFreeSpace/1GB,2)) + 'GB Free)'}})
    Write-DSLog -Level info -Message "Detected $($df.Count) drives, adding them to backup volume path combo"
    Add-DSComboItems -Combo $cboBackupVolumePath -ItemsToAdd @($df.VolumeInfo) -ClearExistingItems
    Remove-Indent -Footer "exit -> Set-DSBackupVolumePathCombo" # decrease indent in log file
}

# set DS SChema upgrade checkbox based on whether update for given forest is required or not
# -------------------------------------------------------------------------------------------
Function Set-DSSchemaUpgradeControl {
    Add-Indent -Header "enter -> Set-DSSchemaUpgradeControl" # increase indent in log file
    $cbUpgradeADSchema.IsChecked = $False # un-select this checkbox first
    if($promoOpCreds.rights -in ('EnterpriseAdmins','DomainAdmins')) { # creds to perform domain op given
        $f = Get-DSADForestName # get forest name for current connected forest
        Write-DSLog -Level info -Message "Identifying schema version for forest $f"
        $sv = Get-DSADSchemaVersion
        Write-DSLog -Level info -Message "Forest $f, schema version is $sv"
        if($sv -eq $null) {
            Write-DSLog -Level warning -Message "Unable to identify forest schema, unable to determine if schema upgrade is required or not"
        }
        else { 
            Write-DSLog -Level info -Message "Checking if schema upgrade is required or not"
            $sr = Test-DSSchemaUpgradeRequired -schemaVersion $sv
            if($sr) { # schema upgrade required
                Write-DSLog -Level info -Message "Schema upgrade required for forest $f, enabling checkbox for user selection"
                $cbUpgradeADSchema.IsEnabled = $true
            }
            else { 
                Write-DSLog -Level info -Message "Schema upgrade not required for forest $f, disabling checkbox"
                $cbUpgradeADSchema.IsEnabled = $False # upgrade not required
            }
        }
    }
    else { # likely invalid or local admin rights, disable it
        Write-DSLog -Level info -Message "Schema upgrade option not applicable for current domain promotion option selected"
        $cbUpgradeADSchema.IsEnabled = $False
    }
    Remove-Indent -Footer "exit -> Set-DSSchemaUpgradeControl" # decrease indent in log file
}

# this function will set forest root domain (for new tree domain) and parent domain (for new domain tree) control values
# -----------------------------------------------------------------------------------------------------------------------
Function Set-DSExistingDomainControls {
    Add-Indent -Header "enter -> Set-DSExistingDomainControls" # increase indent in log file
    # populate combo for parent domain, set root domain
    Write-DSLog -Level info -Message "setting detected domain names in parent domains combo box"
    $domains = Get-DSADForestDomains 
    Add-DSComboItems -Combo $cboParentDomainName -ItemsToAdd @($domains) -ClearExistingItems
                        
    # set root domain name
    $tbForestName.Text = (Get-DSADForestName)
    Write-DSLog -Level info -Message "setting detected forest name $($tbForestName.Text) in text box"
    Remove-Indent -Footer "exit -> Set-DSExistingDomainControls" # decrease indent in log file
}

# this function will enable/disable/show/hide various controls as per 'new forest' promo option
# ---------------------------------------------------------------------------------------------
Function Set-DSNewForestControls {
    Add-Indent -Header "enter -> Set-DSNewForestControls" # increase indent in log file
    Write-DSLog -Level info -Message "setting controls related to new forest selection"
    # Enable forest and domain functional level selections
    $cboForestFuncLevel, $cboDomainFuncLevel | foreach { $_.IsEnabled = $true }
    
    Set-DSFunctionalModeControls # populate forest/domain functional modes combo with DSSOE supported modes
    
    # disable build type tab as none of the options are required for 'new forest'
    $dsui.FindName('tiBuildTypeOptions').Visibility = 'Collapsed'

    # clear domain controller list and disable controls related to additional DC
    $cboReplicateFromExistingDC.Items.Clear()
    Set-DSADCControlsStatus -Status disabled

    # added 29-feb-16, select and disable global catalog checkbox for new forest
    $cbGlobalCatalog.IsChecked = $true
    $cbGlobalCatalog.IsEnabled = $False

    # added 21-Sep-16, disable IPAM checkbox and related controls and disable ad recycle bin & 
    # ad health check related controls
    # uncheck and disable IPAM checkbox and hide the related controls
    $cbConfigureIPAM.IsEnabled = $False #disable it
    $cbConfigureIPAM.IsChecked = $False #uncheck it
    $cbConfigureIPAM.RaiseEvent($evt) #raise the event to disable the IPAM related controls
    $wpConfigureIPAMOptions,$cbConfigureIPAM | foreach { $_.Visibility = 'Collapsed' } #hide the controls related to IPAM

    # enable and uncheck AD recycle bin and AD health check checkboxes
    $cbEnableADRecycleBin.IsEnabled = $true
    $cbRunADHealthCheck.IsEnabled = $true
    $cbEnableADRecycleBin.IsChecked = $False #uncheck it
    $cbRunADHealthCheck.IsChecked = $False #uncheck it
    $cbEnableADRecycleBin.RaiseEvent($evt) #event raised to disble the AD recyclebin related controls
    $cbRunADHealthCheck.RaiseEvent($evt) # event raised to disable the AD health check related to controls
    
    # disable recyclebin and health check creds validation controls
    $tbADRBHCUser,$tbADRBHCPassword | foreach { $_.IsEnabled = $False }

    # hiding the recycle bin and health check related controls
    $lblValidateCredsForADRBADHC,$wpValidateCredsADRBHC,$wpConfigureADRBOptions,$wpConfigureADHCOptions | foreach { $_.Visibility = 'Collapsed' }

    #enable DNS Scavenging checkbox; Added - 4 Apr, 17 [Tarun]
    $cbConfigureDNSScavenging.IsEnabled = $True
    $cbConfigureDNSScavenging.IsChecked = $False

    #refreshing AD Delegation Selection; Added - 4 Apr, 17 [Tarun]
    $cboAccountType.SelectedIndex = 0 # select first item to fire selectionChanged event of this control
    If($cboAccountType.SelectedItem.Content -ne 'Multitenant') {
        $cbConfigureADDelegation.IsEnabled = $false
        $cbConfigureADDelegation.IsChecked = $false
    }
    
    <#
    # if forest functional level is not selected as Windows 2008 R2 Forest and beyond, the AD recycle bin
    # checkbox will remain disabled for selection
    Write-DSLog -Level info -Message "validating if selected forest mode is appropriate, Windows Server 2008 R2 and beyond, for AD recycle bin - $SelectedForestMode"
    $SelectedForestMode = $cboForestFuncLevel.SelectedItem.Content # selected forest functional level
    # validating if selected FFL is Windows Server 2008 R2 or beyond or not.
    If(!($SelectedForestMode -in ('Windows Server 2008 R2','Windows Server 2012','Windows Server 2012 R2','Windows Server 2016'))) {
        $cbEnableADRecycleBin.IsEnabled = $False
    } #>

    Remove-Indent -Footer "exit -> Set-DSNewForestControls" # decrease indent in log file
}

# this function will enable/disable/show/hide various controls as per 'Additional DC' promo option
# -------------------------------------------------------------------------------------------------
Function Set-DSAdditionalDCControls {
    Add-Indent -Header "enter -> Set-DSAdditionalDCControls" # increase indent in log file

    # enable build type tab so that users can select options from it
    $dsui.FindName('tiBuildTypeOptions').Visibility = 'Visible'

    Set-DSFunctionalModeControls # populate forest/domain functional modes combo with DSSOE supported modes
    
    # add existing domain name into combo, by taking domain name from 'User name' text box
    $seletedDomain = Set-DSExistingDomainCombo 

    # pupulate list of DCs to replicate from
    Write-DSLog -Level info -Message "adding domain controllers of domain $($promoOpCreds.domain) to DCs combo" 
    $dcs = Get-DSADDomainControllers -DomainName $promoOpCreds.domain
    Add-DSComboItems -Combo $cboReplicateFromExistingDC -ItemsToAdd @($dcs) -ClearExistingItems
    
    $fm = (Get-DSADForestMode) # get given forest mode
    $dm = (Get-DSADDomainMode -DomainName $seletedDomain)
    
    Write-DSLog -Level info -Message "forest mode detected is $($fm.ModeDisplayName)" 
    Write-DSLog -Level info -Message "selected domain is $seletedDomain" 
    Write-DSLog -Level info -Message "domain mode detected is $($dm.ModeDisplayName)" 

    # auto-select forest functional mode in the combox box as per detected forest mode
    $fmindex = Get-CBOItemIndex -Combo $cboForestFuncLevel -Content $fm.ModeDisplayName
    Write-DSLog -Level info -Message "index of detected forest mode is $fmindex" 
    $cboForestFuncLevel.SelectedIndex = $fmindex # select forest's actual mode

    # auto-select domain functional mode in the combox box as per detected domain mode
    $dmindex = Get-CBOItemIndex -Combo $cboDomainFuncLevel -Content $dm.ModeDisplayName
    Write-DSLog -Level info -Message "index of detected domain mode is $dmindex" 
    $cboDomainFuncLevel.SelectedIndex = $dmindex # select forest's actual mode

    # populate AD Sites list combo with all sites of detected forest
    Set-DSSitesCombo
    
    $cboForestFuncLevel, $cboDomainFuncLevel | foreach { $_.IsEnabled = $false } # disable these selections

    $cbConfigureDNSScavenging.IsEnabled = $False #disable DNS Scavenging control for ADC build
    $cbConfigureDNSScavenging.IsChecked = $False #uncheck DNS Scavenging control for ADC build

    # enable controls specific to 'additional dc'
    Set-DSADCControlsStatus -Status enabled

    # added 29-feb-16, select and disable global catalog checkbox for new forest
    $cbGlobalCatalog.IsChecked = $true
    $cbGlobalCatalog.IsEnabled = $true

    # added 21-Sep-16, enable IPAM checkbox and related controls and ad recycle bin & 
    # ad health check related controls

    # set the IPAM controls 
    $cbConfigureIPAM.Visibility = 'Visible' 
    $cbConfigureIPAM.IsEnabled = $true
    $cbConfigureIPAM.IsChecked = $False
    $cbConfigureIPAM.RaiseEvent($evt)
    $wpConfigureIPAMOptions.Visibility = 'Collapsed'
        
    #Set ad recycle bin and health check creds validation controls
    $tbADRBHCUser.IsEnabled = $true
    $tbADRBHCPassword.IsEnabled = $true
    $tbADRBHCUser.Text = ""
    $tbADRBHCPassword.Password = ""
    $lblValidateCredsForADRBADHC.Visibility = 'Visible'
    $wpValidateCredsADRBHC.Visibility = 'Visible'

    #set ad recycle bin controls
    $cbEnableADRecycleBin.Visibility = 'Visible'
    $cbEnableADRecycleBin.IsEnabled = $False
    $cbEnableADRecycleBin.IsChecked = $False
    $cbEnableADRecycleBin.RaiseEvent($evt)
    $wpConfigureADRBOptions.Visibility = 'Collapsed'

    #set ad health check controls
    $cbRunADHealthCheck.Visibility = 'Visible'
    $cbRunADHealthCheck.IsEnabled = $False
    $cbRunADHealthCheck.IsChecked = $False
    $cbRunADHealthCheck.RaiseEvent($evt)
    $wpConfigureADHCOptions.Visibility = 'Collapsed'
    
    Remove-Indent -Footer "exit -> Set-DSAdditionalDCControls" # decrease indent in log file
}

# this function will enable/disable/show/hide various controls as per 'new tree domain' promo option
# --------------------------------------------------------------------------------------------------
Function Set-DSNewTreeAndChildDomainControls {
    Add-Indent -Header "enter -> Set-DSNewTreeAndChildDomainControls" # increase indent in log file
    Write-DSLog -Level info -Message "setting controls related to new tree or new child domain selection"
    # enable build type tab so that users can select options from it
    $dsui.FindName('tiBuildTypeOptions').Visibility = 'Visible'

    # clear domain controller list and disable controls related to additional DC
    $cboReplicateFromExistingDC.Items.Clear()
    Set-DSADCControlsStatus -Status disabled

    Set-DSFunctionalModeControls # populate forest/domain functional modes combo with DSSOE supported modes

    $fm = (Get-DSADForestMode) # get given forest mode

    # get index of selected forest/domain modes com
    $fmindex = Get-CBOItemIndex -Combo $cboForestFuncLevel -Content $fm.ModeDisplayName
    Write-DSLog -Level info -Message "auto-selecting detected forest mode $($fm.ModeDisplayName), index $fmindex"
    $cboForestFuncLevel.SelectedIndex = $fmindex # select forest's actual mode

    # disable forest functional mode combo and enable domain functional mode combo
    $cboForestFuncLevel.IsEnabled = $false
    $cboDomainFuncLevel.IsEnabled = $true

    # populate AD Sites list combo with all sites of detected forest.
    Set-DSSitesCombo
    # populate parent domain combo with available forest domains and also forest root domain text box
    Set-DSExistingDomainControls

    # added 29-feb-16, select and disable global catalog checkbox for new forest
    $cbGlobalCatalog.IsChecked = $true
    $cbGlobalCatalog.IsEnabled = $true

    # added 21-Sep-16, enable IPAM checkbox and related controls and  ad recycle bin & 
    # ad health check related controls
        # added 21-Sep-16, enable IPAM checkbox and related controls and ad recycle bin & 
    # ad health check related controls

    # set the IPAM controls 
    $cbConfigureIPAM.Visibility = 'Visible'   
    $cbConfigureIPAM.IsEnabled = $true
    $cbConfigureIPAM.IsChecked = $False
    $cbConfigureIPAM.RaiseEvent($evt)
    $wpConfigureIPAMOptions.Visibility = 'Collapsed'
        
    #Set ad recycle bin and health check creds validation controls
    $tbADRBHCUser.IsEnabled = $true
    $tbADRBHCPassword.IsEnabled = $true
    $tbADRBHCUser.Text = ""
    $tbADRBHCPassword.Password = ""
    $lblValidateCredsForADRBADHC.Visibility = 'Visible'
    $wpValidateCredsADRBHC.Visibility = 'Visible'

    #set ad recycle bin controls
    $cbEnableADRecycleBin.Visibility = 'Visible'
    $cbEnableADRecycleBin.IsEnabled = $False
    $cbEnableADRecycleBin.IsChecked = $False
    $cbEnableADRecycleBin.RaiseEvent($evt)
    $wpConfigureADRBOptions.Visibility = 'Collapsed'

    #set ad health check controls
    $cbRunADHealthCheck.Visibility = 'Visible'
    $cbRunADHealthCheck.IsEnabled = $False
    $cbRunADHealthCheck.IsChecked = $False
    $cbRunADHealthCheck.RaiseEvent($evt)
    $wpConfigureADHCOptions.Visibility = 'Collapsed'

    #enable DNS Scavenging checkbox
    $cbConfigureDNSScavenging.IsEnabled = $True
    $cbConfigureDNSScavenging.IsChecked = $False
    
    #refresh 'cbConfigureADDelegation' checkbox for AD Delegation Checkbox status
    $cboAccountType.SelectedIndex = 0 # select first item to fire selectionChanged event of this control
    If($cboAccountType.SelectedItem.Content -ne 'Multitenant') {
        $cbConfigureADDelegation.IsEnabled = $false
        $cbConfigureADDelegation.IsChecked = $false
    }

    Remove-Indent -Footer "exit -> Set-DSNewTreeAndChildDomainControls" # decrease indent in log file
}

<#
# this function will pre-populate target server and target domain controls for AD Recycle Bin option
# -------------------------------------------------------------------------------------------------
Funtion Set-DSEnableADRecycleBinControls {
    Add-Indent -Header "enter -> Set-DSEnableADRecycleBinControls" # increase indent in log file
    Write-DSLog -Level info -Message "setting 'Target Server' & 'Target Domain' controls for AD Recycle Bin option"


    Remove-Indent -Footer "exit -> Set-DSEnableADRecycleBinControls" # decrease indent in log file
}
#>

# This function will add a line in DS summary TextBlock (formatted)
# -------------------------------------------------------------------
Function Add-DSSummaryLine($Label, $Value, $Foreground = "Blue", [switch] $LineBreakAfter, [switch] $BlanksAsRed, [switch]$Bold) {
    # define variables to hold label controls that will be added to textBlock after formatting
    $RunLabel = New-Object System.Windows.Controls.Label # label portion of the line
    $RunValue = New-Object System.Windows.Controls.Label  # value portion of the line
    $bc = New-Object System.Windows.Media.BrushConverter # background color for labels

    # if given value is blank and BlankAsRed is specified then make it red else black
    if(([string]::IsNullOrEmpty($Value)) -and $BlanksAsRed) { $RunLabel.Foreground = "Red"  } 
    else { $RunLabel.Foreground = "Black" }

    # user explicitly specified foreground color other than default, override default for runLabel
    if($Foreground -ne 'Blue') { $RunLabel.Foreground = $Foreground }
    # make font bold for label portion if specified 
    if($Bold) { $RunLabel.FontWeight = [System.Windows.FontWeights]::SemiBold }
    $RunLabel.Content = $Label
    
    # alternate background color for labels
    if(($tbSummary.Inlines.Count % 2) -eq 0) { $lbcolor = $bc.ConvertFrom('#FFD6E6F4') } 
    else { $lbcolor = $bc.ConvertFrom('#FFF5F5F5') }
    $RunLabel.Background = $lbcolor
    $RunLabel.Width = 384

    # if given value is blank and BlankAsRed is specified then make it red else default blue - value portion only
    if(([string]::IsNullOrEmpty($Value)) -and $BlanksAsRed) { 
        $RunValue.Foreground = "Red" 
        $RunValue.Content = "<Blank or value not selected>"
        $btnStartBuild.IsEnabled = $False # disable build button on any empty value (with blankonred specified)
    } 
    else { 
        $RunValue.Foreground = $Foreground 
        $RunValue.Content = "$Value"
    }
    $RunValue.Background = $lbcolor
    $RunValue.Width = 380
    
    # add labels in textblock control
    $tbSummary.Inlines.Add($RunLabel)
    $tbSummary.Inlines.Add($RunValue)
    if($LineBreakAfter) { $tbSummary.Inlines.Add((New-Object System.Windows.Documents.LineBreak)) }
}
#endregion

<#
# Beta build warning message
$BetaBuildWarningMessage = "Please be noted that this is a Beta QA build, based on the Technical Preview of Windows Server 2016. Do not use this package to build domain controllers in production environment."
[System.Windows.Forms.MessageBox]::Show($BetaBuildWarningMessage,"DSSOE GUI Installer - Beta QA Build","OK","Warning") | Out-Null
#>


#region Validate And Load DSSOE Modules
#validate and load required DSSOE modules (using $psscriptpath)
$modsValid = $true
foreach( $module in ('dsUtils.psm1','dsLogger.psm1','LogCallerPref.psm1','DSImplement.psm1','DSValidate.psm1','dsui.psm1','ADFromWorkgroup.psm1','psprogress.psm1')) {
    $cModulePath = "$PSScriptRoot\..\modules\$module"
    if(-not (Test-Path -Path $cModulePath)) {
        $tempErr = "Unable to find and load $cModulePath. Verify that this module exists and try again."
        [System.Windows.Forms.MessageBox]::Show($tempErr,"DSSOE GUI Installer","OK","Error")
        return 'dssoe_modules_load_error'
        break
        
    }
}
 
#importing all the DSSOE modules
Import-Module "$PSScriptRoot\..\Modules\LogCallerPref.psm1" -Force
Import-Module "$PSScriptRoot\..\Modules\DSLogger.psm1" -Force
Import-Module "$PSScriptRoot\..\Modules\DSUtils.psm1" -Force
Import-Module "$PSScriptRoot\..\Modules\DSValidate.psm1" -Force
Import-Module "$PSScriptRoot\..\Modules\DSImplement.psm1" -Force
Import-Module "$PSScriptRoot\..\Modules\dsui.psm1" -Force
Import-Module "$PSScriptRoot\..\Modules\ADFromWorkgroup.psm1" -Force
Import-Module "$PSScriptRoot\..\Modules\psprogress.psm1" -Force

# call verbose writing functions
Set-CallerVerbosePreference
Set-CallerDebugPreference
#endregion Validate And Load DSSOE Modules

#region Test If User Is Admin or not
# checking if script is running with administrative privileges; calling function from dsutils.psm1
If((Test-IsCurrentUserAdmin) -eq $false) {
    $tempErr = "This script must be run using administrative privileges."
    [System.Windows.Forms.MessageBox]::Show($tempErr,"DSSOE GUI Installer","OK","Error")
    return 'ds_no_admin_privileges'
    Exit
}
#endregion Test If User Is Admin or not

#region change verbose message background
((Get-Host).PrivateData).VerboseBackgroundColor =($host.UI.RawUI).BackGroundColor;
#endregion

#region Set log path to static location C:\Support\Logs\DSSOE
$LogPath = "C:\Support\Logs\DSSOE"
#endregion

#region create the logpath folder, set log file path & start the logging
#checking if logfile folder C:\Support\Logs\DSSOE exists; create if it does not
If(-not (Test-Path $LogPath)) {
    New-Item -ItemType Directory -Path $LogPath -Force | Out-Null
}

[string] $DSLogFile = "$($LogPath)\dsui-$((Get-Date).ToString('MMddyyyy-hhmmss')).log"
#calling functions from the dslogger.psm1 module
Set-DSLogFile -LogPath $DSLogFile
# script name as log header
Write-DSLog -Message "[$($PSCommandPath.Split('\')[-1])]" 
Write-DSLog -Level info -Message "DSSOE GUI Installer - script logging started" 
#endregion create the logpath folder, set log file path & start the logging

# region verify this server is not a domain controller! 
if((Test-ServerIsDC) -eq $true) {
    $tempErr = "Server $($env:COMPUTERNAME) is already a domain controller. DSSOE setup cannot continue."
    Write-DSLog -level error -message $tempErr
    [System.Windows.Forms.MessageBox]::Show($tempErr,"DSSOE GUI Installer","OK","Error")
    return 'ds_server_is_already_dc'
    exit
}
#endregion


#region Verify that this server is built using a valid supported SOE
# checking if running on a server built using Windows Server SOE
If((Test-WindowsSOEVersion) -ne $true) {
    $tempErr = "The Operating System on this sever was detected to not have been provisioned using a supported DXC SOE. DSSOE does not support non-SOE provisioned servers. Please ensure the server has been prepared using the latest supportable Windows Server SOE and POST-SOE production patching has been applied prior to running the DS-SOE. Running the DS-SOE without the core baseline OS configuration provided by the Windows Server SOE will result in a non-standard Domain Controller subject to a diminished security posture and Best Effort Support. If you need to proceed with this, obtain approval from your Cybersecurity Account Security Manager and contact Platform_Wintel_SOE@csc.com for more information."
    Write-DSLog -Level error -Message $tempErr
    [System.Windows.Forms.MessageBox]::Show($tempErr,"DSSOE GUI Installer","OK","Error")
    return 'ds_not_soe'
    Exit
}
Else {
    Write-DSLog -Level info -Message "Windows SOE Version is successfully validated"
}
#endregion Verify that this server is built using a valid supported SOE



#region Validating if the baseline operating system is supported by DSSOE or not
# The DSSOE 3.0.0 supported operating systems are Windows Server 2016
#using get-osversion function from DSUtils.psm1 module to retrieve the version of the operating system
If(-not((Get-OSVersion) -in ("6.1","6.2","6.3","10.0"))) {
    $tempErr = "The baseline operating system is not supported by this version of DSSOE. DSSOE program is terminating. For more information contact platform_wintel_soe@csc.com."
    Write-DSLog -Level error -Message $tempErr
    [System.Windows.Forms.MessageBox]::Show($tempErr,"DSSOE GUI Installer","OK","Error")
    return 'ds_unsupported_os'
    Exit
}
#endregion Validating if the baseline operating system is supported by DSSOE or not


#region check if server has any interface with DHCP assigned IP address, in that case show a warning
# check if any interface has IPEnabled
$ipe = @(Get-WmiObject Win32_NetworkAdapterConfiguration | where { $_.IPEnabled -eq $True })
if($ipe.Count -eq 0) { # none are IP enabled!! show error and exit
    $tempErr = "DSSOE setup has determined that none of the network interfaces are enabled for IP configuration. The TCP/IP networking protocol must be properly configured. Complete the configuration and try again."
    Write-DSLog -Level error -Message $tempErr
    [System.Windows.Forms.MessageBox]::Show($tempErr,"DSSOE GUI Installer","OK","Error")
    return 'ds_tcpip_conf_error'
    exit
}
# get whether server has at least one interface with dhcp ip configured
$dhcpconf = Test-DSServerHasDHCPIP
$hasDHCP = "" 
if($dhcpconf -eq $true) { 
    $hasDHCP = "true"
    $tempErr = "This computer has at least one physical network adapter that does not have static IP address(es) assigned to its IP Properties. If both IPv4 and IPv6 are enabled for a network adapter, both IPv4 and IPv6 static IP addresses should be assigned to both IPv4 and IPv6 Properties of the physical network adapter. Such static IP address(es) assignment should be done to all the physical network adapters for reliable Domain Name System (DNS) operation."
    Write-DSLog -Level warning -Message $tempErr
    [System.Windows.Forms.MessageBox]::Show($tempErr,"DSSOE GUI Installer","OK","Warning") | Out-Null    
}
Else {
    $hasDHCP = "false"
}
#endregion 

#region create guid
#$pkey = [guid]::NewGuid().Guid
$pkey = [guid]::NewGuid().Guid.Replace('-','')
#endregion

#region load dssoe gui elements
# Read the Build Manager UI XAML code stored separately, into $xaml and use it to load the form
[xml] $xaml = get-content "$PSScriptRoot\dsui.xaml"
$reader = (New-Object System.Xml.XmlNodeReader $xaml) 
[System.Windows.Window] $dsui = [Windows.Markup.XamlReader]::Load($reader) 
#endregion


#region define variables for UI controls that will be used in code
$btnApplyStaticIP = $dsui.FindName("btnApplyStaticIP")
$btnValidateCreds = $dsui.FindName("btnValidateCreds")
$btnExit = $dsui.FindName("btnExit")
$btnIFMBrowse = $dsui.FindName("btnIFMBrowse")
$btnSelectExistingDomainName = $dsui.FindName("btnSelectExistingDomainName")
$btnSelectParentDomainName = $dsui.FindName("btnSelectParentDomainName")
$btnStartBuild = $dsui.FindName("btnStartBuild")
$cbAdditionalDNS = $dsui.FindName("cbAdditionalDNS")
#$cbBPAReport = $dsui.FindName("cbBPAReport")
$cbClearEvents = $dsui.FindName("cbClearEvents")
$cbConfigPageFile = $dsui.FindName("cbConfigPageFile")
$cbCreateBulkUsers = $dsui.FindName("cbCreateBulkUsers")
$cbCreateReserveFile = $dsui.FindName("cbCreateReserveFile")
$cbCriticalReplOnly = $dsui.FindName("cbCriticalReplOnly")
$cbDCPlacementOU = $dsui.FindName("cbDCPlacementOU")
$cbDCSecPol = $dsui.FindName("cbDCSecPol")
$cbDFSR = $dsui.FindName("cbDFSR")
$cbDomainSecPol = $dsui.FindName("cbDomainSecPol")
$cbEnableBackupMaint = $dsui.FindName("cbEnableBackupMaint")
$cbEnableLMHosts = $dsui.FindName("cbEnableLMHosts")
$cbEnableScheduledBackup = $dsui.FindName("cbEnableScheduledBackup")
$cbExtTimeSyncServer = $dsui.FindName("cbExtTimeSyncServer")
#$cbFRS = $dsui.FindName("cbFRS")
$cbGlobalCatalog = $dsui.FindName("cbGlobalCatalog")
$cbIFM = $dsui.FindName("cbIFM")
$cbInstallDNS = $dsui.FindName("cbInstallDNS")
$cbNetlogon = $dsui.FindName("cbNetlogon")
$cbNTDS = $dsui.FindName("cbNTDS")
$cboAccountType = $dsui.FindName("cboAccountType")
$cboBackupVolumePath = $dsui.FindName("cboBackupVolumePath")
$cboDomainFuncLevel = $dsui.FindName("cboDomainFuncLevel")
$cboForestFuncLevel = $dsui.FindName("cboForestFuncLevel")
$cboNetAdapter = $dsui.FindName("cboNetAdapter")
$cboReplicateFromExistingDC = $dsui.FindName("cboReplicateFromExistingDC")
$cboSiteName = $dsui.FindName("cboSiteName")
$cbReplicateFromExistingDC = $dsui.FindName("cbReplicateFromExistingDC")
$cbRODC = $dsui.FindName("cbRODC")
$cbSubnetSiteAssoc = $dsui.FindName("cbSubnetSiteAssoc")
$dopTab = $dsui.FindName("dopTab")
$dopTiNewForest = $dsui.FindName("dopTiNewForest")
$dopTiAdditionalDC = $dsui.FindName("dopTiAdditionalDC")
$dopTiNewChildDomain = $dsui.FindName("dopTiNewChildDomain")
$dopTiNewTreeDomain = $dsui.FindName("dopTiNewTreeDomain")
$gridADCOptions = $dsui.FindName("gridADCOptions")
$gridChildDomainOptions = $dsui.FindName("gridChildDomainOptions")
$gridConfiguration = $dsui.FindName("gridConfiguration")
$gridDomainTreeOptions = $dsui.FindName("gridDomainTreeOptions")
$gridForestOptions = $dsui.FindName("gridForestOptions")
$gridInstallType = $dsui.FindName("gridInstallType")
$gridReadyToBuild = $dsui.FindName("gridReadyToBuild")
$gridStaticIPOptions = $dsui.FindName("gridStaticIPOptions")
#$lblBPAReportPath = $dsui.FindName("lblBPAReportPath")
$lblBulkUserFile = $dsui.FindName("lblBulkUserFile")
$mnuExit = $dsui.FindName("mnuExit")
$mnuExportConfig = $dsui.FindName("mnuExportConfig")
$mnuOpenLog = $dsui.FindName("mnuOpenLog")
$mnuNotepad = $dsui.FindName("mnuNotepad")
$mnuTools = $dsui.FindName("mnuTools")
$rbAdditionalDC = $dsui.FindName("rbAdditionalDC")
$rbExpressBuild = $dsui.FindName("rbExpressBuild")
$rbNewChildDomain = $dsui.FindName("rbNewChildDomain")
$rbNewForest = $dsui.FindName("rbNewForest")
$rbNewTreeDomain = $dsui.FindName("rbNewTreeDomain")
$rbStandardBuild = $dsui.FindName("rbStandardBuild")
$smAdminPassword = $dsui.FindName("smAdminPassword")
$smAdminPassword2 = $dsui.FindName("smAdminPassword2")
$spDeploymentOp = $dsui.FindName("spDeploymentOp")
$spIP = $dsui.FindName("spIP")
$spReserveFileOptions = $dsui.FindName("spReserveFileOptions")
$tbAccountCode = $dsui.FindName("tbAccountCode")
$tbADDSLog = $dsui.FindName("tbADDSLog")
$tbADDSPath = $dsui.FindName("tbADDSPath")
$tbADDSSysvol = $dsui.FindName("tbADDSSysvol")
#$tbBPAReportPath = $dsui.FindName("tbBPAReportPath")
$tbBulkUserFile = $dsui.FindName("tbBulkUserFile")
$tbChildDomainName = $dsui.FindName("tbChildDomainName")
$tbChildDomainNetBiosName = $dsui.FindName("tbChildDomainNetBiosName")
$cbConfigDNSForwarders = $dsui.FindName("cbConfigDNSForwarders")
$tbDCPlacementOU = $dsui.FindName("tbDCPlacementOU")
$tbDFSR = $dsui.FindName("tbDFSR")
$tbDNS = $dsui.FindName("tbDNS")
$tbDNSForwarders = $dsui.FindName("tbDNSForwarders")
$tbEntAdminPassword = $dsui.FindName("tbEntAdminPassword")
$tbEntAdminUserName = $dsui.FindName("tbEntAdminUserName")
$cboExistingDomainName = $dsui.FindName("cboExistingDomainName")
$tbExtTimeSyncServer = $dsui.FindName("tbExtTimeSyncServer")
$tbForestName = $dsui.FindName("tbForestName")
#$tbFRS = $dsui.FindName("tbFRS")
$tbGateway = $dsui.FindName("tbGateway")
$tbIFMPath = $dsui.FindName("tbIFMPath")
$lblIFMPath = $dsui.FindName("lblIFMPath")
$tbIPAddress = $dsui.FindName("tbIPAddress")
$tbNetDNSSuffix = $dsui.FindName("tbNetDNSSuffix")
$tbNetlogon = $dsui.FindName("tbNetlogon")
$tbNewTreeDomainName = $dsui.FindName("tbNewTreeDomainName")
$tbNewTreeDomainNetBiosName = $dsui.FindName("tbNewTreeDomainNetBiosName")
$tbNTDS = $dsui.FindName("tbNTDS")
$cboParentDomainName = $dsui.FindName("cboParentDomainName")
$tbPassword = $dsui.FindName("tbPassword")
$tbReserveFilePath = $dsui.FindName("tbReserveFilePath")
$tbReserveFileSize = $dsui.FindName("tbReserveFileSize")
$tbRootDomainName = $dsui.FindName("tbRootDomainName")
$tbRootDomainNetBiosName = $dsui.FindName("tbRootDomainNetBiosName")
$tbSiteSubnetMask = $dsui.FindName("tbSiteSubnetMask")
$tbSubnet = $dsui.FindName("tbSubnet")
$tbSummary = $dsui.FindName("tbSummary")
$tbUserName = $dsui.FindName("tbUserName")
#$tbWins = $dsui.FindName("tbWins")
$wpReserveFile = $dsui.FindName("wpReserveFile")
$wpStartupRecovery = $dsui.FindName("wpStartupRecovery")
# variables added after later stage updation/addition of GUI controls
$lblLogPath = $dsui.FindName('lblLogPath')
$cbADPathToOSDrive = $dsui.FindName('cbADPathToOSDrive')
$cbUpgradeADSchema = $dsui.FindName('cbUpgradeADSchema')
#IPAM Controls
$cbConfigureIPAM = $dsui.FindName('cbConfigureIPAM')
$tbIPAMUniversalGroup = $dsui.FindName('tbIPAMUniversalGroup')
$tbIPAMServerName = $dsui.FindName('tbIPAMServerName')
$wpConfigureIPAMOptions = $dsui.FindName('wpConfigureIPAMOptions')
#Controls for AD recycle bin & AD health check credential validation
$lblValidateCredsForADRBADHC = $dsui.FindName('lblValidateCredsForADRBADHC')
$wpValidateCredsADRBHC = $dsui.FindName('wpValidateCredsADRBHC')
$lblEntAdminUserNameADRBHC = $dsui.FindName('lblEntAdminUserNameADRBHC')
$tbADRBHCUser = $dsui.FindName('tbADRBHCUser')
$lblEntAdminUserNameDescADRBHC = $dsui.FindName('lblEntAdminUserNameDescADRBHC')
$lblEntAdminPasswordADRBHC = $dsui.FindName('lblEntAdminPasswordADRBHC')
$tbADRBHCPassword = $dsui.FindName('tbADRBHCPassword')
$btnValidateCredsADRBHC = $dsui.FindName('btnValidateCredsADRBHC')
#AD Recycle Bin Controls
$cbEnableADRecycleBin = $dsui.FindName('cbEnableADRecycleBin')
$lblADRecycleBinScope = $dsui.FindName('lblADRecycleBinScope')
$cboADRecycleBinScope = $dsui.FindName('cboADRecycleBinScope')
$lblADRecycleBinTargetServer = $dsui.FindName('lblADRecycleBinTargetServer')
$tbADRecycleBinTargetServer = $dsui.FindName('tbADRecycleBinTargetServer')
$wpConfigureADRBOptions = $dsui.FindName('wpConfigureADRBOptions')
#$lblADRecycleBinTargetServerFQDN = $dsui.FindName('lblADRecycleBinTargetServerFQDN')
$lblADRecycleBinTargetDomain = $dsui.FindName('lblADRecycleBinTargetDomain')
$cboADRecycleBinDomain = $dsui.FindName('cboADRecycleBinDomain')
#AD health check reporting controls
$lblADHealthCheckReporting = $dsui.FindName('lblADHealthCheckReporting')
$cbRunADHealthCheck = $dsui.FindName('cbRunADHealthCheck')
$lblDomainNamesADHC = $dsui.FindName('lblDomainNamesADHC')
$lboSelectDomainsADHC = $dsui.FindName('lboSelectDomainsADHC')
$cbSelectAll = $dsui.FindName('cbSelectAll')
$wpConfigureADHCOptions = $dsui.FindName('wpConfigureADHCOptions')
#New Controls - MWS requirements
$cbDisableNetBIOSOverTCPIP = $dsui.FindName('cbDisableNetBIOSOverTCPIP')
$cbDisableSMB = $dsui.FindName('cbDisableSMB')
$cbRPCPortRestriction = $dsui.FindName('cbRPCPortRestriction')
$tbRPCPortRange = $dsui.FindName('tbRPCPortRange')
$cbConfigureADDelegation = $dsui.FindName('cbConfigureADDelegation')
$cbInstallADHotfixes = $dsui.FindName('cbInstallADHotfixes')
$cbConfigureDNSScavenging = $dsui.FindName('cbConfigureDNSScavenging')
$cbConfigureDSRM = $dsui.FindName('cbConfigureDSRM')
#endregion 


#region event handlers for various controls for dynamic UI changes
# event handler for 'Express Build' radio button
# ----------------------------------------------
$rbExpressBuild.add_Click({
    $dsui.FindName("tiPreBuildOptions").Visibility = "Collapsed"
    $dsui.FindName("tiPostBuildOptions").Visibility = "Collapsed"
})

# event handler for 'Standard Build' radio button
# ------------------------------------------------
$rbStandardBuild.add_Click({
    $dsui.FindName("tiPreBuildOptions").Visibility = "Visible"
    $dsui.FindName("tiPostBuildOptions").Visibility = "Visible"
})

#region event handlers for all 4 'deployment options' radio buttons
# event handler for 'Add a new forest' radio button
# --------------------------------------------------
$rbNewForest.add_Click({
    Add-Indent -Header "enter -> rbNewForest.add_Click event" # increase indent in log file
    Write-DSLog -Level info -Message "radio button for 'new forest' selected"
    Set-DSBuildDependentTabsVisibility -Status Enabled # enable dependent build tabs

    ('dopTiAdditionalDC', 'dopTiNewChildDomain', 'dopTiNewTreeDomain') | foreach {
        $dsui.FindName($_).Visibility = "Collapsed"
    }
    $dsui.FindName('dopTiNewForest').Visibility = "Visible"
    $dsui.FindName('dopTiNewForest').IsSelected = $true
    
    Set-DSNewForestControls # set controls display and data population as per 'new forest' option

    Remove-Indent -Footer "exit -> rbNewForest.add_Click event" # decrease indent in log file
})

# event handler for 'Add a domain controller to existing domain' radio button
# ----------------------------------------------------------------------------
$rbAdditionalDC.add_Click({
    Add-Indent -Header "enter -> rbAdditionalDC.add_Click event" # increase indent in log file
    Write-DSLog -Level info -Message "radio button for 'domain controller for existing domain' selected"

    Set-DSBuildDependentTabsVisibility -Status Enabled # enable dependent build tabs

    ('dopTiNewForest', 'dopTiNewChildDomain', 'dopTiNewTreeDomain') | foreach {
        $dsui.FindName($_).Visibility = "Collapsed"
    }
    $dsui.FindName('dopTiAdditionalDC').Visibility = "Visible"
    $dsui.FindName('dopTiAdditionalDC').IsSelected = $true
    
    Set-DSAdditionalDCControls # set controls display and data population as per 'additional DC' option

    Remove-Indent -Footer "exit -> rbAdditionalDC.add_Click event" # decrease indent in log file
})

# event handler for 'Add a new child domain to an existing forest' radio button
# -----------------------------------------------------------------------------
$rbNewChildDomain.add_Click({
    Add-Indent -Header "enter -> rbNewChildDomain.add_Click event"
    Write-DSLog -Level info -Message "radio button for 'new child domain' selected"
    Set-DSBuildDependentTabsVisibility -Status Enabled # enable dependent build tabs

    ('dopTiNewForest', 'dopTiAdditionalDC', 'dopTiNewTreeDomain') | foreach {
        $dsui.FindName($_).Visibility = "Collapsed"
    }
    $dsui.FindName('dopTiNewChildDomain').Visibility = "Visible"
    $dsui.FindName('dopTiNewChildDomain').IsSelected = $true
    
    Set-DSNewTreeAndChildDomainControls # set controls display and data population as per 'new child domain' option
    
    Remove-Indent -Footer "exit -> rbNewChildDomain.add_Click event"
})

# event handler for 'Add a new child domain to an existing forest' radio button
# -----------------------------------------------------------------------------
$rbNewTreeDomain.add_Click({
    Add-Indent -Header "enter -> rbNewTreeDomain.add_Click event"
    Write-DSLog -Level info -Message "radio button for 'new tree domain' selected"

    Set-DSBuildDependentTabsVisibility -Status Enabled # enable dependent build tabs

    ('dopTiNewForest', 'dopTiAdditionalDC', 'dopTiNewChildDomain') | foreach {
        $dsui.FindName($_).Visibility = "Collapsed"
    }
    $dsui.FindName('dopTiNewTreeDomain').Visibility = "Visible" 
    $dsui.FindName('dopTiNewTreeDomain').IsSelected = $true
    
    Set-DSNewTreeAndChildDomainControls # set controls display and data population as per 'new domain tree' option
    
    Remove-Indent -Footer "exit -> rbNewTreeDomain.add_Click event"
})
#endregion

# Event handler for 'Root Domain Name' text box
# ----------------------------------------------
$tbRootDomainName.add_PreviewLostKeyboardFocus({
    Add-Indent -Header "enter -> tbRootDomainName.add_PreviewLostKeyboardFocus event" # increase indent in log file
    Show-ProgressWindow -Activity "Please wait while root domain name is validated" -Status ("Validating {0}" -f $tbRootDomainName.Text.Trim())
    Write-DSLog -Level info -Message "Validating given root domain name $($tbRootDomainName.Text)"
    $isForestNameValid = Test-DomainName -Name $tbRootDomainName.Text.Trim()
    if($isForestNameValid -eq $false) { 
        Close-ProgressWindow # close the progress window once validation is complete
        Write-DSLog -Level error -Message "Root domain name validation failed, please enter a valid root domain name."
        Show-DSDialog -Message "Root domain name validation failed, please enter a valid root domain name."
        $tbRootDomainName.Focus()
        $_.Handled = $true
    }
    else { # root domain name validated, auto-generate netbios name
        Write-DSLog -Level info -Message "Root domain name validated successfully"
        $nbname = $tbRootDomainName.Text.Split(".")[0]
        Set-ProgressControls -Label1 "Please wait while root domain NetBIOS name is validated" -Label2 "Validating auto-generated NetBIOS name `"$nbname`""
        Write-DSLog -Level info -Message "Validating auto-generated NetBIOS domain name $nbname"
        if((Test-NetBIOSName -Name $nbName) -eq $true) { 
            $tbRootDomainNetBiosName.Text = $nbname
            Write-DSLog -Level info -Message "Root domain NetBIOS name $nbname validated successfully, adding it to NetBIOS name text box"
            $tbRootDomainNetBiosName.Tag = $tbRootDomainNetBiosName.Text # set validated text as tag
        }
        else {
            Write-DSLog -Level error -Message "Root domain NetBIOS name $nbname validation failed, it will not be auto-populated in NetBIOS name text box"
            $tbRootDomainNetBiosName.Tag = ""
        } 
    }
    Close-ProgressWindow # close the progress window once validation is complete
    Remove-Indent -Footer "exit -> tbRootDomainName.add_PreviewLostKeyboardFocus event"
})

# Event handler for 'Root Domain Netbios Name' text box 
# -----------------------------------------------------
$tbRootDomainNetBiosName.add_PreviewLostKeyboardFocus({
    Add-Indent -Header "enter -> tbRootDomainNetBiosName.add_PreviewLostKeyboardFocus event" # increase indent in log file
    if($tbRootDomainNetBiosName.Text -eq $tbRootDomainNetBiosName.Tag) {
        Write-DSLog -Level info -Message "NetBIOS name already validated and not changed, skip further validation"
        Remove-Indent -Footer "exit -> tbRootDomainNetBiosName.add_PreviewLostKeyboardFocus event"
        return
    }
    Show-ProgressWindow -Activity "Please wait while root domain NetBIOS name is validated" -Status ("Validating {0}" -f $tbRootDomainNetBiosName.Text.Trim())
    Write-DSLog -Level info -Message "Validating given root domain NetBIOS name $($tbRootDomainNetBiosName.Text)"
    $nbValid = Test-NetBIOSName -Name $tbRootDomainNetBiosName.Text.Trim()
    Close-ProgressWindow # close the progress window once validation is complete
    if($nbValid -eq $false) { 
        Write-DSLog -Level error -Message "Root domain NetBIOS name validation failed. Please enter a valid NetBIOS name"
        Show-DSDialog -Message "Root domain NetBIOS name validation failed. Please enter a valid NetBIOS name" | Out-Null
        $tbRootDomainNetBiosName.Focus()
        $_.Handled = $true
    }
    else {
        Write-DSLog -Level info -Message "Root domain NetBIOS name validated successfully"
        Close-ProgressWindow # close the progress window once validation is complete
        $tbRootDomainNetBiosName.Tag = $tbRootDomainNetBiosName.Text # update tag
    }
    Remove-Indent -Footer "exit -> tbRootDomainNetBiosName.add_PreviewLostKeyboardFocus event"
})

# Event handler for 'Child Domain Name' text box when it is about to receive focus
# validate to ensure that parent domain is selected first (for child domain lost focus validation)
# -------------------------------------------------------------------------------------------------
$tbChildDomainName.add_PreviewGotKeyboardFocus({
    if($cboParentDomainName.SelectedIndex -eq -1) { 
        $cboParentDomainName.focus() 
        Show-DSDialog -Message "Please select parent domain name before specifying child domain name"
        $_.Handled = $true
    }
})

# Event handler for 'Child Domain Name' text box when it is about to lose focus
# ------------------------------------------------------------------------------
$tbChildDomainName.add_PreviewLostKeyboardFocus({
    Add-Indent -Header "enter -> tbChildDomainName.add_PreviewLostKeyboardFocus event" # increase indent in log file
    Show-ProgressWindow -Activity "Please wait while child domain name is validated" -Status ("Validating {0}.{1}" -f $tbChildDomainName.Text,$cboParentDomainName.SelectedItem.Content)
    Write-DSLog -Level info -Message "Validating given child domain name $($tbChildDomainName.Text).$($cboParentDomainName.SelectedItem.Content)"
    $res = Test-DSChildDomainName -ChildDomainName $tbChildDomainName.Text -ParentDomainName $cboParentDomainName.SelectedItem.Content
    if($res -eq $false) {
        Close-ProgressWindow # close the progress window once validation is complete
        Write-DSLog -Level error -Message "Child domain name validation failed, please enter a valid child domain name"
        Show-DSDialog -Message "Child domain name validation failed, please enter a valid child domain name"
        $tbChildDomainName.Focus()
        $_.Handled = $true
    }
    else { # child domain name validated, auto-generate netbios name
        Write-DSLog -Level info -Message "Child domain name validated successfully"
        $nbname =  $tbChildDomainName.Text # child domain netbios name is child domain name (flat) as given in text box
        Set-ProgressControls -Label1 "Please wait while child domain NetBIOS name is validated" -Label2 "Validating auto-generated NetBIOS name `"$nbname`""
        Write-DSLog -Level info -Message "Validating auto-generated child domain NetBIOS name $nbname"
        if((Test-NetBIOSName -Name $nbName) -eq $true) { 
            $tbChildDomainNetBiosName.Text = $nbname
            Write-DSLog -Level info -Message "Child domain NetBIOS name $nbname validated successfully, adding it to NetBIOS name text box"
            $tbChildDomainNetBiosName.Tag = $tbChildDomainNetBiosName.Text # set validated text as tag
        } 
        else {
            Write-DSLog -Level error -Message "Child domain NetBIOS name $nbname validation failed, it will not be auto-populated in NetBIOS name text box"
            $tbChildDomainNetBiosName.Tag = "" # blank it on failure
        }
    }
    Close-ProgressWindow # close the progress window once validation is complete
    Remove-Indent -Footer "exit -> tbChildDomainName.add_PreviewLostKeyboardFocus event"
})

# Event handler for 'Child Domain Netbios Name' text box 
# -----------------------------------------------------
$tbChildDomainNetBiosName.add_PreviewLostKeyboardFocus({
    Add-Indent -Header "enter -> tbChildDomainNetBiosName.add_PreviewLostKeyboardFocus event" # increase indent in log file
    if($tbChildDomainNetBiosName.Text -eq $tbChildDomainNetBiosName.Tag) {
        Write-DSLog -Level info -Message "NetBIOS name already validated and not changed, skip further validation"
        Remove-Indent -Footer "exit -> tbChildDomainNetBiosName.add_PreviewLostKeyboardFocus event"
        return
    }
    Write-DSLog -Level info -Message "Validating given child domain NetBIOS name $($tbChildDomainNetBiosName.Text)"
    Show-ProgressWindow -Activity "Please wait while child domain NetBIOS name is validated" -Status ("Validating {0}" -f $tbChildDomainNetBiosName.Text.Trim())
    $nbValid = (Test-NetBIOSName -Name $tbChildDomainNetBiosName.Text.Trim())
    Close-ProgressWindow # close the progress window once validation is complete
    if($nbValid -eq $false) { 
        Write-DSLog -Level error -Message "Child domain NetBIOS name validation failed. Please enter a valid NetBIOS name"
        Show-DSDialog -Message "Child domain NetBIOS name validation failed. Please enter a valid NetBIOS name" | Out-Null
        $tbChildDomainNetBiosName.Focus()
        $_.Handled = $true
    }
    else {
        Write-DSLog -Level info -Message "Child domain NetBIOS name validated successfully"
        Close-ProgressWindow # close the progress window once validation is complete
        $tbChildDomainNetBiosName.Tag = $tbChildDomainNetBiosName.Text # update tag
    }
    Remove-Indent -Footer "exit -> tbChildDomainNetBiosName.add_PreviewLostKeyboardFocus event"
})

# Event handler for 'New Tree Domain Name' text box
# ----------------------------------------------
$tbNewTreeDomainName.add_PreviewLostKeyboardFocus({
    Add-Indent -Header "enter -> tbNewTreeDomainName.add_PreviewLostKeyboardFocus event" # increase indent in log file
    Write-DSLog -Level info -Message "Validating given new tree domain name $($tbNewTreeDomainName.Text)"
    Show-ProgressWindow -Activity "Please wait while new tree domain name is validated" -Status ("Validating {0}" -f $tbNewTreeDomainName.Text.Trim())
    $res = Test-DomainName -Name $tbNewTreeDomainName.Text
    if($res -eq $false) {
        Close-ProgressWindow # close the progress window once validation is complete
        Write-DSLog -Level error -Message "New tree domain name validation failed, please enter a valid new tree domain name"
        Show-DSDialog -Message "New tree domain name validation failed, please enter a valid new tree domain name."
        $tbNewTreeDomainName.Focus()
        $_.Handled = $true
    }
    else { # child domain name validated, auto-generate netbios name
        Write-DSLog -Level info -Message "New tree domain name validated successfully"
        $nbname = $tbNewTreeDomainName.Text.Split(".")[0] # new treedomain netbios name is first part of new tree domain name
        Set-ProgressControls -Label1 "Please wait while tree domain NetBIOS name is validated" -Label2 "Validating auto-generated NetBIOS name `"$nbname`""
        Write-DSLog -Level info -Message "Validating auto-generated new tree domain NetBIOS name $nbname"
        if((Test-NetBIOSName -Name $nbName) -eq $true) { 
            $tbNewTreeDomainNetBiosName.Text = $nbname
            Write-DSLog -Level info -Message "New tree domain NetBIOS name $nbname validated successfully, adding it to NetBIOS name text box"
            $tbNewTreeDomainNetBiosName.Tag = $tbNewTreeDomainNetBiosName.Text # set validated text as tag
        } 
        else {
            Write-DSLog -Level error -Message "New tree domain NetBIOS name $nbname validation failed, it will not be auto-populated in NetBIOS name text box"
            $tbNewTreeDomainNetBiosName.Tag = "" # blank it
        } 
    }
    Close-ProgressWindow # close the progress window once validation is complete
    Remove-Indent -Footer "exit -> tbNewTreeDomainName.add_PreviewLostKeyboardFocus event"
})

# Event handler for 'New Tree Domain Netbios Name' text box 
# -----------------------------------------------------
$tbNewTreeDomainNetBiosName.add_PreviewLostKeyboardFocus({
    Add-Indent -Header "enter -> tbNewTreeDomainNetBiosName.add_PreviewLostKeyboardFocus event" # increase indent in log file
    if($tbNewTreeDomainNetBiosName.Text -eq $tbNewTreeDomainNetBiosName.Tag) {
        Write-DSLog -Level info -Message "NetBIOS name already validated and not changed, skip further validation"
        Remove-Indent -Footer "exit -> tbNewTreeDomainNetBiosName.add_PreviewLostKeyboardFocus event"
        return
    }
    Write-DSLog -Level info -Message "Validating given new tree domain NetBIOS name $($tbNewTreeDomainNetBiosName.Text)"
    Show-ProgressWindow -Activity "Please wait while new tree domain NetBIOS name is validated" -Status ("Validating {0}" -f $tbNewTreeDomainNetBiosName.Text.Trim())
    $nbValid = (Test-NetBIOSName -Name $tbNewTreeDomainNetBiosName.Text.Trim())
    Close-ProgressWindow # close the progress window once validation is complete
    if($nbValid -eq $false) { 
        Write-DSLog -Level error -Message "New tree domain NetBIOS name validation failed. Please enter a valid NetBIOS name"
        Show-DSDialog -Message "New tree domain NetBIOS name validation failed. Please enter a valid NetBIOS name" | Out-Null
        $tbNewTreeDomainNetBiosName.Focus()
        $_.Handled = $true
    }
    else {
        Write-DSLog -Level info -Message "New tree domain NetBIOS name validated successfully"
        Close-ProgressWindow # close the progress window once validation is complete
        $tbNewTreeDomainNetBiosName.Tag = $tbNewTreeDomainNetBiosName.Text # update tag
    }
    Remove-Indent -Footer "exit -> tbNewTreeDomainNetBiosName.add_PreviewLostKeyboardFocus event"
})


# event handler for 'create reserve file' check box
# --------------------------------------------------
$cbCreateReserveFile.add_Click({
    Set-DSControl -Control $wpReserveFile -Property 'IsEnabled' -Value $true -When ($cbCreateReserveFile.IsChecked)
    Set-DSControl -Control $wpReserveFile -Property 'IsEnabled' -Value $false -When (-not $cbCreateReserveFile.IsChecked)
})

# event handler for 'disable netbios over tcpip' check box
# -------------------------------------------------------
$cbDisableNetBIOSOverTCPIP.add_Click({
    If($cbDisableNetBIOSOverTCPIP.IsChecked -eq $False) {
        $warNetbios = "This configuration is cybersecurity recommended and deselecting this checkbox will result in a diminished security posture, be subject to the Best Effort Support and will not fully comply with the baseline domain controller security standards."
        [System.Windows.Forms.MessageBox]::Show($warNetbios,"DSSOE GUI Installer","OK","Warning") | Out-Null
    }
})

# event handler for 'configure domain security policy' checkbox
# -------------------------------------------------------------
$cbDCSecPol.add_Click({
    if($cbDCSecPol.IsChecked -eq $False) {
        $warDCPol = "This configuration is cybersecurity recommended and deselecting this checkbox will result in a diminished security posture, be subject to the Best Effort Support and will not fully comply with the baseline domain controller security standards."
        [System.Windows.Forms.MessageBox]::Show($warDCPol,"DSSOE GUI Installer","OK","Warning") | Out-Null
    }
})

# event handler for 'configure domain controller security policy' checkbox
# -------------------------------------------------------------
$cbDomainSecPol.add_Click({
    if($cbDomainSecPol.IsChecked -eq $False) {
        $warDomainPol = "This configuration is cybersecurity recommended and deselecting this checkbox will result in a diminished security posture, be subject to the Best Effort Support and will not fully comply with the baseline domain controller security standards."
        [System.Windows.Forms.MessageBox]::Show($warDomainPol,"DSSOE GUI Installer","OK","Warning") | Out-Null
    }
})

# event handler for 'install ad hotfix' checkbox
# -------------------------------------------------------------
$cbInstallADHotfixes.add_Click({
    if($cbInstallADHotfixes.IsChecked -eq $False) {
        $warADhotfix = "This configuration is cybersecurity recommended and deselecting this checkbox will result in a diminished security posture, be subject to the Best Effort Support and will not fully comply with the baseline domain controller security standards."
        [System.Windows.Forms.MessageBox]::Show($warADhotfix,"DSSOE GUI Installer","OK","Warning") | Out-Null
    }
})


# event handler for 'Configure RPC port range restriction' check box
# --------------------------------------------------------------------
$cbRPCPortRestriction.add_Click({
    Set-DSControl -Control $tbRPCPortRange -Property 'IsEnabled' -Value $true -When ($cbRPCPortRestriction.IsChecked)
    Set-DSControl -Control $tbRPCPortRange -Property 'IsEnabled' -Value $false -When (-not $cbRPCPortRestriction.IsChecked)
})

# event handler for 'create bulk users' check box
# ------------------------------------------------
$cbCreateBulkUsers.add_Click({
    Set-DSControl -Control ($tbBulkUserFile,$lblBulkUserFile) -Property 'IsEnabled' -Value $true -When ($cbCreateBulkUsers.IsChecked)
    Set-DSControl -Control ($tbBulkUserFile,$lblBulkUserFile) -Property 'IsEnabled' -Value $false -When (-not $cbCreateBulkUsers.IsChecked)
})

# event handler for 'Configure external time sync server' check box
# ------------------------------------------------------------------
$cbExtTimeSyncServer.add_Click({
    Set-DSControl -Control $tbExtTimeSyncServer -Property 'IsEnabled' -Value $true -When ($cbExtTimeSyncServer.IsChecked)
    Set-DSControl -Control $tbExtTimeSyncServer -Property 'IsEnabled' -Value $false -When (-not $cbExtTimeSyncServer.IsChecked)
})

# event handler for 'Place domain controller in specific OU' check box
# ---------------------------------------------------------------------
$cbDCPlacementOU.add_Click({
    Set-DSControl -Control $tbDCPlacementOU -Property 'IsEnabled' -Value $true -When ($cbDCPlacementOU.IsChecked)
    Set-DSControl -Control $tbDCPlacementOU -Property 'IsEnabled' -Value $false -When (-not $cbDCPlacementOU.IsChecked)
})

<#
# event handler for 'Create BPA report' check box
# ------------------------------------------------
$cbBPAReport.add_Click({
    Set-DSControl -Control ($lblBPAReportPath,$tbBPAReportPath) -Property 'IsEnabled' -Value $true -When ($cbBPAReport.IsChecked)
    Set-DSControl -Control ($lblBPAReportPath,$tbBPAReportPath) -Property 'IsEnabled' -Value $false -When (-not $cbBPAReport.IsChecked)
})
#>

# event handler for 'Configure DNS forwarders' check box
# -------------------------------------------------------
$cbConfigDNSForwarders.add_Click({
    Set-DSControl -Control $tbDNSForwarders -Property 'IsEnabled' -Value $true -When ($cbConfigDNSForwarders.IsChecked)
    Set-DSControl -Control $tbDNSForwarders -Property 'IsEnabled' -Value $false -When (-not $cbConfigDNSForwarders.IsChecked)
})

# this event will enable/disable controls related to 'site to subnet association'
# -------------------------------------------------------------------------------
$cbSubnetSiteAssoc.add_Click({
    if($cbSubnetSiteAssoc.IsChecked) { 
        Set-DSSiteSubnetAssocControlsStatus -Status enabled
    }
    else {
        Set-DSSiteSubnetAssocControlsStatus -Status disabled
    }
})

# event handler for 'install from media' checkbox
# ------------------------------------------------
$cbIFM.add_Click({
    if($cbIFM.IsChecked) {
        # enable controls related to IFM
        'lblIFMPath','tbIFMPath','btnIFMBrowse' | foreach { $dsui.FindName($_).IsEnabled = $true }
        # disable controls related to DC replication when IFM is selected
        'cbReplicateFromExistingDC','cboReplicateFromExistingDC' | foreach { $dsui.FindName($_).IsEnabled = $false }
        $dsui.FindName('cbReplicateFromExistingDC').IsChecked = $False
    }
    else { 
        # disable controls related to IFM
        'lblIFMPath','tbIFMPath','btnIFMBrowse' | foreach { $dsui.FindName($_).IsEnabled = $false }
        # enable controls related to DC replication when IFM is un-selected.. so that they can be selected
        'cbReplicateFromExistingDC' | foreach { $dsui.FindName($_).IsEnabled = $true }
        
    }
})

# event handler for 'replicate data from existing DC' check box
# -------------------------------------------------------------
$cbReplicateFromExistingDC.add_Click({
    if($cbReplicateFromExistingDC.IsChecked) { 
        $cboReplicateFromExistingDC.IsEnabled = $true 
        # disable controls related to IFM when DC replication check box is checked
        'cbIFM','lblIFMPath','tbIFMPath','btnIFMBrowse' | foreach { $dsui.FindName($_).IsEnabled = $false }
        $dsui.FindName('cbIFM').IsChecked = $False
    }
    else { 
        $cboReplicateFromExistingDC.IsEnabled = $false 
        # enable controls related to IFM when DC Replication is unchecked
        'cbIFM' | foreach { $dsui.FindName($_).IsEnabled = $true }
    }
})

# event handler for 'browse' button to select 'install from media' folder
# -----------------------------------------------------------------------
$btnIFMBrowse.add_Click({
    $mpath = Select-DSFolder -message 'Select the location of installation media to be used to create the domain controller and configure AD DS' -path Desktop
    if($mpath -eq $null) { # user cancelled the dialog, do nothing
        $tbIFMPath.Text = "" # clear existing selected path
    }
    else {
        $tbIFMPath.Text = $mpath
    }
})

# event handler for RODC check box
# --------------------------------
$cbRODC.add_Click({
    if($cbRODC.IsChecked) { 
        $cbCreateBulkUsers.IsChecked = $false
        $cbCreateBulkUsers.IsEnabled = $false
        $cbCreateBulkUsers.RaiseEvent($evt) | Out-Null
        $cbDCPlacementOU.IsChecked = $false
        $cbDCPlacementOU.IsEnabled = $false
        $cbDCPlacementOU.RaiseEvent($evt) | Out-Null
        $cbConfigureIPAM.IsChecked = $false
        $cbConfigureIPAM.IsEnabled = $false
        $cbConfigureIPAM.RaiseEvent($evt) | Out-Null
        $cbEnableADRecycleBin.IsChecked = $false
        $cbEnableADRecycleBin.IsEnabled = $false
        $cbEnableADRecycleBin.RaiseEvent($evt) | Out-Null
    } 
    else { 
        $cbCreateBulkUsers.IsEnabled = $true 
        $cbDCPlacementOU.IsEnabled = $true
        $cbConfigureIPAM.IsEnabled = $true
        $cbEnableADRecycleBin.RaiseEvent($evt) | Out-Null
    }
})


# event handler for 'change' credential button..validates supplied credentials as well
# ------------------------------------------------------------------------------------
$btnValidateCreds.add_Click({
    Add-Indent -Header "enter -> btnValidateCreds.add_Click event" 
    
    # clear previously connected information
    $promoOpCreds.domain = $promoOpCreds.user = $promoOpCreds.isrootdomain = $promoOpCreds.rights = ""

    # perform input validation before actual credential/domain validation
    $isInputValid = $false # assume that input validation is failed
    if(("" -in ($tbUserName.Text, $tbPassword.Password)) -eq $true) { # user/pass fields are blank
        Write-DSLog -Level info -Message "Please specify Username and Password and try again"
        Show-DSDialog -Message "Please specify Username and Password and try again" | Out-Null
        Remove-Indent -Footer "exit -> btnValidateCreds.add_Click event" 
        return
    }
    else { # user has specified some username nad passwrd, lets verify it
        if(Test-DSEmailAddress -Address $tbUserName.Text) { 
            # username specified in user@domain format, perform domain creds validation
            $uinfo = $tbUserName.Text -as [mailaddress]
            Write-DSLog -Level info -Message "Username $($uinfo.User), domain $($uinfo.Host), pass *****" 
            $res = Test-IsValidCredentials -UserName $uinfo.User -Password $tbPassword.Password -Domain $uinfo.Host
            if($res.Value -eq $true) { # credentail validated
                Write-DSLog -Level info -Message "credential validated successfully"
                
                # set creds info in script level creds object
                $promoOpCreds.domain = $uinfo.Host
                $promoOpCreds.user = $uinfo.User
                
                # attempt to get forest info with given creds
                $forest = Get-DSADForest -Domain $uinfo.Host -UserName $uinfo.User -Password $tbPassword.Password 
                if($forest -eq $null) { 
                    Write-DSLog -Level info -Message "Unable to retrieve domain/forest information.`r`n$($forest.Message)"
                    Show-DSDialog -Level info -Message "Unable to retrieve domain/forest information.`n$($forest.Message)" | out-null
                    return
                }
                # removed - population of site list combo

                # get group membership of the user
                Write-DSLog -Level info -Message "checking group membership of user $($uinfo.User)" 
                $gminfo = Test-DSGroupMembership -Domain $uinfo.Host -UserName $uinfo.User -Password $tbPassword.Password 

                # if given domain is forest root domain too, setup 'additional dc' controls too
                if((Get-DSADForestRootDomain).Name -eq ($uinfo.Host)) { 
                    Write-DSLog -Level info -Message "Given domain is forest root domain"
                    $promoOpCreds.isrootdomain = $true 
                }
                else { 
                    Write-DSLog -Level info -Message "Given domain is NOT forest root domain"
                    $promoOpCreds.isrootdomain = $false 
                } # not a forest root domain

                # if user is enterprise admins then let user perform new child domain or new domain tree ops
                if($gminfo.IsEnterpriseAdmins) {
                    Write-DSLog -Level info -Message "User $($uinfo.User) is Enterprise Admin"
                    $promoOpCreds.rights = "EnterpriseAdmins"
                    # raise event for new child domain radio bydefault
                    $rbNewChildDomain.IsChecked = $true 
                    $rbNewChildDomain.RaiseEvent($evt) 
                }
                # if user is domain admins then let user add new DCs to existing domain
                elseif($gminfo.IsDomainAdmins) {
                    Write-DSLog -Level info -Message "User $($uinfo.User) is Domain Admin"
                    $promoOpCreds.rights = "DomainAdmins"
                    # raise event for new additional dc radio
                    $rbAdditionalDC.IsChecked = $true 
                    $rbAdditionalDC.RaiseEvent($evt) 
                }
                else {
                    Write-DSLog -Level error -Message "user $($uinfo.User) has no admin rights on given domain" 
                    $promoOpCreds.rights = "None"
                    Show-DSDialog -Level info -Message "User $($tbUserName.Text) does not have required administrative privileges to perform domain operations" | Out-Null
                    Set-DSBuildTypeControlsVisibility 
                    $tbUserName.Focus()
                    return # let user re-enter creds
                }
            }
            else { # wrong credentials
                Write-DSLog -Level error -Message "Invalid credential specified, please specify valid credentials and try again"
                Show-DSDialog -Message $res.Message | Out-Null
                Set-DSBuildTypeControlsVisibility 
                $tbUserName.Focus()
                return # let user re-enter creds
            }
        }
        else { # user specified username in flat name format, likely a local user account
            # perform local account validation
            Write-DSLog -Level info -Message "local account credential given, validating it" 
            $res = Test-IsValidCredentials -UserName $tbUserName.Text -Password $tbPassword.Password -Domain $env:COMPUTERNAME
            if($res.Value -eq $true) { # credentail validated and user is local account with local admin rights
                Write-DSLog -Level info -Message "User $($tbUserName.Text) has local administrative rights"
                $promoOpCreds.user = $tbUserName.Text
                $promoOpCreds.isrootdomain = $false
                $promoOpCreds.rights = "LocalAdmin"

                # raise event for new forest radio button
                $rbNewForest.IsChecked = $true 
                $rbNewForest.RaiseEvent($evt)
            }
            else { # wrong credentials or user is not local admin or does not exist
                Write-DSLog -Level error -Message "Invalid credential specified, please specifiy valid credentials and try again"
                Show-DSDialog -Message $res.Message | Out-Null
                Set-DSBuildTypeControlsVisibility 
                $tbUserName.Focus()
                return # let user re-enter creds
            }
        }        
    }

    # now call the function to show/hide dcpromo options based on creds object set earlier in this function
    Write-DSLog -Level info -Message "calling function to display DC Build type options based on given credential" 
    Set-DSBuildTypeControlsVisibility 

    # set whether schema upgrade checkbox will be visible or not
    Write-DSLog -Level info -Message "calling function to enable/disable schema upgrade checkbox"
    Set-DSSchemaUpgradeControl

    Remove-Indent -Footer "exit -> btnValidateCreds.add_Click event" 
})


# Event handler for combox box 'Forect Functional Level' selection change
# -----------------------------------------------------------------------
$cboForestFuncLevel.add_SelectionChanged({    
    Add-Indent -Header "enter -> cboForestFuncLevel.add_SelectionChanged event"
    # If selected item is not a valid item then do not add it
    if(($cboForestFuncLevel.SelectedIndex) -ne -1) {
        # store forest functional level in a variable
        $ffLevel = $cboForestFuncLevel.SelectedItem.Content

        # call function to get supported domain functional levels
        #$dfLevels = Get-DSDomainFunctionalLevels -ForestFunctionalLevel $ffLevel
        $dmodes = (Get-DSSupportedDomainModes -ForestModeDisplayName $ffLevel)

        # add domain functional levels to dthe combo
        Add-DSComboItems -Combo $cboDomainFuncLevel -ItemsToAdd @($dmodes.ModeDisplayName) -ClearExistingItems

        # if forest functional level is not selected as Windows 2008 R2 Forest and beyond, the AD recycle bin
        # checkbox will remain disabled for selection
        Write-DSLog -Level info -Message "validating if selected forest mode is appropriate, Windows Server 2008 R2 and beyond, for AD recycle bin - $ffLevel"
        # validating if selected FFL is Windows Server 2008 R2 or beyond
        If(!($ffLevel -in ('Windows Server 2008 R2','Windows Server 2012','Windows Server 2012 R2','Windows Server 2016'))) {
            $cbEnableADRecycleBin.IsEnabled = $False #disable AD recycle bin check box
            Write-DSLog -Level info -Message "Since FFL is $ffLevel, thus disabled the AD RecycleBin checkbox"
        }
        Else {
            $cbEnableADRecycleBin.IsEnabled = $true #enable AD Recycle bin checkbox
        }
    }
    Remove-Indent -Footer "exit -> cboForestFuncLevel.add_SelectionChanged event"
})

# event handler for 'configure all AD path on windows install dir' checkbox
# --------------------------------------------------------------------------
$cbADPathToOSDrive.add_Click({
    if($cbADPathToOSDrive.IsChecked) { # set all path to C drive, the DSSOE defaults and make it read only
        $tbADDSPath.Text = "C:\NTDS-DB"
        $tbADDSLog.Text = "C:\NTDS-LOGS"
        $tbADDSSysvol.Text = "C:\SYSVOL" 
        $tbADDSPath.IsEnabled = $tbADDSLog.IsEnabled = $tbADDSSysvol.IsEnabled = $False
    }
    else {
        $tbADDSPath.Text = ("E:{0}" -f $tbADDSPath.Text.Substring(2))
        $tbADDSLog.Text = ("D:{0}" -f $tbADDSLog.Text.Substring(2))
        $tbADDSSysvol.Text = ("E:{0}" -f $tbADDSSysvol.Text.Substring(2))
        $tbADDSPath.IsEnabled = $tbADDSLog.IsEnabled = $tbADDSSysvol.IsEnabled = $true
    }

})


# event handler for Account Type combo box selectionChanged event
# ---------------------------------------------------------------
$cboAccountType.add_SelectionChanged({
    if($cboAccountType.SelectedItem.Content -eq 'default') {
        $tbAccountCode.IsEnabled = $False
        $cbConfigureADDelegation.IsEnabled = $False
        $cbConfigureADDelegation.IsChecked = $False
    }
    elseif($cboAccountType.SelectedItem.Content -eq 'standard') {
        $tbAccountCode.IsEnabled = $true
        $cbConfigureADDelegation.IsEnabled = $False
        $cbConfigureADDelegation.IsChecked = $False
    }
    elseif($cboAccountType.SelectedItem.Content -eq 'multitenant') {
        $tbAccountCode.IsEnabled = $true
        $cbConfigureADDelegation.IsEnabled = $True
    }
})

#region event handler for varous static port configurations
# event handler for NTDS port
# ----------------------------
$cbNTDS.add_Click({
    if($cbNTDS.IsChecked) { $tbNTDS.IsEnabled = $true }
    else { $tbNTDS.IsEnabled = $False }
})

# event handler for NTDS port
# ----------------------------
$cbNetlogon.add_Click({
    if($cbNetlogon.IsChecked) { $tbNetlogon.IsEnabled = $true }
    else { $tbNetlogon.IsEnabled = $False }
})

# event handler for DFSR port
# ----------------------------
$cbDFSR.add_Click({
    if($cbDFSR.IsChecked) { 
        $OSInstallMode = (Get-OSInstallMode -ShortName)
        If($OSInstallMode -eq "Full") {
            $tbDFSR.IsEnabled = $true
        }
        Else {
            $warDFSRport = "Due to an anomaly in Windows Server 2016 Server Core version, the DFSR static port cannot be configured programmatically. Please configure the DFSR static port manually on the server. Refer to DSSOE 3.0.0 operations guide for more information."
            [System.Windows.Forms.MessageBox]::Show($warDFSRport,"DSSOE GUI Installer","OK","Warning") | Out-Null
            $cbDFSR.IsChecked = $False
            $tbDFSR.IsEnabled = $False
        }
    }
    else { $tbDFSR.IsEnabled = $False }
})

<#
# event handler for NTDS port
# ----------------------------
$cbFRS.add_Click({
    if($cbFRS.IsChecked) { $tbFRS.IsEnabled = $true }
    else { $tbFRS.IsEnabled = $False }
})
#>
#endregion

# event handler for 'enable scheduled backup' checkbox
# -----------------------------------------------------
$cbEnableScheduledBackup.add_Click({
    # enable or disable backup volume path combo based on this checkbox selection
    $cboBackupVolumePath.IsEnabled = $cbEnableScheduledBackup.IsChecked
})

# event handler for 'Configure IPAM AD prerequisites' check box
# -------------------------------------------------------------
$cbConfigureIPAM.add_Click({
    
    # modify control visibility and status if IPAM checkbox is checked
    If($cbConfigureIPAM.IsChecked) {
        
        # make ipam wrap panel visible
        $dsui.FindName('wpConfigureIPAMOptions').Visibility = "Visible"

        # enable the ipam controls
        'lblIPAMUniversalGroup','tbIPAMUniversalGroup','lblIPAMServerName','tbIPAMServerName' | foreach { $dsui.FindName($_).IsEnabled = $True }
    }

    If(!($cbConfigureIPAM.IsChecked)) {
        #clear the text boxes
        $tbIPAMUniversalGroup.Text = ""
        $tbIPAMServerName.Text = ""
        # disable the ipam controls
        'lblIPAMUniversalGroup','tbIPAMUniversalGroup','lblIPAMServerName','tbIPAMServerName' | foreach { $dsui.FindName($_).IsEnabled = $False }        
    }
           
    #Set-DSControl -Control $wpConfigureIPAMOptions -Property 'Visibility' -Value "Visible" -When ($cbConfigureIPAM.IsChecked)
    #Set-DSControl -Control $wpConfigureIPAMOptions -Property 'Visibility' -Value "Collapsed" -When (-not $cbConfigureIPAM.IsChecked)
})

# event handler for 'AD recycle bin and AD health check credential verify' button
# -------------------------------------------------------------------------------
$btnValidateCredsADRBHC.add_Click({
    Add-Indent -Header "enter -> btnValidateCredsADRBHC.add_Click event"

    # perform input validation before actual credential/domain validation
    $isInputValid = $false # assume that input validation is failed
    if(("" -in ($tbADRBHCUser.Text, $tbADRBHCPassword.Password)) -eq $true) { # user/pass fields are blank
        Write-DSLog -Level info -Message "Please specify the Username and Password specified and try again"
        Show-DSDialog -Message "Please specify Username and Password and try again" | Out-Null
        Remove-Indent -Footer "exit -> btnValidateCredsADRBHC.add_Click event" 
        return
    }
    else {
        # user has specified some username nad passwrd, lets verify it
        if(Test-DSEmailAddress -Address $tbADRBHCUser.Text) { 
            # username specified in user@domain format, perform domain creds validation
            $uinfo = $tbADRBHCUser.Text -as [mailaddress]
            Write-DSLog -Level info -Message "Username $($uinfo.User), domain $($uinfo.Host), pass *****" 
            $res = Test-IsValidCredentials -UserName $uinfo.User -Password $tbADRBHCPassword.Password -Domain $uinfo.Host
            if($res.Value -eq $true) { # credential validated
                Write-DSLog -Level info -Message "credential validated successfully"

                #retrieving forest info
                $forest = Get-DSADForest -Domain $uinfo.Host -UserName $uinfo.User -Password $tbADRBHCPassword.Password 
                if($forest -eq $null) { 
                    Write-DSLog -Level info -Message "Unable to retrieve domain/forest information.`r`n$($forest.Message)"
                    Show-DSDialog -Level info -Message "Unable to retrieve domain/forest information.`n$($forest.Message)" | out-null
                    return
                }
                                
                # get group membership of the user
                Write-DSLog -Level info -Message "checking group membership of user $($uinfo.User)" 
                $gminfo = Test-DSGroupMembership -Domain $uinfo.Host -UserName $uinfo.User -Password $tbADRBHCPassword.Password 

                # if user is enterprise admins then let user select AD recycle bin and ad health check options
                if($gminfo.IsEnterpriseAdmins) {
                    Write-DSLog -Level info -Message "User $($uinfo.User) is Enterprise Admin"                    
                    # if forest functional level of the forest is not Windows 2008 R2 Forest and beyond, the AD recycle bin
                    # checkbox will remain disabled for selection
                    $CurrentFFL = (Get-DSADForestMode).ModeDisplayName
                    Write-DSLog -Level info -Message "Current forest functional level of the forest is - $CurrentFFL"
                    # validating if current FFL is Windows Server 2008 R2 or beyond
                    If((!($CurrentFFL -in ('Windows Server 2008 R2','Windows Server 2012','Windows Server 2012 R2','Windows Server 2016'))) -or ($cbRODC.IsChecked -eq $true)) {
                        $cbEnableADRecycleBin.IsEnabled = $False #disable AD recycle bin check box
                        $cbRunADHealthCheck.IsEnabled = $true #keep the AD health check enabled
                        If($cbRODC.IsChecked -eq $true) {
                            Write-DSLog -Level info -Message "Since RODC checkbox is selected, thus AD Recycle bin option is disabled."
                        }
                        Else {
                            Write-DSLog -Level info -Message "Since FFL of the forest is $CurrentFFL, thus disabled the AD RecycleBin checkbox. AD health check checkbox stays enabled."
                        }
                    }
                    Else {                    
                        'cbEnableADRecycleBin','cbRunADHealthCheck' | foreach { $dsui.FindName($_).IsEnabled = $true }
                        Write-DSLog -Level info -Message "Enabled AD recycle bin and AD health check checkboxes"
                    }
                }                
                else {
                    Write-DSLog -Level error -Message "user $($uinfo.User) does not have enterprise admins rights in the forest" 
                    #$promoOpCreds.rights = "None"
                    Show-DSDialog -Level info -Message "User $($tbUserName.Text) does not have Enterprise Admin privileges" | Out-Null
                    $tbADRBHCUser.Focus()
                    return # let user re-enter creds
                }
            }
            else { # wrong credentials
                Write-DSLog -Level error -Message "Invalid credential specified, please specify valid credentials and try again"
                Show-DSDialog -Message $res.Message | Out-Null
                $tbADRBHCUser.Focus()
                return # let user re-enter creds
            }
        }
        else { # wrong credentials
                Write-DSLog -Level error -Message "Invalid credential specified, please specifiy valid credentials and try again"
                Show-DSDialog -Message $res.Message | Out-Null
                $tbADRBHCUser.Focus()
                return # let user re-enter creds
        }      
    }

    Remove-Indent -Footer "exit -> btnValidateCredsADRBHC.add_Click event" 
})

# event handler for 'enabled ad recycle bin' checkbox
# ---------------------------------------------------
$cbEnableADRecycleBin.add_Click({
    Add-Indent -Header "enter -> cbEnableADRecycleBin.add_Click" # increase indent in log file
    
    # the ad recycle bin controls will only be displayed when build type is not newforest
    If($rbNewForest.IsChecked -eq $False) {
    #enabling the controls
        if($cbEnableADRecycleBin.IsChecked -eq $true) {
            #make the wrap panel visible
            $dsui.FindName('wpConfigureADRBOptions').Visibility = "Visible"
        
            'lblADRecycleBinScope','cboADRecycleBinScope','lblADRecycleBinTargetServer','tbADRecycleBinTargetServer',`
            'lblADRecycleBinTargetDomain','cboADRecycleBinDomain' | foreach { $dsui.FindName($_).IsEnabled = $True  }
            #retrieving the forest info
            $uinfo = $tbADRBHCUser.Text -as [mailaddress]
            $forest = Get-DSADForest -Domain $uinfo.Host -UserName $uinfo.User -Password $tbADRBHCPassword.Password
            #retrieving Domain Naming Master holder DC
            $DomainNamingMasterDC = (Get-DSADForestNamingRoleOwner).Name 
            Write-DSLog -Level info -Message "Domain naming master holder of the forest is - $DomainNamingMasterDC"
            $tbADRecycleBinTargetServer.Text = $DomainNamingMasterDC
            Write-DSLog -Level info -Message "Added the domain naming master role holder DC to 'tbADRecycleBinTargetServer' textbox"

            #adding values to cboADRecycleBinDomain combo box
            #retrieving the list of domains in the forest
            Write-DSLog -Level info -Message "setting all the domains of the forest in 'AD recycle bin target domain' combo box"
            $domainlist = Get-DSADForestDomains
            Add-DSComboItems -Combo $cboADRecycleBinDomain -ItemsToAdd @($domainlist) -ClearExistingItems
        }
    
        # disabling the controls if checkbox is unchecked
        if($cbEnableADRecycleBin.IsChecked -eq $false) {
            'lblADRecycleBinScope','cboADRecycleBinScope','lblADRecycleBinTargetServer','tbADRecycleBinTargetServer',`
            'lblADRecycleBinTargetDomain','cboADRecycleBinDomain' | foreach { $dsui.FindName($_).IsEnabled = $False }
        }
    }
    Remove-Indent -Footer "exit -> cbEnableADRecycleBin.add_Click event" 
})

# event handler for 'AD health check' checkbox
# ----------------------------------------------------
$cbRunADHealthCheck.add_Click({
    Add-Indent -Header "enter -> cbRunADHealthCheck.add_Click" # increase indent in log file
    
    # the ad health check controls will only be displayed when build type is not newforest
    If($rbNewForest.IsChecked -eq $False) {

        # enabling the controls if checkbox is checked
        If($cbRunADHealthCheck.IsChecked) {
        
            $dsui.FindName('wpConfigureADHCOptions').Visibility = "Visible"

            'lblDomainNamesADHC','lboSelectDomainsADHC','cbSelectAll' | foreach { $dsui.FindName($_).IsEnabled = $true }
        
            #retrieving the forest info
            $uinfo = $tbADRBHCUser.Text -as [mailaddress]
            $forest = Get-DSADForest -Domain $uinfo.Host -UserName $uinfo.User -Password $tbADRBHCPassword.Password
            #retrieving Domain Naming Master holder DC
        
            #retrieving the list of domains in the forest
            Write-DSLog -Level info -Message "setting all the domains of the forest in 'Select Domains' list box"
            $domainlist = Get-DSADForestDomains
            Add-DSListItems -List $lboSelectDomainsADHC -ItemsToAdd @($domainlist) -ClearExistingItems

            #make the wrap panel visible as per the selection of checkbox    
            #Set-DSControl -Control $wpConfigureADHCOptions -Property 'Visibility' -Value "Visible" -When ($cbRunADHealthCheck.IsChecked)
        }

        #disabling the controls if checkbox is unchecked
        if(!($cbRunADHealthCheck.IsChecked)) {
            'lblDomainNamesADHC','lboSelectDomainsADHC','cbSelectAll' | foreach { $dsui.FindName($_).IsEnabled = $False }
        }
    }

    Remove-Indent -Footer "exit -> cbRunADHealthCheck.add_Click event" 
})

# Event handler for cbselectall checkbox 
# ----------------------------------------
$cbSelectAll.Add_Click({
    if($cbSelectAll.IsChecked) {
        foreach ($item in $lboSelectDomainsADHC.Items) {
            $lboSelectDomainsADHC.SelectedItems.Add($item)
        }
    }
    if(!($cbSelectAll.IsChecked)) {
        $domainlist = Get-DSADForestDomains
        Add-DSListItems -List $lboSelectDomainsADHC -ItemsToAdd @($domainlist) -ClearExistingItems
    }
})


# Event handler for combo box Network Adapter list
# ------------------------------------------------
$cboNetAdapter.Add_SelectionChanged({
    # If selected item is not a valid item then do not process it
    if(($cboNetAdapter.SelectedIndex) -ne -1) {
        Show-DSNetAdapterDetails -InterfaceIndex $cboNetAdapter.SelectedItem.Tag
    }
})

# event handler for 'apply static ip' button - just apply give IP details, dont save in dssoe xml
# ------------------------------------------------------------------------------------------------
$btnApplyStaticIP.add_Click({
    Add-Indent -Header "enter -> btnApplyStaticIP.add_Click event" # increase indent in log file

    # See if user has selected a valid interface
    if($cboNetAdapter.SelectedItem.Content -eq $null) {
        $emsg = "Please select a network interface from the list to apply static IP address, and then try again"
        Write-DSLog -Level error -Message "$emsg"
        [System.Windows.Forms.MessageBox]::Show("$emsg","DSSOE GUI Installer","OK","Error") | Out-Null
        Remove-Indent -Footer "exit -> btnApplyStaticIP.add_Click event" # decrease indent in log file
        return
    }

    # validate user input first
    $errMsg = ""
    Write-DSLog -Level info -Message "Validating user provided IP details"
    if((Test-DSIPAddress -IPAddress $tbIPAddress.Text) -eq $False) {
        $errMsg = "$errMsg Invalid IP Address specified`n"
    }
    if((Test-DSIPSubnet -IPMask $tbSubnet.Text) -eq $False) {
        $errMsg = "$errMsg Invalid IP Subnet mask specified`n"
    }
    if($tbGateway.Text -ne "" -and (Test-DSIPAddress -IPAddress $tbGateway.Text) -eq $False) {
        $errMsg = "$errMsg Invalid IP Gateway specified`n"
    }
    if((Test-MultipleIPAddress -IPAddress $tbDNS.Text) -eq $False) {
        $errMsg = "$errMsg Invalid DNS server(s) IP address(es) specified. If providing multiple DNS servers, they should be comma separated`n"
    }
    #if($tbWins.Text -ne "" -and ($tbWins.Text.split(',').count -gt 2)) {
    #    $errMsg = "$errMsg Maximum two WINS servers IP addresses can be specified`n"
    #}
    #if($tbWins.Text -ne "" -and (Test-MultipleIPAddress -IPAddress $tbWins.Text) -eq $False) {
    #    $errMsg = "$errMsg Invalid WINS server(s) IP address(es) specified"
    #}

    # check if error indeed occurand show message 
    if($errMsg -ne "") {
        Write-DSLog -Level error -Message "$errMsg`nPlease correct the errors and try again"
        [System.Windows.Forms.MessageBox]::Show("$errMsg`nPlease correst the errors and try again","DSSOE GUI Installer","OK","Error") | Out-Null
    }
    else { # no error, go ahead with applying IP address!
        $ipaMsg = "" # messages related to IP address updations
        Write-DSLog -Level info -Message "User provided IP details validated successfuly, prompting user to proceed with IP configuration"
        $res = [System.Windows.Forms.MessageBox]::Show("Do you want to apply given IP details to selected interface?","DSSOE GUI Installer","YesNo","Question")
        if($res -eq 'Yes') { # apply IP address and related configs
            Write-DSLog -Level info -Message "User selected to continue with IP address configuration"
            # identify net adapter to perform configuration
            $selNetAdapter = Get-DSNetworkAdapters | Where-Object { $_.InterfaceIndex -eq $cboNetAdapter.SelectedItem.Tag }
            if($selNetAdapter -eq $null) {
                $emsg = "Unable to bind to selected network interface Index ($($cboNetAdapter.SelectedItem.Tag)). Static IP address cannot be applied"
                Write-DSLog -Level error -Message "$emsg"
                [System.Windows.Forms.MessageBox]::Show($emsg,"DSSOE GUI Installer","OK","Error") | Out-Null
                Remove-Indent -Footer "exit -> btnApplyStaticIP.add_Click event" # decrease indent in log file
                return
            }
            # at this point, selected adapter name is retrieved
            Write-DSLog -Level info -Message "Configuring Static IP using user provides values"
            Write-DSLog -Level info -Message "Selected network interface is $($selNetAdapter.NetConnectionID)"

            #region set IP address and subnet mask
            Write-DSLog -Level info -Message "Configuring IP address $($tbIPAddress.Text) and subnet mask $($tbSubnet.Text)"
            $res = Set-DSIPAddressAndSubnet -NetAdapterName $selNetAdapter.NetConnectionID -IpAddress $tbIPAddress.Text -SubnetMask $tbSubnet.Text
            if($res -eq $false) { # some errors/message from netsh
                $emsg = "Failed to set IP address properly. IP address configuration failed"
                Write-DSLog -Level error -Message "$emsg"
                [System.Windows.Forms.MessageBox]::Show("$emsg","DSSOE GUI Installer","OK","Error") | Out-Null
                Remove-Indent -Footer "exit -> btnApplyStaticIP.add_Click event" # decrease indent in log file
                return
            }
            else { 
                $ipaMsg = "$ipaMsg # IP address and subnet mask configured successfully.`r`n"
                Write-DSLog -Level info -Message "IP address and subnet mask configured successfully" }
            #endregion

            # configure DNS server
            Write-DSLog -Level info -Message "Configuring DNS address(es): $($tbDNS.Text)"
            $Configdns = Set-DSDNSAddress -DNSServer $tbDNS.Text -NetAdapterName $selNetAdapter.NetConnectionID
            If(-not($Configdns -eq 0) -or ($Configdns -eq 1)) {
                Write-DSLog -Level error -Message "DNS address configuration failed with return code: $Configdns"
                [System.Windows.Forms.MessageBox]::Show("DNS address configuration failed with return code $Configdns","DSSOE GUI Installer","OK","Error") | Out-Null
                return
            }
            Else {
                $ipaMsg = "$ipaMsg # DNS address(es) configured successfully.`r`n"
                Write-DSLog -Level info -Message "DNS address(es) $($tbDNS.Text) are successfully configured"
            }

            # configure IP gateway
            If($tbGateway.Text -ne "") {
                Write-DSLog -Level info -Message "Configuring gateway IP address as $($tbGateway.Text)"
                $gwConf = Set-DSGatewayIP -IpGateway $tbGateway.Text -NetAdapterName $selNetAdapter.NetConnectionID
                If(-not($gwConf -eq [int]0) -or ($gwConf -eq [int]1)) {
                    $ipaMsg = "$ipaMsg # Gateway address configuration failed with return code: $gwConf.`r`n"
                    Write-DSLog -Level error -Message "Gateway address config failed with return code: $gwConf"
                }
                Else {
                    $ipaMsg = "$ipaMsg # Gateway address configured successfully.`n"
                    Write-DSLog -Level info -Message "Gateway address configured successfully"
                }
            }
            else {
                $ipaMsg = "$ipaMsg # Gateway configuration skipped (gateway IP not specified).`r`n"
                Write-DSLog -Level info -Message "Gateway configuration skipped (gateway IP not specified)"
            }

            <## configure WINS address
            If($winsAddress -ne "") {
                Write-DSLog -Level info -Message "Configuring WINS IP address(es) $($tbWins.Text)"
                $configWINS = Set-DSWINSAddress -WINSServer $tbWins.Text -NetAdapterName $selNetAdapter.NetConnectionID
                If(-not($configWINS -eq [int]0) -or ($configWINS -eq [int]1)) {
                    $ipaMsg = "$ipaMsg # WINS address config failed with return code: $configWINS.`r`n"
                    Write-DSLog -Level error -Message "WINS address(es) configuration failed with return code: $configWINS"
                }
                Else {
                    $ipaMsg = "$ipaMsg # WINS address(es) configured successfully.`r`n"
                    Write-DSLog -Level info -Message "WINS address(es) configured successfully"
                }
            }
            else {
                $ipaMsg = "$ipaMsg # WINS configuration skipped (WINS IPs not specified).`r`n"
                 Write-DSLog -Level info -Message "WINS configuration skipped (WINS IPs not specified)"
            }#>

            # configure network adapter DNS Suffix
            If($tbNetDNSSuffix.Text -ne "") {
                Write-DSLog -Level info -Message "[dssoe] Configuring Network Adapter DNS Suffix ($tbNetDNSSuffix.Text)"
                $ndsConf = Set-DSNetworkAdapterDNSSuffix -NetworkAdapterDNSSuffix $tbNetDNSSuffix.Text -NetAdapterName $selNetAdapter.NetConnectionID
                If(-not($ndsConf -eq [int]0) -or ($ndsConf -eq [int]1)) {
                    $ipaMsg = "$ipaMsg # Net Adapter DNS Suffix config failed with return code: $ndsConf.`r`n"
                    Write-DSLog -Level error -Message "[dssoe] Network adapter DNS suffix configuration failed with return code: $ndsConf"
                }
                Else {
                    $ipaMsg = "$ipaMsg # Net Adapter DNS Suffix configured successfully.`r`n"
                    Write-DSLog -Level info -Message "[dssoe] Network adapter DNS suffix is successfully configured"
                }
            }
            else {
                $ipaMsg = "$ipaMsg # Net Adapter DNS Suffix configuration skipped (Suffix not specified).`r`n"
                Write-DSLog -Level info -Message "Net Adapter DNS Suffix configuration skipped (Suffix not specified)"
            }

            # configure LMHosts lookup
            If($cbEnableLMHosts.IsChecked) {
                Write-DSLog -Level info -Message "Configuring LMHosts lookup"
                try {
                    Set-DSLmHostsLookup -LmHostsLookup $cbEnableLMHosts.IsChecked.ToString()
                    $ipaMsg = "$ipaMsg # LMHosts lookup configuration completed successfully`r`n"
                    Write-DSLog -Level info -Message "LMHosts lookup configuration completed successfully"
                }
                catch {
                    $ipaMsg = "$ipaMsg # LMHosts lookup configuration failed with error $($error[0].exception.message)`r`n"
                    Write-DSLog -Level error -Message "LMHosts lookup configuration failed: $($error[0].exception.message)"
                }
            }
            else {
                $ipaMsg = "$ipaMsg # LMHosts configuration skipped (user not selected to configure it).`r`n"
                Write-DSLog -Level info -Message "LMHosts configuration skipped (user not selected to configure it)"
            }
            # show message after applying IP to the user
            [System.Windows.Forms.MessageBox]::Show("$ipaMsg","DSSOE GUI Installer","OK","Information") | Out-Null
        }
        else { # user didn't select to continue with IP config
            Write-DSLog -Level warning -Message "User selected not to perform IP configuration, aborting."
        }
    }

    Remove-Indent -Footer "exit -> btnApplyStaticIP.add_Click event" # decrease indent in log file
})

# Event handler for 'Review and Install' tab item. When clicked, show summary of selection
# ----------------------------------------------------------------------------------------
$dsui.FindName('tcDSSOE').Add_SelectionChanged({
    $selTabHeader = $dsui.FindName('tcDSSOE').SelectedItem.Name
    if($selTabHeader -ne 'tiReviewAndInstall') { # other than 'review and install' tab selected, exit
        return;
    }
    # if this line runs, it means 'review and install' tab is selected
    $tbSummary.Inlines.Clear() # clear out everything off this textblock

    # which type of build has user selected?
    if($rbStandardBuild.IsChecked) { 
        Add-DSSummaryLine -Label "Selected DSSOE build type" -Value "Standard" -LineBreakAfter
    }
    else {
        Add-DSSummaryLine -Label "Selected domain controller build type" -Value "Express" -LineBreakAfter
    }

    # which type of domain promotion option selected by user (deployment operation)?
    $btnStartBuild.IsEnabled = $true # enable dssoe build button. if no valid op selected, it will be disabled by else block!
    if($rbNewForest.IsChecked) { 
        Add-DSSummaryLine -Label "Selected deployment operation" -Value "New Forest" -LineBreakAfter -Bold
        Add-DSSummaryLine -Label "  Root domain name" -Value $tbRootDomainName.Text -LineBreakAfter -BlanksAsRed
        Add-DSSummaryLine -Label "  Domain NetBIOS name" -Value $tbRootDomainNetBiosName.Text -LineBreakAfter -BlanksAsRed
        Add-DSSummaryLine -Label "  Forest functional level" -Value $cboForestFuncLevel.SelectedItem.Content -LineBreakAfter -BlanksAsRed
        Add-DSSummaryLine -Label "  Domain functional level" -Value $cboDomainFuncLevel.SelectedItem.Content -LineBreakAfter -BlanksAsRed
    }
    elseif($rbAdditionalDC.IsChecked) {
        Add-DSSummaryLine -Label "Selected deployment operation" -Value "Domain controller for existing domain" -LineBreakAfter -Bold
        Add-DSSummaryLine -Label "  Existing domain FQDN" -Value $cboExistingDomainName.SelectedItem.Content -LineBreakAfter -BlanksAsRed
        Add-DSSummaryLine -Label "  Forest functional level (detected)" -Value $cboForestFuncLevel.SelectedItem.Content -LineBreakAfter -BlanksAsRed
        Add-DSSummaryLine -Label "  Domain functional level (detected)" -Value $cboDomainFuncLevel.SelectedItem.Content -LineBreakAfter

        # options specific to additional DC
        Add-DSSummaryLine -Label "  Read only domain controller" -Value $cbRODC.IsChecked -LineBreakAfter
        Add-DSSummaryLine -Label "  Replicate data from existing DC" -Value $cbReplicateFromExistingDC.IsChecked -LineBreakAfter -Bold
        if($cbReplicateFromExistingDC.IsChecked) {
            Add-DSSummaryLine -Label "    Domain Controller to replicate from" -Value $cboReplicateFromExistingDC.SelectedItem.Content -LineBreakAfter -BlanksAsRed
        }
        Add-DSSummaryLine -Label "  Install from media" -Value $cbIFM.IsChecked -LineBreakAfter -Bold
        # check if IFM checkbox is selected and whether given path exists or not
        if($cbIFM.IsChecked) { 
            if([System.IO.Directory]::Exists($tbIFMPath.Text)) {
                Add-DSSummaryLine -Label "    Media path" -Value $tbIFMPath.Text -BlanksAsRed -LineBreakAfter
            }
            else { 
                Add-DSSummaryLine -Label " Media path" -Value 'Invalid media path' -Foreground 'Red' -LineBreakAfter
                $btnStartBuild.IsEnabled = $false
            }
        }
        Add-DSSummaryLine -Label "  Critical replication only" -Value $cbCriticalReplOnly.IsChecked -LineBreakAfter
    }
    elseif($rbNewChildDomain.IsChecked) {
        Add-DSSummaryLine -Label "Selected deployment operation" -Value "Child domain in existing forest" -LineBreakAfter -Bold
        Add-DSSummaryLine -Label "  Parent domain name" -Value $cboParentDomainName.SelectedItem.Content -LineBreakAfter -BlanksAsRed
        Add-DSSummaryLine -Label "  New child domain name" -Value $tbChildDomainName.Text -LineBreakAfter -BlanksAsRed
        Add-DSSummaryLine -Label "  Child domain NetBIOS name" -Value $tbChildDomainNetBiosName.Text -LineBreakAfter -BlanksAsRed
        Add-DSSummaryLine -Label "  Forest functional level (detected)" -Value $cboForestFuncLevel.SelectedItem.Content -LineBreakAfter -BlanksAsRed
        Add-DSSummaryLine -Label "  Domain functional level" -Value $cboDomainFuncLevel.SelectedItem.Content -LineBreakAfter -BlanksAsRed
    }
    elseif($rbNewTreeDomain.IsChecked) {
        Add-DSSummaryLine -Label "Selected deployment operation" -Value "Tree domain in existing forest" -LineBreakAfter -Bold
        Add-DSSummaryLine -Label "  Forest root domain name" -Value $tbForestName.Text -LineBreakAfter -BlanksAsRed
        Add-DSSummaryLine -Label "  New tree domain name" -Value $tbNewTreeDomainName.Text -LineBreakAfter -BlanksAsRed
        Add-DSSummaryLine -Label "  Tree domain NetBIOS name" -Value $tbNewTreeDomainNetBiosName.Text -LineBreakAfter -BlanksAsRed
        Add-DSSummaryLine -Label "  Forest functional level (detected)" -Value $cboForestFuncLevel.SelectedItem.Content -LineBreakAfter -BlanksAsRed
        Add-DSSummaryLine -Label "  Domain functional level" -Value $cboDomainFuncLevel.SelectedItem.Content -LineBreakAfter -BlanksAsRed
    }
    else { # none selected, invalid!!
        $btnStartBuild.IsEnabled = $False
        Add-DSSummaryLine -Label "Selected deployment operation" -Value "No deployment operation selected!" -LineBreakAfter -Foreground 'Red'
    }

    # credential info for deployment op
    if($promoOpCreds.user -eq $null) { # if it is not set (typically user will always be set)
        Add-DSSummaryLine -Label "Deployment credentials" -Value "No credential specified!" -LineBreakAfter -Foreground 'Red' 
        $btnStartBuild.IsEnabled = $False
    }
    else {
        if($promoOpCreds.Rights -eq 'LocalAdmin') { $ua = "$($env:COMPUTERNAME)\$($promoOpCreds.User)" }
        else { $ua = $promoOpCreds.User + '@' + $promoOpCreds.Domain }
        Add-DSSummaryLine -Label "Deployment credentials" -Value "$ua ($($promoOpCreds.Rights))" -LineBreakAfter -BlanksAsRed
    }

    # DNS and global catalog options
    Add-DSSummaryLine -Label "Install DNS server" -Value $cbInstallDNS.IsChecked -LineBreakAfter
    Add-DSSummaryLine -Label "Global catalog" -Value $cbGlobalCatalog.IsChecked -LineBreakAfter

    # AD database, log and sysvol paths
    If((Test-ADContentPath -Path $tbADDSPath.Text) -eq $false) { 
        Add-DSSummaryLine -Label "AD Database path" -Value "Invalid path specified" -Foreground 'Red' -LineBreakAfter
        $btnStartBuild.IsEnabled = $False
    }
    else { Add-DSSummaryLine -Label "AD Database path" -Value $tbADDSPath.Text -LineBreakAfter -BlanksAsRed }

    If((Test-ADContentPath -Path $tbADDSLog.Text) -eq $false) { 
        Add-DSSummaryLine -Label "AD Log path" -Value "Invalid path specified" -Foreground 'Red' -LineBreakAfter
        $btnStartBuild.IsEnabled = $False
    }
    else { Add-DSSummaryLine -Label "AD Log path" -Value $tbADDSLog.Text -LineBreakAfter -BlanksAsRed }

    If((Test-ADContentPath -Path $tbADDSSysvol.Text) -eq $false) { 
        Add-DSSummaryLine -Label "AD Sysvol path" -Value "Invalid path specified" -Foreground 'Red' -LineBreakAfter
        $btnStartBuild.IsEnabled = $False
    }
    else { Add-DSSummaryLine -Label "AD Sysvol path" -Value $tbADDSSysvol.Text -LineBreakAfter -BlanksAsRed }
    
    # safe mode admin password
    if($smAdminPassword.Password -eq $smAdminPassword2.Password) { # matches
        if((Test-ComplexPassword -Password $smAdminPassword2.Password)) {
            Add-DSSummaryLine -Label "Safe mode admin password" -Value ('*' * $smAdminPassword.Password.Length) -LineBreakAfter -BlanksAsRed
        }
        else {
            Add-DSSummaryLine -Label "Safe mode admin password" -Value "password is not complex" -Foreground 'Red' -LineBreakAfter -BlanksAsRed
            $btnStartBuild.IsEnabled = $False
        }
    }
    else {
        Add-DSSummaryLine -Label "Safe mode admin password" -Value "passwords do not match" -Foreground 'Red' -LineBreakAfter -BlanksAsRed
        $btnStartBuild.IsEnabled = $False
    }

    # AD site name selected
    if($rbNewForest.IsChecked -eq $False) { # if user has selected other than 'new forest' then show it
        Add-DSSummaryLine -Label "Selected AD site name" -Value $cboSiteName.SelectedItem.Content -BlanksAsRed -LineBreakAfter
    }

    # subnet to site association related items
    Add-DSSummaryLine -Label "Site to subnet association" -Value $cbSubnetSiteAssoc.IsChecked -LineBreakAfter -Bold:($cbSubnetSiteAssoc.IsChecked)
    if($cbSubnetSiteAssoc.IsChecked) {
        #$smvalid = Test-IPSubnetMask -IPMask $tbSiteSubnetMask.Text # validate mask
        #if($smvalid.Valid) { 
        if($tbSiteSubnetMask.Text.Length -lt 9 -or $tbSiteSubnetMask.Text.Contains('/') -eq $false) { # at least, 1.2.3.4/8 is valid 
            Add-DSSummaryLine -Label "  Subnet" -Value "Invalid subnet $($tbSiteSubnetMask.Text)" -LineBreakAfter -Foreground 'Red'
            $btnStartBuild.IsEnabled = $false
        }
        else {
            Add-DSSummaryLine -Label "  Subnet" -Value $tbSiteSubnetMask.Text -LineBreakAfter 
        }
        # check if if user is ent admin and show it accordingly
        if(Test-DSEmailAddress -Address $tbEntAdminUserName.Text) { # username in valid format
            $uinfo = $tbEntAdminUserName.Text -as [mailaddress]
            $res = Test-IsValidCredentials -UserName $uinfo.user -Password $tbEntAdminPassword.Password -Domain $uinfo.Host
            if($res.Value -eq $true) { # credentail validated
                $gminfo = Test-DSGroupMembership -Domain $uinfo.Host -UserName $uinfo.User -Password $tbEntAdminPassword.Password 
                if($gminfo.IsEnterpriseAdmins) {
                    $ssaUserText = $tbEntAdminUserName.Text # ent admin username summary text
                }
                else { # user is not ent admin
                    $ssaUserText = "$($tbEntAdminUserName.Text) is not Enterprise Admins" # ent admin username summary text
                }
            }
            else { $ssaUserText = "Invalid username $($tbEntAdminUserName.Text) or password" }
        }
        else { $ssaUserText = "Username $($tbEntAdminUserName.Text) should be in user@domain format" }

        if($ssaUserText -eq $tbEntAdminUserName.Text) { # show in regular blue color, else in red
            Add-DSSummaryLine -Label "  Username" -Value $ssaUserText -BlanksAsRed -LineBreakAfter
            Add-DSSummaryLine -Label "  Password" -Value ('*' * $tbEntAdminPassword.Password.Length) -BlanksAsRed -LineBreakAfter
        }
        else { 
            Add-DSSummaryLine -Label "  Username" -Value $ssaUserText -Foreground 'Red' -LineBreakAfter 
            Add-DSSummaryLine -Label "  Password" -Value ('*' * $tbEntAdminPassword.Password.Length) -Foreground 'Red' -LineBreakAfter
            $btnStartBuild.IsEnabled = $false # disable build button
        }
        
    }

    # pre-build options, valid for 'standard' build only. ignore for 'express' build
    if($rbStandardBuild.IsChecked) { # standard build
        # write summary of pre-build options
        Add-DSSummaryLine -Label "DSSOE Pre-build options" -Value '' -LineBreakAfter -Bold
        Add-DSSummaryLine -Label "  Configure pagefile" -Value $cbConfigPageFile.IsChecked -LineBreakAfter
        Add-DSSummaryLine -Label "  Clear events in event logs (application, security and system)" -Value $cbClearEvents.IsChecked -LineBreakAfter

        # reserve file creation
        Add-DSSummaryLine -Label "  Create reserve file" -Value $cbCreateReserveFile.IsChecked -LineBreakAfter -Bold:($cbCreateReserveFile.IsChecked)
        if($cbCreateReserveFile.IsChecked) {
            $rftest = Test-DSConfigReserveFile -ReserveFilePath $tbReserveFilePath.Text -SizeInMB $tbReserveFileSize.Text
            # reserve file path and size validated. gotcha is the function returning true if file path or size is blank!
            if($rftest -eq $true -and ($tbReserveFilePath.Text -ne "" -and $tbReserveFileSize.Text -ne "")) { 
                Add-DSSummaryLine -Label "    Reserve file path\name)" -Value $tbReserveFilePath.Text -LineBreakAfter -BlanksAsRed
                Add-DSSummaryLine -Label "    Reserve file size (MB)" -Value $tbReserveFileSize.Text -BlanksAsRed -LineBreakAfter
            }
            else {
                Add-DSSummaryLine -Label "    Reserve file path\name and size (MB)" -Value "invalid path $($tbReserveFilePath.Text) or file size $($tbReserveFileSize.Text)" -LineBreakAfter -Foreground 'Red'
                $btnStartBuild.IsEnabled = $false # disable build button
            }
        }

        # disable Netbios over tcp/ip
        Add-DSSummaryLine -Label "  Disable NetBIOS Over TCP/IP" -Value $cbDisableNetBIOSOverTCPIP.IsChecked -LineBreakAfter
        # disable SMB 1.0
        Add-DSSummaryLine -Label "  Disable SMB 1.0" -Value $cbDisableSMB.IsChecked -LineBreakAfter
        # configure RPC port range restriction
        if($cbRPCPortRestriction.IsChecked) {
            #the port range specified in the text box will be validated against the function Test-DSPortRange in the validation module
            $RpcportRangeTest = Test-DSPortRange -portrange $tbRPCPortRange.Text
            if($RpcportRangeTest -eq $true -and ($tbRPCPortRange.Text -ne "")) {
                Add-DSSummaryLine -Label "  Configure RPC port range restriction" -Value $tbRPCPortRange.Text -LineBreakAfter -BlanksAsRed                
            }
            else {
                Add-DSSummaryLine -Label "  Configure RPC port range restriction" -Value "invalid port range: $($tbRPCPortRange.Text)" -Foreground 'Red' -LineBreakAfter
                $btnStartBuild.IsEnabled = $false # disable build button               
            }
        } else { Add-DSSummaryLine -Label "  Configure RPC port range restriction" -Value $cbRPCPortRestriction.IsChecked -LineBreakAfter }



        # write summary of post-build options here
        Add-DSSummaryLine -Label "DSSOE Post-build options" -Value '' -LineBreakAfter -Bold
        if($rbAdditionalDC.IsChecked -eq $False) { # for additional DC< skip them as they're not applicable
            Add-DSSummaryLine -Label "  DXC stanadrd baseline policy configuration" -Value '' -LineBreakAfter -Bold
            Add-DSSummaryLine -Label "    Configure domain security policy" -Value $cbDomainSecPol.IsChecked -LineBreakAfter
            Add-DSSummaryLine -Label "    Configure domain controller security policy" -Value $cbDCSecPol.IsChecked -LineBreakAfter
        }

        if($rbAdditionalDC.IsChecked -eq $False) { # for additional DC< skip them as they're not applicable
            Add-DSSummaryLine -Label "  Organization Unit structure" -Value '' -LineBreakAfter -Bold
            Add-DSSummaryLine -Label "    Account type" -Value $cboAccountType.SelectedItem.Content -LineBreakAfter
            If($cboAccountType.SelectedItem.Content -eq 'Multitenant') {
                Add-DSSummaryLine -Label "    Implement AD delegation" -Value $cbConfigureADDelegation.IsChecked -LineBreakAfter
            }
            if($tbAccountCode.IsEnabled -eq $true) {
                If(($tbAccountCode.Text.Length -ne 3) -or ((Test-Chars -value $tbAccountCode.Text) -eq $false)) {
                    Add-DSSummaryLine -Label "    Account code" -Value "invalid account code $($tbAccountCode.Text)" -LineBreakAfter -Foreground 'Red'
                    $btnStartBuild.IsEnabled = $false # disable build button
                }
                else { Add-DSSummaryLine -Label "    Account code" -Value $tbAccountCode.Text -LineBreakAfter }
            }
        }

        #if($cbNTDS.IsChecked -or $cbNetlogon.IsChecked -or $cbDFSR.IsChecked -or $cbFRS.IsChecked)
        if($cbNTDS.IsChecked -or $cbNetlogon.IsChecked -or $cbDFSR.IsChecked) {
            Add-DSSummaryLine -Label "  Static port configuration for active directory" -Value '' -LineBreakAfter -Bold
        }
        #$ntdsp = $nlp = $dfsrp = $frsp = "" # iniitalize selected ports with blank text
        $ntdsp = $nlp = $dfsrp = "" # iniitalize selected ports with blank text
        if($cbNTDS.IsChecked) { 
            Add-DSSummaryLine -Label "    NTDS" -Value $tbNTDS.Text -LineBreakAfter -BlanksAsRed 
            $ntdsp = $tbNTDS.Text
        }
        if($cbNetlogon.IsChecked) { 
            Add-DSSummaryLine -Label "    Netlogon" -Value $tbNetlogon.Text -LineBreakAfter -BlanksAsRed 
            $nlp = $tbNetlogon.Text
        }
        if($cbDFSR.IsChecked) { 
            Add-DSSummaryLine -Label "    DFSR" -Value $tbDFSR.Text -LineBreakAfter -BlanksAsRed 
            $dfsrp = $tbDFSR.Text
        }
        <#
        if($cbFRS.IsChecked) { 
            Add-DSSummaryLine -Label "    FRS" -Value $tbFRS.Text -LineBreakAfter -BlanksAsRed 
            $frsp = $tbFRS.Text
        }
        #>
        
        # do overall port validation and set build button - only if at least one port is specified
        #if(-not ($ntdsp -eq "" -and $nlp -eq "" -and $dfsrp -eq "" -and $frsp -eq "")) { # at least one selected/specified
        if(-not ($ntdsp -eq "" -and $nlp -eq "" -and $dfsrp -eq "")) { # at least one selected/specified
            #$portVal = Test-DSStaticPorts -ADReplicationPort $ntdsp  -NetlogonPort $nlp  -FRSPort $frsp  -DFSRPort $dfsrp
            $portVal = Test-DSStaticPorts -ADReplicationPort $ntdsp  -NetlogonPort $nlp  -DFSRPort $dfsrp
            if($portVal -eq $False) { # port validation failed
                Add-DSSummaryLine -Label "    Port validation status" -Value "failed, see port tooltips for details" -LineBreakAfter -Foreground 'Red'
                $btnStartBuild.IsEnabled = $false
            }
            else { # validation successful
                Add-DSSummaryLine -Label "    Port validation status" -Value "passed" -LineBreakAfter
            }
        }

        Add-DSSummaryLine -Label "  Other configuration options" -Value '' -LineBreakAfter -Bold
        if($cbCreateBulkUsers.IsChecked) {
            if([System.IO.File]::Exists($tbBulkUserFile.Text)) {
                Add-DSSummaryLine -Label "    Create bulk users using file" -Value $tbBulkUserFile.Text -BlanksAsRed -LineBreakAfter
            }
            else { # invalid file path
                Add-DSSummaryLine -Label "    Create bulk users using file" -Value "invalid file $($tbBulkUserFile.Text)" -Foreground 'Red' -LineBreakAfter
                $btnStartBuild.IsEnabled = $false # disable build button
            }
        } else { Add-DSSummaryLine -Label "    Create bulk users" -Value $cbCreateBulkUsers.IsChecked -LineBreakAfter }

        if($cbExtTimeSyncServer.IsChecked) {
            if((Test-DSTimeServer -TimeServerName $tbExtTimeSyncServer.Text)) {
                Add-DSSummaryLine -Label "    Configure external time sync server" -Value $tbExtTimeSyncServer.Text -BlanksAsRed -LineBreakAfter
            }
            else { # invalid time sync server
                Add-DSSummaryLine -Label "    Configure external time sync server" -Value 'invalid time sync server specified' -Foreground 'Red' -LineBreakAfter
                $btnStartBuild.IsEnabled = $false # disable build button
            }
        } else { Add-DSSummaryLine -Label "    Configure external time sync server" -Value $cbExtTimeSyncServer.IsChecked -LineBreakAfter }

        if($cbDCPlacementOU.IsChecked) {
            $tdol = Test-DSOULocation -Domain $promoOpCreds.domain -Username $promoOpCreds.user -Password $tbPassword.Password  -OULocation $tbDCPlacementOU.Text
            if($tdol -eq $true) { # valid OU location
                Add-DSSummaryLine -Label "    Place domain controller in specific OU" -Value $tbDCPlacementOU.Text -LineBreakAfter
            }
            else { # invalid OU location
                Add-DSSummaryLine -Label "    Place domain controller in specific OU" -Value "invalid OU location specified" -LineBreakAfter -Foreground 'Red'
                $btnStartBuild.IsEnabled = $false
            }
        } else { Add-DSSummaryLine -Label "    Place domain controller in specific OU" -Value $cbDCPlacementOU.IsChecked -LineBreakAfter }

        <#if($cbBPAReport.IsChecked) {
            if([System.IO.Directory]::Exists($tbBPAReportPath.Text)) {
                Add-DSSummaryLine -Label "    Create BPA report" -Value $tbBPAReportPath.Text -BlanksAsRed -LineBreakAfter
            }
            else { # invalid path of BPA report
                Add-DSSummaryLine -Label "    Create BPA report" -Value 'invalid report folder path specified' -LineBreakAfter -Foreground 'Red'
                $btnStartBuild.IsEnabled = $false # disable build button
            }
        } else { Add-DSSummaryLine -Label "    Create BPA report" -Value $cbBPAReport.IsChecked -LineBreakAfter }
        #>

        if($cbConfigDNSForwarders.IsChecked) {
            $dnsfv = Test-MultipleIPAddress -IPAddress $tbDNSForwarders.Text # validate dns forwarder IP
            if($dnsfv) { 
                Add-DSSummaryLine -Label "    Configure DNS forwarders (IP)" -Value $tbDNSForwarders.Text  -LineBreakAfter
            }
            else { # DNS forwarders validation failed
                Add-DSSummaryLine -Label "    Configure DNS forwarders (IP)" -Value "failed, invalid forwarder IP address"  -LineBreakAfter -Foreground 'Red'
                $btnStartBuild.IsEnabled = $false
            }
        } 
        else { 
            Add-DSSummaryLine -Label "    Configure DNS forwarders" -Value $cbConfigDNSForwarders.IsChecked -LineBreakAfter 
        }

        # Configure DNS Scavenging
        Add-DSSummaryLine -Label "    Configure DNS scavenging" -Value $cbConfigureDNSScavenging.IsChecked -LineBreakAfter
        # Configure DSRM
        Add-DSSummaryLine -Label "    Configure Directory Services Restore Mode" -Value $cbConfigureDSRM.IsChecked -LineBreakAfter


        Add-DSSummaryLine -Label "    Enable scheduled backup" -Value $cbEnableScheduledBackup.IsChecked -LineBreakAfter
        if($cbEnableScheduledBackup.Ischecked) { # if checked then ensure backup volume path is selected
            if($cboBackupVolumePath.SelectedIndex -eq -1) { # none selected
                Add-DSSummaryLine -Label "    Backup Volume Path" -Value 'Not selected' -Foreground 'Red' -LineBreakAfter
                $btnStartBuild.IsEnabled = $false
            }
            else {
                Add-DSSummaryLine -Label "    Backup Volume Path" -Value $cboBackupVolumePath.SelectedItem.Content -LineBreakAfter
            }
        }
        Add-DSSummaryLine -Label "    Enable backup maintenance" -Value $cbEnableBackupMaint.IsChecked -LineBreakAfter

        # Install AD hotfixes
        Add-DSSummaryLine -Label "    Install AD hotfixes" -Value $cbInstallADHotfixes.IsChecked -LineBreakAfter
        
        #adding the ipam title with its selected value in RAI page
        Add-DSSummaryLine -Label "    Configure IPAM AD Prerequisites" -Value $cbConfigureIPAM.IsChecked -LineBreakAfter 
        if($cbConfigureIPAM.IsChecked) { # if checked then make sure to validate the ipam universal group and ipam server name
            If($tbIPAMUniversalGroup.Text -ne "") { # validating ipam universal grp name
                $IPAMgDomainName,$IPAMgrpName = ($tbIPAMUniversalGroup.Text).Split("\")
                #validating the user specified ipam universal group name
                If((Test-DSObjectExistence -domain $IPAMgDomainName -username $tbUserName.Text -password $tbPassword.Password `
                -Objectname $IPAMgrpName -Category 'group') -eq $false) { # invalid IPAM group name
                    Add-DSSummaryLine -Label "      IPAM Universal Group (domain.com\GroupName)" -Value 'Invalid IPAM universal group' -Foreground 'Red' -LineBreakAfter
                    $btnStartBuild.IsEnabled = $false
                }
                Else {
                    Add-DSSummaryLine -Label "      IPAM Universal Group (domain.com\GroupName)" -Value $tbIPAMUniversalGroup.Text -LineBreakAfter
                }
            }
            Else {
                Add-DSSummaryLine -Label "      IPAM Universal Group (domain.com\GroupName)" -Value 'Not specified' -Foreground 'Red' -LineBreakAfter
                $btnStartBuild.IsEnabled = $false
            }
            
            If($tbIPAMServerName.Text -ne "") { # validating ipam server name
                $ipamsrvname,$ipamsDomainname = ($tbIPAMServerName.Text).Split(".",2)
                $ipamsrvname = $ipamsrvname +"$"
                If((Test-DSObjectExistence -domain $ipamsDomainname -username $tbUserName.Text -password $tbPassword.password`
                 -Objectname $ipamsrvname -Category 'computer') -eq $false) {
                     Add-DSSummaryLine -Label "      IPAM Server Name" -Value 'Invalid IPAM server name' -Foreground 'Red' -LineBreakAfter
                     $btnStartBuild.IsEnabled = $false
                }
                else {
                    Add-DSSummaryLine -Label "      IPAM server Name" -Value $tbIPAMServerName.Text -LineBreakAfter
                }
            }
            else {
                Add-DSSummaryLine -Label "      IPAM server Name" -Value 'Not specified' -Foreground 'Red' -LineBreakAfter
                $btnStartBuild.IsEnabled = $false
            }
        }

        #adding AD recycle bin titles to RAI page
        Add-DSSummaryLine -Label "    Enable AD Recycle Bin" -Value $cbEnableADRecycleBin.IsChecked -LineBreakAfter
        If($rbNewForest.IsChecked -eq $false) { # not applicable to new forest scenario
            If($cbEnableADRecycleBin.IsChecked) { 
                Add-DSSummaryLine -Label "      AD Recycle Bin Scope" -Value $cboADRecycleBinScope.SelectedItem.Content -LineBreakAfter
                Add-DSSummaryLine -Label "      AD Recycle Bin Target Server" -Value $tbADRecycleBinTargetServer.Text -LineBreakAfter                
                if($cboADRecycleBinDomain.SelectedIndex -eq -1) { # none selected
                    Add-DSSummaryLine -Label "      AD Recycle Bin Target Domain" -Value 'Not selected' -Foreground 'Red' -LineBreakAfter
                    $btnStartBuild.IsEnabled = $false
                }
                else {
                    if(($cboADRecycleBinScope.SelectedItem.Content) -eq "ForestOrConfigurationSet") {
                        $ADRBUserInfo = $tbADRBHCUser.Text -as [MailAddress]
                        $ADRBForestInfo = (Get-DSADForest -Domain $ADRBUserInfo.Host -UserName $ADRBUserInfo.User -Password $tbADRBHCPassword.Password)
                        If($cboADRecycleBinDomain.SelectedItem.Content -ne (Get-DSADForestRootDomain)) {
                            Add-DSSummaryLine -Label "      AD Recycle Bin Target Domain" -Value 'Not root domain' -Foreground 'Red' -LineBreakAfter
                            $btnStartBuild.IsEnabled = $false
                        }
                        else {
                            Add-DSSummaryLine -Label "      AD Recycle Bin Target Domain" -Value $cboADRecycleBinDomain.SelectedItem.Content -LineBreakAfter
                        }
                    }
                    else {
                        Add-DSSummaryLine -Label "      AD Recycle Bin Target Domain" -Value $cboADRecycleBinDomain.SelectedItem.Content -LineBreakAfter
                    }
                }                
            }
        } 

        Add-DSSummaryLine -Label "  AD Health Check Reporting options" -Value '' -LineBreakAfter -Bold

        #adding AD health check reporting titles to RAi page
        Add-DSSummaryLine -Label "    Run AD Health Check Reporting" -Value $cbRunADHealthCheck.IsChecked -LineBreakAfter
        if($rbNewForest.IsChecked -eq $false) { # not applicable to new forest build
            if($cbRunADHealthCheck.IsChecked) {
                If($cbSelectAll.IsChecked){
                    Add-DSSummaryLine -Label "      Selected Domain(s)" -Value 'All' -LineBreakAfter
                }
                Else {
                    If($lboSelectDomainsADHC.SelectedIndex -eq -1) {
                        Add-DSSummaryLine -Label "      Selected Domain(s)" -Value 'Not selected' -Foreground 'Red' -LineBreakAfter
                        $btnStartBuild.IsEnabled = $false
                    }
                    Else {
                        $Dom = $lboSelectDomainsADHC.SelectedItems.Content
                        $DomainsForScan = $Dom -Join ','                      
                        Add-DSSummaryLine -Label "      Selected Domain(s)" -Value $DomainsForScan -LineBreakAfter                        
                    }
                }                
            }
        }
    }
})

# this function will generate DSSOE runtime XML file for unattended installation
# ------------------------------------------------------------------------------
Function Export-DSBuildXMLFile($Path) {
    Add-Indent -Header "enter -> Export-DSBuildXMLFile" # increase indent in log file

    # read DSSOE config template xml into variable for manipulation
    if([System.IO.File]::Exists("$PSScriptRoot\..\config\dssoe.xml")) { 
        [xml] $dx = Get-Content "$PSScriptRoot\..\config\dssoe.xml"
    }
    else { 
        Write-DSLog -Level error -Message "Unable to find DSSOE template XML file $("$PSScriptRoot\..\config\dssoe.xml"). Export failed."
        Remove-Indent -Footer "exit -> Export-DSBuildXMLFile" # decrease indent in log file
        return $null # indicate that nothing was exported
    }

    Write-DSLog -Level info -Message "Generating DSSOE unattend xml file based on user selections in the GUI"

    # get and set dc promo option selected by user
    if($rbNewForest.IsChecked) { $SelectedPromoOption = "NewDomainNewForest" }
    elseif($rbAdditionalDC.IsChecked) { $SelectedPromoOption = "AdditionalDC" }
    elseif($rbNewChildDomain.IsChecked) { $SelectedPromoOption = "NewChildDomain" }
    elseif($rbNewTreeDomain.IsChecked) { $SelectedPromoOption = "NewTreeDomain" }
    else { $SelectedPromoOption = "Unknown" }

    # now set common xml properties across all 4 dc promo options
    $dx.DSSOE.DCPromoOptions.Selected = $SelectedPromoOption
    $dx.DSSOE.DCPromoOptions.$SelectedPromoOption.UserName = $promoOpCreds.User
    #$dx.DSSOE.DCPromoOptions.$SelectedPromoOption.Password = (&"$PSScriptRoot\..\modules\soecrypt.exe" encrypt $tbPassword.Password $pkey).ToString()
    $dx.DSSOE.DCPromoOptions.$SelectedPromoOption.Password = (Protect-SOEString -String $tbPassword.Password -Key $pkey).ToString()
    $dx.DSSOE.DCPromoOptions.$SelectedPromoOption.ADDatabasePath  = $tbADDSPath.Text            
    $dx.DSSOE.DCPromoOptions.$SelectedPromoOption.ADLogfilePath = $tbADDSLog.Text              
    $dx.DSSOE.DCPromoOptions.$SelectedPromoOption.SysvolPath = $tbADDSSysvol.Text
    #$dx.DSSOE.DCPromoOptions.$SelectedPromoOption.SafeModeAdminPassword = (&"$PSScriptRoot\..\modules\soecrypt.exe" encrypt $smAdminPassword2.Password $pkey).ToString()
    $dx.DSSOE.DCPromoOptions.$SelectedPromoOption.SafeModeAdminPassword = (Protect-SOEString -String $smAdminPassword2.Password -Key $pkey).ToString()
    if($SelectedPromoOption -eq "NewDomainNewForest") {
        $dx.DSSOE.DCPromoOptions.$SelectedPromoOption.ADSiteName = "Default"
    }
    else { $dx.DSSOE.DCPromoOptions.$SelectedPromoOption.ADSiteName = $cboSiteName.SelectedItem.Content }
    $dx.DSSOE.DCPromoOptions.$SelectedPromoOption.InstallDNS = $cbInstallDNS.IsChecked.ToString() 

    # if promo option selected is other than 'NewDomainNewForest' then set Global catalog
    if($rbNewForest.IsChecked -eq $False) { 
        $dx.DSSOE.DCPromoOptions.$SelectedPromoOption.GlobalCatalog = $cbGlobalCatalog.IsChecked.ToString()
    }

    # set domain mode for option other than AdditionalDC
    if($rbAdditionalDC.IsChecked -eq $False) { 
        # get domain mode as required by dcpromo cmd line.. ForestModeNumber 3 is for win2008 so that we get all modes and filter based on select domain mode display name
        $dmode = Get-DSSupportedDomainModes -ForestModeNumber 3 | Where-Object { $_.ModeDisplayName -eq $cboDomainFuncLevel.SelectedItem.Content }
        if($dmode.DomainMode -eq 'Windows8Domain') { $dmode.DomainMode = 'Windows2012Domain' }
        if($dmode.ModeNumber -eq '7') { $dmode.DomainMode = 'Windows2016Domain' } #added [24-1-2017]; when domainmodelevel is 7, domainmode should be Windows2016Domain
        $dx.DSSOE.DCPromoOptions.$SelectedPromoOption.DomainFunctionalLevel = $dmode.DomainMode
    }

    # set items specific to NewDomainNewForest
    if($rbNewForest.IsChecked) { 
        $dx.DSSOE.DCPromoOptions.NewDomainNewForest.NewDomainFQDN = $tbRootDomainName.Text     
        $dx.DSSOE.DCPromoOptions.NewDomainNewForest.NewDomainNetBIOS = $tbRootDomainNetBiosName.Text
        # get forest mode as required by dcpromo cmd line
        $fmode = (Get-DSSupportedForestModes | Where-Object { $_.ModeDisplayName -eq $cboForestFuncLevel.SelectedItem.Content})
        if($fmode.ForestMode -eq 'Windows8Forest') { $fmode.ForestMode = 'Windows2012Forest' }
        if($fmode.ModeNumber -eq '7') { $fmode.ForestMode = 'Windows2016Forest' } #added [24-1-2017]; when forestmodelevel is 7, forestmode should be Windows2016Forest
        $dx.DSSOE.DCPromoOptions.NewDomainNewForest.ForestFunctionalLevel = $fmode.ForestMode
        }
    #}
    elseif($rbAdditionalDC.IsChecked) { 
        $dx.DSSOE.DCPromoOptions.AdditionalDC.Domain = $promoOpCreds.domain # credentials domain
        $dx.DSSOE.DCPromoOptions.AdditionalDC.RODC = $cbRODC.IsChecked.ToSTring()
        # install from media option
        $dx.DSSOE.DCPromoOptions.AdditionalDC.InstallFromMedia.ReplicateDatafromMedia = $cbIFM.IsChecked.ToString()
        $dx.DSSOE.DCPromoOptions.AdditionalDC.InstallFromMedia.MediaPath = $tbIFMPath.Text
        # if IFM is selected then ensure that you set False to ReplicateFromExistingDC!
        if($cbIFM.IsChecked) { $dx.DSSOE.DCPromoOptions.AdditionalDC.ReplicateDatafromExistingDC.Enabled = "False" }
        # if user has selected to replicate from existing DC then set else leave it to XML template default
        if($cbReplicateFromExistingDC.IsChecked) { 
            $dx.DSSOE.DCPromoOptions.AdditionalDC.ReplicateDatafromExistingDC.Enabled = $cbReplicateFromExistingDC.IsChecked.ToString()
            $dx.DSSOE.DCPromoOptions.AdditionalDC.ReplicateDatafromExistingDC.ReplicaDC = $cboReplicateFromExistingDC.SelectedItem.Content
        }
        $dx.DSSOE.DCPromoOptions.AdditionalDC.CriticalReplicationOnly = $cbCriticalReplOnly.IsChecked.ToString()
    }
    elseif($rbNewChildDomain.IsChecked) { 
        $dx.DSSOE.DCPromoOptions.NewChildDomain.Domain = $promoOpCreds.domain # credentials domain
        $dx.DSSOE.DCPromoOptions.NewChildDomain.ParentDomain = $cboParentDomainName.SelectedItem.Content
        $dx.DSSOE.DCPromoOptions.NewChildDomain.ChildDomainName = $tbChildDomainName.Text
        $dx.DSSOE.DCPromoOptions.NewChildDomain.ChildDomainNameNetBIOS = $tbChildDomainNetBiosName.Text
    }
    elseif($rbNewTreeDomain.IsChecked) { 
        $dx.DSSOE.DCPromoOptions.NewTreeDomain.Domain = $promoOpCreds.domain # credentials domain
        $dx.DSSOE.DCPromoOptions.NewTreeDomain.ForestRootDomain = $tbForestName.Text    
        $dx.DSSOE.DCPromoOptions.NewTreeDomain.TreeDomainName = $tbNewTreeDomainName.Text
        $dx.DSSOE.DCPromoOptions.NewTreeDomain.TreeDomainNameNetbios = $tbNewTreeDomainNetBiosName.Text
        $dx.DSSOE.DCPromoOptions.NewTreeDomain.DomainFunctionalLevel
    }

    # site to subnet association options - for all dcpromo options except NewForest
    if($rbNewForest.IsChecked -eq $False) { 
        $dx.DSSOE.DCPromoOptions.Subnet.Association = $cbSubnetSiteAssoc.IsChecked.ToSTring()
        if($cbSubnetSiteAssoc.IsChecked) { # site to subnet association is checked
            $uinfo = $tbEntAdminUserName.Text -as [mailaddress]
            $dx.DSSOE.DCPromoOptions.Subnet.Domain = $uinfo.host
            $dx.DSSOE.DCPromoOptions.Subnet.EntAdminUserName = $uinfo.user
            #$dx.DSSOE.DCPromoOptions.Subnet.Password = (&"$PSScriptRoot\..\modules\soecrypt.exe" encrypt $tbEntAdminPassword.Password $pkey).ToString()
            $dx.DSSOE.DCPromoOptions.Subnet.Password = (Protect-SOEString -String $tbEntAdminPassword.Password -Key $pkey).ToString()
            $dx.DSSOE.DCPromoOptions.Subnet.SubnetMask = $tbSiteSubnetMask.Text
        }
    }

    # DSSOE pre and post configuration items - only for standard build they're applicable
    $dx.DSSOE.DSConfiguration.ConfigureDSPageFile = $cbConfigPageFile.IsChecked.ToString()
    $dx.DSSOE.DSConfiguration.ClearEvents = $cbClearEvents.IsChecked.ToSTring()
    if($cbCreateReserveFile.IsChecked) {
        $dx.DSSOE.DSConfiguration.ReserveFile.Path = $tbReserveFilePath.Text
        $dx.DSSOE.DSConfiguration.ReserveFile.SizeMB = $tbReserveFileSize.Text
    }

    $dx.DSSOE.DSConfiguration.DisableNetBIOSOverTCPIP = $cbDisableNetBIOSOverTCPIP.IsChecked.ToString()
    $dx.DSSOE.DSConfiguration.DisableSMB1 = $cbDisableSMB.IsChecked.ToString()
    $dx.DSSOE.DSConfiguration.ConfigureRPCPortRange.Configure = $cbRPCPortRestriction.IsChecked.ToString()
    if($cbRPCPortRestriction.IsChecked){ # add port range
        $dx.DSSOE.DSConfiguration.ConfigureRPCPortRange.PortRange = $tbRPCPortRange.Text
    }

    if($cbExtTimeSyncServer.IsChecked) {
        $dx.DSSOE.DSConfiguration.ExternalTimeServer.Name = $tbExtTimeSyncServer.Text
    }
    if($rbAdditionalDC.IsChecked -and $cbDCPlacementOU.IsChecked) { #set OU location for additionalDC only, if selected
        $dx.DSSOE.DSConfiguration.DCOULocation.OU = $tbDCPlacementOU.Text
    }
    # for promo option other than additionalDC, set secutiy and OU structure
    if($rbAdditionalDC.IsChecked -eq $False) { 
        $dx.DSSOE.DSConfiguration.SecurityBaselinePolicies.ConfigureDomainPolicy = $cbDomainSecPol.IsChecked.ToString()
        $dx.DSSOE.DSConfiguration.SecurityBaselinePolicies.ConfigureDomainControllerPolicy = $cbDCSecPol.IsChecked.ToString()
        if($cboAccountType.SelectedItem.Content -ne 'default') { # if accountType is selected then add else leave it to xml default
            $dx.DSSOE.DSConfiguration.OUStructure.AccountType = $cboAccountType.SelectedItem.Content
        }
        if($tbAccountCode.Text.Length -gt 0) { $dx.DSSOE.DSConfiguration.OUStructure.AccountCode = $tbAccountCode.Text }
        $dx.DSSOE.DSConfiguration.OUStructure.ADDelegation = $cbConfigureADDelegation.IsChecked.ToString()
    }
    $dx.DSSOE.DSConfiguration.DSBackup.Configure = $cbEnableScheduledBackup.IsChecked.ToString()
    if($cbEnableScheduledBackup.IsChecked) { # add backup volume path 
        $dx.DSSOE.DSConfiguration.DSBackup.BackupVolumePath = $cboBackupVolumePath.SelectedItem.Content.SubString(0,2)
    }
    $dx.DSSOE.DSConfiguration.DSBackup.EnableBackupMaintenance = $cbEnableBackupMaint.IsChecked.Tostring()
    
    if($cbCreateBulkUsers.IsChecked) { 
        $dx.DSSOE.DSConfiguration.CreateADUsers.UserListExcelFile = $tbBulkUserFile.Text 
    }
    #$dx.DSSOE.DSConfiguration.BPAReport.Generate = $cbBPAReport.IsChecked.ToString()
    #$dx.DSSOE.DSConfiguration.BPAReport.ReportPath = $tbBPAReportPath.Text
    if($cbConfigDNSForwarders.IsChecked) {
        $dx.DSSOE.DSConfiguration.DNSForwarders.ForwardersIP = $tbDNSForwarders.Text
    }

    $dx.DSSOE.DSConfiguration.ConfigDNSScavenging = $cbConfigureDNSScavenging.IsChecked.ToString()
    $dx.DSSOE.DSConfiguration.ConfigureDSRM = $cbConfigureDSRM.IsChecked.ToString()
    $dx.DSSOE.DSConfiguration.InstallADHotfixes = $cbInstallADHotfixes.IsChecked.ToString()


    # call verification function to check if user has specified required port combination. if so, set it in xml
    #$portVal = Test-DSStaticPorts -ADReplicationPort $tbNTDS.Text  -NetlogonPort $tbNetlogon.Text  -FRSPort $tbFRS.Text  -DFSRPort $tbDFSR.Text
    $portVal = Test-DSStaticPorts -ADReplicationPort $tbNTDS.Text  -NetlogonPort $tbNetlogon.Text  -DFSRPort $tbDFSR.Text
    if($portVal -eq $False) { # port validation failed
        $dx.DSSOE.DSConfiguration.StaticPort.Configure = "False" # set it to false not to proceed with prot config
    }
    else { # port validation successful
        $dx.DSSOE.DSConfiguration.StaticPort.Configure = "True" # set it to true to proceed with prot config
        $dx.DSSOE.DSConfiguration.StaticPort.ADReplicationPort = $tbNTDS.Text
        $nlp = $dx.DSSOE.DSConfiguration.StaticPort.NetLogonPort = $tbNetlogon.Text
        #$frsp = $dx.DSSOE.DSConfiguration.StaticPort.FRSReplicationPort = $tbFRS.Text
        $dfsrp = $dx.DSSOE.DSConfiguration.StaticPort.DFSRReplicationPort = $tbDFSR.Text
    }

    #IPAM - Added 28 Sep 2016
    If($rbNewForest.IsChecked) {
        $dx.DSSOE.DSConfiguration.IPAMAccess.Configure = "False"        
    }
    Else {
        $dx.DSSOE.DSConfiguration.IPAMAccess.Configure = $cbConfigureIPAM.IsChecked.ToString()
        If($cbConfigureIPAM.IsChecked) {            
            $dx.DSSOE.DSConfiguration.IPAMAccess.IPAMUnivGroup = $tbIPAMUniversalGroup.Text
            $dx.DSSOE.DSConfiguration.IPAMAccess.IPAMServer = $tbIPAMServerName.Text
        }
    }

    #AD Recycle Bin - Added 28-Sep-2016
    If($rbNewForest.IsChecked) {
        $dx.DSSOE.DSConfiguration.ADRecycleBin.Enable = $cbEnableADRecycleBin.IsChecked.ToString()
        If($cbEnableADRecycleBin.IsChecked) {
            $dx.DSSOE.DSConfiguration.ADRecycleBin.Username = $tbUserName.Text
            $dx.DSSOE.DSConfiguration.ADRecycleBin.Password = $dx.DSSOE.DCPromoOptions.NewDomainNewForest.Password
            $dx.DSSOE.DSConfiguration.ADRecycleBin.Domain = $tbRootDomainName.Text
            $dx.DSSOE.DSConfiguration.ADRecycleBin.ADRecycleBinScope = "ForestOrConfigurationSet"
            $dx.DSSOE.DSConfiguration.ADRecycleBin.ADRecycleBinTargetServer = "$($env:COMPUTERNAME).$($tbRootDomainName.Text)"
            $dx.DSSOE.DSConfiguration.ADRecycleBin.ADRecycleBinTargetDomain = $tbRootDomainName.Text
        }
    }
    Else {
        $dx.DSSOE.DSConfiguration.ADRecycleBin.Enable = $cbEnableADRecycleBin.IsChecked.ToString()
        If($cbEnableADRecycleBin.IsChecked) {
            $ADRecyclebinUserInfo = $tbADRBHCUser.Text -as [mailaddress]                        
            $dx.DSSOE.DSConfiguration.ADRecycleBin.Username = $ADRecyclebinUserInfo.User
            $dx.DSSOE.DSConfiguration.ADRecycleBin.Password = (Protect-SOEString -String $tbADRBHCPassword.Password -Key $pkey).ToString()
            $dx.DSSOE.DSConfiguration.ADRecycleBin.Domain = $ADRecyclebinUserInfo.Host
            $dx.DSSOE.DSConfiguration.ADRecycleBin.ADRecycleBinScope = $cboADRecycleBinScope.SelectedItem.Content.ToString()
            $dx.DSSOE.DSConfiguration.ADRecycleBin.ADRecycleBinTargetServer = $tbADRecycleBinTargetServer.Text
            $dx.DSSOE.DSConfiguration.ADRecycleBin.ADRecycleBinTargetDomain = $cboADRecycleBinDomain.SelectedItem.Content.ToString()
        }
    }

    #AD Health Check - Added 28-Sep-2016
    If($rbNewForest.IsChecked) {
        $dx.DSSOE.DSConfiguration.ADHealthCheck.Execute = $cbRunADHealthCheck.IsChecked.ToString()
        If($cbRunADHealthCheck.IsChecked) {
            $dx.DSSOE.DSConfiguration.ADHealthCheck.Username = $tbUserName.Text 
            $dx.DSSOE.DSConfiguration.ADHealthCheck.Password = $dx.DSSOE.DCPromoOptions.NewDomainNewForest.Password
            $dx.DSSOE.DSConfiguration.ADHealthCheck.Domain = $tbRootDomainName.Text
            $dx.DSSOE.DSConfiguration.ADHealthCheck.DomainsToScan = $tbRootDomainName.Text
        }
    }
    else {
        $dx.DSSOE.DSConfiguration.ADHealthCheck.Execute = $cbRunADHealthCheck.IsChecked.ToString()
        If($cbRunADHealthCheck.IsChecked) {
            $ADHCUserInfo = $tbADRBHCUser.Text -as [mailaddress]
            $dx.DSSOE.DSConfiguration.ADHealthCheck.Username = $ADHCUserInfo.User
            $dx.DSSOE.DSConfiguration.ADHealthCheck.Password = (Protect-SOEString -String $tbADRBHCPassword.Password -Key $pkey).ToString()
            $dx.DSSOE.DSConfiguration.ADHealthCheck.Domain = $ADHCUserInfo.Host
            If($cbSelectAll.IsChecked) {
                $dx.DSSOE.DSConfiguration.ADHealthCheck.DomainsToScan = "All"
            }
            Else {
                $DomToScan = $lboSelectDomainsADHC.SelectedItems.Content
                $DomForScan = $DomToScan -Join(',')
                $dx.DSSOE.DSConfiguration.ADHealthCheck.DomainsToScan = $DomForScan
            }
        }
    }


    # if path is null then save to a temp location and return path to user
    if([string]::IsNullOrEmpty($Path)) { $Path = [System.IO.Path]::GetTempFileName() } # get a temp file name in user temp dir
    try { # attemp to save to given file
        $dx.Save($Path)
        Write-DSLog -Level Info -Message "DSSOE build XML file is exported to $Path"
        Remove-Indent -Footer "exit -> Export-DSBuildXMLFile" # decrease indent in log file
        return $path
    }
    catch {
        Write-DSLog -Level Error -Message "Unable to export DSSOE build XML file to $Path. `r`n$($_.Exception.Message)"
        Remove-Indent -Footer "exit -> Export-DSBuildXMLFile" # decrease indent in log file
        return $null
    }
}

# event handler for export menu item.. export DSSOE config XML file
# ------------------------------------------------------------------
$mnuExportConfig.add_Click(
{
    if((Get-OSInstallMode -shortname) -eq 'Core')
    {
    [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.VisualBasic") | Out-null
    $out = [Microsoft.VisualBasic.interaction]::Inputbox("Enter the path along with file name to export the DSSOE xml file","DSSOE XML File Export","C:\Export.xml")
if ($out.Length -ne 0)
{
if($out.Length -ge 8)
{
$res = $null
$filename = split-path -path $out -leaf
$path =  split-path -path $out
if(($out.Substring($out.Length-4,4) -eq '.xml') -and ($filename.IndexOfAny([System.io.path]::GetInvalidFileNameChars()) -eq -1) -and ($path.IndexOfAny([System.io.path]::GetInvalidPathChars()) -eq -1) -and ($path.length -ge 3) -and ($filename -ge 4))
{
    if(!(Test-path $path -PathType Container))
    {
    $res = New-Item -Path $path -ItemType "directory" -force
    if($res -eq $null)
    {
    [System.Windows.Forms.MessageBox]::Show("Unable to create the directory structure provided in the path $out.","DSSOE GUI Installer","OK","Error")
    }
    }
    $dstxml = Export-DSBuildXMLFile -Path $out
    if($dstxml -eq $null) { 
            [System.Windows.Forms.MessageBox]::Show("Unable to export DSSOE build configuration to $out.","DSSOE GUI Installer","OK","Error")
        }
        else {
            [System.Windows.Forms.MessageBox]::Show("DSSOE build configuration is successfully exported to $out.`nIf you are planning to use the exported DSSOE build configuration XML file for DSSOE unattended installation (using SETUP.PS1 script in DSSOE package), please note that you will need to use below text as -PassKey parameter:`n$pkey`nYou should protect this Pass Key as it has potential to decrypt encrypted passwords in exported build configuration XML file!","DSSOE GUI Installer","OK","Information") 
        }
}
else
{
[System.Windows.Forms.MessageBox]::Show("Invalid path or filename specified '$out'.","DSSOE GUI Installer","OK","Error")
}
}
else
{
[System.Windows.Forms.MessageBox]::Show("Invalid path or filename specified '$out'.","DSSOE GUI Installer","OK","Error")
}
}
    }
    else
    {
    $SaveFileDialog = New-Object System.Windows.Forms.SaveFileDialog
    $SaveFileDialog.Filter = "DSSOE Config File (*.xml)|*.xml"
    $SaveFileDialog.initialDirectory = "c:\"
    
    if ($SaveFileDialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        $dstxml = Export-DSBuildXMLFile -Path $SaveFileDialog.FileName 
        if($dstxml -eq $null) { 
            [System.Windows.Forms.MessageBox]::Show("Unable to export DSSOE build configuration to $($SaveFileDialog.FileName).","DSSOE GUI Installer","OK","Error")
        }
        else {
            [System.Windows.Forms.MessageBox]::Show("DSSOE build configuration is successfully exported to $($SaveFileDialog.FileName).`nIf you are planning to use the exported DSSOE build configuration XML file for DSSOE unattended installation (using SETUP.PS1 script in DSSOE package), please note that you will need to use below text as -PassKey parameter:`n$pkey`nYou should protect this Pass Key as it has potential to decrypt encrypted passwords in exported build configuration XML file!","DSSOE GUI Installer","OK","Information") 
        }
    }
   }
}
)

# event handler for Notepad menu item
# -----------------------------------
$mnuNotepad.add_Click({
    Start-Process -FilePath "$($env:Windir)\System32\Notepad.exe"
})

# event handler for 'open log file' menu item
# --------------------------------------------
$mnuOpenLog.add_Click({
    Start-Process -FilePath "$($env:Windir)\System32\Notepad.exe" -ArgumentList ($DSLogFile)
})

# event handler for Exit button
# ------------------------------
$mnuExit.add_Click({
    [void]$btnExit.RaiseEvent($evt)
})

# Event handler for Exit button, simply call Exit menu item click event
# ---------------------------------------------------------------------
$btnExit.add_Click({
    $res = [System.Windows.Forms.MessageBox]::Show("All selections and inputs you have made in the form will be lost. Are you sure you want to exit?","DSSOE GUI Installer","YesNo","Question")
    if($res -eq 'Yes') { # exit
        $dsui.Close()
        exit
    }
})


# event handler for 'Start Build' button
# ----------------------------------------
$btnStartBuild.add_Click({
    Add-Indent -Header "enter -> btnStartBuild.add_Click event" # increase indent in log file

    $bxmlPath = "C:\SUPPORT\LOGS\DSSOE\DSSOE-GUI-$(((Get-Date).ToString('MMddyyyy-hhmmss'))).xml"
    $dstxml = Export-DSBuildXMLFile -Path $bxmlPath
    
    if($dstxml -eq $null) { # fatal error, show dialog and remain
        Write-DSLog -Level error -Message "Unable to save DSSOE build configuration. DSSOE build cannot be started."
        [System.Windows.Forms.MessageBox]::Show("Unable to save DSSOE build configuration. DSSOE build cannot be started.","DSSOE GUI Installer","OK","Error")
    }
    else { # build xml exported, kick of DSSOE setup
        Write-DSLog -Level Info -Message "Exported DSSOE unattended build XML file to $dstxml"
        Write-DSLog -Level Info -Message "Starting DSSOE build using auto-generated build xml file $bxmlPath"
        $dsui.Close()
        
        #Exit
        #exiting for testing.

        (Get-Item -Path $DSLogFile)
        $dsSetupPath = "`'$((Resolve-Path "$PSScriptRoot\..\setup.ps1").Path)`'"
        $dsCmd = "$dsSetupPath -AnswerFile `'$bxmlPath`'"
        if($cbADPathToOSDrive.IsChecked) { $dsCmd = "$dsCmd -ConfigADPathsToOSDrive" } # AD paths on C drive
        if($rbExpressBuild.IsChecked) { $dsCmd = "$dsCmd -ExpressInstall" } # if express install then append it
        if($cbUpgradeADSchema.IsChecked) { $dsCmd = "$dsCmd -UpgradeSchema" } # schema upgrade
        if($hasDHCP -eq "true") { $dsCmd = "$dsCmd -IgnoreDHCPWarning" } # ignore the DHCP warning
        Write-DSLog -Level Info -Message "Invoking DSSOE build using command line"
        Write-DSLog -Level Info -Message "$dsCmd -PassKey *"
        $dsCmd = "$dsCmd -PassKey $pkey" # added here to avoid getting it into log file
        Write-Verbose "DSSOE build process started.. please wait" -Verbose
        $dsCmd = "`"& $dsCmd`""
        $cmdout = Start-Process -FilePath powershell.exe -ArgumentList $dsCmd -NoNewWindow -Wait #-RedirectStandardError $env:TEMP\dssexec.err -RedirectStandardOutput $env:TEMP\dssexec.out -Wait
        #$cmdout = Start-Process -FilePath powershell.exe -ArgumentList $dsCmd -Wait -RedirectStandardError $env:TEMP\dssexec.err -RedirectStandardOutput $env:TEMP\dssexec.out

        # write any errors produced by DSSOE command execution
        <# if((Get-Item $env:TEMP\dssexec.err -ErrorAction SilentlyContinue).Length -ne 0) { # not empty file
            Write-DSLog -Level Info -Message "errors produced by DSSOE build execution:"
            Write-DSLog -Level Info -Message ([system.io.file]::ReadAllText("$env:TEMP\dssexec.err"))
        }
        # write any output produced by DSSOE command execution
        if((Get-Item $env:TEMP\dssexec.out -ErrorAction SilentlyContinue).Length -ne 0) { # not empty file
            Write-DSLog -Level Info -Message "output produced by DSSOE build execution:"
            Write-DSLog -Level Info -Message ([system.io.file]::ReadAllText("$env:TEMP\dssexec.out"))
        } #>
        Write-DSLog -Level Info -Message "Output produced by DSSOE build process kickoff:`n $cmdout" -verbose
    }
})

#endregion

# =================================================================================================
# Prepare to display the form to the user. Set logo paths, load BM configuration and show the form
# =================================================================================================
#region set control defaults (visibility, value etc.)
'lblBulkUserFile','tbBulkUserFile','tbExtTimeSyncServer','tbDCPlacementOU',`
'tbDNSForwarders',,'wpReserveFile','cboReplicateFromExistingDC','cbConfigureADDelegation' | foreach { $dsui.FindName($_).IsEnabled = $false } #removed 'lblBPAReportPath','tbBPAReportPath'

#collapse deployment op tab items
'dopTiNewForest','dopTiNewChildDomain','dopTiNewTreeDomain' | foreach { $dsui.FindName($_).Visibility = "Collapsed" }

#collapse IPAM, AD Recycle Bin, AD health check options
'wpConfigureIPAMOptions','wpConfigureADRBOptions','wpConfigureADHCOptions' | foreach { $dsui.FindName($_).Visibility = "Collapsed" }

#disabling the controls for AD recycle bin, AD health check and IPAM
'lblADRecycleBinScope','cboADRecycleBinScope','lblADRecycleBinTargetServer','tbADRecycleBinTargetServer',`
'lblADRecycleBinTargetDomain','cboADRecycleBinDomain','lblDomainNamesADHC'`
,'lboSelectDomainsADHC','lblIPAMUniversalGroup','tbIPAMUniversalGroup','lblIPAMServerName','tbIPAMServerName'`
,'cbEnableADRecycleBin','cbRunADHealthCheck','cbSelectAll' | foreach { $dsui.FindName($_).IsEnabled = $False }

# by-default, select domain and domain controller security policy, DNS, GC checked also 
$cbDCSecPol, $cbDomainSecPol, $cbInstallDNS, $cbGlobalCatalog | foreach { $_.IsChecked = $true }

# disable controls related to 'site to subnet association' 
Set-DSSiteSubnetAssocControlsStatus -Status disabled

# fire events of 'install from media' and 'replicate data from existing dc' to set related controls 
$cbReplicateFromExistingDC.RaiseEvent($evt)
$cbIFM.RaiseEvent($evt)

# collapse all build dependent tabs.. they will be enabled on creds validation
Set-DSBuildDependentTabsVisibility -Status Disabled

# disable all deployment options radio and focus on 'Username' text box
Set-DSBuildTypeControlsVisibility 

# populate backup volume paths in relevant combo
Set-DSBackupVolumePathCombo

# set default username as logged-in username (based on whether user is member of domain or workgroup)
#(Get-WmiObject win32_computersystem).partofdomain
if(($env:USERDNSDOMAIN)) { $tbUserName.Text = "$($env:USERNAME)@$($env:USERDNSDOMAIN)" }
else { $tbUserName.Text = $env:USERNAME }
# set focus on username text box
$tbUserName.Focus() 

# show lof file path in text box and let user change it as well
$lblLogPath.Content = "DSSOE Log files will be saved to $LogPath"

#endregion

# Set DXC logo image and local build source refresh image. for some reason, relative path is not accepted in xaml (in powershell)
$dsui.FindName("imgCSCLogo").Source = "File://$($PSScriptRoot)\LOGO.PNG"

# populate network interfaces and related elements
Set-DSNetworkInterfaces 

#providing Netbios over tcpip status
if(Get-ADDSNetBStatus -eq $true) {
    $cbDisableNetBIOSOverTCPIP.Content = "Disable NetBIOS Over TCP/IP (already disabled)"
    $cbDisableNetBIOSOverTCPIP.IsChecked = $False
    $cbDisableNetBIOSOverTCPIP.IsEnabled = $False
}

#providing SMB1.0 status
if(Get-ADDSSMB -eq $true) {
    $cbDisableSMB.Content = "Disable SMB 1.0 (already disabled)"
    $cbDisableSMB.IsChecked = $False
    $cbDisableSMB.IsEnabled = $False
}

# display hardware summary row
# disabled during testing.. to avoid 3-4 seconds delay (taken by this function)
$dsui.FindName("lblHardwareInfo").Content = (Get-HardwareSummary)

# This line will appear at bottom to show the window. All code will come above
$dsui.ShowDialog() | out-null
