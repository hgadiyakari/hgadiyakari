﻿<#
.SYNOPSIS
This script is meant to automate the configuration of external time sync server on a domain controller.

.DESCRIPTION
This script is meant to automate the configuration of external time sync server on a domain controller. If a time server name is specified in the script parameter, it will be configured as the NTP server on the domain controller, along with several other supported registry settings.
The script configures the following registry settings under HKLM\SYSTEM\CurrentControlSet\Services\W32Time\ registry hive, to complete the external time sync server configuration:
Parameters\Type			            NTP		String
Config\AnnounceFlags			    5		DWord
TimeProviders\NtpServer\Enabled	    1		DWord
Parameters\NtpServer			    <Server>	String
Config\SpecialPollInterval		    3600		DWord
Config\MaxPosPhaseCorrection		172800		DWord
Config\MaxNegPhaseCorrection		172800		DWord
The script must be executed from an elevated PowerShell prompt. 

.PARAMETER TimeServerName
User must specify the name or IP address of the external time server to sync the AD time with. The script verifies the connectivity to the time server and presents an error if fails.

.PARAMETER ConfigureExternalTimeServer
This parameter must be specified to configure the time sync server. Without this parameter the script will not configure anything. This parameter is sort of a confirmation before actual implementation.

.EXAMPLE
.\ConfigureExternalTimeServer.ps1 -TimeServerName 192.168.10.113 -ConfigureExternalTimeServer

.NOTES
Write to Platform_Wintel_SOE@csc.com for more information on the script

.LINK

#>


param(
[string] $TimeServerName,
[switch] $ConfigureExternalTimeServer)


Function Test-DSTimeServer($TimeServerName)
{    
    #If time server name is blank; return false
    If($TimeServerName -eq "") 
    { 
        Write-Host "TimeServerName is not specified"
        Return $False
    }

    #checking if user provided time server can be reached to or not. Passing the result of te w32tm command into 
    #the $TimeServerCheck variable    
    #if time server name is not blank and Timeservercheck variable value contains Stratum:, return true else return false
    #      
    If($TimeServerName -ne "")
    {
        $TimeServerCheck = [String] $(W32tm /Monitor /Computers:$TimeServerName)
        If($TimeServerCheck.Contains("Stratum:") -eq $True)
        {
            Return $True
        }
        Else
        { 
            Write-Host "Invalid Time Server - Not able to connect to the specified time server, please validate the name/IP provided or the connectivity to the server." 
            Return $False 
        }
    }
}

Function Configure-DSExternalTimeServer($TimeServerName) {
    #Configuring External Time Server parameters
	try
    {
        Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Parameters" -Name Type -Value NTP -Type String
	    Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Config" -Name AnnounceFlags -Value 5 -Type DWord
	    Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\TimeProviders\NtpServer" -Name Enabled -Value 1 -Type DWord
	    Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Parameters" -Name NtpServer -Value "$TimeServerName,0x8" -Type String
	    Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Config" -Name SpecialPollInterval -Value 3600 -Type DWord
	    Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Config" -Name MaxPosPhaseCorrection -Value 172800 -Type DWord
	    Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Config" -Name MaxNegPhaseCorrection -Value 172800 -Type DWord
	    Write-Host "External Time Server parameters are configured in the registry; HKLM\SYSTEM\CurrentControlSet\Services\W32Time\"
    }
    catch
    {
        Write-Host "$($Error[0].exception.message)"
        Write-Host "External Time Server configuration failed."
    }
}

If($ConfigureExternalTimeServer)
{    
    If((Test-DSTimeServer -TimeServerName $TimeServerName) -eq $true)
    {
        Configure-DSExternalTimeServer -TimeServerName $TimeServerName
        Write-Host "DS External Time Server parameters are configured"
    }
    Else
    {
        Write-Host "DS External Time Server parameters are not configured"
    }
}
Else
{
    Write-Host "Please pass the -ConfigureExternalTimeServer parameter in the command to configure the External Time server on the DC"
}
