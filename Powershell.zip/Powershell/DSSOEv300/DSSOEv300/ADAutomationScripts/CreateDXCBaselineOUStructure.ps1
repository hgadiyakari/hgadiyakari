﻿<#
.SYNOPSIS
The purpose of this script is to create DXC Standard OU structure for Standard AD or Multi-tenant AD environment.

.DESCRIPTION
The purpose of this script is to create DXC Standard OU structure for Standard AD or Multi-tenant AD environment. This script also creates the standard groups (only in the case of # multi-tenant AD) and set up standard delegation on the newly created OUs (only in the case of multi-tenant AD). The OU structure will not be created for "AdditionalDC" build type.
Must run this script with an elevated command prompt. Refer to OU Framework Reference Architecture document on CSC docs for standard and multitenat OU structure details and figure. Refer to Global Device and Server naming standards on CSC docs for the list of DXC account codes.

.PARAMETER DCBuildType
The valid values for this parameter are - AdditionalDC | NewDomainNewForest | NewChildDomain | NewTreeDomain. Choose the value that best fits to the type of DC build scenario. It should be noted that the AD OU structure will not be created at all if the –DCBuildType parameter is set to AdditionalDC. Be extra cautious in specifying the value for DCBuildType parameter and only put the value that exactly matches the type of DC build being performed on the local Domain Controller.

.PARAMETER AccountType
The valid values for this parameter are – Standard | Multitenant. The Standard value must be chosen when you are building a regular in-house Active Directory environment and Multitenant value must be chosen in the case of hosting AD environment. In the case of Multitenant OU structure, along with the OU structure the scripts creates three security groups AllAccountUsers, AllResellerUsers & Role-D-3rdLine-Wintel and sets up the baseline AD delegation rights at the domain and OU level. The Role-D-3rdLine-Wintel group is meant for senior administrators and thus the script adds this group to the domain admins group.

.PARAMETER AccountCode
This parameter is meant for the 3 char code of the account the AD belongs to. For the list of all the DXC account codes refer to the latest Global Device and Server naming standards document. The account code must be exactly 3 character long and should only contains alpha-numeric chars.

.EXAMPLE
To create the standard AD OU structure for Zurich account (whose account code is ZUR), where the DC build type was NewTreeDomain
.\CreateDXCBaselineOUStructure.ps1 -DCBuildType NewTreeDomain -AccountType Standard -AccountCode ZUR

.EXAMPLE
To create the Multitenant AD OU structure for Royal Mail Group account (whose account code is RMG), where the DC build type was NewChildDomain
.\CreateDXCBaselineOUStructure.ps1 -DCBuildType NewChildDomain -AccountType Multitenant -AccountCode RMG

.NOTES
Write to Platform_Wintel_SOE@CSC.com for more information on the script

.LINK

#>


param(
[string][ValidateSet('AdditionalDC','NewDomainNewForest','NewChildDomain','NewTreeDomain')]$DCBuildType,
[string][ValidateSet('Standard','MultiTenant')]$AccountType,
[string]$AccountCode)

# This fuction is used in the Configure-DSCustomerOUStructure function for the creation
# of sub-OUs under OU=DXC,DC=domain,Dc=com
Function New-DXCOUStructure {
	#Creating OU's Under DXC
	$DXCOU = "OU=DXC," + (Get-ADDomain -Server $env:COMPUTERNAME).DistinguishedName
	New-ADOrganizationalUnit -Name Admins -Path $DXCOU -ProtectedFromAccidentalDeletion $true | Out-Null
	New-ADOrganizationalUnit -Name Workstations -Path $DXCOU -ProtectedFromAccidentalDeletion $true | Out-Null
	New-ADOrganizationalUnit -Name Groups -Path $DXCOU -ProtectedFromAccidentalDeletion $true | Out-Null
	New-ADOrganizationalUnit -Name Servers -Path $DXCOU -ProtectedFromAccidentalDeletion $true | Out-Null
	New-ADOrganizationalUnit -Name Users -Path $DXCOU -ProtectedFromAccidentalDeletion $true | Out-Null
}

# This function will remove security inheritence for given OU
Function Remove-DSOUInheritence($OUDistinguishedName) {
    $removeinheritance = [adsi]("LDAP://$OUDistinguishedName")
	$removeinheritance.psbase.get_objectsecurity().SetAccessRuleProtection($true, $true)
	$removeinheritance.psbase.CommitChanges()
}

#this function is to validate that -value parameter has only alphabets
function Test-Chars($value)
{
    # Matching the each character of the $Value against [a-z] regex. The loop will continue
    # until the value of $i is less than the length of the $Value parameter
    for($i=0;$i -lt $value.length;$i++)
    { 
        $Status = $value.chars($i) -match "[a-z]" 
        if ($Status -eq $false)
         {
            # if the above case does not match the value of $Status variable (i.e. False) will be returned
            return $Status
         }         
    }
}

#this function is to verify the accountcode
# 1. accountcode should be exactly 3 chars long
# 2. it should only contain chars
Function Test-AccountCode([string]$Code)
{
    If(($Code.Length -ne 3) -or ((Test-Chars -value $Code) -eq $false)) 
    {        
        Return $False
    }
    Else
    {        
        Return $True
    }
}

If((Test-AccountCode -Code $AccountCode) -eq $True)
{
    If($DCBuildType -ne "AdditionalDC")
    {
        #importing activedirectory module
        Import-Module activedirectory

        # Save DN of this DC in a variable for below function calls
        $thisDC = (Get-ADDomain -Server $env:COMPUTERNAME).DistinguishedName

        # Creation of DXC Individual Customer OU Structure for 'Standard' Account type
	    if($AccountType -eq 'Standard') 
        {		
		    # Creating Top level OU's
		    New-ADOrganizationalUnit -Name DXC -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null
		    New-ADOrganizationalUnit -Name Admins -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null
		    New-ADOrganizationalUnit -Name Groups -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null
		    New-ADOrganizationalUnit -Name Servers -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null
		    New-ADOrganizationalUnit -Name Workstations -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null
		    New-ADOrganizationalUnit -Name "Service Accounts" -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null
		    $WorkstationOU = "OU=Workstations,$thisDC"
            #VDI and MAC as sub-OUs under top-level workstations ou
		    New-ADOrganizationalUnit -Name VDI -Path $WorkstationOU -ProtectedFromAccidentalDeletion $true | Out-Null
		    New-ADOrganizationalUnit -Name MAC -Path $WorkstationOU -ProtectedFromAccidentalDeletion $true | Out-Null				
		    New-ADOrganizationalUnit -Name "$AccountCode Users" -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null
		    #calling function New-DXCOUStructure to create sub-ous under DXC OU
            New-DXCOUStructure

            Write-Host "DXC baseline 'standard' OU structure is created."
            Write-Host "Script execution is complete"
	    }

        # Creation of DXC Multi-Tenant OU Structure for 'MultiTenant' Account type
	    if ($AccountType -eq 'MultiTenant') 
        {	
		    #Changing AD Object Mode to List Object		
		    $Admode = [adsi]("LDAP://CN=Directory Service,CN=Windows NT,CN=Services,CN=Configuration," + $thisDC)
		    $Admode.dSHeuristics = "001"
		    $Admode.setinfo()
					
		    # Creating Top level OU's and set their inheritence to not to inherit from parent
		    New-ADOrganizationalUnit -Name DXC -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null 
            Remove-DSOUInheritence -OUDistinguishedName "ou=DXC,$thisDC"

		    New-ADOrganizationalUnit -Name Admins -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null
		    Remove-DSOUInheritence -OUDistinguishedName "ou=Admins,$thisDC"
	       	
		    New-ADOrganizationalUnit -Name Accounts -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null
		    Remove-DSOUInheritence -OUDistinguishedName "ou=Accounts,$thisDC"
	       	
		    New-ADOrganizationalUnit -Name Resellers -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null
		    Remove-DSOUInheritence -OUDistinguishedName "ou=Resellers,$thisDC"
	       	
		    New-ADOrganizationalUnit -Name Groups -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null
		    Remove-DSOUInheritence -OUDistinguishedName "ou=Groups,$thisDC"
	       	
		    New-ADOrganizationalUnit -Name Servers -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null
		    Remove-DSOUInheritence -OUDistinguishedName "ou=Servers,$thisDC"
	       	
		    New-ADOrganizationalUnit -Name Workstations -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null
		    Remove-DSOUInheritence -OUDistinguishedName "ou=Workstations,$thisDC"
	       	
            $WorkstationOU = "OU=Workstations,$thisDC"
		    New-ADOrganizationalUnit -Name VDI -Path $WorkstationOU -ProtectedFromAccidentalDeletion $true | Out-Null
	       	
		    New-ADOrganizationalUnit -Name MAC -Path $WorkstationOU -ProtectedFromAccidentalDeletion $true | Out-Null
	       	
		    New-ADOrganizationalUnit -Name "Service Accounts" -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null
		    Remove-DSOUInheritence -OUDistinguishedName "ou=Service Accounts,$thisDC"
	       	
		    New-ADOrganizationalUnit -Name "$AccountCode Users" -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null
		    Remove-DSOUInheritence -OUDistinguishedName "ou=$AccountCode Users,$thisDC"
	       	
		    # Call function to create DXC sub-ou structure		
		    New-DXCOUStructure
        
            Write-host "DXC baseline 'multitenant' OU structure is created."
					
		    #declaring variables
		    $AccountsOUDN = "OU=Accounts,$thisDC"
		    $ResellersOUDN = "OU=Resellers,$thisDC"			
								
		    #Group Creation        
		    $OUAdministrationRoles = "OU=Admins,$thisDC"
		    New-ADGroup -Path $AccountsOUDN -name AllAccountUsers -samAccountName AllAccountUsers -GroupCategory  "security" -groupscope "DomainLocal" | Out-Null
		    New-ADGroup -Path $ResellersOUDN -name AllResellerUsers -samAccountName AllResellerUsers -GroupCategory "security" -groupscope "DomainLocal" | Out-Null
		    New-ADGroup -Path $OUAdministrationRoles -name Role-D-3rdLine-Wintel -samAccountName Role-D-3rdLine-Wintel -GroupCategory "security" -groupscope "Global" | Out-Null
            Write-Host "AllAccountUsers, AllResellerUsers & Role-D-3rdLine-Wintel AD groups are created."
        
            #Adding Role-D-3rdLine-Wintel group to domain admins
		    $group = [adsi]("LDAP://cn=Domain Admins, cn=Users," + $thisDC)
		    $wintelgroup = [adsi]("LDAP://cn=Role-D-3rdLine-Wintel," + $OUAdministrationRoles)
		    $members = $group.member
		    $group.member = $members + $wintelgroup.distinguishedName
		    $group.setinfo()
            Write-host "Role-D-3rdLine-Wintel group is added to domain admins."
		    
            Write-Host "Setting up AD delegation on newly created OUs and groups."
            #ACL Changes    
            $AccountsOUDN = "OU=Accounts,$thisDC"
		    $AllAccountUsersSID = New-Object System.Security.Principal.SecurityIdentifier(Get-ADGroup "AllAccountUsers").SID
            $nullGUID = [guid]'00000000-0000-0000-0000-000000000000'                
            $AclAccountsOU = Get-Acl -Path "AD:\$AccountsOUDN"
            $RemoveAccountsOUACL = $AclAccountsOU.Access | Where-Object { $_.IdentityReference -eq "NT AUTHORITY\Authenticated Users" }        
            foreach($ADAccessRule in $RemoveAccountsOUACL){ $AclAccountsOU.RemoveAccessRule($ADAccessRule) }
            $AclAccountsOU.AddAccessRule((New-Object System.DirectoryServices.ActiveDirectoryAccessRule $AllAccountUsersSID,"ReadProperty,ListObject","Allow","None",$nullGUID))
            Set-Acl -AclObject $AclAccountsOU -Path "AD:\$AccountsOUDN"

            $ResellersOUDN = "OU=Resellers,$thisDC"
            $AllResellerUsersSID = New-Object System.Security.Principal.SecurityIdentifier(Get-ADGroup "AllResellerUsers").SID
            $nullGUID = [guid]'00000000-0000-0000-0000-000000000000'  
            $AclResellersOU = Get-Acl -Path "AD:\$ResellersOUDN"
            $RemoveResellersOUAcl = $AclResellersOU.Access | Where-Object {$_.IdentityReference -eq "NT AUTHORITY\Authenticated Users" }        
            foreach($ADAccessRule in $RemoveResellersOUAcl){ $AclResellersOU.RemoveAccessRule($ADAccessRule) }
            $AclResellersOU.AddAccessRule((New-Object System.DirectoryServices.ActiveDirectoryAccessRule $AllResellerUsersSID,"ReadProperty,ListObject","Allow","None",$nullGUID))
            Set-Acl -AclObject $AclResellersOU -Path "AD:\$ResellersOUDN"

            $AllAccountusers = "CN=AllAccountUsers,$AccountsOUDN"
            Remove-DSOUInheritence -OUDistinguishedName $AllAccountusers
            $AclAccountUsers = Get-Acl -Path "AD:\$AllAccountusers"
            $RemoveAccountUsersACL1 = $AclAccountUsers.Access | Where-Object { $_.IdentityReference -eq "NT AUTHORITY\Authenticated Users" }
            $RemoveAccountUsersACL2 = $AclAccountUsers.Access | Where-Object { $_.IdentityReference -eq "NT AUTHORITY\SELF" }
            foreach($ADAccessRule in $RemoveAccountUsersACL1){ $AclAccountUsers.RemoveAccessRule($ADAccessRule) }
            foreach($ADAccessRule in $RemoveAccountUsersACL2){ $AclAccountUsers.RemoveAccessRule($ADAccessRule) }
            Set-Acl -AclObject $AclAccountUsers -Path "AD:\$AllAccountusers"

            $AllResellerusers = "CN=AllResellerUsers,$ResellersOUDN"
            Remove-DSOUInheritence -OUDistinguishedName $AllResellerusers
            $AclResellerusers = Get-Acl -Path "AD:\$AllResellerusers"
            $RemoveResellerUsersACL1 = $AclResellerusers.Access | Where-Object { $_.IdentityReference -eq "NT AUTHORITY\Authenticated Users" }
            $RemoveResellerUsersACL2 = $AclResellerusers.Access | Where-Object { $_.IdentityReference -eq "NT AUTHORITY\SELF" }
            foreach($ADAccessRule in $RemoveResellerUsersACL1){ $AclResellerusers.RemoveAccessRule($ADAccessRule) }
            foreach($ADAccessRule in $RemoveResellerUsersACL2){ $AclResellerusers.RemoveAccessRule($ADAccessRule) }
            Set-Acl -AclObject $AclResellerusers -Path "AD:\$AllResellerusers"

            $Role3rdline = "CN=Role-D-3rdLine-Wintel,$OUAdministrationRoles"
            Remove-DSOUInheritence -OUDistinguishedName $Role3rdline
            $AclRole3rdline = Get-Acl -Path "AD:\$Role3rdline"
            $RemoveRole3rdLineAcl1 = $AclRole3rdline.Access | Where-Object { $_.IdentityReference -eq "NT AUTHORITY\Authenticated Users" }
            $RemoveRole3rdLineAcl2 = $AclRole3rdline.Access | Where-Object { $_.IdentityReference -eq "NT AUTHORITY\SELF" }
            foreach($ADAccessRule in $RemoveRole3rdLineAcl1) { $AclRole3rdline.RemoveAccessRule($ADAccessRule) }
            foreach($ADAccessRule in $RemoveRole3rdLineAcl2) { $AclRole3rdline.RemoveAccessRule($ADAccessRule) }
            Set-Acl -AclObject $AclRole3rdline -Path "AD:\$Role3rdline"

            Remove-DSOUInheritence -OUDistinguishedName "CN=Builtin,$thisDC"
            $BuiltinDN = "CN=Builtin,$thisDC"
            $BuiltinAcl = Get-Acl -Path "AD:\$BuiltinDN"
            $RemoveBuiltinAcl = $BuiltinAcl.Access | Where-Object { $_.IdentityReference -eq "NT AUTHORITY\Authenticated Users" }
            foreach($ADAccessRule in $RemoveBuiltinAcl) { $BuiltinAcl.RemoveAccessRule($ADAccessRule) }
            $acl6 = Set-Acl -AclObject $BuiltinAcl -Path "AD:\$BuiltinDN"

	        Remove-DSOUInheritence -OUDistinguishedName "CN=Computers,$thisDC"
            $ComputersDN = "CN=Computers,$thisDC"
            $ComputersACL = Get-Acl -Path "AD:\$ComputersDN"
            $RemoveComputersACL = $ComputersACL.Access | Where-Object { $_.IdentityReference -eq "NT AUTHORITY\Authenticated Users" }
            foreach($ADAccessRule in $RemoveComputersACL){ $ComputersACL.RemoveAccessRule($ADAccessRule) }
            Set-Acl -AclObject $ComputersACL -Path "AD:\$ComputersDN"
        
            Remove-DSOUInheritence -OUDistinguishedName "OU=Domain Controllers,$thisDC"
            $DCsOU = "OU=Domain Controllers,$thisDC"
            $DCsOUACL = Get-Acl -Path "AD:\$DCsOU"
            $RemoveDCsOUACL = $DCsOUACL.Access | Where-Object { $_.IdentityReference -eq "NT AUTHORITY\Authenticated Users" }
            foreach($ADAccessRule in $RemoveDCsOUACL) { $DCsOUACL.RemoveAccessRule($ADAccessRule) }
            Set-Acl -AclObject $DCsOUACL -Path "AD:\$DCsOU"

            Remove-DSOUInheritence -OUDistinguishedName "CN=Users,$thisDC"
            $UsersOU = "CN=Users,$thisDC"
            $UsersOUACL = Get-Acl -Path "AD:\$UsersOU"
            $RemoveUsersOUACL = $UsersOUACL.Access | Where-Object { $_.IdentityReference -eq "NT AUTHORITY\Authenticated Users" }
            foreach($ADAccessRule in $RemoveUsersOUACL) { $UsersOUACL.RemoveAccessRule($ADAccessRule) }
            Set-Acl -AclObject $UsersOUACL -Path "AD:\$UsersOU"
        
		    $DXCOU = "OU=DXC,$thisDC"		
            $DXCObjects = (Get-ADObject -SearchBase $DXCOU -Filter *).DistinguishedName
        
		    foreach ($DXCObject in $DXCObjects)
		    {
			    $WorkingOU = $DXCObject
                $WorkingOUAcl = Get-Acl -Path "AD:\$DXCObject"
                $RemoveWorkingOUAcl = $WorkingOUAcl.Access | Where-Object { $_.IdentityReference -eq "NT AUTHORITY\Authenticated Users" }
                foreach($ADAccessRule in $RemoveWorkingOUAcl){ $WorkingOUAcl.RemoveAccessRule($ADAccessRule) }
                Set-Acl -AclObject $WorkingOUAcl -path "AD:\$WorkingOU"
            }                

            $AdminsDN = "OU=Admins,$thisDC"
            $AdminsAcl = Get-Acl -Path "AD:\$AdminsDN"
            $RemoveAdminsACL = $AdminsAcl.Access | Where-Object { $_.IdentityReference -eq "NT AUTHORITY\Authenticated Users" }
            foreach($ADAccessRule in $RemoveAdminsACL) { $AdminsAcl.RemoveAccessRule($ADAccessRule) }
            Set-Acl -AclObject $AdminsAcl -Path "AD:\$AdminsDN"        

            $SrvAccountsDN = "OU=Service Accounts,$thisDC"
            $SrvAccountsAcl = Get-Acl -Path "AD:\$SrvAccountsDN"
            $RemoveSrvAccountsACL = $SrvAccountsAcl.Access | Where-Object { $_.IdentityReference -eq "NT AUTHORITY\Authenticated Users" }
            foreach($ADAccessRule in $RemoveSrvAccountsACL) { $SrvAccountsAcl.RemoveAccessRule($ADAccessRule) }
            Set-Acl -AclObject $SrvAccountsAcl -Path "AD:\$SrvAccountsDN"

            $WorkstationsOU = "OU=Workstations,$thisDC"
            $WorkstationsObjects = (Get-ADobject -SearchBase $WorkstationsOU -Filter *).DistinguishedName
            foreach($WorkstationsObject in $WorkstationsObjects) 
            {
                $WorkingOU = $WorkstationsObject
                $WorkingOUAcl = Get-Acl -Path "AD:\$WorkstationsObject"
                $RemoveWorkingOUAcl = $WorkingOUAcl.Access | Where-Object { $_.IdentityReference -eq "NT AUTHORITY\Authenticated Users" }
                foreach($ADAccessRule in $RemoveWorkingOUAcl){ $WorkingOUAcl.RemoveAccessRule($ADAccessRule) }
                Set-Acl -AclObject $WorkingOUAcl -Path "AD:\$WorkingOU"       
            }

            $ServersOU = "OU=Servers,$thisDC"
            $ServersACL = Get-Acl -Path "AD:\$ServersOU"
            $RemoveServersACL = $ServersACL.Access | Where-Object { $_.IdentityReference -eq "NT AUTHORITY\Authenticated Users" }
            foreach($ServerACL in $RemoveServersACL) { $ServersACL.RemoveAccessRule($ServerACL) }
            Set-Acl -AclObject $ServersACL -Path "AD:\$ServersOU"

            $GroupsOU = "OU=Groups,$thisDC"
            $GroupsACL = Get-Acl -Path "AD:\$GroupsOU"
            $RemoveGroupsACL = $GroupsACL.Access | Where-Object { $_.IdentityReference -eq "NT AUTHORITY\Authenticated Users" }
            foreach($GroupAcl in $RemoveGroupsACL) { $GroupsACL.RemoveAccessRule($GroupAcl) }
            Set-Acl -AclObject $GroupsACL -Path "AD:\$GroupsOU"

            $AcctUsersOU = "ou=$AccountCode Users,$thisDC"
            $AcctUsersACL = Get-Acl -Path "AD:\$AcctUsersOU"
            $RemoveAcctUsersACL = $AcctUsersACL.Access | Where-Object { $_.IdentityReference -eq "NT AUTHORITY\Authenticated Users" }
            foreach($ACL in $RemoveAcctUsersACL) { $AcctUsersACL.RemoveAccessRule($ACL) }
            Set-Acl -AclObject $AcctUsersACL -Path "AD:\$AcctUsersOU"

            Write-host "AD delegation on newly created OUs and groups is configured."
            Write-host "Script execution is complete."
        }
    }
    Else
    {
        Write-Host "As a standard practice DXC baseline OU structure is not created on an Additional Domain Controller."
        Write-Host "Script execution is complete. DXC baseline OU structure is not configured."
    }
}
Else
{
    Write-Host "Invalid OU Account Code - The account code should be exactly 3 character long and must contain alphabets only. For a list of all the DXC specific account codes refer to Global Device and Server Naming Standards document. Contact Platform_Wintel_SOE@csc.com for details."
    Write-Host "Script execution is complete. DXC baseline OU structure is not configured."
}