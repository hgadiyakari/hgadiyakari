﻿# Below is the help file of this script

<#
.SYNOPSIS
This script can be utilized for AD group reporting and group management to a certain extent.

.DESCRIPTION
The purpose of this script is:
1. To find all the groups without members
2. Enumerate members of a group
3. Enumerate groups of a user 
4. Add a member to multipe AD groups
Ensure appropriate privileges before executing this script. The script must be executed from an elevated PowerShell window.

.PARAMETER FindEmptyGroups
Specify this parameter to find all the groups without members

.PARAMETER EnumerateMembers
Specify this parameter to list our all the members of a group

.PARAMETER EnumerateGroups
Specify this parameter to list all the groups a member is part of

.PARAMETER AddMember
Specify this parameter to add members in a group

.PARAMETER GroupScope
This parameter is meant to be passed when searching for empty groups. The valid value for this parameter is Global, Universal, DomainLocal. 

.PARAMETER SearchBase
This parameter is meant to be passed when searching for empty groups. Specify the distinguished name of the target search base. For example, OU=Groups,DC=Contoso,DC=com

.PARAMETER GroupName
Specify the name of the group to add a member to or to enumerate the members of

.PARAMETER UserID
Specify the name of the user account to enumerate the groups of or to add the groups to

.EXAMPLE
To find the empty groups for 'Universal' scope and searchbase is OU=Groups,DC=Contoso,DC=com
.\groupmanagement.ps1 -FindEmptyGroups -GroupScope Universal -SearchBase 'OU=Groups,DC=Contoso,DC=com'

.EXAMPLE
To enumerate members of a group
.\groupmanagement.ps1 -EnumerateMembers -GroupName 'Domain Admins'

.EXAMPLE
To enumerate groups of a user account
.\groupmanagement.ps1 -EnumerateGroups -UserID 'myaccount'

.EXAMPLE
To add a member (myaccount) to a group (Domain Admins)
.\groupmanagement.ps1 -AddMember -GroupName 'Domain Admins' -UserID 'myaccount'

.EXAMPLE
To add multiple use acocunts to a group
.\groupmanagement.ps1 -AddMember -GroupName 'Domain Admins' -UserID 'myaccount,myaccount1,myaccount2'

.NOTES
Write to Platform_Wintel_SOE@csc.com for more information on the script

.LINK
Used the information in the link and optimized in this script - http://windowsitpro.com/powershell/top-10-active-directory-tasks-solved-powershell
#>

Param(
    [Parameter(ParameterSetName="FindEmptyGroups")][switch] $FindEmptyGroups,
    [Parameter(ParameterSetName="EnumerateMembers")][Switch] $EnumerateMembers,
    [Parameter(ParameterSetName="EnumerateGroups")][Switch] $EnumerateGroups,
    [Parameter(ParameterSetName="AddMember")][Switch] $AddMember,
    [Parameter(ParameterSetName="FindEmptyGroups")][ValidateSet('Global','Universal','DomainLocal')][String] $GroupScope,
    [Parameter(ParameterSetName="FindEmptyGroups")][String] $SearchBase,
    [Parameter(ParameterSetName="EnumerateMembers")][Parameter(ParameterSetName="AddMember")][String] $GroupName,
    [Parameter(ParameterSetName="EnumerateGroups")][Parameter(ParameterSetName="AddMember")][String]$UserID
)

#fn to find the empty groups
Function FindEmptyGroups($GroupScope,[string]$SearchBase) {
    Get-ADGroup -Filter ("members -notlike '*' -AND GroupScope -eq '$GroupScope'") -SearchBase $SearchBase | Select-Object Name,Group*
}

#fn to enumerate the members of a group
Function EnumerateMembers([string]$GroupName) {
    Get-ADGroupMember $GroupName -Recursive | Select-Object Name,DistinguishedName
}

#fn to enumerate groups of a member
Function EnumerateGroups([string]$Username) {
    Get-ADUser $Username -property MemberOf | Format-List Name,memberOf
}

#fn to add one / multiple user account in a group
Function AddMember([string]$GroupName,[string]$Username) {
    $SplitUsers = $Username.Split(',')
    Foreach($User in $SplitUsers) {
        Add-ADGroupMember $GroupName -Members $User
    }
}

If($FindEmptyGroups) {
    Write-Host "Calling funtion to find the empty groups of the specified group scope - $GroupScope and search base - $SearchBase"
    try {
        FindEmptyGroups -GroupScope $GroupScope -SearchBase $SearchBase
        #Write-Host "Script execution is successfully completed"
    }
    catch {
        Write-Host "An error occurred while searching for empty groups."
        Write-Host "$_.Exception.Message"
        return 'error_searching_emptygroups'
    }
}

If($EnumerateMembers) {
    Write-Host "Calling funtion to enumerate the members of the specified group - $GroupName"
    try {
        EnumerateMembers -GroupName $GroupName 
        #Write-Host "Script execution is successfully completed"
    }
    catch {
        Write-Host "An error occurred while enumerating the members."
        Write-Host "$_.Exception.Message"
        return 'error_enumerating_members'
    }
}

If($EnumerateGroups) {
    Write-Host "Calling funtion to enumerate the groups of the specified member - $UserID"
    try {
        EnumerateGroups -Username $UserID
        #Write-Host "Script execution is successfully completed"
    }
    catch {
        Write-Host "An error occurred while enumerating the groups."
        Write-Host "$_.Exception.Message"
        return 'error_enumerating_groups'
    }
}

If($AddMember) {
    Write-Host "Calling funtion to add the user id(s) - $UserID to specified group - $GroupName"
    try {
        AddMember -GroupName $GroupName -Username $UserID 
        #Write-Host "Script execution is successfully completed"
    }
    catch {
        Write-Host "An error occurred while adding the user id to group."
        Write-Host "$_.Exception.Message"
        return 'error_adding_userID_to_group'
    }
}
