﻿<#
.SYNOPSIS
This script is meant for creating a schedule for automated system state backup and automated backup maintenance.

.DESCRIPTION
The script configures a schedule to execute the system state backup of the domain controller at 10:00 pm (local time) daily. And if backup maintenance parameter is passed then the script will take care of the old backup files by deleting all the system state backups except the latest three versions. The backup maintenance task gets scheduled to execute at 9:00 pm daily. The script enables administrator to choose any of three available backup target locations i.e. Network share, Disk and Volume.
-Must run this script with an elevated command prompt. 
-Refer to the "AD Backup & Restore Operations Guide" document on cscdocs repository for information on different backup target locations.
-When BackupTargetLocation is NetworkShare, the script may fail with the below mentioned error message: 
    "A specified logon session does not exist. It may already have been terminated."
    The fix for this error message is to set the below mentioned policy to ‘disabled’.
    Computer Configuration \ Windows Settings\ Security Settings\ Local policies\ security options\ Network access: Do not allow storage of passwords and credentials for network authentication.

.PARAMETER BackupTargetLocation
This parameter is for specifying the target location for the system state backup. The valid values are Volume | NetworkShare | Disk. If any other value is specified then the script will fail. Administrator must choose the value for this parameter as per their target location requirements.

.PARAMETER BackupTargetPath
This parameter is for specifying the target path for the backup files. Administrators must specify a valid path. An invalid path will result in failed execution of the script.

.PARAMETER EnableBackupMaintenance
This parameter is to configure the schedule for the maintenance of the backed up files. The valid values for this option is true or false.

.EXAMPLE
To enable automated system state backup and maintenance with volume as the BackupTargetLocation and F: as the BackupTargetPath
.\SetDSBackup.ps1 -BackupTargetLocation Volume -BackupTargetPath F: -EnableBackupMaintenance 'true'

.EXAMPLE
To enable automated system state backup and maintenance with NetworkShare as the BackupTargetLocation and '\\Server1\BackupSharedFolder' as the BackupTargetPath
.\SetDSBackup.ps1 -BackupTargetLocation NetworkShare -BackupTargetPath '\\Server1\BackupSharedFolder' -EnableBackupMaintenance 'true'

.NOTES
Write to Platform_Wintel_SOE@csc.com for more information on the script

.LINK

#>



Param(
[string][ValidateSet('Disk','Volume','NetworkShare')]$BackupTargetLocation,
$BackupTargetPath,
[string][ValidateSet('True','False')]$EnableBackupMaintenance)


Function Set-DSBackupConfiguration(
[string]$BackupTarget,
$BackupPath,
[string]$EnableMaintenance) 
{
    If($BackupTarget -eq "Disk")
    {
        #installing the windows server backup role on the server
        Add-WindowsFeature Windows-Server-Backup | Out-Null
        #creating the SystemStateBackup key in the registry
        New-Item -Path HKLM:\SYSTEM\CurrentControlSet\Services\wbengine\SystemStateBackup  -Force | Out-Null
        #creating a new value under systemstatebackup key 
	    Set-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\wbengine\SystemStateBackup -Name AllowSSBToAnyVolume -Value 1 -Type DWord | Out-Null
			
	    try
        {
            # Creating Backup policy
            $policy = New-WBPolicy 
	        #scheduling system state backup to execute at 10:00 pm daily
            Set-WBSchedule –Policy $policy –Schedule 22:00 | Out-Null
            #setting the backup disk path
            $BackupTargetVolume = New-WBbackupTarget –Disk $BackupPath
	        Add-WBBackupTarget –Policy $policy –Target $BackupTargetVolume  | Out-Null
	        Add-WBSystemState –Policy $policy | Out-Null
	        Set-WBPolicy –Policy $policy | Out-Null	
            Write-Host "Domain Controller System State Backup Schedule is created to run at 10:00pm daily on the specified disk."
        }
        catch
        {
            Write-Host "$($Error[0].Exception.Message)"
            Write-Host "Use the Get-WBDisk cmdlet to fetch a list of disks on the server and then Select the one you want to use to store the backup in -BackupTargetPath parameter."
        }
    }

    If($BackupTarget -eq "Volume")
    {
        #installing the windows server backup role on the server
        Add-WindowsFeature Windows-Server-Backup | Out-Null
        #creating the SystemStateBackup key in the registry
        New-Item -Path HKLM:\SYSTEM\CurrentControlSet\Services\wbengine\SystemStateBackup  -Force | Out-Null
        #creating a new value under systemstatebackup key 
	    Set-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\wbengine\SystemStateBackup -Name AllowSSBToAnyVolume -Value 1 -Type DWord | Out-Null
			
	    try
        {
            # Creating Backup policy
            $policy = New-WBPolicy 
	        #scheduling system state backup to execute at 10:00 pm daily
            Set-WBSchedule –Policy $policy –Schedule 22:00 | Out-Null
            #setting the backup volume path
            $BackupTargetVolume = New-WBbackupTarget –VolumePath $BackupPath
	        Add-WBBackupTarget –Policy $policy –Target $BackupTargetVolume  | Out-Null
	        Add-WBSystemState –Policy $policy | Out-Null
	        Set-WBPolicy –Policy $policy | Out-Null	
            Write-Host "Domain Controller System State Backup Schedule is created to run at 10:00pm daily on the specified Volume Path."
        }
        catch
        {
            Write-Host "$($Error[0].Exception.Message)"
            Write-Host "Specify the Volume Drive letter as the -BackupTargetPath; for example F:"
        }
    }

    If($BackupTarget -eq "NetworkShare")
    {
        #installing the windows server backup role on the server
        Add-WindowsFeature Windows-Server-Backup | Out-Null
        #creating the SystemStateBackup key in the registry
        New-Item -Path HKLM:\SYSTEM\CurrentControlSet\Services\wbengine\SystemStateBackup  -Force | Out-Null
        #creating a new value under systemstatebackup key 
	    Set-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\wbengine\SystemStateBackup -Name AllowSSBToAnyVolume -Value 1 -Type DWord | Out-Null
			
	    try
        {
            # Creating Backup policy
            $policy = New-WBPolicy 
	        #scheduling system state backup to execute at 10:00 pm daily
            Set-WBSchedule –Policy $policy –Schedule 22:00 | Out-Null
            #setting the backup Network Share path
            $BackupTargetVolume = New-WBbackupTarget –NetworkPath $BackupPath -Credential (Get-Credential)
	        Add-WBBackupTarget –Policy $policy –Target $BackupTargetVolume  | Out-Null
	        Add-WBSystemState –Policy $policy | Out-Null
	        Set-WBPolicy –Policy $policy | Out-Null	
            Write-Host "Domain Controller System State Backup Schedule is created to run at 10:00pm daily on the specified Network Share path."
        }
        catch
        {
            Write-Host "$($Error[0].Exception.Message)"
            Write-Host "Specify the Network Share path as the -BackupTargetPath; for example \\Server_Name\Shared_Folder_Name and input the valid credentials, when prompted, to connect to the specified Network Share."
        }
    }

    # If user has selected to enable backup maintenance then configure it
	if($EnableMaintenance -eq "True") 
    {
		#Configuring DC System State Backup Maintenance scheduled task to delete all the system state backups except the latest 3 versions.
        #The job is scheduled to kick at 9:00 pm daily
		(schtasks.exe /create /sc DAILY  /TN "System State Backup Cleanup" /NP /F /TR "%windir%\System32\wbadmin.exe delete systemstatebackup -keepVersions:3" /ST 21:00) | Out-Null
        Write-Host "Backup Maintenance scheduled task is created to run at 9:00pm daily."
	}
	if($EnableMaintenance -eq "False")
	{
		Write-Host "Domain Controller System State Backup Maintenance task is chosen to be not configured."
    }
}

Set-DSBackupConfiguration -BackupTarget $BackupTargetLocation -BackupPath $BackupTargetPath -EnableMaintenance $EnableBackupMaintenance
Write-Host "DS Backup configuration is complete."

