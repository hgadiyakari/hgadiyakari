﻿# Below is the help file of this script

<#
.SYNOPSIS
This script can be utilized to fetch the drive space information for all the Domain Controllers in the specified domain

.DESCRIPTION
The purpose of this script is to fetch the drive space information for all the Domain Controllers in the specified domain
Ensure that a valid Domain DNS name must be specified. The script will fetch all the DCs in the specified domain and then list the drive information of each DC in a tabular format. 
Ensure appropriate privileges (enterprise admins rights) before executing this script. 
The script must be executed from an elevated PowerShell window.

.PARAMETER GetDCDriveSpaceInfo
Specify this [switch] parameter in order to execute the script. Without this parameter the script will not execute.

.PARAMETER Domain
Specify the Domain DNS name of the domain whose DC(s) drive space information are required to be fetched. For example 'contoso.com'.

.EXAMPLE
To list the drive space info of all the DCs in Myforest.local domain
.\DomainDriveSpaceInfo.ps1 -GetDCDriveSpaceInfo -Domain 'Myforest.local'

.NOTES
Write to Platform_Wintel_SOE@csc.com for more information on the script

.LINK

#>

param( [switch] $GetDCDriveSpaceInfo, [Parameter(Mandatory = $True)][string]$Domain)

Function Get-DCDriveSpaceInfo ([String]$Domain){    
    try {
        $DCs = ((Get-ADForest).domains | where { $_ -eq $Domain } | %{ Get-ADDomainController -Filter * -Server $_  } | select hostname)
        $DCList = $DCs.Hostname
        Write-Host "Successfully fetched the list of Domain Controllers in $Domain domain:`n$DCList"
    }
    catch {
        Write-Host "An error occurred while fetching the list of DCs in the specified domain - $Domain"
        Write-Host "$_.Exception.Message"
        return 'Error_Fetching_DC_List'
    }

    try {
        foreach($DC in $DCList) {
            Get-WmiObject -Class Win32_LogicalDisk -ComputerName $DC -Filter "DriveType=3" | `
            Format-Table SystemName, DeviceID,VolumeName,@{ Label="Total Size";Expression={$_.Size / 1gb -as [int]} },`
            @{ Label="Free Space";Expression={$_.FreeSpace / 1gb -as [int]} } -AutoSize
        }
    }
    catch {
        Write-Host "An error occurred while fetching the Drive Info for the listed DCs"
        Write-Host "$_.Exception.Message"
        return 'Error_Fetching_Drive_Info'
    }
}

Import-Module ActiveDirectory

If($GetDCDriveSpaceInfo) {
    If($Domain -eq "") {
        return "Please specify the domain name (-Domain parameter) whose DC(s) drive info needs to be fetched"    
    }
    Else {
        If(!($Domain -in ((Get-ADForest).Domains))) {
            Return "The specified domain name does not exists. Please verify and try again."
        }
        Else {
            Get-DCDriveSpaceInfo -Domain $Domain
        }
    }
}
Else {
    Write-Host "Please specify the -GetDCDriveSpaceInfo [Switch] parameter in order to run the script" 
}