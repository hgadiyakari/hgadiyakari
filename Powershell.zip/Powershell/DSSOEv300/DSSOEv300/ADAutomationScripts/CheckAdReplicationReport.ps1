
<#
.SYNOPSIS
This script can be utilized to fetch the forest-wide Active Directory replication report.

.DESCRIPTION
This script uses the output of the repadmin command (repadmin /showrepl) to check the AD replication on all the domain controllers and naming contexts all over an Active Directory forest and the output is saved to an html file.

.PARAMETER Filepath
Specify the folder path to store the AD replication report html file.

.EXAMPLE
To generate the forest-wide AD replication report and save it in C:\Share folder
.\CheckADReplicationReport.ps1 -Filepath 'C:\Share'

.NOTES
Write to Platform_Wintel_SOE@csc.com for more information on the script

.LINK

#>


#Parameter declaration for output
Param(
      #The target domain
      [parameter(Mandatory=$True)]
      [ValidateScript({Test-Path $_})]
      [String]$filepath
      )



 
$date = Get-Date -Format "yyyy-MM-dd-HH-mm-ss" 
$array = @()
 
 
 $html_head = "<style type='text/css'> 
table {font-family:verdana,arial,sans-serif;font-size:12px;color:#333333;border-width: 1px;border-color: #729ea5;border-collapse: collapse;} 
th {font-family:verdana,arial,sans-serif;font-size:12px;background-color:#acc8cc;border-width: 1px;padding: 8px;border-style: solid;border-color: #729ea5;text-align:left;} 
tr {font-family:verdana,arial,sans-serif;background-color:#d4e3e5;} 
td {font-family:verdana,arial,sans-serif;font-size:12px;border-width: 1px;padding: 8px;border-style: solid;border-color: #729ea5;} 
</style>"

$myForest = [System.DirectoryServices.ActiveDirectory.Forest]::GetCurrentForest() 
$dclist = $myforest.Sites | % { $_.Servers } 


 
foreach ($dcname in $dclist){ 
    $source_dc_fqdn = ($dcname.Name).tolower() 
    $ad_partition_list = repadmin /showrepl $source_dc_fqdn | select-string "dc=" 
    foreach ($ad_partition in $ad_partition_list) { 
        [Array]$NewArray=$NULL 
        $result = repadmin /showrepl $source_dc_fqdn $ad_partition 
        $result = $result | where { ([string]::IsNullOrEmpty(($result[$_]))) } 
        $index_array_dst = 0..($result.Count - 1) | Where { $result[$_] -like "*via RPC" } 
        foreach ($index in $index_array_dst){ 
            $dst_dc = ($result[$index]).trim() 
            $next_index = [array]::IndexOf($index_array_dst,$index) + 1 
            $next_index_msg = $index_array_dst[$next_index] 
            $msg = "" 
            if ($index -lt $index_array_dst[-1]){ 
                $last_index = $index_array_dst[$next_index] 
            } 
            else { 
                $last_index = $result.Count 
            } 
            
            for ($i=$index+1;$i -lt $last_index; $i++){ 
                if (($msg -eq "") -and ($result[$i])) { 
                    $msg += ($result[$i]).trim() 
                } 
                else { 
                    $msg += " / " + ($result[$i]).trim() 
                } 
            } 
            $Properties = @{source_dc=$source_dc_fqdn;NC=$ad_partition;destination_dc=$dst_dc;repl_status=$msg} 
            $Newobject = New-Object PSObject -Property $Properties 
            $array +=$newobject 
        } 
    } 
} 
 
$status_repl_ko = "<br><br><font face='Calibri' color='black'><i><b>Active Directory Replication Problem :</b></i><br>" 
$status_repl_ok = "<br><br><font face='Calibri' color='black'><i><b>Active Directory Replication OK :</b></i><br>" 
 
 
$message += $status_repl_ko 
 
if ($array | where {$_.repl_status -notlike "*successful*"}){ 
    $message += $array | where {$_.repl_status -notlike "*successful*"} | select source_dc,nc,destination_dc,repl_status |ConvertTo-Html -Head $html_head -Property source_dc,nc,destination_dc,repl_status 
} 
else { 
    $message += "<table style='color:gray;font-family:verdana,arial,sans-serif;font-size:11px;'>No problem detected</table>" 
} 
 
$message += $status_repl_ok 
$message += $array | where {$_.repl_status -like "*successful*"} | select source_dc,nc,destination_dc,repl_status |ConvertTo-Html -Head $html_head -Property source_dc,nc,destination_dc,repl_status 
$message | Out-File "$filepath\ad_repl_status_$date.html"

Write-Host "Output saved to $filepath\ad_repl_status_$date.html"