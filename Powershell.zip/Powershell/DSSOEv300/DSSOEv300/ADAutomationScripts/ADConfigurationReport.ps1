﻿
<#
.SYNOPSIS
Purpose of this script is to gather Active Directory configuration for inventory purposes.

.DESCRIPTION
Purpose of this script is to gather Active Directory configuration for inventory purposes. The script takes a file path as input from user, generates the inventory and saves the file in the user specified path. One must run this script from an elevated command prompt.

.PARAMETER ADConfigurationFilePath
Specify a valid File Path. The fetched information will be saved in the file path provided.

.EXAMPLE
To save the information in C:\Share\ADConfiguration.txt file, run the following command
.\ADConfigurationReport.ps1 -ADConfigurationFilePath 'C:\Share\ADConfiguration.txt'

.NOTES
Write to Platform_Wintel_SOE@csc.com for more information on the script

.LINK

#>


Param(
     #passing a commandline parameter to have the Path\Filename input by the user in string data type
     [string] $ADConfigurationFilePath
)   

#creating a function with ADConfigFilePath parameter
Function Save-ADServerConfig($ADConfigFilePath) 
{
	#importing the Active Directory to use the AD cmdlets
    Import-Module activedirectory

    #saving the domain info in a variable
    $DomainInfo = Get-ADDomain -Server ($env:COMPUTERNAME)
    $DCInfo = Get-ADDomainController -Identity ($env:COMPUTERNAME)
    #saving the network adapter parameters in a variable
	$IPdetails = (gwmi Win32_NetworkAdapterConfiguration | Where-Object { $_.IPAddress -ne $null })	
    $VolumeInfo = Get-WmiObject -Class win32_volume -ComputerName ($env:COMPUTERNAME)
    $ProcessorInfo = Get-WmiObject -Class win32_Processor -ComputerName ($env:COMPUTERNAME)
    $MemoryInfo = Get-WmiObject -Class win32_PhysicalMemory -ComputerName ($env:COMPUTERNAME)
    
    #string variable with the log file text
    $RecordAD = "
	Directory Services Server Configuration`n`r`n`r`n`r`n`r
    Build Date and Time        = $(Get-date)`n`r
    Domain DNS Name            = $($DomainInfo.DNSRoot)`n`r
    DistinguishedName          = $($DomainInfo.DistinguishedName)`n`r
    NetBIOSName                = $($DomainInfo.NetBIOSName)`n`r
    DomainControllersContainer = $($DomainInfo.DomainControllersContainer)`n`r
    Forest Domain Name         = $($DomainInfo.Forest)`n`r
    Parent Domain Name         = $($DomainInfo.ParentDomain)`n`r
    DomainMode                 = $($DomainInfo.DomainMode)`n`r
    Site Name                  = $($DCInfo.Site)`n`r
    IsGlobalCatalog            = $($DCInfo.IsGlobalCatalog)`n`r
    IsRODC                     = $($DCInfo.IsReadOnly)`n`r
    Domain Controller Name     = $(hostname)`n`r
    IPAddress                  = $($IPdetails.IPAddress)`n`r
    SubNet Mask                = $($IPdetails.IPSubnet)`n`r
    GateWay                    = $($IPdetails.DefaultIPGateway)`n`r
    DNS Address                = $($IPdetails.DNSServerSearchOrder)`n`r
    OperatingSystem            = $((Get-ADDomainController).OperatingSystem)`n`r
    OperatingSystemServicePack = $((Get-ADDomainController).OperatingSystemServicePack)`n`r
    OperationMasterRoles       = $((Get-ADDomainController).OperationMasterRoles)`n`r
    Database Path              = $((Get-ItemProperty -Path registry::HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\NTDS\Parameters -Name "DSA Working Directory")."DSA Working Directory")`n`r
    Log File Path              = $((Get-ItemProperty -Path registry::HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\NTDS\Parameters -Name "Database log files path")."Database log files path")`n`r
    Sysvol Path                = $((Get-ItemProperty -Path registry::HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\Netlogon\Parameters -Name "SysVol")."SysVol")`n`r
    Database file              = $((Get-ItemProperty -Path registry::HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\NTDS\Parameters -Name "DSA Database file")."DSA Database file")`n`r
    Volume Letter              = $($VolumeInfo.driveLetter)`n`r
    Volume Free Space          = $($VolumeInfo.freespace)`n`r
    Volume Capacity            = $($VolumeInfo.Capacity)`n`r
    Processor Cores            = $($ProcessorInfo.NumberOfCores)`n`r
    Processor Logical          = $($ProcessorInfo.NumberOfLogicalProcessors)`n`r
    Processor Make             = $($ProcessorInfo.Manufacturer)`n`r
    Memory Capacity            = $($MemoryInfo.Capacity)`n`r"
    
    #creating the file (path\filename), taking the input to the new-item command from the function parameter $ADConfigFilePath
    New-Item $ADConfigFilePath -type file -force | Out-Null
    #set the string text from the $recordAD variable to the newly created file
    Set-Content -Path $ADConfigFilePath $RecordAD

    #writing the output on the console
	Write-Host "Acitve Directory configuration is saved in the Text File: $ADConfigFilePath"
}
#calling the function with parameter value taken as a user input via $ADconfigurationfilepath command line parameter
Save-ADServerConfig -ADConfigFilePath $ADConfigurationFilePath


