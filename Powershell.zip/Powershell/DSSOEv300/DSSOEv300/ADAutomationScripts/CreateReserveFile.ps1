﻿<#
.SYNOPSIS
If administrators need a script to configure reserve file on Servers, they can use this script. Purpose of this script is to create a reserve file with user specified size (in MB). 

.DESCRIPTION
If administrators need a script to configure reserve file on Servers, they can use this script. Purpose of this script is to create a reserve file with user specified size (in MB). The reserve file can be used to recover space on the server, by deleting it, in a low disk space situation. 
The script makes sure the following conditions are met before the creation of reserve file:
- Specified reserve file path is valid or not
- Reserve file is not less than 250MB, throws a message if it did and terminates the script
- Specified reserve file size is an integer value, throws a message if it is not and terminates the script
- Specified reserve file size is not greater than 20% of the logical disk space available on the partition
The script must be executed from an elevated PowerShell prompt. 

.PARAMETER ReserveFilePath
Path of the reserve file which is to be created. An example of the valid value is C:\Reserve\ReserveFile.res.

.PARAMETER SizeInMB
The valid value of this parameter is an integer value. A non-integer value will result in the termination of the script.

.PARAMETER CreateReserveFile
This parameter must be passed as a confirmation for the actual implementation of the reserve file. If this parameter is not passed the script will not execute.

.EXAMPLE
In order to create a reserve file, reservefile.res, of 1 GB (1024 MB) in C:\Share\Reserve folder
.\CreateReserveFile.ps1 -ReserveFilePath C:\Share\Reserve\ReserveFile.res -SizeInMB 1024 -CreateReserveFile

.NOTES
Write to Platform_Wintel_SOE@csc.com for more information on the script

.LINK

#>
Param(
[string] $ReserveFilePath,
[int] $SizeInMB,
[switch] $CreateReserveFile)

# Function to test the validity of the user provided file path
Function Test-InvalidPath 
{
    param([string] $path)

    try
    {
        #trying to write 'test' to the file specified by the user 
        out-file -FilePath $path -InputObject 'test' -ErrorAction Stop
        #if the above command is successful it means that the path specified is correct
        Remove-Item -Path $path
        Return $True
    }
    Catch
    {
        #if commands in the try block fails, the catch block will execute
        #"errors occured"   
        Write-Host "Invalid Reserve File Path - $($error[0].exception.message)"
        return $false
    }
}

#Function to test the validity of the user provided reserver file options. Function will
# return $true or $false.
Function Test-DSConfigReserveFile ([string] $ReserveFilePath,[string] $SizeInMB)
{
    #if the user provided path is invalid, the error message will be returned
    If((Test-InvalidPath -path $ReserveFilePath) -eq $false) 
    {
        return $false
    }

    #checking if value provided in $sizeinmb parameter is an interger value or not
    If ([int]::TryParse($SizeInMB,[ref]$null) -eq $False) 
    {
        Write-Host "Invalid Reserve File Value - Please enter a valid value for SizeInMB (Numeric Integer value)"
        Return $False
    }

    #splitting the user provided reservefilepath value to retrieve the drive letter
    $ReserveFileDrive = ($ReserveFilePath.Split(":"))[0]
    #getting the free disk space on the identified partition in MBs
    $FreeSpace = (Get-PSDrive $ReserveFileDrive).Free / 1024KB

    #using invoke-expression to convert the string into expression. The reserve file size should not be less than 250 mb.
    #logic can be changed to - if($sizeInMB -lt 250) { code }
    If ((Invoke-Expression "${SizeInMB}mb/1024kb") -lt 250) 
    { 
        Write-Host "Invalid Reserve File Size - Reserve file should not be less than 250mb in size"
        return $false 
    }
    
    #the reserver file size should not be greater than 20% of the disk space available on the partion
    If ((Invoke-Expression "${SizeInMB}mb/1024kb") -gt ($FreeSpace/5)) 
    { 
        Write-Host "Invalid Reserve File Size - Reserve file size should not be greater than 20% of the logical disk space available on the partition."
        return $False 
    }
    Else { Return $true }
}


Function Create-DSReserveFile ($FilePath, $FileSize)
{
    # create a new reserve file with given size
    try {	    
        $file = new-object System.IO.FileStream $FilePath, Create, ReadWrite
	    $file.SetLength($FileSize*1MB)
	    $file.Close()
	    Write-Host "Reserve File created with given size: $FileSize MB"
    }
    catch { # something went wrong with creation of reserve file
        Write-Host "Error while creating reserve file."
        Write-Host "$($_.Exception.Message)"
    }
}
 
 #this block only executes when -createreservefile switch parameter is passed in the command
 If($CreateReserveFile)
 {
     #passing the result of the test-dsconfigreservefile function to a variable
     $TestDSConfigReserveFile = Test-DSConfigReserveFile -ReserveFilePath $ReserveFilePath -SizeInMB $SizeInMB
     If($TestDSConfigReserveFile -eq $true)
     {
        #if validation is $true then call the create-dsreservefile function to create the reserve file
        Create-DSReserveFile -FilePath $ReserveFilePath -FileSize $SizeInMB
        Write-Host "Reserve file creation script processing is finished"
     }
     Else
     {
        Write-Host "Reserve File did not get created; script processing finished"
     }
 }
 Else
 {
    Write-Host "Please pass the -CreateReserveFile parameter in the command to create the reserve file"
 }


