
<#
.SYNOPSIS
This script backup all the GPOs and save it to the specified folder name.

.DESCRIPTION
This script backup all the GPOs and save it to the specified folder name. If the specified folder does not exist then the script will create it automatically.
The script must be executed from an elevated PowerShell window.

.PARAMETER GPOBackupPath
This is a mandatory parameter of the script. Specify the valid folder path where you want to save the GPO backup files (GUID Folders).

.PARAMETER TakeGPOBackup
Specify this parameter to execute the processing of GPO backup. Without specifying this parameter the script won't run.

.EXAMPLE
To save the backup of all the GPOs in the current domain to D:\Backup\AllGPOBackup folder
.\AllGPOBackup.ps1 -GPOBackupPath 'D:\Backup\AllGPOBackup -TakeGPOBackup

.NOTES
Write to Platform_Wintel_SOE@csc.com for more information on the script

.LINK

#>

Param([Parameter(Mandatory=$true)][string]$GPOBackupPath,
    [switch]$TakeGPOBackup)

Function GPOBackup($Path) {
    Import-Module grouppolicy
    If(!(Test-Path -Path $Path)) {
        try {
            Write-Host "The specified folder folder does not exist. Creating the specified folder - $Path"
            New-Item -ItemType Directory -Path $Path -ErrorAction Stop
            Write-Host "The specified folder path is created - $Path"            
        }
        Catch {
            Write-Host "An error occurred while creating the $path folder."
            Write-Host "$_.Exception.Message"
            Return 'Script terminated'
        }
    }

    Backup-GPO -All -Path $Path
}

If($TakeGPOBackup) {
    Write-Host "Initiating backup of all GPOs"
    GPOBackup -Path $GPOBackupPath
    Write-Host "GPO backup is complete"
}
Else {
    return 'Please specify the -TakeGPOBackup switch parameter in order to proess the backup of all the GPOs.'
}

