﻿<#
.SYNOPSIS
Purpose of this script is to set page file as per the Platform_Wintel_SOE and CSC standards

.DESCRIPTION
Purpose of this script is to set page file. As a best practice this script should be executed before directory services promotion. The script disables the automatic management of pagefile and configures the initial size of pagefile to RAM + 300 MB & maximum size to RAM * 1.5. If the server has 3 physical disks on the server and 3 partitions i.e. C, D, E, then the pagefile.sys gets created on the root of E:\ drive, else the pagefile.sys gets created on the root of C:\ drive. The script must be executed from an elevated PowerShell prompt. 

.PARAMETER ConfigurePageFile
This switch parameter is required in order for script to run and configure the pagefile. If this parameter is not passed, the script will not execute. This parameter is sort of a confirmation before actual implementation.

.EXAMPLE
.\ConfigureDSPageFile.ps1 -ConfigurePageFile

.NOTES
Write to Platform_Wintel_SOE@csc.com for more information on the script

.LINK

#>
 Purpose of this script is to set page file as per the standards
# This script is tested on Windows Server 2008 R2, Windows Server 2012 and Windows Server 2012 R2 only
# Must run this script with an elevated command prompt
# To run the script run the following command on the powershell prompt
#    .\<ScriptName>.ps1 -ConfigurePageFile

# If -ConfigurePageFile switch parameter is not passed in the commandline then the Set-DSPageFile function will not execute

param([switch] $ConfigurePageFile)

Function Set-DSPageFile 
{
    $ntdsRegPath = 'HKLM:\SYSTEM\CurrentControlSet\Services\NTDS\Parameters'
    #retrieving the path to the Active Directory database
    $ADDrive = (Get-ItemProperty $ntdsRegPath -Name 'DSA Database File').'DSA Database file'
	
    # get a list of physical disks for query
    $ntdsdrivecheck = [string] $(wmic diskdrive get deviceid)
	
    # turn off automatic pagefile management by OS
    $(wmic computersystem set AutomaticManagedPagefile=False)
	
    # Get total visible memory for the purpose of setting pagefile
    $RAM = Get-WmiObject Win32_OperatingSystem | select TotalVisibleMemorySize
	$RAM = ($RAM.TotalVisibleMemorySize / 1kb).tostring("F00")

    # check if server has multiple disks and AD Database is installed to E drive
	if ((($ntdsdrivecheck.Contains("PHYSICALDRIVE2")) -eq $true) -and ($ADDrive[0] -eq "e"))
	{
         # get reference to the page file and put the output in a varible
        $PageFile = Get-WmiObject Win32_PageFileSetting | Where-Object {$_.name -eq "E:\pagefile.sys"}
        #if the output is $null then create the pagefile and set the configuration, else update the 
        #existing pagefile on E drive
        If($PageFile -eq $null)
        {
            # create pagefile on E:\
		    $(wmic.exe pagefileset create name="E:\pagefile.sys")
		
            # get reference to created page file and set its initial/max size
            $PageFile = Get-WmiObject Win32_PageFileSetting | Where-Object {$_.name -eq "E:\pagefile.sys"}
		    $PageFile.InitialSize = [int]$RAM + 300
		    $PageFile.MaximumSize = [int]$RAM * 1.5
		    $PageFile.Put() | Out-Null
            Write-Host ("PageFile configuration is complete, File E:\pagefile.sys" + " Initial =" +$PageFile.InitialSize + " Max =" + $PageFile.MaximumSize)
        }
        Else
        {
            $PageFile = Get-WmiObject Win32_PageFileSetting | Where-Object {$_.name -eq "E:\pagefile.sys"}
            $PageFile.InitialSize = [int]$RAM + 300
		    $PageFile.MaximumSize = [int]$RAM * 1.5
		    $PageFile.Put() | Out-Null
            Write-Host ("PageFile configuration is complete, File E:\pagefile.sys" + " Initial =" +$PageFile.InitialSize + " Max =" + $PageFile.MaximumSize)
        }

        # delete existing old pagefile
		$PageFile = Get-WmiObject Win32_PageFileSetting | Where-Object {$_.name -eq "C:\pagefile.sys"}
		$PageFile.delete()		
	}
	else 
    {
        # Server doesn't have CSC standard disk partitions, set pagefile on C:\
        # get reference to the page file if exists and put the output in a varible		        
        $PageFile = Get-WmiObject Win32_PageFileSetting | Where-Object {$_.name -eq "C:\pagefile.sys"}
        #if the output is $null then create the pagefile and set the configuration, else update the 
        #existing pagefile on C drive
        If($PageFile -eq $null)
        {
            # Create pagefile in C:\
            $(wmic.exe pagefileset create name="C:\pagefile.sys")
            # get reference to created page file and set its initial/max size
            $PageFile = Get-WmiObject Win32_PageFileSetting | Where-Object {$_.name -eq "C:\pagefile.sys"}
		    $PageFile.InitialSize = [int]$RAM + 300
		    $PageFile.MaximumSize = [int]$RAM * 1.5
		    $PageFile.Put() | Out-Null

            Write-Host ("PageFile configuration is complete, File C:\pagefile.sys" + " Initial =" +$PageFile.InitialSize + " Max =" + $PageFile.MaximumSize)
        }
        Else
        {
            $PageFile = Get-WmiObject Win32_PageFileSetting | Where-Object {$_.name -eq "C:\pagefile.sys"}
            $PageFile.InitialSize = [int]$RAM + 300
		    $PageFile.MaximumSize = [int]$RAM * 1.5
		    $PageFile.Put() | Out-Null

            Write-Host ("PageFile configuration is complete, File C:\pagefile.sys" + " Initial =" +$PageFile.InitialSize + " Max =" + $PageFile.MaximumSize)
        }
	 }
}

#if switch parameter is passed in the command then call the set-dspagefile function and set the page file
If($ConfigurePageFile)
{
    Set-DSPageFile
}
Else
{
    Write-Host "Please pass the -ConfigurePageFile parameter in the command to configure the page file"
}

