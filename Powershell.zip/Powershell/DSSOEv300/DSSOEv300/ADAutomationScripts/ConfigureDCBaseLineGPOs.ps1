﻿#requires -version 5.0

<#
.SYNOPSIS
Purpose of this script is to create and then import the DXC standard GPO settings for Domain Policy and Domain Controller Policy

.DESCRIPTION
-Purpose of this script is to create and then import the DXC standard GPO settings for Domain Policy and Domain Controller Policy.
-The GPOs will only get created when the -DCBuildType parameter is not AdditionalDC.
-The GPOs will not get created if the -DCBuildType parameter is AdditonalDC.
-The DomainPolicy and DomainController Policy will only get created if -ConfigureDomainPolicy and -ConfigureDomainControllerPolicy parameters are passed, respecitvely.
-The following files / folders are a must on the scriptroot folder (i.e. the folder where is script is being kept) for the successful execution of the script.
-If any of the files & Folders mentioned below is missing, the script will fail. These files can be found in the DSSOE package folder.
               
              - Security Policies (Folder)
              - Config\MSS-legacy.adml (File in Config Folder)
              - Config\MSS-legacy.admx (File in Config Folder)

-Must run this script with an elevated command prompt
-This script is meant for Windows Server 2016 DCs

.PARAMETER DCBuildType
Specify the DC build type i.e. NewDomainNewForest, NewChildDomain, NewTreeDomain, AdditionalDC. Based on the value of this parameter the GPOs will be or will not be created. This is a mandatory parameter without which the script will not execute. The GPOs will not be created if DCBuildType is AdditionalDC

.PARAMETER ConfigureDomainPolicy
Specify this parameter to create the standard baseline domain policy

.PARAMETER ConfigureDomainControllerPolicy
Specify this parameter to create the standard baseline domain controller policy

.EXAMPLE
To configure the domain policy and domain controller policy when the DC build type is NewChildDomain
.\ConfigureDCBaselineGPOs.ps1 -DCBuildType NewChildDomain -ConfigureDomainPolicy -ConfigureDomainControllerPolicy

.EXAMPLE
To configure the domain policy only when the DC build type is NewTreeDomain
.\ConfigureDCBaselineGPOs.ps1 -DCBuildType NewTreeDomain -ConfigureDomainPolicy

.NOTES
Write to Platform_Wintel_SOE@csc.com for more information on the script

.LINK
#>


Param(
[String][ValidateSet('AdditionalDC','NewDomainNewForest','NewChildDomain','NewTreeDomain')][Parameter(Mandatory = $True)]$DCBuildType,
[switch] $ConfigureDomainPolicy,
[switch] $ConfigureDomainControllerPolicy)


If($DCBuildType -ne "AdditionalDC")
{
    <##Creation of GPO for DXC Standard default domain policy and default domain controllers policy
    Invoke-Command {cmd /c c: "&" cd $PSScriptRoot "&" cscript localgpo.wsf /ConfigSCE}#>

    Write-Host "Revealing MSS GPO settings"
    Write-Host "Copying the MSS-Legacy.admx and MSS-Legacy.adml files to $env:SystemRoot\PolicyDefinitions folder."
    Try {
        Copy-Item -Path "$PSScriptRoot\..\Config\MSS-legacy.admx" -Destination "$env:SystemRoot\PolicyDefinitions" -Force
        Copy-Item -Path "$PSScriptRoot\..\Config\MSS-legacy.adml" -Destination "$env:SystemRoot\PolicyDefinitions\en-US" -Force
        Write-Host "Files copied successfully"
    }
    Catch {
        Write-Host "An error occurred while copying the MSS files: $($error[0].exception.message)"
    }
    
	# Store GPO Backup Path in a variable
	$GPOBackupPath = "$PSScriptRoot\Security Policies"
    If($ConfigureDomainPolicy)
    {
		$gpOut = new-gpo -name DO-B-DXCBaselineDomainPolicy -Domain (Get-ADDomain -Server $(hostname)).dnsroot | new-gplink -target ((Get-ADDomain -Server $(hostname)).DistinguishedName) -Order 1 -Domain (Get-ADDomain -Server $(hostname)).dnsroot	
        Write-Host "$gpOut"
		$gpOut = import-gpo -BackupId EC56A14A-A314-472B-8591-9ABF7F8B93EF -TargetName DO-B-DXCBaselineDomainPolicy -path $GPOBackupPath
		Write-Host "$gpOut"
        $gpout = (gpupdate /force /boot)
        Write-Host "$gpOut"
        Write-Host "GPO for DXC Standard default domain policy has been created and applied"
    }
    Else
    {
        Write-Host "Creation of GPO for DXC Standard default domain policy is not selected"
    }

    If($ConfigureDomainControllerPolicy)
    {
        $gpOut = new-gpo -name OU-B-DXCBaselineDomainControllerPolicy -Domain (Get-ADDomain -Server $(hostname)).dnsroot | new-gplink -target ((Get-ADDomain -Server $(hostname)).domaincontrollerscontainer) -Order 1 -Domain (Get-ADDomain -Server $(hostname)).dnsroot
        Write-Host "$gpOut"
        $gpOut = import-gpo -BackupId 60913860-13F2-4BD3-948D-888901BC4BAD -TargetName OU-B-DXCBaselineDomainControllerPolicy -path $GPOBackupPath
        Write-Host "$gpOut"
        $gpOut = (gpupdate /force /boot)
        Write-Host "GPO for DXC Standard default domain controller policy has been created and applied"
    }
    Else
    {
		Write-Host "Creation of GPO for DXC Standard default domain controller policy is not selected"
    }    
}
Else
{
    Write-Host "As an industry best practice DXC standard GPOs should not be created on the Additional Domain Controller as the standard baseline GPOs configure over 500 security settings and there are fair changes of a conflict in a domain that is already built and may be having its own GPOs."
}
