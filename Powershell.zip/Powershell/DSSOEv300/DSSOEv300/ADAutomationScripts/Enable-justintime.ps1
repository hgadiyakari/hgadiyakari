﻿
<#
.SYNOPSIS
    The Purpose of this Script to Enable JIT(Just In Time)
    Grants time-bound membership of specific high-privileged groups on a per-user basis upto 100hrs
     
.DESCRIPTION
    Grants temporary membership of groups to a user, 
    identified by their distinguished name, in the same domain.

    Uses a nested, dynamic group object to ensure that membership of the high privileged group is
    automatically removed after a period of time, specified in hours. The dynamic group has a TTL. The 
    user is added to the dynamic group and the dynamic group is nested in the high privileged group.

    After adding the user to high priviliged group for certain time period. The user can perform
    the action what highpriviliged group members can perform.After the expiry of the time limit
    the user will automatically remove from that group
 

    PREREQUISTIES
    Server should Require minimum Powershell version 4.0
    Server should have ActiveDirectory installed.
    This script can execute only domain admins. 

.EXAMPLE
    Set-ADUserJitAdmin -Userlogonname "John"
                       -Domain "halo.net"
                       -GroupName "Domain Admins"
                       -TtlHours 10
                       
    Adds the 'John' user account to a dynamic group that is then nested in the Domain Admins
    group of the halo.net domain. The dynamic group is given a TTL of 10 hours. After this time, AD removes
    the group, thereby removing privileged access. 
    
    

.EXAMPLE
    Set-ADUserJitAdmin -Userlogonname "Mike"
                       -Domain "halo.net"
                       -GroupName "Schema Admins"
                       -TtlHours 12
                       

    Adds the 'Mike' user account to a dynamic group that is then nested in the Schema Admins
    group of the halo.net domain. The dynamic group is given a TTL of 12 hours. After this time, AD removes the group, thereby removing 
    privileged access. 

.EXAMPLE
    Set-ADUserJitAdmin -Userlogonname "johnson"
                       -Domain "halo.net"
                       -GroupName "Enterprise Admins"
                       -TtlHours 2 
    
    Adds the 'johnson' user account to a dynamic group that is then nested in the Enterprise Admins
    group of the halo.net domain. The dynamic group is given a TTL of 2 hours.   After this time, AD removes the group, thereby removing 
    privileged access. The Authentication Policy is also deleted.


.PARAMETER Userlogonname
    Specify the userlogon name of the user which you want to add to CertainGroup. Then this user will add be added to group  which your mentioning in group name for a 
    period of time. The user name should be the user logon name(which is using when log in to the domain).
    Ex: -userlogonname pwsuser

.PARAMETER Domain
    Specify the Domain name of the user which you want to add to CertainGroup. The username which is giving in the userlogonname paramter should be in this domain.
    Then the user in this domain will be added to a group.
    Ex: -Domain pws.local
    Ex: -Domain myforest.local

.PARAMETER GroupName
    Specify the Group name in the domain to add the user in this group. Then the user will be added to this group foe the certain amount of time period, which we mentioning
    in the TtlHours parameter.
    Ex: -Groupname "Domain Admins"
    Ex: -Groupname "DNSAdmins"
.PARAMETER TtlHours
    Specify the time limit from (1 to 100Hrs) in this parameter. Then the user will be added to group for certain amount time of time. If the value this prameter is 1 then the user
    will be in group for one hour only. After one hour the user will automatically remove from that group.
    Ex: -TtlHours 1
    Ex: -TtlHours 48

.LINK
https://gallery.technet.microsoft.com/scriptcenter/Set-ADUserJitAdmin-b8bb1f47
.NOTES
This script is tested on Windows Server 2012R2 and Windows Server 2016.

#>


#Requires -version 4
#Requires -modules ActiveDirectory


    #Define and validate parameters
  [CmdletBinding()]
  Param(
          #The distinguished name of the user to be granted high privileged group membership
          [parameter(Mandatory,Position=1)]
          [ValidateScript({Get-ADUser -Identity $_})]
          [String]$Userlogonname,

          #Confirmation of the current domain
          [parameter(Mandatory,Position=2)]
          [ValidateScript({Get-ADDomain -Identity $_})]
          [String]$Domain,

          #The high privileged group the use will be a member of
          [parameter(Mandatory,Position=3)]
          [ValidateScript({Get-ADGroup -Identity $_})]
          [String]$GroupName,

          #The amount of time, in hours, that the user is granted privileged access
          [parameter(Mandatory,Position=4)]
          [ValidateRange(1,100)]
          [Single]$TtlHours
 )


Function Set-ADUserJitAdmin {

    #Get the sAMAccountName of our user
    $UserSamAccountName = ((Get-ADUser -Identity $Userlogonname).SamAccountName).ToUpper()
    Write-Verbose -Message "Getting the  SAM Account name of the user $UserSamAccountName " -Verbose

    #Create the temporary dynamic group name
    $DynamicGroupName = "Dynamic Group - $UserSamAccountName"
    Write-Verbose -Message "Created the Temporary Dynamic group name $DynamicGroupName " -Verbose

    #Get the domain distingusihed name
    $DomainDn = (Get-ADDomain -Identity $Domain).DistinguishedName
    Write-Verbose -Message "Getting the Domain distingusihed name $DomainDn " -Verbose

    #Construct an distinguished name for the Users container
    $UsersContainerDn = "CN=Users,$DomainDn"
    Write-Verbose -Message "Constructing an distinguished name for the Users container $UsersContainerDn " -Verbose

    #Get a System.DirectoryServices.DirectoryEntry object representing the Users container
    $UsersContainer = [ADSI]("LDAP://$UsersContainerDn")

    #Check that we have the object representing the Users container
    if ($UsersContainer) {


        #######################
        ##CREATE DYNAMIC GROUP
        Write-Verbose -Message "Checking whether user had already member of dynamic group or not" -Verbose
        if(((Test-Group -Group "Dynamic Group - $Userlogonname") -ne ($true)) -and ((Test-Membership -groupmember $GroupName) -ne ($true))) 
       {     
        Write-Verbose -Message "Creating dynamic group for $Userlogonname" -Verbose

        #Use the Users container object to create the temporary dynamic group
        $DynamicGroup = $UsersContainer.Create("group","CN=$DynamicGroupName") 
        $DynamicGroup.PutEx(2,"objectClass",@("dynamicObject","group"))
        Write-Verbose -Message "Creating time limit for this group $TtlHours" -Verbose  
        $DynamicGroup.Put("msDS-Entry-Time-To-Die",[datetime]::UtcNow.AddHours($TtlHours))
        $DynamicGroup.Put("sAMAccountName",$DynamicGroupName)  
        $DynamicGroup.Put("displayName",$DynamicGroupName)
        Write-Verbose -Message "Adding description to this Dynamic group" -Verbose  
        $DynamicGroup.Put("description","Temporary group to grant time-bound membership of `'$GroupName`' to `'$UserSamAccountName`'")  
        $DynamicGroup.SetInfo() 

    ##TARGET USER TO DYNAMIC GROUP

    #Add our user to the new dynamic group
    Write-Verbose -Message "Adding  $Userlogonname to temporary Dynamic Group" -Verbose
    Add-ADGroupMember -Identity "CN=$DynamicGroupName,$UsersContainerDn" -Members $Userlogonname -ErrorAction SilentlyContinue

    #Check that Add-ADGroupMember completed successfully
    if ($?) {

        #Write to console
        Write-Verbose -Message "$(Get-Date -f T) - `'$Userlogonname`' added to `'CN=$DynamicGroupName,$UsersContainerDn`'" -Verbose

    }   #end of if ($?)
    else {

        #Write error
        Write-Warning -Message "Unable to add `'$Userlogonname`' to `'CN=$DynamicGroupName,$UsersContainerDn`'!" -ErrorAction Stop

    }   #end of else ($?)

    ##DYNAMIC GROUP TO HIGH PRIVILEGED GROUP

    #Add the dynamic group to the built-in privileged group
    Write-Verbose -Message "Adding Temporary Dynamic Group to High Privileged Group $GroupName" -Verbose
    Add-ADGroupMember -Identity $GroupName -Members "CN=$DynamicGroupName,$UsersContainerDn" -ErrorAction SilentlyContinue
    
    #Check that Add-ADGroupMember completed successfully
    if ($?) {

        #Write to console
        Write-Verbose -Message "$(Get-Date -f T) - `'CN=$DynamicGroupName,$UsersContainerDn`' added to `'$GroupName`'" -Verbose

    }   #end of if ($?)
    else {

        #Write error
        Write-Warning -Message "Unable to add `'CN=$DynamicGroupName,$UsersContainerDn`' to `'$GroupName`'!" -ErrorAction Stop

    }   #end of else ($?) 

Write-Verbose -Message "JIT is Enabled Successfully" -Verbose
Write-Verbose -Message "$Userlogonname is added to $GroupName for $TtlHours hour" -Verbose
}
else {Write-Warning -Message "DynamicGroup for this user already exists" -ErrorAction Stop }

}
else {

        #Write error
        Write-Error -Message "Unable to obtain object for Users container!" -ErrorAction Stop

    }   #end of else ($UsersContainer)
}   #end of Function 
#Executing Function

#########################################################
#Checking whether user has already dynamic group#
########################################################
 Function Test-Group($group) 
 {
    try {
            $Groupname = Get-ADGroup -Identity $group
            if ($Groupname.name -ne $null) { $true } 
             else { $false }
        } 
    catch { Write-Verbose "$_.ExceptionMessage" -Verbose}
 }
#Checking whether user is already a member of Group
Function Test-Membership($groupmember)
{
    try { 
            $k = Get-ADGroupMember -Identity $groupmember
            if($k.samaccountname -contains "$Userlogonname") 
            {
            Write-warning -Message "$userlogonname is already member of $groupname" -Verbose 
            
            exit
            $true 
             }
            else { $false }
        }
    catch { Write-Verbose "$_.ExceptionMessage" -Verbose }

}

##############################################
#Checking whether host is domainadmin or not#
##############################################
Write-Verbose -Message "Checking whether the script is executing Domain admin or not" -Verbose
$CurrentUser = [System.Security.Principal.WindowsIdentity]::GetCurrent()
$WindowsPrincipal = New-Object System.Security.Principal.WindowsPrincipal($CurrentUser)

if($WindowsPrincipal.IsInRole("Domain Admins"))
{
    Write-Verbose -Message "Script is executing by the domain admin" -Verbose
    #Executing JIT Function
   Set-ADUserJitAdmin
}
else
{
   Write-Warning -Message "Current User is not a Domain Admin" -ErrorAction Stop 
}

 


##########################################################################################################