﻿<#
.SYNOPSIS
Purpose of this script is to generate the Best Practices Analyzer report, in the HTML format, from the Domain Controller the script was ran upon

.DESCRIPTION
If an Administrator wants to gather the Best Practices Analyzer report on a domain controller in the HTML format to determine the general health / basic issues on the DC, then this particular script is very helpful. The script gathers reports based on three in-built modules i.e. AD Domain Services, DNS and File Services. 
It should be noted that this script takes fair amount of time generate the reports. Must run this script with an elevated command prompt

.PARAMETER HTMLReportPath
This parameter is for the path of the HTML report. The user must specify a valid folder path. If the folder is not accessible the script will throw an error and will terminate.

.PARAMETER ReportAllSevereties
By default the script only gathers error and warnings, however if administrator wants to gather informational data as well then –ReportAllSevereties parameter must be passed in the command.

.EXAMPLE
.\GenerateBPAReport.ps1 -HTMLReportPath C:\Share\BPAReports -ReportAllSevereties

.NOTES
Write to Platform_Wintel_SOE@csc.com for more information on the script

.LINK

#>

param(
#declaring commandline parameters : $HTMLReportPath & $reportallsevereties
[string]$HTMLReportPath,
[switch]$ReportAllSevereties)

#creating new function with $HTMLReportPath function parameter and $ReportAllServerties [switch] parameter
Function Generate-DSBPAReport($HTMLReportPath, [switch]$ReportAllSevereties) {
    #importing the activedirectory module to use the AD cmdlets
    Import-Module ActiveDirectory

    # Getting a list of models to generate report for
    $ModelsToRun = @() 
    if ((Get-WindowsFeature AD-Domain-Services).Installed) { $ModelsToRun += "Microsoft/Windows/DirectoryServices" } 
    if ((Get-WindowsFeature DNS).Installed) { $ModelsToRun += "Microsoft/Windows/DNSServer" } 
    if ((Get-WindowsFeature File-Services).Installed) { $ModelsToRun += "Microsoft/Windows/FileServices" } 

    # enumerate thru the models and generate reports for them
    foreach ($BestPracticesModelId in $ModelsToRun) 
    { 
        # construct BPA name and html paths 
        $date = (Get-Date).ToString("MMddyyyy-hhmmss")
        $BPAName = $BestPracticesModelId.Replace("Microsoft/Windows/","") 
        $HTMLPath = $HTMLReportPath + '\' + $env:COMPUTERNAME + "-" + $BPAName + "-" + $date + ".html" 

        #HTML-header 
        $Head = " 
        <title>BPA Report for $BestPracticesModelId on $($env:COMPUTERNAME)</title> 
        <style type='text/css'>  
            table  { border-collapse: collapse; width: 700px }  
            body   { font-family: Verdana, Arial }  
            td, th { border-width: 1px; border-style: solid; text-align: left; padding: 2px 4px; border-color: black }  
            th     { background-color: grey; }  
            td.Red { color: Red }  
        </style>"  

        #Invoke BPA Model         
        Invoke-BpaModel -BestPracticesModelId $BestPracticesModelId | Out-Null 

        #Include all severeties in BPA Report if enabled. If not, only errors and warnings are reported. 
        if ($ReportAllSevereties) 
        { 
            $BPAResults = Get-BpaResult -BestPracticesModelId $BestPracticesModelId 
        } 
        else 
        { 
            $BPAResults = Get-BpaResult -BestPracticesModelId $BestPracticesModelId | Where-Object {$_.Severity -eq "Error" -or $_.Severity -eq “Warning” } 
        } 

        #Send BPA Results to HTML-file if enabled 
        if ($BPAResults) 
        { 
            $BPAResults | ConvertTo-Html -Property Severity,Category,Title,Problem,Impact,Resolution,Help `
            -Title "BPA Report for $BestPracticesModelId on $($env:COMPUTERNAME)" -Body "BPA Report for `
            $BestPracticesModelId on server $($env:COMPUTERNAME) <HR>" -Head $head | Out-File -FilePath $HTMLPath 
        } 
    } 
}
#checking if $reportallsevereties switch parameter is specified in the command or not
If($ReportAllSevereties)
{
    #if switch parameter is specified in the command then the BPA report will be generated with all the severties i.e. errors, warning, information, etc
    Generate-DSBPAReport -HTMLReportPath $HTMLReportPath -ReportAllSevereties
    #writing the message on the console
    Write-Host "Best Practices Analyzer report is saved to $HTMLReportPath with all the severeties"
}
Else
{
    #if switch parameter is not specified in the command then the BPA report will only be generated with errors and warnings
    Generate-DSBPAReport -HTMLReportPath $HTMLReportPath
    #writing the message to the console
    Write-Host "Best Practices Analyzer report is saved to $HTMLReportPath with only errors and warnings"
}
   