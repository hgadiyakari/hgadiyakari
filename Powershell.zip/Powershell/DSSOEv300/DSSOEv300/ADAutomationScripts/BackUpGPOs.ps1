##########################################################################################################
<#
.SYNOPSIS
    Backs up all GPOs from a specified domain and includes additional GPO information.

.DESCRIPTION
    The script backs up all GPOs in a target domain and captures additional GPO management information, such
    as Scope of Management, Block Inheritance, Link Enabled, Link Order, Link Enforced and WMI Filters.

    The backup can then be used by a partner script to mirror GPOs in a test domain.

    Details:
    * Creates a XML file containing PSCustomObjects used by partner import script
    * Creates a XML file WMI filter details used by partner import script
    * Creates a CSV file of additional information for readability
    * Additional backup information includes SOM (Scope of Management) Path, Block Inheritance, Link Enabled,
      Link Order', Link Enforced and WMI Filter data
    * Each CSV SOM entry is made up of "DistinguishedName:BlockInheritance:LinkEnabled:LinkOrder:LinkEnforced"
    * Option to create a Migration Table (to then be manually updated)

    Requirements: 
    * PowerShell GroupPolicy Module
    * PowerShell ActiveDirectory Module
    * Group Policy Management Console

.EXAMPLE
   .\BackUpGPOs.ps1 -Domain wintiptoys.com -BackupFolder "\\wingdc01\backups\"

   This will backup all GPOs in the domain wingtiptoys.com and store them in a date and time stamped folder 
   under \\wingdc01\backups\.

.EXAMPLE
   .\BackUpGPOs.ps1 -Domain contoso.com -BackupFolder "c:\backups" -MigTable

   This will backup all GPOs in the domain contoso.com and store them in a date and time stamped folder 
   under c:\backups\. A migration table, MigrationTable.migtable, will also be created for manual editing.

.OUTPUTS
   Backup folder name in the format Year_Month_Day_HourMinuteSecond
   GpoDetails.xml
   WmiFilters.xml
   GpoInformation.csv
   MigrationTable.migtable (optional)

  

#>
##########################################################################################################

#################################
## Script Options and Parameters
#################################

#Requires -version 3
#Requires -modules ActiveDirectory,GroupPolicy

#Version: 2.2

#Define and validate parameters
[CmdletBinding()]
Param(
      #The target domain
      [parameter(Mandatory=$True,Position=1)]
      [String]$Domain,

      #The backup folder
      [parameter(Mandatory=$True,Position=2)]
      [ValidateScript({Test-Path $_})]
      [String]$BackupFolder,

      #Whether to create a migration table
      [Switch] 
      $MigTable
      )


Try
{
Import-Module activedirectory -ErrorAction stop
}
catch
{
Write-Warning "Unable to import active directory module"
exit
}

Try
{
Import-Module grouppolicy -ErrorAction stop
}
catch
{
Write-Warning "Unable to import Group policy module"
exit
}

Try
{
Get-ADDomain -Identity $Domain -ErrorAction Stop
}
catch
{
Write-Warning "Unable to connect to Domain $Domain"
exit
}



#Set strict mode to identify typographical errors (uncomment whilst editing script)
#Set-StrictMode -version Latest


##########################################################################################################

########
## Main
########

########################
##BACKUP FOLDER DETAILS
#Create a variable to represent a new backup folder
#(constructing the report name from date details and the supplied backup folder)
$Date = Get-Date

$SubBackupFolder = "$BackupFolder\" + `                   "$($Date.Year)_" + `                   "$("{0:D2}" -f $Date.Month)_" + `                   "$("{0:D2}" -f $Date.Day)_" + `                   "$("{0:D2}" -f $Date.Hour)" + `                   "$("{0:D2}" -f $Date.Minute)" + `                   "$("{0:D2}" -f $Date.Second)"


##################
##BACKUP ALL GPOs
#Create the backup folder
New-Item -ItemType Directory -Path $SubBackupFolder | Out-Null


#Make sure the backup folder has been created
If (Test-Path -Path $SubBackupFolder) {

    #Connect to the supplied domain
    $TargetDomain = Get-ADDomain -Identity $Domain
    

    #Obtain the domain FQDN
    $DomainFQDN = $TargetDomain.DNSRoot


    #Obtain the domain DN
    $DomainDN = $TargetDomain.DistinguishedName


    #Connect to the forest root domain
    $TargetForestRootDomain = (Get-ADForest -Server $DomainFQDN).RootDomain | Get-ADDomain
    

    #Obtain the forest FQDN
    $ForestFQDN = $TargetForestRootDomain.DNSRoot


    #Obtain the forest DN
    $ForestDN = $TargetForestRootDomain.DistinguishedName    

    #Backup all the GPOs found in the domain
    $Backups = Backup-GPO -All -Path $SubBackupFolder -Domain $DomainFQDN -Comment "Scripted backup created by $env:userdomain\$env:username on $(Get-Date -format d)"


        #Instantiate an object for Group Policy Management (GPMC required)
        Try {

            $GPM = New-Object -ComObject GPMgmt.GPM
    
        }   #End of Try...
    
        Catch {

            #Display exit message to console
            $Message = "ERROR: Unable to connect to GPMC. Please check that it is installed."
            Write-Host
            Write-Error $Message
  
            #Exit the script
            Exit 1
    
        }   #End of Catch...


    #Import the GPM API constants
    $Constants = $GPM.getConstants()


    #Connect to the supplied domain
    $GpmDomain = $GPM.GetDomain($DomainFQDN,$Null,$Constants.UseAnyDc)

    
    #Connect to the sites container
    $GpmSites = $GPM.GetSitesContainer($ForestFQDN,$DomainFQDN,$Null,$Constants.UseAnyDc)
    

    ###################################
    ##COLLECT SPECIFIC GPO INFORMATION
    #Loop through each backed-up GPO
    ForEach ($Backup in $Backups) {

        #Get the GPO GUID for our target GPO
        $GpoGuid = $Backup.GpoId


        #Get the backup GUID for our target GPO
        $BackupGuid = $Backup.Id
        

        #Instantiate an object for the relevant GPO using GPM
        $GPO = $GpmDomain.GetGPO("{$GpoGuid}")


        #Get the GPO DisplayName property
        $GpoName = $GPO.DisplayName

        #Get the GPO ID property
        $GpoID = $GPO.ID

            
            ##Retrieve SOM Information
            #Create a GPM search criteria object
            $GpmSearchCriteria = $GPM.CreateSearchCriteria()


            #Configure search critera for SOM links against a GPO
            $GpmSearchCriteria.Add($Constants.SearchPropertySOMLinks,$Constants.SearchOpContains,$GPO)


            #Perform the search
            $SOMs = $GpmDomain.SearchSOMs($GpmSearchCriteria) + $GpmSites.SearchSites($GpmSearchCriteria)


            #Empty the SomPath variable
            $SomInfo = $Null

        
                #Loop through any SOMs returned and write them to a variable
                ForEach ($SOM in $SOMs) {

                    #Capture the SOM Distinguished Name
                    $SomDN = $SOM.Path

                
                    #Capture Block Inheritance state
                    $SomInheritance = $SOM.GPOInheritanceBlocked

                
                    #Get GPO Link information for the SOM
                    $GpoLinks = $SOM.GetGPOLinks()


                        #Loop through the GPO Link information and match info that relates to our current GPO
                        ForEach ($GpoLink in $GpoLinks) {
                        
                            If ($GpoLink.GPOID -eq $GpoID) {

                                #Capture the GPO link status
                                $LinkEnabled = $GpoLink.Enabled


                                #Capture the GPO precedence order
                                $LinkOrder = $GpoLink.SOMLinkOrder


                                #Capture Enforced state
                                $LinkEnforced = $GpoLink.Enforced


                            }   #End of If ($GpoLink.GPOID -eq $GpoID)


                        }   #End of ForEach ($GpoLink in $GpoLinks)


                #Append the SOM DN, link status, link order and Block Inheritance info to $SomInfo
                [Array]$SomInfo += "$SomDN`:$SomInheritance`:$LinkEnabled`:$LinkOrder`:$LinkEnforced"
            
            
                }   #End of ForEach ($SOM in $SOMs)...


        ##Obtain WMI Filter path using Get-GPO
        $Ginfo = Get-GPO -Guid $GpoGuid -Domain $DomainFQDN
        if($Ginfo.WmiFilter -ne $null)
        {
        $WmiFilter = $Ginfo.WmiFilter.Path
        $WMiFilter = ($WmiFilter -split "`"")[1]
        }
        else
        {
        $WmiFilter = $null
        }
        
        #Split the value down and use the ID portion of the array
        


        #Add selected GPO properties to a custom GPO object
        $GpoInfo = [PSCustomObject]@{

                BackupGuid = $BackupGuid
                Name = $GpoName
                GpoGuid = $GpoGuid
                SOMs = $SomInfo
                DomainDN = $DomainDN
                WmiFilter = $WmiFilter
        
        }   #End of $Properties...

        
        #Add our new object to an array
        [Array]$TotalGPOs += $GpoInfo


    }   #End of ForEach ($Backup in $Backups)...



    #####################
    ##BACKUP WMI FILTERS
    #Connect to the Active Directory to get details of the WMI filters
    $WmiFilters = Get-ADObject -Filter 'objectClass -eq "msWMI-Som"' `                               -Properties msWMI-Author, msWMI-ID, msWMI-Name, msWMI-Parm1, msWMI-Parm2 `                               -Server $DomainFQDN `                               -ErrorAction SilentlyContinue



    ######################
    ##CREATE REPORT FILES
    ##XML reports
    #Create a variable for the XML file representing custom information about the backed up GPOs
    $CustomGpoXML = "$SubBackupFolder\GpoDetails.xml"

    #Export our array of custom GPO objects to XML so they can be easily re-imported as objects
    $TotalGPOs | Export-Clixml -Path $CustomGpoXML

    #If $WMIFilters contains objects write these to an XML file
    If ($WmiFilters) {

        #Create a variable for the XML file representing the WMI filters
        $WmiXML = "$SubBackupFolder\WmiFilters.xml"

        #Export our array of WMI filters to XML so they can be easily re-imported as objects
        $WmiFilters | Export-Clixml -Path $WmiXML

    }   #End of If ($WmiFilters)


    ##CSV report
    #Create a variable for the CSV file that will contain the SOM (Scope of Management) information for each backed-up GPO
    $SOMReportCSV = "$SubBackupFolder\GpoInformation.csv"


    #Now, let's create the CSV report 
    ForEach ($CustomGPO in $TotalGPOs) {
            
        #Start constructing the CSV file line entry for the current GPO
        $CSVLine = "`"$($CustomGPO.Name)`",`"{$($CustomGPO.GPOGuid)}`","


        #Expand the SOMs property of the current object
        $CustomSOMs = $CustomGPO.SOMs


            #Loop through any SOMs returned
            ForEach ($CustomSOM in $CustomSOMs) {

                #Append the SOM path to our CSV line
                $CSVLine += "`"$CustomSOM`","

         
           }   #End of ForEach ($CustomSOM in $CustomSOMs)...


       #Write the newly constructed CSV line to the report
       Add-Content -Path $SOMReportCSV -Value $CSVLine


    }   #End of ForEach ($CustomGPO in $TotalGPOs)...


    ###########
    ##MIGTABLE
    #Check whether a migration table should be created
    If ($MigTable) {

        #Create a variable for the migration table
        $MigrationFile = "$SubBackupFolder\MigrationTable.migtable"

        #Create a migration table 
        $MigrationTable = $GPM.CreateMigrationTable()


        #Connect to the backup directory
        $GpmBackupDir = $GPM.GetBackUpDir($SubBackupFolder)
        #Reset the GPM search criterea
        $GpmSearchCriteria = $GPM.CreateSearchCriteria()


        #Configure search critera for the most recent backup
        $GpmSearchCriteria.Add($Constants.SearchPropertyBackupMostRecent,$Constants.SearchOpEquals,$True)
   

        #Get GPO information
        $BackedUpGPOs = $GpmBackupDir.SearchBackups($GpmSearchCriteria)


            #Add the information to our migration table
            ForEach ($BackedUpGPO in $BackedUpGPOs) {

                $MigrationTable.Add($Constants.ProcessSecurity,$BackedUpGPO)
        
            }   #End of ForEach ($BackedUpGPO in $BackedUpGPOs)...


        #Save the migration table
        $MigrationTable.Save($MigrationFile)


    }   #End of If ($MigTable)...


}   #End of If (Test-Path $SubBackupFolder)...




