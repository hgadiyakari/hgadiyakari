# Gets time stamps for all computers in the domain that have NOT logged in since after specified date

<#
.SYNOPSIS
One can utilize this script to find out inactive computers that have not logged in since after a specified date.

.DESCRIPTION
Purpose of this script is to find stale & inactive computer accounts in domain. An Administrator can define the �DaysInactive Parameter to collect data in CSV file. This script gets time stamps for all computers in the domain that have NOT logged in since after specified date.
Must execute this script from an elevated powershell window.
The output will be saved in a CSV file on the current working directory.

.PARAMETER DaysInactive
Specify the number of days since after you want to find out the computers that have not logged on.

.PARAMETER GetInactiveComputers
Without specifying this parameter, the script won't run

.EXAMPLE
To find the computers that have not logged in since 90 days
.\GetInactiveComputer.ps1 -DaysInactive 90 -GetInactiveComputers

.NOTES
Write to Platform_Wintel_SOE@csc.com for more information on the script

.LINK

#>

Param(
      [parameter(Mandatory=$True)]
      [String]$DaysInactive,
      [switch]$GetInactiveComputers
      )
 

function GetInactiveComputers($Days) {
    import-module activedirectory

    $time = (Get-Date).Adddays(-($DaysInactive))
 
    # Get all AD computers with lastLogonTimestamp less than our time
    Get-ADComputer -Filter {LastLogonTimeStamp -lt $time} -Properties LastLogonTimeStamp | `
    select-object Name,@{Name="Stamp"; Expression={[DateTime]::FromFileTime($_.lastLogonTimestamp)}} | export-csv OLD_Computer.csv -notypeinformation
    # Output hostname and lastLogonTimestamp into CSV
}

If($GetInactiveComputers) {
    GetInactiveComputers -Days $DaysInactive
}
else {
    Write-Host "Please specify the -GetInactiveComputers [switch] parameter to execute the processing of the script"
}