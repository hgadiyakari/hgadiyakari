<#
.SYNOPSIS
This script documents the history of schema updates. 

.DESCRIPTION
This script is useful for all the IT Professionals who have inherited and AD environment which they did not built. One can get insight on the origins of the directory.
The script generated two output files. Complete schema report is saved to a CSV file and Schema version & forest creation date is saved to a html file.

.EXAMPLE
Just execute the script on the elevated PowerShell window to get the output files. The files will be created in the working directory.
.\ADSchemaReport.ps1

.NOTES
Write to Platform_Wintel_SOE@csc.com for more information on the script

.LINK
https://gallery.technet.microsoft.com/PowerShell-Active-4ffedca4
#>


[cmdletbinding]
Import-Module ActiveDirectory 

$schema = Get-ADObject -SearchBase ((Get-ADRootDSE).schemaNamingContext) `
    -SearchScope OneLevel -Filter * -Property objectClass, name, whenChanged,`
    whenCreated, attributeID | Select-Object objectClass, attributeID, name,`
    whenCreated, whenChanged, `
    @{name="event";expression={($_.whenCreated).Date.ToString("yyyy-MM-dd")}} |
    Sort-Object event, objectClass, name

"`nDetails of schema objects created by date:"
$schema | Format-Table objectClass, attributeID, name, whenCreated, whenChanged `
    -GroupBy event -AutoSize

"`nCount of schema objects created by date:"
$schema | Group-Object event | Format-Table Count, Name, Group -AutoSize

$schema | Export-CSV .\schema.csv -NoTypeInformation
"`nSchema CSV output here: .\schema.csv"


$SchemaVersions = @()

$SchemaHashAD = @{
    13="Windows 2000 Server";
    30="Windows Server 2003 RTM";
    31="Windows Server 2003 R2";
    44="Windows Server 2008 RTM";
    47="Windows Server 2008 R2";
    56="Windows Server 2012 RTM";
    69="Windows Server 2012 R2";
    87="Windows Server 2016"
    }

$SchemaPartition = (Get-ADRootDSE).NamingContexts | Where-Object {$_ -like "*Schema*"}
$SchemaVersionAD = (Get-ADObject $SchemaPartition -Property objectVersion).objectVersion
$SchemaVersions += 1 | Select-Object `
    @{name="Product";expression={"AD"}}, `
    @{name="Schema";expression={$SchemaVersionAD}}, `
    @{name="Version";expression={$SchemaHashAD.Item($SchemaVersionAD)}}

#------------------------------------------------------------------------------

$SchemaHashExchange = @{
    4397="Exchange Server 2000 RTM";
    4406="Exchange Server 2000 SP3";
    6870="Exchange Server 2003 RTM";
    6936="Exchange Server 2003 SP3";
    10628="Exchange Server 2007 RTM";
    10637="Exchange Server 2007 RTM";
    11116="Exchange 2007 SP1";
    14622="Exchange 2007 SP2 or Exchange 2010 RTM";
    14625="Exchange 2007 SP3";
    14726="Exchange 2010 SP1";
    14732="Exchange 2010 SP2";
    14734="Exchange 2010 SP3";
    15137="Exchange 2013 RTM";
    15254="Exchange 2013 CU1";
    15281="Exchange 2013 CU2";
    15283="Exchange 2013 CU3";
    15292="Exchange 2013 SP1";
    15300="Exchange 2013 CU5";
    15303="Exchange 2013 CU6"
    }

$SchemaPathExchange = "CN=ms-Exch-Schema-Version-Pt,$SchemaPartition"
If (Test-Path "AD:$SchemaPathExchange") {
    $SchemaVersionExchange = (Get-ADObject $SchemaPathExchange -Property rangeUpper).rangeUpper
} Else {
    $SchemaVersionExchange = 0
}

$SchemaVersions += 1 | Select-Object `
    @{name="Product";expression={"Exchange"}}, `
    @{name="Schema";expression={$SchemaVersionExchange}}, `
    @{name="Version";expression={$SchemaHashExchange.Item($SchemaVersionExchange)}}

#------------------------------------------------------------------------------

$SchemaHashLync = @{
    1006="LCS 2005";
    1007="OCS 2007 R1";
    1008="OCS 2007 R2";
    1100="Lync Server 2010";
    1150="Lync Server 2013"
    }

$SchemaPathLync = "CN=ms-RTC-SIP-SchemaVersion,$SchemaPartition"
If (Test-Path "AD:$SchemaPathLync") {
    $SchemaVersionLync = (Get-ADObject $SchemaPathLync -Property rangeUpper).rangeUpper
} Else {
    $SchemaVersionLync = 0
}

$SchemaVersions += 1 | Select-Object `
    @{name="Product";expression={"Lync"}}, `
    @{name="Schema";expression={$SchemaVersionLync}}, `
    @{name="Version";expression={$SchemaHashLync.Item($SchemaVersionLync)}}

#------------------------------------------------------------------------------

## AD, Exchange and Lync schema information is saved in html format

#---------------------------------------------------------------------------sdg

$a = "<style>"
$a = $a + "BODY{background-color:peachpuff;}"
$a = $a + "TABLE{border-width: 1px;border-style: solid;border-color: black;border-collapse: collapse;}"
$a = $a + "TH{border-width: 1px;padding: 0px;border-style: solid;border-color: black;background-color:thistle}"
$a = $a + "TD{border-width: 1px;padding: 0px;border-style: solid;border-color: black;background-color:PaleGoldenrod}"
$a = $a + "</style>"

$SchemaVersions | ConvertTo-Html -head $a -Body "<H2>Schema Information</H2>" | Out-File .\Schemaoutput.htm


#------------------------------------------------------------------------------


$forestdate = Get-ADObject -SearchBase (Get-ADForest).PartitionsContainer -LDAPFilter "(&(objectClass=crossRef)(systemFlags=3))" `
    -Property dnsRoot, nETBIOSName, whenCreated | Select-Object @{name = "Name"; expression = {$_.nETBIOSName}}, @{name="Date";expression = {$_.whenCreated}}

    
    
   
  $forestdate | ConvertTo-Html -head $a -Body "<H2>Forest creation date</H2>" | Out-File .\Schemaoutput.htm -Append
 
  
#------------------------------------------------------------------------------