﻿
<#
.SYNOPSIS
    The Purpose of this Script to enable JEA(Just Enough Administration).
     
.DESCRIPTION
    It allows nonadmin users to run specific powershell commandlets on servers through powershell remoting 
    without giving them administrator rights,identified by their distinguished group name, in the same domain.
    
    The powershell commands which we givig when running the script, that command can only run the groupmembers 
    through powershell remote sessions.

    Uses a role capability file(contains visble commands,visible external commands which can run user) and session configuration 
    file(contains type of sessions to be apply to user) and registers a Powershell session with the name which user giving as a 
    input in configuration name.

    This role capability file was introduced in Powershell version 5. So this script needs PS Version 5.0

    This scripted is supported on Windows Server 2016 and Windows Server 2012 R2 with Powershell version 5
    
    PREREQUISTIES
    Windows Server 2016 instance running (or) Windows Server 2012 or 2012R2 with WMF 5.0 RTM.
    Domain admin can only execute these scripts.
    The server should have ActiveDirectory installed.

 .EXAMPLE
    1) 
    .\Enable-jea.ps1 -groupname Nonadministrators
            -configurationname JEA 
            -Visiblecmdlets "Write-Host","Get-NetIpAdress"
            -VisibleExternalcmdlets "C:\Windows\System32\ipconfig.exe"
            -Companyname CSC
    Allows the users in Nonnadministrators(-groupname) group to run Write-Host,Get-NetIpAddress,ipconfig(-visiblecmdlets) commandlets
    through powershell remoting, and creates a powershell configuration with the name JEA(-configurationname)

    USING JEA With Respect to Example1
    Enter-PSSession -ComputerName Test -Credential usernameandpassword -Configurationname JEA

    Connecting to a Powershell RemoteSession by using JEA(-Configurationname) with the credintials of the user(should be in nonadministrators group) on 
    a test computer.In this session user can run run the commands which are mentioned in the -visiblecmdlets paramter.


    
 .EXAMPLE
    2) 
    .\Enable-jea.ps1 -groupname operators
            -configurationname test  
            -Visiblecmdlets @{ Name = ‘Restart-Service'; Parameters = @{ Name = 'Name'; ValidateSet = 'Spooler’ }}
                   ‘NetTCPIP\Get-*' 
    Allows the users in operators(-groupname) group to run Restart spooler service(-visiblecmdlets)commandlet
    through powershell remoting, and creates a powershell configuration with the name Test
   
    USING JEA With Respect to Example2
    Enter-PSSession -ComputerName Local -Credential usernameandpassword -Configurationname Test

    Connecting to a Powershell RemoteSession by using Test(-Configurationname) with the credintials of the user(should be in operators group) on 
    a Local computer.In this session user can run run the commands which are mentioned in the -visiblecmdlets paramter.

 EXAMPLE 
    3)
    .\Enable-jea.ps1 -groupname HelpDesk
            -configurationname RestrictHelpDesk  
            -Visiblecmdlets "Get-DNSServer"
    Allows the users in HelpDesk(-groupname) group to run Get-DNSServer(-visiblecmdlets)commandlet
    through powershell remoting, and creates a powershell configuration with the name RestrictHelpDesk
   
    USING JEA With Respect to Example3
    Enter-PSSession -ComputerName Mypc -Credential usernameandpassword -Configurationname RestrictHelpDesk

    Connecting to a Powershell RemoteSession by using RestrictHelpDesk(-Configurationname) with the credintials of the user(should be in HelpDesk group) on 
    a Mypc computer.In this session user can run run the commands which are mentioned in the -visiblecmdlets paramter.

 EXAMPLE 
    4)
    .\Enable-jea.ps1 -groupname PWSUsers
            -configurationname PWS  
            -Visiblecmdlets "Out-File","Get-PSDrive"
    Allows the users in PWSUsers(-groupname) group to run Get-"Out-File","Get-PSDrive"(-visiblecmdlets)commandlets
    through powershell remoting, and creates a powershell configuration with the name PWS
   
    USING JEA With Respect to Example4
    Enter-PSSession -ComputerName GIS -Credential usernameandpassword -Configurationname PWS

    Connecting to a Powershell RemoteSession by using RestrictHelpDesk(-Configurationname) with the credintials of the user(should be in PWS group) on 
    a GIS Computer.In this session user can run run the commands which are mentioned in the -visiblecmdlets paramter.


  .PARAMETER GroupName
    Specify the group name of the Non Adminstrator users in this parameter. After Execution of this Script, users in this 
    group can do Powershell Remote Session by connecting to JEA end point and the users in this group can only run the commandlets
    which are mentioned in Visible cmdlets parameter.

 .PARAMETER configurationname
    Specify a name to create a JEA Endpoint.When connecting to powershell remote session user need to 
    mention this configuration name. This configuration name is nothing but what we are giving in this prameter.

    For Example1:Enable-jea.ps1 -groupname helpdeskoperators -Visiblecmdlets "Get-dnsserver" -configurationname Testjea
    In above example Testjea is the value of -configurationname parameter. This configurationname need to give,when we
    connecting to powershell remote session like below
    
    Example2: Enter-pssession -computername local -credential username\password -configurationname Testjea 
    In above example1 when executing script the value of -configurationname parameter is Testjea, So in Example2, when connecting to
    powershell remote session the value of -configurationname should be Testjea. Otherwise powershell remote session will be fail.

 .PARAMETER Visiblecmdlets
    Specify the commands which user needs to run. Suppose the values for this parameter are "Get-DnsServer","Get-NetIpAdress".
    When user commected to powershell remote session the user can run only the commands mentioned in this parameter.

 .PARAMETER VisibleExternalcmdlets
    Specify the  executable files using this prameter. We can also expose scripts with this parameter.
    Ex: -VisibleExternalcmdlets "C:\Windows\System32\ipconfig.exe"

 .PARAMETER Companyname
    specify the company name that which company is executing  the Script.
    Ex: CSC
   

#>
#Requires -version 5
#Requires -modules ActiveDirectory

#Code Starts

##Define and validate parameters 
[CmdletBinding()]
 Param( 
          [parameter(Mandatory,Position=1)]
          [ValidateScript({Get-ADGroup -Identity $_})]
          [String]$groupname,
          [parameter(Mandatory,Position=2)]
          [String]$Configurationname,
          [parameter(Mandatory,Position=3)]
          $VisibleCmdlets,
          [String[]]$visibleExternalcmdlets,
          [String]$Companyname
       )
#####################################################
# Function to enable JEA(Just Enough Administration)#
#####################################################

function jea{
    
    #Management with JEA occurs through PowerShell Remoting.
    Write-Verbose -Message "Enabling powershell remoting" -Verbose
    Enable-PSRemoting
     

        # Fields in the role capability
            $JeaRoleCapabilityCreationParams = 
            @{
               Author = hostname
               ModulesToImport = "Microsoft.PowerShell.Core"
               CompanyName= "$Companyname"
              }

    # Creating the JEA_Module folder, which will contain the demo Role Capability File
    Write-Verbose -Message "Creating new JEA_Module directory in $env:ProgramFiles\WindowsPowerShell\Modules\JEA_Module " -Verbose
    New-Item -Path “$env:ProgramFiles\WindowsPowerShell\Modules\JEA_Module” -ItemType Directory -Force 


    # Creating the JEA_RoleCapabilities folder, which will contain the demo Role Capability File
    Write-Verbose -Message "Creating new JEA_RoleCapabilities directory in $env:ProgramFiles\WindowsPowerShellModules\JEA_Module\RoleCapabilities " -Verbose
    New-Item -Path “$env:ProgramFiles\WindowsPowerShell\Modules\JEA_Module\RoleCapabilities” -ItemType Directory -Force

    # Create the Role Capability file
    Write-Verbose -Message "Creating new JEARole.psrc rolecapability file in $env:ProgramFiles\WindowsPowerShell\Modules\JEA_Module\RoleCapabilities\JEARole.psrc " -Verbose
     if($visibleExternalcmdlets -eq $null)
            {
            New-PSRoleCapabilityFile -Path “$env:ProgramFiles\WindowsPowerShell\Modules\JEA_Module\RoleCapabilities\JEARole.psrc" -VisibleCmdlets $visiblecmdlets @JeaRoleCapabilityCreationParams 
            }
            else
            { 
            New-PSRoleCapabilityFile -Path “$env:ProgramFiles\WindowsPowerShell\Modules\JEA_Module\RoleCapabilities\JEARole.psrc" -VisibleCmdlets $visiblecmdlets -VisibleExternalCommands $visibleExternalcmdlets @JeaRoleCapabilityCreationParams 
            } 
    #Following commands to create and register the demo “session configuration” file
        #Determine domain
        $domain = (Get-CimInstance -ClassName Win32_ComputerSystem).Domain
        Write-Verbose -Message "Determining Domain $domain" -Verbose
        #Replace with your non-admin group name
        $NonAdministrator = "$domain\$groupname"

        $JEAConfigParams = @{
            SessionType= "RestrictedRemoteServer" 
            RunAsVirtualAccount = $true
            RoleDefinitions = @{ $NonAdministrator = @{RoleCapabilities = 'JEARole'}}
            TranscriptDirectory = "$env:ProgramData\JEAConfiguration\Transcripts”
                    }
     
    if(-not (Test-Path "$env:ProgramData\JEAConfiguration"))
        {
        Write-Verbose -Message "Creating new JEAConfiguration directory in $env:ProgramData\JEAConfiguration " -Verbose
        New-Item -Path "$env:ProgramData\JEAConfiguration” -ItemType Directory
        }



    if(Get-PSSessionConfiguration -Name $Configurationname -ErrorAction SilentlyContinue)
        {
        Unregister-PSSessionConfiguration -Name $Configurationname -ErrorAction Stop
        }

    Write-Verbose -Message "Creating new PowershellSessionConfiguration file in $env:ProgramData\JEAConfiguration\JEA.pssc" -Verbose
    New-PSSessionConfigurationFile -Path "$env:ProgramData\JEAConfiguration\JEA.pssc"  @JEAConfigParams
    #endregion

    #region Register the session configuration
    Write-Verbose -Message "Registering $Configurationname PowershellSessionConfiguration file in $env:ProgramData\JEAConfiguration\JEA.pssc" -Verbose
    Register-PSSessionConfiguration -Name $Configurationname -Path "$env:ProgramData\JEAConfiguration\JEA.pssc"
    Write-Verbose -Message "Restarting WinRM Service" -Verbose
    Restart-Service WinRM
    Write-Verbose -Message "JEA is Enabled Successfully" -Verbose 
    #endregion
 
}
##############################################
#Checking whether host is domainadmin or not#
##############################################
Write-Verbose -Message "Checking whether the Script is running Domain Admin or not" -Verbose
$CurrentUser = [System.Security.Principal.WindowsIdentity]::GetCurrent()
$WindowsPrincipal = New-Object System.Security.Principal.WindowsPrincipal($CurrentUser)

if($WindowsPrincipal.IsInRole("Domain Admins"))
{   
    Write-Verbose -Message "Script is Executing by Domain Admin" -Verbose
    #Executing JEA Function
    Write-Verbose -Message "Executing JEA Function" -Verbose
   jea
   
}
else
{
   Write-Warning -Message "Current User is not a Domain Admin" -ErrorAction Stop
}
