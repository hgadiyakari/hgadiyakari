# This script will run auto update for WinCompliance from a WinCompliance repository or schedule auto Update
# Name  : WCAutoUpdate.ps1
# Author: Harikrishnan GN
# Date  : 28-June-2015
# ---------------------------------------------------------------------------------------------

#Powershell version prerequisite -  the below comment automatically verifies the ps version
#requires -Version 3.0

[CmdletBinding()]
Param (

    [Parameter(ParameterSetName="wcConfigure")] 
    [Switch] $Configure,

    [ValidateScript({Test-Path "$_\WinCompliance"})]
    [Parameter(ParameterSetName="wcConfigure", Mandatory=$true)]
    $wcRepositoryPath,
	
	[Parameter(ParameterSetName="wcConfigure")]
    $ExcludeDirectories,
	
	[Parameter(ParameterSetName="wcConfigure")]
    $ExcludeFiles,

    [Parameter(ParameterSetName="ScanUpdate")] [Switch] $ScanforUpdates,
	
	[Parameter(ParameterSetName="ScanUpdate")]
	[ValidateScript({([System.IO.File]::Exists((resolve-path $_).ProviderPath)) -and $_.trim().split(".")[-1] -eq 'xml'})]
	[string] $autoConfigXML
)

# exitcode - { 0=success; 1=failed, 2=no admin rights, 4=unable to detect Modules, 8=Unable to detect wcmAutoUpdateClientConfig.xml
# does not exists; 16=Error Occoured while updating files; 32=failed to update wcmAutoUpdateClientConfig.xml,64- Noupdate Required as Version of WC Client is higher
$wcUpdaterReturn = [pscustomobject]@{
exitcode='';
status='';
message='';
files='';
config=[pscustomobject]@{
    repositorypath ='';
    wcsource='';
    excludedir='';
    excludefile='';
    }
logpath='';
}

#region ErrorDescriptionVariables
# Error conditions and return codes
$wcErrorElevatedPermissionsRequired = "Elevated permissions are required to run WinCompliance."
$wcErrorImportModules = "WinCompliance Source seems to be corrupt.Exiting Script."
#endregion

#region import Modules
$wccolModules = @("WCAutoUpdater.psm1","LogCallerPref.psm1","wcLogger.psm1","wcUtils.psm1")
$ModulePath = "$PSScriptRoot\modules"
forEach($wcModule in $wccolModules) {
    if(Test-Path "$ModulePath\$wcModule") {
        Import-Module "$ModulePath\$wcModule" -Force
    }
    else {
        $wcUpdaterReturn.exitcode = 4
        $wcUpdaterReturn.message = "$Unable to detect $wcModule in WinCompliance Source.$wcErrorImportModules"
        return $wcUpdaterReturn;
        exit;
    }
}
#endregion

# check if current user is admin (launched via elevated creds)
if(-not (Test-IsCurrentUserAdmin)) { 
    $wcUpdaterReturn.exitcode = 2
    $wcUpdaterReturn.message =  $wcErrorElevatedPermissionsRequired
    return $wcUpdaterReturn;
    exit # terminate script
}

#region create Log File

$logPath = "$PSScriptRoot\logs\$($env:COMPUTERNAME)"

$LogName = "wcau-"
if($Configure.IsPresent) { $LogName = "wcauc-" }

# set report log file path/name if user has not specified it. set it at SOE default location
$wcTime = Get-Date;
$timeStamp = $wcTime.ToString('MMddyyhhmmss') # timestamp to add as part of log/report file names
if(-not $LogFilePath) { 
    $LogFilePath = $logPath + "\$LogName$timeStamp" + ".log"
}

Set-WCLogFile -LogPath $LogFilePath # set log file path
$wcUpdaterReturn.LogPath = $LogFilePath;

Set-WCLogLevel -LogLevel "info"
Write-WCLog -Message "WinCompliance AutoUpdate script logging started"
$CurrentUser = "$([Environment]::UserDomainName)\$([Environment]::UserName)";
Write-WCLog -Message "Account ID used to run AutoUpdate Script : $CurrentUser"
#endregion

if($Configure.IsPresent){
#region scheduling the script
    Write-WCLog -Message "Configuring WinCompliance Auto Updater Configuration xml"
    
    #Update wcAutoUpdatexml file before scheduled Task is created
    Write-WCLog -Message "Validating $wcRepositoryPath and updating AutoUpdate Config XML"
    $returnVal  = Update-WCAUConfigxml -wcRepositoryPath $wcRepositoryPath -ExcludeDirectories $ExcludeDirectories -ExcludeFiles $ExcludeFiles
    Write-WCLog -Level Info -Message $returnVal

    if($returnVal -ne "Success") { 
        $wcUpdaterReturn.exitcode = 32
        $wcUpdaterReturn.message =  $returnVal
        $wcUpdaterReturn.status = "Failed"
    }
    else {
        $wcUpdaterReturn.exitcode = 0
        $wcUpdaterReturn.status = "Success"
    }
	return $wcUpdaterReturn
#endregion
}
else {
#region running Auto Update
    Write-WCLog -Message "Performing Auto Update"
	#if auto update Script is passed use it as repository Path
	if($autoConfigXML.Length -eq 0) {
		$autoConfigXML = resolve-Path "$PSScriptRoot\Config\wcmAutoUpdateClientConfig.xml"
	}
    
    if(Test-Path $autoConfigXML) {
        [xml]$autoXML = Get-Content $autoConfigXML
        Write-WCLog -Message "Reading Configuration Values from wcmAutoUpdateClientConfig.xml"

        #ReadConfig xml to get repolocation and other parameters for sync
        $wcRepository = $autoXML.WCMAutoUpdateConfig.RepositoryLocation.Config.Location
        $wcSource = $psScriptRoot
        $ExcludeDir = @($autoXML.WCMAutoUpdateConfig.Settings.ExcludeList.Directory)
        $ExcludeFile = @($autoXML.WCMAutoUpdateConfig.Settings.ExcludeList.File)

        Write-WCLog -Message "RepositoryPath : $wcRepository"
        $wcUpdaterReturn.config.repositoryPath = $wcRepository
        Write-WCLog -Message "DestinationPath : $wcSource"
        $wcUpdaterReturn.config.wcsource = $wcSource      

        #check to see if update is required
        $wcVersion = Compare-WCAUVersion -wcRepository "$wcRepository\WinCompliance"
        if($wcversion.status -eq "false" -or $wcversion.status -eq "lower") { 
            Write-WCLog -Message "AutoUpdate script is quiting"
            $wcUpdaterReturn.message = $FilestoUpdate;
			$wcUpdaterReturn.status = "No Update Required or error with update.Existing WC version($($wcversion.wcclientversion)) is higher than or equal to the version in the repository($($wcversion.repositoryversion))"
			$wcUpdaterReturn.exitcode = 64
            return $wcUpdaterReturn
        }
		elseif($wcversion.status -eq "equal") { #update only baseline folder in wc source package + additonal folders added by user eg:custommodules
			 $ExcludeFile += @("wcautoupdate.ps1","wcremediation.ps1","wcreportgen.ps1")
			 $ExcludeDir += @("modules","userinterface","bin")
		}
        
		Write-WCLog -Message "Directories to Exclude: $ExcludeDir"
        $wcUpdaterReturn.config.excludedir = $ExcludeDir
        Write-WCLog -Message "Files to Exclude: $ExcludeFile"
        $wcUpdaterReturn.config.excludefile = $ExcludeFile
		
		#Identify files to update
		$FilestoUpdate = Compare-WCAUCompareSource -wcRepository "$wcRepository\WinCompliance" -wcSource $wcSource -ExcludeFileList $ExcludeFile -ExcludeFolderList $ExcludeDir
		
		
		if($FilestoUpdate -join "," -like "Error*") {
			$wcUpdaterReturn.message = $FilestoUpdate;
			$wcUpdaterReturn.status = "Failed"
			$wcUpdaterReturn.exitcode = 1 
		}
		else {
			$wcUpdaterReturn.Files = $FilestoUpdate -join ","
			if($FilestoUpdate -ne $Null -and $ScanforUpdates.IsPresent -eq $false) {
				$return = Update-WCAUSource -wcRepository "$wcRepository\WinCompliance" -wcSource $wcSource -FilestoReplace $FilestoUpdate
				$wcUpdaterReturn.message = $return;
				
				if($return -ne "Success") {
					 $wcUpdaterReturn.status = "Pending"
					 $wcUpdaterReturn.exitcode = 1
				}
				else {
					$wcUpdaterReturn.status = "Updated" 
					$wcUpdaterReturn.exitcode = 0
                    #Update Branding
                    $Ret = Update-WCAUBranding -wcRepository "$wcRepository\WinCompliance" -LogFilePath $LogFilePath -wcversion $wcversion
				}
			}
			else {
				$wcUpdaterReturn.status = "Success"
				$wcUpdaterReturn.exitcode = 0 
			}
		}
    }
    else {
        Write-WCLog -Message "Unable to detect $PSScriptRoot\Config\wcmAutoUpdateClientConfig.xml.Exiting Script";
        $wcUpdaterReturn.exitCode = 8
        $wcUpdaterReturn.message =  "Unable to detect $PSScriptRoot\Config\wcmAutoUpdateClientConfig.xml.Exiting Script"     
    }
#endregion
return $wcUpdaterReturn
}
