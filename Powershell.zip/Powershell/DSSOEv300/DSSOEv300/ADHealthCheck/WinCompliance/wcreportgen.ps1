﻿# This script will generate WinCompliance report based on given user parameters and save it in 
# default XML format. Script accepts multiple command-line arguments and works in silent mode. 
# Name  : WCReportGen.ps1
# Author: Umesh Thakur
# Date  : 25-Nov-2014
# -------------------------------------------------------------------------------------------------
# Modification History: 
# 08-june-2015: Updated code to write errors when WC cannot run due to various reasons (unable
#               to detect baseline, elevated permissions are required, etc.). If you are launching
#               this script locally/remotely (via WCReportGenRemote.ps1), adding -ErrorAction
#               as 'SilentlyContinue' and -ErrorVariable to variableName will prevent error from
#               appearing on console and it will be assigned to given variable. 
# 06-may-2016:  by Umesh - updated code to use Get-WCXMLNode in place of SelectNodes() function
#               to ensure it is supported on Nano server.
# 13-may-2016: by Umesh - some minor updates
# 24-jun-2016: by Umesh - if user has specified folder path in report/log/inventory file path then
#              auto-generate report/log/inventory under given folder
# 01-jul-2016: by Umesh - updated code to return an object with (exitcode, message and log/report paths)
#              as opposed to just returning the report path of true/false.
# 19-aug-2016: by Umesh - re-organized parameters, added parameters for remote reporting, added code for 
#              remote report generation.
# 22-aug-2016: by Umesh - updated with changed report viewer script name (ShowWCReport.ps1 -> WCReportView.ps1)
# -------------------------------------------------------------------------------------------------

#Powershell version prerequisite -  the below comment automatically verifies the ps version
#requires -Version 3.0

#region ScriptParameters
[CmdletBinding(DefaultParameterSetName="wcLocalRepAutoDetect")]
param(
    #[Parameter(ParameterSetName="wcLocalRepAutoDetect")]
    #[Parameter(ParameterSetName="wcLocalRepUserBaseline")]
    #[switch] $Local, 
    
    #[Parameter(ParameterSetName="wcRemoteRep")] 
    #[switch] $Remote,
    
    [Parameter(ParameterSetName="wcLocalRepAutoDetect")] 
    [switch] $DetectBaseline,
    
    [Parameter(ParameterSetName="wcLocalRepAutoDetect")] 
    [ValidateSet("WSSOE", "PVVDISOE", "DSSOE")] 
    [string] $DetectionType = "WSSOE",
    
    [Parameter(ParameterSetName="wcLocalRepUserBaseline")] 
    [ValidateScript({([System.IO.File]::Exists((resolve-path $_).ProviderPath)) -and $_.trim().split(".")[-1] -eq 'xml'})]
    [string] $BaselineFile,
    
    # Category filter parameter
    [Parameter(ParameterSetName="wcLocalRepAutoDetect")]
    [Parameter(ParameterSetName="wcLocalRepUserBaseline")]
    [string[]] $Section,

    # Category filter parameter
    [Parameter(ParameterSetName="wcLocalRepAutoDetect")]
    [Parameter(ParameterSetName="wcLocalRepUserBaseline")]
    [string[]] $Category,
    
    # Policy filter parameter
    [Parameter(ParameterSetName="wcLocalRepAutoDetect")]
    [Parameter(ParameterSetName="wcLocalRepUserBaseline")]
    [string[]] $Policy,
    
    # Custom filter parameter
    [Parameter(ParameterSetName="wcLocalRepAutoDetect")]
    [Parameter(ParameterSetName="wcLocalRepUserBaseline")]
    [string]$Filter,
    
    [Parameter(ParameterSetName="wcLocalRepAutoDetect")]
    [Parameter(ParameterSetName="wcLocalRepUserBaseline")]
    [string] $ReportFilePath, # optional, report file name with path where WC will save the report (.xml)
    
    [Parameter(ParameterSetName="wcLocalRepAutoDetect")]
    [Parameter(ParameterSetName="wcLocalRepUserBaseline")]
    [ValidateSet("XML", "CSV", "Word", "Excel","CSC_TI","HTML")]
    [string[]] $ReportFormat="XML",

    [Parameter(ParameterSetName="wcLocalRepAutoDetect")]
    [Parameter(ParameterSetName="wcLocalRepUserBaseline")]
    [string] $ReportName = "WinCompliance Report",

    [Parameter(ParameterSetName="wcLocalRepAutoDetect")]
    [Parameter(ParameterSetName="wcLocalRepUserBaseline")]
    [string[]] $ImportModule, #Import additional custom Modules
    
    # inventory collection parameters
    [Parameter(ParameterSetName="wcLocalRepUserBaseline")]
    [Parameter(ParameterSetName="wcLocalRepAutoDetect")]
    [switch] $CollectInventory,

    [Parameter(ParameterSetName="wcLocalRepUserBaseline")] 
    [Parameter(ParameterSetName="wcLocalRepAutoDetect")] 
    [ValidateScript({([System.IO.File]::Exists((resolve-path $_).ProviderPath)) -and $_.trim().split(".")[-1] -eq 'xml'})]
    [string] $InventoryConfigFile,
    
    [Parameter(ParameterSetName="wcLocalRepUserBaseline")]
    [Parameter(ParameterSetName="wcLocalRepAutoDetect")]
    [string[]] $InventoryCategory,

    # optional, inventory file name with path where WC will save the inventory (.xml). defaults to same location where wc report is saved
    [Parameter(ParameterSetName="wcLocalRepAutoDetect")]
    [Parameter(ParameterSetName="wcLocalRepUserBaseline")]
    [string] $InventoryFilePath, 
	
    # inventory collection parameters ends here
	
	[Parameter(ParameterSetName="wcLocalRepAutoDetect")]
    [Parameter(ParameterSetName="wcLocalRepUserBaseline")]
    [Switch] $AutoUpdate,
	
    # ~~~ WC remoting related parameters defined here ~~~#
    
    # One or more remote computer names to run remote WC reporting on
    [Parameter(ParameterSetName="wcRemoteRep")]
    [string[]] $ComputerName, 

    # Credentials to connect to remote computers. If not specified, current users identity is used.
    [Parameter(ParameterSetName="wcRemoteRep")] 
    [pscredential] $ComputerCredential, 
    
    # UNC share (\\server\share) where WinCompliance package is stored. from this share, package will be pushed on remote
    # servers for execution. User launching remote WC reporting must have access to the share as well as write permissions.
    [Parameter(ParameterSetName="wcRemoteRep")]
    [string] $WCRepositoryPath,

    # Credentials to connect to WC Package share. If not specified, current users identity is used.
    [Parameter(ParameterSetName="wcRemoteRep")] 
    [pscredential] $WCRepositoryCredential, 
    
    # A hashtable of report generation script arguments that will be passed to each remote computer for report generation
    [Parameter(ParameterSetName="wcRemoteRep")]
    [hashtable] $Arguments = @{DetectBaseline=$true}, 
    
    # default to WC Reports folder on given share. it must be an UNC path, preferably packageshare. 
    # user lauching the script must have write permissions on the given share to save reports. 
    [Parameter(ParameterSetName="wcRemoteRep")]
    #[string] $ReportSharePath = "$WCRepositoryPath\Reports\WCSCAN\wcremote-$((Get-Date).ToString('MMddyyhhmmss'))", 
    [string] $ReportSharePath = "$WCRepositoryPath", 

    # it tells the script to invoke remote WC process and return the object, do not wait for completion
    [Parameter(ParameterSetName="wcRemoteRep")]
    [switch] $PassThru, 

    [Parameter(ParameterSetName="wcRemoteRep")]
    [int32] $WaitTimeout = 900, # seconds that script will wait for remote jobs to finish execution (15mins default)

    # ~~~ all common parameters across all sets are defined here ~~~ #
    [Parameter(ParameterSetName="wcLocalRepAutoDetect")]
    [Parameter(ParameterSetName="wcLocalRepUserBaseline")]
    #[Parameter(ParameterSetName="wcRemoteRep")]
    [string] $LogFilePath, # altername log file path
    
    [Parameter(ParameterSetName="wcLocalRepAutoDetect")]
    [Parameter(ParameterSetName="wcLocalRepUserBaseline")]
    #[Parameter(ParameterSetName="wcRemoteRep")]
    [ValidateSet("info", "debug")] $LogLevel = 'info',
    
    [Parameter(ParameterSetName="wcLocalRepAutoDetect")]
    [Parameter(ParameterSetName="wcLocalRepUserBaseline")]
    [Parameter(ParameterSetName="wcRemoteRep")]
    [switch] $HideProgress, # bydefault, dialog will be displayed. if user has passed this param then it won't 

    [Parameter(ParameterSetName="wcLocalRepAutoDetect")]
    [Parameter(ParameterSetName="wcLocalRepUserBaseline")]
    [Parameter(ParameterSetName="wcRemoteRep")]
    [switch] $ShowGUIReport # display generated report in GUI window
)
#endregion ScriptParameters

#region local reporting is specified then run thru following code segment
if($PSCmdlet.ParameterSetName -in ('wcLocalRepAutoDetect','wcLocalRepUserBaseline')) { 
    #region ErrorDescriptionVariables
    # Error conditions and return codes
    $wcErrorElevatedPermissionsRequired = "Error: Elevated permissions are required to run WinCompliance."
    $wcErrorBaselineDetectionFailed = "Error: WinCompliance was unable to detect a matching baseline file for {0} version {1}. Ensure that a matching baseline is present on the server"
    $wcErrorBaselineFileNotExists = "Error: WinCompliance was able to detect baseline name ({0}) but the file does not exist."
    $wcErrorServerNotBuiltUsingSOE = "Error: This server is not built using {0}. WinCompliance cannot detect baseline. Specify baeline file as command line argument to run compliance test."
    $wcErrorInvalidBaselineXML = "Error: Invalid baseline XML file specified. Ensure that specified baseline file is in correct format."
    $wcErrorNoPoliciesFound = "Error: No applicable policies were found for processing in given/detected baseline XML file"
    #endregion ErrorDescriptionVariables


    #region scriptVariablesDeclaration
    # set path to various WC folders
    $modulesPath = "$PSScriptRoot\modules"
    $SOEBaselinePath = "$PSScriptRoot\baseline\SOEDefault"
    $logPath = "$PSScriptRoot\logs\$($ENV:COMPUTERNAME)"
    $configPath = "$PSScriptRoot\config"
    $reportsPath = "$PSScriptRoot\reports\$($ENV:COMPUTERNAME)"
    #endregion scriptVariablesDeclaration


    #region LoadWCModules
    # import the module first that sets caller preference (verbose and debug only) (do not change this module sequence!)
    Import-Module "$modulesPath\LogCallerPref.psm1" -Force
    Set-CallerVerbosePreference
    Set-CallerDebugPreference

    #change verbose message background - doesn't work on nano
    #((Get-Host).PrivateData).VerboseBackgroundColor =($host.UI.RawUI).BackGroundColor;

    # load all WC required modules, forcing re-load if they're already loaded
    Import-Module "$modulesPath\WCLogger.psm1" -Force
    Import-Module "$modulesPath\WCUtils.psm1" -Force
    Import-Module "$modulesPath\WCLSP.psm1" -Force
    Import-Module "$modulesPath\WCBaselineHandler.psm1" -Force
    Import-Module "$modulesPath\WCSOEConfig.psm1" -Force
    Import-Module "$modulesPath\WCReportConv.psm1" -Force

    #LoadModules passed via ImportModule Parameter
    foreach($addModule in $ImportModule) {
        if(Test-Path $addModule) { 
            Import-Module $addModule -Force 
        }
    }
    #endregion LoadWCModules
	
	#region Auto Update
	if($AutoUpdate.IsPresent -and (Test-Path $PSScriptRoot\wcAutoUpdate.ps1)) {
		$return = Invoke-Expression "$PSScriptRoot\wcAutoUpdate.ps1"
	}
	#endregion
	
    #region wincompliance return object definition
    # exitcode - { 0=success; 1=failed, 2=no admin rights, 4=unable to detect baseline, 8=detected baseline
    # does not exists; 16=server not built using soe; 32=invalid baseline xml; 64=no applicable policies found }
    # construct a wincompliance return object that will be returned with detailed info
    $wcr = [pscustomobject]@{
      computername=$ENV:COMPUTERNAME # added 8-aug-16 for remote reporting host identification
      exitcode=1
      message=''
      logpath=''
      robject=[pscustomobject]@{
        xmlreport=''
        csvreport=''
        htmlreport=''
        wordreport=''
        excelreport=''
        inventoryreport=''}
    }

    # this function will set properties of wcr return object
    function Set-WCReturnObject {
    param($exitcode, $message, $logpath, $robject)
        if($exitcode) { $wcr.exitcode = $exitcode }
        if($message) { $wcr.message = $message }
        if($logpath) { $wcr.logpath = $logpath }
        if($robject) { $wcr.robject = $robject }
    }
    #endregion wincompliance return object definition

    #region ValidateParameters 
    # check if current user is admin (launched via elevated creds)
    if(-not (Test-IsCurrentUserAdmin)) { 
        Write-Error -Category PermissionDenied -ErrorId wcErrorElevatedPermissionsRequired -Message $wcErrorElevatedPermissionsRequired  
        Set-WCReturnObject -exitcode 2 -message $wcErrorElevatedPermissionsRequired 
        #return $false #$wcErrorElevatedPermissionsRequired
        $wcr # return the exit object
        exit 2 # terminate script
    }
    #note: code to validate whether baseline xml file exist or not is not needed. validation is there in parameter.
    #endregion ValidateParameters


    #region SetLogAndReportPaths
    $timeStamp = $((Get-Date).ToString('MMddyyhhmmss')) # timestamp to add as part of log/report file names
    
    # set report file path/name if user has not specified it. set it at SOE default location
    if(-not $ReportFilePath) { 
        $ReportFilePath = $reportsPath + '\' + (New-WCReportFileName -timeStamp $timeStamp)
    }
    else { # user specified reportfilepath.. if it is folder then set it with auto-created file name
        if((Test-Path -Path $ReportFilePath -PathType Container)) { # user specified a folder
            $ReportFilePath = $ReportFilePath + '\' + (New-WCReportFileName -timeStamp $timeStamp)
        }
    }

    # set inventory file path/name if user has not specified it. set it at SOE default location
    if(-not $InventoryFilePath) { 
        $InventoryFilePath = $reportsPath + '\' + (New-WCReportInventoryFileName -timeStamp $timeStamp)
    }
    else { # user specified reportfilepath.. if it is folder then set it with auto-created file name
        if((Test-Path -Path $InventoryFilePath -PathType Container)) { # user specified a folder
            $InventoryFilePath = $InventoryFilePath + '\' + (New-WCReportInventoryFileName -timeStamp $timeStamp)
        }
    }

    # set report log file path/name if user has not specified it. set it at SOE default location
    if(-not $LogFilePath) { 
        $LogFilePath = $logPath + '\' + (New-WCReportingLogFileName -timeStamp $timeStamp)
    }
    else { # user specified reportfilepath.. if it is folder then set it with auto-created file name
        if((Test-Path -Path $LogFilePath -PathType Container)) { # user specified a folder
            $LogFilePath = $LogFilePath + '\' + (New-WCReportingLogFileName -timeStamp $timeStamp)
        }
    }

    #create report Path if it does not exist
    New-WCUReportPath -ReportPath $reportsPath

    # Remove temporary variables to free up resources
    Remove-Variable -Name timeStamp -ErrorAction SilentlyContinue
    #endregion SetLogAndReportPaths


    #region UpdateRequiredParameterValues
    # if user want script to detect baseline then detect and update appropriate parameter
    if($DetectBaseline) { 
        $sv = $null # by-default soe version is null

        # read keys to get corresponding registry key and value for detection of dssoe/pv-vdi soe
        [xml]$x = Get-Content "$configPath\SOEVersionTable.xml"
        
        switch($DetectionType) {
            'WSSOE' { $sv = Get-SOEVersion } 
            'DSSOE' { 
                $sv = Get-SOEVersion -RegistryPath $x.svt.SOEDetection.DSSOE.RegistryPath -KeyName $x.svt.SOEDetection.DSSOE.KeyName
            } 
            'PVVDISOE' { 
                $sv = Get-SOEVersion -RegistryPath $x.svt.SOEDetection.PVVDISOE.RegistryPath -KeyName $x.svt.SOEDetection.PVVDISOE.KeyName
            }     
        }

        # unable to get SOE version, show error message and quit
        if($sv -eq $null) { 
            write-error -Category InvalidType -ErrorId wcErrorServerNotBuiltUsingSOE -Message ($wcErrorServerNotBuiltUsingSOE -f $DetectionType)
            Set-WCReturnObject -exitcode 16 -message ($wcErrorServerNotBuiltUsingSOE -f $DetectionType)
            $wcr # return the exit object 
            #return $false # $wcErrorServerNotBuiltUsingSOE.Replace('_SOE_',$DetectionType)
            exit 16 # terminate script
        }
        else { # SOE version detected successfully, get baseline file
            # get SOE baseline file for given SOE version
            $wcBcf = Get-WCBaselineFile -SOEVersion $sv -DetectionType $DetectionType -WCConfigFilePath "$configPath\SOEVersionTable.xml"
            if(-not $wcBcf) { # couldn't find a matching baseline file
                Write-Error -Category ObjectNotFound -ErrorId wcErrorBaselineDetectionFailed -Message ($wcErrorBaselineDetectionFailed -f $DetectionType,$sv)
                Set-WCReturnObject -exitcode 4 -message ($wcErrorBaselineDetectionFailed -f $DetectionType,$sv)
                $wcr # return the exit object 
                #return $false # ($wcErrorBaselineDetectionFailed -f $DetectionType,$sv)
                exit 4 # terminate script
            }
            else { # set the baseline file with path of detected baseline
                # before setting it, verify that the file actually exist
                if(-not (Test-WCFileExists -FileName "$SOEBaselinePath\$wcBcf")) {
                    Write-Error -Category ObjectNotFound -ErrorId wcErrorBaselineFileNotExists -Message ($wcErrorBaselineFileNotExists -f "$SOEBaselinePath\$wcBcf")
                    Set-WCReturnObject -exitcode 8 -message ($wcErrorBaselineFileNotExists -f "$SOEBaselinePath\$wcBcf")
                    $wcr # return the exit object 
                    #return $false # $wcErrorBaselineFileNotExists.Replace('_BASELINE_',"$SOEBaselinePath\$wcBcf")
                    exit 8 # terminate script
                }
                else { $BaselineFile = "$SOEBaselinePath\$wcBcf" } # set baseline path when file exists!
            }
        }
    }
    #endregion UpdateRequiredParameterValues


    #region SetLogFile and start logging
    Set-WCLogFile -LogPath $LogFilePath # set log file path
    Set-WCLogLevel -LogLevel $LogLevel # set user given log level, defaults to 'info'
    Write-WCLog -Message "[$($PSCommandPath.Split('\')[-1])]" # script name as log header
    Write-WCLog -Message "WinCompliance report generation script logging started"
    $wcr.logpath = $LogFilePath # set log path in return object 
    #endregion SetLogFile


    #region LogParameterInformation
    if($DetectBaseline) {
        Write-WCLog -Level info -Message "Using auto-detected $DetectionType baseline XML file $BaselineFile" 
    }
    else { 
        Write-WCLog -Level info -Message "Using user provided $DetectionType baseline XML file $BaselineFile" 
    }

    Write-WCLog -Level info -Message "Report generation will run on $($env:ComputerName)"
    
    #todo: add logic to identify local and remote servers and call report generation accordingly
    Write-WCLog -Level info -Message "Report will be saved to $ReportFilePath"
    Write-WCLog -Level info -Message "Logs will be saved to $LogFilePath"

    # determine whether user has specified to collect full inventory or selective (no log of no inventory)
    if($CollectInventory) {
        if($InventoryCategory) { 
            Write-WCLog -Level info -Message "User has specified to process specific inventory categories" 
            Write-WCLog -Level info -Message "$InventoryCategory" 
        }
        else { Write-WCLog -Level info -Message "All inventory categories will be processed" }
    }

    #endregion LogParameterInformation


    #region SetupBaselineXMLVariable and start parsing it
    # read given baseline xml file into variable for manipulation purposes. once done, it will be saved as report file.
    [xml]$bx = Get-Content $BaselineFile
    Set-WCBXMLVariable -BaselineXMLFile $BaselineFile # set baseline xml into Baseline Handler module

    # validate whether given input XML file is in correct format and contain correct fields
    if(-not (Test-WCBaseLineXML)) {
        write-error -Category InvalidData -ErrorId wcErrorInvalidBaselineXML -Message $wcErrorInvalidBaselineXML
        Set-WCReturnObject -exitcode 32 -message $wcErrorInvalidBaselineXML
        $wcr # return the exit object
        #return $false
        exit 32
    }
    #endregion ReadBaselineXMLToVariable


    #region ProcessSpecificPoliciesOrCategories - policies take precedence over categories
    # if user has specified to process specific policies, filter them here, based on Policy ID
    if($Policy) {
        Write-WCLog -Level info -Message "User has specified specific policies to process, getting a list of matching policies"
        $Policies = (Get-WCXMLNodes -Xml $bx -XPath "//Policy" | Where-Object { $_.Processed -eq "False" -and ($Policy -contains $_.Id) }) # return an array

    }
    elseif($Section) { # user has specified to process specific Sections only
	    Write-WCLog -Level info -Message "User has specified specific Sections to process, getting a list of matching policies"
        $Category = (Get-WCXMLNodes -Xml $bx -XPath "//Category" | Where-Object { $Section -contains (Get-WCXMLNodes -Xml $_ -XPath "..").Name }).Name
	
        # get a list of policies to process based on given categories
        $Policies = (Get-WCXMLNodes -Xml $bx -XPath "//Policy" | Where-Object { $_.Processed -eq "False" -and `
            $Category -contains  (Get-WCXMLNodes -Xml $_ -XPath "..").Name})
        #Write-WCLog -Level debug -Message "Sections are: $($Sections.Name -join ',')"
    }
    elseif($Category) { # user has specified to process specific categories only
        Write-WCLog -Level info -Message "User has specified specific categories to process, getting a list of matching policies"
        #$categories = $categories | where { $ProcessCategory -contains $_.Name }
    
        # get a list of policies to process based on given categories
        $Policies = (Get-WCXMLNodes -Xml $bx -XPath "//Policy" | Where-Object { $_.Processed -eq "False" -and `
            $Category -contains (Get-WCXMLNodes -Xml $_ -XPath "..").Name })
        #Write-WCLog -Level debug -Message "Categories are: $($categories.Name -join ',')"
    }
    elseif($Filter) { 
        $Policies = Get-WCXmlFilterNodes -BaselineXml $bx -XmlFilter $Filter
    }
    else { # process all
        # create an array of policies to process, in this case, all un-processed policies
        $Policies = (Get-WCXMLNodes -Xml $bx -XPath "//Policy" | Where-Object { $_.Processed -eq "False" })
        Write-WCLog -Level debug -Message "No policy/category parameters found, processing all (unprocessed) policies"
    }
    #endregion ProcessSpecificPoliciesOrCategories


    #region StartBaselineParsingAndPolicyProcessing
    # see whether the baseline has at least one local security policy baseline
    $isLSPProcessingRequired = Test-WCBaselineIncludesLSP -PolicyList $Policies
    if($isLSPProcessingRequired) {
        Write-WCLog -Level info -Message "Specified/detected baseline includes Local Security Policy items"
        Write-WCLog -Level info -Message "Setting up XML for querying local security policy items"
        $lspXmlFile = Set-WCLSPForQuery  # read LSP policies and convert it and save into an XML file
        #Write-WCLog -Level info -Message "Local security policy is exported and converted into $lspXmlFile"
    }
    else {
        Write-WCLog -Level info -Message "Specified/detected baseline doesn't contain local security policy item, skipping it"
    }

    # enumerate thru categories and process policy items
    Write-WCLog -Level info -Message "Determining applicable policies that need to be processed"

    # Get InterfaceMode - full, core, minShell or nano and filter policicies for processing accordingly
    $InterfaceMode = Get-WCInterfaceMode -ShortName
    #Remove Policies that are not applicable to this interfaceMode
    $Policies = @($Policies | Where-Object { ($_.Runson -eq "All") -or ($_.Runson -like "*$InterfaceMode*") })
    Write-WCLog -Level info -Message "Total $($Policies.Count) policies will to be processed"

    # if no policies are available for processing then log message and exit
    if($Policies.Count -eq 0) { 
        Write-WCLog -Level info -Message "No policies found for porcessing, script will terminate now"
        Write-Error -Category ResourceUnavailable -ErrorId wcErrorNoPoliciesFound -Message $wcErrorNoPoliciesFound
        Set-WCReturnObject -exitcode 64 -message $wcErrorNoPoliciesFound
        $wcr # return the exit object
        #return $false 
        exit 64
    }

    #Expand Environment Strings in Default Value
    Update-WCBEnvironmentVariables $Policies

    $cc = 1 #current policy# out of total policy#. Used for progress tracking
    # loop thru each category and process policies under them
    foreach($pol in $Policies) {
        if(-not $HideProgress) { # user has not specified to hide progress bar, display it
            Write-Progress -Activity "WinCompliance: Processing policies $cc/$($Policies.Count)" `
            -CurrentOperation $pol.PolicyName -PercentComplete ($cc*100/$($Policies.Count))
        }
        # start policy processing for current policy
        Start-WCPolicyProcessing -PolicyNode $pol
        $cc = $cc  + 1 # increase policy count
    }

    #region single policy reporting
    # single policy reporting, return 0/1 without saving anything
    # note that its output may interface with $false we return on errors (and script terminates). To handle this,
    # workflows should check if an error is thrown by this script (in single policy reporting output, no error
    # will be thrown. For above terminating errors (write-error), an error will be thrown along with return $false
    if($Policies.Count -eq 1) { # single policy, return 0/1 without saving anything
        $pol = Get-WCBPolicyByID -PolicyID $Policies[0].Id
        Write-WCLog -Level info -Message "Returning single policy status, report will not be saved."
        Write-WCLog -Level info -Message "Single Policy processed: $($Policies[0].Id) ($($Policies[0].PolicyName)), status $($pol.TestResult)"
        $polMsg = "Single policy processed: {0} ({1}) {2} compliance test" -f $Policies[0].Id, $Policies[0].PolicyName, $pol.TestResult.ToLower()
        if($pol.TestResult -eq 'passed' ) { 
            Set-WCReturnObject -exitcode '0' -message $polMsg 
            $wcr # return the exit object
            exit 0 # exit with success code
        }
        elseif($pol.TestResult -eq 'failed') { 
            Set-WCReturnObject -exitcode 1 -message $polMsg 
            $wcr # return the exit object
            exit 1 # exit with failed code
        }
        else { 
            Set-WCReturnObject -exitcode 128 -message ("Unable to determine status for policy {0}. It may not be applicable to this computer" -f  $Policies[0].Id) 
            $wcr # return the exit object
            exit 128 # exit with undetermined code
        }
        #exit # terminate script for single policy processing
    }
    #endregion single policy reporting

    # call function to set counts for given category
    Get-WCBCategories | ForEach-Object {
        Set-WCBPolicyCounts -NodeType Category -NodeName $_.Name
    }

    # call function to set counts for given sections
    Get-WCBSections | ForEach-Object {
        Set-WCBPolicyCounts -NodeType Section -NodeName $_.Name
    }

    # write report summary in xml
    $hashCfg = "$PSScriptRoot\config\soeDefBaselineHash.xml"
    Update-WCBReportSummary -BaselineFile $BaselineFile -ReportName $ReportName -HashConfigFile  $hashCfg

    # after policy processing is done, get back the processed baseline XML data
    Write-WCLog -Level info -Message "Getting back processed baseline report"
    [xml]$bxProcesseData = Get-WCBXMLVariable
	
	#Remove Policies that are not processed
	$bxProcesseData = Remove-WCUnprocessedNodes -Action "Scan" -wcXML $bxProcesseData
	
    # Update report with log file location for te report. Helpful to identify where was log for this
    # report originally saved
    $bxProcesseData.WinCompliance.LogFile.Path = $LogFilePath

    # save processed baseline results into report file - altered the way of saving it to support nano
    #$bxProcesseData.Save($ReportFilePath)
    $rfile = [System.IO.File]::CreateText($ReportFilePath)
    $bxProcesseData.Save($rfile)
    $rfile.Close()

    Write-WCLog -Level info -Message "Saved report to $ReportFilePath"
    $wcr.robject.xmlreport = $ReportFilePath # set xml report file path in return object
    $rfpDirEntry = (Get-Item $ReportFilePath) # for report gen in other formats below
    #endregion StartBaselineParsingAndPolicyProcessing

    #region produce report in CSV format if specified
    if($ReportFormat -contains 'CSV') {
        Write-WCLog -Level info -Message "CSV report format parameter specified, exporting report in CSV format"

        $htCsvParams = @{
            WCReportFile = $ReportFilePath
            OutputCSVFilePath = ($rfpDirEntry -replace $rfpDirEntry.Extension,'.csv') # use same file name
            OutputCSVSummaryFilePath = ($rfpDirEntry -replace $rfpDirEntry.Extension,'-summary.csv')
        }
        $csvout = Export-WCReportToCSV @htCsvParams
        if($csvout -eq 'export_wc_report_success') { 
            Write-WCLog -Level info -Message ("CSV report exported to {0}" -f $htCsvParams['OutputCSVFilePath'])
            Write-WCLog -Level info -Message ("CSV report summary exported to {0}" -f $htCsvParams['OutputCSVSummaryFilePath'])
            $wcr.robject.csvreport = $htCsvParams['OutputCSVFilePath']
        }
        else {
            Write-WCLog -Level info -Message "Exporting report to CSV format failed with error code $csvout"
        }
    }
    #endregion produce report in CSV format if specified

    #region produce report in HTML format if specified
    if($ReportFormat -contains 'HTML') {
        Write-WCLog -Level info -Message "HTML report format parameter specified, exporting report in HTML format"
        #Export-WCReportToHTML -WCReportFile $a -OutputHTMLFilePath $b
        $htHtmlParams = @{
            WCReportFile = $ReportFilePath
            OutputHTMLFilePath = ($rfpDirEntry -replace $rfpDirEntry.Extension,'.html') # use same file name
        }
        $htmlout = Export-WCReportToHTML @htHtmlParams
        if($htmlout -eq 'export_wc_report_success') { 
            Write-WCLog -Level info -Message ("HTML report exported to {0}" -f $htHtmlParams['OutputHTMLFilePath'])
            $wcr.robject.htmlreport = $htHtmlParams['OutputHTMLFilePath']
        }
        else {
            Write-WCLog -Level info -Message "Exporting report to HTML format failed with error code $htmlout"
        }
    }
    #endregion produce report in HTML format if specified

    #region produce report in Excel format if specified
    if($ReportFormat -contains 'Excel') {
        Write-WCLog -Level info -Message "Excel report format parameter specified, exporting report in Excel format"
        $ex = (Test-COMObjectCreation -ComObject Excel)
        if($ex -eq $false) { 
            Write-WCLog -Level info -Message "Cannot export report to Excel format. Verify that Microsoft Excel is installed on this server"
        }
        else {  #proceed with excel report generation
            $htExcelParams = @{
                WCReportFile = $ReportFilePath
                ExcelFilePath = ($rfpDirEntry -replace $rfpDirEntry.Extension,'.xlsx') # use same file name
            }
            $excelout = Export-WCReportToExcel @htExcelParams
            if($excelout.code -eq 0) { 
                Write-WCLog -Level info -Message ("Excel report exported to {0}" -f $htExcelParams['ExcelFilePath'])
                $wcr.robject.excelreport = $htExcelParams['ExcelFilePath']
            }
            else {
                Write-WCLog -Level info -Message ("Exporting report to Excel format failed. Failure info:`n{0}" -f ($excelout | Out-String))
            }
        }
    }
    #endregion produce report in Excel format if specified

    #region produce report in Word format if specified
    if($ReportFormat -contains 'Word') {
        Write-WCLog -Level info -Message "Word report format parameter specified, exporting report in Word format"
        $ex = (Test-COMObjectCreation -ComObject Word)
        if($ex -eq $false) { 
            Write-WCLog -Level info -Message "Cannot export report to Word format. Verify that Microsoft Word is installed on this server"
        }
        else {  #proceed with Word report generation
            $htWordParams = @{
                WCReportFile = $ReportFilePath
                WordFilePath = ($rfpDirEntry -replace $rfpDirEntry.Extension,'.docx') # use same file name
            }
            $Wordout = Export-WCReportToWord @htWordParams
            if($Wordout.code -eq 0) { 
                Write-WCLog -Level info -Message ("Word report exported to {0}" -f $htWordParams['WordFilePath'])
                $wcr.robject.wordreport = $htWordParams['WordFilePath']
            }
            else {
                Write-WCLog -Level info -Message ("Exporting report to Word format failed. Failure info:`n{0}" -f ($Wordout | Out-String))
            }
        }
    }
    #endregion produce report in Word format if specified

    #region InventoryProcessing
    $callInvCmd = $true #indicate that inventory collection will be performed
    if($CollectInventory) { # inventory collection specified
        if(-not $InventoryConfigFile) {
            if(Test-WCFileExists -FileName "$SOEBaselinePath\wcInventory.xml") {
                $InventoryConfigFile = "$SOEBaselinePath\wcInventory.xml"
            }
            else {
                Write-WCLog -Level warning -Message "Could not find default inventory configuration file $SOEBaselinePath\wcInventory.xml"
                $callInvCmd = $false # inventory will not be collected, config file not found
            }
        }
    }
    else { $callInvCmd = $false } # set it to false if inventory collection is not specified

    # if all inventory collection validation is ok then call function
    if($callInvCmd -eq $true) { 
        Import-Module "$modulesPath\WCBaselineInventoryHandler.psm1" -force  
        # construct a hash table of inventory parameters
        $invParams = @{}
        $invParams.Add('FilePath',$InventoryConfigFile)
        if($InventoryCategory) { $invParams.Add('InventoryCategories',$InventoryCategory) }
        if($HideProgress) { $invParams.Add('HideProgress',$true) }
        # call function to generate inventory based on given params hash
        [xml] $wci = Start-WCInventoryCollection @invParams
     
        $wci.Save($InventoryFilePath) # save inventory
        Write-WCLog -Level info -Message "Inventory data is written to $InventoryFilePath"
        $wcr.robject.inventoryreport = $InventoryFilePath # set inventory file path in return object
    }
    #endregion InventoryProcessing

    #region ShowGUIReport only when format is XML
    if($ShowGUIReport) { 
        if((Get-Item -Path $ReportFilePath).Extension -eq '.XML') { 
            & "$PSScriptRoot\userInterface\psr\WCReportView.ps1" -WCReport $ReportFilePath
        }
        else {
            Write-Warning "Only reports in XML format can be displayed in GUI"
        }
    }
    #endregion ShowGUIReport

    #region TI Reporting
    if($ReportFormat -contains "CSC_TI") { # change from -eq to -contains after $reportFormat is changed to [string[]]
        #Import TI Module
        Import-Module "$PSScriptRoot\Modules\wcTI.psm1" -Force

        Write-WCLog -Level Info -Message "Generating TI Reports for Upload"
	
	    if(Test-Path $InventoryFilePath) {
		    #Command to generate TI report and upload to TI Server - TI Configuration details to be updated in \config\ticonfig.xml
		    $result = New-TIReport -xmlReportFilePath $ReportFilePath -xmlInventoryFilePath $InventoryFilePath -LogFile $LogFilePath;
	    }
	    else {
		    #Command to generate TI report and upload to TI Server - TI Configuration details to be updated in \config\ticonfig.xml
		    $result = New-TIReport -xmlReportFilePath $ReportFilePath  -LogFile $LogFilePath
	    }
        
        #verifying result
        if($result -ne "Success") { 
            Write-WCLog -Level Error -Message $result;
        }

    }
    #endregion

    #return 'return object' that contain detailed info about report generation
    Set-WCReturnObject -exitcode '0' -message 'WinCompliance report generated completed'
    $wcr # return the object at the end
}
#endregion local reporting is specified then run thru following code segment - ends here

#region this segment is for remote WC reporting
elseif($PSCmdlet.ParameterSetName -eq 'wcRemoteRep') {
    $modulesPath = "$PSScriptRoot\modules"
    import-module "$modulesPath\WCRemoteCalls.psm1" -Force # load module for remote execution
	
	#Use Computer Credentials to connect to repository if not passed
	if($wcRepositoryCredential -eq $Null) { $wcRepositoryCredential = $ComputerCredential } 
	
    # now construct command to invoke remote reporting
    $wcrParams = @{}
    $wcrParams.Add('WCRepositoryPath',$WCRepositoryPath)
    if($WCRepositoryCredential) { $wcrParams.Add('WCRepositoryCredential',$WCRepositoryCredential) }
    $wcrParams.Add('Action','scan') # reporting has to be performed
    $wcrParams.Add('WCActionArgs',$Arguments)
    $wcrParams.Add('ComputerName',$ComputerName)
    if($ComputerCredential) { $wcrParams.Add('ComputerCredential',$ComputerCredential) }
    $wcrParams.Add('OutputFolder',$ReportSharePath)
    $wcrParams.Add('WaitTimeout',$WaitTimeout)
    if($PassThru) { $wcrParams.Add('PassThru',$true) }
    if($HideProgress) { $wcrParams.Add('HideProgress',$true) }
    
    # call remote reporting now
    $remResult = Invoke-WCRemoteJob @wcrParams

    # if user has specified to launch GUI report then launch it
    if($ShowGUIReport) {
        $reps = @($remResult.reportpath | Where-Object { $_.length -gt 0 }) # all valid reports only, discard all failed ones
        if($reps.Count -gt 0) { # if there are any valid reports then only show GUI
            & "$PSScriptRoot\userInterface\psr\WCReportView.ps1" -WCReport $reps
        }
        else {
            Write-Warning "No valid report XML files found to display in GUI window"
        }
    }
    # at the end, return the remote reporting return object too
    $remResult
}
#endregion this segment is for remote WC reporting - ends here
else { # highly unlikely, but just let user know something unexpected has happened
    Write-Warning "Unknown parameter set specified, cannot generate WinCompliance report"
}



