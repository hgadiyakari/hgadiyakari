﻿#Author : Hari
#Module that handles wincomplinace autoupdate related functions

#Powershell version prerequisite -  the below comment automatically verifies the ps version
#requires -Version 3.0

#Function to set LogFile
Function Compare-WCAUCompareSource($wcRepository,$wcSource,$ExcludeFileList,$ExcludeFolderList) {
    try {
	
		Write-WCLog -Message "Validating WinCompliance Source"
		$returnVal= Test-WCAUSource -WCSourcePath $wcRepository
        if($returnVal -ne "Success") {
            return $returnVal
        }
		$returnVal= Test-WCAUSource -WCSourcePath $wcSource
        if($returnVal -ne "Success") {
            return $returnVal
        }
		
        Write-WCLog -Message "Identifying Updated Files"
        #Enumerate all files in source and destination exclude files in exclusionlist
        $oSource = Get-ChildItem $wcRepository -Recurse -Exclude $ExcludeFileList -File 
        $dSource = Get-ChildItem $wcSource -Recurse -Exclude $ExcludeFileList -File

        #Filter the folders in exclusion List
        ForEach($oFolder in $ExcludeFolderList) {
            $oSource = $oSource | Where-object { $_.FullName -notlike "*\$oFolder\*" }
            $dSource = $dSource | Where-object { $_.FullName -notlike "*\$oFolder\*" }
        }

        #Find the File Hash - SHA256 by-default
        $oSource = $oSource | ForEach-Object { Get-WCFileHash -Path $_.FullName } 
        $dSource = $dSource | ForEach-Object { Get-WCFileHash -Path $_.FullName } 

        #Identify the difference between source and destnation
        $oDifference = Compare-Object -ReferenceObject $oSource -DifferenceObject $dSource -Property Hash -Passthru

        #Identify the files that has to copied from source 
        $oFilestoReplace =  $oDifference | Where-Object { $_.Path -like "$wcRepository*" } | Select Path

        #get relative Path
        Write-WCLog -Message "Follwoing Files that has to updated from WinCompliance Repository"
        $oFilestoReplace | ForEach-Object { 
            $_.Path = ($_.Path).Replace($wcRepository,"");
            Write-WCLog -Message $_.Path;
         }

        if($oFilestoReplace -eq $null) {
            Write-WCLog -Message "No new updates are available in WinCompliance Repository"
        }

        #return the files that has to be updated
        return @($oFilestoReplace.Path)
    }
    catch { 
        Write-WCLog -Message $_.Exception.Message
        return $Null
    }
}

#Function to validate the version and identify if wc needs update
Function Compare-WCAUVersion($wcRepository) {
    try {
        Write-WCLog -Message "Comparing version to see if the update has to be performed"
        #return variable
        $wcVersion = [pscustomobject]@{
        Status="false";
        repositoryversion='';
        wcclientversion='';
        }

        if(Test-Path "$wcRepository\Config\wcConfig.xml") { 

            #get the version a repository
            [xml] $wcconfig = Get-Content "$wcRepository\Config\wcConfig.xml"
            [version]$RepositoryVersion = $wcConfig.WinCompliance.Version
            $wcVersion.repositoryversion = $RepositoryVersion
            
            #Identify installed version
            [version]$CurrentVersion = (Get-ItemProperty HKLM:\SOFTWARE\CSC\WinCompliance -Name GlobalVersion -ErrorAction SilentlyContinue).GlobalVersion
            $wcVersion.wcclientversion = $CurrentVersion

            if($RepositoryVersion) {  
                if($CurrentVersion) {
                    Write-WCLog -Message "WinCompliance Version in Repository $RepositoryVersion"
                    Write-WCLog -Message "WinCompliance Version in the WC Client $CurrentVersion"

                    #Update the Status Variable with true or false(if repository verion is higher return true ie it needs update)
                    if($RepositoryVersion -gt $CurrentVersion)  { $wcVersion.Status =  "higher" } 
					elseif($RepositoryVersion -lt $CurrentVersion)  { $wcVersion.Status =  "lower" } 
					elseif($RepositoryVersion -eq $CurrentVersion)  { $wcVersion.Status =  "equal" } 
                }
                else {
                    Write-WCLog -Message "Unable to detect the current WC Version Installed on the server"
                }
             }
             else {
                Write-WCLog -Message "Unable to detect the WC Repository Version"
             }
        }
    }
    catch {
         Write-WCLog -Message "Error : $($_.Exception.Message)"
    } 
    return $wcVersion;
}

#Function to update WC Brnadning while performing autoupdate
Function Update-WCAUBranding($wcRepository,$LogFilePath,$wcVersion) {
    try {
		 
         #get todays date for xml updation
         $updatedon = $(get-date).tostring("MM-dd-yy hh:mm:ss");

        if(Test-Path "$wcRepository\Config\wcConfig.xml") { 
            
            #read wc client wcconfig.xml
            [xml] $wcconfig = Get-Content "$psScriptRoot\..\Config\wcConfig.xml"

            #create a new element with update date and version
            $NewUpdate = $wcconfig.CreateElement("UpdateInfo")
            $NewUpdate.SetAttribute("UpdatedVersion",($wcVersion.repositoryversion).ToString())

            $NewUpdate.SetAttribute("UpdatedOn",$updatedon)

            Write-WCLog -Message "Updating WC Config File with Update Branding Information"
			
			if($wcVersion.Status -eq "higher") {
				$wcConfig.WinCompliance.Version = ($wcVersion.repositoryversion).ToString()
				$NewUpdate.SetAttribute("Comments","Product Update");
			}
			else {
				$NewUpdate.SetAttribute("Comments","BaseLine and Custom Modules Update");
			}
			
			$NewUpdate.SetAttribute("LogPath",$LogFilePath);
			
            $wcConfig.WinCompliance.UpdateHistory.AppendChild($NewUpdate);

            #save the wc client xml
            $wcConfig.Save("$psScriptRoot\..\Config\wcConfig.xml");

        }
        else {
            Write-WCLog -Message "Error : Branding is not updated in wcConfig.xml as the file is missing"
        }
        #set version in registry
        #check if path exists
        if(!(Test-Path "HKLM:\SOFTWARE\CSC\WinCompliance")) { New-Item "HKLM:\SOFTWARE\CSC\WinCompliance" -Force }
        #update Branding
		if($wcVersion.Status -eq "higher") {
			Set-ItemProperty "HKLM:\SOFTWARE\CSC\WinCompliance" -Name "GlobalVersion" -Value ($wcVersion.repositoryversion).ToString();
		}
        Set-ItemProperty "HKLM:\SOFTWARE\CSC\WinCompliance" -Name "LastUpdate" -Value $updatedon;

    }
    catch {
        Write-WCLog -Message "Updating WC AutoUpdate branding has failed.$($_.Exception.Message)"
    }    
}

#Function to pdate the WC Source with files from WC repostiory
Function Update-WCAUSource($wcRepository,$wcSource,[string[]] $FilestoReplace) {

    try {
        #Copy each file from repo and replace local source
        foreach($wcFile in $FilestoReplace) {
            #$wcfile is a relative path
            Write-WCLog -Message "Copying $wcFile from WinCompliance Repository to $wcSource"

            #Check whether Destination Directory Exists
            $DirPath = $wcFile.Replace($wcFile.split("\")[-1],"")

            #Create the destination if it doesnt exists
            If(!(Test-Path "$wcSource$DirPath")) {
                New-Item -ItemType Directory -Path "$wcSource$DirPath" -Force | Out-Null
            }

            #Copy Update files from repo to source
            Copy-Item -Path "$wcRepository$wcFile" -Destination "$wcSource$wcFile" -Force -Recurse
        }
        Write-WCLog -Message "Succesfully Update WinCompliance Source"
        return "Success"
    }
    catch {
        Write-WCLog -Message $_.Exception.Message
        return $Null
    }
}

#Function to create a new Scheduled Task to perform auto Update
Function New-WCAUScheduledTask {
Param(
    $TaskName,
    $Command,
    $Description,
    $Trigger,
    $TaskPrincipal
)
    try {
        #Create Scheduled Task for WinCompliance AutoUpdate
        #Create Scheduled Task Action
        $Action = New-ScheduledTaskAction -Execute "PowerShell.exe" -Argument $Command 

        #create a scheduled Ta
        Register-ScheduledTask -Action $Action -Trigger $Trigger -TaskName $TaskName -Description $Description -Principal $TaskPrincipal
        return "Success"
    }
    catch {
        return $_.Exception.Message
    }
    
}

#Function to Validate and update wcrepository details into WCxml
Function Update-WCAUConfigxml { 
Param (
    $wcRepositoryPath,
    $ExcludeDirectories,
    $ExcludeFiles
    )
    try {
        #Check whether wcrepository is a valid repository and current user has read access to the share
        $returnVal= Test-WCAURepostiory -WCRepositoryPath $wcRepositoryPath
        if($returnVal -ne "Success") {
            return $returnVal
        }

        $autoConfigXML = resolve-Path "$PSScriptRoot\..\Config\wcmAutoUpdateClientConfig.xml"
        if(Test-Path $autoConfigXML) {
            [xml]$autoXML = Get-Content $autoConfigXML

            #Update Repository Location
            $autoXML.WCMAutoUpdateConfig.RepositoryLocation.Config.Location = $wcRepositoryPath;

            #Update Directory and File Exclude List
            $CurrentDirExcludeList = $autoXML.WCMAutoUpdateConfig.Settings.ExcludeList.Directory
            $CurrentFileExcludeList = $autoXML.WCMAutoUpdateConfig.Settings.ExcludeList.File

            #Get ExcludeLinstNode
            $ExcludeListNode = $autoXML.SelectSingleNode("//ExcludeList")

            ForEach($exDirectory in $ExcludeDirectories) {
                #check whether directory is already there in exclude list
                if(($CurrentDirExcludeList -contains $exDirectory) -eq $false) {

                     #create a new element to add the directory entry
                     $cExclude = $autoXML.CreateElement("Directory")
                     $cExclude.InnerText = $exDirectory;

                     #Add node to exludelist
                     $ExcludeListNode.AppendChild($cExclude) | Out-Null
                }
            }

            ForEach($exFile in $ExcludeFiles) {
                #check whether directory is already there in exclude list
                if(($CurrentFileExcludeList -contains $exFile) -eq $false) {

                     #create a new element to add the directory entry
                     $cExclude = $autoXML.CreateElement("File")
                     $cExclude.InnerText = $exFile;

                     #Add node to exludelist

                     $ExcludeListNode.AppendChild($cExclude) | Out-Null
                }
            }
            #Save the xml file back
            $autoXML.Save($autoConfigXML);

            return "Success"
        }
        else { 
            return "Unable to detect config\wcAutoupdateClientConfig.xml file"
        }
    }
    catch {
        return $_.Exception.Message
    }
}

#Function check for Valid WinCompliance Repository
Function Test-WCAURepostiory($WCRepositoryPath,$WcSourceFileCheck ="Modules\wcUtils.psm1" ) {

    try {
        #Check whether the current Path is a WC folder in the repository
        if((Test-Path "$WCRepositoryPath\WinCompliance") -eq $false) { #repositoryLocation contains WinCompliance Folder
            return "Error : Unable to detect WinCompliance Source in given repository"
        }

        #check whether you have read permissions on the path
        $autoupdateContent = Get-Content "$WCRepositoryPath\WinCompliance\$WcSourceFileCheck" -ErrorAction SilentlyContinue
        if($autoupdateContent -eq $null) {
            return "Error : Issues with read permissions in repository"
        }

        return "Success"
    }
    catch {
        return $_.Exception.Message
    }
}

#Function check for Valid WinCompliance Repository
Function Test-WCAUSource($WCSourcePath,$WcSourceFileCheck ="Modules\wcUtils.psm1" ) {

    try {
        #check whether you have read permissions on the path
        $autoupdateContent = Get-Content "$WCSourcePath\$WcSourceFileCheck" -ErrorAction SilentlyContinue
        if($autoupdateContent -eq $null) {
            return "Error : Issues with read permissions in repository"
        }

        return "Success"
    }
    catch {
        return $_.Exception.Message
    }
}