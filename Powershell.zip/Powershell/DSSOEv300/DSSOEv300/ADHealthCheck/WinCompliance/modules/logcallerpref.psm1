# This module will only contain functions to set verbose and debug preference as per given preference value. 
# Any script that need to use centralized logging/verbose/debug output need to import this module first
# after import, Set- functions of this module has to be called.
# then after all other modules can be imported and loggin be used

#Powershell version prerequisite -  the below comment automatically verifies the ps version
#requires -Version 3.0

# to enable powershell common parameters, these lines are mandatory
[CmdletBinding()]
Param ()

# This variable will contain caller preference for verbose. call below function only
$verbosePref = "dummy" #its blank, means main function has not called it. 
$debugPref = "dummy" #its blank, means main function has not called it.

# this function will set Verbose prerefence of the calling script
# ---------------------------------------------------------------
function Set-CallerVerbosePreference 
{
[CmdletBinding()]
Param ()
    $script:verbosePref = $PSCmdlet.SessionState.PSVariable.GetValue('VerbosePreference')
}

# this function will return caller script's Verbose preference
# -------------------------------------------------------------
function Get-CallerVerbosePreference { 
    ##write-host "[SetVerbose] returning $($script:callerPref)";
    return $script:verbosePref 
}

# this function will set Debug prerefence of the calling script
# ---------------------------------------------------------------
function Set-CallerDebugPreference 
{
[CmdletBinding()]
Param ()
    $script:debugPref = $PSCmdlet.SessionState.PSVariable.GetValue('DebugPreference')
}

# this function will return caller script's Debug preference
# -------------------------------------------------------------
function Get-CallerDebugPreference { 
    ##write-host "[SetVerbose] returning $($script:callerPref)";
    return $script:debugPref 
}