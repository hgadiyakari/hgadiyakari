﻿##################################################################
#Date      : 17-Mar-2016
#Author    : Harikrishnan GN
#Purpose   : Module to perform TI related actions
#Updated   : 06-may-2016 by Umesh - replaced Get-WMIObject with Get-CIMInstance to support nano

#Powershell version prerequisite -  the below comment automatically verifies the ps version
#requires -Version 3.0

#region general functions
#Function to read config XML and assign it to a script variable
Function Set-TIConfigXML{
Param(
    [ValidateScript({([System.IO.File]::Exists((resolve-path $_).path)) -and $_.trim().split(".")[-1] -eq 'xml'})] $xmlFilePath
    )

    try {
        [xml]$Script:TIXML = get-Content $xmlFilePath
    }
    catch { return $_.Exception.Message }

}

#Function to read config XML and assign it to a script variable
Function Set-TILogFile{
Param(
        $LogFile
    )

    try {
        if((Test-Path $LogFile) -ne $true) {
            New-Item -ItemType File $LogFile -Force | Out-Null;
        }
        $Script:TILogFile = $LogFile
    }
    catch { return $_.Exception.Message }

}

#Function get Date in TI Format
Function Get-TIDateFormat() { 
    Write-WCLog -LogFile $Script:TILogFile -Level debug -Message "[Get-TIDateFormat]"

    $date = Date
    #return date in TI Format yearmonthday-hourminsec all in 00 format
    return "$($($date).Year)$($($date).Month.ToString("00"))$($($date).Day.ToString("00"))-$($($date).Hour.ToString("00"))$($($date).Minute.ToString("00"))$($($date).Second.ToString("00"))";
}

#Function to get Values from TI Config XML
Function Get-TIConfigValues {
    Param (
        [Parameter(Mandatory=$True)] $FieldName,
        $HeaderName
    )
    Write-WCLog -LogFile $Script:TILogFile -Level debug -Message "[Get-TIConfigValues]"

    try {
        if($Script:TIXML -ne $null) {
            $Filter =  $Script:TIXML;

            #If categoryName is passed first filter the result by category Name
            if($HeaderName -ne $Null) {
                $Filter = $Script:TIXML.SelectNodes("//$HeaderName");
                $return =  $($Filter.Config | Where-Object { $_.Name -eq $FieldName }).InnerText;
            }
            else {
                #Filter the result by Configuration to get the required data
                $return =  $($Filter.SelectNodes("//Config") | Where-Object { $_.Name -eq $FieldName }).InnerText;
            }
        }
        #return nill if return value is Null
        if($return -eq $Null) { $return  = "" }
    }
    catch {
        $return = $_.Exception.Message;
        Write-WCLog -LogFile $Script:TILogFile -Level Error -Message $_.Exception.Message;
    }
    return $return;
}

#Function to read IP address of the machine from TI Config XML 
Function Get-TIIPAddr() {
    
    Write-WCLog -LogFile $Script:TILogFile -Level debug -Message "[Get-TIIPAddr]"

    #get IP from xml
    $IP = get-TIConfigValues -FieldName "IPADDRESS"
    
    #get IP of local machine if xml entry is not pupulated
    if($IP -eq "") {
        $IP =  (Get-CimInstance -ClassName Win32_NetworkAdapterConfiguration -Filter 'IPEnabled = True' | Select IPAddress)[0].IPAddress
    }

    #return 0.0.0.0 if IP is still null
    if($IP -eq "") {   $IP = "0.0.0.0" }

    return $IP;
}

#Function to Get TI Domain Name
Function Get-TIDomainName() {
    
    Write-WCLog -LogFile $Script:TILogFile -Level debug -Message "[Get-TIDomainName]"    

    #Get DomainName from XML Config File
    $Domain = get-TIConfigValues -FieldName "DOMAININFO"

    #If Domain Name is not specified in XML then get actual domain Name
    if($Domain -eq "") {
        $Domain = (Get-CimInstance -ClassName win32_computersystem).Domain
    }
    return $Domain
}

#Function to get the file Name in TI Format
Function Get-TIFileName() {
    
    Write-WCLog -LogFile $Script:TILogFile -Level debug -Message "[Get-TIFileName]"

    #Get Account Details from xml
    $Account = get-TIConfigValues -FieldName "ACCOUNTINFO"
    
    #Get the FileName - Datetime-AccountName-IPaddr-hostname-DomainName
    $fileName = "$(get-TIDateFormat)-$Account-$(Get-TIIPAddr)-$(hostname).$(Get-TIDomainName)"
    
    return $fileName;
}

#Function to convert default value or current value to readable string format
Function Get-TIResultValue {
    Param (
    [Parameter(Mandatory=$True)]$PolicyNode,
    $ValueType = "DefaultValue"
    )

    try {
        Write-WCLog -LogFile $Script:TILogFile -Level debug -Message "[Get-TIResultValue]"

        #Identify whether to use currentvalue or defaultvalue
        if($ValueType -eq "DefaultValue") {  $rValue = $PolicyNode.DefaultValue }
        else { $rValue = $PolicyNode.CurrentValue }

        #If valueenumeration field is present join the values with coma and send the result string
        if($rValue.ValueEnumeration -ne $Null) { 
            $result = $rValue.ValueEnumeration -join "," 
        }
        else {  #single value
            $result = $rvalue.Value;
            #check to see if their is a value description field
            if($PolicyNode.ValueDescription.Enum -ne $null) {
                $result = ($PolicyNode.ValueDescription.Enum | Where-Object { $_.Key -eq $rValue.Value }).Value
        }
    }

        #Append the suffix field if avilable
        if(($PolicyNode.ValueDescription.Suffix).Length -gt 0) { $result = "$result $($PolicyNode.ValueDescription.Suffix)" }
    }
    catch {
        $result = $_.Exception.Message
        Write-WCLog -LogFile $Script:TILogFile -Level Error -Message $_.Exception.Message;
    }

    return $result;
}

#endregion

#region function so support TI xml report format
#Function to add Header fields to TI xml Report
Function Add-TIHeadertoXMLReport {
     Param (
        [xml]$ReportXML,
        [System.XML.XMLElement] [ref]$oXMLRoot,
        [System.Xml.XmlDocument] $oXMLDocument
    )
    Write-WCLog -LogFile $Script:TILogFile -Level debug -Message "[Add-TIHeadertoXMLReport]"

    #set audit Node Properties
    $oXMLRoot.SetAttribute("audit",$(($ReportXML.WinCompliance.ReportSummary.RSItem | Where-Object { $_.Name -eq "ReportGenerationDateTime" }).Value))
    $oXMLRoot.SetAttribute("revision",$(Get-TIConfigValues -FieldName "HARDENREVISION"))
    $oXMLRoot.SetAttribute("version",$(Get-TIConfigValues -FieldName "HARDENVERSION"))
    $oXMLRoot.SetAttribute("hostname",$(($ReportXML.WinCompliance.ReportSummary.RSItem | Where-Object { $_.Name -eq "ReportGeneratedOnServer" }).Value))
    $oXMLRoot.SetAttribute("os",$(($ReportXML.WinCompliance.ReportSummary.RSItem | Where-Object { $_.Name -eq "OperatingSystem" }).Value))

    #policyNode
    [System.XML.XMLElement]$oXMLPolicyHeader=$oXMLDocument.CreateElement("Policy")

    #set policy Node Properties
    $oXMLPolicyHeader.SetAttribute("checksum",$(Get-TIConfigValues -FieldName "POLICYCHECKSUM"))
    $oXMLPolicyHeader.SetAttribute("version",$(Get-TIConfigValues -FieldName "POLICYVERSION"))
    $oXMLPolicyHeader.SetAttribute("file",$($ReportXML.WinCompliance.Baseline.SOEInfo.ExpectedValue))
    $oXMLPolicyHeader.InnerText = $(Get-TIConfigValues -FieldName "POLICYNAME")
    $oXMLRoot.appendChild($oXMLPolicyHeader) | Out-Null;

}

Function Add-TICategoryHeadertoXMLReport { 
     Param (
        $Category,
        [System.XML.XMLElement] [ref]$oXMLModule,
        [System.Xml.XmlDocument] $oXMLDocument
    )
    Write-WCLog -LogFile $Script:TILogFile -Level debug -Message "[Add-TICategoryHeadertoXMLReport]"

    $oXMLModule.SetAttribute("version","1.0");
    $oXMLModule.SetAttribute("name","1.0");;
    $oXMLModule.SetAttribute("id",$($($category.Name).ToLower().Replace(' ','_')));
    $oXMLModule.SetAttribute("category",$($Category.ParentNode.Name));
    $oXMLModule.SetAttribute("description","$($Category.ParentNode.Name) - $($Category.Name)");
    $oXMLModule.SetAttribute("severity",$(Get-TIConfigValues -FieldName $($Category.Name) -HeaderName "Severity"));
                        
    #add category result status
    if($($Category.Failed) -gt 0){ $oXMLModule.SetAttribute("status","fail"); }
    else { $oXMLModule.SetAttribute("status","pass"); }

    #add status Node to denote number of tests that failed
    $oXMLStatus = $oXMLDocument.CreateElement("Status")
    $oXMLStatus.SetAttribute("id","fail")
    $oXMLStatus.InnerText = $Category.Failed;
    $oXMLModule.AppendChild($oXMLStatus) | Out-Null;

    #add status Node to denote number of tests that PASSED
    $oXMLStatus = $oXMLDocument.CreateElement("Status")
    $oXMLStatus.SetAttribute("id","pass")
    $oXMLStatus.InnerText = $Category.Passed;
    $oXMLModule.AppendChild($oXMLStatus) | Out-Null;

}

#endregion

#region functions to support TI txt Report
#Function add CategoryHeader to txt TI report
Function Add-TICategoryHeadertoTXTReport {
Param (
    $Category,
    $ReportFilePath   
)
    Write-WCLog -LogFile $Script:TILogFile -Level debug -Message "[Add-TICategoryHeadertoTXTReport]"

    # Information related to Module - Module SUMMARY
    Add-Content $ReportFilePath -Value " ------------------------------------------------------------------------------"
    Add-Content $ReportFilePath -Value "%MODULE: $($($category.Name).ToLower().Replace(' ','_'))"
    Add-Content $ReportFilePath -Value "%MODNAME: 1.0"
    Add-Content $ReportFilePath -Value "%DESCRIPTION: $($Category.ParentNode.Name) - $($Category.Name)"
    Add-Content $ReportFilePath -Value "%CATEGORY: $($Category.ParentNode.Name)"
            
    #add policy checksum and severity realted setting
    Add-Content $ReportFilePath -Value "%POLICY_CHECKSUM: $(Get-TIConfigValues -FieldName "POLICYCHECKSUM")"
    Add-Content $ReportFilePath -Value "%SEVERITY: $(Get-TIConfigValues -FieldName $($Category.Name) -HeaderName "Severity")"
            
    #add category result status
    if($($Category.Failed) -gt 0){ Add-Content $ReportFilePath -Value "%STATUS: Fail" }
    else { Add-Content $ReportFilePath -Value "%STATUS: Pass" }

    Add-Content $ReportFilePath -Value "%STATUSCOUNT: $($Category.Passed)/$($Category.Failed)/0/0/0 (pass/fail/check/exempt/skip)"
    Add-Content $ReportFilePath -Value "";

}

#Function to add Header fields to TI txt Report
Function Add-TIHeadertoTXTReport {
     Param (
        [xml]$ReportXML,
        $ReportFilePath
    )
    Write-WCLog -LogFile $Script:TILogFile -Level debug -Message "[Add-TIHeadertoTXTReport]"

    #Write Header Field in txt report
    #Windows SOE audit Report <harden version>
    Add-Content $ReportFilePath -Value "Windows SOE audit Report $(Get-TIConfigValues -FieldName "HARDENVERSION")"
    Add-Content $ReportFilePath -Value ""

    #Add server attributes      
    Add-Content $ReportFilePath -Value "%HOSTNAME: $(($ReportXML.WinCompliance.ReportSummary.RSItem | Where-Object { $_.Name -eq "ReportGeneratedOnServer" }).Value)";
    Add-Content $ReportFilePath -Value "%OPSYS: $(($ReportXML.WinCompliance.ReportSummary.RSItem | Where-Object { $_.Name -eq "OperatingSystem" }).Value)"
    Add-Content $ReportFilePath -Value "%AUDITDATE: $(($ReportXML.WinCompliance.ReportSummary.RSItem | Where-Object { $_.Name -eq "ReportGenerationDateTime" }).Value)"

    #add ti related attributes
    Add-Content $ReportFilePath -Value "%HARDENVER: $(Get-TIConfigValues -FieldName "HARDENVERSION")($(Get-TIConfigValues -FieldName "HARDENREVISION"))"
    Add-Content $ReportFilePath -Value "%POLICY_NAME: $(Get-TIConfigValues -FieldName "POLICYNAME")"
    Add-Content $ReportFilePath -Value "%POLICY_VERSION: $(Get-TIConfigValues -FieldName "POLICYVERSION")"
    Add-Content $ReportFilePath -Value "%POLICY_CHECKSUM: $(Get-TIConfigValues -FieldName "POLICYCHECKSUM")"
    Add-Content $ReportFilePath -Value "%POLICY_FILE:  $($ReportXML.WinCompliance.Baseline.SOEInfo.ExpectedValue)"

}

#endregion

#region functions to build xml,txt,inventory,autoconfig reports and Push reports to TI
#Function to generate txt report format for TI
Function New-TIHardenTXTReport {
    Param (
        [xml]$ReportXML,
        $ReportFilePath
    )
    Write-WCLog -LogFile $Script:TILogFile -Message "[New-TIHardenTXTReport]"

    try {

        #Remove report file if exists and create a new One
        if(Test-Path $ReportFilePath) { Remove-Item $ReportFilePath -Force; } 
        New-Item -ItemType File -Path $ReportFilePath -Force | Out-Null;

        Write-WCLog -LogFile $Script:TILogFile -Level debug -Message "Adding WC header to TI text Report"
        Add-TIHeadertoTXTReport -ReportXML $ReportXML -ReportFilePath $ReportFilePath;

        #Add Module related entries
        $colCategory = $ReportXML.SelectNodes("//Category") | Where-Object { $_.PolicyCount -gt 0 }
        Foreach($Category in $colCategory) {
            
            #Add category header to txt report
            Write-WCLog -LogFile $Script:TILogFile -Level debug -Message "Adding WC Category Header to TI text Report"
            Add-TICategoryHeadertoTXTReport -ReportFilePath $ReportFilePath -Category $Category;
            
            #Information related to Policy
            $colPolicy  = $Category.Policy | Where-Object {$_.Processed -eq "True" }
            Write-WCLog -LogFile $Script:TILogFile -Level debug -Message "Adding PolicyResults to TI text Report"

            foreach($Policy in $colPolicy) {
                Write-WCLog -LogFile $Script:TILogFile -Level debug -Message "Adding PolicyResults for $($Policy.Name)"
                #add information about each policy
                if($Policy.TestResult -eq "Passed") {
                    Add-Content $ReportFilePath -Value "%PASS $($Policy.PolicyName) is currently set to '$(Get-TIResultValue -PolicyNode $Policy -ValueType "CurrentValue")' (ok)";
                }
                else {
                    Add-Content $ReportFilePath -Value "%FAIL $($Policy.PolicyName) is currently set to '$(Get-TIResultValue -PolicyNode $Policy -ValueType "CurrentValue")'(bad),(should be '$(Get-TIResultValue -PolicyNode $Policy)')";
                }
            }
        }
        $return = "Success";
    }
    catch {
        $return = $_.Exception.Message ;
        Write-WCLog -LogFile $Script:TILogFile -Level Error -Message $_.Exception.Message;
    }
    return $return;
}

#Function to generate xml report format for TI
Function New-TIHardenXMLReport {
    Param (
        [xml]$ReportXML,
        $ReportFilePath,
        [Switch] $Summary #dont write policy realted entries to xm lif summary switch is passed
    )

    try {
        Write-WCLog -LogFile $Script:TILogFile -Message "[New-TIHardenXMLReport]"

        [System.XML.XMLDocument]$oXMLDocument=New-Object System.XML.XMLDocument
        [System.XML.XMLElement]$oXMLRoot=$oXMLDocument.CreateElement("Audit")
    
        [System.XML.XmlDeclaration] $xmldecl | Out-Null;
        $xmldecl = $oXMLDocument.CreateXmlDeclaration("1.0",$null,$null);

        # Append as child to an existing node
        $oXMLDocument.appendChild($oXMLRoot) | Out-Null;

        #add declaration before rootNode
        $oXMLDocument.InsertBefore($xmldecl, $oXMLRoot) | Out-Null;
        
        Write-WCLog -LogFile $Script:TILogFile -Level debug -Message "Adding WC Header to TI XML Report"
        $ret = Add-TIHeadertoXMLReport -ReportXML $ReportXML -oXMLRoot ([ref] $oXMLRoot) -oXMLDocument $oXMLDocument
        
        [System.XML.XMLElement]$oXMLModule;
        $colCategory = $ReportXML.SelectNodes("//Category") | Where-Object { $_.PolicyCount -gt 0 }
        Foreach($Category in $colCategory) {

            # Information related to Module - Module SUMMARY
            $oXMLModule = $oXMLDocument.CreateElement("Module")
            
            Write-WCLog -LogFile $Script:TILogFile -Level debug -Message "Adding WC Category Header to TI XML Report"
            $ret = Add-TICategoryHeadertoXMLReport -Category $Category -oXMLModule ([ref] $oXMLModule) -oXMLDocument $oXMLDocument

            if($Summary.IsPresent -ne $true) { #Summary xml  will not have policy realted entries
                #PolicyID is added to check ID field if generic PolicyID is not populated in xml field
                $genericpolID = $(Get-TIConfigValues -FieldName "POLICYID")

                #Information related to Policy
                $colPolicy  = $Category.Policy | Where-Object {$_.Processed -eq "True" }

                Write-WCLog -LogFile $Script:TILogFile -Level debug -Message "Adding PolicyResults to XML Report"
                foreach($Policy in $colPolicy) {
                    
                    Write-WCLog -LogFile $Script:TILogFile -Level debug -Message "Adding PolicyResults for $($Policy.Name)"
                    $oXMLCheck = $oXMLDocument.CreateElement("Check")
                    $oXMLCheck.SetAttribute("object",$Policy.PolicyName)

                    #generic ID is used in TI if policy IDs are not configured in TI
                    if($genericpolID.length -gt 0) {
                        $oXMLCheck.SetAttribute("checkid",$genericpolID)
                    }
                    else {
                        $oXMLCheck.SetAttribute("checkid",$Policy.Id)
                    }

                    #add information about each policy / pass failed and the policy default and current value
                    if($Policy.TestResult -eq "Passed") {
                        $oXMLCheck.SetAttribute("status","PASS")
                        $oXMLCheck.InnerText =  "$($Policy.PolicyName) is currently set to '$(Get-TIResultValue -PolicyNode $Policy -ValueType "CurrentValue")' (ok)";
                    }
                    else {
                        $oXMLCheck.SetAttribute("status","FAIL")
                        $oXMLCheck.InnerText ="$($Policy.PolicyName) is currently set to '$(Get-TIResultValue -PolicyNode $Policy -ValueType "CurrentValue")'(bad),(should be '$(Get-TIResultValue -PolicyNode $Policy)')";
                    }
                    #add the check node as child to module Node
                    $oXMLModule.appendChild($oXMLCheck) | Out-Null;
                }
            }
            #add module node as child to root Node
            $oXMLRoot.appendChild($oXMLModule) | Out-Null;
        }
        #save the file toreportFilePath
        $oXMLDocument.Save($ReportFilePath) | Out-Null;
        $return  = "Success";
    }
    catch {
        $return = $_.Exception.Message
        Write-WCLog -LogFile $Script:TILogFile -Level Error -Message $_.Exception.Message
    }
    return $return;
}

#Function to generate xml report format for TI
Function New-TIAutoconfigReport {
    Param (
        [xml]$ReportXML,
        $ReportFilePath
    )
    try {
        Write-WCLog -LogFile $Script:TILogFile -Message "[New-TIAutoconfigReport]"

        #Remove report file if exists and create a new One
        if(Test-Path $ReportFilePath) { Remove-Item $ReportFilePath -Force; } 
        New-Item -ItemType File -Path $ReportFilePath -Force | Out-Null;

        #Add content to patch info report
        Add-Content $ReportFilePath -Value "%%%%%%%% PATCHINFO `$Revision: 1.10 $ %%%%%%%%"
        Add-Content $ReportFilePath -Value "ScanDate: 2016 03 14 04 52"
        Add-Content $ReportFilePath -Value "OperatingSystem: Microsoft Windows"
        Add-Content $ReportFilePath -Value "OperatingSystemVersion: $(($ReportXML.WinCompliance.ReportSummary.RSItem | Where-Object { $_.Name -eq "OperatingSystem" }).Value)"
        Add-Content $ReportFilePath -Value "%%%%%%%% FINISHED `$Revision: 1.10 $ %%%%%%%%"
        $return = "Success";
    }
    catch {
        $return = $_.Exception.Message
        Write-WCLog -LogFile $Script:TILogFile -Level Error -Message $_.Exception.Message
    }
    return $return;
}

#Function to genrerate HTML report for TI
Function New-TIHTMLReport {
        Param (
        [xml] $ReportXML,
        [xml]$InventoryXML,
        $ReportFilePath
    )
    try {
        $report = @();
        Write-WCLog -LogFile $Script:TILogFile -Message "[New-TIHTMLReport]"

        #Collect Inventory Item Name
        $colinvItem = $InventoryXML.SelectNodes("//InventoryItem").Name | Select -Unique
        
        #Create a header and add the header 
        Write-WCLog -LogFile $Script:TILogFile -Level debug -Message "Creating WC Header Table"
        $report += "<table><th>WinCompliance TI Inventory Report</th> `
                    <tr><td>TEST PERFORMED ON : $(($ReportXML.WinCompliance.ReportSummary.RSItem | Where-Object { $_.Name -eq "ReportGenerationDateTime" }).Value) `
                    <tr><td>SERVER : $(($ReportXML.WinCompliance.ReportSummary.RSItem | Where-Object { $_.Name -eq "ReportGeneratedOnServer" }).Value)</td></tr> `
                    <tr><td>$(($ReportXML.WinCompliance.ReportSummary.RSItem | Where-Object { $_.Name -eq "OperatingSystem" }).Value)</td></tr> `
                    <table><br>"

        #create Index Table <a href=inventory categoryname
        Write-WCLog -LogFile $Script:TILogFile -Level debug -Message "Creating WC Index Table"
        [string] $htmlIndex = "<table><th>Index</th>";
        foreach($invItem in $colInvItem) {
            #create index for each inventoryItem Tag
            $htmlIndex +=  "<tr><td><a href=#$($invItem.Replace(' ',''))>$($invItem.Replace(' ',''))</a></td></tr>"
        }
        $htmlIndex += "</table>"

        #append Index table to report variable
        $report += $htmlIndex;

        #Create Individual table for each InventoryItem and keep appending to report  variable
        Foreach($invItem in $colinvItem) {
            #create tag for index table
            $report += "<a name=$($invItem.Replace(' ',''))></a>"

            #create Individual table for Inventory Item
            Write-WCLog -LogFile $Script:TILogFile -Level debug -Message "Creating Table for Inventory Item $invItem"
            $report += "<br><table><th>$invItem</th></table>"
            $invName = $InventoryXML.SelectNodes("//$($invItem.Replace(' ',''))");
			
			if($invName.Count -gt 0) {
				#append the new table to report variable
				$report += $invName |  Select ($invName | Get-Member -MemberType Property).Name |  Convertto-Html -Fragment
			}
        }

        #Define the style
        $head = "<style>"
        $head = $head + "TABLE{width: 100%;background-color:lightblue;padding: 5px;border-width: 1px;border-style: solid;border-color: black;border-collapse: collapse;}"
        $head = $head + "TH{border-width: 1px;padding: 2px;border-style: solid;border-color: black;}"
        $head = $head + "TD{border-width: 1px;padding: 0px;border-style: solid;border-color: white;}"
        $head = $head + "</style>"

        #Save the html report to reportfile location
        $return = Convertto-html -Body "$report" -Title "WC Inventory Report" -Head $head  | Out-File $ReportFilePath

        $return = "Success"
    }
    catch {
        $return = $_.Exception.Message
        Write-WCLog -LogFile $Script:TILogFile -Level Error -Message $_.Exception.Message
    }
    return $return;
}

#Function to remove files after upload
Function Remove-TIResultFiles {
    Param (
        $TIFileName,
        $TIReportFolder
    )
    try {
        Write-WCLog -LogFile $Script:TILogFile -Message "[Remove-TIResultFiles]"

        #Remove Files after Upload if specified in xml
        if($(Get-TIConfigValues -FieldName "DELRESFILE") -eq "YES") {
             Write-WCLog -LogFile $Script:TILogFile -Level debug -Message "Deleting hardentxt,hardenxml,patchinfo,winconfig files"

            "harden-hardentxt","harden-hardenxml","auto_config-patchinfo","auto_config-winconfig" | `
                     foreach-Object { 
                        if(Test-Path "$TIReportFolder\$($_)-$($TIFileName).dat") {
                            Remove-Item "$TIReportFolder\$($_)-$($TIFileName).dat" -Force
                        }
                     } 
        }

        #remove summary file if enabled in XML
        if($(Get-TIConfigValues -FieldName "DELSUMMARYFILE") -eq "YES") {
            Write-WCLog -LogFile $Script:TILogFile -Level debug -Message "Deleting hardensummary file"
            
            if(Test-Path "$TIReportFolder\harden-hardensum-$($TIFileName).dat") {
                Remove-Item -Path "$TIReportFolder\harden-hardensum-$($TIFileName).dat" -Force
            }
        }
        #remove the answer file if exists
        if(Test-Path  "$TIReportFolder\Answer.txt") {
            Remove-Item -Path "$TIReportFolder\Answer.txt" | Out-Null
        }

        $return = "Success";
    }
    catch {
        $return = $_.Exception.Message;
    }
    return $return
}

#Function to upload reports to TI Server
Function Push-TIReport {
Param (
        $TIFilestoTransfer,
        $TIReportFolder
    )

    try {
        Write-WCLog -LogFile $Script:TILogFile -Message "[Push-TIReport]"
        #fso
        #pscp will not support Long Names so findout shortPath using FSO
        $FSO = New-Object -ComObject Scripting.FileSystemObject
        $TIReportPath = $FSO.getfolder($TIReportFolder).ShortPath;

        #check for the existance of pscp.exe
        if(Test-Path "$psScriptRoot\..\bin\pscp.exe"){
            
            #pscppath  ShortPath
            $PSCPPath = Resolve-path "$psScriptRoot\..\bin"
            $PSCPPath = "$($FSO.GetFolder($PSCPPath).ShortPath)\pscp.exe";

            #ti server
            $TIServerIP = $(Get-TIConfigValues -FieldName "TISERVERIP")
            if($TIServerIP -eq $Null) { 
                Write-WCLog -LogFile $Script:TILogFile -Level debug -Message "TI Server IP Not populated in XML"
                return "TIServer IP not populated" 
            }

            #Test Connectiont to TI Server
            if(Test-Connection $TIServerIP -Count 2) {
                
                #Get Credentials from Config File
                $UserName = $(Get-TIConfigValues -FieldName "TIUSERNAME")
                $Password = $(Get-TIConfigValues -FieldName "TIPASSWORD")
                $UploadPath= $(Get-TIConfigValues -FieldName "TIUPLOADPATH")

                #ppk file
                $PPKFile = $(Get-TIConfigValues -FieldName "PPKFile")

                #if absolute path is added pointing to root of WC source give the resolve-path
                if($PPKFile.subString(0,2) -eq "\") { $PPKFile = Resolve-Path ("$psScriptRoot\..$PPKFile") }

                #a string Y has to be passed as a part of command prompt to pscpexe
                "Y" | Out-File "$TIReportFolder\Answer.txt"

                Write-WCLog -LogFile $Script:TILogFile -Message "Uploading results to TI Server $TIServerIP"

                #Test-Whether $PPKFile is present
                if(Test-Path $PPKFile) {
                    
                    #find shortPath to the ppk file
                    $PPKFileName =  $PPKFile.Split("\")[-1] ;
                    $PPKFile = "$($FSO.GetFolder($PPKFile.Replace($PPKFileName,'')).ShortPath)\$PPKFileName"

                    #transfer each file using PPK File
                    ForEach($FileName in $TIFilestoTransfer) {
                        #Build the Command
                        $exp = "cmd /c $PSCPPath -i $PPKFile $TIReportPath\$FileName $UserName@$TIServerIP" + ':' + "$UploadPath ``< $TIReportFolder\Answer.txt"
                        
                        #Run the Command
                        Write-WCLog -LogFile $Script:TILogFile -Message "Uploading $FileName"
                        Write-WCLog -LogFile $Script:TILogFile -Level debug -Message "$exp"

                        $result = Invoke-Expression $exp;

                        #If 100% is not present in result some file upload has failed
                        if(($result -match "100%") -eq $null) {
                            $return = "File Upload Failed : $FileName" 
                        }
                        else { 
                            Write-WCLog -LogFile $Script:TILogFile -Message "Succesfully Uploaded" 
                        }
                    
                    }
                }
                else {
                    #Transfer the files using password
                    ForEach($FileName in $TIFilestoTransfer) {
                        #Build the Command
                        $exp = "cmd /c $PSCPPath -pw $Password $TIReportPath\$FileName $UserName@$TIServerIP" + ':' + "$UploadPath ``< $TIReportFolder\Answer.txt"
                        
                        #Run the Command
                        Write-WCLog -LogFile $Script:TILogFile -Message "Uploading $FileName"
                        Write-WCLog -LogFile $Script:TILogFile -level debug -Message "cmd /c $PSCPPath -pw !!!!!!!!! $TIReportPath\$FileName $UserName@$TIServerIP``:$UploadPath ``< $TIReportFolder\Answer.txt"

                        $result = Invoke-Expression $exp;

                        #If 100% is not present in result some file upload has failed
                        if(($result -match "100%") -eq $null) {
                            $return = "File Upload Failed : $FileName" 
                        }
                        else { 
                            Write-WCLog -LogFile $Script:TILogFile -Message "Succesfully Uploaded" 
                        }
                    }
                }
                if($return -eq $Null) { $return = "Success" }
            }
            else { 
                Write-WCLog -LogFile $Script:TILogFile -level Error -Message "TI Server $TIServerIP Not reachable"
                $return = "TI Server $TIServerIP Not reachable" 
            }
        }
        else {
            Write-WCLog -LogFile $Script:TILogFile -level Error -Message "$psScriptRoot\..\bin\pscp.exe is missing"
            $return = "$psScriptRoot\..\bin\pscp.exe is missing"
        }
    }
    catch {
        $return = $_.Exception.Message;
        Write-WCLog -LogFile $Script:TILogFile -level Error -Message $_.Exception.Message
    }
    return $return;
}
#endregion

#Function to Kick Start TI Report Generation and Upload
Function New-TIReport { 
    Param(
        [Parameter(Mandatory="True")][ValidateScript({([System.IO.File]::Exists((resolve-path $_).path)) -and $_.trim().split(".")[-1] -eq 'xml'})] $xmlReportFilePath,
        [ValidateScript({([System.IO.File]::Exists((resolve-path $_).path)) -and $_.trim().split(".")[-1] -eq 'xml'})] $xmlInventoryFilePath,
        [ValidateScript({([System.IO.File]::Exists((resolve-path $_).path)) -and $_.trim().split(".")[-1] -eq 'xml'})] $xmlTIConfigFilePath,
        $TIReportFolder,
        $LogFile
    )
    try {
        #Set TI Config file to default location if not passed
        if($xmlTIConfigFilePath -eq $Null) {
            $xmlTIConfigFilePath = (Resolve-Path "$psScriptRoot\..\config\ticonfig.xml").path
        }

		#Set TI report folder to Logs folder if not passed
		if($TIReportFolder -eq $Null) { 
			$TIReportFolder = Resolve-Path "$psScriptRoot\..\";
			$TIReportFolder = "$TIReportFolder\TIReport" 
		}
		
        #Set Global Variable for TI XML
        Set-TIConfigXML -xmlFilePath $xmlTIConfigFilePath;

        #generate filename format for TI
        $TIFileName = $(Get-TIFileName)
        $FileList = @();

        If($LogFile -eq $Null) {
            $LogFile = "$TIReportFolder\$($TIFileName).log"
        }
        #Create Script Variable for Log File
        Set-TILogFile -LogFile $LogFile;

        Write-WCLog -LogFile $Script:TILogFile -Message "[New-TIReport]"

        #read xml report
        Write-WCLog -LogFile $Script:TILogFile -Level debug -Message "Reading $xmlReportFilePath"
        [xml]$ReportXML = Get-Content $xmlReportFilePath;

        #create TI report Folder if doesnt exists
        if((Test-Path $TIReportFolder) -eq $false) { New-Item -ItemType Directory -Path $TIReportFolder -Force; }

        #BuildAuto Config Report
        Write-WCLog -LogFile $Script:TILogFile -Message "Creating AutoConfig Report"
        $return = New-TIAutoconfigReport -ReportXML $ReportXML -ReportFilePath "$TIReportFolder\auto_config-patchinfo-$($TIFileName).dat"
        
        if($return -ne "success") {
            Write-WCLog -LogFile $Script:TILogFile -level Error -Message $return;
            return "Error Creating Auto Config Patch info Report : $return" 
        }

        #append filename to the list of files to be sent toTI
        $FileList += "auto_config-patchinfo-$($TIFileName).dat"
        Write-WCLog -LogFile $Script:TILogFile -Message "AutoConfig File is created succesfully";
        
        #Build Harden xml report
        Write-WCLog -LogFile $Script:TILogFile -Message "Creating Harden XML Report"
        $return = New-TIHardenXMLReport -ReportXML $ReportXML -ReportFilePath "$TIReportFolder\harden-hardenxml-$($TIFileName).dat"
        
        if($return -ne "success") {
            Write-WCLog -LogFile $Script:TILogFile -level Error -Message $return;
             return "Error Creating Harden XML Report : $return" 
        }

        #append filename to the list of files to be sent toTI
        $FileList += "harden-hardenxml-$($TIFileName).dat"
        Write-WCLog -LogFile $Script:TILogFile -Message "Hardenxml File is created succesfully";

        #Build Harden report Summary
        Write-WCLog -LogFile $Script:TILogFile -Message "Creating Harden Summary Report"
        $return = New-TIHardenXMLReport -Summary -ReportXML $ReportXML -ReportFilePath "$TIReportFolder\harden-hardensum-$($TIFileName).dat"
        
        if($return -ne "success") {
            Write-WCLog -LogFile $Script:TILogFile -level Error -Message $return;
            return "Error Creating Harden Summary Report : $return" 
        }

        #append filename to the list of files to be sent toTI
        $FileList += "harden-hardensum-$($TIFileName).dat"
        Write-WCLog -LogFile $Script:TILogFile -Message "Harden Summary File is created succesfully";

        #Build harden txt Report
        Write-WCLog -LogFile $Script:TILogFile -Message "Creating Harden Text Report"
        $return = New-TIHardenTXTReport -ReportXML $ReportXML -ReportFilePath "$TIReportFolder\harden-hardentxt-$($TIFileName).dat"
        
        if($return -ne "success") { 
            Write-WCLog -LogFile $Script:TILogFile -level Error -Message $return;
            return "Error Creating Harden TXT Report : $return" 
        }

        #append filename to the list of files to be sent toTI
        $FileList += "harden-hardentxt-$($TIFileName).dat";
        Write-WCLog -LogFile $Script:TILogFile -Message "HardenTxt File is created succesfully";

        #Build InventoryReport
        if($xmlInventoryFilePath -ne $Null) {
            if(Test-Path $xmlInventoryFilePath) { 
                Write-WCLog -LogFile $Script:TILogFile -Message "Creating Inventory Report"
                [xml]$InventoryXML = Get-Content $xmlInventoryFilePath;
                
                $return = New-TIHTMLReport -ReportXML $ReportXML -InventoryXML $InventoryXML -ReportFilePath "$TIReportFolder\auto_config-winconfig-$($TIFileName).dat"
                
                if($return -ne "success") { 
                    Write-WCLog -LogFile $Script:TILogFile -level Error -Message $return;
                    return "Error Creating Harden HTML Report : $return"
                }

                #append filename to the list of files to be sent toTI
                $FileList += "auto_config-winconfig-$($TIFileName).dat"
                Write-WCLog -LogFile $Script:TILogFile -Message "Inventory File is created succesfully";
            }
        }

        #Upload report to TI Server
        Write-WCLog -LogFile $Script:TILogFile -level debug -Message "Push the reports to TI"
        $return = Push-TIReport -TIFilestoTransfer $FileList -TIReportFolder $TIReportFolder
        Write-WCLog -LogFile $Script:TILogFile -Message $return;

        #Remove the files created upload based on xml defenitions
        Write-WCLog -LogFile $Script:TILogFile -level debug -Message "Cleanup TI reports"
        $return = Remove-TIResultFiles -TIFileName $TIFileName -TIReportFolder $TIReportFolder
        Write-WCLog -LogFile $Script:TILogFile -Message $return;
    }
    Catch {
        $result = $_.Exception.Message
        Write-WCLog -LogFile $Script:TILogFile -level Error -Message $_.Exception.Message;
    }
    return $return;
}