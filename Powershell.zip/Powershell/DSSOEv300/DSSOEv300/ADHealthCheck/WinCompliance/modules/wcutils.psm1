﻿# This script module contains functions related to performing various system checks like file system, registry
# services, disk, network, server roles and many more. 
# Name   : WCUtils.psm1
# Author : Umesh Thakur
# Date   : 10-Nov-2014
# Updated: 04-nov-2015 by Umesh - added functions related to local account enablement/disablement
# Updated: 22-mar-2016 by Umesh -  added functions related to local account inventory collection (as per query and request received from BizCloud HC)
# Updated: 05-may-2016 by Umesh - Updated different methods of calling SelectNodes XML method in order to support Nano
# Updated: 05-may-2016 by Umesh - replaced Get-WMIObject with Get-CIMInstance to support nano
# Updated: 12-jul-2016 by Umesh - added function to test for word/excel COM object creation (used in exporting report to excel/word format)
# Updated: 08-aug-2016 by Umesh - updated report/log file name generator functions to use computername as prefix
# Updated: 20-oct-2016 by Umesh - added Get-WCFileHash function to compute file hash using native .net methods (to support downlevel clients like w2k8r2, w2k12)
#Powershell version prerequisite -  the below comment automatically verifies the ps version
#requires -Version 3.0

#region module level variables
# detect if running on nano. if yes then use different set of xml function call
# 143/144 are for Nano server 
$OSSKU = (get-ciminstance -ClassName win32_operatingsystem).operatingsystemSKU
#endregion module level variables


#region logFileRelatedFunctions
# this function will return reporting log file name generated on given date/time stamp. 
# -------------------------------------------------------------------------------------
Function New-WCReportingLogFileName($timeStamp) {  
    return ($env:COMPUTERNAME + '-wcs-' + $timeStamp + '.log')
}
# this function will return reporting log Folder name generated on given date/time stamp. 
# -------------------------------------------------------------------------------------
Function New-WCRemediationLogFolderName($timeStamp) {  
    return ($env:COMPUTERNAME + '-wcr-' + $timeStamp)
}
# this function will return remediation log file name generated on given date/time stamp.
# ---------------------------------------------------------------------------------------
Function New-WCRemediationLogFileName($timeStamp) { 
    return ($env:COMPUTERNAME + '-wcr-' + $timeStamp + '.log')
}

# this function will return reporting file name generated on given date/time stamp. 
# ---------------------------------------------------------------------------------
Function New-WCReportFileName($timeStamp) { 
     return ($env:COMPUTERNAME + '-wcs-' + $timeStamp + '.xml')
} 

# this function will return remediation  file name generated on given date/time stamp.
# ---------------------------------------------------------------------------------------
Function New-WCRemediationFileName($timeStamp) { 
    return ($env:COMPUTERNAME + '-wcr-' + $timeStamp + '.xml')
}

# this function will return inventory file name generated on given date/time stamp. 
# ---------------------------------------------------------------------------------
Function New-WCReportInventoryFileName($timeStamp) { 
     return ($env:COMPUTERNAME + '-wci-' + $timeStamp + '.xml')
}

#this function will create reports path for both remediatin and scan
Function New-WCUReportPath($ReportPath) {
	if((Test-Path $ReportPath) -eq $false) {
		New-Item -ItemType Directory -Path $ReportPath -Force | Out-Null
	}
}
#endregion logFileRelatedFunctions


#region systemFunctions
# function to return whether current user is admin or not
# --------------------------------------------------------
Function Test-IsCurrentUserAdmin {
    $myIdentity = [System.Security.Principal.WindowsIdentity]::GetCurrent()
    $wp = New-Object Security.Principal.WindowsPrincipal($myIdentity)
    if (-not $wp.IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)) {
        return $false # current user has no administrative rights
    }
    else { return $true } # current user is admin
}

# This function will convert given SID value to corresponding account name.
# --------------------------------------------------------------------------
Function Get-SIDToUserName($SIDValue) {
    try {
        $objSID = New-Object System.Security.Principal.SecurityIdentifier($SIDValue)
        $objUser = $objSID.Translate( [System.Security.Principal.NTAccount])
        return $objUser.Value
    }
    catch { #[System.Security.Principal.IdentityNotMappedException] {
        Write-WCLog -Level debug -Message "[Get-SIDToUSerName] ($SIDValue) - $($_.Exception.Message)"
        return $null
    }
}

# This function will convert given account name value to corresponding SID .
# --------------------------------------------------------------------------
Function Get-UserNameToSID($AccountName) {
    try {
        $objUser = New-Object System.Security.Principal.NTAccount($AccountName)
        $objSID = $objUser.Translate( [System.Security.Principal.SecurityIdentifier])
        return "*$($objSID.Value)";
    }
    catch { #[System.Security.Principal.IdentityNotMappedException] {
        Write-WCLog -Level debug -Message "[Get-UserNameToSID] ($AccountName) - $($_.Exception.Message)"
        return $null
    }
}
#endregion systemFunctions


#region Account Related compliance checks and inventory functions
# All bits of any flag attribute (userFlags, userAccountControl, systemFlags, groupType, etc.) are 
# tested using a bit-wise AND, set with a bit-wise OR, and toggled with a bit-wise XOR. - Richard Mueller
# added this region by Umesh - 04-nov-2015

# This function checks for whether specified local user account exists or not
# ----------------------------------------------------------------------------
Function Test-WCUserAccountExists([string] $UserName) {
    $srv = [ADSI]$srv = "WinNT://$($env:COMPUTERNAME)"
    try {
        $usr = $srv.children | where-object { $_.schemaclassname -eq "user" -and $_.name -eq $UserName }
        if($usr -eq $null) { return $false } else { return $true }
    }
    catch {
        Write-WCLog -Level debug -Message "[Test-WCUserAccountExists] ($UserName) - $($_.Exception.Message)"
        return $false
    }
}

# This function checks for whether specified local user account is disabled or not
# --------------------------------------------------------------------------------
Function Test-WCUserAccountIsDisabled([string] $UserName) {
    
    $srv = [ADSI]$srv = "WinNT://$($env:COMPUTERNAME)"
    try {
        $usr = $srv.children | where-object { $_.schemaclassname -eq "user" -and $_.name -eq $UserName }
        if($usr -eq $null) { return 'user_not_found' } 

        # check if account is disabled
        $uflags = $usr.userflags
        if(($uflags.tostring() -band 2) -eq 2) { # flag number 2 represents disabled state
            return $true
        }
        else { return $false }
    }
    catch {
        Write-WCLog -Level debug -Message "[Test-WCUserAccountIsDisabled] ($UserName) - $($_.Exception.Message)"
        return $false
    }
}

# This function will disable specified local user account
# --------------------------------------------------------
Function Disable-WCUserAccount([string] $UserName) {
    $srv = [ADSI]$srv = "WinNT://$($env:COMPUTERNAME)"
    try {
        $usr = $srv.children | where-object { $_.schemaclassname -eq "user" -and $_.name -eq $UserName }
        if($usr -eq $null) { return 'user_not_found' } 

        $uflags = $usr.userflags
        if(($uflags.tostring() -band 2) -eq 2) { # flag number 2 represents disabled state
            return 'user_already_disabled'
        }
        else { # disable user account
            $usr.userflags = [int]$uflags.tostring() -bor 2
            $usr.setinfo()
            return $true # success in disabling user account
        }
    }
    catch {
         Write-WCLog -Level debug -Message "[Disable-WCUserAccount] ($UserName) - $($_.Exception.Message)"
        return $false
    }
}

# Functions are based on following source (and updated here to suit needs):
# Convert-UserFlag, ConvertTo-SID, Get-WCLocalUserAccount, Get-WCLocalGroup
# https://mcpmag.com/articles/2015/04/15/reporting-on-local-accounts.aspx
# This function will decode given users flag and return an array
# ------------------------------------------------------------------------
Function  Convert-UserFlag($UserFlag) {
    $List  = New-Object  System.Collections.ArrayList
    Switch  ($UserFlag) {
        ($UserFlag  -BOR 0x0001)  {[void]$List.Add('SCRIPT')}
        ($UserFlag  -BOR 0x0002)  {[void]$List.Add('ACCOUNTDISABLE')}
        ($UserFlag  -BOR 0x0008)  {[void]$List.Add('HOMEDIR_REQUIRED')}
        ($UserFlag  -BOR 0x0010)  {[void]$List.Add('LOCKOUT')}
        ($UserFlag  -BOR 0x0020)  {[void]$List.Add('PASSWD_NOTREQD')}
        ($UserFlag  -BOR 0x0040)  {[void]$List.Add('PASSWD_CANT_CHANGE')}
        ($UserFlag  -BOR 0x0080)  {[void]$List.Add('ENCRYPTED_TEXT_PWD_ALLOWED')}
        ($UserFlag  -BOR 0x0100)  {[void]$List.Add('TEMP_DUPLICATE_ACCOUNT')}
        ($UserFlag  -BOR 0x0200)  {[void]$List.Add('NORMAL_ACCOUNT')}
        ($UserFlag  -BOR 0x0800)  {[void]$List.Add('INTERDOMAIN_TRUST_ACCOUNT')}
        ($UserFlag  -BOR 0x1000)  {[void]$List.Add('WORKSTATION_TRUST_ACCOUNT')}
        ($UserFlag  -BOR 0x2000)  {[void]$List.Add('SERVER_TRUST_ACCOUNT')}
        ($UserFlag  -BOR 0x10000)  {[void]$List.Add('DONT_EXPIRE_PASSWORD')}
        ($UserFlag  -BOR 0x20000)  {[void]$List.Add('MNS_LOGON_ACCOUNT')}
        ($UserFlag  -BOR 0x40000)  {[void]$List.Add('SMARTCARD_REQUIRED')}
        ($UserFlag  -BOR 0x80000)  {[void]$List.Add('TRUSTED_FOR_DELEGATION')}
        ($UserFlag  -BOR 0x100000)  {[void]$List.Add('NOT_DELEGATED')}
        ($UserFlag  -BOR 0x200000)  {[void]$List.Add('USE_DES_KEY_ONLY')}
        ($UserFlag  -BOR 0x400000)  {[void]$List.Add('DONT_REQ_PREAUTH')}
        ($UserFlag  -BOR 0x800000)  {[void]$List.Add('PASSWORD_EXPIRED')}
        ($UserFlag  -BOR 0x1000000)  {[void]$List.Add('TRUSTED_TO_AUTH_FOR_DELEGATION')}
        ($UserFlag  -BOR 0x04000000)  {[void]$List.Add('PARTIAL_SECRETS_ACCOUNT')}
    }
    return $List
}

# Convert given Sid in binary format to Sid-string representation
# ---------------------------------------------------------------
Function  ConvertTo-SID {
  Param([byte[]]$BinarySID)
    return (New-Object  System.Security.Principal.SecurityIdentifier($BinarySID,0)).Value
}

# This function will get details about local user accounts on given system
# -------------------------------------------------------------------------
Function Get-WCLocalUserAccount {
[Cmdletbinding()]
Param(
    [Parameter(ValueFromPipeline=$True,ValueFromPipelineByPropertyName=$True)]
    [String[]]$Computername =  $Env:Computername
)
    # load account management assembly to use .net user account methods
    Add-Type -assemblyname System.DirectoryServices.AccountManagement

    # create an arraylist variable to hold user details
    $uiList = New-Object System.Collections.ArrayList

    # get group info, to identify membership of each user
    $groups = Get-WCLocalGroup -ComputerName $Computername
    
    # create context for local account management (machine context)
    $localCtx = New-Object System.DirectoryServices.AccountManagement.PrincipalContext([System.DirectoryServices.AccountManagement.ContextType]::Machine,$ComputerName)
    
    # loop thru all given computers and get account details
    foreach ($Computer in  $Computername) {
        $adsi  = [ADSI]"WinNT://$Computername"
        $adsi.Children | where {$_.SchemaClassName -eq  'user'} |  ForEach {
            # create an empty custom PS object with required property names we need
            $uinfo = '' | select UserName, PasswordAge, PasswordLastChanged, PasswordExpiryDate, LastLogin, InactiveDays, AccountLocked, AccountDisabled, CantChangePassword, PassNeverExpires, PasswordExpired, MemberOf, UserSid
            
            # bind to current account using .net method
            $cuser = [System.DirectoryServices.AccountManagement.UserPrincipal]::FindByIdentity($localCtx,'samAccountName',$_.Name)
            
            $uinfo.UserName = $cuser.samAccountName
            $uinfo.UserSid = $cuser.Sid
            $uinfo.PasswordAge = [math]::Round($_.PasswordAge[0]/86400)
            $uinfo.PasswordLastChanged = $cuser.LastPasswordSet
            
            
            # set last logon date/time and inactive days. N/A if unable to find it
            $uinfo.LastLogin = If($cuser.LastLogon -is [datetime]) { $cuser.LastLogon } Else { 'N/A' }
            if($uinfo.LastLogin -ne 'N/A') {
                $uinfo.InactiveDays = ((get-date) - ([datetime]$uinfo.LastLogin)).Days
            }
            else { $uinfo.InactiveDays = 'N/A' }
            
            # set various user flags in custom PS object
            $UserFlags = (Convert-UserFlag  -UserFlag $_.UserFlags[0])
            if('ACCOUNTDISABLE' -in $UserFlags) { $uinfo.AccountDisabled = 'True' } else { $uinfo.AccountDisabled = 'False' }
            if('PASSWD_CANT_CHANGE' -in $UserFlags) { $uinfo.CantChangePassword = 'True' } else { $uinfo.CantChangePassword = 'False' }
            if('DONT_EXPIRE_PASSWORD' -in $UserFlags) { $uinfo.PassNeverExpires = 'True' } else { $uinfo.PassNeverExpires = 'False' }
            if('PASSWORD_EXPIRED' -in $UserFlags) { $uinfo.PasswordExpired = 'True' } else { $uinfo.PasswordExpired = 'False' }
            if('LOCKOUT' -in $UserFlags) { $uinfo.AccountLocked = 'True' } else { $uinfo.AccountLocked = 'False' }
            
            # set password expiry date only if account is not set to 'dont expire pass'
            if($uinfo.PassNeverExpires -eq 'False') {
                $uinfo.PasswordExpiryDate = (get-date).AddSeconds($_.MaxPasswordAge[0] - $_.PasswordAge[0])
            }
            else { $uinfo.PasswordExpiryDate = "N/A" }

            # get group membership
            $gm = ($groups | Where-Object { $_.Members.split(',').trim() -contains $uinfo.UserName }).GroupName
            $uinfo.MemberOf = ($gm -join ', ')

            # add to array list
            $uiList.Add($uinfo) | Out-Null
        }
  }
  return $uiList
}

# This function will get all local group names and their members (comma separated)
# --------------------------------------------------------------------------------
Function Get-WCLocalGroup([string] $GroupName, [string] $ComputerName = $env:ComputerName) {
    $gmlist = New-Object System.Collections.ArrayList # array-list to hold group membership details
    $adsi  = [ADSI]"WinNT://$ComputerName"
    if($GroupName) { 
        $glist = $adsi.psbase.children | where { $_.psbase.schemaClassName -eq 'group' -and $_.psbase.name -eq $GroupName }
    }
    else {
        $glist = $adsi.psbase.children | where { $_.psbase.schemaClassName -eq 'group' }
    } 
    # loop thru all groups and get the info aobut members
    $glist | foreach {
        $gminfo = '' | Select-Object GroupName, Members # a custom PSobject to hold group info, to be added to gmlist
        $groupname = $_.name
        
        $group =[ADSI]$_.psbase.Path
        #write-host "group: $groupname"
        $alist = New-Object System.Collections.ArrayList
        $group.Invoke("Members") | foreach {
            $member = $_.GetType().InvokeMember("Name", 'GetProperty', $null, $_, $null)
            [void]$alist.Add($member)
            #write-host $member
        }
        $gminfo.GroupName = $groupname.ToSTring()
        $gminfo.Members = $alist -join ', '
        [void]$gmlist.Add($gminfo)
    }
    return $gmlist
}
#endregion 


#region SOESpecificFunctions
# This function will return SOE version based on given version registry location
# -------------------------------------------------------------------------------
Function Get-SOEVersion {
[CmdletBinding()]
param([string] $RegistryPath = "HKLM:\Software\CSC\SOE", $KeyName="GlobalVersion")
    $rval = Get-ItemProperty -Path $RegistryPath -Name $KeyName -ErrorAction SilentlyContinue
    if($rval -ne $null) { $rval = $rval.$keyName }
    return $rval # it will return version as read from $keyName. if $keyName doesnt exist then it will return null
}

# This function will return matching baseline XML file for given SOE version
# ---------------------------------------------------------------------------
Function Get-WCBaselineFile {
[CmdletBinding()]
param([string] $SOEVersion, [string] $DetectionType, [string]$WCConfigFilePath)
    # Check if SOEVersionTable file exist or not. return null if doesn't exist. add to log as well
    if(-not ([System.IO.File]::Exists($WCConfigFilePath))) { # config file doesn't exist, log and return null
        #todo: write to log
        return $null
    }
    else { #baseline file exist, look for SOE version and related baseline
        try {
            [xml]$x = Get-Content $WCConfigFilePath
            # based on specified detection type, identify corresponding SOE baseline file
            $sv = $x.SVT.SOEVersions.SOE | where {$_.Version -eq $SOEVersion -and $_.Type -eq $DetectionType}
            if($sv) { #found a matching row, proces it to get baseline
                return $sv.BaselineFile
            }
            else { # a matching baseline entry not found for given SOE version, return null
                return $sv # it wil be null
            }
        }
        catch { # something went wrong, log error
            #todo: log the error and return null
        }
    }
}

# This function will detect the hardware vendor and return its name. Sun is not included.
# ---------------------------------------------------------------------------------------
function Get-HardwareVendorName {
    $v = ((Get-CimInstance -ClassName Win32_ComputerSystem).Manufacturer.Split(" ")[0]).ToUpper()
    if($v.ToUpper().Contains("HEWLETT")) { $v = "HP" }
    if($v.ToUpper() -eq "MICROSOFT") { $v = "HYPERV" } # For Hyper-V virtual machines, return HYPERV
    
    # Below line fixes and issue where vendor VMWARE is identified as VMWARE, modified 02-aug-13
    if($v.EndsWith(",")) { $v = $v.Replace(",","")} 
    return $v
}

#endregion SOEBaselineFileValidationFunctions


#region SharedUtilityFunctions
#region Compare String
#-----------------------------------------------------------------------
#Function to Compare Default and Current Policy string Value
#-----------------------------------------------------------------------
Function Compare-WCString {
<#
  .SYNOPSIS
  Compare-WCString 
  .DESCRIPTION
  Function to compare String values
  Return Value : Bool True/False
  .EXAMPLE
  Compare-WCString $LeftValue $RightValue "-eq"
  .PARAMETER LeftValue
  Left Value
  .PARAMETER RightValue
  Right Value
  .PARAMETER $CompareMethod 
  Comparision Method to be used
  #>
[CmdletBinding()]
Param(
	[Parameter(Mandatory=$true)]
    [string]$LeftValue,
	[Parameter(Mandatory=$true)]
    [string]$RightValue,
	[Parameter(Mandatory=$true)]
    [ValidateSet("-eq","=","-ne","<>","-contains","-notcontains","-like","-notlike","-match","-notmatch")]
	[string]$CompareMethod 
)
    Write-WCLog  -Level debug -Message "[Compare-WCString]"
    $RightValue = $RightValue.replace('&quot;','"') # replace &quot from xml value to actual " for proper comparison
    
    try {
    	Switch($CompareMethod.ToLower()) {
    		('-eq') { #equal to
    			return ($RightValue.ToLower().Trim() -eq $LeftValue.ToLower().Trim()); 
    		}
    		('=') { #equal to
    			return ($RightValue.ToLower().Trim() -eq $LeftValue.ToLower().Trim());
    		}
    		('-ne') { #not equal to
    			return ($RightValue.ToLower().Trim() -ne $LeftValue.ToLower().Trim()); 
    		}
    		('<>') { #not equal to
    			return ($RightValue.ToLower().Trim() -ne $LeftValue.ToLower().Trim()); 
    		}
    		('-contains') { #contains
    			return ($LeftValue.ToLower().Trim().Contains($RightValue.ToLower().Trim()));
    		}
    		('-notcontains') { #not contains
    			return (($LeftValue.ToLower().Trim().Contains($RightValue.ToLower().Trim())) -eq $false);
    		}
    		('-like') { #like 
    			return ($RightValue.ToLower().Trim() -like $LeftValue.ToLower().Trim());
    		}
    		('-notlike') { #not like
    			return (($RightValue.ToLower().Trim() -like $LeftValue.ToLower().Trim()) -eq $false);
    		}
    		('-match') { #match
    			return ($RightValue.ToLower().Trim() -match $LeftValue.ToLower().Trim());
    		}
    		('-notmatch') { #not match
    			return (($RightValue.ToLower().Trim() -match $LeftValue.ToLower().Trim()) -eq $false);
    		}
            default { #equal to
    			return ($RightValue.ToLower().Trim() -eq $LeftValue.ToLower().Trim());
    		}
    	}
    }
    Catch {
        Write-WCLog -Level Error -Message "[Compare-WCString] : Error Comparing String Values";
        Write-WCLog -Level Error -Message $_.Exception.Message;
        return $false;
    }
}
#endregion

#region Compare-Integer/Version
#-----------------------------------------------------------------------
#Function to Compare Default and Current Policy Integer Value
#-----------------------------------------------------------------------
Function Compare-WCInteger {
<#
  .SYNOPSIS
  Compare-WCInteger 
  .DESCRIPTION
  Function to compare Integer/Version datatype values
  Return Value : Bool True/False
  .EXAMPLE
  Compare-WCInteger $LeftValue $RightValue "-eq"
  .PARAMETER LeftValue
  Left Value
  .PARAMETER RightValue
  Right Value
  .PARAMETER $CompareMethod 
  Comparision Method to be used
  #>
[CmdletBinding()]
Param(
	[Parameter(Mandatory=$true)]
    $LeftValue,
	[Parameter(Mandatory=$true)]
    $RightValue,
    [ValidateSet("-eq","=","-ne","<>","-gt",">","-ge",">=","-le","<=","-lt","<")]
	[string]$CompareMethod 
)
    try {
        Write-WCLog  -Level debug -Message "[Compare-WCInteger]"
        
		$DataType ="int";
        #If CurrentVale or default Value contains "." then its datatype is version
		if($LeftValue.Contains(".") -or $RightValue.Contains(".")) { $DataType = "version"; }
		
		#Convert the data to integer or Version DataType
        $lValue = Format-WCInteger -Value $LeftValue -DataType $DataType;
        $rValue = Format-WCInteger -Value $RightValue -DataType $DataType;
        
        #If one the Value is NULL then there is some error in converting DataType
        if($lValue -eq $NULL -or $rValue -eq $NULL) { 
            return $false;
        }
        
    	Switch($CompareMethod.ToLower()) {
    		('-eq') { #equal to
    			return ($rValue -eq $lValue);
    		}
    		('=') { #equal to
    			return ($rValue -eq $lValue);
    		}
    		('-ne') { #not equal to
    			return ($rValue -ne $lValue);
    		}
    		('<>') { #not equal to
    			return ($rValue -ne $lValue); 
    		}
    		('-gt') { #greater than
    			return ($rValue -gt $lValue);
    		}
    		('>') { #greater than
    			return ($rValue -gt $lValue);
    		}
            ('-ge') { #greater than
    			return ($rValue -ge $lValue);
    		}
    		('>=') { #greater than
    			return ($rValue -ge $lValue);
    		}
            ('-le') { #greater than
    			return ($rValue -le $lValue);
    		}
    		('<=') { #greater than
    			return ($rValue -le $lValue);
    		}
    		('-lt') { #less than
    			return ($rValue -lt $lValue);
    		}
    		('<') { #less than
    			return ($rValue -lt $lValue);
    		}
            default { #equal to
    			return ($rValue -eq $lValue);
    		}
    	}
    }
    Catch {
        Write-WCLog -Level Error -Message "[Compare-WCInteger] : Error Comparing Values."
        Write-WCLog -Level Error -Message $_.Exception.Message;
        return $false;
    }
}
#-----------------------------------------------------------------------
#Function to Compare Default and Current Policy Integer Value
#-----------------------------------------------------------------------
Function Format-WCInteger {
<#
  .SYNOPSIS
  Format-WCInteger 
  .DESCRIPTION
  Function to Format the Integer/Version datatype values
  Return Value : Integer Variable or Version Variable
  .EXAMPLE
  Format-WCInteger $Value $DataType
  .PARAMETER Value
  Value that will be string Value
  .PARAMETER DataType
  Either version or integer
  #>
[CmdletBinding()]
Param(
	[Parameter(Mandatory=$true)]
    $Value,
	[Parameter(Mandatory=$true)]
	[ValidateSet("version","int")]
	$DataType
)
    Write-WCLog  -Level debug -Message "[Format-WCInteger]";
    
    try {   
        if($DataType.ToLower().Trim() -eq "version") {
            Write-WCLog -Level debug -Message "Casting $Value to DataType Version";
			#Append .0 if value doesn't have . 
			if($Value.Contains(".") -eq $false) { $Value += ".0"; }
			
            [Version]$retValue = $Value; #Cast the value to Version DataType
        }
        else {
            Write-WCLog -Level debug -Message "Casting $Value to DataType Integer";
            [int]$retValue = $Value;  #Cast the value to Integer DataType
        }      
    }
    Catch {
        Write-WCLog -Level Error -Message "[Format-WCInteger] : Error Converting $Value.";
        Write-WCLog -Level Error -Message $_.Exception.Message;
        $retValue = $NULL; #Incase of error set the data to NULL
    }
    
    Write-WCLog -Level debug -Message "Casting done Successfully.";
    return $retValue;
}
#endregion

#region Compare Array  - - Enum Field
#-----------------------------------------------------------------------
#Function to Compare Default and Current Policy Array Value
#-----------------------------------------------------------------------
Function Compare-WCEnumToArray {
<#
  .SYNOPSIS
  Compare-WCEnumToArray 
  .DESCRIPTION
  Function to Compare two Array and return Comparison Status
  Return Value : Bool True/False
  .EXAMPLE
  Compare-WCEnumToArray $LeftValue $RightValue "-eq"
  .PARAMETER LeftValue
  Left Array to COmpare
  .PARAMETER RightValue
  Right Array to Compare
  .PARAMETER CompareMethod
  Comparision Method to be used to compare the array
  -eq,-like,-match,-contains
  #>
[CmdletBinding()]
Param(
	[Parameter(Mandatory=$true)]
    $LeftValue,
	[Parameter(Mandatory=$true)]
    $RightValue,
	[Parameter(Mandatory=$true)]
    [ValidateSet("-eq","=","-ne","<>","-contains","-notcontains","-match","-notmatch","-like","-notlike")]
	[string]$CompareMethod 
)
    Write-WCLog -Level debug -Message "[Compare-WCEnumToArray]";
    
    try {
        Switch($CompareMethod.ToLower()) {
			('-oeq') { #equal to - Default Value array should be exactly similar to Current Value Array
    			return(Compare-WCArrayEqual -LeftValue $LeftValue -RightValue $RightValue -Sync);
    		}
    		('-eq') { #equal to - Default Value array should be exactly similar to Current Value Array
    			return(Compare-WCArrayEqual -LeftValue $LeftValue -RightValue $RightValue);
    		}
    		('=') { #equal to
    			return(Compare-WCArrayEqual -LeftValue $LeftValue -RightValue $RightValue);
    		}
			('-ne') { #equal to - Default Value array should be exactly similar to Current Value Array
    			return((Compare-WCArrayEqual -LeftValue $LeftValue -RightValue $RightValue) -eq $false);
    		}
    		('<>') { #equal to
    			return((Compare-WCArrayEqual -LeftValue $LeftValue -RightValue $RightValue) -eq $false);
    		}
    		('-contains') { #not equal to
    			return(Compare-WCArrayContains -LeftValue $LeftValue -RightValue $RightValue);
    		}
    		('-notcontains') { #not equal to
    			return(((Compare-WCArrayContains -LeftValue $LeftValue -RightValue $RightValue) -eq $false));
    		}
    		('-like') { #like 
    			return(Compare-WCArrayLike -LeftValue $LeftValue -RightValue $RightValue);
    		}
    		('-notlike') { #not like
    			return(((Compare-WCArrayLike -LeftValue $LeftValue -RightValue $RightValue) -eq $false));
    		}
    		('-match') { #match
    			return(Compare-WCArrayMatch -LeftValue $LeftValue -RightValue $RightValue);
    		}
    		('-notmatch') { #not match
    			return(((Compare-WCArrayMatch -LeftValue $LeftValue -RightValue $RightValue) -eq $false));
    		}
            default { #equal to - Default Value array should be exactly similar to Current Value Array
    			return(Compare-WCArrayEqual -LeftValue $LeftValue -RightValue $RightValue);
    		}
    	}
    }
    Catch {     
        Write-WCLog -Level Error -Message "[Compare-WCEnumToArray] : Error Comparing Array/Enum Value.";
        Write-WCLog -Level Error -Message $_.Exception.Message;
        return $false;
    }
}
#----------------------------------------------------------------------------------
#Function to Compare whether Default and Current  Array Values are exactly the same
#----------------------------------------------------------------------------------
Function Compare-WCArrayEqual {
<#
  .SYNOPSIS
  Compare-WCArrayEqual 
  .DESCRIPTION
  Function to Compare whether two Arrays are equal
  Return Value : Bool True/False
  .EXAMPLE
  Compare-WCArrayEqual $LeftValue $RightValue
  .PARAMETER LeftValue
  Left Array to COmpare
  .PARAMETER RightValue
  Right Array to Compare
  #>
[CmdletBinding()]
Param(
	[Parameter(Mandatory=$true)] $LeftValue,
	[Parameter(Mandatory=$true)] $RightValue,
	[Switch]$Sync
    )
    Write-WCLog -Level debug -Message "[Compare-WCArrayEqual]";
	
    try { 
		#return false if array length not matching	
		#if($LeftValue.Count -ne $RightValue.Count) { return $false; }
		
        #Compare each value in Default Value array string and Current Value array string
        #For([int] $i=0;$i -lt $LeftValue.Count;$i++) {
        #    if($LeftValue[$i].Trim().ToLower() -ne $RightValue[$i].Trim().ToLower()) { #they should be exactly the same
        #        return $false;
        #    } 
        #}
        if($LeftValue -eq $null -or $RightValue -eq $null -or $LeftValue.count -eq 0 -or $RightValue.count -eq 0) { 
            return $false 
        }
		elseif ($Sync.IsPresent -eq $True) {
			if((Compare-Object -ReferenceObject $LeftValue -DifferenceObject $RightValue -SyncWindow 0).Count -eq 0) {
				return $true
			}
			else { 
				return $false 
			}
		}
        else { 
            if((Compare-Object -ReferenceObject $LeftValue -DifferenceObject $RightValue).Count -eq 0) {
				return $true
			}
			else { 
				return $false 
			} 
        }
	}
    Catch {     
        Write-WCLog -Level Error -Message "[Compare-WCArrayEqual] : Error Comparing Array/Enum Value.";
        Write-WCLog -Level Error -Message $_.Exception.Message;
        return $false;
    }    
}
#-----------------------------------------------------------------------------------------------------
#Function to Compare whether Entries in Current Value Array is present in Default Policy Value Array
#-----------------------------------------------------------------------------------------------------
Function Compare-WCArrayContains {
<#
  .SYNOPSIS
  Compare-WCArrayContains 
  .DESCRIPTION
  Function to check whether Array1 contains entries in Array2
  Return Value : Bool True/False
  .EXAMPLE
  Compare-WCArrayContains $LeftValue $RightValue
  .PARAMETER LeftValue
  Left Array to COmpare
  .PARAMETER RightValue
  Right Array to Compare
  #>
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)]
    $LeftValue,
	[Parameter(Mandatory=$true)]
    $RightValue
    )    
	Write-WCLog -Level debug -Message "[Compare-WCArrayContains]";
	try {
		ForEach($EnumValue in $RightValue) { #Enumerate each value in Current Value array string
			if(($LeftValue -contains $EnumValue) -eq $false) { #If Current Value is not there in default value array return false
				return $false;
			}
		}
	}
	Catch {     
        Write-WCLog -Level Error -Message "[Compare-WCArrayContains] : Error Comparing Array/Enum Value.";
        Write-WCLog -Level Error -Message $_.Exception.Message;
        return $false;
    }
    return $true;
}

#-----------------------------------------------------------------------------------------------------
#Function to Compare whether Entries in Current Value Array is "-like" the Default Policy Value Array
#-----------------------------------------------------------------------------------------------------
Function Compare-WCArrayLike {
<#
  .SYNOPSIS
  Compare-WCArrayLike 
  .DESCRIPTION
  Function to check whether entries in Array2 is like Array1
  Return Value : Bool True/False
  .EXAMPLE
  Compare-WCArrayLike $LeftValue $RightValue
  .PARAMETER LeftValue
  Left Array to COmpare
  .PARAMETER RightValue
  Right Array to Compare
  #>
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)]
    $LeftValue,
	[Parameter(Mandatory=$true)]
    $RightValue
    )  
	Write-WCLog -Level debug -Message "[Compare-WCArrayLike]";
    try {
		ForEach($EnumValue in $RightValue) {
			$boolVar = $false;
			$LeftValue | ForEach-Object { #Enumerate each value in Current Value array string
				if($EnumValue -like $_) { #If Current Value is like the entries in the default value array set the variable to true
					$boolVar = $true;
				}
			}
			if($boolVar -eq $false) { #If Current Enum Value is not like the entries in Default Value array then return false
				return $false;
			}
		}
	}
	Catch {     
        Write-WCLog -Level Error -Message "[Compare-WCArrayLike] : Error Comparing Array/Enum Value.";
        Write-WCLog -Level Error -Message $_.Exception.Message;
        return $false;
    }
    return $true;
}

#-----------------------------------------------------------------------------------------------------
#Function to Compare whether Entries in Current Value Array "-match" the Default Policy Value Array
#-----------------------------------------------------------------------------------------------------
Function Compare-WCArrayMatch {
<#
  .SYNOPSIS
  Compare-WCArrayMatch 
  .DESCRIPTION
  Function to check whether entries in Array2 matches Array1
  Return Value : Bool True/False
  .EXAMPLE
  Compare-WCArrayMatch $LeftValue $RightValue
  .PARAMETER LeftValue
  Left Array to COmpare
  .PARAMETER RightValue
  Right Array to Compare
  #>
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)]
    $LeftValue,
	[Parameter(Mandatory=$true)]
    $RightValue
    )    
    Write-WCLog -Level debug -Message "[Compare-WCArrayMatch]";
	try {
		ForEach($EnumValue in  $RightValue) {
			$boolVar = $false;
			
			$LeftValue | ForEach-Object { #Enumerate each value in Current Value array string
					if($EnumValue -Match $_) { #If Current Value does match in the default value array set the variable to true
						$boolVar = $true;
					}
			}
			
			if($boolVar -eq $false) { #If Current Enum Value doesnt match in Default Value array then return false
				return $false;
			}
		}
	}
	Catch {     
        Write-WCLog -Level Error -Message "[Compare-WCArrayMatch] : Error Comparing Array/Enum Value.";
        Write-WCLog -Level Error -Message $_.Exception.Message;
        return $false;
    }
    return $true;
}
#endregion
#endregion SharedUtilityFunctions


#region FileSystemFunctions
# -----------------------------------------------------------
# This function will return whether given file exists or not
# -----------------------------------------------------------
Function Test-WCFileExists([string]$FileName) {
    if($FileName -match "[*?]") { # this file has wildcard specified, get a count
        $fc = @(Get-ChildItem -Path $FileName -File -Force -ErrorAction SilentlyContinue).Count
        if($fc -eq 0) { return $false } else { return $true }
    }
    else { # this is single file
        return [system.io.file]::Exists($FileName)
    }
}

# -------------------------------------------------------------
# This function will return whether given folder exists or not
# -------------------------------------------------------------
Function Test-WCFolderExists([string]$FolderName) {
    if($FolderName -match "[*?]") { # this folder has wildcard specified, get a count
        $fc = @(Get-ChildItem -Path $FileName -Directory -Force -ErrorAction SilentlyContinue).Count
        if($fc -eq 0) { return $false } else { return $true }
    }
    else { # this is single folder status
        return [System.IO.Directory]::Exists($FolderName)
    }
}

# ---------------------------------------------------------------------
# This function will check the size of given file using given parameter
# ---------------------------------------------------------------------
Function Test-WCFileSize {
param(
[string]$FileName,
[string][ValidateSet('=','-eq','-ne','<>','-gt','>','-lt','<','-ge','>=','-le','<=')]$op = '-eq',
[int64]$Size)
    if(-not (Test-WCFileExists -FileName $FileName)) { 
        Write-WCLog -Level warning -Message "File $FileName does not exist, cannot get size of file"
        return $null 
    }
    #file exists, get size and do comparison
    $f = Get-Item -Path $FileName
    #$cresult = Compare-WCInteger -SourceNumber $f.Length -op $op -CompareWith $Size
    $cresult = Compare-WCInteger -LeftValue $f.Length -RightValue $size -CompareMethod $op
    return $cresult
}

# ---------------------------------------------------------------------
# This function will check the size of given file using given parameter
# File age is in days.
# ---------------------------------------------------------------------
Function Test-WCFileAge {
param(
[string]$FileName,
[string][ValidateSet('=','-eq','-ne','<>','-gt','>','-lt','<','-ge','>=','-le','<=')]$op = '-eq',
$Age)
    if(-not (Test-WCFileExists -FileName $FileName)) { 
        Write-WCLog -Level warning -Message "File $FileName does not exist, cannot get age of file"
        return $null 
    }
    #file exists, get size and do comparison
    $f = Get-Item -Path $FileName
    #$cresult = Compare-WCInteger -SourceNumber ((get-date) - $f.CreationTime) -op $op -CompareWith $Age
    $cresult = Compare-WCInteger -LeftValue ((get-date) - $f.CreationTime) -RightValue $Age -CompareMethod $op
    return $cresult
}

# -------------------------------------------------------
# This function will return 'File Version' of given file.
# -------------------------------------------------------
Function Get-WCFileVersion([string]$FilePath) {
    $fileversion = (get-item $FilePath -ErrorAction SilentlyContinue).VersionInfo
	return "$($fileversion.FileMajorPart).$($fileversion.FileMinorPart).$($fileversion.FileBuildPart).$($fileversion.FilePrivatePart)"
}

# This function will check given file's attributes and return whether it 
# matches with user provided attribute list
# ------------------------------------------------------------------------
Function Test-WCFileAttributes {
param(
[string] $FileName,
[System.IO.FileAttributes[]]$Attributes)
# see if given file has given attributes
if(-not (Test-WCFileExists -FileName $FileName)) { 
        Write-WCLog -Level warning -Message "File $FileName does not exist, cannot get attributes of file"
        return $null 
    }
    #file exists, get size and do comparison
    $attribMatches = $true #indicate that all file attributes match
    $f = Get-Item -Path $FileName
    foreach($attrib in ($f.Attributes.ToString().Split(","))) {
        if(-not ($Attributes -contains $attrib)) { $attribMatches = $false }
    }
    return $attribMatches #return the result
}
#endregion FileSystemFunctions


#region ProcessFunctions
# ------------------------------------------------------------------
# This function will return whether given process is running or not
# ------------------------------------------------------------------
Function Test-WCProcessRunning([string]$ProcessName) {
    return ((Get-Process -Name $ProcessName -ErrorAction SilentlyContinue).count -gt 0)
}

# ------------------------------------------------------------------
# This function will return whether given process is running or not
# ------------------------------------------------------------------
Function Test-WCProcessRunningFromPath([string]$ProcessName, [string]$ProcessPath, [switch]$MatchAllRunningInstances) {
    $allMatched = $true #indiate that all process path matched with given path
    $oneOrMoreMatched = $false #indicate that no process path matched by-default
    $p = Get-Process -Name $ProcessName -ErrorAction SilentlyContinue
    if (($p).count -gt 0) {
        foreach($cp in $p) {
            if($cp.Path.ToLower() -ne $ProcessPath.ToLower()) {
                $allMatched = $false #at least one did not match, so allMatched will be false
            }
            else {
                $oneOrMoreMatched = $true #at least one matched
            }
        }
        if($MatchAllRunningInstances) { #user has specified to match all instances of given process
            if($allMatched) { return $true } else { return $false }
        }
        else { #user has not specified to match all instances
            if($oneOrMoreMatched) { return $true } else { return $false }
        }
    }
    else {
        Write-WCLog -Level warning -Message "Process $ProcessName is not running"
        return $false #return false if process is not running either
    }
}
#endregion ProcessFunctions


#region ServiceFunctions

# ------------------------------------------------------------------
# This function will return whether given service exist or not
# ------------------------------------------------------------------
Function Test-WCServiceByName([string]$ServiceName) {
    return ((Get-Service -Name $ServiceName -ErrorAction SilentlyContinue) -ne $null)
}

# -----------------------------------------------------------------------------------
# This function will return whether given service exist or not, based on Display Name
# -----------------------------------------------------------------------------------
Function Test-WCServiceByDisplayName([string]$ServiceDisplayName) {
    return ((Get-Service -DisplayName $ServiceDisplayName -ErrorAction SilentlyContinue) -ne $null)
}

# -----------------------------------------------------------------------
# This function will return service running status, based on service name
# -----------------------------------------------------------------------
Function Get-WCServiceStatus([string]$ServiceName) {
    return (Get-Service -Name $ServiceName -ErrorAction SilentlyContinue).Status
}

# -----------------------------------------------------------------------
# This function will return service startup mode, based on service name
# -----------------------------------------------------------------------
Function Get-WCServiceStartMode([string]$ServiceName) {
    return (Get-CimInstance -ClassName Win32_Service -Property StartMode -Filter "Name='$ServiceName'").StartMode
}

#endregion ServiceFunctions


#region ServerRolesAndFeaturesFunctions

# --------------------------------------------------------------
# This function will return status of given server role/feature
# --------------------------------------------------------------
Function Get-WCWindowsFeatureStatus([string]$FeatureName) {
    return (Get-WindowsFeature -Name $FeatureName).InstallState
}

#endregion ServerRolesAndFeaturesFunctions


#region RegistryFunctions
# ----------------------------------------------------------------
# This function will test whether given registry key exist or not
# KeyPath will be in [HKLM|HKCU]:\KeyPath\KeyPath\.. format
# ----------------------------------------------------------------
Function Test-WCRegistryKey([string]$KeyPath) {
    return ((Get-Item -Path $KeyPath -ErrorAction SilentlyContinue) -ne $null)
}
# ----------------------------------------------------------------
# This function will test whether given registry key Value exist or not
# KeyPath will be in [HKLM|HKCU]:\KeyPath\KeyPath\.. format and KeyName will be in value format
# ----------------------------------------------------------------
Function Test-WCRegistryValue([string] $Path,[string] $Name) {
	$retVal = Get-ItemProperty -Path $Path -Name $Name -ErrorAction SilentlyContinue;
	#if return Value is null then the key doesnt exists or value doesnt exists
	if($retVal -ne $null) { return $true; } 
	else { return $false;}
}
# ----------------------------------------------------------
# This function will return data of given registry value
# KeyPath will be in [HKLM|HKCU]:\KeyPath\KeyPath\.. format
# ----------------------------------------------------------
Function Get-WCRegistryValue([string]$KeyPath, [string]$ValueName, [switch] $ReturnBlankAsNotDefined) {
    try { 
        $regVal = (Get-ItemProperty -Path $KeyPath -Name $ValueName -ErrorAction Stop).$ValueName
        if([string]::IsNullOrEmpty($regVal) -and $ReturnBlankAsNotDefined) { 
            return 'NotDefined' 
        }
        else { return $regVal }
    }
    catch [System.Management.Automation.ItemNotFoundException], [System.Management.Automation.PSArgumentException] {
        return "NotExists"
    }
    catch [System.Security.SecurityException] { return "AccessDenied" }
    catch { return $_.CategoryInfo.Reason }
}

#--------------------------------------------------------------------------------------------------------------
#Function to Remove a Registry Key
#--------------------------------------------------------------------------------------------------------------
Function Remove-WCRegistryValue {
<#
  .SYNOPSIS
  Remove-WCRegistryValue
  .DESCRIPTION
  Function to Delete Registry Key while remediation
  .EXAMPLE
  Remove-WCRegistryValue <RegistryKey>
  #>
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)]
    [string] $Path,
    [Parameter(Mandatory=$true)]
    [string] $Key
)
    Write-WCLog -Message "[Remove-WCRegistryValue]"
    Write-WCLog -Level debug -Message "Registry : $Path";

    try {
        if((Test-WCRegistryValue -Path "$Path" -Name $Key)) { 
            #Delete Registry Key
            Remove-ItemProperty -Path "$Path" -Name $Key -Force;
            Write-WCLog -Level Error -Message "Successfully Removed the Key";
        }
        else { Write-WCLog -Level debug -Message "Key Doesn't Exists"; } #Key  Doesnt Exists

        return $true;
    }
    Catch {
        Write-WCLog -Level Error -Message $_.Exception.Message;
        return $false;
    }
}
#--------------------------------------------------------------------------------------------------------------
#Function to Set a registry Key
#--------------------------------------------------------------------------------------------------------------
Function Set-WCRegistryValue {
<#
  .SYNOPSIS
  Set-WCRegistryValue
  .DESCRIPTION
  Function to Format Registry Key while remediation
  .EXAMPLE
  Set-WCRegistryValue <RegistryKey>
  #>
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)]
    [string] $Path,
    [Parameter(Mandatory=$true)]
    [string] $Key,
    $Value,
    [Parameter(Mandatory=$true)]
    [ValidateSet("String", "MultiString","ExpandString","DWord","Binary","QWord")]
    [string] $Type
)
    Write-WCLog -Message "[Set-WCRegistryValue]"
    Write-WCLog -Level debug -Message "Registry : $Path\$Key";
    Write-WCLog -Level debug -Message "DataType : $Type";

    try {
        #Write Value to Log File
        if($Value.GetType().BaseType.Name.ToLower() -eq "array") { Write-WCLog -Level debug -Message ("Value : "+ @($Value) -join ","); } #Array Value
        else{ Write-WCLog -Level debug -Message ("Value : "+ $Value);} #String/Dword Value

        if(!(Test-Path "$Path")) { New-Item $Path -Force } #Create Registry Path if it doesnt Exists
        Set-ItemProperty -Path $Path -Name $Key -Value $Value -Type $Type; #Create Registry Key
        return $true;
    }
    Catch {
        Write-WCLog -Level Error -Message $_.Exception.Message;
        return $false;
    }
}
#endregion RegistryFunctions


#region WMI/Powershell Commands
#-----------------------------------------------------------------------
#Function to Set attributes in a Policy
#-----------------------------------------------------------------------
Function Get-WCPSValue {
<#
  .SYNOPSIS
  Get-WCPSValue
  .DESCRIPTION
  Function to Run a PSCommand and return its Output Object
  Return Value :
  Powershell Object should be one dimentional Array or String
  NULL- Incase of any Errors
  .EXAMPLE
  Get-WCPSValue PSCommand
  .PARAMETER PSCommand
  PSCommand woyld be the Powershell Command to be executed
  #>
[CmdletBinding()]
Param(
	[Parameter(Mandatory=$true)] [string]$PSCommand
)

	Write-WCLog -Level debug -Message "[Get-WCPSValue]";
	Write-WCLog -Level debug -Message "PowerShell Command : $PSCommand";
	
	try {	
		if((Test-WCPSCommand -PSCommand $PSCommand) -eq $false) {
			Write-WCLog -Level debug -Message "This ps Command is not a WC Approved ps Command";	
			return $NULL;
		}
		$sb = $executioncontext.invokecommand.NewScriptBlock($PSCommand) 
		#Run the PowerShell Command
		if($PSCommand.Trim().SubString(0,1) -eq "@") {
			$ExpressionResult = @(Invoke-Command $sb  -ErrorAction "SilentlyContinue");
		}
		else {
			$ExpressionResult = Invoke-Command $sb  -ErrorAction "SilentlyContinue";
		}

        $nonCollDataType = "string|char|byte|int|int32|long|bool|decimal|double|datetime|";
        # added by Umesh to handle string output
        if($ExpressionResult.GetType().Name -eq 'String') { # this is single value string
            $ColPropertyName = $NULL
        }    
        #If DataType is Object[],ManagementObject,PSCustomObject
        elseif($ExpressionResult.GetType().BaseType.Name.ToLower().Contains("object")) { $ColPropertyName = $ExpressionResult.PSObject.Properties; }
        #If DataType is an Array
        elseif($ExpressionResult.GetType().BaseType.Name.ToLower().Contains("array")) {
            #if Arrays first element dataType is not in this list, then the value is Object
            if(!($nonCollDataType -match $ExpressionResult[0].GetType().Name.ToLower())) {
                $ColPropertyName = $ExpressionResult[0].PSObject.Properties; #Update the ColProperty Name with Properties of the Object
            }              
        }

        if($ColPropertyName -ne $null) { $ReturnValue = Convert-WCPSObjectToArray -PSObject $ExpressionResult -ColProperty $ColPropertyName }
        #PSValue is a single Value or a string/int array
        else {$ReturnValue = $ExpressionResult}
	}
	Catch {
        Write-WCLog -Level Error -Message "[Get-WCPSValue] : Error Converting PSObject to Array";
        Write-WCLog -Level Error -Message $_.Exception.Message;
		$ReturnValue =$NULL;
    }
	return $ReturnValue
}
#-----------------------------------------------------------------------
#Function to Convert to psArray to String Array
#-----------------------------------------------------------------------
Function Test-WCPSCommand {
<#
  .SYNOPSIS
  Test-WCPSCommand
  .DESCRIPTION
  Function to Validate whether the PSCommand is WC Approved
  Return Value : True or False
  .EXAMPLE
  Test-WCPSCommand PSCommand
  .PARAMETER PSCommand
  PSCommand would be the Powershell Command to be executed
  #>
[CmdletBinding()]
Param(
	[Parameter(Mandatory=$true)]
    $PSCommand
    )
	$ApprovedWCVerbs = "get-","test-","select-","foreach-","where-","find-","compare-","measure-","group-","resolve-","wait-","sort-","[int]";
	$bApproved = $false;
	$StartIndex = 0;
	try 
	{	
		Write-WCLog -Level debug -Message "[Test-WCPSCommand]";
	
		if($PSCommand -eq $NULL) { return $false; }
		elseif($PSCommand.Trim() -eq "") { return $false; }
		#elseif($PSCommand.ToLower().Contains(".ps1") -and (Test-Path $PSCommand)) {$PSCommand = Get-Content $PSCommand;} #if its a script then get the content of the script to Command

		#Verify that the psCommands are under approved Verb List
		#PSComamnd can Start with @( for an Array
		#or PSComamnd can start with ( for a string
		
		#Identify actual powershell commandlets in thePSCommand 
        $PSallCommands = @();
		$tokens = [Management.Automation.PSParser]::Tokenize($PSCommand, [ref]$null)
		$PSallCommands = $tokens | where { $_.Type -eq 'Command' } 

		#Check whether the command is approved
		ForEach($Command in $PSallCommands) {
			$bApproved = $false;
			ForEach($Verb in $ApprovedWCVerbs) {
				if($Command.Content.Length -ge $Verb.Length) {
					if($Command.Content.SubString(0,$Verb.Length).ToLower() -eq $Verb.ToLower()) {
						$bApproved = $true;break;
					}
				}
			}
			if($bApproved -eq $false) {
				Write-WCLog -Level debug -Message "Unapproved WC CommandLet Found in PSCommand : $($Command.Content)";
				return $false;
			}
		}
		#If all command are approved then return true
		$bApproved = $true;
	}
	Catch {
		Write-WCLog -Level Error -Message $_.Exception.Message;
		$bApproved = $false;
    }

	return $bApproved;
}
#-----------------------------------------------------------------------
#Function to Convert to psArray to String Array
#-----------------------------------------------------------------------
Function Convert-WCPSObjectToArray {
<#
  .SYNOPSIS
  Convert-WCPSObjectToArray
  .DESCRIPTION
  Function to Convert-WCPSObjectToArray
  return Value: xmlNode
  .EXAMPLE
  Convert-WCPSObjectToArray -PSObject $ExpressionResult -ColProperty $ColPropertyName
  .PARAMETER PSObject
  PSObject
  .PARAMETER Property
  Properties of PSObject
  #>
[CmdletBinding()]
Param(
	[Parameter(Mandatory=$true)]
    $PSObject,
    [Parameter(Mandatory=$true)]
    $ColProperty
    )
    Write-WCLog -Message "[Convert-WCPSObjectToArray]";
    $PSArr = @();
	
	try {
		ForEach($PSValue in $PSObject) {
			ForEach($Attribute in $ColProperty) {						
				if($PSValue.$($Attribute.Name) -eq $NULL ) { $PSArr += ""; }
				else {
					$Value="";               
					
					if(($PSValue.$($Attribute.Name)).GetType().BaseType.Name.ToLower() -eq "array") { #If the Value is Array join them by ","
						$Value = $PSValue.$($Attribute.Name) -join ",";
					}
					else { 
						$Value = $PSValue.$($Attribute.Name) #Value is String
					}
					
					#Update the Array
					$PSArr +=  $Value;
				}
			}
		}
    }
    Catch {
        Write-WCLog -Level Error -Message "[Convert-WCPSObjectToArray] : Error Converting PSObject to Array";
        Write-WCLog -Level Error -Message $_.Exception.Message;
		$PSArr = @();
    }
    return $PSArr;
}
#endregion


#region ACL Functions
Function Get-WCACLValue {
    
<#
  .SYNOPSIS
  Get-WCACLValue
  .DESCRIPTION
  Function to Run get-WCACLValue Function and report the output
  Return Value :
  Powershell Object should be one dimentional Array or String
  NULL- Incase of any Errors
  .EXAMPLE
  Get-WCACLValue PSCommand
  .PARAMETER PSCommand
  PSCommand woyld be the Powershell Command to be executed
  #>
[CmdletBinding()]
Param(
	[Parameter(Mandatory=$true)] [string]$Path
)
		
	Write-WCLog -Level debug -Message "[Get-WCACLValue]";
	Write-WCLog -Level debug -Message "Path : $Path";
	
	try {	
		if(Test-Path $Path) { $ReturnValue = (Get-ACL $Path).AccessToString.Split("`n"); } #Get ACL Permissions
        else {
            Write-WCLog -Level debug -Message "Path doesnt Exists";
            $ReturnValue="NotExists";
        }
		
	}
	Catch {
        Write-WCLog -Level Error -Message "[Get-WCACLValue] : Error getting ACL";
        Write-WCLog -Level Error -Message $_.Exception.Message;
		$ReturnValue =$NULL;
    }
	return $ReturnValue
}
#endregion

#--------------------------------------------------------------------------------------------------------------
#Function to run a Powershell Script
#--------------------------------------------------------------------------------------------------------------
Function Start-PSScript {
<#
  .SYNOPSIS
  Get-psScript
  .DESCRIPTION
  Function to run a powershell script and return its output 
  .EXAMPLE
  Start-psScript <psscript with parameters>
  #>
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)]
    [string] $psScript,
    [ValidateSet("Scan","Revert","Remediate")] $Action = "Scan",
	$DefaultValue
)
	try {
				Write-WCLog -Level debug -Message "[Start-PSScript]";
				Write-WCLog -Level debug -Message "Script : $psScript";
	
			if($psScript -match ".ps1") { #Ensure that the parameter has powershell script	
				$SplitscriptPath = $psScript -split ".ps1";#Identify the script file in the command
				
				$scriptPath = "$($SplitscriptPath[0]).ps1"; #Temp ScriptPath as its not resolved Path
				$scriptParameter = $SplitscriptPath[1].Trim();
				
				#If Script File may start with ' or " , remove the character
				if($scriptPath -like "'*") { $scriptpath = $scriptPath -replace "'","";}
				if($scriptPath -like "[char]34*") { $scriptpath = $scriptPath -replace [char]34,"";}
				
				#if ScriptPath is relative path then append the psscriptroot to it
                if(($scriptPath -like ".\*") -or ($scriptPath -like "..\*")) {
                    $scriptPath = "$psScriptRoot\.$scriptPath";
                }
				
				#Check whether path exists - Resolve the path to get full path
				$psscriptPath = Resolve-Path "$scriptPath" -ErrorAction SilentlyContinue;
				
				if($psscriptPath -ne $null) {
					#Add single quotes before and after the file path
					$psscriptPath = "'" + $psscriptPath + "'";
					#The initial split was done using .ps1.So there is a possibility of single or double quotes along with the parameter
					if(($scriptParameter -like "'*") -or ($scriptParameter -like "[char]34*")) {
						$scriptParameter = $scriptParameter.SubString(1,$scriptParameter.Length - 1);
					}
					
					$psCommand = $psscriptPath + $scriptParameter + " -Action $Action";
					
					Write-WCLog -Level debug -Message "[Start-psScript] :Running Command $psCommand";
					#Run the psScript and collect the return value
					if($DefaultValue -ne $Null) { $ReturnValue = Invoke-Expression "& $psCommand -DefaultValue `$DefaultValue"; }
					else { $ReturnValue = Invoke-Expression "& $psCommand";}
				}
				else {
					Write-WCLog -Level Error -Message "[Start-PSScript] : Script Missing : $psscriptPath";
					$ReturnValue="Error";
				}
			}		
			else { #Unable to find psscript in parameter
				Write-WCLog -Level Error -Message "[Start-PSScript] : Incorrect parameter for the datatype : psscript";
				$ReturnValue="Error";
			}
		}
	Catch {
        Write-WCLog -Level Error -Message "[Start-PSScript] : Error running psScript:$psScript";
        Write-WCLog -Level Error -Message $_.Exception.Message;
		$ReturnValue="Error";
    }
	return $ReturnValue
}

# ----------------------------------------------------------------------------------------
#Identify whether the Interface Mode ServerCore full or Minshell or Nano
# ----------------------------------------------------------------------------------------
Function Get-WCInterfaceMode([Switch] $ShortName) {

    # get interface mode - method is different for w2k8r2 and w2k12+
    #https://msdn.microsoft.com/en-us/library/hh846315%28v=vs.85%29.aspx -> for w2k12 and above
    if((get-ciminstance -ClassName win32_operatingsystem).Version.startsWith("6.1.")) {
        # this is windows server 2008 R2
        #https://msdn.microsoft.com/en-us/library/aa394239(v=vs.85).aspx
        if($OSSKU -in (7,8,10)) { # standard, datacenter, enterprise gui
            $Mode = "Server with a GUI (Full GUI)"    
        }
        elseif($OSSKU -in (12,13,14)) { # standard, datacenter, enterprise core
            $Mode = "Server Core"
        }
        else { $Mode = "Unidentified" }

        # if shortname is needed then return it
        if($ShortName.IsPresent) {
		    Switch($Mode) {
			    "Server with a GUI (Full GUI)" { $Mode = "Full"; }
			    "Server Core" { $Mode = "Core"; }
		    }
	    }
    }
    else { # it is windows servfer 2012 and above
	    $ServerLevels = Get-Item "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Server\ServerLevels"

	    if($ServerLevels.GetValue("NanoServer") -eq "1") { $Mode  = "Nano" }
	    elseif(($ServerLevels.GetValue("Server-Gui-Shell") -eq "1") -and ($ServerLevels.GetValue("Server-Gui-Mgmt") -eq "1")) { $Mode = "Server with a GUI (Full GUI)"; }
	    elseif($ServerLevels.GetValue("Server-Gui-Shell") -eq "1") { $Mode = "Minimal Server Interface"; }
	    elseif($ServerLevels.GetValue("ServerCore") -eq "1") { $Mode = "Server Core" }
	
	    if($ShortName.IsPresent) {
		    Switch($Mode) {
			    "Server with a GUI (Full GUI)" { $Mode = "Full"; }
			    "Server Core" { $Mode = "Core"; }
			    "Minimal Server Interface" { $Mode = "Minshell"; }
                # for nano, it will be "Nano" as above
		    }
	    }
    }
	
    return $Mode
}

#region BaselineHashIntegrity
Function Test-WCBaselineIntegrity([string]$Baseline, [string]$HashConfigFile) {
    if(!(Test-Path -Path $HashConfigFile)) { return $false } # no hash file found, return false
    if(!(Test-Path -Path $Baseline)) { return $false } # given baseline doesn't exist

    # check hash to ensure it matches
    $hashes = Import-Clixml -Path $HashConfigFile
    $ph = ($hashes | where { $_.Baseline -eq (Split-Path -Path $Baseline -Leaf) }).Hash
    $ch = (Get-WCFileHash -Path $Baseline -Algorithm SHA256).Hash
    return ($ph -eq $ch) # return whether both current and saved hashes match or not
}
#endregion BaselineHashIntegrity

# -------------------------------------------------------------------------------------
# this function will return XML nodes based on given xml variable and XPath query
# if query does not result in any nodes, a blank array is returned. you can check
# returnvar.count to see if anything was returned. 0 means query didn't return anything
# TODO: utilize return object (like in Ansible)
# --------------------------------------------------------------------------------------
Function Get-WCXMLNodes {
param(
    $Xml,
    $XPath
)
    # check OS SKU and use xml calls accordingly
    if($OSSKU -in (143,144)) { # nano server
        try {
            $res = @([System.Xml.XmlDocumentXPathExtensions]::SelectNodes($Xml,$XPath))
            $res # return the result
        }
        catch { # error occured. user need to check if returned item is array or not
            # $_.Exception.Message # write to log file
            return $null
        }
    }
    else { # its full or core
        try {
            $res = $Xml.SelectNodes($XPath)
            $res
        }
        catch { # error occured. user need to check if returned item is array or not
            #$_.Exception.Message
            return $null
        }
    }
}

# function to test whether Word/Excel COM object can be created or not
# use it to determine whether to enable word/excel report format in UI or not
# ----------------------------------------------------------------------------
Function Test-COMObjectCreation([validateset('Word','Excel')] [string] $ComObject) {
    # identify if word/excel are installed.. if so, enable report format check boxes for them
    try { 
        if($ComObject -eq 'Word') { $cobj = New-Object -ComObject Word.Application }
        else { $cobj = New-Object -ComObject Excel.Application }
        $cobj.quit() # quit word application and release COM object
        [void] [System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($cobj)
        $true # return true
    } 
    catch { # failed to create COM object for Word.. its not installed likely, disable checkbox
        $false # return false
    }
}

# This function will compute md5/sha256/sha512/sha hash of given file
# credit: https://gist.github.com/kennwhite/ea5c371ed784bf68ab3f
# ----------------------------------------------------------------------
function Get-WCFileHash {
    param( 
        [string] $Path = $(throw "You must specify a valid file path"),
        [ValidateSet("sha256", "sha512", "sha", "md5")] [string] $Algorithm = 'sha256' 
    ) 
    if([System.IO.File]::Exists((Resolve-Path -Path $Path).ProviderPath)) {
        $fileStream = [system.io.file]::openread((resolve-path $Path).ProviderPath) 
        $hasher = [System.Security.Cryptography.HashAlgorithm]::create($Algorithm) 
        $hash = $hasher.ComputeHash($fileStream) 
        $fileStream.close() 
        $fileStream.dispose() 

        # construct and return hash information object
        $robject = '' | Select-Object Algorithm, Hash, Path
        $robject.Hash = [system.bitconverter]::tostring($hash).replace('-','')
        $robject.Path = $Path
        $robject.Algorithm = $Algorithm
        $robject
    }
    else {
        $null # do nothing in case of file doesn't exist
    }
}

#this function will remove Unprocessed Nodes in an xmlNode
Function Remove-WCUnprocessedNodes($Action,$wcXML) {
	#Identify policies that are not processed
	if($Action -eq "Scan") { $NodestobeRemoved = (Get-WCXMLNodes -Xml $wcXML -XPath "//Policy") | Where-Object { $_.Processed -eq "False" } }
	else { $NodestobeRemoved = (Get-WCXMLNodes -Xml $wcXML -XPath "//Policy") | Where-Object { $_.Remediate -ne "True" } }
	
	#Remove Policies that are identified
	ForEach($Node in $NodestobeRemoved) {
		$Node.ParentNode.RemoveChild($Node) | Out-Null
	}
	
	#Remove Category that doesnt not have Policies
	$colCategory =  (Get-WCXMLNodes -Xml $wcXML -XPath "//Category") | Where-Object { $_.Policy.Count -eq 0 }
	ForEach($Category in $colCategory) {
		$Category.ParentNode.RemoveChild($Category) | Out-Null
	}
	#Remove Sections that doesnt have categories
	$colSection =  (Get-WCXMLNodes -Xml $wcXML -XPath "//Section") | Where-Object { $_.Category.Count -eq 0 }
	ForEach($Section in $colSection) {
		$Section.ParentNode.RemoveChild($Section) | Out-Null
	}
	
	return $wcXML
	
}