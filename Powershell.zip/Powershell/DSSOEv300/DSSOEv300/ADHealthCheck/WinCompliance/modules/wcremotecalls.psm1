# this module include functions that are used for performing remote WinCompliance reporting and remediation
# Name  : WCReportGen.ps1
# Author: Umesh Thakur
# Date  : 25-Nov-2014
# ----------------------------------------------------------------------------------------------------------
# Modification History: 
# ----------------------------------------------------------------------------------------------------------

#Powershell version prerequisite -  the below comment automatically verifies the ps version
#requires -Version 3.0

# Test whether given TCP port is open on given system or not # Taken from http://poshcode.org/2455
# ------------------------------------------------------------------------------------------------
Function Test-TCPPort([string] $ComputerName, $Port) {
    try
    {
        $c = New-Object System.Net.Sockets.TcpClient($machine, $port)
        $c.Close()
        return $true
    }
    catch [system.exception] {
    return $false
  }
}

# this function will invoke given WinCompliance command (reporting or remediation) on specified
# Remote computer(s). requirement is to have WC package on a shared path and user launching it should
# have write access to the share (to pull the report back from remote servers)
# ----------------------------------------------------------------------------------------------------
Function Invoke-WCRemoteJob {
param(
    [parameter (Mandatory="true")] [string] $WCRepositoryPath,
    [parameter (Mandatory="false")] [pscredential] $WCRepositoryCredential,
    [ValidateSet("scan","remediate")][string] $Action = "scan",
    [parameter (Mandatory="true")] [hashtable] $WCActionArgs = @{DetectBaseline=$true}, # default action is to auto-detect baseline and perform reporting
    [parameter (Mandatory="true")] [string[]] $ComputerName, # computers on which remote wc job will be launched
    [pscredential] $ComputerCredential, # credentials to connect to remote computers
    [string]$OutputFolder, 
    [switch] $PassThru, # if specified, does not wait for job completion, returns immediately after launch
    [int32] $WaitTimeout = 900, # 15 minutes max. wait time, that is 900 seconds. Valif if PassThru is not specified
    [switch] $HideProgress # valid if PassThru is not specified is specified. 
)
    #region scriptBlock that will be launched on remote servers, for reporting/remediation as per given params
    #this scriptblock should be self-contained. it can't access anything outside it,  except params passed to it
    $sbRemoteWCLaunch = {
    param(
        [string] $WCRepositoryPath,
        [pscredential] $Credential,
        [ValidateSet("scan","remediate")][string] $Action,
        [hashtable] $WCActionArgs,
        [string]$OutputFolder
    )
        # function to check if I can create files on given package share
        function Test-WriteOnSharedFolder([string] $SharePath) {
            try {
                [System.IO.File]::Create("$SharePath\test12345deleteme21.tmp",1,'DeleteOnClose') > $null
                $true # you can create file on shared path
            }
            catch {
                $false # you can't create file on share
            }
        }
        # end function to check if I can create files on given package share

        Write-Verbose "Attempting to run WinCompliance $Action on $($env:COMPUTERNAME)" -Verbose

        # try to map given network share
        try {
            # check if given path is UNC path!
            if(([uri]$WCRepositoryPath).IsUnc -eq $false) { # this is not a shared path!!
                Write-Warning "$WCRepositoryPath must be an UNC path, local path is not supported"
                return # halt execution
            }
            Write-Verbose "connecting to WinCompliance repository $WCRepositoryPath" -Verbose
            $psdParams = @{Name='wcd';Root=$WCRepositoryPath;PSProvider='FileSystem'}
            if($Credential) { $psdParams.Add('Credential',$Credential) }
            $wcd = New-PSDrive @psdParams -ErrorAction Stop
            Write-Verbose "connected to WinCompliance repository" -Verbose

            # todo: check to see if WinCompliance package is present in the repository
        }
        catch {
            Write-Verbose "failed to connect to WinCompliance repository, see error record for details" -Verbose
            Write-Error $_
            return # exit the block
        }
        # at this point, drive mapped. lets copy the package now
        try {
            Write-Verbose "copying WinCompliance package" -Verbose
            $tempPath = [System.IO.Path]::GetTempFileName() # a temp path.. it actually creates the file!
            Remove-Item -Path $tempPath -Force # remove the temp file and use this path as folder!
            New-Item -Path $tempPath -ItemType Directory -Force -ErrorAction Stop | Out-Null
            Copy-Item -Path wcd:\WinCompliance\* -Destination "$tempPath" -Recurse -ErrorAction Stop
            Write-Verbose "WinCompliance package copied to $tempPath" -Verbose
        }
        catch { 
            Write-Verbose "failed to copy the package to $tempPath, see error record for details" -Verbose
            Write-Error $_
            Remove-PSDrive $wcd # remove psdrive that was created above
            return # exit the block
        }

        # adjust paths in parameters (like baselinepath, inventoryconfigfile etc.) to make them local wrt copied package
        if($WCActionArgs.Contains('BaselineFile')) {
            Write-Verbose ("given baseline is {0}" -f $WCActionArgs['BaselineFile']) -Verbose
			$repoPath = $WCRepositoryPath
			#if reportxmlfile path is inside the WinCompliance Source then adjust the path accordingly
            if($WCActionArgs['BaselineFile'] -like "$WCRepositoryPath\WinCompliance\*") { $repoPath = "$WCRepositoryPath\WinCompliance" }
			
            $WCActionArgs['BaselineFile'] = ($WCActionArgs['BaselineFile']).replace($repoPath.ToLower(),$tempPath)
            Write-Verbose ("adjusted baseline path is {0}" -f $WCActionArgs['BaselineFile']) -Verbose
        }

        # adjust paths in parameters (like baselinepath, inventoryconfigfile, reportxmlfilepath etc.) to make them local wrt copied package
        if($WCActionArgs.Contains('ReportXMLFile')) {
            Write-Verbose ("given baseline is {0}" -f $WCActionArgs['ReportXMLFile']) -Verbose
            $repoPath = $WCRepositoryPath
			#if reportxmlfile path is inside the WinCompliance Source then adjust the path accordingly
            if($WCActionArgs['ReportXMLFile'] -like "$WCRepositoryPath\WinCompliance\*") { $repoPath = "$WCRepositoryPath\WinCompliance" }
            
            $WCActionArgs['ReportXMLFile'] = ($WCActionArgs['ReportXMLFile']).ToLower().replace($repoPath.ToLower(),$tempPath)
            Write-Verbose ("adjusted baseline path is {0}" -f $WCActionArgs['ReportXMLFile']) -Verbose
        }

        # adjust paths in parameters (like baselinepath, inventoryconfigfile etc.) to make them local wrt copied package
        if($WCActionArgs.Contains('InventoryConfigFile')) {
            Write-Verbose ("given inventory config file is {0}" -f $WCActionArgs['InventoryConfigFile']) -Verbose
			$repoPath = $WCRepositoryPath
			#if reportxmlfile path is inside the WinCompliance Source then adjust the path accordingly
            if($WCActionArgs['InventoryConfigFile'] -like "$WCRepositoryPath\WinCompliance\*") { $repoPath = "$WCRepositoryPath\WinCompliance" }
			
            $WCActionArgs['InventoryConfigFile'] = ($WCActionArgs['InventoryConfigFile']).replace($repoPath.ToLower(),$tempPath)
            Write-Verbose ("adjusted inventory config file is {0}" -f $WCActionArgs['InventoryConfigFile']) -Verbose
        }

        # invoke WinCompliance reporting on this local system based on given parameters (WCActionArgs)
        if($Action -eq 'scan') { 
            Write-Verbose "invoking WinCompliance report generation using given arguments" -Verbose
            $sb = [scriptblock]::Create("$tempPath\wcreportgen.ps1 @WCActionArgs")

            # bypass execution policy for current process so that script can run (in case exec pol is restricted or allsigned etc.)
            Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process -Force

            # now invoke constructed command and get the result as output
            $wcrout = Invoke-Command -ScriptBlock $sb
            $wcrout # write output object to output stream
            if($wcrout.exitcode.length -gt 0) { # wc ran and there was an exit code
                Write-Verbose ("{0} (exit code {1})" -f $wcrout.message, $wcrout.exitcode) -Verbose
            }
        }
        # invoke WinCompliance reporting on this local system based on given parameters (WCActionArgs)
        elseif($Action -eq 'remediate') {
            #todo: code for invoking remote remediation and corresponding output gathering
			#todo: code for invoking remote remediation and corresponding output gathering
            Write-Verbose "invoking WinCompliance report generation using given arguments" -Verbose
            $sb = [scriptblock]::Create("$tempPath\wcRemediation.ps1 @WCActionArgs")

            # bypass execution policy for current process so that script can run (in case exec pol is restricted or allsigned etc.)
            Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process -Force

            # now invoke constructed command and get the result as output
            $wcrout = Invoke-Command -ScriptBlock $sb
            $wcrout # write output object to output stream
            if($wcrout.exitcode.length -gt 0) { # wc ran and there was an exit code
                Write-Verbose ("{0} (exit code {1})" -f $wcrout.message, $wcrout.exitcode) -Verbose
            }
        }
        
        # attempt to copy report to output folder. for remediation report, it may need additional/different code
        try {
            # check if given path is UNC path!
            if(([uri]$OutputFolder).IsUnc -eq $false) { # this is not a shared path!!
                Write-Warning "$OutputFolder must be an UNC path, local path is not supported. reports could not be copied to $OutputFolder"
                #return # halt execution
            }
            else {
                # create output folders (reports and logs) on given outputFolder path (defaults to repository share)
                $repoRepPath = "$OutputFolder\Reports\$($env:COMPUTERNAME)"
                $repoLogPath = "$OutputFolder\Logs\$($env:COMPUTERNAME)"
                if(([System.IO.Directory]::Exists($repoRepPath) -eq $false)) {
                    New-Item -ItemType Directory -Path $repoRepPath -ErrorAction Stop -Force | Out-Null
                    Write-Verbose "created report folder $repoRepPath on repository" -Verbose
                }
                if(([System.IO.Directory]::Exists($repoLogPath) -eq $false)) {
                    New-Item -ItemType Directory -Path $repoLogPath -ErrorAction Stop -Force | Out-Null
                    Write-Verbose "created logs folder $repoLogPath on repository" -Verbose
                }
                
                # now copy the remediation report to reports folder as created above (if didn't exist)
				if($wcrout.robject.remediationxmlreport) {
					if([system.io.file]::Exists($wcrout.robject.remediationxmlreport)) {
						Copy-Item -Path $wcrout.robject.remediationxmlreport -Destination $repoRepPath -ErrorAction Stop
						Write-Verbose "Remediation report copied to $repoRepPath" -Verbose
					}
				}
                # now copy the report to reports folder as created above (if didn't exist)
                elseif([system.io.file]::Exists($wcrout.robject.xmlreport)) {
                    Copy-Item -Path $wcrout.robject.xmlreport -Destination $repoRepPath -ErrorAction Stop
                    Write-Verbose "report copied to $repoRepPath" -Verbose
                }
                # now copy the inventory report 
                if([system.io.file]::Exists($wcrout.robject.inventoryreport)) {
                    Copy-Item -Path $wcrout.robject.inventoryreport -Destination $repoRepPath -ErrorAction Stop
                    Write-Verbose "inventory report copied to $repoRepPath" -Verbose
                }

                #copy log folder in case of remediation
                if($wcrout.logfolder) {
                   if([system.io.Directory]::Exists($wcrout.logfolder)) {
                        Copy-Item -Path $wcrout.logfolder -Destination $repoLogPath -ErrorAction Stop -Recurse
                        Write-Verbose "log Folder copied to $repoLogPath" -Verbose
                    }
                }
                # now copy the log file
                elseif([system.io.file]::Exists($wcrout.logpath)) {
                    Copy-Item -Path $wcrout.logpath -Destination $repoLogPath -ErrorAction Stop
                    Write-Verbose "log file copied to $repoLogPath" -Verbose
                }
            }
        }
        catch {
            Write-Verbose "error copying report/log files to $OutputFolder, see error and warning records for details" -Verbose
            Write-Error $_
        }

        # clean up the temp folder now
        try {
            Remove-Item $tempPath -Recurse -Force -ErrorAction Stop
            Write-Verbose "cleaned up temp folder $tempPath" -Verbose
        }
        catch {
            Write-Verbose "failed to remove temp folder $tempPath, see error record for details"
            Write-Error $_
        }

        Remove-PSDrive $wcd # remove psdrive that was created for copying the pacakge
    }
    #endregion scriptBlock that will be launched on remote servers, for reporting/remediation as per given params

    # create parameter splat for invoking WC remote job on given computers
    $icmdArgs = @{
        ComputerName = $ComputerName
        ScriptBlock = $sbRemoteWcLaunch
        ArgumentList = ($WCRepositoryPath,$WCRepositoryCredential,$Action,$WCActionArgs,$OutputFolder)
    }
    if($ComputerCredential) { $icmdArgs.Add('Credential',$ComputerCredential) } # add credential only if specified

    # launch wc job (reporting or remediation) on given remote servers
    $wcJob = Invoke-Command -ComputerName $ComputerName -Credential $ComputerCredential `
        -ScriptBlock $sbRemoteWcLaunch -ArgumentList $WCRepositoryPath,$WCRepositoryCredential,$Action,$WCActionArgs,$OutputFolder `
        -AsJob # run the scriptblock as a job
    
    if($PassThru) { $wcJob } # return job object if wait param is not specified
    else { # wait for job to complete
        # create a wc remote job object that keepts track of wc remote reporting/remediation
        $jso = New-WCRemoteJobObject -ComputerName $ComputerName
        # invoke function that shows progress and waits for the job
        $wcWaitJob = Wait-WCRemoteJob -Job $wcJob -JobStatusObject $jso -TimeoutSeconds $WaitTimeout -HideProgress:$HideProgress

        # update report path, compliance % and baseline in Jobstatus object
        $wcWaitJob = Update-WCRemoteReports -JobStatusObject $wcWaitJob -OutputFolder $OutputFolder

        $wcWaitJob # return the object
    }
}

# this function will create a new WC Job status object that will store detailed job info
# ---------------------------------------------------------------------------------------
function New-WCRemoteJobObject {
param(
    [string[]] $ComputerName # computers, for which tracker object will be created
)
    $jobObject = foreach($comp in $ComputerName) {
        $comp | Select-Object @{Name='ComputerName';Expression={$_}}, state, wcexitcode, singlepolicy, output, reportpath, baseline `
            ,compliance, progress, failurereason, starttime, endtime, error, verbose, warning
    }

    # return this job object
    $jobObject
}

# this function wil update 'reportpath' property of job status object with generated report name wrt to outputfolder
# -------------------------------------------------------------------------------------------------------------------
function Update-WCRemoteReports {
param(
    $JobStatusObject,
    $OutputFolder
)
    # update report path (reportpath in JobStatusObject) with relative reference to OutputFolder
    foreach($jso in $JobStatusObject) {
        # update report path - note that $mjob[0].Output.robject.xmlreport is path to the report on the server 
        # on which, report was generated. it will not be accessible directly using its local path from host
        # (the server who invoked remote reporting/remediation). for this, reportpath property is added
        if($jso.output.robject.xmlreport.length -gt 7) { # report exist at least in x:\y.xml format. update reportpath
            $reportName = $jso.output.robject.xmlreport.split('\')[-1] # only file name
            # only update if report really exists
            $rep = Get-ChildItem -Path "$OutputFolder\Reports" -Recurse -Filter $reportName
            #if([System.IO.File]::Exists("$OutputFolder\Reports\$reportName")) {
            if($rep.count -eq 1) { # found the report, use fullname to get path of the report
                $jso.reportpath = $rep.FullName #"$OutputFolder\$reportName" # updated
                [xml]$x = Get-Content $jso.reportpath
                $baseline = ($x.WinCompliance.ReportSummary.RSItem | Where-Object { $_.Name -eq 'BaselineUsed' }).value.split('\')[-1]
                $cpercent = ($x.WinCompliance.ReportSummary.RSItem | Where-Object { $_.Name -eq 'CompliancePercent' }).value
                $jso.baseline = $baseline
                $jso.compliance = $cpercent
            }
        }
    }

    # return updated job status object
    $JobStatusObject
}


# this function will wait for given WC job till completion, optionally showing progress bar
# -----------------------------------------------------------------------------------------
function Wait-WCRemoteJob {
param(
    [System.Management.Automation.Job] $Job,
    $JobStatusObject,
    $TimeoutSeconds = 900, # timeout of 15 minutes by-default
    [switch] $HideProgress
)
    
    $startTime = Get-Date # time before starting wait loop , used to calculate timeout
    $jobCount = $job.ChildJobs.Count
    while($job.State -eq [System.Management.Automation.JobState]::Running) {
        # Update job progress 
        $runningJobs = ($Job.ChildJobs | Where-Object { $_.State -eq 'running' }).Count
        $failedJobs = ($Job.ChildJobs | Where-Object { $_.State -eq 'failed' }).Count
        $completedJobs = ($Job.ChildJobs | Where-Object { $_.State -eq 'completed' }).Count
        $notStartedJobs = ($Job.ChildJobs | Where-Object { $_.State -eq 'notstarted' }).Count
        if(-not $HideProgress) {
            $progActivity = ("WinCompliance remote jobs status - total {0}, completed {1}, failed {2}, running {3}, pending start {4}" -f $jobCount,$completedJobs,$failedJobs,$runningJobs,$notStartedJobs)
            write-progress -Id 3 -activity $progActivity -status "Job Progress:" -percentcomplete (($completedJobs + $failedJobs)/$jobCount*100) #(($jobCount-$runningJobs)/$jobCount*100)
        }
        
        # loop thru all jobs and update their progress
        foreach($jso in $JobStatusObject) {
            $mjob = $job.ChildJobs | Where-Object { $_.Location -eq $jso.ComputerName }
            $jso.state = $mjob[0].State # update job state

            # for running jobs, update progress
            if($mjob[0].State -eq 'running') {  
                # some policies invoke powershell cmd that starts their own progress and they make this jobs percentComplete inconsistent. so discarding them
                if($mjob[0].Progress[-1].PercentComplete -ge $jso.progress) {
                    $jso.progress = $mjob[0].Progress[-1].PercentComplete
                }
            }
        }
        # check if timeout has occured. if so, exit the function
        if(((get-date) - $startTime).TotalSeconds -gt $TimeoutSeconds) { 
            # timeout has occured, return job object as it is in current state
            break # exit the loop
        }
    }
    
    # job is either failed or complete at this point - only if timeout has not occured    
    foreach($jso in $JobStatusObject) {
        $mjob = $job.ChildJobs | Where-Object { $_.Location -eq $jso.ComputerName }
        #Write-Verbose "processing job $($mjob[0].Location)" -Verbose
        $jso.state = $mjob[0].State # update job state

        # update status object with full details
        $jso.wcexitcode = $mjob[0].output.exitcode # winCompliance exit code, or null for failed jobs
        $jso.starttime = $mjob[0].PSBeginTime # time when this job was started
        $jso.endtime = $mjob[0].PSEndTime # time when this job was finished
        $jso.output = $mjob[0].Output # output produced by WC reporting/remediation process
        $jso.error = $mjob[0].Error # errors produced by WC reporting/remediation process
        $jso.warning = $mjob[0].Warning # warnings produced by WC reporting/remediation process
        $jso.verbose = $mjob[0].Verbose # verbose messages produced by WC reporting/remediation process
        $jso.failurereason = $mjob[0].JobStateInfo.Reason # for failed jobs, reason for failure
        if(($jso.verbose -match 'Single policy processed:').count -eq 1) { # this is single policy processing
            $jso.singlepolicy = $true
            if($jso.wcexitcode -eq 0) { $jso.compliance = '100' } else { $jso.compliance = '0' }
        }
        else { $jso.singlepolicy = $false }
    }
    
    write-progress -Id 3 -activity "closing" -Completed # complete and close the progress bar
    
    $JobStatusObject # return job status object
}
