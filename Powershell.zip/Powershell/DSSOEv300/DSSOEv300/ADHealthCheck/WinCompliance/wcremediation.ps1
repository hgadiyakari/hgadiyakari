﻿# This script will perform the WinCompliance remediation based on given user parameters
# default XML format. Script accepts multiple command-line arguments and works in silent mode. 
# Name  : WCRemediation.ps1
# Author: Harikrishnan GN
# Date  : 12-Jan-2015
# ---------------------------------------------------------------------------------------------
# Modification History:
# 06-may-2016 by Umesh - replaced .SelectNodes method with Get-WCXmlNode function for nano compatbility
# 06-may-2016 by Umesh - changed the way xml is saved (earlier .save())
# 06-jun-2016 by Umesh - added loading of GPRegistryPolicy and GPRegistryPolicyParser modules to apply LGPO policies on Nano server
# ---------------------------------------------------------------------------------------------

#Powershell version prerequisite -  the below comment automatically verifies the ps version
#requires -Version 3.0

#region ScriptParameters
[CmdletBinding(SupportsShouldProcess=$True,ConfirmImpact="High")]
param(
    #Polcies that has to be processed for Local Remediation
    [Parameter(ParameterSetName="wcLocalRep")]
    [string[]] $Policy,

    #Category that has to be processed for Local Remediation
    [Parameter(ParameterSetName="wcLocalRep")]
	[string[]] $Category,
    
    #Sections that has to be processed for Local Remediation
    [Parameter(ParameterSetName="wcLocalRep")]
	[string[]] $Section,

    #Option to Remediation All
    [Parameter(ParameterSetName="wcLocalRep")]
    [Switch] $RemediateAll,

    #Is Remediation Type Revert(apply current setting in xml) or Remediate ( apply default setting)
    [Parameter(ParameterSetName="wcLocalRep")]
    [ValidateSet("Remediate", "Revert")] [string]$RemediationType = "Remediate",

    [Parameter(ParameterSetName="wcLocalRep")]
    $ImportModule, #Import additional custom Modules

    [Parameter(ParameterSetName="wcLocalRep")]
    [Switch]$UpdateBranding, #Will update Branding placeholders in xml
	
	[Parameter(ParameterSetName="wcLocalRep",Mandatory=$true)]
    [ValidateScript({([System.IO.File]::Exists((resolve-path $_).ProviderPath)) -and $_.trim().split(".")[-1] -eq 'xml'})] [string] $ReportXMLFile,
	
	[Parameter(ParameterSetName="wcLocalRep")]
    [string] $LogPath = "$PSScriptRoot\logs\$($env:COMPUTERNAME)", # altername log file path

    #Location where reportpath is stored
    [Parameter(ParameterSetName="wcLocalRep")]
	[string] $ReportPath = "$PSScriptRoot\reports\$($ENV:COMPUTERNAME)",

    #Log Level
    [Parameter(ParameterSetName="wcLocalRep")]    
    [ValidateSet("info", "debug")] $LogLevel = 'info',

    #Ignore Rescan Incase of Remediation
    [Parameter(ParameterSetName="wcLocalRep")]
	[Switch]$IgnoreRescan, #WCRemediation process will perform scan to see if settings are applied.If you pass this switch rescan will be ignored
	
	[Parameter(ParameterSetName="wcLocalRep")]
    [Switch] $AutoUpdate,
	
    # ~~~ WC remoting related parameters defined here ~~~#
    
    # One or more remote computer names to run remote WC reporting on
    [Parameter(ParameterSetName="wcRemoteRep")]
    [string[]] $ComputerName, 

    # Credentials to connect to remote computers. If not specified, current users identity is used.
    [Parameter(ParameterSetName="wcRemoteRep")] 
    [pscredential] $ComputerCredential, 
    
    # UNC share (\\server\share) where WinCompliance package is stored. from this share, package will be pushed on remote
    # servers for execution. User launching remote WC reporting must have access to the share as well as write permissions.
    [Parameter(ParameterSetName="wcRemoteRep")]
    [string] $WCRepositoryPath,

    # Credentials to connect to WC Package share. If not specified, current users identity is used.
    [Parameter(ParameterSetName="wcRemoteRep")] 
    [pscredential] $wcRepositoryCredential, 
    
    # A hashtable of report generation script arguments that will be passed to each remote computer for report generation
    [Parameter(ParameterSetName="wcRemoteRep")]
    [hashtable] $Arguments = @{}, 
    
    # default to WC Reports folder on given share. it must be an UNC path, preferably packageshare. 
    # user lauching the script must have write permissions on the given share to save reports. 
    [Parameter(ParameterSetName="wcRemoteRep")]
    [string] $ReportSharePath = "$WCRepositoryPath",

    # it tells the script to invoke remote WC process and return the object, do not wait for completion
    [Parameter(ParameterSetName="wcRemoteRep")]
    [switch] $PassThru, 

    [Parameter(ParameterSetName="wcRemoteRep")]
    [int32] $WaitTimeout = 900, # seconds that script will wait for remote jobs to finish execution (15mins default)

    #section Common Parameters
    #remediation xml File

    #Hide Progress if the progress of remediation is to be hidden
    [Parameter(ParameterSetName="wcRemoteRep")]
    [Parameter(ParameterSetName="wcLocalRep")]
    [Switch] $HideProgress
    
    )

if($PSCmdlet.ParameterSetName -eq 'wcLocalRep') { 
	
	#region Auto Update
	if($AutoUpdate.IsPresent -and (Test-Path $PSScriptRoot\wcAutoUpdate.ps1)) {
		$return = Invoke-Expression "$PSScriptRoot\wcAutoUpdate.ps1"
	}
	#endregion
	
    #region wincompliance return object definition
    # exitcode - { 0=success; 1=failed, 2=no admin rights, 4=unable to detect baseline, 8=detected baseline
    # does not exists; 16=server not built using soe; 32=invalid baseline xml; 64=no applicable policies found; 128 = Remediate All Confirmation not accepted }
    # construct a wincompliance return object that will be returned with detailed info
    $wcr = [pscustomobject]@{
        computername=$ENV:COMPUTERNAME
        exitcode=1
        message=''
        logpath=''
        logfolder=''
        robject=[pscustomobject]@{
        xmlreport=''
        remediationxmlreport=''
        csvreport=''
        htmlreport=''
        wordreport=''
        excelreport=''
        inventoryreport=''}
        failedpolicies=[pscustomobject]@{
        id=''
        }
    }
    #endregion

    #Validate Confirm Parameter
    if($RemediateAll.isPresent) {
	    $Message = "You have selected to remediate all security settings in <baseline XML file name/path>. It is highly recommended that you review all security settings which you are going to remediate and ensure that they are applicable to this server. Some of the security settings that are described as medium to high risk have potential to break applications or may result in unexpected server behaviour. Do you want to continue?";
	    if(!($PSCmdlet.ShouldProcess($Message))) { 
            $wcr.exitcode = 128
            $wcr.message = "Confirmation was not accepted by the user to start WinCompliance Remediation with 'RemediateAll' Parameter"
            return $wcr
            Exit; 
        }
    }

    #Variable to be used with confirm parameter
    $ConfirmPreference  = "None" #Dont receive Confirmation for set add commandlets

    #region scriptVariablesDeclaration
    # set path to various WC folders
    $modulesPath = "$PSScriptRoot\modules"
    #endregion scriptVariablesDeclaration

    #region ErrorDescriptionVariables
    # Error conditions and return codes
    $wcErrorElevatedPermissionsRequired = "Elevated permissions are required to run WinCompliance."
    #endregion

    #region LoadWCModules
    # import the module first that sets caller preference (verbose and debug only) (do not change this module sequence!)
    Import-Module "$modulesPath\LogCallerPref.psm1" -Force
    Set-CallerVerbosePreference
    Set-CallerDebugPreference

    # load all WC required modules, forcing re-load if they're already loaded
    Import-Module "$modulesPath\WCLogger.psm1" -Force
    Import-Module "$modulesPath\WCUtils.psm1" -Force
    Import-Module "$modulesPath\WCRemediator.psm1" -Force
    Import-Module "$modulesPath\WCSOEConfig.psm1" -Force

    #region Nano specific modules
    # 06-june-2016 - umesh: for applying LGPO policies on Nano server, these 2 modules are required
    #Import-Module "$modulesPath\GPRegistryPolicyParser\0.1\GPRegistryPolicyParser.psd1" -Force
    # add WC module path to modulesPath list for GPRegitryPolicyParser load - it is for this session only
    if((Get-WCInterfaceMode -ShortName) -eq 'Nano') {
        $env:PSModulePath = $env:PSModulePath + ";$PSScriptRoot\modules" 
        Import-Module "$modulesPath\GPRegistryPolicy\0.1\GPRegistryPolicy.psd1" -Force
    }
    #endregion

    # Import-Module "$modulesPath\WCReportHandler.psm1" -Force

    #LoadModules passed via ImportModule Parameter
    foreach($addModule in $ImportModule) {
        if(Test-Path $addModule) { 
            Import-Module $addModule -Force 		
        }
    }

    #Load Branding Module if applicable
    if($UpdateBranding.IsPresent) {
	    Import-Module "$modulesPath\WCSOEBranding.psm1" -force
    }
    #endregion LoadWCModules

    #region ValidateParameters 
    # check if current user is admin (launched via elevated creds)

    if(-not (Test-IsCurrentUserAdmin)) { 
        $wcr.exitcode = 2
        $wcr.message = $wcErrorElevatedPermissionsRequired
        return $wcr
        Exit;
    }

    #note: code to validate whether baseline xml file exist or not is not needed. validation is there in parameter.
    #endregion ValidateParameters

    # set report log file path/name if user has not specified it. set it at SOE default location
    $wcTime = Get-Date;
    $timeStamp = $wcTime.ToString('MMddyyhhmmss') # timestamp to add as part of log/report file names
    $RemedationLogFolderName = (New-WCRemediationLogFolderName $timeStamp) #remediation Log Folder Name

	$LogFilePath = $logPath + '\' + $RemedationLogFolderName + '\' + (New-WCRemediationLogFileName -timeStamp $timeStamp)

    #region SetLogFile and start logging
    Set-WCLogFile -LogPath $LogFilePath # set log file path
    Set-WCLogLevel -LogLevel $LogLevel # set user given log level, defaults to 'info'
    Write-WCLog -Message "[$($PSCommandPath.Split('\')[-1])]" # script name as log header
    Write-WCLog -Message "WinCompliance Remediation script logging started"
    $CurrentUser = "$([Environment]::UserDomainName)\$([Environment]::UserName)";
    Write-WCLog -Message "Account ID used to perform Remediation : $CurrentUser"
    #endregion

    #region set XML
    $Status = Set-WCRXMLVariable -ReportXMLFile $ReportXMLFile -UpdateBranding:$UpdateBranding; #Load the Set Script XML Variable with the report XML file 
	if($Status -ne "Success") {
        $wcr.exitcode = 32
        $wcr.message = $Status
        return $wcr
        exit; #terminate script
    }
	
    #Test whether the XML is in Valid WC report Format
    If((Test-WCRXMLVariable) -eq $false) { 
        Write-WCLog -Level Error -Message "Invalid Report XML File";
        $wcr.exitcode = 32
        $wcr.message = "Invalid Report XML File"
        return $wcr
        exit; #terminate script
    }

    #endregion

    #Scan script Path
    $ScanscriptPath = "$PSScriptRoot\WCReportGen.ps1";

    #region Copy of ScanXML
    #Create a copy of the report xml file and change the processed and current Value fields
    $ScanXML = [xml](get-content $ReportXMLFile);
    $PolicyNodes = (Get-WCXMLNodes -Xml $ScanXML -XPath "//Policy");
    $PolicyNodes | foreach-Object { $_.Processed = "False";$_.CurrentValue.Value = "";$_.CurrentValue.InnerText = "";}
    $tempScanXML = "$env:temp\Temp_$((Get-Item $ReportXMLFile).Name)";

    $tsx = [System.IO.File]::CreateText($tempScanXML)
    $ScanXML.Save($tsx);
    $tsx.Close()

    #endregion

    #region kickstart Remediation
    #create report Path
    New-WCUReportPath -ReportPath $ReportPath
	$RemediationReportFile = "$ReportPath\$(New-WCRemediationFileName $TimeStamp)"
	
    if($RemediateAll.IsPresent) {
	    #Start RemediateAll
        Write-WCLog -Level info -Message "RemediateAll : True";
        $RemediationReport = Start-WCRRemediation -ReportXMLFilePath $ReportXMLFile -RemediationType $RemediationType -RemediateAll:$RemediateAll -HideProgress:$HideProgress -LogPath $LogPath -LogFilePath $LogFilePath -TimeStamp $TimeStamp -RemediationReportFile $RemediationReportFile;

        #Build Scan Command
        $Scancmd = "$ScanscriptPath -BaseLineFile $tempScanXML -ReportFilePath $env:temp\$(New-WCReportFileName($timeStamp)) -LogFilePath $env:temp\$(New-WCReportingLogFileName($timeStamp))";
	
    }
    else {
	    #If ProcessSection is passed identify categories in section
	    if($Section -ne $null){
		    $Category = @((Get-WCRCategoriesBySection -Section $Section).Name)		
	    }
	
	    #Section to process a category or if policyIDs are passed for remediation
	    if($Category -ne $NULL) { #if ProcessCategory argument is passed 
		    
            Write-WCLog -Level info -Message ("Process Category: " + (@($Category) -join ","));
		    $xmlProcessPolicy = Get-WCRPoliciesByCategory -Category $Category
		    
            if($xmlProcessPolicy -eq $NULL) {#If category value is NULL
			    Write-WCLog -Level Error -Message ("Unable to find the category name : " + (@($Category) -join ",") + " in the baseline xml");
                $wcr.exitcode = 64
                $wcr.message = "No Policies Found for Remediation"
                return $wcr
                Exit;
		    }
		    $Policy = ($xmlProcessPolicy).ID;
	    }
			
	    if((@($Policy)).Length -eq 0) { #if no policies are passed
		    Write-WCLog -Level Error -Message ("No Policies are provided for Remediation");
            $wcr.exitcode = 64
            $wcr.message = "No Policies Found for Remediation"
            return $wcr
		    Exit;#terminate script
	    }
        elseIf((Test-WCRReportXML -PolicyIDs $Policy -RemediateAll:$RemediateAll -RemediationType $RemediationType) -eq $false) {
            #check whether the policies are processed in the report XML in case of remediationtype = revert
            Write-WCLog -Level Error -Message "Error Validating Report XML File";
            
            $wcr.exitcode = 32
            $wcr.message = "Invalid Report XML.This XML cannot be used for Revert action."
            return $wcr
            exit; #terminate script
        }
	
	    #Start Remediation
        Write-WCLog -Level info -Message ("Policy IDs : " + (@($Policy) -join ","));
        $RemediationReport = Start-WCRRemediation -ReportXMLFilePath $ReportXMLFile -PolicyIDs $Policy -RemediationType $RemediationType -HideProgress:$HideProgress -LogPath $LogPath  -LogFilePath $LogFilePath -TimeStamp $TimeStamp -RemediationReportFile $RemediationReportFile;

        #Build Scan Command
        $PolicyIDs =@();
        ForEach($pPolicy in $Policy) {$PolicyIDs += "'$pPolicy'";} #Collect Policy ID in 'PolicyID' Format
        $Scancmd = "$ScanscriptPath -BaseLineFile $tempScanXML -ReportFilePath $env:temp\$(New-WCReportFileName($timeStamp)) -LogFilePath $env:temp\$(New-WCReportingLogFileName($timeStamp)) -Policy ($($PolicyIDs -join ","))";
      
    }

    #Set the  return Object
    $wcr.robject.remediationxmlreport = $RemediationReport
    $wcr.logpath = $LogFilePath
    $wcr.logfolder = $logPath + '\' + $RemedationLogFolderName

    #endregion
    #region branding
    #Update Remediation Action in Registry
    $WCRRegPath = "HKLM:SOFTWARE\CSC\WinCompliance\Remediation\$($wctime.ToString('MM-dd-yy hh:mm:ss'))"
    Set-WCRBranding -WCRRegPath $WCRRegPath -BrandingName "Account" -BrandingValue $currentUser
    Set-WCRBranding -WCRRegPath $WCRRegPath -BrandingName "TimeStamp" -BrandingValue $wctime.ToString('MM-dd-yy hh:mm:ss')
    Set-WCRBranding -WCRRegPath $WCRRegPath -BrandingName "LogFilePath" -BrandingValue $LogFilePath
	Set-WCRBranding -WCRRegPath $WCRRegPath -BrandingName "LogFolderPath" -BrandingValue $wcr.logfolder
    Set-WCRBranding -WCRRegPath $WCRRegPath -BrandingName "RemediationReport" -BrandingValue $RemediationReport
    #endregion

    #region Rescan
    if($RemediationType -eq "Remediate" -and !($IgnoreRescan.IsPresent)) { #Action yet to be decided for revert
        if($HideProgress.IsPresent) { 
		    $Scancmd = $Scancmd + " -HideProgress";
	    }

        #Update tempscan report location in return Object
        $wcr.robject.xmlreport = $tempScanXML 

	    #Run the WC Scan
        $ScanReport = Invoke-Expression $Scancmd;

        if($ScanReport -ne $null) {
            if($ScanReport.robject.xmlreport.ToString().ToLower().Contains(".xml")) { #Request is to remediate more than one policy and return xml
                #Update Scan Status into remediation report XML
                $RemediationReport = Update-WCScanStatus -ScanReport $ScanReport.robject.xmlreport.ToString() -RemediationReport $RemediationReport -RemediateAll:$RemediateAll -PolicyIDs $Policy;
            }          
        }
    }
    #endregion

    #Identify Failed Remediations if exists
    #read remediation report
    [xml]$RemXML = Get-Content $RemediationReport

    #Identify failed remediation policy IDs
    $FailedPolicies = $RemXML.SelectNodes("//Policy") | Where-Object { $_.RemediationStatus -eq "Failed" }

    if($FailedPolicies) {
        $wcr.FailedPolicies = $FailedPolicies.ID -join "," #Update the return variable with failed policy ID
        $wcr.exitcode = 1;
        $wcr.Message = "Some of the policies failed WinCompliance Remediation";
    }
    else {
        $wcr.exitcode = 0;
        $wcr.Message = "Success";
    }
    
    return $wcr;
}
#region this segment is for remote WC reporting
elseif($PSCmdlet.ParameterSetName -eq 'wcRemoteRep') {
    $modulesPath = "$PSScriptRoot\modules"
    import-module "$modulesPath\WCRemoteCalls.psm1" -Force # load module for remote execution
	
	#Use Computer Credentials to connect to repository if not passed
	if($wcRepositoryCredential -eq $Null) { $wcRepositoryCredential = $ComputerCredential } 
	
    # now construct command to invoke remote reporting
    $wcrParams = @{}
    $wcrParams.Add('WCRepositoryPath',$WCRepositoryPath)
    if($wcRepositoryCredential) { $wcrParams.Add('wcRepositoryCredential',$wcRepositoryCredential) }
    $wcrParams.Add('Action',$RemediationType) # reporting has to be performed
    $wcrParams.Add('WCActionArgs',$Arguments)
    $wcrParams.Add('ComputerName',$ComputerName)
    if($ComputerCredential) { $wcrParams.Add('ComputerCredential',$ComputerCredential) }
    $wcrParams.Add('OutputFolder',$ReportSharePath)
    $wcrParams.Add('WaitTimeout',$WaitTimeout)
    if($PassThru) { $wcrParams.Add('PassThru',$true) }
    if($HideProgress) { $wcrParams.Add('HideProgress',$true) }
    
    # call remote reporting now
    $remResult = Invoke-WCRemoteJob @wcrParams

    # at the end, return the remote reporting return object too
    $remResult
}
#endregion this segment is for remote WC reporting - ends here
else { # highly unlikely, but just let user know something unexpected has happened
    Write-Warning "Unknown parameter set specified, cannot generate WinCompliance report"
}


