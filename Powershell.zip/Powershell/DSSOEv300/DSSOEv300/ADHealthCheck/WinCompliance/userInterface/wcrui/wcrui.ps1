﻿# WinCompliance Management Console - centralized UI that provides all WinCompliance capability
# Author : Umesh Thakur
# Created: 20-june-2016

# Modification History: 
# 22-aug-2016: by Umesh - updated with changed report viewer xaml name (ShowWCReport.ps1 -> WCReportView.ps1)
# ------------------------------------------------------------------------------------------------------------
Add-Type -AssemblyName presentationframework 
[System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms") | Out-Null

#region script functions
# this function will display a dialog box with given message and icon
Function Show-WCDialog {
param(
    [string]$message,
    [string]$title = "WinCompliance",
    [System.Windows.MessageBoxButton] $Button = [System.Windows.MessageBoxButton]::OK,
    [System.Windows.MessageBoxImage] $Icon = [System.Windows.MessageBoxImage]::Error
)
    [System.Windows.MessageBox]::Show($message,$title,$Button,$Icon)
}

# this function will set given control(s) visibility as per parameter values
# --------------------------------------------------------------------------
Function Set-ControlStatus {
param(
    $Enabled,
    $Disabled
)
    # set visibility of given controls
    foreach($ctrl in $Enabled) { $ctrl.IsEnabled = $true }
    foreach($ctrl in $Disabled) { $ctrl.IsEnabled = $false }
}

# this function will add given items to given list/combo box control
# ------------------------------------------------------------------
Function Add-WCListItems {
param(
    $ControlName,
    [ValidateSet('ComboBox','ListBox')] $ControlType,
    $ListItems, # an array of items (objects or flat arrays) to add to the $ControlName
    $Property = '', # which property of given listItems object to add?
    $TagProperty = '' # property of object that will be used to set as tag
)
    # add items by enumerating it
    foreach($li in @($ListItems)) { # force it to be an array even if it has only one element and not passed as an array
        if($ControlType -eq 'ComboBox') { $lbItem = New-Object System.Windows.Controls.ListBoxItem }
        else { $lbItem = New-Object System.Windows.Controls.ListBoxItem }
        if($Property -eq '') { $lbitem.Content = $li } # no property, add given object.. it may not have any property
        else { $lbitem.Content = $li.$Property } # add given property
        if($TagProperty.Length -gt 0) { $lbItem.Tag = $li.$TagProperty } # add tag
        [void]$ControlName.items.add($lbItem)
    }
}

# This function will set various contrals with specified baseline info. (sections/categories/policies etc.)
# ---------------------------------------------------------------------------------------------------------
Function Set-WCBaselineInfoInControls {
param(
    [string]$BaselineFile,
    [switch] $ClearControls
)
    # empty all controls that will be populated by this function
    $lbSections, $lbCategories, $lbPolicyIds | foreach { $_.Items.Clear() }

    # exit function if ClearControls param is given 
    if($ClearControls) { return }

    # if given baseline file exists then populate ocntrols with info in this baseline
    if(Test-Path -Path $BaselineFile) {
        #todo: validate that it is valid WC baseline file
        try {
            [xml]$x = Get-Content $BaselineFile
            # report name, it is only set/available in wc baseline (not in inventory)
            $tbReportName.Text = $x.SelectNodes("//RSItem[@Name='ReportName']").Value 
            Set-WCBXMLVariable -BaselineXMLFile $BaselineFile # set baseline xml object in baseline handler for further queries
            Add-WCListItems -ControlName $lbSections -ControlType ListBox -ListItems (Get-WCBSections) -Property 'Name'
            Add-WCListItems -ControlName $lbCategories -ControlType ListBox -ListItems (Get-WCBCategories) -Property 'Name'
            $pols = (Get-WCBXMLVariable).SelectNodes("//Policy") | Select-Object Id,@{N='PolicyInfo';E={"$($_.Id) ($($_.PolicyName))"}}
            Add-WCListItems -ControlName $lbPolicyIds -ControlType ListBox -ListItems $pols -Property 'PolicyInfo' -TagProperty 'Id'

        }
        catch { # todo: move this block contents to log file
            Write-Host $_.exception.message
        }
    }
}

#Function to open up File/Folder Dialog and fill tab control
#----------------------------------------------------------
Function Get-WCFileDialog {
Param(
       [ValidateSet("Folder","FileOpen","FileSave")] $Type = "FileOpen",
       $Extension # extensions to display in the dialog, valid for File type only
    )
    #textbox Name is btnname split by browse and rename btn with tb

    if($Type -eq "Folder") {
        #Show the folder dialog
        $FolderBrowser = New-Object System.Windows.Forms.FolderBrowserDialog
        $FolderBrowser.ShowDialog() | Out-Null
        $FolderBrowser.SelectedPath # return selected path
    }
    elseif($Type -eq 'FileOpen') {
        #Show File Dialog
        $ofd = New-Object Microsoft.Win32.OpenFileDialog
        #processfile extension type if extension is passed
        if($Extension -ne $null) { $ofd.filter = $Extension }
        $ofd.ShowDialog() | Out-Null
        $ofd.filename # return path of selected file
    }
    else {
        #Show File Dialog - bydefault, it will check for valid path but file name is allowed without creating it
        $sfd = New-Object Microsoft.Win32.SaveFileDialog
        #processfile extension type if extension is passed
        if($Extension -ne $null) { $sfd.filter = $Extension }
        $sfd.ShowDialog() | Out-Null
        $sfd.filename # return path of selected file
    }
}

# function to test whether Word/Excel COM object can be created or not
# use it to determine whether to enable word/excel report format in UI or not
# ----------------------------------------------------------------------------
Function Test-COMObjectCreation([validateset('Word','Excel')] [string] $ComObject) {
    # identify if word/excel are installed.. if so, enable report format check boxes for them
    try { 
        if($ComObject -eq 'Word') { $cobj = New-Object -ComObject Word.Application }
        else { $cobj = New-Object -ComObject Excel.Application }
        $cobj.quit() # quit word application and release COM object
        [void] [System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($cobj)
        $true # return true
    } 
    catch { # failed to create COM object for Word.. its not installed likely, disable checkbox
        $false # return false
    }
}

# this function will update WC inventory config file text field and categories list
# ---------------------------------------------------------------------------------
Function Set-WCInventoryControls {
param(
    [string] $InventoryFile
)
    if($InventoryFile.Length -gt 0) { # not a blank file
        if((Test-Path $InventoryFile)) { 
            # todo: add logic to validate that it is wc inventory file
            $tbInvConfigFile.Text = (Resolve-Path -Path $InventoryFile).Path
            [xml]$inv = Get-Content $tbInvConfigFile.Text
            $invCatNames = $inv.SelectNodes("//Category")
            $lbInvCategories.Items.Clear() # empty categories list first
            Add-WCListItems -ControlName $lbInvCategories -ControlType ListBox -ListItems $invCatNames -Property Name
        }
        else { 
            $tbInvConfigFile.Text = 'select inventory config file' 
            $lbInvCategories.Items.Clear() # empty categories list
        }
    }
    else { 
        $tbInvConfigFile.Text = 'specify a valid inventory config file' 
        $lbInvCategories.Items.Clear() # empty categories list
    }
}

# this function detect SOE version, set auto-detected radio text/status accordingly 
# ---------------------------------------------------------------------------------
Function Set-SOEDetectionControls {
    # detect SOE version and update text in 'Auto-detect' radio
    # todo: utilize detection mechanism used in wcReportGen.ps1. try to put that code section in a function and leverage that
    $sv = get-SOEVersion
    $rbSelectBaseline.IsChecked = $true # auto-select the option to select baseline when detection fails
    $rbAutoDetect.IsEnabled = $false # disable auto-detect radio as it has failed
    if($sv -eq $null) { 
        $sv = 'unable to detect SOE version' 
    }
    else { 
        $wcBcf = Get-WCBaselineFile -SOEVersion $sv -DetectionType WSSOE -WCConfigFilePath "$configPath\SOEVersionTable.xml"
        if(-not $wcBcf) { # couldn't find a matching baseline file
            $sv = "baseline detection for SOE $sv not available" # in SOEVersionTable, there is no entry for this SOE.. probably due to this being a newer SOE that WC does not know about
        }
        else { # matching baseline found
            if(-not (Test-WCFileExists -FileName "$SOEBaselinePath\$wcBcf")) { # but baseline file does not exist!
                $sv = "baseline file for SOE $sv does not exist"
            }
            else {
                $sv = "SOE $sv" # prefix the version with 'SOE '
                $rbAutoDetect.Tag = "$SOEBaselinePath\$wcBcf" # set tab with full path of baseline
                $rbAutoDetect.IsEnabled = $true # enable auto-detect radio on successful detection
                $rbAutoDetect.IsChecked = $true # select auto-detect radio on successful detection
            }
        }
    } 
    $rbAutoDetect.Content = ("{0} ({1})" -f $rbAutoDetect.Content, $sv)
}

# This function will add a line in DS summary TextBlock (formatted)
# -------------------------------------------------------------------
Function Add-WCRichText {
    param(
        [System.Windows.Documents.Paragraph] $Paragraph, # to add text to existing paragraph
        [string] $Text, 
        [switch] $AddHyperlink,
        [string] $Hyperlink,
        [string] $Foreground = "#FF746D6D",
        [string] $FontName, 
        [switch] $Bold, 
        [switch] $Italic,
        [switch] $AsWCReport
    ) 
    $run = New-Object System.Windows.Documents.Run
    $run.Foreground = $Foreground
    if($FontName) { $run.FontFamily = $FontName }
    if($Bold) { $run.FontWeight = [System.Windows.FontWeights]::Bold }
    if($Italic) { $run.FontStyle = [System.Windows.FontStyles]::Italic }
    $run.Text = $Text

    # construct hyper-link if user has provided parameters to do so
    if($AddHyperlink) {
        $hl = new-object System.Windows.Documents.Hyperlink -ArgumentList $run
        try { $uri = new-object uri -ArgumentList $Hyperlink }
        catch { Write-Warning $_.exception.message; Write-Warning $_.ScriptStackTrace }
        $hl.NavigateUri = $uri # navigate to $uri resource
        $hl.ToolTip  = "Click to navigate to $Hyperlink"
        if($AsWCReport) { $hl.Tag = 'wcreport' }
        # add a routed event handler for click event so that action can be performed on link-click
        $hl.AddHandler([System.Windows.Documents.Hyperlink]::ClickEvent,[System.Windows.RoutedEventHandler]{
            param(
                [object]$sender,
                [System.Windows.RoutedEventArgs]$e
            )
            #write-host "$([uri]$e.Source.NavigateURI | out-string)"
            try { 
                if($e.source.tag -ne 'wcreport') { # let OS file association take care of launching the URI
                    Start-Process $e.Source.NavigateURI 
                }
                else { # it is WC report, launch it in WC reporting GUI
                    $repLauncher = (resolve-path "$PSScriptRoot\..\psr\WCReportView.ps1").Path
                    $rptPath = ([uri]$e.Source.NavigateURI).LocalPath
                    write-host "launching with params: -NoProfile -$repLauncher -WCReport $rptPath -NoExit"
                    Start-Process powershell.exe -ArgumentList "$repLauncher -WCReport $rptPath"
                }
            } 
            catch { Write-Warning ("Failed to launch {0}" -f $e.Source.NavigateURI) }
        })
    }
    # end construct hyper-link if user has provided parameters to do so
    
    if(-not $Paragraph) {
        $Paragraph = New-Object System.Windows.Documents.Paragraph #-ArgumentList $run
        $Paragraph.Margin = "0"
        $Paragraph.Padding = "0"
    }
    # if link is given then add link, else add the text (as run object)
    if($hl) { $Paragraph.Inlines.Add($hl) } else { $Paragraph.Inlines.Add($run) }
    # add paragraph to rich text box document blocks
    $rtbReportGenInfo.Document.Blocks.Add($Paragraph) # add it to richtextbox
    
    $Paragraph # return paragraph object
}
#endregion script functions

#region scriptVariablesDeclaration
# set path to various WC folders
$modulesPath = "$PSScriptRoot\..\..\modules"
$SOEBaselinePath = "$PSScriptRoot\..\..\baseline\SOEDefault"
$logPath = "$PSScriptRoot\..\..\logs\$($ENV:COMPUTERNAME)"
$configPath = "$PSScriptRoot\..\..\config"
$reportsPath = "$PSScriptRoot\..\..\reports\$($ENV:COMPUTERNAME)"

# check to see if repoers/logs folder exist or not and create if they do not exit
if([System.IO.Directory]::Exists($logPath) -eq $false) { $null = [System.IO.Directory]::CreateDirectory($logPath) }
if([System.IO.Directory]::Exists($reportsPath) -eq $false) { $null  = [System.IO.Directory]::CreateDirectory($reportsPath) }

# store remote credentials
$remoteCreds = $null # by-default is is null. respective routine will set it

# events that should be raised in script code
$rbCheckedEvent = [System.Windows.Controls.RadioButton]::CheckedEvent
$chkClickEvent = [System.Windows.Controls.CheckBox]::ClickEvent
$chkCheckedEvent = [System.Windows.Controls.CheckBox]::CheckedEvent
#endregion scriptVariablesDeclaration

#region LoadWCModules
# import the module first that sets caller preference (verbose and debug only) (do not change this module sequence!)
Import-Module "$modulesPath\LogCallerPref.psm1" -Force
Set-CallerVerbosePreference
Set-CallerDebugPreference

#change verbose message background - doesn't work on nano
#((Get-Host).PrivateData).VerboseBackgroundColor =($host.UI.RawUI).BackGroundColor;

# load all WC required modules, forcing re-load if they're already loaded
Import-Module "$modulesPath\WCLogger.psm1" -Force
Import-Module "$modulesPath\WCUtils.psm1" -Force
Import-Module "$modulesPath\WCLSP.psm1" -Force
Import-Module "$modulesPath\WCBaselineHandler.psm1" -Force
#endregion LoadWCModules

#region read WC UI xaml file and load it
$xaml = get-content "$PSScriptRoot\wcrui.xaml" -Raw
$xaml = $xaml -replace 'mc:Ignorable="d"','' -replace "x:N",'N'
[xml]$xaml = $xaml
$xaml.Window.RemoveAttribute("x:Class") # remove x:class attribute
$Reader = New-Object System.Xml.XmlNodeReader $xaml
$wcui = [Windows.Markup.XamlReader]::Load($Reader)

#Assign the Variables to denote the GUI controls
$xaml.SelectNodes("//*[@Name]") | foreach { Set-Variable -Name "$($_.Name)" -Value $wcui.FindName($_.Name) }
#endregion read WC UI xaml file and load it

#region collapse all controls that should be, initially
$CollapseControls = ($cboServerInvFile, $wpServersTextFile, $tbServerNamesTyped, $wpRemoteCreds, $lbSections, $lbCategories `
, $lbPolicyIds, $tbPolicyFilter, $cboSelectBaseline, $wpCustomBaseline, $wpInventory, $lbInvCategories, $wpLoadPSModule)
Set-ControlStatus -Disabled $CollapseControls
#endregion collapse all controls that should be, initially

# event handler for 'localhost' radio button
$rbLocalhost.add_Checked({
    Set-ControlStatus -Disabled ($cboServerInvFile, $wpServersTextFile, $tbServerNamesTyped, $wpRemoteCreds)
})

$rbServerInvFile.add_Checked({
    Set-ControlStatus -Enabled ($cboServerInvFile, $wpRemoteCreds) -Disabled ($wpServersTextFile, $tbServerNamesTyped)
})

$rbServerNamesTyped.add_Checked({
    Set-ControlStatus -Enabled ($tbServerNamesTyped, $wpRemoteCreds) -Disabled ($wpServersTextFile, $cboServerInvFile)
})

$rbServersTextFile.add_Checked({
    Set-ControlStatus -Enabled ($wpServersTextFile, $wpRemoteCreds) -Disabled ($tbServerNamesTyped, $cboServerInvFile)
})

$btnServersTextFile.add_Click({
    $sfile = Get-WCFileDialog -Type FileOpen -Extension "Text Files (*.txt)|*.txt|All Files (*.*)|*.*"
    if($sfile.length -gt 0) { $tbServersTextFile.Text = $sfile }
    else { $tbServersTextFile.Text = 'please specify a valid text file' }
})

$rbUseLoggedInuserCreds.add_Checked({
    # set credentials as of current user
    $tbRemoteCreds.Text = $env:USERDOMAIN + '\' + $env:USERNAME
})

$rbSpecifyCreds.add_Checked({
    $tbRemoteCreds.Text = '' # blank out user creds info
})

$btnRemoteCreds.add_Click({
    $remoteCreds = Get-Credential -Message "Enter credentials that will be used for WinCompliance report generation" 
    $tbRemoteCreds.Text = $remoteCreds.UserName # set username in display
})

$rbProcessAllPolicies.add_Checked({
    Set-ControlStatus -Disabled ($lbSections, $lbCategories, $lbPolicyIds, $tbPolicyFilter)
})

$rbProcessSectionsList.add_Checked({
    Set-ControlStatus -Enabled ($lbSections) -Disabled ($lbCategories, $lbPolicyIds, $tbPolicyFilter)
})

$rbProcessCategoriesList.add_Checked({
    Set-ControlStatus -Enabled ($lbCategories) -Disabled ($lbSections, $lbPolicyIds, $tbPolicyFilter)
})

$rbProcessSelectedPolicyId.add_Checked({
    Set-ControlStatus -Enabled ($lbPolicyIds) -Disabled ($lbSections, $lbCategories, $tbPolicyFilter)
})

$rbPolicyFilter.add_Checked({
    Set-ControlStatus -Enabled ($tbPolicyFilter) -Disabled ($lbSections, $lbPolicyIds, $lbCategories)
})

$lbPolicyIds.add_SelectionChanged({
    $rbProcessSelectedPolicyId.Content = "Process selected policies by their policy id ({0} selected)" -f $lbPolicyIds.SelectedItems.Count
})

# event handler for XML report format checkbox click.. prevent un-checking it
$chkReportFormatXML.add_Click({
    if($chkReportFormatXML.IsChecked -eq $false) {
        Show-WCDialog -message "You cannot uncheck XML report formation option. Report will always be generated in XML format and any other format that you select"
        $chkReportFormatXML.IsChecked = $true
    }
})

# event handler for select report path button
$btnReportPath.add_Click({
    $rpath = Get-WCFileDialog -Type Folder
    if($rpath -ne '') { $tbReportPath.Text = $rpath } # set report path if provided. else leave to default
})

# event handler for select log path button
$btnLogPath.add_Click({
    $rpath = Get-WCFileDialog -Type Folder
    if($rpath -ne '') { $tbLogPath.Text = $rpath } # set report path if provided. else leave to default
})

$rbAutoDetect.add_Checked({
    Set-ControlStatus -Disabled ($wpCustomBaseline, $cboSelectBaseline)
    Set-WCBaselineInfoInControls -BaselineFile $rbAutoDetect.Tag 
})

$rbSelectBaseline.add_Checked({
    Set-ControlStatus -Enabled ($cboSelectBaseline) -Disabled ($wpCustomBaseline)
    if($cboSelectBaseline.SelectedItem.Tag.Length -gt 0) { # when this radio is selected, set baseline controls as per previous selection
        Set-WCBaselineInfoInControls -BaselineFile $cboSelectBaseline.SelectedItem.Tag 
    }
    else { # empty control population if no earlier baseline was selected/specified 
        Set-WCBaselineInfoInControls -ClearControls
    }
})

$rbCustomBaseline.add_Checked({
    Set-ControlStatus -Enabled ($wpCustomBaseline) -Disabled ($cboSelectBaseline)
    if($rbCustomBaseline.Tag.Length -gt 0) { # earlier selected baseline is set in tag, use it
        Set-WCBaselineInfoInControls -BaselineFile $rbCustomBaseline.Tag
    }
    else { # empty control population if no earlier baseline was selected/specified 
        Set-WCBaselineInfoInControls -ClearControls
    }
})

$btnCustomBaseline.add_Click({
    $baseline = Get-WCFileDialog -Type FileOpen -Extension "WinCompliance Baseline Files (*.xml)|*.xml"
    if($baseline.length -ne 0) { # non-empty file, use it
        $tbCustomBaseline.Text = $baseline
        Set-WCBaselineInfoInControls -BaselineFile $baseline
        $rbCustomBaseline.Tag = $baseline # add selected baseline as tag for radio
    }
    else { # user cancelled in the dialog or something weird has happened
        # do nothing
    }
})

$chkCollectInventory.add_Click({
    if($chkCollectInventory.IsChecked) { # checked
        Set-ControlStatus -Enabled ($wpInventory) 
    }
    else { # unchecked
        Set-ControlStatus -Disabled ($wpInventory) 
    }
})

$chkInvCategories.add_Click({
    if($chkInvCategories.IsChecked) { # checked
        Set-ControlStatus -Enabled ($lbInvCategories) 
    }
    else { # unchecked
        Set-ControlStatus -Disabled ($lbInvCategories) 
    }
})

$btnInvConfigFile.add_Click({
    $invFile = Get-WCFileDialog -Type FileOpen -Extension "WinCompliance Inventory Files (*.xml)|*.xml"
    Set-WCInventoryControls -InventoryFile $invFile
})

$chkLoadPSModule.add_Click({
    if($chkLoadPSModule.IsChecked) { # checked
        Set-ControlStatus -Enabled ($wpLoadPSModule) 
    }
    else { # unchecked
        Set-ControlStatus -Disabled ($wpLoadPSModule) 
    }
})


$cboSelectBaseline.add_SelectionChanged({
    #write-host "$($cboSelectBaseline.SelectedItem.Tag)"
    # pass full path of selected baseline file to the function to set control defaults
    Set-WCBaselineInfoInControls -BaselineFile $cboSelectBaseline.SelectedItem.Tag 
})

# event handler for 'review & start scan' button
# -----------------------------------------------
$btnStartScan.add_Click({
    $ht = @{} # create empty hash table to hold report gen parameters
    $rtbReportGenInfo.Document.Blocks.Clear() # clear report info rich text box
    $null = Add-WCRichText -Text "WinCompliance report generation information are displayed below" -Bold

    # set parameters related to report gen on local host
    if($rbLocalhost.IsChecked) { 
        # baseline file selection
        if($rbAutoDetect.IsChecked) { # add auto-detect param
            $ht.Add('DetectBaseline',$true) # use auto-detection
            $ht.Add('DetectionType','WSSOE') # use windows server SOE detection, though it is default in report gen script
            $p = Add-WCRichText -Text "Report will be generated using autodetected baseline file "
            $null = Add-WCRichText -Paragraph $p -Text $rbAutoDetect.Tag -AddHyperlink -Hyperlink $rbAutoDetect.Tag -Foreground "Blue"
        }
        elseif($rbSelectBaseline.IsChecked) { # use selected one of existing baseline
            if($cboSelectBaseline.SelectedItem.Tag.length -gt 0) {
                $ht.Add('BaselineFile',$cboSelectBaseline.SelectedItem.Tag) # selected baseline path
                $p = Add-WCRichText -Text "Report will be generated using user selected baseline file "
                $null = Add-WCRichText -Paragraph $p -Text $cboSelectBaseline.SelectedItem.Tag -AddHyperlink -Hyperlink $cboSelectBaseline.SelectedItem.Tag -Foreground "Blue"
            }
            else { # no baseline is selected from drop-down
                Show-WCDialog -message "No baseline file selected. You must select a baseline file or use auto-detect option to generate a report" | Out-Null
                return # validation failed, exit the function
            }
        }
        elseif($rbCustomBaseline.IsChecked) { # user specified a custom baseline
            $ht.Add('BaselineFile',$tbCustomBaseline.Text) # specified baseline path
            $p = Add-WCRichText -Text "Report will be generated using user a custom baseline file "
            $null = Add-WCRichText -Paragraph $p -Text $tbCustomBaseline.Text -AddHyperlink -Hyperlink $tbCustomBaseline.Text -Foreground "Blue"
        }
        else { # do not anticipate this but if something really goes out of way..
            Show-WCDialog -message "An unexpected error has occured, cannot determine baseline selection." | Out-Null
            return # validation failed, exit the function
        }

        # policy processing/filtering here - nothing to do if $rbProcessAllPolicies.IsChecked
        if($rbProcessAllPolicies.IsChecked) {
            $null = Add-WCRichText -Text "All applicable policies defined in selected baseline file will be processed"
        }
        # process selected policy sections if selected
        if($rbProcessSectionsList.IsChecked) { 
            if($lbSections.SelectedItems.Count -gt 0) {
                $ht.Add('Section',@($lbSections.SelectedItems.Content)) # selected sections
                $null = Add-WCRichText -Text "Only policies under selected sections ($($lbSections.SelectedItems.Count)) will be processed"
            }
            else { # user didn't select any
                Show-WCDialog -message "You must select at least one section to continue with report generation" | Out-Null
                return # validation failed, exit the function
            }
        }
        # process selected policy categories if selected
        elseif($rbProcessCategoriesList.IsChecked) { 
            if($lbCategories.SelectedItems.Count -gt 0) {
                $ht.Add('Category',@($lbCategories.SelectedItems.Content)) # selected categories
                $null = Add-WCRichText -Text "Only policies under selected categories ($($lbCategories.SelectedItems.Count)) will be processed"
            }
            else { # user didn't select any
                Show-WCDialog -message "You must select at least one category to continue with report generation" | Out-Null
                return # validation failed, exit the function
            }
        }
        # process selected policy Ids if selected
        elseif($rbProcessSelectedPolicyId.IsChecked) { 
            if($lbPolicyIds.SelectedItems.Count -gt 0) {
                $ht.Add('Policy',@($lbPolicyIds.SelectedItems.Tag)) # selected policy ids
                $null = Add-WCRichText -Text "Only selected policies ($($lbPolicyIds.SelectedItems.Count)) will be processed"
            }
            else { # user didn't select any
                Show-WCDialog -message "You must select at least one policy to continue with report generation" | Out-Null
                return # validation failed, exit the function
            }
        }
        # process policies based on given policy filter, if specified
        elseif($rbPolicyFilter.IsChecked) { 
            if($tbPolicyFilter.Text.Length -gt 9) { # at least a filter like Id -eq 'A'
                $ht.Add('Filter',@($tbPolicyFilter.Text)) # policy filter
                 $null = Add-WCRichText -Text "Only policies matching policy filter will be processed"
            }
            else { # user didn't select any
                Show-WCDialog -message "You must specify a valid policy filter to continue with report generation" | Out-Null
                return # validation failed, exit the function
            }
        }

        # report formats - populate an array of all report formats
        $reportFormats = '' # empty array of report formats
        if($chkReportFormatXML.IsChecked) { $reportFormats = "XML" } # XML report format selected
        if($chkReportFormatCSV.IsChecked) { $reportFormats = "$reportFormats,CSV" } # XML report format selected
        if($chkReportFormatCSCTI.IsChecked) { $reportFormats = "$reportFormats,CSC_TI" } # XML report format selected
        if($chkReportFormatHTML.IsChecked) { $reportFormats = "$reportFormats,HTML" } # XML report format selected
        if($chkReportFormatWord.IsChecked) { $reportFormats = "$reportFormats,Word" } # XML report format selected
        if($chkReportFormatExcel.IsChecked) { $reportFormats = "$reportFormats,Excel" } # XML report format selected
        if($reportFormats -eq '') { # user didn't select any! 
            Show-WCDialog -message "You must select at least one report format to continue with report generation" | Out-Null
            return # validation failed, exit the function
        }
        else {
            $ht.Add('ReportFormat',$reportFormats.Split(',')) # array of report formats!
            $null = Add-WCRichText -Text "Report will be generated in $($reportFormats -join ',') format(s)"
        }

        # set report name parameter
        if($tbReportName.Text.Length -eq 0) { 
            Show-WCDialog -message "A report name must be specified. Please specify a report name"
            return # validation failed, exit the function
        }
        else { $ht.Add('ReportName',$tbReportName.Text) }
        # set report path parameter
        if($tbReportPath.Text.Length -eq 0) { # user didn't specify report path 
            Show-WCDialog -message "You must specify a valid report file path."
            return # validation failed, exit the function
        }
        else { 
            $ht.Add('ReportFilePath',$tbReportPath.Text) 
            $p = Add-WCRichText -Text "Report file path is "
            $null = Add-WCRichText -Paragraph $p -Text $tbReportPath.Text -AddHyperlink -Hyperlink $tbReportPath.Text -Foreground "Blue"
        } 
        # set log file path parameter
        if($tbLogPath.Text.Length -eq 0) { # user didn't specify log path 
            Show-WCDialog -message "You must specify a valid logs file path."
            return # validation failed, exit the function
        }
        else { 
            $ht.Add('LogFilePath',$tbLogPath.Text)
            $p = Add-WCRichText -Text "Log file path is "
            $null = Add-WCRichText -Paragraph $p -Text $tbLogPath.Text -AddHyperlink -Hyperlink $tbLogPath.Text -Foreground "Blue"
        } 
        
        # set log level - if debug is selected then it will be debug else it will be info
        if($chkLogLevelDebug.IsChecked) { $ht.Add('LogLevel','Debug') }
        elseif($chkLogLevelInfo.IsChecked) { $ht.Add('LogLevel','Info') } 
        else { # none is checked, show error
            Show-WCDialog -message "You must select at least one log level"
            return # validation failed, exit the function
        }

        # inventory collection parameters
        if($chkCollectInventory.IsChecked) {
            if($tbInvConfigFile.Text.Length -eq 0) {
                Show-WCDialog "You must select a valid inventory configuration file"
                return # validation failed, exit the function
            }
            else { # add inventory collection info
                $ht.Add('CollectInventory',$true)
                $ht.Add('InventoryConfigFile',$tbInvConfigFile.Text)
                $p = Add-WCRichText -Text "Inventory will be collected using configuration file "
                $null = Add-WCRichText -Paragraph $p -Text $tbInvConfigFile.Text -AddHyperlink -Hyperlink $tbInvConfigFile.Text -Foreground "Blue"
                if($chkInvCategories.IsChecked) { # user selected to process specific inventory categories
                    if($lbInvCategories.SelectedItems.Count -eq 0) {
                        Show-WCDialog -message "You must select at least one inventory category to continue with inventory generation"
                        return # validation failed, exit the function
                    }
                    else {
                        $ht.Add('InventoryCategory',$lbInvCategories.SelectedItems.Content)
                        $null = Add-WCRichText -Text ("Only selected inventory categories ({0}) will be processed" -f $lbInvCategories.SelectedItems.Count)
                    }
                }
            }
        }

        # prevent GUI report from appearing if selected.. else show it
        if($chkPreventReportGUI.IsChecked -eq $false) { 
            $ht.Add('ShowGUIReport',$true) 
            $null = Add-WCRichText -Text "Report will be displayed after report generation" -Foreground "Green"
        }
        else { $null = Add-WCRichText -Text "Report will not be displayed after report generation" -Foreground "Maroon" }

        # if given to load additional module then add it
        if($tbPSModulePath.Text.Length -gt 0) { 
            $ht.Add('ImportModule',$tbPSModulePath.Text) 
            $null = Add-WCRichText -Text ("User supplied PowerShell module {0} will be imported before report generation" -f $tbPSModulePath.Text)
        }

        # start report generation using background jobs
        $tiGenWCReportStatus.Visibility = "Visible"
        $tiGenWCReport.Visibility = "Collapsed" # hide tab that provids params selections
        $tcReportGen.SelectedItem = $tiGenWCReportStatus # select report gen status tab
        # create timer to track progress
        
        $repGenScript = (Resolve-Path -Path "$PSScriptRoot\..\..\WCReportGen.ps1").Path
        $sbWCRepGen = [scriptblock]::Create("$repGenScript @Using:ht")
        $p = Add-WCRichText -Text "Performing compliance check using $sbWCRepGen"
        $null = Add-WCRichText -Paragraph $p -Text "$($ht | Out-String)" -FontName "Courier New" # show param hash too
        #$script:wcrJob = Invoke-Command -ScriptBlock $sbWCRepGen -AsJob -ComputerName $env:COMPUTERNAME
        $script:wcrJob = Start-Job -ScriptBlock $sbWCRepGen # report gen using jobs

        Add-WCRichText -Text "Please wait while report is being generated.." -Foreground "DarkBlue"
        $rtbReportGenInfo.ScrollToEnd() # scroll to end of rich text box

        # enable timer that tracks the report generation progress and reset progress bar
        $pbReportGenLocal.Value = 0 # reset the progress bar
        $timer.IsEnabled = $true 
        $timer.Start()
        # end report generation using background jobs
    }
})

# event handler for 'Close' button on report gen progress and status tab
# ----------------------------------------------------------------------
$btnClose.add_Click({
    # close report gen status/progress tracking tab and make report gen params tab visible
    $tiGenWCReportStatus.Visibility = "Collapsed"
    $tiGenWCReport.Visibility = "Visible" 
    $tcReportGen.SelectedItem = $tiGenWCReport # select report gen params tab
})

# event handler for EXIT button, that closes WinCompliance and exit
$btnExit.add_Click({
    $message = "Are you sure that you want to close and exit WinCompliance Report generation GUI?"
    $res = Show-WCDialog -message $message -title "WinCompliance" -Button YesNo -Icon Question
    if($res -eq 'Yes') { 
        $wcui.Close()
        exit 
    }
})



#region set timer here
# Create and start timer to keep updating the Summary of selection
$timer = new-object System.Windows.Threading.DispatcherTimer            
$timer.Interval = [TimeSpan]"0:0:1.00" #run every 1 second
 
# this timer tick event will track progress of WC report gen job and report progress + output
# --------------------------------------------------------------------------------------------
$timer.Add_Tick({
    # show report generation progress while it is running in background
    if($script:wcrJob.State -eq 'running') {    
        # some policies invoke powershell cmd that starts their own progress bars and they make this progress bar display inconsistent. so discarding them
        if($script:wcrJob.ChildJobs[0].Progress[-1].PercentComplete -ge $pbReportGenLocal.Value) {
            $pbReportGenLocal.Value = $script:wcrJob.ChildJobs[0].Progress[-1].PercentComplete
        }
    }
    else { # job not running, either completed or failed or something else
        $timer.Stop()
        $timer.IsEnabled = $false # not enabled

        if($script:wcrJob.State -eq 'Failed') {
            $null = Add-WCRichText -Text "WinCompliance report generation failed" -Foreground 'Red'
            $null = Add-WCRichText -Text $script:wcrJob.ChildJobs[0].JobStateInfo.Reason.Message -Foreground 'Red'
            $null = Add-WCRichText -Text $script:wcrJob.ChildJobs[0].Error -Foreground 'Red'
            Show-WCDialog -message "WinCompliance report generation failed!" -title "WinCompliance" -Icon Error
        }
        elseif($script:wcrJob.State -eq 'completed') {
            $wcrOut = $script:wcrJob.ChildJobs[0].Output[0] # output generated by the report gen job
            # print out job results in summary richtextbox
            $p = Add-WCRichText -Text ("Return code: ") -Foreground 'Blue'
            $null = Add-WCRichText -Paragraph $p -Text $wcrOut.exitcode 
            $p = Add-WCRichText -Text ("Return message: ") -Foreground 'Blue'
            $null = Add-WCRichText -Paragraph $p -Text $wcrOut.message 

            if($wcrOut.logpath.length -ne 0) { 
                $p = Add-WCRichText -Text "Log path: "
                $null = Add-WCRichText -Paragraph $p -Text $wcrOut.logpath -AddHyperlink -Hyperlink $wcrOut.logpath -Foreground "Blue" 
            }
            
            # show path for various reports
            if($wcrOut.robject.xmlreport.length -gt 0) { 
                $p = Add-WCRichText -Text "Report path: " 
                $p = Add-WCRichText -Paragraph $p -Text $wcrOut.robject.xmlreport -AddHyperlink -Hyperlink $wcrOut.robject.xmlreport -Foreground "Blue"
                $p = Add-WCRichText -Paragraph $p -Text " ("
                $p = Add-WCRichText -Paragraph $p -Text "Launch WinCompliance GUI Report" -AddHyperlink -Hyperlink $wcrOut.robject.xmlreport -Foreground "Blue" -AsWCReport
                $p = Add-WCRichText -Paragraph $p -Text " )"
                
            }
            if($wcrOut.robject.inventoryreport.length -gt 0) { 
                $p = Add-WCRichText -Text "Inventory report path: "
                $null = Add-WCRichText -Paragraph $p -Text $wcrOut.robject.inventoryreport -AddHyperlink -Hyperlink $wcrOut.robject.inventoryreport -Foreground "Blue"
            }
            if($wcrOut.robject.csvreport.length -gt 0) { 
                $p = Add-WCRichText -Text "CSV report path: "
                $null = Add-WCRichText -Paragraph $p -Text $wcrOut.robject.csvreport -AddHyperlink -Hyperlink $wcrOut.robject.csvreport -Foreground "Blue"
                #$wcrOut.robject.csvreport) -Foreground 'Blue'
            }
            if($wcrOut.robject.htmlreport.length -gt 0) { 
                $p = Add-WCRichText -Text "HTML report path: " 
                $null = Add-WCRichText -Paragraph $p -Text $wcrOut.robject.htmlreport -AddHyperlink -Hyperlink $wcrOut.robject.htmlreport -Foreground "Blue"
                #$wcrOut.robject.htmlreport) -Foreground 'Blue'
            }
            if($wcrOut.robject.wordreport.length -gt 0) { 
                $p = Add-WCRichText -Text "WORD report path: "
                $null = Add-WCRichText -Paragraph $p -Text $wcrOut.robject.wordreport -AddHyperlink -Hyperlink $wcrOut.robject.wordreport -Foreground "Blue" 
                #$wcrOut.robject.wordreport) -Foreground 'Blue'
            }
            if($wcrOut.robject.excelreport.length -gt 0) { 
                $p = Add-WCRichText -Text "EXCEL report path: "
                $null = Add-WCRichText -Paragraph $p -Text $wcrOut.robject.excelreport -AddHyperlink -Hyperlink $wcrOut.robject.excelreport -Foreground "Blue"
                # $wcrOut.robject.excelreport) -Foreground 'Blue'
            }

            # now do further message displays based on whether it failed or passed
            if($wcrOut.exitcode -eq 0)  { # report gen passed
                # if single policy is processed then prevent GUI report launching as there won't be any report generated
                # determine if single policy was processed
                if($wcrOut.message.startsWith("Single policy")) { $singlePolProcessed = $true } 
                else { $singlePolProcessed = $false }
                
                if($singlePolProcessed) { 
                    $ccmsg = "WinCompliance single policy compliance check completed successfully." 
                    $null = Add-WCRichText -Text "single policy processed, report generation and display is ignored" -Foreground 'Maroon' -Italic
                }
                else { $ccmsg = "WinCompliance compliance check completed successfully." }
                
                $null = Add-WCRichText -Text $ccmsg -Foreground 'Green' # light green
                
                
                $rtbReportGenInfo.ScrollToEnd() # let user see it all

                # alter message to display based on whether user has selected to display or hide it
                if($chkPreventReportGUI.IsChecked -eq $false  -and $singlePolProcessed -eq $false) {
                    $ccmsg = "$ccmsg Click OK to launch the report in a separate window."
                }
                # show the dialog now
                $rl = Show-WCDialog -message $ccmsg -title "WinCompliance" -Icon Information

                # if user has selected to launch the report in GUI then do it
                if($chkPreventReportGUI.IsChecked -eq $false  -and $singlePolProcessed -eq $false) {
                    $repCmd = ("$PSScriptRoot\..\psr\WCReportView.ps1 -WCReport {0}" -f $wcrOut.robject.xmlreport)
                    #Invoke-Expression $repCmd
                    Start-Process -FilePath powershell.exe -ArgumentList $repCmd
                }
            }
            else { # it has failed for some reason.. if single policy and it fails, this will come here
                if($wcrOut.message.startsWith("Single policy")) { 
                    $null = Add-WCRichText -Text "single policy processed, report generation and display is ignored" -Foreground 'Maroon' -Italic
                    $null = Add-WCRichText -Text "WinCompliance single policy compliance check failed with exit code $($wcrOut.exitcode)." -Foreground 'Red'
                    Show-WCDialog -message "WinCompliance single policy compliance check failed with exit code $($wcrOut.exitcode)." -title "WinCompliance" -Icon Error
                }
                else { 
                    $null = Add-WCRichText -Text "WinCompliance report generation failed" -Foreground 'Red'
                    $null = Add-WCRichText -Text $script:wcrJob.ChildJobs[0].Error[0] -Foreground 'Red'
                    Show-WCDialog -message "WinCompliance report generation failed with exit code $($wcrOut.exitcode)" -title "WinCompliance" -Icon Error
                }
                
            }
        }
        else { # liked failed or some other issues
            $null = Add-WCRichText -Text "Unable to determine WinCompliance report generation status" -Foreground 'Orange' 
            $null = Add-WCRichText -Text "Job finished with state $($script:wcrJob.State)" 
            Show-WCDialog -message "WinCompliance report generation failed due to unexpected reasons" -title "WinCompliance" -Icon Error 
        }
        # scroll to end of rich text box so that latest updates are visible
        $rtbReportGenInfo.ScrollToEnd()
    }
})

#endregion

#region set UI defaults when script is loaded
# add GotFocus event handler to select all text in TextBox when they receive keyboard focus
$tbServersTextFile, $tbPolicyFilter, $tbServerNamesTyped, $tbRemoteCreds, $tbCustomBaseline, $tbReportName `
, $tbReportPath, $tbLogPath, $tbInvConfigFile, $tbPSModulePath | foreach { $_.add_GotFocus({ $this.SelectAll() }) }

# set localhost radio with local host name
$rbLocalhost.Content = ("{0} ({1})" -f $rbLocalhost.Content,$env:COMPUTERNAME)
$rbUseLoggedInuserCreds.RaiseEvent($rbCheckedEvent) # set current logged-in user name in credentials text box

# test and enable/disable word/excel check boxes
$ex = (Test-COMObjectCreation -ComObject Excel)
$wd = (Test-COMObjectCreation -ComObject Word)
$chkReportFormatExcel.IsEnabled = $ex
$chkReportFormatWord.IsEnabled = $wd

# set report paths as per launch path
$tbReportPath.Text = (Resolve-Path -Path $reportsPath).Path
$tbLogPath.Text = (Resolve-Path -Path $logPath).Path
Set-WCInventoryControls -InventoryFile "$SOEBaselinePath\wcInventory.xml"

# detect SOE version, set auto-detected radio text/status accordingly 
Set-SOEDetectionControls

# hide tab that shows WC report generation progress
$tiGenWCReportStatus.Visibility = "Collapsed"

# detect all available baseline files and add them to the baselines combo box
# todo: use logic to validate individual detected baseline XML and only add them that are valid for WC Report generation
Get-ChildItem $SOEBaselinePath -Filter *.xml | foreach {
    try { # check if it is valid WC reporting/remediation baseline file
        [xml]$xb = Get-Content $_.FullName
        if($xb.WinCompliance -ne $null) { $isValidBaseline = $true } else { $isValidBaseline = $false } 
    } catch { $isValidBaseline = $false }
    # if it is a valid WC baseline then add it to the combo for selection
    if($isValidBaseline -eq $true) { # this is a valid baseline
        $listItem = New-Object System.Windows.Controls.ComboBoxItem
        $listItem.Content = $_.BaseName
        $listitem.Tag = $_.FullName # full name the control as per baseline file name, will be used to read it on selection
        $listItem.Padding = "2,2,2,2"
        [void]$cboSelectBaseline.Items.Add($listItem)
    }
}
#endregion set UI defaults when script is loaded

# display WC UI window
$wcui.showDialog()