#requires -version 4.0
# Script to perform Active Directory HealthCheck.
# Author: ArunKumar Bavirisetti
# Update Date  : 29-Nov-2016
# Copyright  : @Platform Wintel SOE, CSC. 
# ------------------------------------------------------------------------------------------------------------

[CmdletBinding()]
Param(
[string]$username = "",
[string]$domain = "",
[string]$domainsToScan = "",
[Parameter(Mandatory = $true)][system.security.securestring]$password = (read-host -AsSecureString)
)

#region Validate And Load Modules
foreach( $module in ('HCLogger.psm1','LogCallerPref.psm1','AD_Healthcheck.psm1')) {
    $cModulePath = "$PSScriptRoot\modules\$module"
    if(-not (Test-Path -Path $cModulePath)) {
        Write-Host "[adhealthcheck] unable to find and load $cModulePath. Verify that this module exists and try again."
        return 'adhealthcheck_modules_load_error'
        break
    }
}

#importing all the ADHealthCheck modules
Import-Module "$PSScriptRoot\Modules\LogCallerPref.psm1" -Force
# call verbose writing functions
Set-CallerVerbosePreference
Set-CallerDebugPreference
Import-Module "$PSScriptRoot\Modules\HCLogger.psm1" -Force
Import-Module "$PSScriptRoot\Modules\AD_Healthcheck.psm1" -Force

#endregion Validate And Load Modules

#region change verbose message background
((Get-Host).PrivateData).VerboseBackgroundColor =($host.UI.RawUI).BackGroundColor;
#endregion

#region Set log path to static location C:\Support\Logs\DSSOE
$LogPath = "$PSScriptRoot\Logs"
#endregion

#region create the logpath folder, set log file path & start the logging
#checking if logfile folder C:\Support\Logs\DSSOE exists; create if it does not
If(-not (Test-Path $LogPath)) {
    New-Item -ItemType Directory -Path $LogPath -Force | Out-Null
}

[string] $HCLogFile = "$($LogPath)\DSADhealthcheck-$((Get-Date).ToString('MMddyyyy-hhmmss')).log"
#calling functions from the hclogger.psm1 module
Set-HCLogFile -LogPath $HCLogFile
# script name as log header
Write-HCLog -Level info -Message "[$($PSCommandPath.Split('\')[-1])]" 
Write-HCLog -Level info -Message "[adhealthcheck]DSADHealthCheck script logging started" 
#endregion create the logpath folder, set log file path & start the logging

#region Test If User Is Admin or not
# checking if script is running with administrative privileges
If((Test-IsCurrentUserAdmin) -eq $false) {
    Write-HCLog -level error -message "[adhealthcheck] This script must be run using administrative privileges"
    return 'hc_no_admin_privileges'
    Exit
}
#endregion Test If User Is Admin or not

# region verify this server is not a domain controller! 
if((Test-ServerIsDC) -ne $true) {
    Write-HCLog -level error -message "[adhealthcheck] Server $($env:COMPUTERNAME) is not a domain controller. Execute the script on DC."
    return 'hc_server_is_not_dc'
    exit
}
#endregion
Write-HCLog -Level Info -Message "[adhealthcheck]Decrypting user provided password"
#decrypting secure pwd string
$bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($password)
$pwd = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr)

#validate if given user is part of ent admin grp or not
Write-HCLog -Level Info -Message "[adhealthcheck]validate if given user is part of ent admin grp or not"
Try {
$GroupStatus = Test-HCGroupMembership -Domain $domain -UserName $username -Password $pwd -IsEnterpriseAdmins

                If($GroupStatus -eq $true) {
                    Write-HCLog -Level Info -Message "[adhealthcheck]Group membership is successfully validated"
                }
                Else {
                    Write-HCLog -Level error -Message "[adhealthcheck]Group membership validation failed. Specified User is not a member of the Enterprise Admins group. Make sure the specified User account has Enterprise Admin rights."
                    return 'ADHealthCheckUserIsNotEnterpriseAdmins'
                }
            }
            Catch {
                Write-HCLog -Level error -Message "[adhealthcheck]An error occurred while validating the group membership of the user account"
                Write-HCLog -Level error -Message "$($_.Exception.Message)"
                return 'ADHealthCheckErrorValidatingEnterpriseAdminRights'
            }

#Check forest connection
Write-HCLog -Level Info -Message "[adhealthcheck]Checking connection to forest"
$obj = Set-ADDSForest -domain $domain -username $username -password $pwd
if($obj -ne $true)
{
Write-HCLog -Level error -Message "[adhealthcheck]Forest connection failed with given credentials"
Write-Host "Forest_connection_failed" -ForegroundColor Red
exit
}

#Validate domains to scan variable
Write-HCLog -Level Info -Message "[adhealthcheck]Validating value given in domainstoscan: $domainsToScan"
if(Test-ADDSDomainValue -DomainsToScan $domainsToScan)
{
$tempArr = $domainsToScan.Split(",")
    foreach($dm in $tempArr)
    {
        if(!(Test-ADDSDomainExists -domain $dm))
        {
        Write-HCLog -Level error -Message "[adhealthcheck]Invalid Domain:$dm"
        Write-Host "Invalid Domain:$dm" -ForegroundColor Red
        exit
        }
    }
}
else
{
Write-HCLog -Level error -Message "[adhealthcheck]Invalid DomainsToScan value:$domainsToScan"
Write-Host "Invalid DomainsToScan value:$domainsToScan" -ForegroundColor Red
exit
}

$invpath = Set-ADWCInventory -domainstoscan $domainsToScan #creating xml file for wincompliance inventory scan
Write-HCLog -Level Info -Message "[adhealthcheck]Inventory file generated at: $invpath"

Write-HCLog -Level Info -Message "[adhealthcheck]Calling function to set reports path"
set-reportpath -domainsToScan $domainsToScan #folder creation for saving html output


#Building command for calling wincompliance scan
$wincompath = "$PSScriptRoot\WinCompliance"
$winCmd = "`'$winCompath\WCReportGen.ps1`' -BaseLineFile `'$winCompath\baseline\dssoe\dssoe300.xml`' -ShowGUIReport -CollectInventory -InventoryConfigFile `'$invpath`' -policy `'pp701`',`'pp702`'"
$winCmd = "& $winCmd"
Write-HCLog -Level Info -Message "[adhealthcheck]Command generated for scan $winCmd"
Write-HCLog -Level Info -Message "[adhealthcheck]calling wincompliance"
Invoke-expression -command $winCmd
Write-HCLog -Level Info -Message "[adhealthcheck]calling cleanup function for deletion of inventory file $invpath"
Start-DSCleanupInventoryXML $invpath



