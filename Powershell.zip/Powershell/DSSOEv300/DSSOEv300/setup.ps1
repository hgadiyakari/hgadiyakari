﻿#requires -version 5.0
# Script to perform DXC DSSOE (Directory Services SOE) installation.
# Requires command-line parameters be passed for unattended command-line installation and an updated XML answer file for unattended answer file installation
# Author: Umesh Thakur, Tarun Rajvanshi, ArunKumar Bavirisetti
# Update Date  : 21-March-2017
# Copyright  : @Platform Wintel SOE, DXC. 
# ------------------------------------------------------------------------------------------------------------

#Below is the help file contents of the setup.ps1 script

<#
.SYNOPSIS
Performs unattended installation of DXC Directory Services SOE (DSSOE) v3.0.0

.DESCRIPTION
This script installs DXC Directory Services SOE (DSSOE) v3.0.0 in fully unattended way. You can either provide 
an unattended installation XML file (a template is availalbe under CONFIG folder of the package) or specify
command line parameters for the script to perform the installation. 

The script is supported on Windows Server 2016 Technical Preview 5 operating system.

Installation logs can be found under C:\SUPPORT\LOGS\DSSOE folder.

.PARAMETER AnswerFile
Specify path to DSSOE unattended installation answer file. Template unattended answer files (dssoe.xml, NewDomainNewForest.xml, NewChildDomain.xml, NewTreeDomain.xml, AdditionalDC.xml, dsParamsTemplate.xml) are available under CONFIG folder of the package which can be used to create an answer file to use with this parameter.

.PARAMETER NewDomainNewForest
Specify this parameter to build the first Domain Controller (Root DC) in a new forest.

.PARAMETER AdditionalDC
Specify this parameter to build an Additional Domain Controller in an existing domain.

.PARAMETER NewChildDomain
Specify this parameter to build the first Domain Controller in a new child domain.

.PARAMETER NewTreeDomain
Specify this parameter to build the first domain controller in a new tree domain.

.PARAMETER UserName
Specify the user name that corresponds to the account used to install the domain controller. For NewDomainNewForest build the Username should be an account with local administrator privileges. For NewChildDomain & NewTreeDomain builds the Username should be an account with Enterprise admin privileges. For Additional DC build the Username should be an account with Domain admin (preferably) or Enterprise admin privileges.

.PARAMETER Domain
Specify the fully qualified domain name (FQDN) for the account mentioned in the UserName Parameter. This parameter is not applicable to the NewDomainNewForest build type.

.PARAMETER Password
Specify the password for the account mentioned in the UserName Parameter.

.PARAMETER PassKey
PassKey is a text (any text) that is used for hashing and encryption of the password to ensure that it cannot be decrypted without PassKey. Refer to Examples section for demonstration.

.PARAMETER NewDomainName
Specify the Fully Qualified Domain Name for the new forest. An example of a valid forest name is 'Myforest.com'. This parameter is Only applicable to NewDomainNewForest build scenario. 

.PARAMETER NewDomainNetBIOSName
Specify a domain NetBios name for the new forest. A valid domain NetBIOS name contains [a-z 0-9 -] chars only. An example of a valid domain NetBIOS name is 'Myforest'. This parameter is Only applicable to NewDomainNewForest build scenario.

.PARAMETER ParentDomainName
Specify the Fully Qualified Domain Name of the parent domain underneath which the new Child domain needs to be created. This parameter is only applicable to NewChildDomain build scenario. 

.PARAMETER ChildDomainName
Specify a single label name for the new child domain. The child domain name must only contain [a-z 0-9 -] chars. An example of a valid single label name is 'Mychild'. This parameter is only applicable to the NewChildDomain build scenario.

.PARAMETER ChildDomainNetBIOSName
Specify a NetBios name for the new child domain. A domain NetBIOS name must only contain [a-z 0-9 -] chars. An example of a valid domain NetBIOS name is 'Mychild'. This parameter is only applicable to NewChildDomain build scenario.

.PARAMETER ForestRootDomain
Specify the Fully Qualified Name of the root domain of the forest for the creation of the new tree namespace. This parameter is only applicable to NewTreeDomain build scenario.

.PARAMETER TreeDomainName
Specify the Fully Qualified name for the new Tree domain. An example of a valid Tree domain name is 'Mytree.com'. This parameter is only applicable to the NewTreeDomain build scenario.

.PARAMETER TreeDomainNetBIOSName
Specify a NetBios name for the new Tree domain. A domain NetBIOS name must only contain [a-z 0-9 -] chars. An example of a valid domain NetBIOS name is 'Mytree'. This parameter is only applicable to NewTreeDomain build scenario.

.PARAMETER ADDatabasePath
Specify the folder path for Active Directory database files. If the specified folder already exists then the script will delete the existing one & recreate it. An example on a valid Active Directory Database path is 'E:\NTDS-DB'.

.PARAMETER ADLogfilePath
Specify the folder path for Active Directory log files. If the specified folder already exists then the script will delete the existing one and recreate it. An example of a valid Active Directory log file path is 'D:\NTDS-LOGS'.

.PARAMETER ADSysvolPath
Specify the folder path for Active Directory SYSVOL tree structure. If the specified folder already exists then the script will delete the existing one and recreate it. An example of a valid Active Directory SYSVOL path is 'E:\SYSVOL'.

.PARAMETER SafeModeAdminPass
Specify the Safe Mode Administrator Password. This password is required to reboot the domain controller (after promotion) in Active Directory Restore Mode. The specified password must meet the password complexity requirements i.e. Minimum Length of 8 Chars, Atleast 1 uppercase alphabet, Atleast 1 lowercase alphabet, Atleast 1 numeric char, Atleast 1 special char.

.PARAMETER ForestFunctionalLevel
Specify the forest functional level for the new forest. The valid value for forest functional level is 'Windows2008Forest / Windows2008R2Forest / Windows2012Forest / Windows2012R2Forest / Windows2016Forest'. It should be noted that the forest functional level value varies based on the operating system of the server. This parameter is only applicable to NewDomainNewForest build scenario.

.PARAMETER DomainFunctionalLevel
Specify the domain functional level for the new domain. The valid value for domain functional level is 'Windows2008Domain / Windows2008R2Domain / Windows2012Domain / Windows2012R2Domain / Windows2016Domain'. However, the domain functional level value varies depending upon the specified / configured forest functional level of the forest. This parameter is only applicable to NewChildDomain and NewTreeDomain build scenarios.

.PARAMETER InstallDNS
Specify this parameter to install Domain Naming System (DNS) on the server. Microsoft recommends to install DNS on all the domain controllers for high availability in the distributed environment.

.PARAMETER GlobalCatalog
Specify this parameter to configure the domain controller as a global catalog server. Microsoft recommends to configure GC on all the domain controllers for high availability in the distributed environment.

.PARAMETER RODC
Specify this switch parameter to build a Read-Only Domain Controller. This parameter is only applicable for Additional DC build scenario.

.PARAMETER ReplicateFromDC
This parameter is only applicable to Additional DC build scenario. Specify an existing domain controller (FQDN) in the same domain to replicate the Active Directory data from. If this parameter is not specified then replication partner will be chosen automatically by the dcpromo process. Either 'ReplicateFromDC' or 'InstallFromMedia' parameter can be specified at a time.

.PARAMETER InstallFromMedia
This parameter is only applicable to Additional DC build scenario. Specify this parameter with the IFM media path for building the Additonal Domain Controller from a backup ISO. Either 'ReplicateFromDC' or 'InstallFromMedia' parameter can be specified at a time. If both the options are not specified then the script will take the selection of 'ReplicateFromDC' as Automatic (replicate the AD data from an auto-selected DC) and proceed with the DC build.

.PARAMETER CriticalReplicationOnly
This parameter is only applicable to Additional DC build scenario. Specify this parameter for replicating only critical replication data while building the Additional domain controller. 

.PARAMETER ADSiteName
Specify the name of the site where the new domain controller needs to be placed. This parameter is not applicable to NewDomainNewForest build scenario, where the DC will always be placed in the 'Default-First_Site_Name' site.

.PARAMETER SiteSubnetAssociate
Specify this parameter if you want to utilize the script capability to assosiate a user provided subnet with the site name mentioned in the 'ADSiteName' parameter. This parameter is not applicable to NewDomainNewForest build scenario.

.PARAMETER SiteSubnetAssociationUserName
In order to assosiate the subnet with site specify the User account having Enterprise Admin privileges. This parameter is not applicable (and will be skipped by the script) if 'SiteSubnetAssociate' parameter is not passed.

.PARAMETER SiteSubnetAssociationPassword
Specify the password for the above mentioned user account. This parameter is not applicable (and will be skipped by the script) if 'SiteSubnetAssociate' parameter is not passed.

.PARAMETER SiteSubnetAssociationDomain
Specify the domain FQDN of the above mentioned user account. This parameter is not applicable (and will be skipped by the script) if 'SiteSubnetAssociate' parameter is not passed.

.PARAMETER SubnetMaskToAssociate
Specify the subnet value. An example of a valid subnet for association with site is '192.168.10.0/24'. This parameter is not applicable (and will be skipped by the script) if 'SiteSubnetAssociate' parameter is not passed.

.PARAMETER IPConfig
Specify this parameter to utilize the script capability to implement the Network Adapter IP Addressing configurations; such as IP Address, Subnet Mask, DNS etc. 

.PARAMETER NetworkAdapterName
Specify the name of the Network Adapter over which the IP configurations need to be implemented. If the Network Adapter name has 'space' then specify the name in the qoutes ''. This parameter is not applicable (and will be skipped by the script) if 'IPConfig' parameter is not passed.

.PARAMETER IPAddress
Specify a valid IP address. This is a mandatory parameter. This parameter is not applicable (and will be skipped by the script) if 'IPConfig' parameter is not passed.

.PARAMETER SubnetMask
Specify a valid subnet mask. This is a mandatory parameter. This parameter is not applicable (and will be skipped by the script) if 'IPConfig' parameter is not passed.

.PARAMETER Gateway
Specify a valid gateway address. This parameter is not applicable (and will be skipped by the script) if 'IPConfig' parameter is not passed.

.PARAMETER DNSAddress
Specify a valid DNS address. This is a mandatory parameter. Multiple DNS addresses can be passed as comma separated value. This parameter is not applicable (and will be skipped by the script) if 'IPConfig' parameter is not passed.

.PARAMETER NetworkAdapterDNSSuffix
Specify a valid Network adapter DNS suffix. The valid value for the DNS Suffix is a fully qualified domain DNS name, for example 'MyDomain.com'. This parameter is not applicable (and will be skipped by the script) if 'IPConfig' parameter is not passed.

.PARAMETER LmhostsLookup
Specify this parameter to enable LMHost lookup. This parameter is not applicable (and will be skipped by the script) if 'IPConfig' parameter is not passed.

.PARAMETER ConfigADPathsToOSDrive
Specify this parameter to utilize the script capability to place all the Active Directory folders (AD Database, AD Logs and SYSVOL) to Windows installation drive; for example C:\

.PARAMETER UpgradeSchema
Specify this parameter to utilize the script capability to automatically upgrade the schema of the forest, if deemed necessary by the script. This parameter is only applicable to NewChildDomain and NewTreeDomain build scenario.

.PARAMETER ExpressInstall
Specify this parameter for express installation of the Active Directory services. In expressinstall mode the pre and post configuration tasks does not run and only the normal dcpromo runs to promote the DC without DXC and PDC mandated standardization. It should be noted that Express installation will result in minimal default Microsoft security, be subject to PDS best effort support and will not fully comply with the DXC baseline Domain Controller security standards. If you choose to proceed, ensure you have consulted with your Cybersecurity Account Security Manager (ASM).

.PARAMETER IgnoreDHCPWarning
Specify this parameter to continue installation even if the server has network interface with DHCP enabled.

.PARAMETER DSConfigurations
Specify the DSSOE Post promotion configuration parameters in the form of Hashtable. Create a new hashtable and specify the parameters with valid values which are needed to be configured post DC promotion. Refer to Examples section or DSSOE operations guide for more information on this parameter.
Creation of Hashtable:
$Post = @{"ConfigurePageFile" = "Value";"ClearEvents" = "Value";"ReserveFilePath" = "Value";"ReserveFileSize" = "Value";"DisableNetBIOSOverTCPIP" = "Value";"DisableSMB1" = "Value";"RestrictRPCPort" = "Value";"RPCPortRange" = "Value";"ExternalTimeServer" = "Value";"DCOULocation"="Value";"ConfigureDomainPolicy"="Value";"ConfigureDomainControllerPolicy" = "Value";"OU_AccountType" = "Value";"OU_AccountCode" = "Value";"OU_Delegation" = "Value";"ConfigureDSBackup" = "Value";"EnableBackupMaintenance" = "Value";"BackupVolumePath" = "Value";"CreateADUsers" = "Value";"DNSForwarders" = "Value";"ConfigDNSScavenging" = "Value";"ConfigureDSRM" = "Value";"InstallADHotfixes" = "Value";"ConfigureStaticPort" = "Value";"ADReplicationPort"= "Value";"NetLogonPort" = "Value";"DFSRReplicationPort" = "Value";"ConfigureIPAMAccess" = "Value";"IPAMUnivGroup" = "Value";"IPAMServer" = "Value";"EnableADRecycleBin" = "Value";"Username" = "value";"Password"="Value";"Domain" = "Value";"ADRecycleBinScope" = "Value";"ADRecycleBinTargetServer" = "Value";"ADRecycleBinTargetDomain" = "Value";"ExecuteADHealthCheck" = "Value"; "ADHCUsername" = "Value";"ADHCPwd" = "Value";""ADHCDomain" = "Value";"ADHCDomainsToScan" = "Value"}
ConfigurePageFile - Configures the page file on the server as per the standards before the DC promotion starts. Valid value is either True or False
ClearEvents - Clears the system, security & application events before the DC promotion starts. Valid value is either True or False.
ReserveFilePath - File path for the creation of reserve file. Reserve file can be created on the volume that stores NTDS.Dit database (or any other volume). In case of free disk space crisis, reserve file can be deleted to claim free space on the volume. Example 'D:\ReserveFile\Reserve.res'.
ReservefileSize - Size of the reserve file in Mega Bytes. The specified size should be an integer value, larger than 512 MB and not more than 20% of the free disk space available on the volume.
DisableNetBIOSOverTCPIP - Use this option to disable NetBIOS Over TCP/IP on all the NIC cards on the server. This is a pre-build option. The valid values for this parameter is either True or False.
DisableSMB1 - Use this option to disable SMB 1.0 on the server. This is a pre-build option and is a recommended configuration.The valid values are True / False. The default value for this parameter is True. You can set it to False to let SMB 1.0 be enabled on the server, if in case the support for legacy environments is needed.
RestrictRPCPort - This pre-build option can be used to configure RPC dynamic port range restrictions. This is a Cybersecurity recommendation and the restriction port range is recommended as 49152-49407. You can specify another port range if your requirement differs from Cybersecurity recommendations or you can choose not to exercise this configuration at all. The valid values for 'Configure' attribute is True / False.
RPCPortRange - The example of a valid value for PortRange attribute is '49152-49407' or '49152-50000'.
ExternalTimeServer - Configures the external time sync server. Specify valid IP address or name of the external time sync server. Only one time sync server is allowed to be configured in this version of DSSOE.
DCOULocation - Moves the Domain Controller AD object to user specified OU. Specify the valid Distinguished Name (DN) of the OU to which the DC object needs to be moved. The valid value is either 'Default' or a valid DN of an OU. This parameter is only applicable to Additional DC Build, but NOT applicable when building an RODC. For example, "OU=DCs,DC=Mydomain,DC=com".
ConfigureDomainPolicy - Configures the DXC standard baseline domain security group policy. Valid value is either True or False. This parameter is not applicable to Additional DC build.
ConfigureDomainControllerPolicy - Configues the DXC standard baseline domain controller security group policy. Valid value is either True or False. This parameter is not applicable to Additional DC build.
OU_AccountType - Specify the type of OU structure to implement. Valid value is either Standard or Multitenant. This parameter is not applicable to Additional DC build. If not specified the OU creation will be skipped.
OU_AccountCode - Specify the 3 character DXC Account code for creation of the OU structure. Refer to DXC device and naming standard document for the list of account codes or write to Platform_Wintel_SOE@csc.com
OU_Delegation - The valid value is True / False. This parameter is only applicable when Multitenant AccountType is selected. This option does not apply for Standard or default OU structures.## SHOULD NOT be applied to Additional domain controllers
ConfigureDSBackup - Configures a scheduled task to trigger the system state backup at a specific time, daily. Valid value is either True or False.
EnableBackupMaintenance - Configures a scheduled task to maintain the number of backups to keep on the volume. Only latest three backups are kept, rest deleted. Valid value is either True or False.
BackupVolumePath - Specify the volume to store the backups. For example F:
CreateADUsers - Creates the Active Directory user accounts in bulk. The script reads the details from the csv file (resides in DSSOE Package) and creates the users automatically. The csv file should be properly pre-filled and a valid path to the csv file must be specified. This parameter is not applicable to RODC build scenario.
DNSForwarders - Configures the DNS forwarders on the domain controller. Multiple forwarder IPs can be specified as comma separated value. Specify a valid IP address(es).
ConfigDNSScavenging - You can use this option to configure standard DNS Scavenging on the Domain Controller. DNS role must be installed on the server in order to use this parameter. The valid value is True / False.#### This option is not applicable for 'Addtional DC' build scenario.
ConfigureDSRM - You can use this option to add Directory Services Restore Mode selection in the boot menu.Valid value is True / False.
InstallADHotfixes - You can use this option to install AD DS hotfixes on the server. The value value is True / False.
ConfigureStaticPort - Configures the static port AD & Sysvol replication. Valid value is either True or False.
ADReplicationPort - Specify the port number for NTDS (Active Directory replication). Valid value is a port number of the range 1 - 65535.
NetLogonPort - Specify the port number for Netlogon (AD Replication). Valid value is a port number of the range 1 - 65535.
DFSRReplicationPort - Specify the port number for SYSVOL replication using DFSR. Valid value is a port number of the range 1 - 65535.
ConfigureIPAMAccess - This option is only applicable in the case of AdditionalDC, NewChildDomain, & NewTreeDomain. If you wish to configure security configuration to enable IPAM server to access this DNS server, set the attribute to 'True'.
IPAMUnivGroup - Speciy Universal group name where IPAM server is a member of. Group should be in format DomainDNSName\groupname , for example Myforest.local\MyGroup
IPAMServer - Speciy the FQDN of the IPAM server name, for example IPAMServer.Myforest.local
EnableADRecycleBin - Enable the Active Directory Recycle Bin. Value value is either True or False.
Username - Specify the credentials with the Enterprise Admins rights in order to enable the AD Recycle Bin.
Password - Specify the value password for the above specified Username. The password should be first encrypted, using the procedured described in Examples section, and then passed.
Domain - Specify the Domain DNS name where the above mentioned Username resides.
ADRecycleBinScope - Specify the Scope of operation for AD Recycle Bin. The value values for Scope is either 'ForestOrConfigurationSet' or 'Domain'
ADRecycleBinTargetServer - Specify the Fully Qualified Domain Name (FQDN) of the Target Server onto which the AD Recycle Bin will be enabled. The target server should be a Domain Naming Master role holder.
ADRecycleBinTargetDomain - Specify the valid Target Domain DNS name for AD Recycle Bin operation. If 'ForestOrConfigurationSet' is chosen as the Scope then specify the Root Domain DNS name as the Target Domain.
ExecuteADHealthCheck - If you wish to run Active Directory health check script against the domains specified in 'ADHCDomainsToScan' attribute, set the attribute to True
ADHCUsername - Specify the credentials with the Enterprise Admins rights in order to enable the AD Recycle Bin.
ADHCPwd - Specify the value password for the above specified Username. The password should be first encrypted, using the procedured described in Examples section, and then passed.
ADHCDomain - Specify the Domain DNS name where the above mentioned Username resides.
ADHCDomainsToScan - Specify the FQDN of the domains you wish to run the AD health check against.Multiple domains can be specified as comma seperated values. Specify 'All' if you wish to scan all the domains.

.PARAMETER ExportUnattendBuildFileTo
Specify this parameter to utilize the script capability to export the Unattended XML file which is auto-generated by the script as per the values passed in the build parameters. This exported XML file then can be reused to build more domain controllers by utilizing the 'Answerfile' parameter. An example of a valid value for this parameter is 'C:\DSSOEXMLExport'.


.EXAMPLE
How to encrypt passwords for DSSOE usage
To encrypt password that you need to specify in unattended XML file for DSSOE build (or when launching it with command-line parameterized build), follow steps below to encrypt the password. Note that C:\DSSOE300\ in this example is assumed as a location where DSSOE 3.0.0 package is extracted. If you have a different folder then adjust the path accordingly. 

Use the C:\DSSOE300\Modules\SecurePwd.ps1 script to encrypt Admin Password, Safe Mode Admin Password Or Site to Subnet Association Admin Password.
SecurePwd.ps1 script takes an array of passwords, auto generates an encryption pass key, encrypt each of the specified password and provide an output array with encrypted passwords and pass key.
$SecPwds = ./SecurePwd.ps1 -encrypt -string "AdminPassword","SafeModeAdminPassword","SiteSubnetAssociationPassword" 
If you do not wish to configure site to subnet association then do not pass the "SiteSubnetAssociationPassword" in the above command.

One should save the values from the output array to individual variables in order to pass them in command-line parameters.
$AdmPwd = $SecPwds.Password[0]
$SMAdmPwd = $SecPwds.Password[1]
$SSAPwd = $SecPwds.Password[2]
$Passkey = $SecPwds.Key

If order to decrypt the password you will have to specify the encrypted password and the pass key
$UnsecPwd = ./SecurePwd.ps1 -decrypt -string $AdmPwd -key $Passkey
$UnsecPwd = ./SecurePwd.ps1 -decrypt -string $SMAdmPwd -key $Passkey
$UnsecPwd = ./SecurePwd.ps1 -decrypt -string $SSAPwd -key $Passkey

.EXAMPLE
Perform DSSOE standard installation (create a new forest) using unattended answer file:
./setup.ps1 -AnswerFile c:\DSSOE300\config\example-newForest.xml -PassKey $SecPwds.key 

.EXAMPLE 
Perform DSSOE express installation (create a new forest) using unattended answer file:
./setup.ps1 -AnswerFile c:\DSSOE300\config\example-newForest.xml -PassKey $Passkey -ExpressInstall

.EXAMPLE 
Perform DSSOE express installation (create a new forest) using unattended answer file and force creation of AD log/database/sysvol folders on system drive (for example, C:\):
./setup.ps1 -AnswerFile c:\DSSOE300\config\example-newForest.xml -PassKey $SecPwds.Key -ConfigADPathsToOSDrive -ExpressInstall

.EXAMPLE
Perform DSSOE standard installation (add a new tree domain) using unattended answer file and let setup upgrade ACtive Directory schema if it is required to perform requested domain promotion type:
./setup.ps1 -AnswerFile c:\DSSOE300\config\example-newTree.xml -PassKey $Passkey -ConfigADPathsToOSDrive -UpgradeSchema -ExpressInstall

.EXAMPLE
Perform DSSOE standard installation (create new forest) using command line unattended installation.
.\setup.ps1 -NewDomainNewForest -UserName soe-load -Password $SecPwds.Password[0] -PassKey $SecPwds.Key -NewDomainName myforest.com -NewDomainNetBIOSName myforest -ADDatabasePath E:\NTDS-DB -ADLogfilePath D:\NTDS-LOGS -ADSysvolPath E:\SYSVOL -SafeModeAdminPass $SecPwds.Password[1] -ForestFunctionalLevel Windows2016Forest -DomainFunctionalLevel Windows2016Domain -InstallDNS -IPConfig -NetworkAdapterName Ethernet -IPAddress 192.168.10.1 -SubnetMask 255.255.255.0 -Gateway 192.168.10.2 -DNSAddress '192.168.10.3,192.168.10.4 -LmhostsLookup -DSConfigurations $post -ExportUnattendBuildFileTo 'C:\DSSOEExport'

.EXAMPLE
Perform DSSOE express installation (create new forest) using command line unattended procedure.
.\setup.ps1 -NewDomainNewForest -UserName soe-load -Password $AdmPwd -PassKey $Passkey -NewDomainName myforest.com -NewDomainNetBIOSName myforest -ADDatabasePath E:\NTDS-DB -ADLogfilePath D:\NTDS-LOGS -ADSysvolPath E:\SYSVOL -SafeModeAdminPass $SMAdmPwd -ForestFunctionalLevel Windows2016Forest -DomainFunctionalLevel Windows2016Domain -InstallDNS -IPConfig -NetworkAdapterName Ethernet -IPAddress 192.168.10.1 -SubnetMask 255.255.255.0 -Gateway 192.168.10.2 -DNSAddress '192.168.10.3,192.168.10.4' -LmhostsLookup -ExpressInstall -ExportUnattendBuildFileTo 'C:\DSSOEExport'

.EXAMPLE
Perform DSSOE standard installation (create new child domain) using command line parameters.
.\setup.ps1 -NewChildDomain -UserName soe-load -Domain myforest.com -Password $SecPwds.Password[0] -PassKey $SecPwds.Key -ParentDomainName myforest.com -ChildDomainName mychild -ChildDomainNetBIOSName mychild -ADDatabasePath E:\NTDS-DB -ADLogfilePath D:\NTDS-LOGS -ADSysvolPath E:\SYSVOL -SafeModeAdminPass $SecPwds.Password[1] -DomainFunctionalLevel Windows2016Domain -InstallDNS -GlobalCatalog -ADSiteName default-first-site-name -SiteSubnetAssociate -SiteSubnetAssociationUserName soe-load -SiteSubnetAssociationPassword $SecPwds.Password[2] -SiteSubnetAssociationDomain myforest.com -SubnetMaskToAssociate 192.168.10.0/24 -IPConfig -NetworkAdapterName Ethernet -IPAddress 192.168.10.10 -SubnetMask 255.255.255.0 -Gateway 192.168.10.1 -DNSAddress 192.168.10.5,192.168.10.6 -NetworkAdapterDNSSuffix -LmhostsLookup -UpgradeSchema -DSConfigurations $post -ExportUnattendBuildFileTo 'C:\DSSOEExport'

.EXAMPLE
Perform DSSOE standard installation (create new additional DC) using command line parameters.
.\setup.ps1 -AdditionalDC -UserName soe-load -Domain mydomain.com -Password $AdmPwd -PassKey $Passkey -SafeModeAdminPass $SMAdmPwd -InstallDNS -GlobalCatalog -ReplicateFromDC DC1.mydomain.com -ADSiteName default-first-site-name -ConfigADPathsToOSDrive -DSConfigurations $post -ExportUnattendBuildFileTo 'C:\DSSOE'

.EXAMPLE
Perform DSSOE standard installation (create new RODC) using command line parameters.
.\setup.ps1 -AdditionalDC -UserName soe-load -Domain mydomain.com -Password $AdmPwd -PassKey $Passkey -ADDatabasePath E:\NTDS-DB -ADLogfilePath D:\NTDS-LOGS -ADSysvolPath E:\SYSVOL -SafeModeAdminPass $SMAdmPwd -InstallDNS -GlobalCatalog -RODC -ADSiteName ADSite -SiteSubnetAssociate -SiteSubnetAssociation UserName dssoe-load -SiteSubnetAssociationPassword $SSAPwd -SiteSubnetAssociationDomain mydomain.com -SubnetMaskToAssociate 192.168.10.0/24 -IPConfig -NetworkAdapterName 'Local Area Connection' -IPAddress 192.168.10.10 -SubnetMask 255.255.255.0 -Gateway 192.168.10.1 -DNSAddress '192.168.10.11,192.168.10.12' -LmhostsLookup -DSConfigurations $post -ExportUnattendBuildFileTo 'C:\DSSOEXMLExport'

.EXAMPLE
Perform DSSOE standard installation (create a new forest) using unattended answer file with DHCP enabled Network interface:
./setup.ps1 -AnswerFile c:\DSSOE300\config\example-newForest.xml -PassKey $pkey -IgnoreDHCPWarning

.EXAMPLE 
Perform DSSOE express installation (create a new forest) using unattended answer file with DHCP enabled Network interface:
./setup.ps1 -AnswerFile c:\DSSOE300\config\example-newForest.xml -PassKey $pkey -ExpressInstall -IgnoreDHCPWarning 

.NOTES
Exit Codes (Refer to log files under C:\SUPPORT\LOGS\DSSOE) for detailed information about exit codes)
	ds_no_admin_privileges
    DSSOE setup was launched without admin privileges. 
    
    ds_server_is_already_dc
    you are running DSSOE setup on a server that is already a Domain Controller. 

    ds_not_soe
    You are running DSSOE setup on a server that is not built using a supported version of Windows Server SOE.

    ds_no_passkey
    PassKey parameter was not specified. 

    ds_unsupported_os
    You are running DSSOE setup on a server that does not have supported operating system installed.

    ds_xmltemplate_not_exists
    DSSOE unattended installation template file (under CONFIG folder of the package) could not be found.

    ds_invalid_answerfiletemplate_ext
    DSSOE unattended installation template file (under CONFIG folder of the package) does not have valid file extension. It must be .XML
    
    ds_missing_config_param
    DSConfigurations parameter was specified but it is empty

    ds_invalid_config_param
    An invalid item was specified with DSConfigurations parameter 

    ds_answerfile_not_exists
    Specified DSSOE unattended setup answer file does not exist.

    ds_invalid_answerfile_ext
    Specified DSSOE unattended setup answer file does not have a valid extension (must have .XML).

    ds_answerfile_load_error
    Unable to open unattended setup answer file likely due to incorrect XML format/node.

    ds_xml_validation_error
    Unattended answer file has invalid or missing parameter value. See log file for details.

    ds_sysdrv_disk_validation_error
    Disk validation error occured (when selected ConfigADPathsToOSDrive parameter).

    ds_disk_validation_error
    Disk validaiton error occured.

    ds_dhcp_conf_found
    Found the DHCP enabled on the Network Adapter of the server (should have static IP configured instead)
     
    ds_static_ipconfig_failed
    Failed to configure given static IP on given network interface.

    ds_dns_ip_conf_error
    Failed to configure given DNS server IP.

    ds_gw_ip_conf_error
    Failed to configure given gateway IP address.
    
    ds_unsupported_schema_version
    The schema version of the forest is not supported on the baseline OS of the server.

    ds_schema_upgrade_failed
    Failed to upgrade Active Directory Schema.

    ds_not_schema_admins
    Schema Upgrade parameter specified but user is not a member of Schema Admins.
    
    ds_domain_promotion_failed
    Failed to promote the server as a Domain Controller. 

    ds_domain_not_found
    Failed to find the domain.

    ds_tcpip_conf_error
    None of the Network Interfaces are enabled for IP configuration.

.LINK
https://pws.can-kan.csc.com/

#>

[CmdletBinding()]
Param(
    # parameters related to new forest creation
    #[Parameter(ParameterSetName="xmlInput")] [switch] $XMLInput,
    [Parameter(ParameterSetName="xmlInput")] [string] $AnswerFile, # DSSOE answer file
    [Parameter(ParameterSetName="NewDomainNewForest")] [switch] $NewDomainNewForest,
    [Parameter(ParameterSetName="AdditionalDC")] [switch] $AdditionalDC,
    [Parameter(ParameterSetName="NewChildDomain")] [switch] $NewChildDomain,
    [Parameter(ParameterSetName="NewTreeDomain")] [switch] $NewTreeDomain,
    [Parameter(ParameterSetName="NewDomainNewForest")] [Parameter(ParameterSetName="AdditionalDC")] [Parameter(ParameterSetName="NewChildDomain")] 
    [Parameter(ParameterSetName="NewTreeDomain")] [string] $UserName,
    [Parameter(ParameterSetName="AdditionalDC")] [Parameter(ParameterSetName="NewChildDomain")] 
    [Parameter(ParameterSetName="NewTreeDomain")] [string] $Domain, 
    [Parameter(ParameterSetName="NewDomainNewForest")] [Parameter(ParameterSetName="AdditionalDC")] [Parameter(ParameterSetName="NewChildDomain")] 
    [Parameter(ParameterSetName="NewTreeDomain")] [string] $Password,
    [Parameter(ParameterSetName="NewDomainNewForest")] [Parameter(ParameterSetName="AdditionalDC")] [Parameter(ParameterSetName="NewChildDomain")] 
    [Parameter(ParameterSetName="NewTreeDomain")] [Parameter(ParameterSetName="xmlInput")][string] $PassKey, # added by umesh for encrypted password
    [Parameter(ParameterSetName="NewDomainNewForest")] [string] $NewDomainName,
    [Parameter(ParameterSetName="NewDomainNewForest")] [string] $NewDomainNetBIOSName,
    [Parameter(ParameterSetName="NewChildDomain")] [string] $ParentDomainName,
    [Parameter(ParameterSetName="NewChildDomain")] [string] $ChildDomainName,
    [Parameter(ParameterSetName="NewChildDomain")] [string] $ChildDomainNetBIOSName,
    [Parameter(ParameterSetName="NewTreeDomain")] [string] $ForestRootDomain,
    [Parameter(ParameterSetName="NewTreeDomain")] [string] $TreeDomainName,
    [Parameter(ParameterSetName="NewTreeDomain")] [string] $TreeDomainNetBIOSName,
    [Parameter(ParameterSetName="NewDomainNewForest")] [Parameter(ParameterSetName="AdditionalDC")] [Parameter(ParameterSetName="NewChildDomain")] 
    [Parameter(ParameterSetName="NewTreeDomain")] [string] $ADDatabasePath = 'E:\NTDS-DB',
    [Parameter(ParameterSetName="NewDomainNewForest")] [Parameter(ParameterSetName="AdditionalDC")] [Parameter(ParameterSetName="NewChildDomain")] 
    [Parameter(ParameterSetName="NewTreeDomain")] [string] $ADLogfilePath = 'D:\NTDS-LOGS',
    [Parameter(ParameterSetName="NewDomainNewForest")] [Parameter(ParameterSetName="AdditionalDC")] [Parameter(ParameterSetName="NewChildDomain")] 
    [Parameter(ParameterSetName="NewTreeDomain")] [string] $ADSysvolPath='E:\SYSVOL',
    [Parameter(ParameterSetName="NewDomainNewForest")] [Parameter(ParameterSetName="AdditionalDC")] [Parameter(ParameterSetName="NewChildDomain")] 
    [Parameter(ParameterSetName="NewTreeDomain")] [string] $SafeModeAdminPass,
    [Parameter(ParameterSetName="NewDomainNewForest")] [string] $ForestFunctionalLevel,
    [Parameter(ParameterSetName="NewDomainNewForest")] [Parameter(ParameterSetName="NewChildDomain")] 
    [Parameter(ParameterSetName="NewTreeDomain")] [string] $DomainFunctionalLevel,
    [Parameter(ParameterSetName="NewDomainNewForest")] [Parameter(ParameterSetName="AdditionalDC")] [Parameter(ParameterSetName="NewChildDomain")] 
    [Parameter(ParameterSetName="NewTreeDomain")] [switch] $InstallDNS,
    [Parameter(ParameterSetName="AdditionalDC")] [Parameter(ParameterSetName="NewChildDomain")] 
    [Parameter(ParameterSetName="NewTreeDomain")] [switch] $GlobalCatalog,
    [Parameter(ParameterSetName="AdditionalDC")] [switch] $RODC,
    [Parameter(ParameterSetName="AdditionalDC")] [string] $ReplicateFromDC = 'Automatic',
    [Parameter(ParameterSetName="AdditionalDC")] [string] $InstallFromMedia,
    [Parameter(ParameterSetName="AdditionalDC")] [switch] $CriticalReplicationOnly,
    #[Parameter(ParameterSetName="NewDomainNewForest")] [Parameter(ParameterSetName="AdditionalDC")] [Parameter(ParameterSetName="NewChildDomain")] 
    #[Parameter(ParameterSetName="NewTreeDomain")] [switch] $RebootOnCompletion, 14-Jun-16 [TR] Removed the reboot on completion option
    [Parameter(ParameterSetName="AdditionalDC")] [Parameter(ParameterSetName="NewChildDomain")] 
    [Parameter(ParameterSetName="NewTreeDomain")] [string] $ADSiteName = 'Default',
    [Parameter(ParameterSetName="AdditionalDC")] [Parameter(ParameterSetName="NewChildDomain")] 
    [Parameter(ParameterSetName="NewTreeDomain")] [switch] $SiteSubnetAssociate,
    [Parameter(ParameterSetName="AdditionalDC")] [Parameter(ParameterSetName="NewChildDomain")] 
    [Parameter(ParameterSetName="NewTreeDomain")] [string] $SiteSubnetAssociationUserName,
    [Parameter(ParameterSetName="AdditionalDC")] [Parameter(ParameterSetName="NewChildDomain")] 
    [Parameter(ParameterSetName="NewTreeDomain")] [string] $SiteSubnetAssociationPassword,
    [Parameter(ParameterSetName="AdditionalDC")] [Parameter(ParameterSetName="NewChildDomain")] 
    [Parameter(ParameterSetName="NewTreeDomain")] [string] $SiteSubnetAssociationDomain,
    [Parameter(ParameterSetName="AdditionalDC")] [Parameter(ParameterSetName="NewChildDomain")] 
    [Parameter(ParameterSetName="NewTreeDomain")] [string] $SubnetMaskToAssociate,
    [Parameter(ParameterSetName="NewDomainNewForest")] [Parameter(ParameterSetName="AdditionalDC")] [Parameter(ParameterSetName="NewChildDomain")] 
    [Parameter(ParameterSetName="NewTreeDomain")] [switch] $IPConfig,
    [Parameter(ParameterSetName="NewDomainNewForest")] [Parameter(ParameterSetName="AdditionalDC")] [Parameter(ParameterSetName="NewChildDomain")] 
    [Parameter(ParameterSetName="NewTreeDomain")] [string] $NetworkAdapterName,
    [Parameter(ParameterSetName="NewDomainNewForest")] [Parameter(ParameterSetName="AdditionalDC")] [Parameter(ParameterSetName="NewChildDomain")] 
    [Parameter(ParameterSetName="NewTreeDomain")] [string] $IPAddress,
    [Parameter(ParameterSetName="NewDomainNewForest")] [Parameter(ParameterSetName="AdditionalDC")] [Parameter(ParameterSetName="NewChildDomain")] 
    [Parameter(ParameterSetName="NewTreeDomain")] [string] $SubnetMask,
    [Parameter(ParameterSetName="NewDomainNewForest")] [Parameter(ParameterSetName="AdditionalDC")] [Parameter(ParameterSetName="NewChildDomain")] 
    [Parameter(ParameterSetName="NewTreeDomain")] [string] $Gateway,
    [Parameter(ParameterSetName="NewDomainNewForest")] [Parameter(ParameterSetName="AdditionalDC")] [Parameter(ParameterSetName="NewChildDomain")] 
    [Parameter(ParameterSetName="NewTreeDomain")] [string] $DNSAddress,
    #[Parameter(ParameterSetName="NewDomainNewForest")] [Parameter(ParameterSetName="AdditionalDC")] [Parameter(ParameterSetName="NewChildDomain")] 
    #[Parameter(ParameterSetName="NewTreeDomain")] [string] $WINSAddress, -- Removed it since netbios config is disabled - Arun 8th june 2016
    [Parameter(ParameterSetName="NewDomainNewForest")] [Parameter(ParameterSetName="AdditionalDC")] [Parameter(ParameterSetName="NewChildDomain")] 
    [Parameter(ParameterSetName="NewTreeDomain")] [string] $NetworkAdapterDNSSuffix,
    [Parameter(ParameterSetName="NewDomainNewForest")] [Parameter(ParameterSetName="AdditionalDC")] [Parameter(ParameterSetName="NewChildDomain")] 
    [Parameter(ParameterSetName="NewTreeDomain")] [switch] $LmhostsLookup,
    
    # common parameters
    [switch] $ConfigADPathsToOSDrive, #controls the drive creation
    [switch] $UpgradeSchema, #controls the schema update
    [switch] $ExpressInstall, # run DSSOE in express mode.. skip post-install.
    [switch] $IgnoreDHCPWarning, #script continues even if DHCP enabled
    # end common parameters
    
    [Parameter(ParameterSetName="NewDomainNewForest")] [Parameter(ParameterSetName="AdditionalDC")] [Parameter(ParameterSetName="NewChildDomain")] 
    [Parameter(ParameterSetName="NewTreeDomain")] [hashtable] $DSConfigurations,   
    
    # parameter to export auto-generated XML to specified location.. in case of parameterized installation
    [Parameter(ParameterSetName="NewDomainNewForest")] [Parameter(ParameterSetName="AdditionalDC")] [Parameter(ParameterSetName="NewChildDomain")] 
    [Parameter(ParameterSetName="NewTreeDomain")] [string] $ExportUnattendBuildFileTo
)


#region Validate And Load DSSOE Modules
#validate and load required DSSOE modules (using $psscriptpath)
$modsValid = $true
foreach( $module in ('dsUtils.psm1','dsLogger.psm1','LogCallerPref.psm1','DSImplement.psm1','DSValidate.psm1','ADFromWorkgroup.psm1','AD_Healthcheck.psm1')) {
    $cModulePath = "$PSScriptRoot\modules\$module"
    if(-not (Test-Path -Path $cModulePath)) {
        Write-Error "[dssoe] unable to find and load $cModulePath. Verify that this module exists and try again."
        return 'dssoe_modules_load_error'
        break
    }
}

#importing all the DSSOE modules
Import-Module "$PSScriptRoot\Modules\LogCallerPref.psm1" -Force
Import-Module "$PSScriptRoot\Modules\DSLogger.psm1" -Force
Import-Module "$PSScriptRoot\Modules\DSUtils.psm1" -Force
Import-Module "$PSScriptRoot\Modules\DSValidate.psm1" -Force
Import-Module "$PSScriptRoot\Modules\DSImplement.psm1" -Force
Import-Module "$PSScriptRoot\Modules\ADFromWorkgroup.psm1" -Force
Import-Module "$PSScriptRoot\Modules\AD_Healthcheck.psm1" -Force

# call verbose writing functions
Set-CallerVerbosePreference
Set-CallerDebugPreference
#endregion Validate And Load DSSOE Modules

#region change verbose message background
((Get-Host).PrivateData).VerboseBackgroundColor =($host.UI.RawUI).BackGroundColor;
#endregion

#region Set log path to static location C:\Support\Logs\DSSOE
$LogPath = "C:\Support\Logs\DSSOE"
#endregion

#region create the logpath folder, set log file path & start the logging
#checking if logfile folder C:\Support\Logs\DSSOE exists; create if it does not
If(-not (Test-Path $LogPath)) {
    New-Item -ItemType Directory -Path $LogPath -Force | Out-Null
}

[string] $DSLogFile = "$($LogPath)\dssoe-$((Get-Date).ToString('MMddyyyy-hhmmss')).log"
#calling functions from the dslogger.psm1 module
Set-DSLogFile -LogPath $DSLogFile
# script name as log header
Write-DSLog -Level info -Message "[$($PSCommandPath.Split('\')[-1])]" 
Write-DSLog -Level info -Message "DSSOE script logging started" 
#endregion create the logpath folder, set log file path & start the logging

#region Test If User Is Admin or not
# checking if script is running with administrative privileges; calling function from dsutils.psm1
If((Test-IsCurrentUserAdmin) -eq $false) {
    Write-DSLog -level error -message "[dssoe] This script must be run using administrative privileges"
    return 'ds_no_admin_privileges'
    Exit
}
#endregion Test If User Is Admin or not

# region verify this server is not a domain controller! 
if((Test-ServerIsDC) -eq $true) {
    Write-DSLog -level error -message "[dssoe] Server $($env:COMPUTERNAME) is already a domain controller. DSSOE setup cannot continue."
    return 'ds_server_is_already_dc'
    exit
}
#endregion


#region Verify that this server is built using a valid supported SOE
# checking if running on a server built using Windows Server SOE
If((Test-WindowsSOEVersion) -ne $true) {
    Write-DSLog -Level error -Message "[dssoe] The Operating System on this sever was detected to not have been provisioned using a supported DXC SOE. DSSOE does not support non-SOE provisioned servers. Please ensure the server has been prepared using the latest supportable Windows Server SOE and POST-SOE production patching has been applied prior to running the DSSOE. Running the DSSOE without the core baseline OS configuration provided by the Windows Server SOE will result in a non-standard Domain Controller subject to a diminished security posture and Best Effort Support. If you need to proceed with this, obtain approval from your Cybersecurity Account Security Manager and contact Platform_Wintel_SOE@csc.com for more information."
    return 'ds_not_soe'
    Exit
}
Else {
    Write-DSLog -Level info -Message "[dssoe] Windows SOE Version is successfully validated"
}
#endregion Verify that this server is built using a valid supported SOE


#region check account params are given
if(-not ($PassKey)) {
    Write-DSLog -Level error -Message "[dssoe] You must specify PassKey to perform DSSOE build"
    return 'ds_no_passkey'
    exit
}
#endregion


#region Validating if the baseline operating system is supported by DSSOE 3.0.0 or not
#The DSSOE 3.0.0 supports Windows Server 2016 operating system
#Using get-osversion function from DSUtils.psm1 module to retrieve the version of the operating system
If(-not((Get-OSVersion) -in ("6.1","6.2","6.3","10.0"))) {
    Write-DSLog -Level error -Message "[dssoe] The baseline operating system is not supported by this version of DSSOE. DSSOE program is terminating. For more information contact platform_wintel_soe@csc.com."
    return 'ds_unsupported_os'
    Exit
}
#endregion Validating if the baseline operating system is supported by DSSOE 3.0.0 or not


#Start region if xmlinput not selected
if($PSCmdlet.ParameterSetName -ne "XMLInput"){
Write-DSLog -Level info -Message "[dssoe] parameter based installation type selected by user"
Write-DSLog -Level info -Message "[dssoe] generating DSSOE unattended installation answer file" -verbose
# for auto-gen of DSSOE XML file based on given params, use a blank template 
$tempxmlpath = "$PSScriptRoot\Config\dsParamsTemplate.xml" #Read xml template to create a temp answerfile

    If(-not(Test-Path -Path $tempxmlpath)) {
        Write-DSLog -Level error -Message "[dssoe] xml template file not found"
        return 'ds_xmltemplate_not_exists'
        Exit
    }

    $aft = Get-Item -Path $tempxmlpath
    if($aft.Extension -ne '.xml') {
        Write-DSLog -Level error -Message "[dssoe] invalid xml template found (.xml)"
        return 'ds_invalid_answerfiletemplate_ext'
        exit
    }

    [xml] $xml = Get-Content $tempxmlpath #Read xml template to create a temp answerfile

    #Based on install type update xml file with common params. Added domain to the list too
    $xml.DSSOE.DCPromoOptions.Selected = $PSCmdlet.ParameterSetName
    $cparams = @{"UserName" = $UserName;"Password" = $Password;"Domain"=$Domain;"ADDatabasePath" = $ADDatabasePath;"ADLogfilePath"=$ADLogfilePath;"SysvolPath"=$ADSysvolPath;
    "SafeModeAdminPassword"=$SafeModeAdminPass;"InstallDNS"=$InstallDNS;"ADSiteName"=$ADSiteName} # 14-Jun-16 [TR] removed "RebootOnCompletion"=$RebootOnCompletion
    $ChildNodes = $xml.DSSOE.DCPromoOptions.$($PSCmdlet.ParameterSetName).ChildNodes
    foreach($c in $ChildNodes){
        $array = $cparams.GetEnumerator()
        foreach($a in $array){
            if($a.Name -eq $c.Name){
            $xml.DSSOE.DCPromoOptions.$($PSCmdlet.ParameterSetName).$($c.Name) = $a.Value.ToString()}
        }
    }
    Write-DSLog -Level info -Message "[dssoe] updated common parameters in the xml file under node $($PSCmdlet.ParameterSetName)"

    #Update Domain functional level and global catalog
    if(($PSCmdlet.ParameterSetName -eq "NewDomainNewForest") -or ($PSCmdlet.ParameterSetName -eq "NewChildDomain") -or ($PSCmdlet.ParameterSetName -eq "NewTreeDomain")){
        $xml.DSSOE.DCPromoOptions.$($PSCmdlet.ParameterSetName).DomainFunctionalLevel = $DomainFunctionalLevel
    }
    if(($PSCmdlet.ParameterSetName -eq "AdditionalDC") -or ($PSCmdlet.ParameterSetName -eq "NewChildDomain") -or ($PSCmdlet.ParameterSetName -eq "NewTreeDomain")){
        $xml.DSSOE.DCPromoOptions.$($PSCmdlet.ParameterSetName).GlobalCatalog = $GlobalCatalog.ToString()
    }

    #Update xml file unique parameters based on install type
    switch($PSCmdlet.ParameterSetName) {
    "NewDomainNewForest" {
        $xml.DSSOE.DCPromoOptions.$($PSCmdlet.ParameterSetName).NewDomainFQDN = $NewDomainName
        $xml.DSSOE.DCPromoOptions.$($PSCmdlet.ParameterSetName).NewDomainNetBIOS = $NewDomainNetBIOSName
        $xml.DSSOE.DCPromoOptions.$($PSCmdlet.ParameterSetName).ForestFunctionalLevel = $ForestFunctionalLevel
    }

    "AdditionalDC" {
        $xml.DSSOE.DCPromoOptions.$($PSCmdlet.ParameterSetName).Domain = $Domain
        $xml.DSSOE.DCPromoOptions.$($PSCmdlet.ParameterSetName).RODC = $RODC.ToString()
        $xml.DSSOE.DCPromoOptions.$($PSCmdlet.ParameterSetName).CriticalReplicationOnly = $CriticalReplicationOnly.ToString()
        if($InstallFromMedia.Length -eq 0){
            $xml.DSSOE.DCPromoOptions.$($PSCmdlet.ParameterSetName).ReplicateDatafromExistingDC.Enabled = "True"
            $xml.DSSOE.DCPromoOptions.$($PSCmdlet.ParameterSetName).ReplicateDatafromExistingDC.ReplicaDC = $ReplicateFromDC
        }
        else {
            $xml.DSSOE.DCPromoOptions.$($PSCmdlet.ParameterSetName).ReplicateDatafromExistingDC.Enabled = "False"
            $xml.DSSOE.DCPromoOptions.$($PSCmdlet.ParameterSetName).InstallFromMedia.ReplicateDatafromMedia = "True"
            $xml.DSSOE.DCPromoOptions.$($PSCmdlet.ParameterSetName).InstallFromMedia.MediaPath = $InstallFromMedia
        }
    }

    "NewChildDomain"{
        $xml.DSSOE.DCPromoOptions.$($PSCmdlet.ParameterSetName).ParentDomain = $ParentDomainName
        $xml.DSSOE.DCPromoOptions.$($PSCmdlet.ParameterSetName).ChildDomainName = $ChildDomainName
        $xml.DSSOE.DCPromoOptions.$($PSCmdlet.ParameterSetName).ChildDomainNameNetBIOS = $ChildDomainNetBIOSName
    }

    "NewTreeDomain"{
        $xml.DSSOE.DCPromoOptions.$($PSCmdlet.ParameterSetName).ForestRootDomain = $ForestRootDomain
        $xml.DSSOE.DCPromoOptions.$($PSCmdlet.ParameterSetName).TreeDomainName = $TreeDomainName
        $xml.DSSOE.DCPromoOptions.$($PSCmdlet.ParameterSetName).TreeDomainNameNetbios = $TreeDomainNetBIOSName
    }
    }

    Write-DSLog -Level info -Message "[dssoe] updated unique parameters in the xml file under node $($PSCmdlet.ParameterSetName)"
    #Update site subnet association node if selected
    if($SiteSubnetAssociate) {
        $xml.DSSOE.DCPromoOptions.Subnet.Association = $SiteSubnetAssociate.ToString()
        $xml.DSSOE.DCPromoOptions.Subnet.Domain = $SiteSubnetAssociationDomain
        $xml.DSSOE.DCPromoOptions.Subnet.EntAdminUserName = $SiteSubnetAssociationUserName
        $xml.DSSOE.DCPromoOptions.Subnet.Password = $SiteSubnetAssociationPassword
        $xml.DSSOE.DCPromoOptions.Subnet.SubnetMask = $SubnetMaskToAssociate
        Write-DSLog -Level info -Message "[dssoe] Added values under subnet to site node"
    }
    else {
        $xml.DSSOE.DCPromoOptions.Subnet.Association = $SiteSubnetAssociate.ToString()
    }

    if($IPConfig){
        $xml.DSSOE.DSConfiguration.IPConfig.Enabled = $IPConfig.ToString()
        $xml.DSSOE.DSConfiguration.IPConfig.NetworkAdapterName = $NetworkAdapterName
        $xml.DSSOE.DSConfiguration.IPConfig.IPAddress = $IPAddress
        $xml.DSSOE.DSConfiguration.IPConfig.SubnetMask = $SubnetMask
        $xml.DSSOE.DSConfiguration.IPConfig.Gateway = $Gateway
        $xml.DSSOE.DSConfiguration.IPConfig.DNSAddress = $DNSAddress
        #$xml.DSSOE.DSConfiguration.IPConfig.WINSAddress = $WINSAddress -- Removed it since netbios config is disabled - Arun 8th june 2016
        $xml.DSSOE.DSConfiguration.IPConfig.NetworkAdapterDNSSuffix = $NetworkAdapterDNSSuffix
        $xml.DSSOE.DSConfiguration.IPConfig.LmhostsLookup = $LmhostsLookup.ToString()
        Write-DSLog -Level info -Message "[dssoe] Added values under ipconfig node"
    }
    else {
        $xml.DSSOE.DSConfiguration.IPConfig.Enabled = $IPConfig.ToString()
    }

    #update DS configuration if not express install
    if(!($ExpressInstall)){
        Write-DSLog -Level info -Message "[dssoe] standard installation type selected.Started updating ds configurations"
        $DSParam = @{"ConfigurePageFile" = "ConfigureDSPageFile";"ClearEvents" = "ClearEvents";"ReserveFilePath" = "ReserveFile.Path";"ReserveFileSize" = "ReserveFile.SizeMB";
        "ExternalTimeServer" = "ExternalTimeServer.Name";"DCOULocation"="DCOULocation.OU";"ConfigureDomainPolicy"="SecurityBaselinePolicies.ConfigureDomainPolicy";
        "ConfigureDomainControllerPolicy" = "SecurityBaselinePolicies.ConfigureDomainControllerPolicy";"OU_AccountType" = "OUStructure.AccountType";"OU_AccountCode" = "OUStructure.AccountCode";
        "OU_Delegation" = "OUStructure.ADDelegation";"ConfigureDSBackup" = "DSBackup.Configure";"EnableBackupMaintenance" = "DSBackup.EnableBackupMaintenance";"BackupVolumePath" = "DSBackup.BackupVolumePath";
        "CreateADUsers" = "CreateADUsers.UserListExcelFile";"DNSForwarders" = "DNSForwarders.ForwardersIP";"ADReplicationPort"= "StaticPort.ADReplicationPort";
        "NetLogonPort" = "StaticPort.NetLogonPort";"DFSRReplicationPort" = "StaticPort.DFSRReplicationPort";
        "ConfigureStaticPort" = "StaticPort.Configure";"EnableADRecycleBin" = "ADRecycleBin.Enable";"Username" = "ADRecycleBin.Username";"Password"="ADRecycleBin.Password";
        "Domain" = "ADRecycleBin.Domain";"ADRecycleBinScope" = "ADRecycleBin.ADRecycleBinScope";"ADRecycleBinTargetServer" = "ADRecycleBin.ADRecycleBinTargetServer";
        "ADRecycleBinTargetDomain" = "ADRecycleBin.ADRecycleBinTargetDomain";"ConfigureIPAMAccess" = "IPAMAccess.Configure";"IPAMUnivGroup"="IPAMAccess.IPAMUnivGroup";"IPAMServer" = "IPAMAccess.IPAMServer"
        "ExecuteADHealthCheck" = "ADHealthCheck.Execute";"ADHCUsername" = "ADHealthCheck.UserName";"ADHCPwd" = "ADHealthCheck.Password";
        "ADHCDomain" = "ADHealthCheck.Domain";"ADHCDomainsToScan" = "ADHealthCheck.DomainsToScan";"RestrictRPCPort" = "ConfigureRPCPortRange.Configure";
        "RPCPortRange" = "ConfigureRPCPortRange.PortRange";"DisableNetBIOSOverTCPIP" = "DisableNetBIOSOverTCPIP";"DisableSMB1" = "DisableSMB1";"ConfigureDSRM" = "ConfigureDSRM";"ConfigDNSScavenging" = "ConfigDNSScavenging";
        "InstallADHotfixes" = "InstallADHotfixes"}
        if($DSConfigurations.Length -eq 0){
            Write-Error "DSConfiguration parameters missing. Provide pre/post configuration information or select express install parameter"
            Write-DSLog -Level error -Message "[dssoe] DSConfiguration parameters missing. Please provide pre/post configuration information or select express install parameter"
            return 'ds_missing_config_param'
            exit
        }
        $DSConfigurations.GetEnumerator() | foreach {
            $flag = 0
            $sparamarray = $DSParam.GetEnumerator()
            foreach($spar in $sparamarray) {
                if($_.Name -eq $spar.Name) {
                    if($($spar.Value).Contains(".")) {
                        $split1,$split2 = $($spar.Value).Split(".")
                        $xml.DSSOE.DSConfiguration.$split1.$split2 = $_.Value
                    }
                    else {
                        $xml.DSSOE.DSConfiguration.$($spar.Value) = $_.Value
                    }
                    $flag++
                }
            }
            if($flag -eq 0) {
                $InvalidParams += @($_.Name)
            }
        }
        if($invalidparams.length -ne 0) {
            Write-error "Invalid parameters passed in DSConfiguration. Please provide valid parameters and re-run the setup."
            Write-DSLog -level error -Message "[dssoe] Invalid parameters: $invalidparams"
            return 'ds_invalid_config_param'
            exit
        }
    }
    else {
        Write-DSLog -Level info -Message "[dssoe] express installation type selected"
        Write-Warning "Express install selected, hence ignoring pre and post configuration parameters"
    }
    # updated by umesh - pointing to dssoe log file path to save auto-generated XML
    $filename = $LogPath + "\dssoe-autogen-" + $(Get-Date -Format ("ddMMyyhhmmss")) + ".xml"
    $xml.Save($filename)
    $AnswerFile = $filename #Save new xml file with current date and time and assign it to ansfile file variable
    Write-DSLog -Level info -Message "[dssoe] generated unattended answer file $Answerfile" -verbose
}
else { # user has specified InputXML parameter and supplied an XML file
    Write-DSLog -Level info -Message "[dssoe] unattended file based installation type selected"
}

#region Validate answer file and load it in XML variable
#checking if user provided answer file (via $answerfile parameter) exists, 
#if not error will be thrown
If(-not(Test-Path -Path $AnswerFile)) {
    Write-DSLog -Level error -Message "[dssoe] The specified path to the XML answer file is not valid"
    return 'ds_answerfile_not_exists'
    Exit
}

$af = Get-Item -Path $AnswerFile
if($af.Extension -ne '.xml') {
    Write-DSLog -Level error -Message "[dssoe] answer file supplied must be XML file with proper extension (.xml)"
    return 'ds_invalid_answerfile_ext'
    exit
}

# try to load the xml file into a variable
Write-DSLog -Level info -Message "[dssoe] trying to load DSSOE answer file $AnswerFile"
try {
    [xml]$xmldata = Get-Content -Path $AnswerFile
    Write-DSLog -Level info -Message "[dssoe] answer file loaded successfully"
}
catch {
    Write-DSLog -Level error -Message "[dssoe] error reading answer file $AnswerFile.`n$($error[0].exception.message)"
    return 'ds_answerfile_load_error'
    exit
}
#endregion Validate answer file and load it in XML variable

#region Write Log about Express install (if selected)
if($ExpressInstall) {
    Write-DSLog -Level info -Message "[dssoe] Express Installation of DSSOE is selected by the user, the pre and post promotion tasks will be skipped." -Verbose
    $installMode = 'express'
}
Else {
    Write-DSLog -Level info -Message "[dssoe] DSSOE standard installation will be performed." -Verbose
    $installMode = 'standard'
}
#endregion

#region creds related checks misc
# passkey given, proceed
$selectedDCPromoOption = $xmldata.DSSOE.DCPromoOptions.Selected
#$xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.Password = (Get-DSPassCode -Code $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.Password -PassKey $PassKey)
$xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.Password = (Unprotect-SOEString -string $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.Password -key $PassKey).ToString()
#$xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.SafeModeAdminPassword = (Get-DSPassCode -Code $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.SafeModeAdminPassword -PassKey $PassKey)
$xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.SafeModeAdminPassword = (Unprotect-SOEString -string $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.SafeModeAdminPassword -key $PassKey).ToString()
#endregion

#region Validating the XML answer file for values specified by the user
#validating the XML file for values specified by the user
# calling the Test-DSSOEXML function from the DSValidate.psm1 module to validate the XML file
Write-DSLog -Level info -Message "[dssoe] validating DSSOE unattended installation answer file $AnswerFile for $installMode installation" -Verbose
If(-not($ConfigADPathsToOSDrive)) { # if -configaddrivestoosdrive switch is not passed in the dssoe command
    If($ExpressInstall) { # if expressinstall switch is called in the dssoe command
        #calling the function, from dsvalidate module, with -expressinstall switch so that the 
        # pre and post promotion xml values are not validated as they stand irrelevant in the case
        # of express installation
        $Status = Test-DSSOEXML -DSSOEXmlPath $AnswerFile -ExpressInstall -PassKey $PassKey
        Remove-Indent -Footer "exit -> Test-DSSOEXML" # only for this function, decrease indent after function call as it has many points where it has been returning false (result of failed validation) and writing this line those # of times is ugly
        If($Status[0] -eq $false) {
            Write-DSLog -Level error -Message "[dssoe] One or more XML parameter values failed the validation check for express installation. return code is $($Status[1]). Check the DSSOE log file for details; the DSSOE program is terminating"
            return $Status[1] #'ds_xml_validation_error'
            Exit
        }
        Else {
            Write-DSLog -Level info -Message "[dssoe] XML answer file for express installation is validated successfully" -Verbose
        }
    }
    Else { # for standard installation
        $Status = Test-DSSOEXML -DSSOEXmlPath $AnswerFile -PassKey $PassKey
        Remove-Indent -Footer "exit -> Test-DSSOEXML" # only for this function, decrease indent after function call as it has many points where it has been returning false (result of failed validation) and writing this line those # of times is ugly
        If($Status[0] -eq $false) {
            Write-DSLog -Level error -Message "[dssoe] One or more XML parameter values failed the validation check. return code is $($Status[1]). Check the DSSOE log file for details; the DSSOE program is terminating"
            return $Status[1] #'ds_xml_validation_error'
            Exit
        }
        Else {
            Write-DSLog -Level info -Message "[dssoe] Answer file is validated successfully" -Verbose
        }
    }
}
Else { # if -configaddrivestoosdrive switch is passed in the dssoe command
    If($ExpressInstall) { # if expressinstall switch is called in the dssoe command
        #calling the function, from dsvalidate module, with -expressinstall switch so that the 
        # pre and post promotion xml values are not validated as they stand irrelevant in the case
        # of express installation
        $Status = Test-DSSOEXML -DSSOEXmlPath $AnswerFile -ExpressInstall -ConfigADPathsToOSDrive -PassKey $PassKey
        Remove-Indent -Footer "exit -> Test-DSSOEXML" # only for this function, decrease indent after function call as it has many points where it has been returning false (result of failed validation) and writing this line those # of times is ugly
        If($Status[0] -eq $false) {
            Write-DSLog -Level error -Message "[dssoe] One or more XML parameter values failed the validation check for express installation. return code is $($Status[1]). Check the DSSOE log file for details; the DSSOE program is terminating"
            return $Status[1] #'ds_xml_validation_error'
            Exit
        }
        Else {
            Write-DSLog -Level info -Message "[dssoe] XML answer file for express installation is validated successfully" -Verbose
        }
    }
    Else { # for standard installation
        $Status = Test-DSSOEXML -DSSOEXmlPath $AnswerFile -ConfigADPathsToOSDrive -PassKey $PassKey
        Remove-Indent -Footer "exit -> Test-DSSOEXML" # only for this function, decrease indent after function call as it has many points where it has been returning false (result of failed validation) and writing this line those # of times is ugly
        If($Status[0] -eq $false) {
            Write-DSLog -Level error -Message "[dssoe] One or more XML parameter values failed the validation check. Return code is $($Status[1]). check the DSSOE log file for details; the DSSOE program is terminating"
            return $Status[1] #'ds_xml_validation_error'
            Exit
        }
        Else {
            Write-DSLog -Level info -Message "[dssoe] Answer file is validated successfully" -Verbose
        }
    }
}
#endregion Validating the XML answer file for values specified by the user

$AnswerFile = Resolve-Path -Path $AnswerFile #absolute path assigned to answerfile


#region --- DiskValidation ---
# if user has specified parameter to configure all AD paths to systemdrive then call function appropriately
Write-DSLog -Level info -Message "[dssoe] validating DSSOE disk requirements" -verbose
if($ConfigADPathsToOSDrive) {
    $resDiskVal = Test-DSDiskRequirements -ConfigADPathsToOSDrive # returns an array
    if($resDiskVal[0] -eq $false) { # validation failed,
        Write-DSLog -Level error -Message "[dssoe] Error validating disk requirements to install DSSOE. DSSOE setup cannot continue."
        return 'ds_sysdrv_disk_validation_error'
        exit
    }
}
else { 
    # call validation function with values in xml. note that C, D and E drives validation is performed
    # first and then xml provided values (via parameters below) used for validation (if C, D, E fails)
    $selectedDCPromoOption = $xmldata.DSSOE.DCPromoOptions.Selected
    $ADDatabasePath = $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.ADDatabasePath
    $ADLogfilePath = $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.ADLogfilePath
    $SysvolPath = $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.SysvolPath

    # call function to validate disk parameters
    $resDiskVal = Test-DSDiskRequirements -ADDSPath $ADDatabasePath -ADLogPath $ADLogfilePath -ADSysvolPath $SysvolPath
    if($resDiskVal[0] -eq $false) { # validation failed,
        Write-DSLog -Level error -Message "[dssoe] Error validating disk requirements to install DSSOE. DSSOE setup cannot continue."
        return 'ds_disk_validation_error'
        exit
    }
}
Write-DSLog -Level info -Message "[dssoe] DSSOE disk requirements validated successfully" -verbose
#endregion DiskValidation

#region StaticIPConfiguration 
# Reading IP configuration settings from the XML file and Configuring them
# store ip configuration parameters from the answer xml file and configure them as per user specifications.
If($xmldata.DSSOE.DSConfiguration.IPConfig.Enabled -eq "true")
{
    # store IP config parameters from XML into variables for easy reference in function calls
    $netAdapterName = $xmldata.dssoe.DSConfiguration.IPConfig.NetworkAdapterName
    $ipAddress = $xmldata.dssoe.DSConfiguration.IPConfig.IPAddress
    $subnetMask = $xmldata.dssoe.DSConfiguration.IPConfig.SubnetMask
    $ipGateway = $xmldata.dssoe.DSConfiguration.IPConfig.Gateway
    $dnsServers = $xmldata.dssoe.DSConfiguration.IPConfig.DNSAddress
    #$winsAddress = $xmldata.dssoe.DSConfiguration.IPConfig.WinsAddress - Not accepting wins parameter, hence commenting this line - Arun 8-06-16
    $netDnsSuffix = $xmldata.dssoe.DSConfiguration.IPConfig.NetworkAdapterDNSSuffix
    #$sysDnsSuffix = $xmldata.dssoe.DSConfiguration.IPConfig.SystemDNSsuffix #This tab is removed from XML - Tarun 28-9-15
    # added condition by Umesh as it was throwing error due to switch param and string conversion
    $lmHostsLookup = ($xmldata.dssoe.DSConfiguration.IPConfig.LmhostsLookup -eq "true")

    Write-DSLog -Level info -Message "[dssoe] Configuring Static IP using parameters from the XML file" -verbose
    Write-DSLog -Level info -Message "[dssoe] Configuring IP address ($ipAddress) and subnet mask ($subnetMask)"
    $res = Set-DSIPAddressAndSubnet -NetAdapterName $netAdapterName -IpAddress $ipAddress -SubnetMask $subnetMask
    if($res -eq $false) { # some errors/message from netsh
        Write-DSLog -Level error -Message "[dssoe] Failed to set IP address properly. DSSE setup cannot continue. Review log file for potential issues and try again"
        return 'ds_static_ipconfig_failed'
        exit
        
    }
    
    # configure DNS server
    Write-DSLog -Level info -Message "[dssoe] Configuring DNS address(es): $dnsServers"
    $Configdns = Set-DSDNSAddress -DNSServer $dnsServers -NetAdapterName $netAdapterName
    If(-not($Configdns -eq 0) -or ($Configdns -eq 1)) {
        Write-DSLog -Level error -Message "[dssoe] DNS address configuration failed with return code: $Configdns"
        return 'ds_dns_ip_conf_error'
        Exit
    }
    Else {
        Write-DSLog -Level info -Message "[dssoe] DNS address is successfully configured; $($xmldata.DSSOE.DSConfiguration.IPConfig.DNSAddress)"
    }

    # configure IP Gateway
    If($ipGateway -ne "")
    {
        Write-DSLog -Level info -Message "[dssoe] Configuring gateway IP address as $ipGateway"
        $gwConf = Set-DSGatewayIP -IpGateway $ipGateway -NetAdapterName $netAdapterName
        If(-not($gwConf -eq [int]0) -or ($gwConf -eq [int]1)) {
            Write-DSLog -Level error -Message "[dssoe] Gateway address configuration failed with return code: $gwConf"
            return 'ds_gw_ip_conf_error'
            Exit
        }
        Else {
            Write-DSLog -Level info -Message "[dssoe] Gateway address is successfully configured"
        }
    }

    # configure WINS address
    <#If($winsAddress -ne "")
    {
        Write-DSLog -Level info -Message "[dssoe] Configuring WINS IP address(es) ($winsAddress)"
        $configWINS = Set-DSWINSAddress -WINSServer $winsAddress -NetAdapterName $netAdapterName
        If(-not($configWINS -eq [int]0) -or ($configWINS -eq [int]1)) {
            Write-DSLog -Level error -Message "[dssoe] WINS address configuration failed with return code: $configWINS"
        }
        Else {
            Write-DSLog -Level info -Message "[dssoe] WINS address is successfully configured"
        }
    }#> #- Not accepting wins parameter, hence commenting this section - Arun 8-06-16

    # configure network adapter dns suffix
    If($netDnsSuffix -ne "")
    {
        Write-DSLog -Level info -Message "[dssoe] Configuring Network Adapter DNS Suffix ($netDnsSuffix)"
        $ndsConf = Set-DSNetworkAdapterDNSSuffix -NetworkAdapterDNSSuffix $netDnsSuffix -NetAdapterName $netAdapterName
        If(-not($ndsConf -eq [int]0) -or ($ndsConf -eq [int]1)) {
            Write-DSLog -Level error -Message "[dssoe] Network adapter DNS suffix configuration failed with return code: $ndsConf"
        }
        Else {
            Write-DSLog -Level info -Message "[dssoe] Network adapter DNS suffix is successfully configured"
        }
    }

    <#
    # configure system dns suffix
    # Removed, as this option is causing Reboot Pending error during DC promotion.
    # Technically this option is not needed to be configured before DC promotion as SystemDNSSuffix
    # auto updates when the system changes it domain membership - Tarun - 28-9-15
    If($sysDnsSuffix -ne "")
    {
        Write-DSLog -Level info -Message "[dssoe] Configuring System DNS Suffix ($sysDnsSuffix)"
        try {
            Set-DSSystemDNSSuffix -SystemDNSSuffix $sysDnsSuffix
            Write-DSLog -Level info -Message "[dssoe] System DNS Suffix is successfully configured"
        }
        catch {
            Write-DSLog -Level error -Message "[dssoe] System DNS suffix configuration failed: $($error[0].exception.message)"
        }
    }#>

    # configure LMHosts lookup - changed ot to compare as True - umesh 22-feb-16
    If($lmHostsLookup.ToString() -eq "True")
    {
        Write-DSLog -Level info -Message "[dssoe] Configuring LMHosts lookup"
        try {
            Set-DSLmHostsLookup -LmHostsLookup $lmHostsLookup.ToString()
            Write-DSLog -Level info -Message "[dssoe] LMHosts lookup configuration is complete"
        }
        catch {
            Write-DSLog -Level error -Message "[dssoe] LMHosts lookup configuration failed: $($error[0].exception.message)"
        }
    }
    Write-DSLog -Level info -Message "[dssoe] Static IP Configuration is completed" -verbose
}
Else { # check if dhcp is enabled or not and show appropriate message
    
    Write-DSLog -Level info -Message "[dssoe] IPConfig.Enabled parameter is set to False, thus IP config configurations will not be implemented."
}  

#endregion StaticIPConfiguration

#region ValidateDHCPStatus
$DHCPStatus = Get-WmiObject -Class Win32_NetworkAdapterConfiguration -Filter IPEnabled=TRUE -ComputerName ($env:COMPUTERNAME) | Where-Object { $_.DHCPEnabled -eq $true }
    If($DHCPStatus -ne $null) {
        If(!($IgnoreDHCPWarning)) {
            #Write-DSLog -Level error -Message "[dssoe] DHCP is found to be enabled on one or more network adapters on the server, which is not a DXC & Microsoft recommended configuration for a domain controller. Either use the IP Configuration parameters to configure static IP on the server or do it manually. Alternatively, if your requirement dictates the use of DHCP assigned IP Address on the server than pass -IgnoreDHCPWarning switch parameter in the command to bypass the ds_dhcp_conf_found error message. DSSOE program is terminating."
            Write-Warning -Message "This computer has at least one physical network adapter that does not have static IP address(es) assigned to its IP Properties. If both IPv4 and IPv6 are enabled for a network adapter, both IPv4 and IPv6 static IP addresses should be assigned to both IPv4 and IPv6 Properties of the physical network adapter. Such static IP address(es) assignment should be done to all the physical network adapters for reliable Domain Name System (DNS) operation. Either use the IP Configuration parameters to configure static IP on the server or do it manually. Alternatively, if your requirement dictates the use of DHCP assigned IP Address on the server than pass -IgnoreDHCPWarning switch parameter in the command to bypass the ds_dhcp_conf_found error message. DSSOE program is terminating."
            Write-DSLog -Level error -Message "This computer has at least one physical network adapter that does not have static IP address(es) assigned to its IP Properties. If both IPv4 and IPv6 are enabled for a network adapter, both IPv4 and IPv6 static IP addresses should be assigned to both IPv4 and IPv6 Properties of the physical network adapter. Such static IP address(es) assignment should be done to all the physical network adapters for reliable Domain Name System (DNS) operation. Either use the IP Configuration parameters to configure static IP on the server or do it manually. Alternatively, if your requirement dictates the use of DHCP assigned IP Address on the server than pass -IgnoreDHCPWarning switch parameter in the command to bypass the ds_dhcp_conf_found error message. DSSOE program is terminating."
            return 'ds_dhcp_conf_found'
            Exit
        }
        Else {
            Write-DSLog -Level error -Message "[dssoe] IgonreDHCPWarning switch parameter is passed. DSSOE will continue to build this server as a domain controller despite of DHCP being enabled on one or more NIC cards, which is not a DXC & Microsoft recommended configuration."
        }
    }
    Else {
        Write-DSLog -Level info -Message "[dssoe] None of the NIC cards on the server has DHCP enabled. DHCP check is passed successfully"
    }
#endregion ValidateDHCPStatus


#region SchemaUpgradeIfRequired
# Retrieving & comparing the schema version of the forest 
# with required schema version of given OS and upgrade / exit schema accordinlgy.
# Retrieving the current schema version of the forest; comparing it with the required schema version 
# for given OS; and exit/continue accordingly

Write-DSLog -Level info -Message "[dssoe] Identifying domain promotion option specified by user" -verbose
# save selected domain promotion option in a variable
$selectedDCPromoOption = $xmldata.DSSOE.DCPromoOptions.Selected
Write-DSLog -Level info -Message "[dssoe] Domain promotion option selected is $selectedDCPromoOption" -verbose

# if NewChildDomain or NewTreeDomain is selected as the build option then check/perform schema upgrade
# only if user has specified to do and criteria to do so is met
If($selectedDCPromoOption -eq "NewChildDomain" -or $selectedDCPromoOption -eq 'NewTreeDomain') {
    # save credentials in variable from selected promotion section in xml
    Write-DSLog -Level info -Message "[dssoe] retrieving credentials from answer file"
    $ncDomain = $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.Domain
    $ncUser = $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.Username
    $ncPass = $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.Password
    
    #retrieving the schema version of the forest
    Write-DSLog -Level info -Message "[dssoe] Identifying schema version of given forest/domain $ncDomain"
    $osName = (Get-WmiObject win32_operatingsystem).Name.split('|')[0]
    #comment: 2-Jan-2016 - Tarun - Updated the code to use the latest fn to retrieve the schema version number. Removed the refrences to the older functions.
    #$schemaversion = Get-ForestSchemaVersion -domain $ncDomain -username $ncUser -password $ncPass
    #$schemaversion = Test-DSDomainExistence -username $ncUser -password $ncPass -domain $ncDomain -domaintosearch "" -schemaversion
    #calling the function from ADFromWorkgroup module to retreive the forest info and then calling another function to retrieve the schema version number.
    #$ForestInfo = Get-DSADForest -Domain $ncDomain -UserName $ncUser -Password $ncPass
    #$ForestInfo = Get-DSADForest -Domain 'contoso.com' -UserName 'soe-load' -Password 'P@ssw0rd1'
    
    $schemaversion = Get-ForestSchemaVersion -domain $ncDomain -username $ncUser -password $ncPass
    #write-host "Schema version is $schemaversion"
    Write-DSLog -Level info -Message "[dssoe] Schema version of the forest is $schemaversion"
    
    # if a parameter is not specified, it is $null (trying to reference $UpgradeSchema here)
    If(((Test-DSSchemaUpgradeRequired -schemaVersion $schemaversion) -eq $true) -and (-not ($UpgradeSchema))) {
        # schema upgrade required to run DC promotion, user has not specified parameter to upgrade schema
        Write-DSLog -Level error -Message "[dssoe] The Schema ($schemaversion) for this forest has been detected to not have been upgraded to support the promotion of a $osName Domain Controller. Please upgrade the schema and run the DSSOE program again OR if you would like the DSSOE program to upgrade the schema, please use the -UpgradeSchema switch in the DSSOE command. Important - Please ensure you have conducted the necessary planning, testing, change management requests and obtained the necessary approvals/privileges before preforming the schema upgrade. DSSOE program is terminating." -WriteErrorOnScreen
        return 'ds_unsupported_schema_version'
        exit # exit code
    }
    elseif(((Test-DSSchemaUpgradeRequired -schemaVersion $schemaversion) -eq $true) -and ($UpgradeSchema)) {
        # schema upgrade required to run DC promotion, user has specified parameter to upgrade schema
        Write-DSLog -Level info -Message "[dssoe] DSSOE setup has determined that schema upgrade is required on this server before proceeding with domain promotion"
        Write-DSLog -Level info -Message "[dssoe] Validating whether the specified user account:$ncUser is a member of schema admins or not"
        try {        
            $IsSchemaAdm = Test-DSGroupMembership -Domain $ncDomain -Username $ncUser -Password $ncPass -IsSchemaAdmins        
        }
        catch {
             Write-DSLog -Level error -Message "[dssoe] An error occurred while validating the group membership"
             Write-DSLog -Level error -Message "[dssoe] $($_.exception.message)"
             $IsSchemaAdm = $False
        }
        If($IsSchemaAdm -eq $true) {
            Write-DSLog -Level info -Message "[dssoe] Group membership is successfully validated"
            Write-DSLog -Level info -Message "[dssoe] Attempting to upgrade schema as per user input in answer file"
            $res = Invoke-DSSchemaUpgrade -Domain $ncDomain -Username $ncUser -Password  $ncPass -dcpromoselection $selectedDCPromoOption
            if($res -eq $false) {
               Write-DSLog -Level error -Message "[dssoe] An error has occured while upgrading the schema. Check the DSSOE logs for details. DSSOE program is terminating." -WriteErrorOnScreen
               return 'ds_schema_upgrade_failed'
               Exit
            }
            else { 
                Write-DSLog -Level info -Message "[dssoe] schema is upgraded successfully"
            }            
        }
        Else {
            Write-DSLog -Level error -Message "[dssoe] Group membership validation failed. User account is not a member of Schema Admins group. Please make sure that the user account must possess Schema Admins and Enterprise admins rights to proceed with the schema upgrade process."
            return 'ds_not_schema_admins'
            Exit
        }
    }        
    Elseif((Test-DSSchemaUpgradeRequired -schemaVersion $schemaversion) -eq $false) {
        # schema upgrade not required
        Write-DSLog -Level info -Message "[dssoe] The schema is already upgraded"
    }
}
#endregion SchemaUpgradeIfRequired

#region Set AD paths based on disk validation results
# Set disk related paths based on disk validation performed
# set disk related paths based on disk validation performed, regardless of selected
# DCPromo option as these paths are consistent in xml and will be same for all DCPromo options
$ADDatabasePath = $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.ADDatabasePath
$ADLogFilepath = $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.ADLogfilePath
$ADSysvolPath = $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.SysvolPath

# if user has specified to configure all AD paths to systemDrive then configure it here
If($ConfigADPathsToOSDrive) {
    $RootDrive = $env:SystemDrive       
    $ADDatabasePath = "$RootDrive\NTDS-DB"
    $ADLogFilepath = "$RootDrive\NTDS-LOGS"
    $ADSysvolPath = "$RootDrive\SYSVOL"            
}
<#elseif($resDiskVal[1] -eq 1) { #disk validation done using CDE drives
    $ADDatabasePath = "E:\NTDS-DB"
    $ADLogFilepath = "D:\NTDS-LOGS"
    $ADSysvolPath = "E:\SYSVOL"
}#>
#Arun: Removed as per team's discussion 14-12-2016
elseif($resDiskVal[1] -eq 2) { # disk validated using user-provided paths (in xml)
    # do nothing, already set above using values from XML
}
else { # something weird has happened, log error and go home
    Write-DSLog -Level error -message ("[dssoe] Unexpected disk validation type return code {0}" -f $resDiskVal[1]) -WriteErrorOnScreen
    return 'ds_unexpected_disk_validation_error'
    exit
}

# record paths in log file for troubleshooting purposes
Write-DSLog -Level info -Message "[dssoe] AD database path will be set to $ADDatabasePath"
Write-DSLog -Level info -Message "[dssoe] AD log file path will be set to $ADLogfilePath"
Write-DSLog -Level info -Message "[dssoe] AD Sysvol path will be set to $ADSysvolPath"
# done with setting AD paths variables
#endregion Set AD paths based on disk validation results

#region Perform Pre Promotion Configuration
if($ExpressInstall) {
    Write-DSLog -Level info -Message "[dssoe] Express install option specified, skipping dssoe pre-promotion configuration"
}
else { # configure pre-promotion items
    #configure startup and recovery options
    #Write-DSLog -Level info -Message "[dssoe] Configuring startp and recovery options"
    
    #$StartupRecovery = ""
    $ReserveFile = ""
        
    <#
    If($xmldata.DSSOE.DSConfiguration.StartupAndRecoverySettings.Enabled -eq "true") {
        $TimetoDisplayOS = $xmldata.DSSOE.DSConfiguration.StartupAndRecoverySettings.TimetoDisplayOS
        $WriteDebugInfo = $xmldata.DSSOE.DSConfiguration.StartupAndRecoverySettings.WriteDebugInfo
        Write-DSLog -Level info -Message "[dssoe] Time to Display OS:$timetodisplayos"
        Write-DSLog -Level info -Message "[dssoe] Write Debug Info:$writedebuginfo"
        #calling function from dsimplement.psm1 module
        $setstartuprecovery = Set-DSStartupAndRecovery -TimetoDisplayOS $TimetoDisplayOS -WriteDebugInfo $WriteDebugInfo
        $StartupRecovery = "True"
    }
    else {
        Write-DSLog -Level info -Message "[dssoe] Startup and recovery option is not selected for configuration"
        $StartupRecovery = "False"
    }
    #>

    #configure pagefile 
    If($xmldata.DSSOE.DSConfiguration.ConfigureDSPageFile -eq "true") {
        Write-DSLog -Level info -Message "[dssoe] Configuring page file"
        try {
            #calling function from dsimplement.psm1 module to set the pagefile
            $setpagefile = Set-DSPageFile -ADDBPath $ADDatabasePath
        }
        catch {
            Write-DSLog -Level error -Message "[dssoe] Error configuring pagefile.. $($error[0].exception.message)"
        }        
    }
    Else {
        Write-DSLog -Level info -Message "[dssoe] Page file is not selected for configuration"
        New-Item -Path "C:\support\logs\dssoe\nopage.txt" -ItemType file -Force | Out-Null #this temporary file is being created to identify if uer not opted for pagefile creation and will be reported in wincompliance
    }

    #Clear event logs
    If($xmldata.DSSOE.DSConfiguration.ClearEvents -eq "true") {
        Write-DSLog -Level info -Message "[dssoe] Clearing the system, application & security event logs"
        try {
            # calling fn from dsimplement.psm1 module to clear the event logs
            $setclearevents = Set-DSClearEvents
            Write-DSLog -Level info -Message "[dssoe] Event logs cleared"
        }
        catch {
            Write-DSLog -Level error -Message "[dssoe] error clearing events$($error[0].exception.message)"
        }
    }
    else {
        Write-DSLog -Level info -Message "[dssoe] option to clear event logs is not specified"
    }

    #create reserve file
    If($xmldata.DSSOE.DSConfiguration.ReserveFile.Path -ne "" -and $xmldata.DSSOE.DSConfiguration.ReserveFile.SizeMB -ne "") {
        $reservefilepath = $xmldata.DSSOE.DSConfiguration.ReserveFile.Path
        $size = $xmldata.DSSOE.DSConfiguration.ReserveFile.SizeMB
        Write-DSLog -Level info -Message "[dssoe] Creating reserve file; Path:$reservefilepath SizeinMB:$size"
        #calling function from dsimplement.psm1 to create the reserve file
        $createreservefile = Set-DSReserveFile -FilePath $reservefilepath -FileSize $size
        $ReserveFile = "True"   
    }
    Else {
        Write-DSLog -Level info -Message "[dssoe] Reserve file is not created as the Path or SizeMB parameter is not specified"
        $ReserveFile = "False"
    }

    # disable NetBIOS over TCP/IP as per Amy's feedback 11-apr-16
     If($xmldata.DSSOE.DSConfiguration.DisableNetBIOSOverTCPIP -eq "False") 
     {
     $resetNetB = "False"
      Write-DSLog -Level info -Message "The value of DisableNetBIOSOverTCPIP parameter is set to False, thus Netbios over tcpip will not be disabled."
     }
        else
        {
            if(Get-ADDSNetBStatus)
            {
            $resetNetB = "False"
            Write-DSLog -Level info -Message "Netbios over tcp/ip already disabled on this server. Hence not calling the function to disable"
            }
            else
            {
                $nbres = Disable-NetBIOSOverTCPIP
                if($nbres -eq 'Success') 
                {
                $resetNetB = "True"
                    Write-DSLog -Level info -Message "[dssoe] NetBIOS over TCP/IP disabled successfully"
                }
                else {
                $resetNetB = "False"
                    Write-DSLog -Level info -Message "[dssoe] Failed to disable NetBIOS over TCP/IP successfully"
                    Write-DSLog -Level info -Message "[dssoe] Error returned is: $nbres"
                     }
            }
        }
    #disable SMB1
    If($xmldata.DSSOE.DSConfiguration.DisableSMB1 -ne "False") 
    {
        if(!(Get-ADDSSMB))
        {
            if(Test-OSIsWindowsServer2008R2)
            {
            Write-DSLog -Level info -Message "calling function to disable SMB1"
            $resetSMB = "True"
            Disable-SMB1 -Windows2008Server
            }
            else
            {
            $resetSMB = "True"
            Write-DSLog -Level info -Message "calling function to disable SMB1"
            Disable-SMB1
            }
        }
        else
        {
        $resetSMB = "false"
        Write-DSLog -Level info -Message "SMB 1.0 is already disabled on this server. Hence not calling the function to disable"
        }
    }
    else{$resetSMB = "false"}

    #Configure rpc port range
    If($xmldata.DSSOE.DSConfiguration.ConfigureRPCPortRange.Configure -ne "False") 
    {
    Write-DSLog -Level info -Message "Calling function to configure RPC port range restriction with range: $($xmldata.DSSOE.DSConfiguration.ConfigureRPCPortRange.PortRange)"
    Enable-RPCPortRestriction -PortRange $xmldata.DSSOE.DSConfiguration.ConfigureRPCPortRange.PortRange
    $resetPort = "True"
    }
    else
    {$resetPort = "False"}
    
}
#endregion Perform Pre Promotion Configuration


#region Constructing the DSSOE unattended command for "New Domain New Forest" Installation
# DSSOE unattend answer file is now loaded in the variable, identify type of DS build
# other build parameters and construct unattended parameters
If($selectedDCPromoOption -eq "NewDomainNewForest")
{
    #putting the values from XML, relevant to NewDomainNewForest implementation, in the variables
    $Username = $xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.UserName
    $Password = $xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.Password
    $DomainFQDN = $xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.NewDomainFQDN
    $NetBIOS = $xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.NewDomainNetBIOS
    
    $safemodepassword = $xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.SafeModeAdminPassword
    $forestmode = $xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.ForestFunctionalLevel
    $domainmode = $xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.DomainFunctionalLevel
    # added condition by Umesh, as it was causing errors on string to bool conversion
    $Installdns = ($xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.InstallDNS -eq "true")
    #$rebootoncompletion = ($xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.RebootOnCompletion -eq "true") 14-Jun-16: [TR] Removed reboot on completion

    # construct dcpromo command line for w2k8r2 platform
    If(Test-OSIsWindowsServer2008R2 -eq $true)
    {
        Write-DSLog -Level info -Message "[dssoe] Constructing command for DC promotion on $osName" 
        #declaring variables and passing values in the preparation to construct the Dcpromo command
        # for NewDomainNewForest when the underlying OS is W2K8R2        
        #converting forestmode passed via XML file to numeric value
        $forestmode = Get-DSForestModeNumberW2k8R2 -ForestModeString $forestmode
        ##converting domainmode passed via XML file to numeric value
        $domainmode = Get-DSDomainModeNumberW2k8R2 -DomainModeString $domainmode

        # construct DCPromo command using path set above
        Write-DSLog -Level info -Message "[dssoe] Installing the first domain in the forest: $DomainFQDN" -verbose
        #calling the update-dsparams function from dsutils.psm1 module, to convert the value of true / false from the XML to Yes / No  respectively        
        # 2-feb-16: added .ToString() to $InstallDNS to correctly convert its value as it is a switch param type variable! ~ umesh
        $DCpromooptions = "/unattend /InstallDns:$(Update-DSParams -Value $InstallDNS.ToString() -textvalue) /replicaOrNewDomain:domain /newDomain:forest /newDomainDnsName:$DomainFQDN /DomainNetbiosName:$NetBIOS /databasePath:$ADDatabasePath /logPath:$ADLogfilePath /sysvolpath:$ADSysvolPath /safeModeAdminPassword:$safemodepassword /forestLevel:$forestmode /domainLevel:$domainmode /rebootOnCompletion:No"            

        # run DCpromo and capture return codes
        $res = Start-DSDomainPromotion -DCPromoParams $DCpromooptions
        if($res -eq $false) {
            Write-DSLog -Level error -Message "[dssoe] DSSOE domain promotion failed" -verbose
            #if not expressinstall, reset the prepromotion configuration to default values if they are set to true in XML
            if(-not($ExpressInstall)) {
                #calling function from dsimpletement module
                Reset-DSPrePromotionOptions -DSReserveFile $ReserveFile -ResFilePath $reservefilepath -ResetNetB $resetNetB -ResetSMB $resetSMB -ResetPort $resetport
            }    
            return 'ds_domain_promotion_failed'
            exit
        }
        elseif($res -eq $true) {
            Write-DSLog -Level info -Message "[dssoe] Starting the execution of post promotion configurations" -verbose
            # set autologon and kick off post promotion script
            Set-DSPostPromotionTasks -UserName $Username -Password $Password -Domain $NetBIOS -DSInstallMode $installMode -AnswerFile $AnswerFile -PassKey $PassKey -ExportUnattendBuildFileTo $ExportUnattendBuildFileTo
        }
        else {
            Write-DSLog -Level error -Message "[dssoe] DSSOE domain promotion did not complete. Check the log file for error."
            Exit
        }
    }
    #declaring variables and passing values in the preparation to construct the Dcpromo command
    # for NewDomainNewForest when the underlying OS is W2K12 R1 or R2
    If((Test-OSIsWindowsServer2012 -eq $true) -or (Test-OSIsWindowsServer2012R2 -eq $true))
    {
        #converting forestmode passed via XML file to a value understand by 2012 dcpromo cmmand
        $forestmode = Get-DSForestModeNumberW2k12 -ForestModeString $forestmode
        #converting domainmode passed via XML file to a value understand by 2012 dcpromo cmmand
        $domainmode = Get-DSDomainModeNumberW2k12 -DomainModeString $domainmode
        
        #AD DS installation cmdlets have been used to utilize the pre-check and other stuff 
        #not provided by dcpromo / unattend command
        Write-DSLog -Level info -Message "[dssoe] Installing the first domain in the forest: $DomainFQDN" -verbose
        #calling the update-dsparams function from dsutils.psm1 module, to convert the value of true / false from the XML to $true / $false bool value respectively         
        # 2-feb-16: added .ToString() to $InstallDNS to correctly convert its value as it is a switch param type variable! ~ umesh
        $addsCommand = "Install-ADDSForest -DatabasePath $ADDatabasePath -DomainMode $domainmode -DomainName $DomainFQDN -DomainNetbiosName $NetBIOS -ForestMode $forestmode -InstallDns:$(Update-DSParams -Value $Installdns.ToString() -boolvalue) -LogPath $ADLogfilePath -safemodeadministratorpassword (convertto-securestring '$safemodepassword' -asplaintext -force) -NoRebootOnCompletion:$('$true') -SysvolPath $ADSysvolPath -Force:$('$true')"
        
        # todo: write code to handle different return codes ($res)
        $res = Start-DSDomainPromotion -ADDSCommand $addsCommand
        if($res -eq $false) {
            Write-DSLog -Level error -Message "[dssoe] DSSOE domain promotion failed" -verbose
            #if not expressinstall, reset the prepromotion configuration to default values if they are set to true in XML
            if(-not($ExpressInstall)) {
                #calling function from dsimpletement module
                Reset-DSPrePromotionOptions -DSReserveFile $ReserveFile -ResFilePath $reservefilepath -ResetNetB $resetNetB -ResetSMB $resetSMB -ResetPort $resetport
            }
            return 'ds_domain_promotion_failed'
            exit
        }
        elseif($res -eq $true) {
            Write-DSLog -Level info -Message "[dssoe] Starting the execution of post promotion configurations" -verbose
            # set autologon and kick off post promotion script
            Set-DSPostPromotionTasks -UserName $Username -Password $Password -Domain $NetBIOS -DSInstallMode $installMode -AnswerFile $AnswerFile  -PassKey $PassKey -ExportUnattendBuildFileTo $ExportUnattendBuildFileTo
        }
        else {
            Write-DSLog -Level error -Message "[dssoe] DSSOE domain promotion did not complete. Check the log file for error."
            Exit
        }
    }

    # for NewDomainNewForest when the underlying OS is W2K16
    If(Test-OSIsWindowsServer2016 -eq $True) {
        
        #converting forestmode passed via XML file to a value understand by 2016 dcpromo cmmand
        $forestmode = Get-DSForestModeNumberW2k16 -ForestModeString $forestmode
        #converting domainmode passed via XML file to a value understand by 2016 dcpromo cmmand
        $domainmode = Get-DSDomainModeNumberW2k16 -DomainModeString $domainmode
        
        #AD DS installation cmdlets have been used to utilize the pre-check and other stuff 
        #not provided by dcpromo / unattend command
        Write-DSLog -Level info -Message "[dssoe] Installing the first domain in the forest: $DomainFQDN" -verbose
        #calling the update-dsparams function from dsutils.psm1 module, to convert the value of true / false from the XML to $true / $false bool value respectively         
        # 2-feb-16: added .ToString() to $InstallDNS to correctly convert its value as it is a switch param type variable! ~ umesh
        $addsCommand = "Install-ADDSForest -DatabasePath $ADDatabasePath -DomainMode $domainmode -DomainName $DomainFQDN -DomainNetbiosName $NetBIOS -ForestMode $forestmode -InstallDns:$(Update-DSParams -Value $Installdns.ToString() -boolvalue) -LogPath $ADLogfilePath -safemodeadministratorpassword (convertto-securestring '$safemodepassword' -asplaintext -force) -NoRebootOnCompletion:$('$true') -SysvolPath $ADSysvolPath -Force:$('$true')"
        #Write-DSLog -Level info -message "[dssoe] $addsCommand"
        # todo: write code to handle different return codes ($res)
        $res = Start-DSDomainPromotion -W2K16ADDSCommand $addsCommand
        if($res -eq $false) {
            Write-DSLog -Level error -Message "[dssoe] DSSOE domain promotion failed" -verbose
            #if not expressinstall, reset the prepromotion configuration to default values if they are set to true in XML
            if(-not($ExpressInstall)) {
                #calling function from dsimpletement module
                Reset-DSPrePromotionOptions -DSReserveFile $ReserveFile -ResFilePath $reservefilepath -ResetNetB $resetNetB -ResetSMB $resetSMB -ResetPort $resetport
            }
            return 'ds_domain_promotion_failed'
            exit
        }
        elseif($res -eq $true) {
            Write-DSLog -Level info -Message "[dssoe] Starting the execution of post promotion configurations" -verbose
            # set autologon and kick off post promotion script
            Set-DSPostPromotionTasks -UserName $Username -Password $Password -Domain $NetBIOS -DSInstallMode $installMode -AnswerFile $AnswerFile  -PassKey $PassKey -ExportUnattendBuildFileTo $ExportUnattendBuildFileTo
        }
        else {
            Write-DSLog -Level error -Message "[dssoe] DSSOE domain promotion did not complete. Check the log file for error."
            Exit
        }
    }
}
#endregion Constructing the DSSOE unattended command for New Domain New Forest Installation

#region Constructing the DSSOE unattended command for AdditionalDC Installation
#[xml]$xmldata = Get-Content -Path "D:\SOE\DSSOE\DSSOE\DSSOE Packages and Code\DSSOEv2.2.0_Dev_Share\XML\dssoe.xml"
If($xmldata.DSSOE.DCPromoOptions.Selected -eq "AdditionalDC") {
    $Username = $xmldata.DSSOE.DCPromoOptions.AdditionalDC.UserName
    $Password = $xmldata.DSSOE.DCPromoOptions.AdditionalDC.Password
    $DomainFQDN = $xmldata.DSSOE.DCPromoOptions.AdditionalDC.Domain
    $safemodepassword = $xmldata.DSSOE.DCPromoOptions.AdditionalDC.SafeModeAdminPassword
    # added condition by Umesh, as it was causing errors on string to bool conversion
    $Installdns = ($xmldata.DSSOE.DCPromoOptions.AdditionalDC.InstallDNS -eq "true")
    $Globalcatalog = ($xmldata.DSSOE.DCPromoOptions.AdditionalDC.GlobalCatalog -eq "true")
    $RODC = ($xmldata.DSSOE.DCPromoOptions.AdditionalDC.RODC -eq "true")
    $CriticalRepOnly = ($xmldata.DSSOE.DCPromoOptions.AdditionalDC.CriticalReplicationOnly -eq "true")
    #$rebootoncompletion = ($xmldata.DSSOE.DCPromoOptions.AdditionalDC.RebootOnCompletion -eq "true") 14-Jun-16: [TR] Removed reboot on completion
    $Sitename = $xmldata.DSSOE.DCPromoOptions.AdditionalDC.ADSiteName
    $ReplicateDataFromExistingDC = $xmldata.DSSOE.DCPromoOptions.AdditionalDC.ReplicateDatafromExistingDC.Enabled
    $ReplicaDC = $xmldata.DSSOE.DCPromoOptions.AdditionalDC.ReplicateDatafromExistingDC.ReplicaDC
    $InstallFromMedia = $xmldata.DSSOE.DCPromoOptions.AdditionalDC.InstallFromMedia.ReplicateDatafromMedia
    $MediaPath = $xmldata.DSSOE.DCPromoOptions.AdditionalDC.InstallFromMedia.MediaPath
    $NetBIOS = $DomainFQDN.Split('.')[0]
        
    $htDCPromo = @{}
    #$htDCPromo.Add('/unattend','') #Comment: 13 Jan; Tarun: Commented this line to fix the issue with final output of the dcpromooptions
    $htDCPromo.Add('/UserDomain:',$DomainFQDN)
    $htDCPromo.Add('/UserName:',$Username)
    $htDCPromo.Add('/Password:',$Password)
    #calling the update-dsparams function from dsutils.psm1 module, to convert the value of true / false from the XML to Yes / No respectively
    # 2-feb-16: added .ToString() to $InstallDNS to correctly convert its value as it is a switch param type variable! ~ umesh
    $htDCPromo.Add('/InstallDNS:',$(Update-DSParams -Value $Installdns.ToString() -textvalue))
    $htDCPromo.Add('/ConfirmGC:',$(Update-DSParams -Value $Globalcatalog.ToString() -textvalue))
    $htDCPromo.Add('/replicaOrNewDomain:','readOnlyReplica')
    $htDCPromo.Add('/replicaDomainDNSName:',$DomainFQDN)
    $htDCPromo.Add('/DatabasePath:','')
    $htDCPromo.Add('/LogPath:','')
    $htDCPromo.Add('/SysvolPath:','')
    $htDCPromo.Add('/safeModeAdminPassword:',$safemodepassword)
    $htDCPromo.Add('/rebootOnCompletion:','no')
    $htDCPromo.Add('/SiteName:',$Sitename)

    # if underlying OS is win 2k8R2 then construct command and launch it accordingly
    If(Test-OSIsWindowsServer2008R2 -eq $true) {
        Write-DSLog -Level info -Message "[dssoe] Constructing command for DC promotion on $osName"
        $RootDrive = $env:SystemDrive       
        $htDCPromo['/DatabasePath:'] = $ADDatabasePath
        $htDCPromo['/LogPath:'] = $ADLogfilePath
        $htDCPromo['/SysvolPath:'] = $ADSysvolPath

        # set DCpromo options related to RODC configuration 
        If($RODC.ToString() -eq "true") {
            If($ReplicateDataFromExistingDC -eq "true") {                    
                If($ReplicaDC -eq "Automatic")  { 
                    Write-DSLog -Level info -Message "[dssoe] Promoting a Read Only Domain controller with replication partner chosen automatically" -verbose
                } # just write the log
                else {
                    Write-DSLog -Level info -Message "[dssoe] Promoting a Read Only Domain controller with $ReplicaDC DC as the replication partner" -verbose
                    $htDCPromo.Add('/ReplicationSourceDC:',$ReplicaDC)
                }
            }
            Else { # not replicating from existing DC
                if($InstallFromMedia -eq "true") {
                    Write-DSLog -Level info -Message "[dssoe] Promoting a Read Only Domain controller with Install from Media option, where media path is $MediaPath" -verbose
                    $htDCPromo.Add('/ReplicationSourcePath:',$MediaPath)
                }
            }
        }
        Else { # user has not selected option to create RODC
            If($ReplicateDataFromExistingDC -eq "true") {                    
                If($ReplicaDC -eq "Automatic") {
                    Write-DSLog -Level info -Message "[dssoe] Promoting an Additional Domain controller with replication partner chosen automatically" -verbose
                    $htDCPromo['/replicaOrNewDomain:'] = 'Replica'
                }
                Else {
                    Write-DSLog -Level info -Message "[dssoe] Promoting an Additional Domain Controller with $ReplicaDC DC as the replication partner" -verbose
                    $htDCPromo['/replicaOrNewDomain:'] = 'Replica'
                    $htDCPromo.Add('/ReplicationSourceDC:',$ReplicaDC)	
                }
            }
            Else { # not replicating from existing DC
                if($InstallFromMedia -eq "true") {
                    Write-DSLog -Level info -Message "[dssoe] Promoting an Additional Domain Controller with Install from Media option, where media path is $MediaPath" -verbose
                    $htDCPromo['/replicaOrNewDomain:'] = 'Replica'
                    $htDCPromo.Add('/ReplicationSourcePath:',$MediaPath)
                }
            }
        }
        # construct DCPromo command out of hash table
        #Comment: 13 Jan; Tarun: Made some changes below to fix the issue with final output of the dcpromooptions
        $DCpromooptions = "/unattend " # blank dcpromo options
        $htDCPromo.GetEnumerator() | ForEach-Object {
            if(!([string]::IsNullOrEmpty($_.Value))) {
                $DCpromooptions = ("{0}{1}{2}{3}" -f $DCpromooptions, $_.Name, $_.Value," ")
            }
        }
        
        # run DCpromo and capture return codes
        $res = Start-DSDomainPromotion -DCPromoParams $DCpromooptions
        if($res -eq $false) {
            Write-DSLog -Level error -Message "[dssoe] DSSOE domain promotion failed" -verbose
            if(-not($ExpressInstall)) {
                #calling function from dsimpletement module
                Reset-DSPrePromotionOptions -DSReserveFile $ReserveFile -ResFilePath $reservefilepath -ResetNetB $resetNetB -ResetSMB $resetSMB -ResetPort $resetport
            } 
            return 'ds_domain_promotion_failed'
            exit
        }
        elseif($res -eq $true) {
            Write-DSLog -Level info -Message "[dssoe] Starting the execution of post promotion configurations" -verbose
            Set-DSPostPromotionTasks -UserName $Username -Password $Password -Domain $NetBIOS -DSInstallMode $installMode -AnswerFile $AnswerFile  -PassKey $PassKey -ExportUnattendBuildFileTo $ExportUnattendBuildFileTo
        }
        else {
            Write-DSLog -Level error -Message "[dssoe] DSSOE domain promotion did not complete. Check the log file for error."
            Exit
        }
     }
    
    #if underlying OS is windows Server 2012 R1 or R2, the below block will execute
    If((Test-OSIsWindowsServer2012 -eq $true) -or (Test-OSIsWindowsServer2012R2 -eq $true)) {
        #create credential object, to be used with -credential ADDS installation cmdlet parameter
        $Pwd = $Password | ConvertTo-SecureString -AsPlainText -Force
        $UserID = "$NetBIOS\$Username"
        $credentials = New-Object System.Management.Automation.PSCredential($UserID, $pwd)

        If($RODC.ToString() -eq "true") { #if server is RODC           
            If($ReplicateDataFromExistingDC -eq "true") { # if replicating data from existing DC                   
                If($ReplicaDC -eq "Automatic") { # if replication from existing DC, automatically
                    Write-DSLog -Level info -Message "[dssoe] Promoting a Read Only Domain controller with replication partner chosen automatically" -verbose
                    #command to install rodc when replicating from existing DC, automatically
                    # 2-feb-16: added .ToString() to $InstallDNS to correctly convert its value as it is a switch param type variable! ~ umesh
                    #calling the update-dsparams function from dsutils.psm1 module, to convert the value of true / false from the XML to $true / $false bool value respectively
                    $addsCommand = "Install-ADDSDomainController -DomainName $DomainFQDN -Credential `$credentials -InstallDNS:$(Update-DSParams -Value $InstallDNS.ToString() -boolvalue) -NoGlobalCatalog:$('$False') -ReadOnlyReplica:$('$true') -SiteName $Sitename -safemodeadministratorpassword (convertto-securestring '$safemodepassword' -asplaintext -force) -databasepath $ADDatabasePath -logpath $ADLogfilePath -sysvolpath $ADSysvolPath -criticalreplicationonly:$(Update-DSParams -Value $CriticalRepOnly.ToString() -boolvalue) -NoRebootOnCompletion:$('$true') -force:$('$true')"
                }
                Else { # replicating from existing DC, as specified by the user in XML
                    Write-DSLog -Level info -Message "[dssoe] Promoting a Read Only Domain controller with $ReplicaDC DC as the replication partner" -verbose
                    #command to install rodc when replicating from existing DC, as specified by the user via XML file
                    #calling the update-dsparams function from dsutils.psm1 module, to convert the value of true / false from the XML to $true / $false bool value respectively
                    $addsCommand = "Install-ADDSDomainController -DomainName $DomainFQDN -Credential `$credentials -InstallDNS:$(Update-DSParams -Value $InstallDNS.ToString() -boolvalue) -NoGlobalCatalog:$('$False') -ReadOnlyReplica:$('$true') -SiteName $Sitename -safemodeadministratorpassword (convertto-securestring '$safemodepassword' -asplaintext -force) -databasepath $ADDatabasePath -logpath $ADLogfilePath -sysvolpath $ADSysvolPath -criticalreplicationonly:$(Update-DSParams -Value $CriticalRepOnly.ToString() -boolvalue) -NoRebootOnCompletion:$('$true') -replicationsourcedc $ReplicaDC -force:$('$true')"
                }
            }
            Else { #if server is not replicating data from existing DC i.e. replicating via install from media option
                if($InstallFromMedia -eq "true") { #if replicating from media
                    Write-DSLog -Level info -Message "[dssoe] Promoting a Read Only Domain controller with Install from Media option, where media path is $MediaPath" -verbose
                    #command to install rodc when replicating from media
                    #calling the update-dsparams function from dsutils.psm1 module, to convert the value of true / false from the XML to $true / $false bool value respectively
                    $addsCommand = "Install-ADDSDomainController -DomainName $DomainFQDN -Credential `$credentials -InstallDNS:$(Update-DSParams -Value $InstallDNS.ToString() -boolvalue) -NoGlobalCatalog:$('$False') -ReadOnlyReplica:$('$true') -SiteName $Sitename -safemodeadministratorpassword (convertto-securestring '$safemodepassword' -asplaintext -force) -databasepath $ADDatabasePath -logpath $ADLogfilePath -sysvolpath $ADSysvolPath -criticalreplicationonly:$(Update-DSParams -Value $CriticalRepOnly.ToString() -boolvalue) -NoRebootOnCompletion:$('$true') -installationmediapath $MediaPath -force:$('$true')"
                }
            }
        }
        Else { # not a readonlyreplica DC but a replica DC
            If($ReplicateDataFromExistingDC -eq "true") { # replicating from existing DC
                If($ReplicaDC -eq "Automatic") { # replica DC type is automatic  
                    Write-DSLog -Level info -Message "[dssoe] Promoting an Additional Domain controller with replication partner chosen automatically" -verbose
                    #calling the update-dsparams function from dsutils.psm1 module, to convert the value of true / false from the XML to $true / $false bool value respectively                        
                    $addsCommand = "Install-ADDSDomainController -DomainName $DomainFQDN -Credential `$credentials -InstallDNS:$(Update-DSParams -Value $Installdns.ToString() -boolvalue) -NoGlobalCatalog:$('$False') -SiteName $Sitename -safemodeadministratorpassword (convertto-securestring '$safemodepassword' -asplaintext -force) -databasepath $ADDatabasePath -logpath $ADLogfilePath -sysvolpath $ADSysvolPath -criticalreplicationonly:$(Update-DSParams -Value $CriticalRepOnly.ToString() -boolvalue) -NoRebootOnCompletion:$('$true') -force:$('$true')"
                }
                Else { #replicating from DC specified in XML file
                    Write-DSLog -Level info -Message "[dssoe] Promoting an Additional Domain Controller with $ReplicaDC DC as the replication partner" -verbose
                    #calling the update-dsparams function from dsutils.psm1 module, to convert the value of true / false from the XML to $true / $false bool value respectively
                    $addsCommand = "Install-ADDSDomainController -DomainName $DomainFQDN -Credential `$credentials -InstallDNS:$(Update-DSParams -Value $InstallDNS.ToString() -boolvalue) -NoGlobalCatalog:$('$False') -SiteName $Sitename -safemodeadministratorpassword (convertto-securestring '$safemodepassword' -asplaintext -force) -databasepath $ADDatabasePath -logpath $ADLogfilePath -sysvolpath $ADSysvolPath -criticalreplicationonly:$(Update-DSParams -Value $CriticalRepOnly.ToString() -boolvalue) -NoRebootOnCompletion:$('$true') -replicationsourcedc $ReplicaDC -force:$('$true')"
                }
            }
            Else { #if server is not replicating data from existing DC i.e. replicating via install from media option
                Write-DSLog -Level info -Message "[dssoe] Promoting an Additional Domain Controller with Install from Media option, where media path is $MediaPath" -verbose
                #calling the update-dsparams function from dsutils.psm1 module, to convert the value of true / false from the XML to $true / $false bool value respectively                      
                $addsCommand = "Install-ADDSDomainController -DomainName $DomainFQDN -Credential `$credentials -InstallDNS:$(Update-DSParams -Value $InstallDNS.ToString() -boolvalue) -NoGlobalCatalog:$('$False') -SiteName $Sitename -safemodeadministratorpassword (convertto-securestring '$safemodepassword' -asplaintext -force) -databasepath $ADDatabasePath -logpath $ADLogfilePath -sysvolpath $ADSysvolPath -criticalreplicationonly:$(Update-DSParams -Value $CriticalRepOnly.ToString() -boolvalue) -NoRebootOnCompletion:$('$true') -installationmediapath $MediaPath -force:$('$true')"
            }
        }  
        
        # run command constructed above for domain promotion
        $res = Start-DSDomainPromotion -ADDSCommand $addsCommand -Credentials $credentials
        if($res -eq $false) {
            Write-DSLog -Level error -Message "[dssoe] DSSOE domain promotion failed" -verbose 
            if(-not($ExpressInstall)) {
                #calling function from dsimpletement module
                $ResetPrePromotion = (Reset-DSPrePromotionOptions -DSReserveFile $ReserveFile -ResFilePath $reservefilepath -ResetNetB $resetNetB -ResetSMB $resetSMB -ResetPort $resetport)
            }
            return 'ds_domain_promotion_failed'
            exit
        }
        elseif($res -eq $true) {
            Write-DSLog -Level info -Message "[dssoe] Starting the execution of post promotion configurations" -verbose
            Set-DSPostPromotionTasks -UserName $Username -Password $Password -Domain $NetBIOS -DSInstallMode $installMode -AnswerFile $AnswerFile  -PassKey $PassKey -ExportUnattendBuildFileTo $ExportUnattendBuildFileTo
        }
        else {
            Write-DSLog -Level error -Message "[dssoe] DSSOE domain promotion did not complete. Check the log file for error."
            Exit
        }
    }

    #if underlying OS is Windows Server 2016, the below block will execute
    If(Test-OSIsWindowsServer2016 -eq $true) {
        #create credential object, to be used with -credential ADDS installation cmdlet parameter
        $Pwd = $Password | ConvertTo-SecureString -AsPlainText -Force
        $UserID = "$NetBIOS\$Username"
        $credentials = New-Object System.Management.Automation.PSCredential($UserID, $pwd)

        #added by Tarun on 19th Jul 2016; to use the $globalcatalog variable in W2K16 ADDS build command.
        #$False for NoGlobalCatalog parameter will result in configuration of global catalog and $true is inversely proportional.
        If($xmldata.DSSOE.DCPromoOptions.AdditionalDC.GlobalCatalog -eq "true") {
            $GlobalCatalog = $False
        }
        Else {
            $GlobalCatalog = $true
        }

        If($RODC.ToString() -eq "true") { #if server is RODC           
            If($ReplicateDataFromExistingDC -eq "true") { # if replicating data from existing DC                   
                If($ReplicaDC -eq "Automatic") { # if replication from existing DC, automatically
                    Write-DSLog -Level info -Message "[dssoe] Promoting a Read Only Domain controller with replication partner chosen automatically" -verbose
                    #command to install rodc when replicating from existing DC, automatically
                    # 2-feb-16: added .ToString() to $InstallDNS to correctly convert its value as it is a switch param type variable! ~ umesh
                    #calling the update-dsparams function from dsutils.psm1 module, to convert the value of true / false from the XML to $true / $false bool value respectively
                    $addsCommand = "Install-ADDSDomainController -DomainName $DomainFQDN -Credential `$credentials -InstallDNS:$(Update-DSParams -Value $InstallDNS.ToString() -boolvalue) -NoGlobalCatalog:$(Update-DSParams -Value $GlobalCatalog.ToString() -boolvalue) -ReadOnlyReplica:$('$true') -SiteName $Sitename -safemodeadministratorpassword (convertto-securestring '$safemodepassword' -asplaintext -force) -databasepath $ADDatabasePath -logpath $ADLogfilePath -sysvolpath $ADSysvolPath -criticalreplicationonly:$(Update-DSParams -Value $CriticalRepOnly.ToString() -boolvalue) -NoRebootOnCompletion:$('$true') -force:$('$true')"
                }
                Else { # replicating from existing DC, as specified by the user in XML
                    Write-DSLog -Level info -Message "[dssoe] Promoting a Read Only Domain controller with $ReplicaDC DC as the replication partner" -verbose
                    #command to install rodc when replicating from existing DC, as specified by the user via XML file
                    #calling the update-dsparams function from dsutils.psm1 module, to convert the value of true / false from the XML to $true / $false bool value respectively
                    #$addsCommand = "Install-ADDSDomainController -DomainName $DomainFQDN -Credential `$credentials -InstallDNS:$(Update-DSParams -Value $InstallDNS.ToString() -boolvalue) -NoGlobalCatalog:$('$False') -ReadOnlyReplica:$('$true') -SiteName $Sitename -safemodeadministratorpassword (convertto-securestring '$safemodepassword' -asplaintext -force) -databasepath $ADDatabasePath -logpath $ADLogfilePath -sysvolpath $ADSysvolPath -criticalreplicationonly:$(Update-DSParams -Value $CriticalRepOnly.ToString() -boolvalue) -NoRebootOnCompletion:$('$true') -replicationsourcedc $ReplicaDC -force:$('$true')"
                    $addsCommand = "Install-ADDSDomainController -DomainName $DomainFQDN -Credential `$credentials -InstallDNS:$(Update-DSParams -Value $InstallDNS.ToString() -boolvalue) -NoGlobalCatalog:$(Update-DSParams -Value $GlobalCatalog.ToString() -boolvalue) -ReadOnlyReplica:$('$true') -SiteName $Sitename -safemodeadministratorpassword (convertto-securestring '$safemodepassword' -asplaintext -force) -databasepath $ADDatabasePath -logpath $ADLogfilePath -sysvolpath $ADSysvolPath -criticalreplicationonly:$(Update-DSParams -Value $CriticalRepOnly.ToString() -boolvalue) -NoRebootOnCompletion:$('$true') -replicationsourcedc $ReplicaDC -force:$('$true')"
                }
            }
            Else { #if server is not replicating data from existing DC i.e. replicating via install from media option
                if($InstallFromMedia -eq "true") { #if replicating from media
                    Write-DSLog -Level info -Message "[dssoe] Promoting a Read Only Domain controller with Install from Media option, where media path is $MediaPath" -verbose
                    #command to install rodc when replicating from media
                    #calling the update-dsparams function from dsutils.psm1 module, to convert the value of true / false from the XML to $true / $false bool value respectively
                    $addsCommand = "Install-ADDSDomainController -DomainName $DomainFQDN -Credential `$credentials -InstallDNS:$(Update-DSParams -Value $InstallDNS.ToString() -boolvalue) -NoGlobalCatalog:$(Update-DSParams -Value $GlobalCatalog.ToString() -boolvalue) -ReadOnlyReplica:$('$true') -SiteName $Sitename -safemodeadministratorpassword (convertto-securestring '$safemodepassword' -asplaintext -force) -databasepath $ADDatabasePath -logpath $ADLogfilePath -sysvolpath $ADSysvolPath -criticalreplicationonly:$(Update-DSParams -Value $CriticalRepOnly.ToString() -boolvalue) -NoRebootOnCompletion:$('$true') -installationmediapath $MediaPath -force:$('$true')"
                }
            }
        }
        Else { # not a readonlyreplica DC but a replica DC
            If($ReplicateDataFromExistingDC -eq "true") { # replicating from existing DC
                If($ReplicaDC -eq "Automatic") { # replica DC type is automatic  
                    Write-DSLog -Level info -Message "[dssoe] Promoting an Additional Domain controller with replication partner chosen automatically" -verbose
                    #calling the update-dsparams function from dsutils.psm1 module, to convert the value of true / false from the XML to $true / $false bool value respectively                        
                    $addsCommand = "Install-ADDSDomainController -DomainName $DomainFQDN -Credential `$credentials -InstallDNS:$(Update-DSParams -Value $Installdns.ToString() -boolvalue) -NoGlobalCatalog:$(Update-DSParams -Value $GlobalCatalog.ToString() -boolvalue) -SiteName $Sitename -safemodeadministratorpassword (convertto-securestring '$safemodepassword' -asplaintext -force) -databasepath $ADDatabasePath -logpath $ADLogfilePath -sysvolpath $ADSysvolPath -criticalreplicationonly:$(Update-DSParams -Value $CriticalRepOnly.ToString() -boolvalue) -NoRebootOnCompletion:$('$true') -force:$('$true')"
                }
                Else { #replicating from DC specified in XML file
                    Write-DSLog -Level info -Message "[dssoe] Promoting an Additional Domain Controller with $ReplicaDC DC as the replication partner" -verbose
                    #calling the update-dsparams function from dsutils.psm1 module, to convert the value of true / false from the XML to $true / $false bool value respectively
                    $addsCommand = "Install-ADDSDomainController -DomainName $DomainFQDN -Credential `$credentials -InstallDNS:$(Update-DSParams -Value $InstallDNS.ToString() -boolvalue) -NoGlobalCatalog:$(Update-DSParams -Value $GlobalCatalog.ToString() -boolvalue) -SiteName $Sitename -safemodeadministratorpassword (convertto-securestring '$safemodepassword' -asplaintext -force) -databasepath $ADDatabasePath -logpath $ADLogfilePath -sysvolpath $ADSysvolPath -criticalreplicationonly:$(Update-DSParams -Value $CriticalRepOnly.ToString() -boolvalue) -NoRebootOnCompletion:$('$true') -replicationsourcedc $ReplicaDC -force:$('$true')"
                }
            }
            Else { #if server is not replicating data from existing DC i.e. replicating via install from media option
                Write-DSLog -Level info -Message "[dssoe] Promoting an Additional Domain Controller with Install from Media option, where media path is $MediaPath" -verbose
                #calling the update-dsparams function from dsutils.psm1 module, to convert the value of true / false from the XML to $true / $false bool value respectively                      
                $addsCommand = "Install-ADDSDomainController -DomainName $DomainFQDN -Credential `$credentials -InstallDNS:$(Update-DSParams -Value $InstallDNS.ToString() -boolvalue) -NoGlobalCatalog:$(Update-DSParams -Value $GlobalCatalog.ToString() -boolvalue) -SiteName $Sitename -safemodeadministratorpassword (convertto-securestring '$safemodepassword' -asplaintext -force) -databasepath $ADDatabasePath -logpath $ADLogfilePath -sysvolpath $ADSysvolPath -criticalreplicationonly:$(Update-DSParams -Value $CriticalRepOnly.ToString() -boolvalue) -NoRebootOnCompletion:$('$true') -installationmediapath $MediaPath -force:$('$true')"
            }
        }  
        
        # run command constructed above for domain promotion
        $res = Start-DSDomainPromotion -W2K16ADDSCommand $addsCommand -Credentials $credentials
        if($res -eq $false) {
            Write-DSLog -Level error -Message "[dssoe] DSSOE domain promotion failed" -verbose 
            if(-not($ExpressInstall)) {
                #calling function from dsimpletement module
                $ResetPrePromotion = (Reset-DSPrePromotionOptions -DSReserveFile $ReserveFile -ResFilePath $reservefilepath -ResetNetB $resetNetB -ResetSMB $resetSMB -ResetPort $resetport)
            }
            return 'ds_domain_promotion_failed'
            exit
        }
        elseif($res -eq $true) {
            Write-DSLog -Level info -Message "[dssoe] Starting the execution of post promotion configurations" -verbose
            Set-DSPostPromotionTasks -UserName $Username -Password $Password -Domain $NetBIOS -DSInstallMode $installMode -AnswerFile $AnswerFile  -PassKey $PassKey -ExportUnattendBuildFileTo $ExportUnattendBuildFileTo
        }
        else {
            Write-DSLog -Level error -Message "[dssoe] DSSOE domain promotion did not complete. Check the log file for error."
            Exit
        }
    }
}
#endregion Constructing the DSSOE unattended command for AdditionalDC Installation

#region Constructing the DSSOE unattended command for NewChildDomain Installaion

If($xmldata.DSSOE.DCPromoOptions.Selected -eq "NewChildDomain") { #if build type is NewChildDomain then run this code block
    #saving XML values in variables
    $Username = $xmldata.DSSOE.DCPromoOptions.NewChildDomain.UserName
    $Password = $xmldata.DSSOE.DCPromoOptions.NewChildDomain.Password
    $DomainFQDN = $xmldata.DSSOE.DCPromoOptions.NewChildDomain.Domain
    $ParentDomain = $xmldata.DSSOE.DCPromoOptions.NewChildDomain.ParentDomain
    $ChildDomain = $xmldata.DSSOE.DCPromoOptions.NewChildDomain.ChildDomainName
    $NewChildFQDN = "$ChildDomain.$ParentDomain"
    $ChildNetBIOS = $xmldata.DSSOE.DCPromoOptions.NewChildDomain.ChildDomainNameNetBIOS
    $safemodepassword = $xmldata.DSSOE.DCPromoOptions.NewChildDomain.SafeModeAdminPassword
    $DomainMode = $xmldata.DSSOE.DCPromoOptions.NewChildDomain.DomainFunctionalLevel
    # added condition by Umesh, as it was causing errors on string to bool conversion
    $Installdns = ($xmldata.DSSOE.DCPromoOptions.NewChildDomain.InstallDNS -eq "true")
    $Globalcatalog = ($xmldata.DSSOE.DCPromoOptions.NewChildDomain.GlobalCatalog -eq "true")
    $Sitename = $xmldata.DSSOE.DCPromoOptions.NewChildDomain.ADSiteName
    $UserDomainNetBIOS = $DomainFQDN.Split('.')[0]
    
    If(Test-OSIsWindowsServer2008R2 -eq $true) {
        #declaring variables and passing values in the preparation to construct the Dcpromo command
        # for NewchildDomain when the underlying OS is W2K8R2
        #converting domainmode passed via XML file to numeric value
        $domainmode = Get-DSDomainModeNumberW2k8R2 -DomainModeString $domainmode

        Write-DSLog -Level info -Message "[dssoe] Promoting the first Domain Controller in the child domain: $NewChildFQDN" -verbose
        # construct DCPromo command for newchildomain
        #calling the update-dsparams function from dsutils.psm1 module, to convert the value of true / false from the XML to Yes / No  respectively
        $DCpromooptions = "/unattend /UserDomain:$DomainFQDN /UserName:$Username /Password:$Password /InstallDns:$(Update-DSParams -Value $InstallDNS.ToString() -textvalue) /ParentDomainDNSName:$ParentDomain /replicaOrNewDomain:domain /newDomain:child /newDomainDnsName:$NewChildFQDN /childName:$ChildDomain /DomainNetbiosName:$ChildNetBIOS /databasePath:$ADDatabasePath /logPath:$ADLogfilePath /sysvolpath:$ADSysvolPath /safeModeAdminPassword:$safemodepassword /domainLevel:$domainmode /ConfirmGc:$(Update-DSParams -Value $GlobalCatalog.ToString() -textvalue) /rebootOnCompletion:No /SiteName:$Sitename"

        # run DCpromo and capture return codes
        $res = Start-DSDomainPromotion -DCPromoParams $DCpromooptions
        if($res -eq $false) {
            Write-DSLog -Level error -Message "[dssoe] DSSOE domain promotion failed" -verbose
            if(-not($ExpressInstall)) {
                #calling function from dsimplement module
                Reset-DSPrePromotionOptions -DSReserveFile $ReserveFile -ResFilePath $reservefilepath -ResetNetB $resetNetB -ResetSMB $resetSMB -ResetPort $resetport
            } 
            return 'ds_domain_promotion_failed'
            exit
        }
        elseif($res -eq $true) {
            Write-DSLog -Level info -Message "[dssoe] Starting the execution of post promotion configurations" -verbose
            Set-DSPostPromotionTasks -UserName $Username -Password $Password -Domain $DomainFQDN -DSInstallMode $installMode -AnswerFile $AnswerFile  -PassKey $PassKey -ExportUnattendBuildFileTo $ExportUnattendBuildFileTo
        }
        else {
            Write-DSLog -Level error -Message "[dssoe] DSSOE domain promotion did not complete. Check the log file for error."
            Exit
        }
    }
    #declaring variables and passing values in the preparation to construct the Dcpromo command
    # for NewChildDomain when the underlying OS is W2K12 R1 or R2
    If((Test-OSIsWindowsServer2012 -eq $true) -or (Test-OSIsWindowsServer2012R2 -eq $true)) {
        #converting domainmode passed via XML file to a value understand by 2012 dcpromo cmmand
        $domainmode = Get-DSDomainModeNumberW2k12 -DomainModeString $domainmode
        #create credential object, to be used with -credential ADDS installation cmdlet parameter
        $Pwd = $Password | ConvertTo-SecureString -AsPlainText -Force
        $UserID = "$UserDomainNetBIOS\$Username"    
        #Write-DSLog -Level info -Message "[dssoe] Username for the creation of first child domain controller is : $UserID"    
        $credentials = New-Object System.Management.Automation.PSCredential($UserID, $Pwd)

        #AD DS installation cmdlets have been used to utilize the pre-check and other stuff 
        #not provided by dcpromo / unattend command 
        Write-DSLog -Level info -Message "[dssoe] Promoting the first Domain Controller in the child domain: $NewChildFQDN" -verbose
        #calling the update-dsparams function from dsutils.psm1 module, to convert the value of true / false from the XML to $true / $false bool value respectively
        $addsCommand = "Install-ADDSDomain -NoGlobalCatalog:$('$false') -credential `$credentials -databasepath $ADDatabasePath -DomainMode $domainmode -DomainType 'ChildDomain' -InstallDNS:$(Update-DSParams -Value $InstallDNS.ToString() -boolvalue) -logpath $ADLogfilePath -newdomainname $ChildDomain -newdomainnetbiosname $ChildNetBIOS -parentdomainname $ParentDomain -NoRebootOnCompletion:$('$true') -Sitename $Sitename -sysvolpath $ADSysvolPath -SafeModeAdministratorPassword (convertto-securestring '$safemodepassword' -asplaintext -force) -Force:$('$true')"
        
        # run command constructed above for domain promotion
        $res = Start-DSDomainPromotion -ADDSCommand $addsCommand -Credentials $credentials
        if($res -eq $false) {
            Write-DSLog -Level error -Message "[dssoe] DSSOE domain promotion failed" -verbose
            if(-not($ExpressInstall)) {
                #calling function from dsimplement module
                Reset-DSPrePromotionOptions -DSReserveFile $ReserveFile -ResFilePath $reservefilepath -ResetNetB $resetNetB -ResetSMB $resetSMB -ResetPort $resetport
            } 
            return 'ds_domain_promotion_failed'
            exit
        }
        elseif($res -eq $true) {
            Write-DSLog -Level info -Message "[dssoe] Starting the execution of post promotion configurations" -verbose
            Set-DSPostPromotionTasks -UserName $Username -Password $Password -Domain $DomainFQDN -DSInstallMode $installMode -AnswerFile $AnswerFile  -PassKey $PassKey -ExportUnattendBuildFileTo $ExportUnattendBuildFileTo
        }
        else {
            Write-DSLog -Level error -Message "[dssoe] DSSOE domain promotion did not complete. Check the log file for error."
            exit
        }  
    }

    # for NewChildDomain when the underlying OS is W2K16
    If(Test-OSIsWindowsServer2016 -eq $true) {
        #converting domainmode passed via XML file to a value understand by 2012 dcpromo cmmand
        $domainmode = Get-DSDomainModeNumberW2k16 -DomainModeString $domainmode
        #create credential object, to be used with -credential ADDS installation cmdlet parameter
        $Pwd = $Password | ConvertTo-SecureString -AsPlainText -Force
        $UserID = "$UserDomainNetBIOS\$Username"    
        #Write-DSLog -Level info -Message "[dssoe] Username for the creation of first child domain controller is : $UserID"    
        $credentials = New-Object System.Management.Automation.PSCredential($UserID, $Pwd)

        #added by Tarun on 19th Jul 2016; to use the $globalcatalog variable in W2K16 ADDS build command.
        #$False for NoGlobalCatalog parameter will result in configuration of global catalog and $true is inversely proportional.
        If($xmldata.DSSOE.DCPromoOptions.NewChildDomain.GlobalCatalog -eq "true") {
            $GlobalCatalog = $False
        }
        Else {
            $GlobalCatalog = $true
        }

        #AD DS installation cmdlets have been used to utilize the pre-check and other stuff 
        #not provided by dcpromo / unattend command 
        Write-DSLog -Level info -Message "[dssoe] Promoting the first Domain Controller in the child domain: $NewChildFQDN" -verbose
        #calling the update-dsparams function from dsutils.psm1 module, to convert the value of true / false from the XML to $true / $false bool value respectively
        $addsCommand = "Install-ADDSDomain -NoGlobalCatalog:$(Update-DSParams -Value $GlobalCatalog.ToString() -boolvalue) -credential `$credentials -databasepath $ADDatabasePath -DomainMode $domainmode -DomainType 'ChildDomain' -InstallDNS:$(Update-DSParams -Value $InstallDNS.ToString() -boolvalue) -logpath $ADLogfilePath -newdomainname $ChildDomain -newdomainnetbiosname $ChildNetBIOS -parentdomainname $ParentDomain -NoRebootOnCompletion:$('$true') -Sitename $Sitename -sysvolpath $ADSysvolPath -SafeModeAdministratorPassword (convertto-securestring '$safemodepassword' -asplaintext -force) -Force:$('$true')"
        
        # run command constructed above for domain promotion
        $res = Start-DSDomainPromotion -W2K16ADDSCommand $addsCommand -Credentials $credentials
        if($res -eq $false) {
            Write-DSLog -Level error -Message "[dssoe] DSSOE domain promotion failed" -verbose
            if(-not($ExpressInstall)) {
                #calling function from dsimplement module
                Reset-DSPrePromotionOptions -DSReserveFile $ReserveFile -ResFilePath $reservefilepath -ResetNetB $resetNetB -ResetSMB $resetSMB -ResetPort $resetport
            } 
            return 'ds_domain_promotion_failed'
            exit
        }
        elseif($res -eq $true) {
            Write-DSLog -Level info -Message "[dssoe] Starting the execution of post promotion configurations" -verbose
            Set-DSPostPromotionTasks -UserName $Username -Password $Password -Domain $DomainFQDN -DSInstallMode $installMode -AnswerFile $AnswerFile  -PassKey $PassKey -ExportUnattendBuildFileTo $ExportUnattendBuildFileTo
        }
        else {
            Write-DSLog -Level error -Message "[dssoe] DSSOE domain promotion did not complete. Check the log file for error."
            exit
        }  
    }
}
#endregion Constructing the DSSOE unattended command for NewChildDomain Installaion

#region Constructing the DSSOE unattended command for NewTreeDomain Installaion

If($xmldata.DSSOE.DCPromoOptions.Selected -eq "NewTreeDomain") {#if build type is NEwTreeDomain then run this code block
    #saving XML values in variables
    $Username = $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.UserName
    $Password = $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.Password
    $DomainFQDN = $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.Domain
    $ForestRootDomain = $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.ForestRootDomain
    $TreeDomainFQDN = $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.TreeDomainName
    $TreeNetBIOS = $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.TreeDomainNameNetbios
    $safemodepassword = $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.SafeModeAdminPassword
    $DomainMode = $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.DomainFunctionalLevel
    # added condition by Umesh, as it was causing errors on string to bool conversion
    $Installdns = ($xmldata.DSSOE.DCPromoOptions.NewTreeDomain.InstallDNS -eq "true")
    $Globalcatalog = ($xmldata.DSSOE.DCPromoOptions.NewTreeDomain.GlobalCatalog  -eq "true")
    $Sitename = $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.ADSiteName
    $UserDomainNetBIOS = $DomainFQDN.Split('.')[0]
    
    If(Test-OSIsWindowsServer2008R2 -eq $true)
    {
        #declaring variables and passing values in the preparation to construct the Dcpromo command
        # for NewTreeDomain when the underlying OS is W2K8R2
        #converting domainmode passed via XML file to numeric value
        $domainmode = Get-DSDomainModeNumberW2k8R2 -DomainModeString $domainmode
        Write-DSLog -Level info -Message "[dssoe] Promoting the first Domain Controller in the tree domain: $TreeDomainFQDN" -verbose
        # construct DCPromo command for newtreedomain
        #calling the update-dsparams function from dsutils.psm1 module, to convert the value of true / false from the XML to Yes / No  respectively
        $DCpromooptions = "/unattend /UserDomain:$DomainFQDN /UserName:$Username /Password:$Password /InstallDns:$(Update-DSParams -Value $InstallDNS.ToString() -textvalue) /ParentDomainDNSName:$ForestRootDomain /replicaOrNewDomain:domain /newDomain:tree /newDomainDnsName:$TreeDomainFQDN /DomainNetbiosName:$TreeNetBIOS /databasePath:$ADDatabasePath /logPath:$ADLogfilePath /sysvolpath:$ADSysvolPath /safeModeAdminPassword:$safemodepassword /domainLevel:$domainmode /rebootOnCompletion:No /ConfirmGc:$(Update-DSParams -Value $GlobalCatalog.ToString() -textvalue) /SiteName:$Sitename"

        # run DCpromo and capture return codes
        $res = Start-DSDomainPromotion -DCPromoParams $DCpromooptions
        if($res -eq $false) {
            Write-DSLog -Level error -Message "[dssoe] DSSOE domain promotion failed" -verbose
            if(-not($ExpressInstall)) {
                #calling function from dsimplement module
                Reset-DSPrePromotionOptions -DSReserveFile $ReserveFile -ResFilePath $reservefilepath -ResetNetB $resetNetB -ResetSMB $resetSMB -ResetPort $resetport
            } 
            return 'ds_domain_promotion_failed'
            exit
        }
        elseif($res -eq $true) {
            Write-DSLog -Level info -Message "[dssoe] Starting the execution of post promotion configurations" -verbose
            Set-DSPostPromotionTasks -UserName $Username -Password $Password -Domain $DomainFQDN -DSInstallMode $installMode -AnswerFile $AnswerFile -PassKey $PassKey -ExportUnattendBuildFileTo $ExportUnattendBuildFileTo
        }
        else {
            Write-DSLog -Level error -Message "[dssoe] DSSOE domain promotion did not complete. Check the log file for error."
            exit
        }
    }
    #declaring variables and passing values in the preparation to construct the Dcpromo command
    # for NewTreeDomain when the underlying OS is W2K12 R1 or R2
    If((Test-OSIsWindowsServer2012 -eq $true) -or (Test-OSIsWindowsServer2012R2 -eq $true))
    {
        #converting domainmode passed via XML file to a value understand by 2012 dcpromo cmmand
        $domainmode = Get-DSDomainModeNumberW2k12 -DomainModeString $domainmode
        $UserID = "$UserDomainNetBIOS\$Username"
        #create credential object, to be used with -credential ADDS installation cmdlet parameter
        $Pwd = $Password | ConvertTo-SecureString -AsPlainText -Force
        $credentials = New-Object System.Management.Automation.PSCredential($UserID, $pwd)

        Write-DSLog -Level info -Message "[dssoe] Promoting the first Domain Controller in the tree domain: $TreeDomainFQDN" -verbose
        #AD DS installation cmdlets have been used to utilize the pre-check and other stuff 
        #not provided by dcpromo / unattend command 
        #calling the update-dsparams function from dsutils.psm1 module, to convert the value of true / false from the XML to $true / $false bool value respectively
        $addsCommand = "Install-ADDSDomain -DomainType 'TreeDomain' -parentdomainname $ForestRootDomain -newdomainname $TreeDomainFQDN -credential `$credentials -InstallDNS:$(Update-DSParams -Value $InstallDNS.ToString() -boolvalue) -NoGlobalCatalog:$('$false') -DomainMode $domainmode -Sitename $Sitename -SafeModeAdministratorPassword (convertto-securestring '$safemodepassword' -asplaintext -force) -newdomainnetbiosname $TreeNetBIOS -databasepath $ADDatabasePath -logpath $ADLogfilePath -sysvolpath $ADSysvolPath -NoRebootOnCompletion:$('$true') -Force:$('$true')"
        
        # run command constructed above for domain promotion
        $res = Start-DSDomainPromotion -ADDSCommand $addsCommand -Credentials $credentials
        if($res -eq $false) {
            Write-DSLog -Level error -Message "[dssoe] DSSOE domain promotion failed" -verbose
            if(-not($ExpressInstall)) {
                #calling function from dsimplement module
                Reset-DSPrePromotionOptions -DSReserveFile $ReserveFile -ResFilePath $reservefilepath -ResetNetB $resetNetB -ResetSMB $resetSMB -ResetPort $resetport
            } 
            return 'ds_domain_promotion_failed'
            exit
        }
        elseif($res -eq $true) {
            Write-DSLog -Level info -Message "[dssoe] Starting the execution of post promotion configurations" -verbose
            Set-DSPostPromotionTasks -UserName $Username -Password $Password -Domain $DomainFQDN -DSInstallMode $installMode -AnswerFile $AnswerFile -PassKey $PassKey -ExportUnattendBuildFileTo $ExportUnattendBuildFileTo
        }
        else {
            Write-DSLog -Level error -Message "[dssoe] DSSOE domain promotion did not complete. Check the log file for error."
            exit
        }
    }
    
        # for NewTreeDomain when the underlying OS is W2K12 R1 or R2
    If(Test-OSIsWindowsServer2016 -eq $true)
    {
        #converting domainmode passed via XML file to a value understand by 2012 dcpromo cmmand
        $domainmode = Get-DSDomainModeNumberW2k16 -DomainModeString $domainmode
        $UserID = "$UserDomainNetBIOS\$Username"
        #create credential object, to be used with -credential ADDS installation cmdlet parameter
        $Pwd = $Password | ConvertTo-SecureString -AsPlainText -Force
        $credentials = New-Object System.Management.Automation.PSCredential($UserID, $pwd)

        #added by Tarun on 19th Jul 2016; to use the $globalcatalog variable in W2K16 ADDS build command.
        #$False for NoGlobalCatalog parameter will result in configuration of global catalog and $true is inversely proportional.
        If($xmldata.DSSOE.DCPromoOptions.NewTreeDomain.GlobalCatalog -eq "true") {
            $Globalcatalog = $False
        }
        Else {
            $Globalcatalog = $true
        }

        Write-DSLog -Level info -Message "[dssoe] Promoting the first Domain Controller in the tree domain: $TreeDomainFQDN" -verbose
        #AD DS installation cmdlets have been used to utilize the pre-check and other stuff 
        #not provided by dcpromo / unattend command 
        #calling the update-dsparams function from dsutils.psm1 module, to convert the value of true / false from the XML to $true / $false bool value respectively
        $addsCommand = "Install-ADDSDomain -DomainType 'TreeDomain' -parentdomainname $ForestRootDomain -newdomainname $TreeDomainFQDN -credential `$credentials -InstallDNS:$(Update-DSParams -Value $InstallDNS.ToString() -boolvalue) -NoGlobalCatalog:$(Update-DSParams -Value $GlobalCatalog.ToString() -boolvalue) -DomainMode $domainmode -Sitename $Sitename -SafeModeAdministratorPassword (convertto-securestring '$safemodepassword' -asplaintext -force) -newdomainnetbiosname $TreeNetBIOS -databasepath $ADDatabasePath -logpath $ADLogfilePath -sysvolpath $ADSysvolPath -NoRebootOnCompletion:$('$true') -Force:$('$true')"
        
        # run command constructed above for domain promotion
        $res = Start-DSDomainPromotion -W2K16ADDSCommand $addsCommand -Credentials $credentials
        if($res -eq $false) {
            Write-DSLog -Level error -Message "[dssoe] DSSOE domain promotion failed" -verbose
            if(-not($ExpressInstall)) {
                #calling function from dsimplement module
                Reset-DSPrePromotionOptions -DSReserveFile $ReserveFile -ResFilePath $reservefilepath -ResetNetB $resetNetB -ResetSMB $resetSMB -ResetPort $resetport
            } 
            return 'ds_domain_promotion_failed'
            exit
        }
        elseif($res -eq $true) {
            Write-DSLog -Level info -Message "[dssoe] Starting the execution of post promotion configurations" -verbose
            Set-DSPostPromotionTasks -UserName $Username -Password $Password -Domain $DomainFQDN -DSInstallMode $installMode -AnswerFile $AnswerFile -PassKey $PassKey -ExportUnattendBuildFileTo $ExportUnattendBuildFileTo
        }
        else {
            Write-DSLog -Level error -Message "[dssoe] DSSOE domain promotion did not complete. Check the log file for error."
            exit
        }
    }    
}
#endregion Constructing the DSSOE unattended command for NewTreeDomain Installaion




