﻿# This script module contains functions related to logging in the tool.
# Author: Umesh Thakur
# Date  : 22-june-2015
# Originally copied from NextGen WinCompliance and updated for any DS related requirements
# Copyright  : @Platform Wintel SOE
[CmdletBinding()]
Param()

# set verbose/debug preferences of the script that loads this module
if((Get-Module).Name -contains 'LogCallerPref') { # works in PS3.0 and above
    $verbosePref = Get-CallerVerbosePreference # set it for module
    $DebugPref = Get-CallerDebugPreference # set it for module
}
else { 
    Write-Warning "You must import LogCallerPref module before importing this module"
    exit
}

#region ModuleVariables
# this is default log file name auto-created to write log entries to, in case user didn't set log name
# it is responsibility of the ps1 script that loads  this module to set the log file if they want.
[string] $DSLogFile = "$($env:temp)\dssoe-$((Get-Date).ToString('MMddyyyy-hhmmss')).log"
[string] $LogLevel = "debug" # 'info', 'debug' are two options available
$IndentChars = 2 # number of characters to indent
$IndentLevel = 0 # indicate current indent level, it increases in multiples of $IndentChars
#endregion ModuleVariables

#region LogFileNameFunctions
function Get-IndentChars { return $script:IndentChars }
function Set-IndentChars($IndentBy) { $script:IndentChars = $IndentBy}
function Add-Indent($Header) { 
    if($Header) { Write-DSLog -Message "$Header"  }
    $Script:IndentLevel = $script:IndentLevel + 1 
}
function Remove-Indent($Footer) { 
    if($script:IndentLevel -gt 0) { $Script:IndentLevel = $script:IndentLevel - 1 } 
    if($Footer) { Write-DSLog -Message "$Footer"  }
}
function Reset-Indent { $Script:IndentLevel = 0 }
function Get-Indent { return  ($Script:IndentLevel * $script:IndentChars) } # numm chars to indent when writing log
function Get-IndentSpace { return (' ' * (Get-Indent)) }

function Get-DSLogFile { return $script:DSLogFile }
function Set-DSLogFile([string]$LogPath) { $script:DSLogFile = $LogPath }
#endregion LogFileNameFunctions

#region LogLevelFunctions
function Get-DSLogLevel { return $script:LogLevel }

function Set-DSLogLevel {
[CmdletBinding()]
param([string][ValidateSet('info', 'debug')]$LogLevel) 
    $script:LogLevel = $LogLevel 
}
#endregion LogLevelFunctions

#region LoggingFunctions

Function Test-IsLogLevelPermitted {
[CmdletBinding()]
param([string] [ValidateSet('warning', 'error', 'info', 'debug', 'none')]$MessageLogLevel)
    switch($script:LogLevel) {
        'info' { return ($MessageLogLevel -ne 'debug') }
        'debug' { return $true }
    }
}

# This function will write a log message in given log file. 
# Intended to be used with different log file
# -----------------------------------------------------------
Function Write-DSLog {
[CmdletBinding()]
param(
    [string]$LogFile = $Script:DSLogFile,   #if user didn't provide then default to what is set in the module
    [string][ValidateSet('warning', 'error', 'info', 'debug', 'none')] $Level = 'none',
    [string] $LogSource = "", # typically function name of the caller or blank
    $Message,
    [switch] $WriteErrorOnScreen
)
    # based on logLevel set on script level (this module level); and logLevel passed with this function
    # determine if current log entry will go into log file. If it goes then write log, else skip it
    if(Test-IsLogLevelPermitted -MessageLogLevel $Level) { 
        # in date formatting, mm is minutes, MM is month!
        $formattedDateTime = "[" + (Get-Date).ToString("MMddyyhhmmss") + "] "

        if($LogSource) { $LogSource = "[$LogSource]" } # surround logSource with []

        # Construct message to log in the given log file
        if($Level -eq 'none') { 
            $Message = $formattedDateTime + (Get-IndentSpace) + $LogSource + $Message # updated message with date/log-level info
        }
        else {
            $Message = $formattedDateTime + (Get-IndentSpace) + $LogSource +  "[$Level] " + $Message # updated message with date/log-level info
        }
        
        # now write the log line into file
        try { 
            
            #Out-File -FilePath $LogFile -Encoding ascii -Append -InputObject $Message -Force -ErrorAction Stop
            [System.IO.File]::AppendAllText($LogFile,$Message + "`r`n") # use .net method for faster performance
            
            # if user has called main script (who loads this module) with -verbose then below line will output message
            if($verbosePref -eq 'Continue') { Write-Verbose -Message $Message -Verbose:($verbosePref -eq 'Continue') }
            # if user has specified verbose param with this function, write verbose message on the screen
            if($VerbosePreference -eq 'Continue') { Write-Verbose -Message $Message -Verbose }

            # if user has mentioned to write it as error on screen, then write it
            if($Level -eq 'error' -and $WriteErrorOnScreen) {
                Write-Error -Message $Message
            }
        }
        catch {
            Write-Warning "[warning] Unable to write to given log file $LogFile"
            Write-Warning ($_.Exception.Message)
        }
    }
}

# this is experimental function.. shouldn't be there in final module
Function Get-CallerName($scope) {
    # get caller function or script's name, for logging purposes
    $myCaller = (Get-Variable MyInvocation -Scope $scope).Value.MyCommand.Name
    if($myCaller) { $myCaller = "[$myCaller] " } else { $myCaller = "[Unknown] " }
    return $myCaller
}
#endregion LoggingFunctions
