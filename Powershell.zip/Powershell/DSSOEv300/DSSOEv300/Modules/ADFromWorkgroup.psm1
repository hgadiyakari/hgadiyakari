﻿# This module will define functions related to Active Directory. It will include functions
# for most basic to advanced AD related information
# Author: Umesh Thakur

# Note: You must always call Get-DSADForest first after loading this module. This function will
#       set object for query by other module functions. Not doing so will return null for most
#       of the function calls. 
# Note: All Names in function arguments or returned are FQDN unless otherwise mentioned in context
# Copyright  : @Platform Wintel SOE, DXC. 
# ----------------------------------------------------------------------------------------------
#region module level functions
$script:mvForest = ""
$script:modesText = @"
DomainMode,ForestMode,ModeNumber,ModeShortName,ModeDisplayName
Windows2008Domain,Windows2008Forest,3,Win2008,Windows Server 2008
Windows2008R2Domain,Windows2008R2Forest,4,Win2008R2,Windows Server 2008 R2
Windows8Domain,Windows8Forest,5,Win2012,Windows Server 2012
Windows2012R2Domain,Windows2012R2Forest,6,Win2012R2,Windows Server 2012 R2
Windows2016Domain,Windows2016Forest,7,WinThreshold,Windows Server 2016
"@
#Dated: 24 Jan, 2017
#The AD namespace is not updated as off above mentioned date and is returning the forestmode value as 'Unknown' for W2K16.
#Thus we are keeping the value of forestmode as is and will be using ForestModeNumber as the base for validation.
#Dated: 30-Jan-2017 [Tarun] Changing the forestmode & domainmode value from 'unknown' to Windows2016Forest & Windows2016Domain respectively

$script:modesCSV = ConvertFrom-Csv -InputObject $script:modesText
#endregion

#region script/module support functions
# This function will return an object that could be used to return values, message 
# and return code from a function to caller. USeful as it can return lot of useful
# information instead of just a return value
# ---------------------------------------------------------------------------------
Function Get-PSReturnObject($ReturnCode=0, $Message="Success", $Value="") {
    $outp = '' | Select-Object ReturnCode, Message, Value
    $outp.ReturnCode = $ReturnCode
    $outp.Message = $Message
    $outp.Value = $Value
    return $outp
}
#endregion

# This function will return a forest object (.Net object) based on given domain and credentials.
# domain can be any domain in the forest
# -----------------------------------------------------------------------------------------------
Function Get-DSADForest($Domain, $UserName, $Password) {
    Add-Indent -Header "enter -> Get-DSADForest" # increase indent in log file
    Write-DSLog -Level info -Message "Connecting to domain $Domain using credentials of user $UserName"
    $domainContext = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext('domain', $Domain, $UserName, $Password)
    try {
        $domain = [System.DirectoryServices.ActiveDirectory.Domain]::GetDomain($domainContext)
        $forestFQDN = $Domain.Forest # fqdn of forest in which domain is member of
        $ForestContext = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext('forest', $forestFQDN, "$UserName@$Domain", $Password)
        $forest = [System.DirectoryServices.ActiveDirectory.Forest]::GetForest($ForestContext)
        Write-DSLog -Level info -Message "Forest name is (FQDN of forest root domain) $forestFQDN"
        
        If(($forest.forestmodelevel) -eq "7") {
            Write-DSLog -Level info -Message "Forest mode is Windows2016Forest"
        }
        else { 
            Write-DSLog -Level info -Message "Forest mode is $($forest.ForestMode)"
        }
        $ret = Get-PSReturnObject -ReturnCode 0 -Message 'success' -Value $forest
        #Write-DSLog -Level info -Message "Forest mode is $($forest.ForestMode)"
        #$ret = Get-PSReturnObject -ReturnCode 0 -Message 'success' -Value $forest
    }
    catch {
        Write-DSLog -Level info -Message "Failed to connect to domain $Domain using given credentials ($UserName)"
        Write-DSLog -Level info -Message $_.Exception.Message
        $ret = Get-PSReturnObject -ReturnCode 1 -Message $_.Exception.Message -Value $null
    }
    # set forest object in the variable. Rest of the functions will use this var to get info
    Write-DSLog -Level info -Message "Setting forest object in script variable"
    $script:mvForest = $ret.Value

    Remove-Indent -Footer "exit -> Get-DSADForest" # decrease indent in log file
    return $ret # return object to caller
}
# This function will return forest name 
# ------------------------------------- 
Function Get-DSADForestName {
    Add-Indent -Header "enter -> Get-DSADForestName" # increase indent in log file
    if($script:mvForest -ne $null) { 
        Write-DSLog -Level info -Message "returning forest name as $($script:mvForest.Name)"
        Remove-Indent -Footer "exit -> Get-DSADForestName" # decrease indent in log file
        return $script:mvForest.Name 
    } else { 
        Write-DSLog -Level info -Message "error getting forest name, make sure you have used Get-DSADForest to connect to the domain/forest first"
        Remove-Indent -Footer "exit -> Get-DSADForestName" # decrease indent in log file
        return $null 
    }
}

# This function will return name of all sites in a forest
# -------------------------------------------------------
Function Get-DSADForestSites {
    if($script:mvForest -ne $null) { return $script:mvForest.Sites.Name } else { return $null }
}

# This function will return name of all domains in a forest 
# ---------------------------------------------------------
Function Get-DSADForestDomains {
    if($script:mvForest -ne $null) { return $script:mvForest.Domains.Name } else { return $null }
}

# This function will return domain object for given domain name
# -------------------------------------------------------------
Function Get-DSADDomain($DomainName) {
    if($DomainName -in (Get-DSADForestDomains)) { 
        $domain = $script:mvForest.Domains | Where-Object { $_.Name -eq $DomainName }
        return $domain
    }
    else { return $null }
}

# this function returns name of forest root domain
# ------------------------------------------------
Function Get-DSADForestRootDomain {
    if($script:mvForest -ne $null) { return $script:mvForest.RootDomain } else { return $null }
}

# this function returns name of forest schema role owner
# ------------------------------------------------------
Function Get-DSADForestSchemaRoleOwner {
    if($script:mvForest -ne $null) { return $script:mvForest.SchemaRoleOwner } else { return $null }
}

# this function returns name of forest naming role owner
# ------------------------------------------------------
Function Get-DSADForestNamingRoleOwner {
    if($script:mvForest -ne $null) { return $script:mvForest.NamingRoleOwner } else { return $null }
}

# this function tests whether given domain exists in the forest or not
# ---------------------------------------------------------------------
Function Test-DSADDomainExists($DomainName) {
    return ($DomainName -in (Get-DSADForestDomains)) # true or false even if forest is null
}

# this function tests whether given site exists in the forest or not
# -------------------------------------------------------------------
Function Test-DSADSiteExists($SiteName) {
    return ($SiteName -in (Get-DSADForestSites)) # true or false even if forest is null
}

# this function returns a list of domain controllers for given domain
# --------------------------------------------------------------------
Function Get-DSADDomainControllers($DomainName) {
    if((Test-DSADDomainExists -DomainName $DomainName) -eq $null) { return $null }
    else {
        $domain = $script:mvForest.Domains | Where-Object { $_.Name -eq $DomainName }
        return $domain.DomainControllers.name
    }
}

# This function will return parent of given domain. If $DomainName is root domain then this 
# function will return null. If invalid domain name is given then also it will return null
# ------------------------------------------------------------------------------------------
Function Get-DSADParentDomainName($DomainName) {
    $domain = Get-DSADDomain -DomainName $DomainName
    if($domain -eq $null) { return $null }
    else { return $domain.Parent }
}

# THis function will return Domain role holder for given domain
# -------------------------------------------------------------
Function Get-DSADDomainRoleOwner {
param(
    [string]$DomainName,
    [string][ValidateSet('pdc','rid','infrastructure')] $Role
)
    $domain = Get-DSADDomain -DomainName $DomainName
    if($domain -eq $null) { return $null }
    else { 
        switch($Role) {
            'pdc' { return $domain.PdcRoleOwner }
            'rid' { return $domain.RidRoleOwner }
            'infrastructure' { return $domain.InfrastructureRoleOwner }
        }
    }
}

# This function will return Active directory schema version
# ---------------------------------------------------------
Function Get-DSADSchemaVersion {
    if($script:mvForest -ne $null) { return $script:mvForest.Schema.GetDirectoryEntry().objectVersion }
    else { return $null }   
}

#region Forest and domain mode related functions
# this function returns forest functional mode
# --------------------------------------------
Function Get-DSADForestMode {
    Add-Indent -Header "enter -> Get-DSADForestMode" # increase indent in log file
    if($script:mvForest -eq $null) { 
        Write-DSLog -Level info -Message "error getting forest mode, make sure you have used Get-DSADForest to connect to the domain/forest first"
        return $null 
    } # return null if forest info is not available
    else { 
        Write-DSLog -Level info -Message "Getting details for forest mode $($script:mvForest.ForestModeLevel)"
        # updated 22-feb-16: w2k8r2 returns forest mode as number instead of mode name!
        if((Get-OSVersion) -eq '6.1') {
            $fmode = $script:modesCSV | Where-Object { $_.ModeNumber -eq $script:mvForest.ForestMode } |
            Select-Object ForestMode, ModeNumber, ModeShortName, ModeDisplayName
            if($fmode -eq $null) { # use mode name to get this info - kind of 2nd attempt
                $fmode = $script:modesCSV | Where-Object { $_.ForestMode -eq $script:mvForest.ForestMode } |
                Select-Object ForestMode, ModeNumber, ModeShortName, ModeDisplayName
            }
        }
        else { # for rest of supported platforms.. likely 2012 r1 and above
                #modified the code to change the validation from forestmode to forestmodelevel; 24/1/2017
            $fmode = $script:modesCSV | Where-Object { $_.ModeNumber -eq $script:mvForest.ForestModeLevel } |
            Select-Object ForestMode, ModeNumber, ModeShortName, ModeDisplayName
        }
        Write-DSLog -Level info -Message "Returning forest mode $fmode"
        Remove-Indent -Footer "exit -> Get-DSADForestMode" # decrease indent in log file
        return $fmode # return forest mode custom object
    }
}

# this function returns given domain's mode
# -----------------------------------------
Function Get-DSADDomainMode($DomainName) {
    $domain = Get-DSADDomain -DomainName $DomainName
    if($domain -eq $null) { return $null }
    else {
        #Modified to change the validation from domainmode to domainmodelevel; 24-1-2017
        $dmode = $script:modesCSV | Where-Object { $_.ModeNumber -eq $domain.DomainModeLevel } |
            Select-Object DomainMode, ModeNumber, ModeShortName, ModeDisplayName
        return $dmode # return forest mode custom object
    }
}

# this function will return support forest modes
# -----------------------------------------------
Function Get-DSSupportedForestModes {
    $os = Get-OSVersion # get OS version of this host - 6.1: w2k8r2, 6.2: w2k12, 6.3 w2k12r2, 10.0 W2K16
    if($os -eq '6.1') { $fmnum = 4 }
    elseif($os -eq '6.2') { $fmnum =5 }
    if($os -eq '6.3') { $fmnum = 6 }
    if($os -eq '10.0') { $fmnum = 7 }

    $fmodes = ($script:modesCSV | Where-Object { $_.ModeNumber -le $fmnum } |
    Select-Object ForestMode, ModeNumber, ModeShortName, ModeDisplayName)
    return $fmodes
    #return ($script:modesCSV | Select-Object ForestMode, ModeNumber, ModeShortName, ModeDisplayName)
}

# this function will return support domain modes. If forest mode filter is given then a list of supported
# domain modes based on given forest mode is returned
# --------------------------------------------------------------------------------------------------------
Function Get-DSSupportedDomainModes {
param(
    [Parameter(ParameterSetName="fm",Mandatory=$false)] 
    [validateset('Windows2008Forest','Windows2008R2Forest','Windows8Forest','Windows2012R2Forest','Windows2016Forest')]
    [string]$ForestMode,
    [Parameter(ParameterSetName="fmnum",Mandatory=$false)] 
    [validateset(3,4,5,6,7)]
    [string] $ForestModeNumber,
    [Parameter(ParameterSetName="fmsname",Mandatory=$false)] 
    [validateset('Win2008','Win2008R2','Win2012','Win2012R2','WinThreshold')]
    [string] $ForestModeShortName,
    [Parameter(ParameterSetName="fmdname",Mandatory=$false)]
    [validateset('Windows Server 2008','Windows Server 2008 R2','Windows Server 2012','Windows Server 2012 R2','Windows Server 2016')]
    [string] $ForestModeDisplayName
)

    # store the specified forest mode format for filtering purpose
    $givenFMode = '' # bydefault assume no forest mode is given
    $givenFModeValue = '' # store given mode value for filtering below
    if($ForestMode) { $givenFMode = 'ForestMode'; $givenFModeValue = $ForestMode }
    elseif($ForestModeNumber) { $givenFMode = 'ModeNumber'; $givenFModeValue = $ForestModeNumber }
    elseif($ForestModeShortName) { $givenFMode = 'ModeShortName'; $givenFModeValue = $ForestModeShortName }
    elseif($ForestModeDisplayName) { $givenFMode = 'ModeDisplayName'; $givenFModeValue = $ForestModeDisplayName }

    if($givenFMode -eq '') { # none of forest mode filters were given, return all modes
        return ($script:modesCSV | Select-Object DomainMode, ModeNumber, ModeShortName, ModeDisplayName)
    }
    else { # one of the forest mode filter were given
        # get mode number of given forest mode
        $givenModeNum = ($script:modesCSV | Where-Object { $_.($givenFMode) -eq $givenFModeValue }).ModeNumber
        
        # detect OS and get its mode number for filtering       
        $os = Get-OSVersion # get OS version of this host - 6.1: w2k8r2, 6.2: w2k12, 6.3 w2k12r2, 10.0 W2K16
        if($os -eq '6.1') { $fmnum = 4 }
        elseif($os -eq '6.2') { $fmnum =5 }
        if($os -eq '6.3') { $fmnum = 6 }
        If($os -eq '10.0') { $fmnum = 7 }

        # get all supported modes for given forest mode
        $supportedDModes = $script:modesCSV | Where-Object { $_.ModeNumber -ge $givenModeNum -and $_.ModeNumber -le $fmnum } | 
            Select-Object DomainMode, ModeNumber, ModeShortName, ModeDisplayName
        return $supportedDModes # return the list
    }
}

