﻿# This module contains the functions relevant to implementing configurations as per the options selected by user in XML file / tool.
# The name of the module is DSImplement.psm1
# Author: Tarun Rajvanshi, Umesh Thakur & Arunkumar Bavirisetti
# Update Date  : 21-March-2017
# Copyright  : @Platform Wintel SOE, DXC. 
# ---------------------------------------------------------------------------------


Function Get-DSIPAddress($InterfaceIndex) {
    $i = (Get-WmiObject Win32_NetworkAdapterConfiguration | where {$_.InterfaceIndex -eq $InterfaceIndex})
    if($i.IPAddress.Count -eq 1) { return $i.IPAddress[0] }
    elseif($i.IPAddress.Count -eq 0) { return "" } 
}

# this function will return network interface on which you can set IP configurations
# ----------------------------------------------------------------------------------
function Get-DSNetworkInterface($NetAdapterName) {
    
    Add-Indent -Header "enter -> Get-DSNetworkInterface" # increase indent in log file
    
    #retrieving the object properties of the Network Adapter specified by the user
    $NetAdapter = Get-WmiObject -Class Win32_NetworkAdapter | Where-Object { $_.NetconnectionID -eq  $NetAdapterName }
    if($NetAdapter -eq $null) {
        Write-DSLog -Level info -Message "Unable to bind to network adapter with Connection Id: $NetAdapterName"
        Remove-Indent -Footer "exit -> Get-DSNetworkInterface" # decrease indent in log file
        return $false
    }
    else {
        Write-DSLog -Level info -Message "Able to successfully bind to Network Adapter: $NetAdapterName"
    }

    #retrieving the object properties of the network adapter based on the interfaceindex
    $NetInt = Get-WmiObject -Class Win32_NetworkAdapterConfiguration | Where-Object { 
        $_.InterfaceIndex -eq $NetAdapter.InterfaceIndex }
    if($NetInt -eq $null) {
        Write-DSLog -Level error -Message "Unable to bind to network adapter interface index: $($NetAdapter.InterfaceIndex)"
        Remove-Indent -Footer "exit -> Get-DSNetworkInterface" # decrease indent in log file
        return $false
    }
    else {
        Write-DSLog -Level info -Message "Able to successfully bind to interface index: $($NetAdapter.InterfaceIndex)"
        Remove-Indent -Footer "exit -> Get-DSNetworkInterface" # decrease indent in log file
        return $NetInt
    }
}

# ---------------------------------------------------------------------------------
# configure the static ip and subnetmask, reading the values from the xml file
# $xmldata.dssoe.DSConfiguration.IPConfig.NetworkAdapterName -> $NetAdapterName
# ---------------------------------------------------------------------------------
Function Set-DSIPAddressAndSubnet($NetAdapterName, $IpAddress, $SubnetMask)
{
    Add-Indent -Header "enter -> Set-DSIPAddressAndSubnet" # increase indent in log file
    # $xmldata.dssoe.DSConfiguration.IPConfig.IPAddress
    # $xmldata.dssoe.DSConfiguration.IPConfig.SubnetMask
    $netInt = Get-DSNetworkInterface -NetAdapterName $NetAdapterName
    if($netInt -eq $false) {
        Write-DSLog -Level info -Message "Unable to bind to network interface, IP configuration cannot be performed"
        Remove-Indent -Footer "exit -> Set-DSIPAddressAndSubnet" # decrease indent in log file
        return $false
    }
    # at this point, successfully binded to network interface
    Write-DSLog -Level info -Message "Trying to configure Static IP and Subnet on Network Adapter: $NetAdapterName"

    try {
        #$res = $netInt.EnableStatic($IpAddress,$SubnetMask)        
        $res = netsh interface ip set address name="$NetAdapterName" source=static address=$IpAddress mask=$SubnetMask
        Write-DSLog -Level info -Message "Output from setting IP address and subnet mask:`n$res"
        $newIP = Get-DSIPAddress -InterfaceIndex $netInt.InterfaceIndex
        if($newIP -ne $IpAddress) { # something wrong, error message and quit
            Remove-Indent -Footer "exit -> Set-DSIPAddressAndSubnet" # decrease indent in log file
            return $false
        }
    }
    catch {
        Write-DSLog -Level error -Message "$($error[0].exception.message)"
        Remove-Indent -Footer "exit -> Set-DSIPAddressAndSubnet" # decrease indent in log file
        return $false
    }
    Remove-Indent -Footer "exit -> Set-DSIPAddressAndSubnet" # decrease indent in log file
    return $true #.returnvalue # return code
}


# ---------------------------------------------------------------------------------
# configure the gateway ip, reading the values from the xml file
# ---------------------------------------------------------------------------------
Function Set-DSGatewayIP($IpGateway, $NetAdapterName)
{
    Add-Indent -Header "enter -> Set-DSGatewayIP" # increase indent in log file
    # $xmldata.dssoe.DSConfiguration.IPConfig.Gateway
    $netInt = Get-DSNetworkInterface -NetAdapterName $NetAdapterName
    if($netInt -eq $false) {
        Write-DSLog -Level info -Message "Unable to bind to network interface, IP gateway configuration cannot be performed"
        Remove-Indent -Footer "exit -> Set-DSGatewayIP" # decrease indent in log file
        return $false
    }
    try {
        $res = $netInt.SetGateways($IpGateway)
    }
    catch
    {
        Write-DSLog -Level error -Message "$($error[0].exception.message)"
    }
    Remove-Indent -Footer "exit -> Set-DSGatewayIP" # decrease indent in log file
    return $res.returnvalue
}


# ---------------------------------------------------------------------------------
# configure dns ip address(es), reading the values from the xml file
# ---------------------------------------------------------------------------------
Function Set-DSDNSAddress($DNSServer, $NetAdapterName)
{
    Add-Indent -Header "enter -> Set-DSDNSAddress" # increase indent in log file
    $netInt = Get-DSNetworkInterface -NetAdapterName $NetAdapterName
    if($netInt -eq $false) {
        Write-DSLog -Level info -Message "Unable to bind to network interface, DNS Server configuration cannot be performed"
        Remove-Indent -Footer "exit -> Set-DSDNSAddress" # decrease indent in log file
        return $false
    }
    $DNSIPAddress = $DNSServer.split(",")
    try
    {
        $res = $netInt.SetDNSServerSearchOrder($DNSIPAddress)
    }
    catch
    {
        Write-DSLog -Level error -Message "$($error[0].exception.message)"
    }
    Remove-Indent -Footer "exit -> Set-DSDNSAddress" # decrease indent in log file
    return $res.returnvalue
}

# ---------------------------------------------------------------------------------
# configure WINS ip address(es), reading the values from the xml file
# ---------------------------------------------------------------------------------
<#Function Set-DSWINSAddress ($WINSServer, $NetAdapterName)
{
    Add-Indent -Header "enter -> Set-DSWINSAddress" # increase indent in log file
    $netInt = Get-DSNetworkInterface -NetAdapterName $NetAdapterName
    if($netInt -eq $false) {
        Write-DSLog -Level info -Message "Unable to bind to network interface, WINS configuration cannot be performed"
        Remove-Indent -Footer "exit -> Set-DSWINSAddress" # decrease indent in log file
        return $false
    }
    $WINSAddress = $WINSServer.split(",")
    If($WINSAddress.count -eq 1) {
        $WINSServer1 = $WINSAddress[0]
		$WINSServer2 = ""
    }

    If($WINSAddress.count -eq 2) {
        $WINSServer1 = $WINSAddress[0]
		$WINSServer2 = $WINSAddress[1]
    }

    try
    {
        $res = $netInt.SetWINSServer($WINSServer1,$WINSServer2)
    }
    catch
    {
        Write-DSLog -Level error -Message "$($error[0].exception.message)"
    }
    Remove-Indent -Footer "exit -> Set-DSWINSAddress" # decrease indent in log file
    return $res.returnvalue
} - Not accepting wins parameter hence commenting this section - Arun 08-06-16 #>


# ---------------------------------------------------------------------------------
# configure network adapter dns suffix as specified by user in the xml file
# ---------------------------------------------------------------------------------
Function Set-DSNetworkAdapterDNSSuffix ($NetworkAdapterDNSSuffix, $NetAdapterName)
{
    Add-Indent -Header "enter -> Set-DSNetworkAdapterDNSSuffix" # increase indent in log file
    $netInt = Get-DSNetworkInterface -NetAdapterName $NetAdapterName
    if($netInt -eq $false) {
        Write-DSLog -Level info -Message "Unable to bind to network interface, DNS Suffix configuration cannot be performed"
        Remove-Indent -Footer "exit -> Set-DSNetworkAdapterDNSSuffix" # decrease indent in log file
        return $false
    }

    try {
        $res = $netInt.SetDNSDomain($NetworkAdapterDNSSuffix)
    }
    catch
    {
        Write-DSLog -Level error -Message "$($error[0].exception.message)"
    }
    Remove-Indent -Footer "exit -> Set-DSNetworkAdapterDNSSuffix" # decrease indent in log file
    return $res.returnvalue
}


# ---------------------------------------------------------------------------------
# configure lmhostlookup
# ---------------------------------------------------------------------------------
Function Set-DSLmHostsLookup ($LmHostsLookup)
{
    Add-Indent -Header "enter -> Set-DSLmHostsLookup" # increase indent in log file
    If($LmHostsLookup -eq "True")
    {
        ([wmiclass]"Win32_NetworkAdapterConfiguration").EnableWINS($null,$true)
        Write-DSLog -Level info -Message "Enabled LMHostsLookup - True"
    }
 
    If($LmHostsLookup -eq "False")
    {
        ([wmiclass]"Win32_NetworkAdapterConfiguration").EnableWINS($null,$False)  
        Write-DSLog -Level info -Message "Enabled LMHostsLookup - False"
    }
    Remove-Indent -Footer "exit -> Set-DSLmHostsLookup" # decrease indent in log file             
}

# ---------------------------------------------------------------------------------
# Configure pagefile as per recommended practice. If there are 3 physical drives and 
# NTDS.Dit is in E drive then the page file is set to E:\, else on C:\. 
# Initial Size = RAM + 300
# Maximum Size = RAM * 1.5
# ---------------------------------------------------------------------------------  
Function Set-DSPageFile ([string]$ADDBPath)
{
    Add-Indent -Header "enter -> Set-DSPageFile" # increase indent in log file	
    #$ntdsRegPath = 'HKLM:\SYSTEM\CurrentControlSet\Services\NTDS\Parameters'
    #$ADDrive = (Get-ItemProperty $ntdsRegPath -Name 'DSA Database File').'DSA Database file'
    $ADDrive = $ADDBPath.Split(':')

    # get a list of physical disks for query
    $ntdsdrivecheck = [string] $(wmic diskdrive get deviceid)
	
    # turn off automatic pagefile management by OS
    $(wmic computersystem set AutomaticManagedPagefile=False)
	
    # Get total visible memory for the purpose of setting pagefile
    $RAM = Get-WmiObject Win32_OperatingSystem | select TotalVisibleMemorySize
	$RAM = ($RAM.TotalVisibleMemorySize / 1kb).tostring("F00")

    # check if server has multiple disks as per DSSOE requirements and AD Database is installed to E drive
	if ((($ntdsdrivecheck.Contains("PHYSICALDRIVE2")) -eq $true) -and ($ADDrive[0] -eq "e"))
	{
        # create pagefile on E:\
		$(wmic.exe pagefileset create name="E:\pagefile.sys")
		
        # get reference to created page file and set its initial/max size
        $PageFile = Get-WmiObject Win32_PageFileSetting | Where-Object {$_.name -eq "E:\pagefile.sys"}
		$PageFile.InitialSize = [int]$RAM + 300
		$PageFile.MaximumSize = [int]$RAM * 1.5
		$PageFile.Put() | Out-Null

        # delete existing old pagefile
		$PageFile = Get-WmiObject Win32_PageFileSetting | Where-Object {$_.name -eq "C:\pagefile.sys"}
		$PageFile.delete()

        # Write to log file about pagefile set
		Write-DSLog -Level info -Message ("PageFile Settings Configuration done, File E:\pagefile.sys" + " Initial =" +$PageFile.InitialSize + " Max =" + $PageFile.MaximumSize)
		
	}
	else {
        # Server doesn't have disk partitions as per DSSOE, set pagefile on C:\
		
        # Create pagefile in C:\
        $(wmic.exe pagefileset create name="C:\pagefile.sys")
		
        # get reference to created page file and set its initial/max size
        $PageFile = Get-WmiObject Win32_PageFileSetting | Where-Object {$_.name -eq "C:\pagefile.sys"}
		$PageFile.InitialSize = [int]$RAM + 300
		$PageFile.MaximumSize = [int]$RAM * 1.5
		$PageFile.Put() | Out-Null

        # Write to log file about pagefile set
		Write-DSLog -Level info -Message ("PageFile Settings Configuration done File C:\pagefile.sys" + " Initial =" +$PageFile.InitialSize + " Max =" + $PageFile.MaximumSize)
	}
    Remove-Indent -Footer "exit -> Set-DSPageFile" # decrease indent in log file
}



Function Set-DSClearEvents
{
    #command to clear the event logs
    Clear-EventLog -LogName application, system, Security
}


# ---------------------------------------------------------------------------------
# Create reserver file for the purpose of disk space recovery
# ---------------------------------------------------------------------------------  
Function Set-DSReserveFile ([string]$FilePath, [int]$FileSize)
{
    Add-Indent -Header "enter -> Set-DSReserveFile" # increase indent in log file
    # Delete existing reserve file, if found
    if((Test-Path -Path $FilePath -PathType Leaf -ErrorAction SilentlyContinue) -eq $true)
    {    
        [System.IO.File]::delete($FilePath)	 
        #Write-DSLog -Level info -Message "Existing reserve file deleted: $FilePath"  
    }
    
    # create a new reserve file with given size
    try {
	    $file = new-object System.IO.FileStream $FilePath, Create, ReadWrite
	    $file.SetLength($FileSize*1MB)
	    $file.Close()
	    Write-DSLog -Level info -Message "Reserve File created with given size $FileSize MB"
    }
    catch { # something went wrong with creation of reserve file
        Write-DSLog -Level error -Message "Error while creating reserve file."
        Write-DSLog -Level error -Message "$($_.Exception.Message)"
    }
    Remove-Indent -Footer "exit -> Set-DSReserveFile" # decrease indent in log file    
}
  

# ---------------------------------------------------------------------------------
# configure external time sync server and dependent registry values
# ---------------------------------------------------------------------------------  
Function Set-DSExternalTimeServer($TimeServerName) {
    #Configuring External Time Server parameters
    Add-Indent -Header "enter -> Set-DSExternalTimeServer" # increase indent in log file	

    try {
        Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Parameters" -Name Type -Value NTP -Type String
	    Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Config" -Name AnnounceFlags -Value 5 -Type DWord
	    Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\TimeProviders\NtpServer" -Name Enabled -Value 1 -Type DWord
	    Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Parameters" -Name NtpServer -Value "$TimeServerName,0x8" -Type String
	    Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Config" -Name SpecialPollInterval -Value 3600 -Type DWord
	    Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Config" -Name MaxPosPhaseCorrection -Value 172800 -Type DWord
	    Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Config" -Name MaxNegPhaseCorrection -Value 172800 -Type DWord
	    Write-DSLog -Level info -Message "External Time Server parameters configured" -Verbose
    }
    catch {
        Write-DSLog -Level error -Message "Error occurred; $($error[0].exception.message)"       
    }
    Remove-Indent -Footer "exit -> Set-DSExternalTimeServer" # decrease indent in log file
}


# ---------------------------------------------------------------------------------
# creating the domain controller object in a custom OU, other than default Domain 
# Controllers OU. User will have to specify the target DN path of the OU where DC needs
# to be placed.
# ---------------------------------------------------------------------------------  
Function Set-DSDCOULocation ($TargetPath)
{
    Add-Indent -Header "enter -> Set-DSDCOULocation" # increase indent in log file
    #importing active directory module
    Import-Module -Name ActiveDirectory -Force
    
    #retrieving DN of domain controller and moving the DC object to the $targetpath
    $DCDN = (Get-ADDomainController -Identity $(hostname)).computerobjectDN
    Move-ADObject -Identity $DCDN -TargetPath $TargetPath
    				
    #Link DXC or Default Domain Controller Policy to the OU
    $LinkedGPOs = (Get-GPInheritance -Target $TargetPath).InheritedGpoLinks
    $GPOPresent = $false
    
    foreach($gpo in $LinkedGPOs)
    {
        if (($gpo.DisplayName -eq "OU-B-DXCBaselineDomainControllerPolicy" ) -or ($gpo.DisplayName -eq "OU-B-CSCBaselineDomainControllerPolicy" ) -or ($gpo.DisplayName -eq "Default Domain Controllers Policy" ))
        {
            Write-DSLog -Level info -Message "CSC\DXC or Default Domain Controller Policy already linked to the - " + $TargetPath
            $GPOPresent = $true
        }					
    }
    
    if ($GPOPresent -eq $false)
    {
        $GPODXC = (Get-GPO -Name "OU-B-DXCBaselineDomainControllerPolicy" -ErrorAction SilentlyContinue).displayname
        $GPOCSC = (Get-GPO -Name "OU-B-CSCBaselineDomainControllerPolicy" -ErrorAction SilentlyContinue).displayname				
        if (($GPODXC -eq $null) -and ($GPOCSC -eq $null))
        {
            #if OU-B-DXCBaselineDomainControllerPolicy GPO is not found then link the Default Domain Controller policy to the $targetpath
            new-gplink -Guid 6AC1786C-016F-11D2-945F-00C04fB984F9 -target $TargetPath -Order 1
            Write-DSLog -Level warning -Message "Since OU-B-(DXC\CSC)BaselineDomainControllerPolicy GPO is not found, thus default domain controller policy is linked to the - " + $TargetPath
        }
        else
        {
            #if OU-B-DXCBaselineDomainControllerPolicy GPO is found then link it & make linkorder = 1 and link the default domain controller policy at link order 2
            if($GPOCSC -eq $null){new-gplink -name  "OU-B-DXCBaselineDomainControllerPolicy" -target $TargetPath -Order 1}else{new-gplink -name  "OU-B-CSCBaselineDomainControllerPolicy" -target $TargetPath -Order 1}
            new-gplink -Guid 6AC1786C-016F-11D2-945F-00C04fB984F9 -target $TargetPath -Order 2
            Write-DSLog -Level warning -Message "OU-B-(DXC/CSC)BaselineDomainControllerPolicy is linked at order 1 and default domain controller policy is linked at order 2, to the target path - " + $TargetPath
        }
    }
    Remove-Indent -Footer "exit -> Set-DSDCOULocation" # decrease indent in log file
}


# ---------------------------------------------------------------------------------
# create DXC standard baseline GPOs for domain and domain controllers and import the
# baseline GPO settings. Function is NOT applicable in case of Additional DC.
# ---------------------------------------------------------------------------------  
Function Set-DSBaseLineGPOs 
(   [switch] $DCPromoOptionsSelected, 
    [switch] $ConfigureDomainPolicy,
    [switch] $ConfigureDomainControllerPolicy)
{   
    Add-Indent -Header "enter -> Set-DSBaseLineGPOs" # increase indent in log file
    # If this server is NOT additional domain controller, then configure this section
	If($DCPromoOptionsSelected) {
        #Creation of GPO for DXC Standard default domain policy and default domain controllers policy
        #localgpo.wfs is used to reveal the MSS settings in the group policy editor
        #Invoke-Command {cmd /c c: "&" cd $(split-path -path $PSScriptRoot) "&" cscript localgpo.wsf /ConfigSCE}
        
        <#Write-DSLog -Level info -Message "Importing localgpo.wsf"
        try {
            invoke-command { cscript $PSScriptRoot\localgpo.wsf /configSCE }
            Write-DSLog -Level info -Message "Localgpo.wsf imported successfully"
        }
        catch {
            Write-DSLog -Level error -Message "An error occurred: $($error[0].exception.message)"
        }
        #>
        #Copying the MSS-Legacy.adml and MSS-Legacy.admx files to the policy store on the server, in order to reveal 
        # the MSS settings in GP Editor
        Write-DSLog -Level info -Message "Revealing MSS GPO settings"
        Write-DSLog -Level info -Message "Copying the MSS-Legacy.admx and MSS-Legacy.adml files to $env:SystemRoot\PolicyDefinitions folder."
        Try {
            Copy-Item -Path "$PSScriptRoot\..\Config\MSS-legacy.admx" -Destination "$env:SystemRoot\PolicyDefinitions" -Force
            Copy-Item -Path "$PSScriptRoot\..\Config\MSS-legacy.adml" -Destination "$env:SystemRoot\PolicyDefinitions\en-US" -Force
            Write-DSLog -Level info -Message "Files copied successfully"
        }
        Catch {
            Write-DSLog -Level error -Message "An error occurred while copying the MSS files: $($error[0].exception.message)"
        }
        
		# Store GPO Backup Path in a variable
		$GPOBackupPath = $(split-path -path $PSScriptRoot) + "\Security Policies"		
		
        # configure domain security policy
		if($ConfigureDomainPolicy) { 
            $gpoName = 'DO-B-DXCBaselineDomainPolicy'
            $domain = (Get-ADDomain -Server $(hostname)).dnsroot
            $domainDN = ((Get-ADDomain -Server $(hostname)).DistinguishedName)
            $backupId = 'A3D33815-4BA6-4821-943D-F191AD6EBB2A'

			Write-DSLog -Level info -Message "Creating GPO for DXC Standard domain policy"
			$gpOut = new-gpo -name $gpoName -Domain $domain | new-gplink -target $domainDN -Order 1 -Domain $domain
            Write-DSLog -Level info -Message "$($gpOut | Select-Object *)"
            
            Write-DSLog -Level info -Message "Importing GPO from $GPOBackupPath (backup Id: $backupId)"
			$gpOut = import-gpo -BackupId $backupId -TargetName $gpoName -path $GPOBackupPath -Domain $domain
			Write-DSLog -Level info -Message "$($gpOut | Select-Object *)"
            
            Write-DSLog -Level info -Message "Performing gpupdate (with `/force)"
            $gpout = (gpupdate /force /boot)
            Write-DSLog -Level info -Message "$gpOut"
            
            Write-DSLog -Level info -Message "GPO for DXC Standard domain policy has been created and applied" -Verbose
		}
		else 
        {
            # user has not specified to configure domain security policy
			Write-DSLog -Level warning -Message "Creation of GPO for DXC Standard domain policy is not selected by user"
		}

        # Configure domain controller security policy
		if($ConfigureDomainControllerPolicy) {
            $gpoName = 'OU-B-DXCBaselineDomainControllerPolicy'
            $domain = (Get-ADDomain -Server $(hostname)).dnsroot
            $dcOU = ((Get-ADDomain -Server $(hostname)).domaincontrollerscontainer)
            $backupId = '5C0FC933-1993-485D-A19F-4396DC31B880'
			
            Write-DSLog -Level info -Message "[DSDCGPO] Creating GPO for DXC Standard domain controller policy"
			$gpOut = new-gpo -name $gpoName -Domain $domain | new-gplink -target $dcOU -Order 1 -Domain $domain
            Write-DSLog -Level info -Message "[DSDCGPO] $($gpOut | Select-Object *)"
            
            Write-DSLog -Level info -Message "[DSDomainGPO] Importing GPO from $GPOBackupPath (backup Id: $backupId)"
			$gpOut = import-gpo -BackupId $backupId -TargetName $gpoName -path $GPOBackupPath -Domain $domain
            Write-DSLog -Level info -Message "[DSDCGPO] $($gpOut | Select-Object *)"
			
            Write-DSLog -Level info -Message "[DSDomainGPO] Performing gpupdate (with `/force)"
            $gpout = (gpupdate /force /boot)
            Write-DSLog -Level info -Message "[DSDomainGPO] $gpOut"			
			
            Write-DSLog -Level info -Message "[DSDCGPO] GPO for DXC Standard domain controller policy has been created and applied" -Verbose
		}
		else {
		    Write-DSLog -Level info -Message "[DSDCGPO] Creation of GPO for DXC Standard domain controller policy is not selected by user"
        }
    }
    Remove-Indent -Footer "exit -> Set-DSBaseLineGPOs" # decrease indent in log file
}


# -------------------------------------------------------------------------------------
# This fuction is used in the Configure-DSCustomerOUStructure function for the creation
# of sub-OUs under OU=DXC,DC=domain,Dc=com
# -------------------------------------------------------------------------------------
Function New-DXCOUStructure {
	#Creating OU's Under DXC
	$DXCOU = "OU=DXC," + (Get-ADDomain -Server $env:COMPUTERNAME).DistinguishedName
	New-ADOrganizationalUnit -Name Admins -Path $DXCOU -ProtectedFromAccidentalDeletion $true | Out-Null
	New-ADOrganizationalUnit -Name Workstations -Path $DXCOU -ProtectedFromAccidentalDeletion $true | Out-Null
	New-ADOrganizationalUnit -Name Groups -Path $DXCOU -ProtectedFromAccidentalDeletion $true | Out-Null
	New-ADOrganizationalUnit -Name Servers -Path $DXCOU -ProtectedFromAccidentalDeletion $true | Out-Null
	New-ADOrganizationalUnit -Name Users -Path $DXCOU -ProtectedFromAccidentalDeletion $true | Out-Null
    New-ADOrganizationalUnit -Name "Service Accounts" -Path $DXCOU -ProtectedFromAccidentalDeletion $true | Out-Null #07-11-16 Arun: Added as per new guidelines
}


# -----------------------------------------------------------
# This function will remove security inheritence for given OU
# -----------------------------------------------------------
Function Remove-DSOUInheritence($OUDistinguishedName) {
    $removeinheritance = [adsi]("LDAP://$OUDistinguishedName")
	$removeinheritance.psbase.get_objectsecurity().SetAccessRuleProtection($true, $true)
	$removeinheritance.psbase.CommitChanges()
}


# ----------------------------------------------------------------------
# This function will create DXC Standard OU structure for Standard AD or Multi-tenant
# AD environment. This function also creates the standard groups (only in the case of 
# multi-tenant AD) and set up standard delegation on the newly created OUs (only in the 
# case of multi-tenant AD).
# ----------------------------------------------------------------------
Function Set-DSCustomerOUStructure(
    [ValidateSet("Standard", "MultiTenant")]$AccountType,
    [string] $AccountCode,
    [switch]$ADDelegation
) 
{    
    Add-Indent -Header "enter -> Set-DSCustomerOUStructure" # increase indent in log file
    #importing activedirectory module
    Import-Module activedirectory

    # Save DN of this DC in a variable for below function calls
    $thisDC = (Get-ADDomain -Server $env:COMPUTERNAME).DistinguishedName

    # Creation of DXC Individual Customer OU Structure for 'Standard' Account type
	if($AccountType -eq 'Standard') {
		Write-DSLog -Level info -Message "Creating DXC Standard AD OU Structure"
					
		# Creating Top level OU's
		New-ADOrganizationalUnit -Name DXC -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null
		New-ADOrganizationalUnit -Name Admins -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null
		New-ADOrganizationalUnit -Name Groups -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null
		New-ADOrganizationalUnit -Name Servers -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null
		New-ADOrganizationalUnit -Name Workstations -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null
		New-ADOrganizationalUnit -Name "Service Accounts" -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null
		$WorkstationOU = "OU=Workstations,$thisDC"
        #VDI and MAC as sub-OUs under top-level workstations ou
		#New-ADOrganizationalUnit -Name VDI -Path $WorkstationOU -ProtectedFromAccidentalDeletion $true | Out-Null #07-11-16 Arun: Removed as per new guidelines
		#New-ADOrganizationalUnit -Name MAC -Path $WorkstationOU -ProtectedFromAccidentalDeletion $true | Out-Null	#07-11-16 Arun: Removed as per new guidelines			
		New-ADOrganizationalUnit -Name "$AccountCode Users" -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null
					
		Write-DSLog -Level info -Message "Calling Function New-DXCOUStructure" 
		New-DXCOUStructure
        
	}

    # Creation of DXC Multi-Tenant OU Structure for 'MultiTenant' Account type with delegation
	if (($AccountType -eq 'MultiTenant') -and ($ADDelegation)) {
		Write-DSLog -Level info -Message "Creating DXC MultiTenant AD OU Structure"
			
        
        <#Installing Quest CMDlets
        Write-DSLog -Level info -Message "[OUStructure] Installing Quest cmdlets"
		$questcmdletspath = ($PSScriptRoot + "\Cmdlets.msi")
		$questcmdlets = [System.Diagnostics.Process]::Start($questcmdletspath,"/quiet") 
		$questcmdlets.WaitForExit()#>
        
        $ForestInfo = [System.DirectoryServices.DirectoryEntry]([ADSI]"LDAP://RootDSE")
        $RootDomainDN = $ForestInfo.rootDomainNamingContext

		#Changing AD Object Mode to List Object
		Write-DSLog -Level info -Message "Changing AD Object Mode to List Object"
		$Admode = [adsi]("LDAP://CN=Directory Service,CN=Windows NT,CN=Services,CN=Configuration," + $RootDomainDN)
		$Admode.dSHeuristics = "001"
		$Admode.setinfo()
					
		# Creating Top level OU's and set their inheritence to not to inherit from parent
		New-ADOrganizationalUnit -Name DXC -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null 
        Remove-DSOUInheritence -OUDistinguishedName "ou=DXC,$thisDC"

		New-ADOrganizationalUnit -Name Admins -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null
		Remove-DSOUInheritence -OUDistinguishedName "ou=Admins,$thisDC"
	       	
		New-ADOrganizationalUnit -Name Accounts -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null
		Remove-DSOUInheritence -OUDistinguishedName "ou=Accounts,$thisDC"
	       	
		New-ADOrganizationalUnit -Name Resellers -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null
		Remove-DSOUInheritence -OUDistinguishedName "ou=Resellers,$thisDC"
	       	
		New-ADOrganizationalUnit -Name Groups -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null
		Remove-DSOUInheritence -OUDistinguishedName "ou=Groups,$thisDC"
	       	
		New-ADOrganizationalUnit -Name Servers -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null
		Remove-DSOUInheritence -OUDistinguishedName "ou=Servers,$thisDC"
	       	
		New-ADOrganizationalUnit -Name Workstations -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null
		Remove-DSOUInheritence -OUDistinguishedName "ou=Workstations,$thisDC"
	       	
        #$WorkstationOU = "OU=Workstations,$thisDC"
		#New-ADOrganizationalUnit -Name VDI -Path $WorkstationOU -ProtectedFromAccidentalDeletion $true | Out-Null #07-11-16 Arun: Removed as per new guidelines
	       	
		#New-ADOrganizationalUnit -Name MAC -Path $WorkstationOU -ProtectedFromAccidentalDeletion $true | Out-Null #07-11-16 Arun: Removed as per new guidelines
	       	
		New-ADOrganizationalUnit -Name "Service Accounts" -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null
		Remove-DSOUInheritence -OUDistinguishedName "ou=Service Accounts,$thisDC"
	       	
		New-ADOrganizationalUnit -Name "$AccountCode Users" -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null
		Remove-DSOUInheritence -OUDistinguishedName "ou=$AccountCode Users,$thisDC"
	       	
		# Call function to create DXC sub-ou structure		
		Write-DSLog -Level info -Message "Calling Function New-DXCOUStructure" 
		New-DXCOUStructure
					
		#creating variables
		$AccountsOUDN = "OU=Accounts,$thisDC"
		$ResellersOUDN = "OU=Resellers,$thisDC"			
								
		#Group Creation
        Write-DSLog -Level info -Message "Creating groups - AllAccountUsers, AllResellerUsers"
		$OUAdministrationRoles = "OU=Admins,$thisDC"
		New-ADGroup -Path $AccountsOUDN -name AllAccountUsers -samAccountName AllAccountUsers -GroupCategory  "security" -groupscope "DomainLocal" | Out-Null
		New-ADGroup -Path $ResellersOUDN -name AllResellerUsers -samAccountName AllResellerUsers -GroupCategory "security" -groupscope "DomainLocal" | Out-Null
		#New-ADGroup -Path $OUAdministrationRoles -name Role-D-3rdLine-Wintel -samAccountName Role-D-3rdLine-Wintel -GroupCategory "security" -groupscope "Global" | Out-Null #07-11-16 Arun: Removed as per new guidelines
        
        #Adding Role-D-3rdLine-Wintel group to domain admins
		#$root = [adsi]""
		#$rootdn = $root.distinguishedName
        <#Write-DSLog -Level info -Message "Adding Role-D-3rdLine-Wintel group to Domain Admins built-in group"
		$group = [adsi]("LDAP://cn=Domain Admins, cn=Users," + $thisDC)
		$wintelgroup = [adsi]("LDAP://cn=Role-D-3rdLine-Wintel," + $OUAdministrationRoles)
		$members = $group.member
		$group.member = $members + $wintelgroup.distinguishedName
		$group.setinfo() #> #07-11-16 Arun: Removed as per new guidelines
		
        <#	
		#ACL Changes
		Add-PSSnapin Quest.ActiveRoles.ADManagement
		Add-QADPermission $AccountsOUDN -Account AllAccountUsers -Rights "ReadProperty,ListObject" -ApplyTo "ThisObjectOnly" | Out-Null
	    Get-QADPermission $AccountsOUDN -account "Authenticated Users" -schemadefault -inherited | Remove-QADPermission | Out-Null
		Add-QADPermission $ResellersOUDN -Account AllResellerUsers -Rights "ReadProperty,ListObject" -ApplyTo "ThisObjectOnly" | Out-Null
	    Get-QADPermission $ResellersOUDN -account "Authenticated Users" -schemadefault -inherited | Remove-QADPermission | Out-Null
        #>
        
		#ACL Changes
    
        Write-DSLog -Level info -Message "Configuring AD delegation on the newly created OUs and groups"

        $AccountsOUDN = "OU=Accounts,$thisDC"
		$AllAccountUsersSID = New-Object System.Security.Principal.SecurityIdentifier(Get-ADGroup "AllAccountUsers").SID
        $nullGUID = [guid]'00000000-0000-0000-0000-000000000000'                
        $AclAccountsOU = Get-Acl -Path "AD:\$AccountsOUDN"
        $RemoveAccountsOUACL = $AclAccountsOU.Access | Where-Object { $_.IdentityReference -eq "NT AUTHORITY\Authenticated Users" }        
        foreach($ADAccessRule in $RemoveAccountsOUACL){ $AclAccountsOU.RemoveAccessRule($ADAccessRule) | Out-Null }
        $AclAccountsOU.AddAccessRule((New-Object System.DirectoryServices.ActiveDirectoryAccessRule $AllAccountUsersSID,"ReadProperty,ListObject","Allow","None",$nullGUID))
        Set-Acl -AclObject $AclAccountsOU -Path "AD:\$AccountsOUDN" | Out-Null

        $ResellersOUDN = "OU=Resellers,$thisDC"
        $AllResellerUsersSID = New-Object System.Security.Principal.SecurityIdentifier(Get-ADGroup "AllResellerUsers").SID
        $nullGUID = [guid]'00000000-0000-0000-0000-000000000000'  
        $AclResellersOU = Get-Acl -Path "AD:\$ResellersOUDN"
        $RemoveResellersOUAcl = $AclResellersOU.Access | Where-Object {$_.IdentityReference -eq "NT AUTHORITY\Authenticated Users" }        
        foreach($ADAccessRule in $RemoveResellersOUAcl){ $AclResellersOU.RemoveAccessRule($ADAccessRule) | Out-Null }
        $AclResellersOU.AddAccessRule((New-Object System.DirectoryServices.ActiveDirectoryAccessRule $AllResellerUsersSID,"ReadProperty,ListObject","Allow","None",$nullGUID))
        Set-Acl -AclObject $AclResellersOU -Path "AD:\$ResellersOUDN" | Out-Null

        <#Get-QADPermission -identity $AllAccountusers -account "Authenticated Users","Self"  -schemadefault  | Remove-QADPermission | Out-Null
		Get-QADPermission  -identity $AllResellerusers -account "Authenticated Users","Self"  -schemadefault  | Remove-QADPermission | Out-Null
		Get-QADPermission -identity $Role3rdline -account "Authenticated Users","Self"  -schemadefault  | Remove-QADPermission | Out-Null#>
        

        $AllAccountusers = "CN=AllAccountUsers,$AccountsOUDN"
        Remove-DSOUInheritence -OUDistinguishedName $AllAccountusers
        $AclAccountUsers = Get-Acl -Path "AD:\$AllAccountusers"
        $RemoveAccountUsersACL1 = $AclAccountUsers.Access | Where-Object { $_.IdentityReference -eq "NT AUTHORITY\Authenticated Users" }
        $RemoveAccountUsersACL2 = $AclAccountUsers.Access | Where-Object { $_.IdentityReference -eq "NT AUTHORITY\SELF" }
        foreach($ADAccessRule in $RemoveAccountUsersACL1){ $AclAccountUsers.RemoveAccessRule($ADAccessRule) | Out-Null }
        foreach($ADAccessRule in $RemoveAccountUsersACL2){ $AclAccountUsers.RemoveAccessRule($ADAccessRule) | Out-Null }
        Set-Acl -AclObject $AclAccountUsers -Path "AD:\$AllAccountusers" | Out-Null


        $AllResellerusers = "CN=AllResellerUsers,$ResellersOUDN"
        Remove-DSOUInheritence -OUDistinguishedName $AllResellerusers
        $AclResellerusers = Get-Acl -Path "AD:\$AllResellerusers"
        $RemoveResellerUsersACL1 = $AclResellerusers.Access | Where-Object { $_.IdentityReference -eq "NT AUTHORITY\Authenticated Users" }
        $RemoveResellerUsersACL2 = $AclResellerusers.Access | Where-Object { $_.IdentityReference -eq "NT AUTHORITY\SELF" }
        foreach($ADAccessRule in $RemoveResellerUsersACL1){ $AclResellerusers.RemoveAccessRule($ADAccessRule) | Out-Null }
        foreach($ADAccessRule in $RemoveResellerUsersACL2){ $AclResellerusers.RemoveAccessRule($ADAccessRule) | Out-Null }
        Set-Acl -AclObject $AclResellerusers -Path "AD:\$AllResellerusers" | Out-Null


        <#$Role3rdline = "CN=Role-D-3rdLine-Wintel,$OUAdministrationRoles"
        Remove-DSOUInheritence -OUDistinguishedName $Role3rdline
        $AclRole3rdline = Get-Acl -Path "AD:\$Role3rdline"
        $RemoveRole3rdLineAcl1 = $AclRole3rdline.Access | Where-Object { $_.IdentityReference -eq "NT AUTHORITY\Authenticated Users" }
        $RemoveRole3rdLineAcl2 = $AclRole3rdline.Access | Where-Object { $_.IdentityReference -eq "NT AUTHORITY\SELF" }
        foreach($ADAccessRule in $RemoveRole3rdLineAcl1) { $AclRole3rdline.RemoveAccessRule($ADAccessRule) | Out-Null }
        foreach($ADAccessRule in $RemoveRole3rdLineAcl2) { $AclRole3rdline.RemoveAccessRule($ADAccessRule) | Out-Null }
        Set-Acl -AclObject $AclRole3rdline -Path "AD:\$Role3rdline" | Out-Null#> #07-11-16 Arun: Removed as per new guidelines

			
        #Get-QADPermission $("CN=Builtin," + $thisDC) -account "Authenticated Users" -schemadefault -inherited | Remove-QADPermission | Out-Null

        Remove-DSOUInheritence -OUDistinguishedName "CN=Builtin,$thisDC"
        $BuiltinDN = "CN=Builtin,$thisDC"
        $BuiltinAcl = Get-Acl -Path "AD:\$BuiltinDN"
        $RemoveBuiltinAcl = $BuiltinAcl.Access | Where-Object { $_.IdentityReference -eq "NT AUTHORITY\Authenticated Users" }
        foreach($ADAccessRule in $RemoveBuiltinAcl) { $BuiltinAcl.RemoveAccessRule($ADAccessRule) | Out-Null }
        Set-Acl -AclObject $BuiltinAcl -Path "AD:\$BuiltinDN" | Out-Null
        			
        #Get-QADPermission $("CN=Computers," + $thisDC) -account "Authenticated Users" -schemadefault -inherited | Remove-QADPermission | Out-Null

	    Remove-DSOUInheritence -OUDistinguishedName "CN=Computers,$thisDC"
        $ComputersDN = "CN=Computers,$thisDC"
        $ComputersACL = Get-Acl -Path "AD:\$ComputersDN"
        $RemoveComputersACL = $ComputersACL.Access | Where-Object { $_.IdentityReference -eq "NT AUTHORITY\Authenticated Users" }
        foreach($ADAccessRule in $RemoveComputersACL){ $ComputersACL.RemoveAccessRule($ADAccessRule) | Out-Null }
        Set-Acl -AclObject $ComputersACL -Path "AD:\$ComputersDN" | Out-Null
        			
        #Get-QADPermission $("OU=Domain Controllers," + $thisDC) -account "Authenticated Users" -schemadefault -inherited | Remove-QADPermission | Out-Null
        
        Remove-DSOUInheritence -OUDistinguishedName "OU=Domain Controllers,$thisDC"
        $DCsOU = "OU=Domain Controllers,$thisDC"
        $DCsOUACL = Get-Acl -Path "AD:\$DCsOU"
        $RemoveDCsOUACL = $DCsOUACL.Access | Where-Object { $_.IdentityReference -eq "NT AUTHORITY\Authenticated Users" }
        foreach($ADAccessRule in $RemoveDCsOUACL) { $DCsOUACL.RemoveAccessRule($ADAccessRule) | Out-Null }
        Set-Acl -AclObject $DCsOUACL -Path "AD:\$DCsOU" | Out-Null
        			
        #Get-QADPermission $("CN=Users," + $thisDC) -account "Authenticated Users" -schemadefault -inherited | Remove-QADPermission | Out-Null

        Remove-DSOUInheritence -OUDistinguishedName "CN=Users,$thisDC"
        $UsersOU = "CN=Users,$thisDC"
        $UsersOUACL = Get-Acl -Path "AD:\$UsersOU"
        $RemoveUsersOUACL = $UsersOUACL.Access | Where-Object { $_.IdentityReference -eq "NT AUTHORITY\Authenticated Users" }
        foreach($ADAccessRule in $RemoveUsersOUACL) { $UsersOUACL.RemoveAccessRule($ADAccessRule) | Out-Null }
        Set-Acl -AclObject $UsersOUACL -Path "AD:\$UsersOU" | Out-Null
        
		$DXCOU = "OU=DXC,$thisDC"		
        $DXCObjects = (Get-ADObject -SearchBase $DXCOU -Filter *).DistinguishedName
        <#
        foreach ($DXCObject in $DXCObjects)
		{
			Get-QADPermission $DXCObject.DistinguishedName -account "Authenticated Users" -schemadefault -inherited | Remove-QADPermission | Out-Null
		}
        #>

		foreach ($DXCObject in $DXCObjects)
		{
			$WorkingOU = $DXCObject
            $WorkingOUAcl = Get-Acl -Path "AD:\$DXCObject"
            $RemoveWorkingOUAcl = $WorkingOUAcl.Access | Where-Object { $_.IdentityReference -eq "NT AUTHORITY\Authenticated Users" }
            foreach($ADAccessRule in $RemoveWorkingOUAcl){ $WorkingOUAcl.RemoveAccessRule($ADAccessRule) | Out-Null }
            Set-Acl -AclObject $WorkingOUAcl -path "AD:\$WorkingOU" | Out-Null
        }
                

        $AdminsDN = "OU=Admins,$thisDC"
        $AdminsAcl = Get-Acl -Path "AD:\$AdminsDN"
        $RemoveAdminsACL = $AdminsAcl.Access | Where-Object { $_.IdentityReference -eq "NT AUTHORITY\Authenticated Users" }
        foreach($ADAccessRule in $RemoveAdminsACL) { $AdminsAcl.RemoveAccessRule($ADAccessRule) | Out-Null }
        Set-Acl -AclObject $AdminsAcl -Path "AD:\$AdminsDN" | Out-Null
        

        $SrvAccountsDN = "OU=Service Accounts,$thisDC"
        $SrvAccountsAcl = Get-Acl -Path "AD:\$SrvAccountsDN"
        $RemoveSrvAccountsACL = $SrvAccountsAcl.Access | Where-Object { $_.IdentityReference -eq "NT AUTHORITY\Authenticated Users" }
        foreach($ADAccessRule in $RemoveSrvAccountsACL) { $SrvAccountsAcl.RemoveAccessRule($ADAccessRule) | Out-Null }
        Set-Acl -AclObject $SrvAccountsAcl -Path "AD:\$SrvAccountsDN" | Out-Null


        $WorkstationsOU = "OU=Workstations,$thisDC"
        $WorkstationsObjects = (Get-ADobject -SearchBase $WorkstationsOU -Filter *).DistinguishedName
        foreach($WorkstationsObject in $WorkstationsObjects) 
        {
            $WorkingOU = $WorkstationsObject
            $WorkingOUAcl = Get-Acl -Path "AD:\$WorkstationsObject"
            $RemoveWorkingOUAcl = $WorkingOUAcl.Access | Where-Object { $_.IdentityReference -eq "NT AUTHORITY\Authenticated Users" }
            foreach($ADAccessRule in $RemoveWorkingOUAcl){ $WorkingOUAcl.RemoveAccessRule($ADAccessRule) | Out-Null }
            Set-Acl -AclObject $WorkingOUAcl -Path "AD:\$WorkingOU" | Out-Null
        }


        $ServersOU = "OU=Servers,$thisDC"
        $ServersACL = Get-Acl -Path "AD:\$ServersOU"
        $RemoveServersACL = $ServersACL.Access | Where-Object { $_.IdentityReference -eq "NT AUTHORITY\Authenticated Users" }
        foreach($ServerACL in $RemoveServersACL) { $ServersACL.RemoveAccessRule($ServerACL) | Out-Null }
        Set-Acl -AclObject $ServersACL -Path "AD:\$ServersOU" | Out-Null


        $GroupsOU = "OU=Groups,$thisDC"
        $GroupsACL = Get-Acl -Path "AD:\$GroupsOU"
        $RemoveGroupsACL = $GroupsACL.Access | Where-Object { $_.IdentityReference -eq "NT AUTHORITY\Authenticated Users" }
        foreach($GroupAcl in $RemoveGroupsACL) { $GroupsACL.RemoveAccessRule($GroupAcl) | Out-Null }
        Set-Acl -AclObject $GroupsACL -Path "AD:\$GroupsOU" | Out-Null


        $AcctUsersOU = "ou=$AccountCode Users,$thisDC"
        $AcctUsersACL = Get-Acl -Path "AD:\$AcctUsersOU"
        $RemoveAcctUsersACL = $AcctUsersACL.Access | Where-Object { $_.IdentityReference -eq "NT AUTHORITY\Authenticated Users" }
        foreach($ACL in $RemoveAcctUsersACL) { $AcctUsersACL.RemoveAccessRule($ACL) | Out-Null }
        Set-Acl -AclObject $AcctUsersACL -Path "AD:\$AcctUsersOU" | Out-Null     
        
    }

    # Creation of DXC Multi-Tenant OU Structure for 'MultiTenant' Account type without delegation
	if (($AccountType -eq 'MultiTenant') -and (!($ADDelegation))) {
		Write-DSLog -Level info -Message "Creating DXC MultiTenant AD OU Structure"
 					
		# Creating Top level OU's and set their inheritence to not to inherit from parent
		New-ADOrganizationalUnit -Name DXC -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null 
        New-ADOrganizationalUnit -Name Admins -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null
		New-ADOrganizationalUnit -Name Accounts -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null      	
		New-ADOrganizationalUnit -Name Resellers -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null	       	
		New-ADOrganizationalUnit -Name Groups -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null	       	
		New-ADOrganizationalUnit -Name Servers -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null	       	
		New-ADOrganizationalUnit -Name Workstations -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null			       	
		New-ADOrganizationalUnit -Name "Service Accounts" -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null       	
		New-ADOrganizationalUnit -Name "$AccountCode Users" -Path $thisDC -ProtectedFromAccidentalDeletion $true | Out-Null
	       	
		# Call function to create DXC sub-ou structure		
		Write-DSLog -Level info -Message "Calling Function New-DXCOUStructure" 
		New-DXCOUStructure   
        
}
    Remove-Indent -Footer "exit -> Set-DSCustomerOUStructure" # decrease indent in log file
}


#-----------------------------------------------------------------------------------------------------------------
# configure system state back schedule (10:00 pm everyday) on the user specified volume path and backup maintenance
# task (to keep the 3 latest version and delete the rest)
#-----------------------------------------------------------------------------------------------------------------
Function Set-DSBackupConfiguration([switch]$EnableBackupMaintenance, $BackupVolumePath) 
{
   Add-Indent -Header "enter -> Set-DSBackupConfiguration" # increase indent in log file
   # Write-DSLog -Level info -Message "[DSBackupConfig] Installing Windows Server Backup role"    
   # Add-WindowsFeature Windows-Server-Backup | Out-Null #Commenting since backup feature is installed before calling this function, discussed with tarun - Arun
    
    New-Item -Path HKLM:\SYSTEM\CurrentControlSet\Services\wbengine\SystemStateBackup -Force | Out-Null
	Set-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\wbengine\SystemStateBackup -Name AllowSSBToAnyVolume -Value 1 -Type DWord | Out-Null
			
	#Creating Backup policy
    Write-DSLog -Level info -Message "Configuring DC System State Backup Schedule"
	$policy = New-WBPolicy 
	Set-WBSchedule –Policy $policy –Schedule 22:00 | Out-Null
	$BackupTargetVolume = New-WBbackupTarget –VolumePath $BackupVolumePath
	Add-WBBackupTarget –Policy $policy –Target $BackupTargetVolume  | Out-Null
	Add-WBSystemState –Policy $policy | Out-Null
	Set-WBPolicy –Policy $policy | Out-Null
	
    Write-DSLog -Level info -Message "DC System State Backup Schedule created"

    # If user has selected to enable backup maintenance then configure it
	if($EnableBackupMaintenance)
    {
		Write-DSLog -Level info -Message "Configuring DC System State Backup Maintenance job"
		(schtasks.exe /create /sc DAILY  /TN "System State Backup Cleanup" /NP /F /TR "%windir%\System32\wbadmin.exe delete systemstatebackup -keepVersions:3 -quiet" /ST 21:00) | Out-Null
	}
	else
	{
		Write-DSLog -Level info -Message "Backup maintenance configuration is not selected"
    }
    Remove-Indent -Footer "exit -> Set-DSBackupConfiguration" # decrease indent in log file
}


#-----------------------------------------------------------------------------------------------------------------
#Create the Active Directory Users in bulk, reading from the csv file.
#-----------------------------------------------------------------------------------------------------------------
Function New-DSCreateADUsers($ExcelPath){

Add-Indent -Header "enter -> New-DSCreateADUsers" # increase indent in log file
#Declaring variables
#variable for the path of the csv file, which should reside on the root of the DSSOE package folder
#variable for the log file, to be stored in the C:\Support\Logs\dssoe folder
#$path     = "$PSScriptRoot\import_create_ad_users.csv"  #Commenting this line since user provided path needs to considered, discussed with tarun - Arun
$path = $ExcelPath
$log      = "C:\Support\Logs\dssoe\create_ad_users.log"
$date     = Get-Date
#storing the DN of the domain
$addn     = (Get-ADDomain).DistinguishedName
#storing the DNS name of the domain
$dnsroot  = (Get-ADDomain).DNSRoot
$i        = 1

Write-DSLog -Level info -Message "Creating AD users from the csv file; the log is stored separately in C:\Support\Logs\dssoe\create_ad_users.log file"

 "Processing started (on " + $date + "): " | Out-File $log -append
  "--------------------------------------------" | Out-File $log -append
  Import-CSV $path | ForEach-Object {
    If (($_.Implement.ToLower()) -eq "yes")
    {
        If (($_.GivenName -eq "") -Or ($_.LastName -eq ""))
        {
            #Write-Host "[ERROR]`t Please provide valid GivenName and LastName. Processing skipped for line $($i)`r`n"
            "[ERROR]`t Please provide valid GivenName, LastName and Initials. Processing skipped for line $($i)`r`n" | Out-File $log -append
        }
      Else
        {
            # Set the target OU
            $location = $_.TargetOU #+ ",$($addn)"
	

            # Set the Enabled and PasswordNeverExpires properties
            If (($_.Enabled.ToLower()) -eq "true") { $enabled = $True } Else { $enabled = $False }
            If (($_.PasswordNeverExpires.ToLower()) -eq "true") { $expires = $True } Else { $expires = $False }

            # A check for the country, because those were full names and need 
            # to be land codes in order for AD to accept them. Used Netherlands 
            # as example
            If($_.Country -eq "Netherlands")
            {
                $_.Country = "NL"
            }
            Else
            {
                $_.Country = "EN"
            }
            # Replace dots / points (.) in names, because AD will error when a 
            # name ends with a dot (and it looks cleaner as well)
            $replace = $_.Lastname.Replace(".","")
            If($replace.length -lt 4)
            {
                $lastname = $replace
            }
            Else
            {
                $lastname = $replace.substring(0,4)
            }
            # Create sAMAccountName according to this 'naming convention':
            # <FirstLetterInitials><FirstFourLettersLastName> for example
            # htehp
            $sam = $_.sAMAccountName #$_.Initials.substring(0,1).ToLower() + $lastname.ToLower()
            Try   { $exists = Get-ADUser -LDAPFilter "(sAMAccountName=$sam)" }
            Catch { }
            
            If(!$exists)
            {
                # Set all variables according to the table names in the Excel 
                # sheet / import CSV. The names can differ in every project, but 
                # if the names change, make sure to change it below as well.
                $setpass = ConvertTo-SecureString -AsPlainText $_.Password -force

                Try
                {
                    #Write-Host "[INFO]`t Creating user : $($sam)"
                    "[INFO]`t Creating user : $($sam)" | Out-File $log -append
                    New-ADUser $sam -GivenName $_.GivenName -Initials $_.Initials `
                    -Surname $_.LastName -DisplayName ($_.LastName + "," + $_.Initials + " " + $_.GivenName) `
                    -Office $_.OfficeName -Description $_.Description -EmailAddress $_.Mail `
                    -StreetAddress $_.StreetAddress -City $_.City -State $_.State `
                    -PostalCode $_.PostalCode -Country $_.Country -UserPrincipalName ($sam + "@" + $dnsroot) `
                    -Company $_.Company -Department $_.Department -EmployeeID $_.EmployeeID `
                    -Title $_.Title -OfficePhone $_.Phone -AccountPassword $setpass `
                    -profilePath $_.ProfilePath -scriptPath $_.ScriptPath -homeDirectory $_.HomeDirectory `
                    -homeDrive $_.homeDrive -Enabled $enabled -PasswordNeverExpires $expires
                    #Write-Host "[INFO]`t Created new user : $($sam)"
                    "[INFO]`t Created new user : $($sam)" | Out-File $log -append
     
                    $dn = (Get-ADUser $sam).DistinguishedName
                    # Set an ExtensionAttribute
                    If ($_.ExtensionAttribute1 -ne "" -And $_.ExtensionAttribute1 -ne $Null)
                    {
                        $ext = [ADSI]"LDAP://$dn"
                        $ext.Put("extensionAttribute1", $_.ExtensionAttribute1)
                        Try   { $ext.SetInfo() }
                        Catch { "[ERROR]`t Couldn't set the Extension Attribute : $($_.Exception.Message)" | Out-File $log -Append }
                    }
       
                    # Move the user to the OU ($location) you set above. If you don't
                    # want to move the user(s) and just create them in the global Users
                    # OU, comment the string below
                    If ([adsi]::Exists("LDAP://$($location)"))
                    {
                        Move-ADObject -Identity $dn -TargetPath $location
                        #Write-Host "[INFO]`t User $sam moved to target OU : $($location)"
                        "[INFO]`t User $sam moved to target OU : $($location)" | Out-File $log -append
                    }
                    Else
                    {
                       # Write-Host "[ERROR]`t Targeted OU couldn't be found. Newly created user wasn't moved!"
                        "[ERROR]`t Targeted OU couldn't be found. Newly created user wasn't moved!" | Out-File $log -append
                    }
       
                    # Rename the object to a good looking name (otherwise you see
                    # the 'ugly' shortened sAMAccountNames as a name in AD. This
                    # can't be set right away (as sAMAccountName) due to the 20
                    # character restriction
                    $newdn = (Get-ADUser $sam).DistinguishedName
                    Rename-ADObject -Identity $newdn -NewName ($_.GivenName + " " + $_.LastName)
                    #Write-Host "[INFO]`t Renamed $($sam) to $($_.GivenName) $($_.LastName)`r`n"
                    "[INFO]`t Renamed $($sam) to $($_.GivenName) $($_.LastName)`r`n" | Out-File $log -append
                }
                Catch
                {
                    "[ERROR]`t Oops, something went wrong: $($_.Exception.Message)`r`n" | Out-File $log -Append
                }
            }
            Else
            {
                #Write-Host "[SKIP]`t User $($sam) ($($_.GivenName) $($_.LastName)) already exists or returned an error!`r`n"
                "[SKIP]`t User $($sam) ($($_.GivenName) $($_.LastName)) already exists or returned an error!" | Out-File $log -append
            }
        }
    }
    Else
    {
      #Write-Host "[SKIP]`t User $($sam) ($($_.GivenName) $($_.LastName)) will be skipped for processing!`r`n"
      "[SKIP]`t User $($sam) ($($_.GivenName) $($_.LastName)) will be skipped for processing!" | Out-File $log -append
    }
    $i++
  }
  "--------------------------------------------" + "`r`n" | Out-File $log -append
  Add-Indent -Header "enter -> New-DSCreateADUsers" # increase indent in log file
}


#-----------------------------------------------------------------------------------------------------------------
# generate best practice analyzer report, on the local domain controller, in html format
#-----------------------------------------------------------------------------------------------------------------
Function Set-DSBPAReport($HTMLReportPath, [switch]$ReportAllSevereties) {
    Add-Indent -Header "enter -> Set-DSBPAReport" # increase indent in log file

    #Create directory if not exists
    if((Test-Path -Path $HTMLReportPath -ErrorAction SilentlyContinue) -eq $False){
    New-Item -Path $HTMLReportPath -ItemType Directory -Force | Out-Null
    }
        
    # Getting a list of models to generate report for
    $ModelsToRun = @() 
    Write-DSLog -Level info -Message "Identifying BPA models to run"
    if ((Get-WindowsFeature AD-Domain-Services).Installed) { $ModelsToRun += "Microsoft/Windows/DirectoryServices" } 
    if ((Get-WindowsFeature DNS).Installed) { $ModelsToRun += "Microsoft/Windows/DNSServer" } 
    if ((Get-WindowsFeature File-Services).Installed -and (!(Test-OSIsWindowsServer2008R2))) { $ModelsToRun += "Microsoft/Windows/FileServices" } 

    # Log which all severity will be included in the report
    if($ReportAllSevereties) 
    { 
       Write-DSLog -Level info -Message "All severity will be included in the report"
    }
    else 
    {
       Write-DSLog -Level info -Message "Only errors and warnings will be included in the report"
    }

    # enumerate thru the models and generate reports for them
    foreach ($BestPracticesModelId in $ModelsToRun) 
    { 
        # construct BPA name and html paths 
        $date = (Get-Date).ToString("MMddyyyy-hhmmss")
        $BPAName = $BestPracticesModelId.Replace("Microsoft/Windows/","") 
        $HTMLPath = $HTMLReportPath + '\' + $env:COMPUTERNAME + "-" + $BPAName + "-" + $date + ".html" 

        #HTML-header 
        $Head = " 
        <title>BPA Report for $BestPracticesModelId on $($env:COMPUTERNAME)</title> 
        <style type='text/css'>  
            table  { border-collapse: collapse; width: 700px }  
            body   { font-family: Verdana, Arial }  
            td, th { border-width: 1px; border-style: solid; text-align: left; padding: 2px 4px; border-color: black }  
            th     { background-color: grey; }  
            td.Red { color: Red }  
        </style>"  

        #Invoke BPA Model 
        Write-DSLog -Level info -Message "Invoking BPA report generation for model $BestPracticesModelId" -Verbose
        Invoke-BpaModel -BestPracticesModelId $BestPracticesModelId | Out-Null 

        #Include all severeties in BPA Report if enabled. If not, only errors and warnings are reported. 
        if ($ReportAllSevereties) 
        { 
            $BPAResults = Get-BpaResult -BestPracticesModelId $BestPracticesModelId 
        } 
        else 
        { 
            $BPAResults = Get-BpaResult -BestPracticesModelId $BestPracticesModelId | Where-Object {$_.Severity -eq "Error" -or $_.Severity -eq “Warning” } 
        } 

        #Send BPA Results to HTML-file if enabled 
        if ($BPAResults) 
        { 
            $BPAResults | ConvertTo-Html -Property Severity,Category,Title,Problem,Impact,Resolution,Help `
            -Title "BPA Report for $BestPracticesModelId on $($env:COMPUTERNAME)" -Body "BPA Report for `
            $BestPracticesModelId on server $($env:COMPUTERNAME) <HR>" -Head $head | Out-File -FilePath $HTMLPath 
            Write-DSLog -Level info -Message "BPA report generation complete.Report is saved to $HTMLPath" -Verbose
        } 
    }
    Remove-Indent -Footer "exit -> Set-DSBPAReport" # decrease indent in log file
} 


#------------------------------------------
# configure the DNS forwarders 
#------------------------------------------
Function Set-DSDNSForwarders([string]$ForwardersIP) {
    Add-Indent -Header "enter -> Set-DSDNSForwarders" # increase indent in log file				
    if($ForwardersIP -ne "") 
    {
	    [string] $ForwardersIP = $ForwardersIP.split(",")
	    Write-DSLog -Level info -Message "Creating DNS Forwarders $ForwardersIP" -Verbose
	    
        $command = "C:\Windows\System32\dnscmd.exe $(hostname) /resetforwarders $ForwardersIP"
        
        Write-DSLog -Level info -Message "Creating DNS Forwarders"	    
        $fwdOut = Invoke-Expression -Command $command 
        
        Write-DSLog -Level info -Message "$fwdOut"
    }
    Remove-Indent -Footer "exit -> Set-DSDNSForwarders" # decrease indent in log file
}



#-------------------------------------------------------------------------------
# configure AD replication / DFSR Replication on static ports 
#-------------------------------------------------------------------------------
Function Set-DSStaticPorts(
$ADReplicationPort,
$NetlogonPort,
$DFSRPort)
#$FRSPort
{
    Add-Indent -Header "enter -> Set-DSStaticPorts" # increase indent in log file
    If($ADReplicationPort -ne "" -and $NetlogonPort -ne "")
    {
        Write-DSLog -Level info -Message "Configuring AD replication on static port i.e AD replication port: $ADReplicationPort and Netlogon port: $NetlogonPort" -Verbose
        #setting AD replication static port registry values
        Set-ItemProperty -Path registry::"HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\NTDS\Parameters" -Name "TCP/IP Port" -Value $ADReplicationPort -Type DWord
		Set-ItemProperty -Path registry::"HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\Netlogon\Parameters" -Name "DCTcpipPort" -Value $NetlogonPort -Type DWord
    }
    Else
    {
        Write-DSLog -Level warning -Message "To configure AD replication on static ports, both ADReplicationPort and NetlogonPort must be specified."
    }
	
    #If($DFSRPort -ne "" -and $FRSPort -ne "")
    #{
    #    Write-DSLog -Level warning -Message "DFRS and FRS both, cannot be used at the same time for SYSVOL replication. Thus choose a static port for either of them."
    #}
    #Else
    #{
    If(($DFSRPort -ne "") -and ((Get-OSInstallMode -ShortName) -eq 'Full'))
    {
        #configuring DFSR on static port
        Write-DSLog -Level info -Message "Configuring DFSR static port: $DFSRPort" -Verbose
        $hostname = hostname
		dfsrdiag StaticRPC /port:$DFSRPort /Member:$hostname 
	}
    Else
    {
        Write-DSLog -Level info -Message "Not configured, because the port isn't specified or the underneath OS is of servercore/Nano/Minimalserver interface"
    }

    <#If($FRSPort -ne "")
    {
        #setting FRS replication on static port
        Write-DSLog -Level info -Message "configuring FRS static port: $FRSPort"
        Set-ItemProperty -Path registry::"HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\NTFRS\Parameters" -Name "RPC TCP/IP Port Assignment" -Value $FRSPort -Type DWord
    }
    Else
    {        
        Write-DSLog -Level info -Message "Not configured because the port isn't specified"
    }#>
    #}
    Remove-Indent -Footer "exit -> Set-DSStaticPorts" # decrease indent in log file
}


#-------------------------------------------------------------------------------
# Configure DNS Scavenging 
#-------------------------------------------------------------------------------
function Set-DSDNSScavenging([switch] $NewDomainNewForest)
{
    Add-Indent -Header "enter -> Set-DSDNSScavenging" # increase indent in log file	
    $DNSFQDN = (Get-ADComputer -Identity $env:COMPUTERNAME).DNSHostName
	$DNSroot = (Get-ADDomain -Server  $env:COMPUTERNAME).dnsroot
	$DNSMSDCSroot = "_msdcs." + $DNSroot

	# Enabling Scavenging at zone level
    Write-DSLog -Level info -Message "Enabling scavenging at zone level"
	$dnsCmdOut = (DNScmd /config $DNSroot /aging 1)
    Write-DSLog -Level info -Message "$dnsCmdOut"
	
	#_Msdcs Scavenging will be enabled on the first DC in forest only
	if($NewDomainNewForest) 
    { 
        Write-DSLog -Level info -Message "FirstDCInForect is true, enabling _msdcs scavenging "
        $dnsCmdOut = (DNScmd /config $DNSMSDCSroot /aging 1) 
        Write-DSLog -Level info -Message "$dnsCmdOut"
    }

	# Getting IP address info of the localmachine 
	$NetworkAdpaters = @(Get-wmiobject -class "Win32_NetworkAdapter" -computername (hostname) | Where {$_.netEnabled -eq "True"})
	for($i = 0;$i -lt $NetworkAdpaters.count; $i++)
	{
		$NetInterface = Get-WmiObject Win32_NetworkAdapterConfiguration | where-object {$_.InterfaceIndex -eq $NetworkAdpaters[$i].InterfaceIndex}
		if(($netinterface.ipaddress -ne $null) -and ($netinterface.ipaddress -notlike "169.254.*"))
		{
			$ip = $netinterface.IPaddress
		}
	}

	#enabling Scavenging which server will do for the zones
    Write-DSLog -Level info -Message "Resetting scavenging for this server"
	$dnsCmdOut = (dnscmd . /zoneresetscavengeservers $DNSroot $ip)
    Write-DSLog -Level info -Message "$dnsCmdOut"

	#_Msdcs Scavenging will be enabled on the first DC in forest only
	if($NewDomainNewForest) 
    { 
        Write-DSLog -Level info -Message "FirstDCInForect is true, resetting scavenging on _msdcs zone"
        $dnsCmdOut = (dnscmd . /zoneresetscavengeservers $DNSMSDCSroot $ip) 
        Write-DSLog -Level info -Message "$dnsCmdOut"
    }
	
	#enabling Scavenging at server level
    Write-DSLog -Level info -Message "Enabling scavenging at server level"
	$dnsCmdOut = (dnscmd . /config /defaultagingstate 1 )
    Write-DSLog -Level info -Message "$dnsCmdOut"
	$dnsCmdOut = (dnscmd . /config /scavenginginterval 168)
    Write-DSLog -Level info -Message "$dnsCmdOut"
    Write-DSLog -Level info -Message "Configuration DNS scavenging is complete" -Verbose
    Remove-Indent -Footer "exit -> Set-DSDNSScavenging" # decrease indent in log file
}



#-------------------------------------------------------------------------------
# DSSOE verification function; to test certain parameters, which will verify the 
# program ran successfully or not, for success or failure.
#-------------------------------------------------------------------------------
function Test-DSSetup {
	
    Add-Indent -Header "enter -> Test-DSSetup" # increase indent in log file
    #checking ldap bind status
    try
    {
        Get-ADDomain -Server $(hostname)
        $Ldapbind = $true
        Write-DSLog -Level info -Message "LDAP bind is successful"
    }
    catch
    {
        Write-DSLog -Level error -Message "LDAP bind is NOT successful"
        Write-DSLog -Level error -Message "$_.Exception.message"
        $Ldapbind = $false
    }    
    
    <##Checking Existence of 29223 event ID 
	$elog = Get-EventLog -LogName System -ComputerName $env:COMPUTERNAME -InstanceId 29223 -ErrorAction SilentlyContinue
	if ($elog -ne $null) { 
        $event29223 = $true
		Write-DSLog -Level info -Message "Event ID 29223 - This server is a Domain Controller" 
	}
	else { 
        Write-DSLog -Level error -Message "Event ID 29223 not found - This server is NOT a Domain Controller"
        $event29223 = $false 
    }#>

    #Checking Domain Role of the server; if domainrole property is 4 or 5, server is a DC else not
    $DomRol = (Get-WmiObject -Class 'win32_computersystem' | Select DomainRole).DomainRole
    if ($DomRol -in ("4","5")) {
        $isDC = $true
        Write-DSLog -Level info -Message "Domain Role $DomRol - This server is a Domain Controller"
    }
    else {
        Write-DSLog -Level error -Message "Domain Role $DomRol - This server is NOT a Domain Controller"
        $isDC = $false        
    }

	#Checking SYSVOL ready entry
	if (((Get-ItemProperty -Path HKLM:\System\CurrentControlSet\Services\Netlogon\Parameters -name Sysvolready).Sysvolready) -eq 1) {
		$SYSVOLready = $true
		Write-DSLog -Level info -Message "SysvolReady - SYSVOL is ready"
	}
	else { 
        Write-DSLog -Level error -Message "SYSVOL is NOT ready"
        $SYSVOLready = $false 
    }
	
	#Checking SYSVOL share
    $sshare = Get-WmiObject win32_share -computer $env:COMPUTERNAME -ErrorAction SilentlyContinue | Where-Object {$_.name -eq "sysvol"}
	if($sshare -ne $null)
    {
        if (($sshare.name).tolower() -eq "sysvol") {
		    $SYSVOLshare = $true
		    Write-DSLog -Level info -Message "SysvolShare - SYSVOL is shared"
	    }
	    else { 
            Write-DSLog -Level error -Message "SYSVOL is NOT shared"
            $SYSVOLshare = $false 
        }
	}else{$SYSVOLshare = $false}
	#Checking NETLOGON share
    $nshare = Get-WmiObject win32_share -computer $env:COMPUTERNAME -ErrorAction SilentlyContinue | Where-Object {$_.name -eq "netlogon"}
    if($nshare -ne $null)
    {
	    if (($nshare.name).tolower() -eq "netlogon") {
		    $netlogonshare = $true
		    Write-DSLog -Level info -Message "NetlogonShare - Netlogon is shared"
	    }
	    else { 
            Write-DSLog -Level error -Message "Netlogon is NOT shared"
            $netlogonshare = $false 
        }
	}else{$netlogonshare = $false}

	#Checking ADWS
	[string] $ADWSEvent = (Get-EventLog -LogName "Active Directory Web Services" -ComputerName $env:COMPUTERNAME -Source "ADWS" -InstanceId 1073743024)
	if ($ADWSEvent -eq "") { 
        Write-DSLog -Level warning -Message "ADWS - Active Directory Web Services is NOT installed"
        $event1200 = $False 
    }
	else { 
        $event1200 = $true
		Write-DSLog -Level info -Message "ADWS - Active Directory Web Services is installed" 
	}

    # return current status of Sysvol share and Netlogon share
	if($Ldapbind -eq $true -and $SYSVOLshare -eq $true -and $netlogonshare -eq $true -and $isDC -eq $true -and $SYSVOLready -eq $true) {
		Remove-Indent -Footer "exit -> Test-DSSetup" # decrease indent in log file
        return $true
	}
	else { 
        Write-DSLog -Level error -Message "Not all required tests were successful"
        Remove-Indent -Footer "exit -> Test-DSSetup" # decrease indent in log file
        return $false 
    }
}

#-------------------------------------------------------------------------------------
#configure the directory services repair mode option on the startup menu
#-------------------------------------------------------------------------------------
Function Set-DSRepairMode { 
    Add-Indent -Header "enter -> Set-DSRepairMode" # increase indent in log file
    Write-DSLog -Level info -Message "Configuring DS repair mode"
    $CopyBCD = bcdedit /copy '{current}' /d "Directory Services Restore Mode"
	$guid = $CopyBCD.Substring($CopyBCD.IndexOf("{"),$copybcd.indexof("}") - $copybcd.indexof("{") + 1)
	$bcdOut = bcdedit /set $guid safeboot dsrepair
    Write-DSLog -Level info -Message "$bcdOut"
    Write-DSLog -Level info -Message "Directory Services Repair Mode configuration complete" -Verbose
    Remove-Indent -Footer "exit -> Set-DSRepairMode" # decrease indent in log file
}


#-------------------------------------------------------------------------------------
#Adding the DFS management tool for sysvol folder replication management
#-------------------------------------------------------------------------------------
Function Add-DFSTools {
    Add-Indent -Header "enter -> Add-DFSTools" # increase indent in log file
    Add-WindowsFeature RSAT-DFS-Mgmt-Con | Out-Null
    Write-DSLog -Level info -Message "DFS Tools feature for SYSVOL folder replication management are added" -Verbose
    Remove-Indent -Footer "exit -> Add-DFSTools" # decrease indent in log file
}


#-------------------------------------------------------------------------------------
# Saving Domain controller configuration for the purpose of inventory in a file
#-------------------------------------------------------------------------------------
Function Save-ADServerConfig($ADConfigFilePath) {
	Add-Indent -Header "enter -> Save-ADServerConfig" # increase indent in log file
    $DomainInfo = Get-ADDomain -Server ($env:COMPUTERNAME)
    $DCInfo = Get-ADDomainController -Identity ($env:COMPUTERNAME)
	$IPdetails = (gwmi Win32_NetworkAdapterConfiguration | ? { $_.IPAddress -ne $null })
    $VolumeInfo = Get-WmiObject -Class win32_volume -ComputerName ($env:COMPUTERNAME)
    $ProcessorInfo = Get-WmiObject -Class win32_Processor -ComputerName ($env:COMPUTERNAME)
    $MemoryInfo = Get-WmiObject -Class win32_PhysicalMemory -ComputerName ($env:COMPUTERNAME)
    
	$RecordAD = "
    Directory Services Server Configuration`n`r`n`r`n`r`n`r
    Build Date and Time        = $(Get-date)`n`r
    Domain DNS Name            = $($DomainInfo.DNSRoot)`n`r
    DistinguishedName          = $($DomainInfo.DistinguishedName)`n`r
    NetBIOSName                = $($DomainInfo.NetBIOSName)`n`r
    DomainControllersContainer = $($DomainInfo.DomainControllersContainer)`n`r
    Forest Domain Name         = $($DomainInfo.Forest)`n`r
    Parent Domain Name         = $($DomainInfo.ParentDomain)`n`r
    DomainMode                 = $($DomainInfo.DomainMode)`n`r
    Site Name                  = $($DCInfo.Site)`n`r
    IsGlobalCatalog            = $($DCInfo.IsGlobalCatalog)`n`r
    IsRODC                     = $($DCInfo.IsReadOnly)`n`r
    Domain Controller Name     = $(hostname)`n`r
    IPAddress                  = $($IPdetails.IPAddress)`n`r
    SubNet Mask                = $($IPdetails.IPSubnet)`n`r
    GateWay                    = $($IPdetails.DefaultIPGateway)`n`r
    DNS Address                = $($IPdetails.DNSServerSearchOrder)`n`r
    OperatingSystem            = $((Get-ADDomainController).OperatingSystem)`n`r
    OperatingSystemServicePack = $((Get-ADDomainController).OperatingSystemServicePack)`n`r
    OperationMasterRoles       = $((Get-ADDomainController).OperationMasterRoles)`n`r
    Database Path              = $((Get-ItemProperty -Path registry::HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\NTDS\Parameters -Name "DSA Working Directory")."DSA Working Directory")`n`r
    Log File Path              = $((Get-ItemProperty -Path registry::HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\NTDS\Parameters -Name "Database log files path")."Database log files path")`n`r
    Sysvol Path                = $((Get-ItemProperty -Path registry::HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\Netlogon\Parameters -Name "SysVol")."SysVol")`n`r
    Database file              = $((Get-ItemProperty -Path registry::HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\NTDS\Parameters -Name "DSA Database file")."DSA Database file")`n`r
    Volume Letter              = $($VolumeInfo.driveLetter)`n`r
    Volume Free Space          = $($VolumeInfo.freespace)`n`r
    Volume Capacity            = $($VolumeInfo.Capacity)`n`r
    Processor Cores            = $($ProcessorInfo.NumberOfCores)`n`r
    Processor Logical          = $($ProcessorInfo.NumberOfLogicalProcessors)`n`r
    Processor Make             = $($ProcessorInfo.Manufacturer)`n`r
    Memory Capacity            = $($MemoryInfo.Capacity)`n`r"
    
    New-Item $ADConfigFilePath -type file -force | Out-Null
	Set-Content -Path $ADConfigFilePath  $RecordAD

	Write-DSLog -Level info -Message "Configuration of AD Server is saved in the Text File : $ADConfigFilePath" -Verbose
    Remove-Indent -Footer "exit -> Save-ADServerConfig" # decrease indent in log file
}


#-------------------------------------------------------------------------------------
# installting directory services related critical hotfix for windows server 2012 R2
#-------------------------------------------------------------------------------------
Function Install-DSHotfix([string] $Hotfixlogpath) {
    Add-Indent -Header "enter -> Install-DSHotfix" # increase indent in log file
    if(Test-OSIsWindowsServer2012R2){$HotFixFolderPath = $(split-path -Path $PSScriptRoot) + "\Hotfix\W2K12R2"}
    if(Test-OSIsWindowsServer2012){$HotFixFolderPath = $(split-path -Path $PSScriptRoot) + "\Hotfix\W2K12R1"}
    if(Test-OSIsWindowsServer2008R2){
        #if((Get-WmiObject -Class win32_processor).Architecture -eq "6"){ $HotFixFolderPath = $(split-path -Path $PSScriptRoot) + "\Hotfix\W2K8R2\IA" }
        # Removed 14 Jan 16 (Tarun): because W2K8R2 SOE has no support for itanium based servers and our DSSOE is only suppose to run on a server provisioned with SOE.
        #else{
            $HotFixFolderPath = $(split-path -Path $PSScriptRoot) + "\Hotfix\W2K8R2\x64"
            #}
    }
    If(Test-OSIsWindowsServer2016) { $HotFixFolderPath = $(split-path -Path $PSScriptRoot) + "\Hotfix\W2K16" }

    New-Item -Path $Hotfixlogpath -ItemType "file" -Force | Out-Null #Create log file for hotfix installation logging
	
    #list of all hotfixes
        $HotFixes = Get-ChildItem -Path $HotFixFolderPath -Include *.msu -Recurse

        # enumerate through all hotfixes and install them after verifying that they're not already installed
        foreach($HF in $HotFixes) {
            #replace extension with blank in hotfix name, to make it hotfix id
            $HFID = $HF.Name -replace $HF.Extension,'' 

            if((Get-HotFix -Id $HFID -ErrorAction SilentlyContinue)) {
            Write-DSLog -Level info -Message "Security update $HFID is already installed, thus skiping it." -Verbose
                Add-Content -Value "Security update $HFID is already installed, thus skiping it." -Path $Hotfixlogpath
            }	
            else { 
            # The hotfix is not installed, installing the hofix.
            Write-DSLog -Level info -Message "Installing security update $HFID" -Verbose
            Add-Content -Value "Installing security update $HFID" -Path $Hotfixlogpath
            $output = Start-Process -FilePath WUSA.EXE -ArgumentList "`"$($hf.FullName)`" /quiet /norestart" -Wait -PassThru

            switch($output.exitcode)
                {
              
              0 {Add-Content -Value "Installation of Hotfix $HFID is successfull with exit code $($output.exitcode)" -Path $Hotfixlogpath}
              3010 {Add-Content -Value "Installation of Hotfix $HFID is successfull with exit code $($output.exitcode) . System reboot is required " -Path $Hotfixlogpath}
              default {Add-Content -Value "Installation of Hotfix $HFID failed with exit code $($output.exitcode)"}
                
                }
                                           
            }
        }
        Write-DSLog -Level info -Message "Hotfix installation routine is finished running" -Verbose
    Remove-Indent -Footer "exit -> Install-DSHotfix" # decrease indent in log file
}  


#-------------------------------------------------------------------------------------
# saving AD replication status in $ADReplFilePath; user provided file
#-------------------------------------------------------------------------------------
Function Save-ADReplicationStatus ($ADReplFilePath)
{
    Add-Indent -Header "enter -> Save-ADReplicationStatus" # increase indent in log file
    $RecordADReplStatus = Invoke-Command {cmd /c repadmin /showreps}
    New-Item $ADReplFilePath -type file -force | Out-Null
	Set-Content -Path $ADReplFilePath  $RecordADReplStatus
    Write-DSLog -Level info -Message "$ADReplFilePath file has been created, containing the Active Directory replication status" -Verbose
    Remove-Indent -Footer "exit -> Save-ADReplicationStatus" # decrease indent in log file
}


#-------------------------------------------------------------------------------------
# adding the DSSOE signatures in the registry key. GlobalVersion: 3.0.0 and LoadDateTime:
# (get-date) will be added as the signatures.
#-------------------------------------------------------------------------------------
Function Add-DSRegistrySignature
{
    Add-Indent -Header "enter -> Add-DSRegistrySignature" # increase indent in log file
    if(Test-Path -Path 'HKLM:\SOFTWARE\DXC'){$companycode = 'DXC'}else{$companycode = 'CSC'}
    $DSSOERegKey = New-Item -Path registry::HKEY_LOCAL_MACHINE\Software\$companycode\DSSOE -force
    Set-ItemProperty -Path registry::HKEY_LOCAL_MACHINE\Software\$companycode\DSSOE -Name GlobalVersion -Value '3.0.0'  -Type string
    Set-ItemProperty -Path registry::HKEY_LOCAL_MACHINE\Software\$companycode\DSSOE -Name LoadDateTime -Value (Get-Date)  -Type string
    Write-DSLog -Level info -Message "DSSOE registry signatures have been added." -Verbose
    Remove-Indent -Footer "exit -> Add-DSRegistrySignature" # decrease indent in log file
}


#-------------------------------------------------------------------------------------
# function will be fed with IP address and subnetmask and it will give back the network
# ID portion of the IP address, for example 192.168.10.0
#-------------------------------------------------------------------------------------
function Get-IPNetworkID ([string]$ipaddr, [string]$subnetmask) 
{
	$ipoctets = $ipaddr.split(".")
    $subnetoctets = $subnetmask.split(".")
	$result = ""
	
	for ($i = 0; $i -lt 4; $i++) {
		$result += $ipoctets[$i] -band $subnetoctets[$i]
		$result += "."
	}
	$result = $result.substring(0,$result.length -1)
	return $result
}


#-------------------------------------------------------------------------------------
# This function will convert the subnetmask to the masklength, for example 255.255.255.0
# will be converted to 24
#-------------------------------------------------------------------------------------
Function ConvertTo-MaskLength( [String]$subnetmask )
{     
 $IPMask = [Net.IPAddress]::Parse($subnetmask)   
 $Bits = "$( $IPMask.GetAddressBytes() | %{    
 [Convert]::ToString($_, 2) } )" -Replace "[\s0]"   
 Return $Bits.Length
} 


#-------------------------------------------------------------------------------------
# this function will associate the domain controller site to the appropriate subnet 
# notation. $Sitename can be default-first-site-name or a user provided custom site name
# subnet notation is calculated on the basis of IP address and subnet mask of the local
# server. This function will run by default in new domain new forest scenario.
#-------------------------------------------------------------------------------------
Function Set-SiteSubnetAssociation([string]$Sitename)
{
	Add-Indent -Header "enter -> Set-SiteSubnetAssociation" # increase indent in log file
    #Converting IP address and subnet mask info of the localmachine to subnet slash notification
	$NetworkAdapters = @(Get-wmiobject -class "Win32_NetworkAdapter" -computername (hostname) | Where { $_.netEnabled -eq "True" })
	for($i = 0;$i -lt $NetworkAdapters.count; $i++)
	{
	    $NetInterface = Get-WmiObject Win32_NetworkAdapterConfiguration | where-object {$_.InterfaceIndex -eq $NetworkAdapters[$i].InterfaceIndex}
		if(($netinterface.ipaddress -ne $null) -and ($netinterface.ipaddress -notlike "169.254.*"))
		{
		   $ipaddress = $netinterface.IPaddress
	       $subnetmask = $netinterface.IPSubnet
		}
	}
	#calling get-ipnetworkid function to store the network portion of the server's ip address in the variable
    $netwID = Get-IPNetworkID -ipaddr $ipaddress -subnetmask $subnetmask
    #calling convertto-masklength function to store the maskbits in the variable
    $startMaskLength = ConvertTo-MaskLength -subnetmask $subnetmask
    $subnetmaskslashnot =  $("$netwID/$startMaskLength")
    try
    {
        $AllForestinfo = new-object System.DirectoryServices.ActiveDirectory.DirectoryContext("Forest") 
        #new subnet is created and associated with the given site  	
        $subnet = new-object System.DirectoryServices.ActiveDirectory.ActiveDirectorySubnet($AllForestinfo,$subnetmaskslashnot,$Sitename)
	    $subnet.save()
        Write-DSLog -Level info -Message "Subnet: $subnetmaskslashnot is associated with the Site: $Sitename" -Verbose
    }
    catch
    {
        Write-DSLog -Level error -Message $_.Exception.Message
    }
    Remove-Indent -Footer "exit -> Set-SiteSubnetAssociation" # decrease indent in log file
}


#--------------------------------------------------------------------------------------------
# Function to associate a new subnet to existing site. This function will be used in all the
# scenario's except NewDomainNewForest
#--------------------------------------------------------------------------------------------
Function Set-NewSubnetSiteAssociation(
[string]$domain,
[string]$username,
[string]$password,
[string]$subnetmask,
[string]$sitename)
{
    Add-Indent -Header "enter -> Set-NewSubnetSiteAssociation" # increase indent in log file
    try
    {
        $AllForestinfo = new-object System.DirectoryServices.ActiveDirectory.DirectoryContext("Forest",$domain,$username,$password)
	    $subnet = new-object System.DirectoryServices.ActiveDirectory.ActiveDirectorySubnet($AllForestinfo,$subnetmask,$sitename) 
        $subnet.save()
        Write-DSLog -Level info -Message "$subnetmask subnet is created and associated with the $Sitename site"
    }
    catch
    {
        Write-DSLog -Level error -Message "$_.Exception.Message"
    }
    Remove-Indent -Footer "exit -> Set-NewSubnetSiteAssociation" # decrease indent in log file
}


#Reset the Reserve File creation if DC promotion is failed for any reason
# -----------------------------------------------------------------------
Function Reset-DSReserveFile([string]$Path) {
    Add-Indent -Header "enter -> Reset-DSReserveFile" # increase indent in log file
    if((Test-Path $Path) -eq $true) {
        [System.IO.File]::delete($Path)
        Write-DSLog -Level info -Message ("Existing reserve file deleted: " + $Path)
    }
    Remove-Indent -Footer "exit -> Reset-DSReserveFile" # decrease indent in log file
}

#region disable NetBIOS over TCP/IP
#-----------------------------------------------------------------------------------------
#This function will query and modify netBIOS over TCP settings
#-----------------------------------------------------------------------------------------
Function Reset-NetBIOSOverTCPIP {
Add-Indent -Header "enter -> Reset-NetBIOSOverTCPIP" # increase indent in log file
	try {
		$RegPath = "HKLM:\SYSTEM\CurrentControlSet\Services\NetBT\Parameters\Interfaces"
        $ColInterfaces = Get-ChildItem $RegPath | Select-Object Name,PSChildName
        $keyName = "NetBIOSOptions"
		
		$NetBiosDisableVal = "2"
		$NetBiosEnableVal = "0"
        
        #Set expected avlue based on defaultvalue
        # 0 - enabled, 2 - disabled
        $ExpectedValue = $NetBiosEnableVal;
            
        #Write-WCLog -Level info -Message "Setting NetBIOS over TCP to : $DefaultValue"

    	ForEach($Interface in $ColInterfaces) {
            #Write-DSLog -Level info -Message "Disabling NetBIOS over TCP/IP on $Interface.PSChildName"

            #Disable/Enable NetBIOS over TCP for all interfaces
	        Set-ItemProperty -Path "$RegPath\$($Interface.PSChildName)" -Name $keyName -Value $ExpectedValue -Type "DWord"
        }
        Remove-Indent -Footer "exit -> Reset-NetBiosOverTCPIP" # decrease indent in log file
        $return = "Success"
	}
	catch { $return =  "Error : $($_.Exception.Message)" }
	Remove-Indent -Footer "exit -> Reset-NetBiosOverTCPIP" # decrease indent in log file
	return $return
}
#endregion

# Function to Enable SMB1.0
# --------------------------------------
Function Reset-SMB1 (){
    Add-Indent -Header "enter -> Reset-SMB1" # increase indent in log file
    if(Test-OSIsWindowsServer2008R2) {
        Write-DSLog -Level info -Message "The server operating system is Windows Server 2008 R1 0r R2; setting the registry to enable SMB 1.0."
        Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" SMB1 -Type DWORD -Value 1 -Force
    }
    else {
        Write-DSLog -Level info -Message "enabling the SMB 1.0 via PowerShell cmdlet"
        Set-SmbServerConfiguration -EnableSMB1Protocol $true -Force
    }
    Remove-Indent -Footer "exit -> Reset-SMB1" # decrease indent in log file
}

# Function to reset RPC Port Range Restriction
# ---------------------------------------------------
Function Reset-TCPPort () {
    Add-Indent -Header "enter -> Reset-TCPPort" # increase indent in log file
    Write-DSLog -Level info -Message "deleting the Internet key in HKLM\Software\Microsoft\Rpc path"
    $InternetRegKey = Remove-Item -Path registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Rpc\Internet -force
    Write-DSLog -Level info -Message "Internet reg key deleted"
    Remove-Indent -Footer "exit -> Reset-TCPPort" # decrease indent in log file
}

#This function will separately call each of the reset function to reset the pre promotion
# configuration to their original face. This function is particularly being used to 
#revert the configuration in case of dcpromo failure
#-----------------------------------------------------------------------------------------   
Function Reset-DSPrePromotionOptions($DSReserveFile, [string]$ResFilePath,$ResetNetB,$ResetSMB,$ResetPort) {
    Add-Indent -Header "enter -> Reset-DSPrePromotionOptions" # increase indent in log file
    #If($DSstartupRecovery -eq "true") {
    #    Write-DSLog -Level info -Message "[dssoe] Reverting the startup and recovery options to default values"
    #    Reset-DSStartupAndRecovery
    #}    
    If($DSReserveFile -eq "true") {
        Write-DSLog -Level info -Message "Deleting the reserve file: $ResFilePath"
        Reset-DSReserveFile -Path $ResFilePath
    }
    if($ResetNetB -eq "True")
    {
    Write-DSLog -Level info -Message "Reseting Netbiosovertcpip"
    $retN = Reset-NetBiosOverTcpip
    }
    if($ResetSMB -eq "True")
    {
    Write-DSLog -Level info -Message "Reseting smb1"
    Reset-SMB1
    }
    if($ResetPort -eq "True")
    {
    Write-DSLog -Level info -Message "Reseting rpcport restrictions"
    Reset-TCPPort
    }
    Remove-Indent -Footer "exit -> Reset-DSPrePromotionOptions" # decrease indent in log file
}

# ------------------------------------------------------------------------------------------
# As per the switch parameter the function will return the value of either $true/$false or 
# Yes/No
# ------------------------------------------------------------------------------------------
Function Update-DSParams($Value,[switch]$boolvalue,[switch]$textvalue) {
    If($boolvalue) { #return the boolean values
        If($Value -eq "true") {
            return '$True'
        }
        Else {
            return '$False'
        }
    }
    If($textvalue) { # return the text values
        If($Value -eq "True") {
            return 'Yes'
        }
        Else {
            return 'No'
        } 
    }
}


# ----------------------------------------------------------------------------------
# This function is to enable the Active Directory recycle bin option
#-----------------------------------------------------------------------------------
Function Enable-DSADRecycleBin (
    [String] $Username,
    [String] $Password,
    [String] $Domain,
    [String] [ValidateSet("Domain","ForestOrConfigurationSet")] $ADRecycleBinScope,
    [String] $ADRecycleBinTargetServer,
    [string] $ADRecycleBinTargetDomain) {

    Add-Indent -Header "enter -> Enable-DSADRecycleBin" # increase indent in log file
    Import-Module ActiveDirectory #importing AD module
    
    # verifying if AD Recycle Bin is already enabled or not
    $ADRBStatus = (Get-ADOptionalFeature -Filter 'Name -like "Recycle Bin Feature"')
    # no value in EnabledScopes attributes implies that the AD recycle bin in not enabled
    If($($ADRBStatus.EnabledScopes) -eq $Null) {    
        
        #creating the credential object
        $Pwd = $Password | ConvertTo-SecureString -AsPlainText -Force
        $DomainNetBIOS = $Domain.Split('.')[0]
        $UserID = "$DomainNetBIOS\$Username"
        $Credentials = New-Object System.Management.Automation.PSCredential($UserID, $Pwd)

        try {
            #enabling AD recycle bin
            Enable-ADOptionalFeature -Credential $Credentials -Identity 'Recycle Bin Feature' -Scope $ADRecycleBinScope -Server $ADRecycleBinTargetServer -Target $ADRecycleBinTargetDomain -Confirm:$False
            Write-DSLog -Level info -Message "AD recycle bin feature is successfully enabled" -Verbose
        }
        Catch {
            # any error occurred will be caught in the catch block
            Write-DSLog -Level error -Message "An error occurred while enabling the AD recycle bin feature" -Verbose
            Write-DSLog -Level error -Message "$_.Exception.Message"
        }
    }
    Else {
        Write-DSLog -Level info -Message "AD Recycle Bin seems to be already enabled. Skipping the implementation via this function." -Verbose
    }
    Remove-Indent -Footer "exit -> Enable-DSADRecycleBin" # decrease indent in log file
}

Function Set-DSIPAMConfig($group,$server)
{

Add-Indent -Header "enter -> Set-IPAMConfig" # increase indent in log file
Import-Module ActiveDirectory #importing AD module

$gDomainname,$grpname = $group.Split("\")
$srvname,$sDomainname = $server.Split(".",2)
$srvname = $srvname+"$"



#Region Enable Firewall rules
try
{
    $FArray = @("RPC (TCP, Incoming)","DNS (UDP, Incoming)","DNS (TCP, Incoming)","RPC Endpoint Mapper (TCP, Incoming)","Remote Service Management (RPC-EPMAP)",`
    "Remote Service Management (NP-In)","Remote Service Management (RPC)","Remote Event Log Management (RPC-EPMAP)","Remote Event Log Management (RPC)")
    $Farray | % `
    {
        if($(Get-NetFirewallRule -DisplayName $_).Enabled -eq 'false')
        {
        Write-DSLog -Level Info -Message "Enabling Firewall rule $_" -Verbose
        $status = Set-NetFirewallRule -DisplayName $_ -Enabled True
        }
    }
    $count++
}
catch
{
    Write-DSLog -Level error -Message "Failed to enable firewall rule"
    Write-DSLog -Level error -Message "$($Error[0].Exception.Message)"
}

#End Region

#Region add ipam grp to Eventlog readers grp
try
{
    $Ipamgrp = Get-ADGroup -Identity $grpname -Server $gDomainname
    Write-DSLog -Level info -Message "Adding group $grpname to builtin\event log users group"
    Add-ADGroupMember -Identity "Event Log Readers" -Members $Ipamgrp
    $Ipamsrv = Get-ADComputer -Identity $srvname -Server $sDomainname
    Write-DSLog -Level info -Message "Adding server  $Ipamsrv to administrators group"
    Add-ADGroupMember -Identity "Administrators" -Members $Ipamsrv
}

catch
{
    Write-DSLog -Level error -Message "Error modifing group membership "
    Write-DSLog -Level error -Message "$($Error[0].Exception.Message)"
}

#End Region

#Region edit eventlog\dns server registry with ipam server SID
try
{
    $ipamSID = (Get-ADComputer -Identity $srvname -Server $sDomainname).SID
    $regpath = "HKLM:\SYSTEM\CurrentControlSet\Services\EventLog\DNS Server"
    $CValue = $(Get-ItemProperty $regpath -Name CustomSD).CustomSD
    $Cvalue = $Cvalue + "(A;;0x1;;;" + $ipamSID + ")"
    Write-DSLog -Level info -Message "Appending IPAM server SID to $regpath"
    Set-ItemProperty -Path $regpath -Name CustomSD -Value $Cvalue
}
catch
{
    Write-DSLog -Level error -Message "Error adding IPAM server SID to registry"
    Write-DSLog -Level error -Message "$($Error[0].Exception.Message)"
}
#End Region

#Region Set DNSmgmt rights
try
{
  $dnspath = "ActiveDirectory:://RootDSE/CN=MicrosoftDNS," + $(get-addomain -Current LocalComputer).SystemsContainer
    $acc = New-Object System.Security.Principal.NTAccount -ArgumentList $gDomainname,$grpname
    $ADR = [System.DirectoryServices.ActiveDirectoryRights]"ReadProperty, GenericExecute"
    $acontrol = [System.Security.AccessControl.AccessControlType]::Allow
    $accessRule = New-Object System.DirectoryServices.ActiveDirectoryAccessRule($acc,$ADR,$acontrol)
    $acl = get-acl -path $dnspath
    $acl.AddAccessRule($accessRule)
    Write-DSLog -Level info -Message "Adding AD rights to path $dnspath for group $grpname"
    Set-Acl -path $dnspath -AclObject $acl
}
catch
{
    Write-DSLog -Level error -Message "Error setting dnsmgmt rights to ipam group"
    Write-DSLog -Level error -Message "$($Error[0].Exception.Message)"
}
#End Region
Remove-Indent -Footer "exit -> Set-IpamConfig" # decrease indent in log file
}

# Function to Disable SMB1.0
# --------------------------------------
Function Disable-SMB1 ([switch]$Windows2008Server){
    Add-Indent -Header "enter -> Disable-SMB1" # increase indent in log file
    if($Windows2008Server) {
        Write-DSLog -Level info -Message "The server operating system is Windows Server 2008 R1 0r R2; setting the registry to disable SMB 1.0. The server requires a reboot for registry modification to take effect."
        Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" SMB1 -Type DWORD -Value 0 -Force
    }
    else {
        Write-DSLog -Level info -Message "Disabling the SMB 1.0 via PowerShell cmdlet"
        Set-SmbServerConfiguration -EnableSMB1Protocol $false -Force
    }
    Remove-Indent -Footer "exit -> Disable-SMB1" # decrease indent in log file
}

# Function to configure RPC Port Range Restriction
# ---------------------------------------------------
Function Enable-RPCPortRestriction ($PortRange) {
    Add-Indent -Header "enter -> Enable-RPCPortRestriction" # increase indent in log file
    Write-DSLog -Level info -Message "Adding the Internet key in HKLM\Software\Microsoft\Rpc path"
    $InternetRegKey = New-Item -Path registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Rpc\Internet -force
    Write-DSLog -Level info -Message "Internet reg key added"    
    Write-DSLog -Level info -Message "Adding the registry values to enable the RPC port range restriction: $PortRange"
    Set-ItemProperty -Path registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Rpc\Internet -Name Ports -Value $PortRange -Type MultiString
    Set-ItemProperty -Path registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Rpc\Internet -Name PortsInternetAvailable -Value Y -Type String
    Set-ItemProperty -Path registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Rpc\Internet -Name UseInternetPorts -Value Y -Type String
    Write-DSLog -Level info -Message "RPC port range restriction is added"
    Remove-Indent -Footer "exit -> Enable-RPCPortRestriction" # decrease indent in log file
}
