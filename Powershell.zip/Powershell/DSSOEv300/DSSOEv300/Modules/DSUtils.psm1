# This code module includes those functions that be shared across all DSSOE scripts
# Name  : DSUtils.psm1
# Author: Umesh Thakur, Tarun Rajvanshi & ArunKumar Bavirisetti
# Update Date  : 21-March-2017
# Copyright  : @Platform Wintel SOE, DXC. 
# ----------------------------------------------------------------------------------

# this function will return reporting log file name generated on given date/time stamp. 
# -------------------------------------------------------------------------------------
Function New-LogFileName($TimeStamp) {  
    return ($env:COMPUTERNAME + '-' + 'dssoe-' + $timeStamp + '.log')
}


# function to return whether current user is admin or not
# --------------------------------------------------------
Function Test-IsCurrentUserAdmin {
    $myIdentity = [System.Security.Principal.WindowsIdentity]::GetCurrent()
    $wp = New-Object Security.Principal.WindowsPrincipal($myIdentity)
    if (-not $wp.IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)) {
        return $false # current user has no administrative rights
    }
    else { return $true } # current user is admin
}

# This function will return true if server is a domain controller
# ----------------------------------------------------------------
function Test-ServerIsDC {
    $droles = (Get-WMIObject win32_computersystem).DomainRole
    if($droles -in (4,5)) { return $true } else { return $false }
}

# function to check whether given user account is local administrator or not
# credit: http://www.hanselman.com/blog/HowToDetermineIfAUserIsALocalAdministratorWithPowerShell.aspx
# do not use this function for DOMAIN accounts!!
# --------------------------------------------------------------------------
Function Test-IsUserLocalAdmin($UserName) { 
  $administratorsAccount = Get-WmiObject Win32_Group -filter "LocalAccount=True AND SID='S-1-5-32-544'" 
  $administratorQuery = "GroupComponent = `"Win32_Group.Domain='" + $administratorsAccount.Domain + "',NAME='" + $administratorsAccount.Name + "'`"" 
  $user = Get-WmiObject Win32_GroupUser -filter $administratorQuery | select PartComponent |where {$_ -match $UserName} 
  return ($user -is [object]) # if an admin entry is found for the user, $user will contain it. else, it will be null
}

# This function will check whether username is specified in DOMAIN\USER format
# -----------------------------------------------------------------------------
Function Test-DSUserNameFormat($UserName, $Separator = '\') {
    if([string]::IsNullOrEmpty($UserName)) { return $false }
    return ($UserName.split($Separator).count -eq 2)
}

# This function will return SOE version based on given version registry location
# -------------------------------------------------------------------------------
Function Get-SOEVersion {
[CmdletBinding()]
param([string] $RegistryPath = "HKLM:\Software\DXC\SOE", $KeyName="GlobalVersion")
    $rval = Get-ItemProperty -Path $RegistryPath -Name $KeyName -ErrorAction SilentlyContinue
    if($rval -ne $null) { $rval = $rval.$keyName }
    return $rval # it will return version as read from $keyName. if $keyName doesnt exist then it will return null
}


# ----------------------------------------------------------------
# This function will test whether given registry key exist or not
# KeyPath will be in [HKLM|HKCU]:\KeyPath\KeyPath\.. format
# ----------------------------------------------------------------
Function Test-RegistryKey([string]$KeyPath) {
    return ((Get-Item -Path $KeyPath -ErrorAction SilentlyContinue) -ne $null)
}


# ----------------------------------------------------------------
# This function will test whether given registry key Value exist or not
# KeyPath will be in [HKLM|HKCU]:\KeyPath\KeyPath\.. format and KeyName will be in value format
# ----------------------------------------------------------------
Function Test-RegistryValue([string] $Path,[string] $Name) {
	$retVal = Get-ItemProperty -Path $Path -Name $Name -ErrorAction SilentlyContinue;
	#if return Value is null then the key doesnt exists or value doesnt exists
	if($retVal -ne $null) { return $true; } 
	else { return $false;}
}


# ----------------------------------------------------------
# This function will return data of given registry value
# KeyPath will be in [HKLM|HKCU]:\KeyPath\KeyPath\.. format
# ----------------------------------------------------------
Function Get-RegistryValue([string]$KeyPath, [string]$ValueName, [switch] $ReturnBlankAsNotDefined) {
    try { 
        $regVal = (Get-ItemProperty -Path $KeyPath -Name $ValueName -ErrorAction Stop).$ValueName
        if([string]::IsNullOrEmpty($regVal) -and $ReturnBlankAsNotDefined) { 
            return 'NotDefined' 
        }
        else { return $regVal }
    }
    catch [System.Management.Automation.ItemNotFoundException], [System.Management.Automation.PSArgumentException] {
        return "NotExists"
    }
    catch [System.Security.SecurityException] { return "AccessDenied" }
    catch { return $_.CategoryInfo.Reason }
}


# --------------------------------------------------------------------------------------------
# This function will validate given credentials for different ContextType and return validated
# result (true/false). Function originally taken from DSSOE 210 and updated/optimized here
# ContextType can be of following types:
#                - ApplicationDirectory
#                - Domain
#                - Machine
# ---------------------------------------------------------------------------------------------
Function Test-DSCredentials(
    [System.DirectoryServices.AccountManagement.ContextType] $ContextType,
    [string] $ContextName,
    [string] $UserName,
    [string] $Password)
{
    Add-Indent -Header "enter -> Test-DSCredentials" # increase indent in log file
    # note: If DNS is not configured properly on the server where this code runs, error will be thrown

    # Load required assembly to peform validation
    Add-Type -AssemblyName System.DirectoryServices.AccountManagement

    try { # try to bind to the given context
        $pcontext = New-Object System.DirectoryServices.AccountManagement.PrincipalContext($ContextType,$ContextName)
        # Check to see if given credentials are valid.. function call will return true/false
        return $pcontext.ValidateCredentials($UserName,$Password)
    }
    catch {
        # todo: write to the log file instead of console
        Write-DSLog -Level info -Message "Failed to bind to $ContextName"
        Write-DSLog -Level info -Message $_.Exception.Message
        Remove-Indent -Footer "exit -> Test-DSCredentials" # decrease indent in log file
        return $false
    }
    Remove-Indent -Footer "exit -> Test-DSCredentials" # decrease indent in log file
}  


# -----------------------------------------------------
# Function to check if given password is complex or not
# -----------------------------------------------------
# Part of this function's code is taken from following article:
# http://scriptolog.blogspot.in/2008/01/validating-password-strength.html
Function Test-ComplexPassword {
    param(
        [string]$Password,
        [int]$minLength=8,
        [int]$numUpper = 1,
        [int]$numLower = 1,
        [int]$numNumbers = 1, 
        [int]$numSpecial = 1
    )

    $upper = [regex]"[A-Z]"
    $lower = [regex]"[a-z]"
    $number = [regex]"[0-9]"
    #Special is "none of the above"
    $special = [regex]"[^a-zA-Z0-9]"

    # Check the length.
    if($Password.length -lt $minLength) {$false; return}
    # Check for minimum number of occurrences.
    if($upper.Matches($Password).Count -lt $numUpper ) { return $false }
    if($lower.Matches($Password).Count -lt $numLower ) { return $false }
    if($number.Matches($Password).Count -lt $numNumbers ) { return $false }
    if($special.Matches($Password).Count -lt $numSpecial ) { return $false }

    # Passed all checks.
    return $true
}

# This function will return creds in format that dssoe require
# -------------------------------------------------------------
function Get-DSPassCode([string] $Code, $PassKey) {
    return (&"$PSScriptRoot\soecrypt.exe" decrypt $Code $PassKey).ToString()
}

#----------------------------------------------------------------------------------------
#Function to validate whether the local server is provisioned with one of the supported
# windows server SOE or not. The supported windows server SOE is 7.0.0 and above.
#----------------------------------------------------------------------------------------
Function Test-WindowsSOEVersion {
    Add-Indent -Header "enter -> Test-WindowsSOEVersion" # increase indent in log file
    Write-DSLog -Level info -Message "Validating Windows Server SOE version on server $($env:COMPUTERNAME)"
    #retrieve the globalversion key's value
    if((Test-path HKLM:\SOFTWARE\DXC\SOE) -eq 'True'){$SOEVersion = Get-ItemProperty -Path HKLM:\SOFTWARE\DXC\SOE -Name GlobalVersion -ErrorAction SilentlyContinue}
    else{$SOEVersion = Get-ItemProperty -Path HKLM:\SOFTWARE\CSC\SOE -Name GlobalVersion -ErrorAction SilentlyContinue}
    Write-DSLog -Level info -Message "Detected Windows Server SOE version is $($SOEVersion.GlobalVersion)"

    $isValidVer = $true # indiate that valid SOE version found

    #get the first 3 characters of the output
    $SV2 = ($SOEVersion.GlobalVersion).Substring(0,3)

    #error if value is empty
    If($SOEVersion.GlobalVersion -eq $null) {
        Write-DSLog -Level error -Message "Invalid version key - GlobalVersion key is null"
        $isValidVer = $false
    }
    If($SV2.length -lt 3) {
        Write-DSLog -Level error -Message "Invalid version key - The character length is less than 3"
        $isValidVer = $false
    }
    #checking if first 3 chars of the value is a double; if yes set (-as) the datatype as [double]
    if([double]::TryParse($SV2,[ref]$null)) {
        $SV = ($SV2 -as [double])
    }
    else {
        Write-DSLog -Level error -Message "Invalid version key - Ensure that the server you're trying to promote is built using a supported version of Windows Server SOE" 
        $isValidVer = $false
    }

    #7.0.0 is minimum Windows SOE requirement for DSSOE 3.0.0
    If(-not ($SV -ge 7.0)) {
        Write-DSLog -Level error -Message "Invalid version key - The supportable Windows SOE version key is 7.x.x or above"
        $isValidVer = $false
    }

    # at this point, this server is built using valid and supported windows server soe
    Remove-Indent -Footer "exit -> Test-WindowsSOEVersion" # decrease indent in log file
    return $isValidVer
}


#------------------------------------------------------------------------
# function will check if the baseline server is a virtual machine or not
# -----------------------------------------------------------------------
Function Test-IsServerVirtual
{
    Add-Indent -Header "enter -> Test-IsServerVirtual" # increase indent in log file
    #using wim class to retrieve the value of Model property
    $Model = (Get-WmiObject -Class "win32_computersystem").Model
    $Status = $null

    #if model property contains "VIRTUAL" then the system is a virtual machine else not
    If($Model.toupper().contains("VIRTUAL"))
    {
        Write-DSLog -Level info -Message "Server is a virtual machine"
        $Status = $true
    }
    else
    {
        Write-DSLog -Level info -Message "Server is a physical machine"
        $status = $false
    }
    #$status will return $true or $false based on above condition
    Remove-Indent -Footer "exit -> Test-IsServerVirtual" # decrease indent in log file
    return $Status
}


#-----------------------------------------------------------------------------
# This function will compare two given arrays and return whether second array
# is part of first array or not
# ----------------------------------------------------------------------------
Function Test-ListPartOf {
    param(
        [object[]] $SourceList, # source array to compare against
        [object[]] $CompareWith # check if this array is contained in $SourceList
    )

    # get common elements across both arrays (intersection)
    $res = Compare-Object -ReferenceObject $SourceList -DifferenceObject $CompareWith -ExcludeDifferent -IncludeEqual

    # return true/false based on comparison - whether 2nd array is part of first array or not
    return (($res.inputObject | Sort-Object) -join '') -eq (($CompareWith | Sort-Object) -join '')
} 


#-----------------------------------------------------------------------------
# Function to retrieve the size of the specified drive
#-----------------------------------------------------------------------------
Function Get-DriveSize(
$Drive)
{
 #call the WMI class for logical disk and retreive the size of the drive whose deviceID is equal to user's input 
 $Size = Get-WmiObject -Class Win32_LogicalDisk | Where-Object { $_.DeviceID -eq $Drive } | Select-Object Size
 #function will return the size in bytes
 Return $Size.Size
}


#-----------------------------------------------------------------------------
# Function to retrieve the free space on the specified drive
#-----------------------------------------------------------------------------
Function Get-DriveFreeSpace(
$Drive)
{
 #call the WMI class for logical disk and retreive the freespace of the drive whose deviceID is equal to user's input  
 $FreeSpace = Get-WmiObject -Class Win32_LogicalDisk | Where-Object { $_.DeviceID -eq $Drive } | Select-Object FreeSpace
 #function will return the freespace in bytes
 Return $Freespace.freespace
}


#-----------------------------------------------------------------
# Function to retrieve the schema version number of the forest
# ----------------------------------------------------------------
Function Get-ForestSchemaVersion(
[string]$domain,
[string]$username,
[string]$password)
{
    try {
        # get root domain naming context
        $rdom = New-Object -TypeName System.DirectoryServices.DirectoryEntry("LDAP://$domain/rootDSE",$username,$password)
        $rdom.RefreshCache() | Out-Null
        #write-host "rdom: $rdom"
        #connect to schema and get version
        $sch = New-Object -TypeName System.DirectoryServices.DirectoryEntry("LDAP://$domain/$($rdom.SchemaNamingContext)",$username,$password)
        $sch.RefreshCache() | Out-Null
        #write-host "schema: $($sch | select *)"
        return $sch.objectVersion
    }
    catch {
        # write to log, the error
        write-host "error: $($_)"
        Write-DSLog -Level info -Message $_.Exception.Message
        return $null
    }
}


#------------------------------------------------------------------
# Function to retrieve the Domain DNS Name of the forest root. This
# function will be particularly used to determine the root domain's
# FQDN for doing schema upgrade (adprep / forestprep)
#------------------------------------------------------------------
Function Get-ForestRootDomain(
[string]$Domain,
[string]$username,
[string]$password)
{
    #ldap path of the specified domain + rootdse. This will form the gateway to connect to the root domain
    $DomainLDAP = "LDAP://$Domain/RootDSE"
    #retrieving the root domain's properties
    $DomainInfo = New-Object -TypeName System.DirectoryServices.DirectoryEntry($DomainLDAP,$username,$password)
    #rootDomainNamingContext property stores the root domain name as a DN. -relace will convert the DN name to Domain DNS name.
    $Rootdomain = (($DomainInfo.rootDomainNamingContext -replace 'DC=','') -replace ',','.')
    #return the domain dns name
    return $Rootdomain
}

# this function will return operating system version number 
# 10.0 -> Windows Server 2016, 6.3 -> Windows Server 2012 R2
#  6.2 -> Windows server 2012, 6.1 -> Windows Server 2008 R2
# ----------------------------------------------------------
Function Get-OSVersion {
    #return only version part in x.y format, exclude build number
    # example: 10.0.14300 will be returned as 10.0
    return ((Get-WmiObject -Class win32_OperatingSystem).Version.split('.')[0..1] -join '.')
}

# Test if this operating system is Windows Server 2016 (True or False)
Function Test-OSIsWindowsServer2016 { return ((Get-OSVersion) -eq '10.0') }

# Test if this operating system is Windows Server 2012 R2 (True or False)
Function Test-OSIsWindowsServer2012R2 { return ((Get-OSVersion) -eq '6.3') }

# Test if this operating system is Windows Server 2012 (True or False)
Function Test-OSIsWindowsServer2012 { return ((Get-OSVersion) -eq '6.2') }

# Test if this operating system is Windows Server 2008 R2 (True or False)
Function Test-OSIsWindowsServer2008R2 { return ((Get-OSVersion) -eq '6.1') }

# this function will validate whether given drive letter has space as mentioned in dsInfo var
# -------------------------------------------------------------------------------------------
Function Test-DSDiskSpace($dsInfo) {
    Add-Indent -Header "enter -> Test-DSDiskSpace" # increase indent in log file    
    $driveLetter = $dsInfo.driveLetter # drive letter to check
    # error/warning/info messages to display below
    $dsDriveNotFound = "Could not find $driveLetter on this server. disk validation failed"
    $dsDriveLessThanRecommended = "$driveLetter size is less than recommended disk size $($dsInfo.ReccSize)"
    $dsDriveLessThanMinRequired = "$driveLetter size is less than minimum required disk size $($dsInfo.MinSize)"
    $dsDriveInsufficientFreeSpace = "$driveLetter has insufficient free disk space, required $($dsInfo.MinFree)"
    $dsDriveValidationSuccess = "$driveLetter disk validation successful"

    # get disk info for given disk
    Write-DSLog -Level info -Message "Looking for $driveLetter drive"
    $ldisk = Get-WmiObject -Class win32_LogicalDisk | where { $_.DriveType -eq 3 }
    $sdrive = $ldisk | Where-Object { $_.DeviceId -eq $driveLetter }
    if($sdrive -eq $null) { # given disk drive not found!
        Write-DSLog -Level error -Message $dsDriveNotFound
        Remove-Indent -Footer "exit -> Test-DSDiskSpace" # decrease indent in log file
        return $false
    }
    else { # check if drive has required free space and size
        Write-DSLog -Level info -Message "$driveLetter size is $($sdrive.size), free space is $($sdrive.freespace)"
        if($sdrive.Size -lt $dsInfo.ReccSize) { 
            Write-DSLog -Level warning -Message $dsDriveLessThanRecommended
        }
        elseif($sdrive.size -lt $dsInfo.MinSize) {
            Write-DSLog -Level warning -Message $dsDriveLessThanMinRequired
            Remove-Indent -Footer "exit -> Test-DSDiskSpace" # decrease indent in log file
            return $false
        }
        # check if free space meets requirement
        <#if($sdrive.freeSpace -lt $dsInfo.MinFree)
         {
            Write-DSLog -Level warning -Message $dsDriveInsufficientFreeSpace
            Remove-Indent -Footer "exit -> Test-DSDiskSpace" # decrease indent in log file
            return $false
        } 29-11-2016 removed as per new recommendations #>
        # at this point, validation is successful, return true
        Write-DSLog -Level info -Message $dsDriveValidationSuccess
        Remove-Indent -Footer "exit -> Test-DSDiskSpace" # decrease indent in log file
        return $true
    }
}

<# --- Disk Validation Notes ---
- if $ConfigADPathsToOSDrive parameter is used, create AD paths on the C: drive, 
  irrespective of what is chosen in the XML or whether CDE drives exist or not
- check if there are C D E partitions, if not write a warning in the log and continue
- if $configADpathstoOSdrive is not used and patitions are not as per recommendations, 
  then use the values in the XML file and configure them after validation
- check if partition size is as per the recommendation, if not write a warning in the log
- if partition size is lower than the minimum required size, write error and exit
- if free disk space on the partition is not appropriate, write error and exit
- different checks for windows server 2008 R2, Windows Server 2012 R1 & R2 and Windows Server 2016
#>
# this function will validate if DSSOE disk requirements are met
# return codes: an array of (true or false AND one of (0,1,2)
# 0 = ConfigADPathsToOSDrive, 1 = C,D,E drive, 2 = Drives from 
# XML used for validation
# --------------------------------------------------------------
Function Test-DSDiskRequirements(
    [cmdletbinding()]
    [Parameter(ParameterSetName="conf2osdrive")] [switch] $ConfigADPathsToOSDrive, 
    [Parameter(ParameterSetName="userpath")] [string] $ADDSPath, 
    [Parameter(ParameterSetName="userpath")] [string] $ADLogPath, 
    [Parameter(ParameterSetName="userpath")] [string] $ADSysvolPath) {

    Add-Indent -Header "enter -> Test-DSDiskRequirements" # increase indent in log file
    # define disk validation related errors/warnings
    $dsXmlDrivesNotFound = "Could not find all required disk drives"
    $dsDiskParamsNotProvided = "Could not find DSSOE recommended drives on the server and user has not provided parameters to check for other drives"

    # define space requirements for all drives
    $dinfo = '' | Select-Object DriveLetter,ReccSize,MinSize,MinFree
    $darray = New-Object System.Collections.ArrayList

    # for 3-disk requirement, here is validation array
    # drive letters will be added by respective code part
    if((Test-OSIsWindowsServer2012R2) -or (Test-OSIsWindowsServer2012)) {
        $dinfo2 = '' | Select-Object DriveLetter,ReccSize,MinSize,MinFree
        $dinfo2.ReccSize = 80gb; $dinfo2.MinSize = 35gb; $dinfo2.MinFree = 5gb # AD DB drive
        $darray.Add($dinfo2) | Out-Null
        $dinfo2 = '' | Select-Object DriveLetter,ReccSize,MinSize,MinFree
        $dinfo2.ReccSize = 10gb; $dinfo2.MinSize = 2gb; $dinfo2.MinFree = 1gb # AD Log drive
        $darray.Add($dinfo2) | Out-Null
        $dinfo2 = '' | Select-Object DriveLetter,ReccSize,MinSize,MinFree
        $dinfo2.ReccSize = 80gb; $dinfo2.MinSize = 5gb; $dinfo2.MinFree = 5gb # AD Sysvol drive
        $darray.Add($dinfo2) | Out-Null
    }
    elseif((Test-OSIsWindowsServer2008R2)) { # for w2k8R2 OS
        $dinfo2 = '' | Select-Object DriveLetter,ReccSize,MinSize,MinFree
        $dinfo2.ReccSize = 50gb; $dinfo2.MinSize = 35gb; $dinfo2.MinFree = 5gb # AD DB drive
        $darray.Add($dinfo2) | Out-Null
        $dinfo2 = '' | Select-Object DriveLetter,ReccSize,MinSize,MinFree
        $dinfo2.ReccSize = 5gb; $dinfo2.MinSize = 2gb; $dinfo2.MinFree = 1gb # AD Log drive
        $darray.Add($dinfo2) | Out-Null
        $dinfo2 = '' | Select-Object DriveLetter,ReccSize,MinSize,MinFree
        $dinfo2.ReccSize = 20gb; $dinfo2.MinSize = 5gb; $dinfo2.MinFree = 5gb # AD Sysvol drive
        $darray.Add($dinfo2) | Out-Null
    }
    elseif((Test-OSIsWindowsServer2016)) { # for Windows Server 2016 OS #29-11-2016 modified as per new recommendations
        $dinfo2 = '' | Select-Object DriveLetter,ReccSize,MinSize,MinFree
        $dinfo2.ReccSize = 80gb; $dinfo2.MinSize = 40gb; #$dinfo2.MinFree = 5gb # AD DB drive
        $darray.Add($dinfo2) | Out-Null
        $dinfo2 = '' | Select-Object DriveLetter,ReccSize,MinSize,MinFree
        $dinfo2.ReccSize = 10gb; $dinfo2.MinSize = 5gb; #$dinfo2.MinFree = 1gb # AD Log drive
        $darray.Add($dinfo2) | Out-Null
        $dinfo2 = '' | Select-Object DriveLetter,ReccSize,MinSize,MinFree
        $dinfo2.ReccSize = 80gb; $dinfo2.MinSize = 10gb; #$dinfo2.MinFree = 5gb # AD Sysvol drive
        $darray.Add($dinfo2) | Out-Null
    }

    # if user has provided switch to configure AD paths on systemDrive only then
    # populate object with systemDrive disk space requirements as per DSSOE recommendations
    if($ConfigADPathsToOSDrive) {
        if((Test-OSIsWindowsServer2012R2) -or (Test-OSIsWindowsServer2012)) {
            $dinfo.DriveLetter = $env:SystemDrive
            $dinfo.ReccSize = 100gb
            $dinfo.MinSize = 42gb
            $dinfo.MinFree = 11gb
        }
        elseif((Test-OSIsWindowsServer2008R2)) { # for w2k8R2 OS
            $dinfo.DriveLetter = $env:SystemDrive
            $dinfo.ReccSize = 75gb
            $dinfo.MinSize = 42gb
            $dinfo.MinFree = 11gb
        }
        elseif((Test-OSIsWindowsServer2016)) { # for Windows Server 2016 OS
            $dinfo.DriveLetter = $env:SystemDrive
            $dinfo.ReccSize = 100gb
            $dinfo.MinSize = 50gb
            #$dinfo.MinFree = 11gb #29-11-2016 removed as per new recommendations
        }

        # perform validation and return true/false
        Write-DSLog -Level info -message "Validating logical disk $($dinfo.DriveLetter)"
        $res = Test-DSDiskSpace -dsInfo $dinfo
        if($res -eq $false) { 
            Write-DSLog -Level error -message "overall disk validation failed, return false"
        }
        Remove-Indent -Footer "exit -> Test-DSDiskRequirements" # decrease indent in log file
        return ($res,0) # true or false
    }
    else { <# look for CDE drives and set disk requirements for them
        $ldisk = Get-WmiObject -Class win32_LogicalDisk | Where-Object { $_.DriveType -eq 3 }
        $res = $true # indicate that all C:, D: and E: drives were found
        # check if these drives are available on the server
        ('C:','D:','E:') | foreach { if($ldisk.deviceId -notcontains $_) { $res = $false} } #> 
        
        #Arun: Removed above as per team's discussion 14-12-2016
        $ldisk = Get-WmiObject -Class win32_LogicalDisk | Where-Object { $_.DriveType -eq 3 }
        $res = $false
        if($res -eq $false) { # not all of these drives are available
            # check if user has provided disk drive parameters
            if($ADDSPath -and $ADLogPath -and $ADSysvolPath) { # provided  by user
                $upRes = $true # assume that user provided drives (constructed below) exists
                $drives = ($ADDSPath.Substring(0,2), $ADLogPath.Substring(0,2), $ADSysvolPath.Substring(0,2))
                $drives | foreach { if($ldisk.deviceId -notcontains $_) { $upRes = $false} }

                # check if these drives are available on the server
                if($upRes -eq $false) { # not found, log warning/error
                    Write-DSLog -Level error -Message $dsXmlDrivesNotFound  
                    Write-DSLog -Level error -message "overall disk validation failed, return false"
                    Remove-Indent -Footer "exit -> Test-DSDiskRequirements" # decrease indent in log file
                    return ($false,2) # validation using XML values failed
                }
                else { # drives were matching/found C:, D: and E:
                    #todo: validate disk space requirements, set drive letters
                    $darray[0].DriveLetter = $drives[0]
                    $darray[1].DriveLetter = $drives[1]
                    $darray[2].DriveLetter = $drives[2]
                    foreach($d in $darray) {
                        Write-DSLog -Level info -message "Validating logical disk $($d.DriveLetter)"
                        $res = Test-DSDiskSpace -dsInfo $d
                        if($res -eq $false) { 
                            Write-DSLog -Level error -message "overall disk validation failed, return false"
                            Remove-Indent -Footer "exit -> Test-DSDiskRequirements" # decrease indent in log file
                            return ($res,2)
                        } # terminate on failed validation
                    }
                    # at this point, validation would be successful
                    Write-DSLog -Level info -message "overall disk validation is successful, return true"
                    Remove-Indent -Footer "exit -> Test-DSDiskRequirements" # decrease indent in log file
                    return ($true,2) # validation using XML values successful
                }
            }
            else { # user has not provided all input for disks to look for
                Write-DSLog -Level error -Message $dsDiskParamsNotProvided 
                Write-DSLog -Level error -message "overall disk validation failed, return false"
                Remove-Indent -Footer "exit -> Test-DSDiskRequirements" # decrease indent in log file
                return ($false,1) # validation failed
            }
        }
        else { <#  CDE drives found, do disk related validations
            #todo: validate disk space requirements
            $darray[0].DriveLetter = 'C:' 
            $darray[1].DriveLetter = 'D:'
            $darray[2].DriveLetter = 'E:'
            foreach($d in $darray) {
                Write-DSLog -Level info -message "Validating logical disk $($d.DriveLetter)"
                $res = Test-DSDiskSpace -dsInfo $d
                if($res -eq $false) { 
                    Write-DSLog -Level error -message "overall disk validation failed, return false"
                    Remove-Indent -Footer "exit -> Test-DSDiskRequirements" # decrease indent in log file
                    return ($res,1) # validation of CDE drives failed
                } # terminate on failed validation
            }
            # at this point, validation would be successful
            Write-DSLog -Level info -message "overall disk validation is successful, return true"
            Remove-Indent -Footer "exit -> Test-DSDiskRequirements" # decrease indent in log file
            return ($true,1) #> 
            #Arun: Removed as per team's discussion 14-12-2016
        }
    }
}

#region dsSchemaUpgrade related functions
# Test whether AD schema version upgrade is required based on given schema version
# --------------------------------------------------------------------------------
Function Test-DSSchemaUpgradeRequired($schemaVersion) {
    If((Test-OSIsWindowsServer2008R2 -eq $true) -and $schemaversion -lt 47) { return $true }
    If((Test-OSIsWindowsServer2012 -eq $true) -and $schemaversion -lt 56) { return $true }
    If((Test-OSIsWindowsServer2012R2 -eq $true) -and $schemaversion -lt 69) { return $true }
    If((Test-OSIsWindowsServer2016 -eq $true) -and $schemaversion -lt 87) { return $true }

    # if none of them match then return false
    return $false
}

# Upgrade AD schema utilizing supplied credentials
# -------------------------------------------------
function Invoke-DSSchemaUpgrade($Domain, $Username, $Password, $dcpromoselection) {
    Add-Indent -Header "enter -> Invoke-DSSchemaUpgrade" # increase indent in log file    
    $upgraded = ""                
    [string]$forestroot = Get-ForestRootDomain -Domain $Domain -username $Username -password $Password
    # do adprep /forestprep
    
    try {        
        Write-DSLog -Message "Starting the forest level schema upgrade"
        Invoke-Command {cmd /c c: "&" cd\support\adprep "&" adprep /forestprep /forest $forestroot /userDomain $xmldata.DSSOE.DCPromoOptions.$dcpromoselection.Domain /user $xmldata.DSSOE.DCPromoOptions.$dcpromoselection.UserName /Password $xmldata.DSSOE.DCPromoOptions.$dcpromoselection.Password /silent}
        Write-DSLog -Level info -Message "Forest level schema is upgraded successfully"
        $upgraded = $true 
    }
    catch { # catch any error and put in the log
        Write-DSLog -Level error -Message "Forest level schema upgrade failed`n$error[0].exception.message"
        $upgraded = $false
    }

    # do adprep / domainprep
    try {
        Write-DSLog -Message "Starting the domain level schema upgrade"
		Invoke-Command {cmd /c c: "&" cd\support\adprep "&" adprep /domainprep /Domain $xmldata.DSSOE.DCPromoOptions.$dcpromoselection.Domain /userDomain $xmldata.DSSOE.DCPromoOptions.$dcpromoselection.Domain /user $xmldata.DSSOE.DCPromoOptions.$dcpromoselection.UserName /Password $xmldata.DSSOE.DCPromoOptions.$dcpromoselection.Password /silent}
        Write-DSLog -Level info -Message "Domain level schema is upgraded successfully" 
        $upgraded = $true
    }
    catch
    {
        Write-DSLog -Level error -Message "Domain level schema upgrade failed`n$error[0].exception.message"
        $upgraded = $false
    }

    # do adprep /domainprep /gpprep
	try {
        Write-DSLog -Message "Starting the domain level group policy preparation upgrade"
        Invoke-Command {cmd /c c: "&" cd\support\adprep "&" adprep /domainprep /gpprep /Domain $xmldata.DSSOE.DCPromoOptions.$dcpromoselection.Domain /userDomain $xmldata.DSSOE.DCPromoOptions.$dcpromoselection.Domain /user $xmldata.DSSOE.DCPromoOptions.$dcpromoselection.UserName /Password $xmldata.DSSOE.DCPromoOptions.$dcpromoselection.Password /silent}
        Write-DSLog -Level info -Message "Domain level group policy preparation is upgraded successfully" 
        $upgraded = $true
    }
    catch
    {
        Write-DSLog -Level error -Message "Domain level Group policy preparation upgrade failed`n$error[0].exception.message"
        $upgraded = $false
    }
    Remove-Indent -Footer "exit -> Invoke-DSSchemaUpgrade" # decrease indent in log file
    # return the upgrade result
    return $upgraded
   
}

# Get forest mode numeric representation based on given mode text name for Windows Server 2008 R2
# ---------------------------------------------------------------------
Function Get-DSForestModeNumberW2k8R2($ForestModeString) {
    $htForestModes = @{
        "Windows2003Forest" = '2';
        "Windows2008Forest" = '3';
        "Windows2008R2Forest" = '4';
        "Windows2012Forest" = '5';
        "Windows2012R2Forest" = '6'
    }
    return $htForestModes[$ForestModeString]
}

# Get domain mode numeric representation based on given mode text name for Windows server 2008 R2
# ---------------------------------------------------------------------
Function Get-DSDomainModeNumberW2k8R2($DomainModeString) {
    $htDomainModes = @{
        "Windows2008Domain" = '3';
        "Windows2008R2Domain" = '4';
        "Windows2012Domain" = '5';
        "Windows2012R2Domain" = '6'
    }
    return $htDomainModes[$DomainModeString]
}

# Get forest mode representation based on given mode text name for Windows Server 2012 R1 & R2
# ---------------------------------------------------------------------
Function Get-DSForestModeNumberW2k12($ForestModeString) {
    $htForestModes = @{
        "Windows2003Forest" = 'Win2003';
        "Windows2008Forest" = 'Win2008';
        "Windows2008R2Forest" = 'Win2008R2';
        "Windows2012Forest" = 'Win2012';
        "Windows2012R2Forest" = 'Win2012R2';
    }
    return $htForestModes[$ForestModeString]
}

# Get domain mode numeric representation based on given mode text name for Windows server 2012 R1 & R2
# ---------------------------------------------------------------------
Function Get-DSDomainModeNumberW2k12($DomainModeString) {
    $htDomainModes = @{
        "Windows2008Domain" = 'Win2008';
        "Windows2008R2Domain" = 'Win2008R2';
        "Windows2012Domain" = 'Win2012';
        "Windows2012R2Domain" = 'Win2012R2';
    }
    return $htDomainModes[$DomainModeString]
}

# Get forest mode representation based on given mode text name for Windows Server 2012 R1 & R2
# ---------------------------------------------------------------------
Function Get-DSForestModeNumberW2k16($ForestModeString) {
    $htForestModes = @{
        "Windows2008Forest" = 'Win2008';
        "Windows2008R2Forest" = 'Win2008R2';
        "Windows2012Forest" = 'Win2012';
        "Windows2012R2Forest" = 'Win2012R2';
        "Windows2016Forest" = 'WinThreshold';
        #"Unknown" = 'WinThreshold'
    }
    return $htForestModes[$ForestModeString]
}

# Get domain mode numeric representation based on given mode text name for Windows server 2012 R1 & R2
# ---------------------------------------------------------------------
Function Get-DSDomainModeNumberW2k16($DomainModeString) {
    $htDomainModes = @{
        "Windows2008Domain" = 'Win2008';
        "Windows2008R2Domain" = 'Win2008R2';
        "Windows2012Domain" = 'Win2012';
        "Windows2012R2Domain" = 'Win2012R2';
        "Windows2016Domain" = 'WinThreshold';
        #"Unknown" = 'WinThreshold'
    }
    return $htDomainModes[$DomainModeString]
}

#endregion dsSchemaUpgrade related function

# this function will perform domain promotion based on given parameters
# it will also gather and process return code and handle any errors
# ----------------------------------------------------------------------
Function Start-DSDomainPromotion {
param(
    [cmdletbinding()]
    [Parameter(ParameterSetName="w2k8r2")] [string] $DCPromoParams, 
    [Parameter(ParameterSetName="w2k12")] [string] $ADDSCommand,
    [Parameter(ParameterSetName="w2K16")] [string] $W2K16ADDSCommand,
    $Credentials
    #[Parameter(ParameterSetName="w2k12")] [Parameter(ParameterSetName="w2k16")] $Credentials # for DSCredentials to work, $DCPromoParams or $ADDSCommand or $W2k16ADDSCommand sdhould include a placeholder _DSCREDS_ that will be replaced at runtime
)
    Add-Indent -Header "enter -> Start-DSDomainPromotion" # increase indent in log file
    # based on what user has provided, run specific promotion tasks
    if($DCPromoParams) { # w2k8r2 dcpromo options specified
        $rc,$code = Start-DomainPromotionW2K8R2 -DCPromoParams $DCPromoParams
      
              # get dcpromo exit code/message, log them and return true/false based on it
        $dcpExitCodeFile = "$PSScriptRoot\..\config\dcpromoExitCodes.csv"
        if(-not ([system.io.file]::Exists($dcpExitCodeFile))) { 
            Write-DSLog -Level info -Message "unable to read dcpromo exit code and messages from file"
        }
        else {
            $dcpCodes = Import-Csv -Delimiter "`t" -Path $dcpExitCodeFile
            $ec = $dcpCodes | where { $_.exitCode -eq $code }
            if($ec -ne $null) {
                Write-DSLog -Level info -Message "dcpromo exit code $($ec.ExitCode)"
                Write-DSLog -Level info -Message "dcpromo return message:"
                Write-DSLog -Level info -Message "$($ec.case) $($ec.description)"
            }
            else {
                Write-DSLog -Level info -Message "could not find dcpromo description for exit code $exit"
            }
        }
        
       

        # determine if it was successful or failed
        if($code -in (1..4)) {
            Write-DSLog -Level info -Message "domain promotion completed successfully"
            Remove-Indent -Footer "exit -> Start-DSDomainPromotion" # decrease indent in log file
            return $true
        }
        else {
            Write-DSLog -Level info -Message "domain promotion failed"
            Remove-Indent -Footer "exit -> Start-DSDomainPromotion" # decrease indent in log file
            return $false
        }
    }

    # w2k12/w2k12r2 ADDS command specified
    if($ADDSCommand) { 
        if($Credentials) { 
            $res = Start-DomainPromotionW2K12 -ADDSCommand $ADDSCommand -Credentials $Credentials
        }
        else {
            $res = Start-DomainPromotionW2K12 -ADDSCommand $ADDSCommand
        }
        
        # write return code/message in log
        Write-DSLog -Level info -Message "domain promotion returned context $($res.context)"
        Write-DSLog -Level info -Message "message: $($res.message)"
        Write-DSLog -Level info -Message "reboot required: $($res.RebootRequired)"
        Write-DSLog -Level info -Message "status: $($res.status)"
        
        # check to see if task was successful, last part of context contain return code, 1-4 are success
        if(($res.context.split('.')[-1] -in (1..4))) {
            Write-DSLog -Level info -Message "domain promotion successfuly completed"
            Remove-Indent -Footer "exit -> Start-DSDomainPromotion" # decrease indent in log file
            return $true # return success
        }
        else {
            Write-DSLog -Level info -Message "domain promotion failed. See above context and message for details"
            Remove-Indent -Footer "exit -> Start-DSDomainPromotion" # decrease indent in log file
            return $false # return failure
        }
    }
    
    # W2K16 ADDS command is specified
    if($W2K16ADDSCommand) { 
        if($Credentials) { 
            $res = Start-DomainPromotionW2K16 -ADDSCommand $W2K16ADDSCommand -Credentials $Credentials
        }
        else {
            $res = Start-DomainPromotionW2K16 -ADDSCommand $W2K16ADDSCommand
        }
        
        # write return code/message in log
        Write-DSLog -Level info -Message "domain promotion returned context $($res.context)"
        Write-DSLog -Level info -Message "message: $($res.message)"
        Write-DSLog -Level info -Message "reboot required: $($res.RebootRequired)"
        Write-DSLog -Level info -Message "status: $($res.status)"
        
        # check to see if task was successful, last part of context contain return code, 1-4 are success
        if(($res.context.split('.')[-1] -in (1..4))) {
            Write-DSLog -Level info -Message "domain promotion successfuly completed"
            Remove-Indent -Footer "exit -> Start-DSDomainPromotion" # decrease indent in log file
            return $true # return success
        }
        else {
            Write-DSLog -Level info -Message "domain promotion failed. See above context and message for details"
            Remove-Indent -Footer "exit -> Start-DSDomainPromotion" # decrease indent in log file
            return $false # return failure
        }
    }   
}

# this function will perform classic dcpromo operation on W2k8R2 server
# ---------------------------------------------------------------------
Function Start-DomainPromotionW2K8R2($DCPromoParams) {

    Add-Indent -Header "enter -> Start-DomainPromotionW2K8R2" # increase indent in log file
    # a function to remove password before the dcpromo line gets written to log
    # --------------------------------------------------------------------------
    Function Remove-PSSensitiveInfo($Text, $SensitiveText, $EndTextMarker) {
        $startIndex = $Text.IndexOf($SensitiveText)
        $endIndex = $Text.IndexOfAny($EndTextMarker,$startIndex+1)
        #write-verbose "StartIndex: $startIndex, endIndex: $endIndex)" -verbose
        if($endIndex -gt $startIndex -and ($startIndex -ne -1)) {
            #write-verbose "condition met, found text to replace" -verbose
            $strToRepl = $Text.SubString($startIndex, $endIndex - $startIndex)
            #write-verbose "String to replace is $strToRepl" -verbose
            return ($Text -Replace $strToRepl,($SensitiveText + '******** '))
        }
        else { return $Text }
    } # end function

    Write-DSLog -Level info -Message "W2K8R2 dcpromo option selected."
    Write-DSLog -Level info -Message "checking and installing AD-Domain-Services role if required."
    $addsSvcStat = (Get-WindowsFeature -Name ad-domain-services).InstallState
    if($addsSvcStat -ne 'installed') { # need to install
        Write-DSLog -Level info -Message "Installing AD-Domain-Services role"
        Add-WindowsFeature -Name AD-Domain-Services -LogPath c:\support\logs\dssoe\addsServiceInstall.log  
    }
    else { 
        Write-DSLog -Level info -Message "AD-Domain-Services role is already intalled"
    }
        
    # update any parameters value from true to yes and false to no. dcpromo requires them in this yes/no
    # format while dssoe xml file represent them as true/false
    #$DCPromoParams = $DCPromoParams -replace ':true',':yes'
    #$DCPromoParams = $DCPromoParams -replace ':false',':no'

    # write command in log for troubleshooting purposes
    Write-DSLog -Level info -Message "domain promotion command is"
    # remote pasword from dcpromo line before writing to log
    $dp2 = Remove-PSSensitiveInfo -Text $DCPromoParams -SensitiveText '/Password' -EndTextMarker '/'
    $dp2 = Remove-PSSensitiveInfo -Text $dp2 -SensitiveText '/safeModeAdminPassword:' -EndTextMarker '/'
    Write-DSLog -Level info -Message "dcpromo $dp2"

    Write-DSLog -Level info -Message "running domain promotion process"
        
    # start process to kick off dcpromo with given arguments. capture errors/output as well
    $dcproc = Start-Process -FilePath 'dcpromo.exe' -ArgumentList $DCPromoParams -PassThru `
                -NoNewWindow -RedirectStandardError 'C:\SUPPORT\Logs\dssoe\dcpromoErrors.txt' `
                -RedirectStandardOutput 'C:\SUPPORT\Logs\dssoe\dcpromoOutput.txt'
    # store process handle in a variable. it is weird but it helps in getting exitCode once process
    # has stopped execution. otherwise, exitCode is not returned!
    $dcprocHandle = $dcproc.Handle 
                  
    Write-DSLog -Level info -Message "dcpromo launched using specified params, process id $($dcproc.Id)"
    Write-DSLog -Level info -Message "waiting for dcpromo to finish.."
        
    $start = 1 # seconds elapsed
    $max = 900 # 900 seconds max tracking
    while($dcproc.HasExited -eq $false) { 
        # wait for dcpromo to finish, show some kind of progress based on 15minutes avg. time
        # taken for dcpromo to finish running
        $pc = [math]::Round(($start/$max)*100)
        if($pc -ge 100) { $pc = 99 } # to avoid erros and keep going until dcpromo finishes

        Write-Progress -Activity "DXC Directory Services SOE (DSSOE) Setup" -Status "Performing domain promotion" `
            -PercentComplete ($pc)
        Start-Sleep -Seconds 1
        $start = $start  + 1 # increase second by one
        if($start -eq $max) { 
            # max time reached, running unusually slow or hung!
            #todo: Tarun to provide opinion on how to handle this condition
        }
    }

    # dcpromo finshed running, 
    Start-Sleep -Seconds 3 # sleep for 3 seconds before finishing it up.. to capture exit code
    Write-DSLog -Level info -Message "dcpromo finished with exit code $($dcproc.ExitCode)"
    Remove-Indent -Footer "exit -> Start-DomainPromotionW2K8R2" # decrease indent in log file
    return "$($dcproc.ExitCode)"
}

# this function will perform classic dcpromo operation on W2k12 server
# ---------------------------------------------------------------------
Function Start-DomainPromotionW2K12($ADDSCommand, $Credentials) {
    Add-Indent -Header "enter -> Start-DomainPromotionW2K12" # increase indent in log file
    # remove safemodeadmin password from install-addomain command line before writing to log
    Function Remove-DSPassword([string]$DSInstallText) {
        $dsArray = $DSInstallText.Split(' ')
        $ptIndex = $dsArray.IndexOf('-asplaintext') # index of this text
        $changedText = ($dsArray -join ' ') -replace $dsArray[$ptIndex-1],'********'
        return $changedText
    }

    Write-DSLog -Level info -Message "W2K12/W2K12R2 domain promotion option selected."
    Write-DSLog -Level info -Message "checking and installing AD-Domain-Services role if required."

    # check if ad-domain-services role is already installed
    $addsSvcStat = (Get-WindowsFeature -Name ad-domain-services).InstallState
    if($addsSvcStat -ne 'installed') { # need to install
        Write-DSLog -Level info -Message "Installing AD-Domain-Services role"
        Add-WindowsFeature -Name AD-Domain-Services -IncludeManagementTools -LogPath c:\support\logs\dssoe\addsServiceInstall.log  
    }
    else { Write-DSLog -Level info -Message "AD-Domain-Services role is already intalled" }

    # update any parameters value from true to $true and false to $false as required by install-addsforest
    #$ADDSCommand = $ADDSCommand -replace ':true',':$true'
    #$ADDSCommand = $ADDSCommand -replace ':false',':$false'

    # write command in log for troubleshooting purposes
    Write-DSLog -Level info -Message "domain promotion command is"
    $ADDSCmdForLog = Remove-DSPassword -DSInstallText $ADDSCommand
    Write-DSLog -Level info -Message "$ADDSCmdForLog"

    $sb = [scriptblock]::Create($ADDSCommand)
    Write-DSLog -Level info -Message "running domain promotion process"
    $rc = Invoke-Command -ScriptBlock $sb
    Write-DSLog -Level info -Message "return object is $rc"
    Remove-Indent -Footer "exit -> Start-DomainPromotionW2K12" # decrease indent in log file
    return $rc
}

# ---------------------------------------------------------------------
# this function will perform classic dcpromo operation on W2k16 server
# ---------------------------------------------------------------------
Function Start-DomainPromotionW2K16($ADDSCommand, $Credentials) {
    Add-Indent -Header "enter -> Start-DomainPromotionW2K16" # increase indent in log file
    # remove safemodeadmin password from install-addomain command line before writing to log
    Function Remove-DSPassword([string]$DSInstallText) {
        $dsArray = $DSInstallText.Split(' ')
        $ptIndex = $dsArray.IndexOf('-asplaintext') # index of this text
        $changedText = ($dsArray -join ' ') -replace $dsArray[$ptIndex-1],'********'
        return $changedText
    }

    Write-DSLog -Level info -Message "W2K16 domain promotion option selected."
    Write-DSLog -Level info -Message "checking and installing AD-Domain-Services role if required."

    # check if ad-domain-services role is already installed
    $addsSvcStat = (Get-WindowsFeature -Name ad-domain-services).InstallState
    if($addsSvcStat -ne 'installed') { # need to install
        Write-DSLog -Level info -Message "Installing AD-Domain-Services role"
        Add-WindowsFeature -Name AD-Domain-Services -IncludeManagementTools -LogPath c:\support\logs\dssoe\addsServiceInstall.log  
    }
    else { Write-DSLog -Level info -Message "AD-Domain-Services role is already intalled" }

    # update any parameters value from true to $true and false to $false as required by install-addsforest
    #$ADDSCommand = $ADDSCommand -replace ':true',':$true'
    #$ADDSCommand = $ADDSCommand -replace ':false',':$false'

    # write command in log for troubleshooting purposes
    Write-DSLog -Level info -Message "domain promotion command is"
    $ADDSCmdForLog = Remove-DSPassword -DSInstallText $ADDSCommand
    Write-DSLog -Level info -Message "$ADDSCmdForLog"

    $sb = [scriptblock]::Create($ADDSCommand)
    Write-DSLog -Level info -Message "running domain promotion process"
    $rc = Invoke-Command -ScriptBlock $sb
    Write-DSLog -Level info -Message "return object is $rc"
    Remove-Indent -Footer "exit -> Start-DomainPromotionW2K16" # decrease indent in log file
    return $rc
}


#region Set auto-logon and post-promotion tasks kickoff
# ---------------------------------------------------------------
# This function will set autologon for dssoe post promotion tasks
# ---------------------------------------------------------------
Function Set-DSAutoLogon($UserName, $Password, $Domain) {
    # disable UAC
    Set-ItemProperty -Path HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\system -Name EnableLUA -Value 0 -Force -ErrorAction SilentlyContinue

    # Remove login banner texts 
    Set-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\policies\system -Name legalnoticecaption -Value '' -ErrorAction SilentlyContinue
    Set-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\policies\system -Name legalnoticetext -Value '' -ErrorAction SilentlyContinue

    # set autologon entry in registry
    $regWinLogon = 'HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Winlogon'
    Set-ItemProperty -Path $regWinLogon -Name 'DefaultDomainName' -Value $Domain
    Set-ItemProperty -Path $regWinLogon -Name 'DefaultUserName' -Value $UserName
    Set-ItemProperty -Path $regWinLogon -Name 'DefaultPassword' -Value $Password
    Set-ItemProperty -Path $regWinLogon -Name AutoAdminLogon -Value 1
    Set-ItemProperty -Path $regWinLogon -Name AutoLogonCount -Value 1

}

# ---------------------------------------------------------------
# This function will remove registry entries related to autologon 
# ---------------------------------------------------------------
Function Remove-DSAutoLogon {
    #Commenting the below since enabling of UAC is called explicitly whenever required, discussed with Tarun - Arun
    # enable UAC back 
    #Set-ItemProperty -Path HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\system -Name EnableLUA -Value 1 -Force -ErrorAction SilentlyContinue

    # remove auto-logon related registry entries
    $regWinLogon = 'HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Winlogon'
    Set-ItemProperty -Path $regWinLogon -Name 'LastUsedUserName' -Value '' 
    Set-ItemProperty -Path $regWinLogon -Name 'DefaultDomainName' -Value ''
    Set-ItemProperty -Path $regWinLogon -Name 'DefaultUserName' -Value ''
    Set-ItemProperty -Path $regWinLogon -Name 'DefaultPassword' -Value ''
    Set-ItemProperty -Path $regWinLogon -Name AutoAdminLogon -Value 0
    Set-ItemProperty -Path $regWinLogon -Name AutoLogonCount -Value 0

    # Login banner will be set of DSSOE post promotion tasks, no action required here
}


# ---------------------------------------------------------------------------------------------
# This function will set DSSOE Post Promotion Configuration Tasks to auto-run during next logon
# ---------------------------------------------------------------------------------------------
Function Set-DSPostRunEntry($ScriptPath, $EntryName) {
    Add-Indent -Header "enter -> Set-DSPostRunEntry" # increase indent in log file
    Write-DSLog -Level info -Message "Setting Run registry entry for $ScriptPath with the name of $EntryName"
    New-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run -Name $EntryName -PropertyType "String" -Value $ScriptPath -ErrorAction SilentlyContinue
    Remove-Indent -Footer "exit -> Set-DSPostRunEntry" # decrease indent in log file
}

# -------------------------------------------------------------------------------------
# This function will remove DSSOE Post Promotion Configuration Tasks from run registry
# -------------------------------------------------------------------------------------
Function Remove-DSPostRunEntry($EntryName) {
    Add-Indent -Header "enter -> Remove-DSPostRunEntry" # increase indent in log file
    Write-DSLog -Level info -Message "Removing Run registry entry for $EntryName"
    Remove-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run -Name $EntryName -ErrorAction SilentlyContinue
    Remove-Indent -Footer "exit -> Remove-DSPostRunEntry" # decrease indent in log file
}

#endregion

#region Call Post Promotion related functions
# ------------------------------------------------------------------
# This function will call functions related to post promotion tasks
# ------------------------------------------------------------------
Function Set-DSPostPromotionTasks {
param(
    $UserName, 
    $Password, 
    $Domain, 
    $DSInstallMode = 'standard', # standard or express are options
    $AnswerFile,
    $PassKey,
    [string]$ExportUnattendBuildFileTo
)
    
    # post launcher target location.. where dspost.cmd will be created
    $dsPostLauncher = 'c:\support\Logs\dssoe\dspost.cmd'
    
    # Set run registry entry using a cmd file.. if export param is given to add it as well
    if($ExportUnattendBuildFileTo.Length -ge 8) { # at least a file path like C:\A.XML
        $command = "`"&'$PSScriptRoot\dspost.ps1' -DSInstallMode $DSInstallMode -AnswerFile '$Answerfile' -PassKey $PassKey -ExportUnattendBuildFileTo $ExportUnattendBuildFileTo`""
    }
    else {
        $command = "`"&'$PSScriptRoot\dspost.ps1' -DSInstallMode $DSInstallMode -AnswerFile '$Answerfile' -PassKey $PassKey`""
    }

    "@echo off" | Out-File -FilePath $dsPostLauncher -Encoding ascii -Force #does not display command on screen
    "Powershell -executionPolicy Bypass -Command $command" | Out-File -FilePath $dsPostLauncher -Encoding ascii -Force -Append
    
    Set-DSPostRunEntry -ScriptPath $dsPostLauncher -EntryName 'DSSOE Post Promotion Tasks'

    # Set auto-logon in registry
    Set-DSAutoLogon -UserName $UserName -Password $Password -Domain $Domain 

    # reboot the server so that autologon happens and post promotion task is executed
   Shutdown -r -t 10 /c "DSSOE Setup need to restart this server to perform post-promotion configuration. This server will restart in 10 seconds."
}
#endregion


# ------------------------------------------------------------------
# This function copies entire folder from source to destination
# ------------------------------------------------------------------
Function Invoke-Copy($source,$destination){
    Add-Indent -Header "enter -> Invoke-Copy" # increase indent in log file
    if((Test-path -Path $source) -and (Test-path -Path $destination)) {
        Copy-Item $source -Destination $destination -Recurse -Force
        Write-DSLog -Level info -Message "Copying data from $source to $destination"
    }
    else {
        Write-DSLog -Level error -Message "error copying data from $source to $destination :Path not found"
    }
    Remove-Indent -Footer "exit -> Invoke-Copy" # decrease indent in log file
}
#endregion

#region disable NetBIOS over TCP/IP
#-----------------------------------------------------------------------------------------
#This function will query and modify netBIOS over TCP settings
#-----------------------------------------------------------------------------------------
Function Disable-NetBIOSOverTCPIP {
	try {
		$RegPath = "HKLM:\SYSTEM\CurrentControlSet\Services\NetBT\Parameters\Interfaces"
        $ColInterfaces = Get-ChildItem $RegPath | Select-Object Name,PSChildName
        $keyName = "NetBIOSOptions"
		
		$NetBiosDisableVal = "2"
		$NetBiosEnableVal = "0"
        
        #Set expected avlue based on defaultvalue
        # 0 - enabled, 2 - disabled
        $ExpectedValue = $NetBiosDisableVal;
            
        #Write-WCLog -Level info -Message "Setting NetBIOS over TCP to : $DefaultValue"

    	ForEach($Interface in $ColInterfaces) {
            #Write-DSLog -Level info -Message "Disabling NetBIOS over TCP/IP on $Interface.PSChildName"

            #Disable/Enable NetBIOS over TCP for all interfaces
	        Set-ItemProperty -Path "$RegPath\$($Interface.PSChildName)" -Name $keyName -Value $ExpectedValue -Type "DWord"
        }
        $return = "Success"
	}
	catch { $return =  "Error : $($_.Exception.Message)" }
	
	return $return
}
#endregion


# encrypt given string using given key and return back encrypted string (AES)
# -----------------------------------------------------------------------------
Function Protect-SOEString {
param(
    [parameter (mandatory="true")] [string] $String,
    #[string] $Key = [guid]::newGuid().Guid.Replace('-','')
    [parameter (mandatory="true")] [string] $Key
)

    # create encryption key that will be used for encryption purposes
    if($key.Length -notin (16,24,32)) {
        Write-Warning "Key length should be either 16 or 24 or 32."
        $null # return null on failure
    }
    try {
        $keyBytes = [System.Text.Encoding]::UTF8.GetBytes($key)
        $ss = $String | ConvertTo-SecureString -AsPlainText -Force -ErrorAction Stop
        $es = $ss | ConvertFrom-SecureString -Key $keyBytes -ErrorAction Stop
        #[pscustomobject]@{password=$es;key=$key} # return encrypted string
        $es # return encrypted string
    }
    catch { 
        write-warning $_.exception.message
        $null # return null on error
    }
}

# decrypt given string using given key and return back decrypted string
# ----------------------------------------------------------------------
Function Unprotect-SOEString {
param(
    [parameter (mandatory="true")] [string] $String,
    [parameter (mandatory="true")] [string] $Key
)

    # create encryption key that will be used for encryption purposes
    if($key.Length -notin (16,24,32)) {
        Write-Warning "Key length should be either 16 or 24 or 32."
        $null # return null on failure
    }
    
    try {
        $keyBytes = [System.Text.Encoding]::UTF8.GetBytes($key)
        $ss = $String | ConvertTo-SecureString -Key $keyBytes -ErrorAction Stop
        $bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($ss)
        $pp = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr)
        $pp
    }
    catch { 
        write-warning $_.exception.message
        $null # return null on error
    }
}

# ------------------------------------------------------------------------------------
# Identify whether the server installation Mode is ServerCore full or Minshell or Nano
# ------------------------------------------------------------------------------------
Function Get-OSInstallMode([Switch] $ShortName) {
    #https://msdn.microsoft.com/en-us/library/hh846315%28v=vs.85%29.aspx
	$ServerLevels = Get-Item "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Server\ServerLevels"

    # detect nano server install mode
	if($ServerLevels.GetValue("NanoServer") -eq "1") { $Mode  = "Nano" }
    # detect full GUI mode
	elseif(($ServerLevels.GetValue("Server-Gui-Shell") -eq "1") -and ($ServerLevels.GetValue("Server-Gui-Mgmt") -eq "1")) { 
        $Mode = "Server with a GUI (Full GUI)"
    }
    # detect Minimal Service Interface mode
	elseif($ServerLevels.GetValue("Server-Gui-Shell") -eq "1") { $Mode = "Minimal Server Interface" }
    # detect Server Core
	elseif($ServerLevels.GetValue("ServerCore") -eq "1") { $Mode = "Server Core" }
	
    # if user need short names, get short names of detect mode
	if($ShortName.IsPresent) {
		Switch($Mode) {
			"Server with a GUI (Full GUI)" { $Mode = "Full"; }
			"Server Core" { $Mode = "Core"; }
			"Minimal Server Interface" { $Mode = "Minshell"; }
            "Nano" { $Mode = "Nano" }
            # for nano, it will be "Nano" as above
		}
	}
	
    $Mode # return detected mode
}


# validate if SMB1.0 is already disabled on the server
# $true indicate that the SMB1.0 is disabled on the server
# $false is for otherwise
# ------------------------------------------------------
Function Get-ADDSSMB($dc = $env:COMPUTERNAME)
{
Add-Indent -Header "enter -> Get-ADDSSMB"
Write-dsLog -Level info -Message "Querying server $dc for smb1.0 value"
    try
    {
          $stdReg = Get-WmiObject -List -Namespace root\default -ComputerName $dc -ErrorAction SilentlyContinue | Where-Object {$_.Name -eq "StdRegProv"}
          $hklm = 2147483650
          $value = $stdReg.GetDWORDValue($hklm,"SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters","smb1").uValue
          if(($value -ne $null) -and ($value -eq 0))
          {
              Write-dsLog -Level info -Message "SMB1.0 value in registry is $value"
              return $true
              Remove-Indent -Footer "exit -> Get-ADDSSMB"
          }
          else
          {
              Write-dsLog -Level info -Message "SMB1.0 value in registry is either null or not zero"
              return $false
              Remove-Indent -Footer "exit -> Get-ADDSSMB"
          }
    }
    catch
    {
        return $false
        Remove-Indent -Footer "exit -> Get-ADDSSMB"
    }
}

# validate if netbios over tcpip is already disabled on the server
# $true indicates that the netbios over tcpip is disabled on all the NICs
# $false is for otherwise
# ------------------------------------------------------
Function Get-ADDSNetBStatus($dc = $env:COMPUTERNAME)
{
Add-Indent -Header "enter -> Get-ADDSNetBStatus"
Write-dsLog -Level info -Message "Querying dc $dc for netbios over tcp value"
try
{
      $stdReg = Get-WmiObject -List -Namespace root\default -ComputerName $dc -ErrorAction SilentlyContinue | Where-Object {$_.Name -eq "StdRegProv"}
      
      $hklm = 2147483650
      $regpath = "SYSTEM\CurrentControlSet\Services\NetBT\Parameters\Interfaces"
      $enumkey = $stdReg.EnumKey($hklm,$regpath)
      $count = 0
      $keyc = $enumkey.snames.count
      foreach($key in $enumkey.snames)
      {
      $val = $stdReg.GetDWORDValue($hklm,$regpath+"\"+$key,"NetBIOSOptions").uValue
          if($val -eq 2)
          {
          $count++
          }
      Write-dsLog -Level info -Message "Netbios over tcp value in key $key is $val"
      }
      if($count -eq $keyc){
        return $true
        Remove-Indent -Footer "exit -> Get-ADDSNetBStatus"
      }
      else{
        return $false
        Remove-Indent -Footer "exit -> Get-ADDSNetBStatus"
      }
}
catch
{
return $false
Remove-Indent -Footer "exit -> Get-ADDSNetBStatus"
}

}


# get the status of RPC port restriction registry keys.
# $true indicates the Cybersecurity recommendations for RPC port range restriction was used
# $false is for otherwise
# -----------------------------------------------------------
Function Get-ADDSRPCPortStatus($dc = $env:COMPUTERNAME)
{
Add-Indent -Header "enter -> Get-ADDSRPCPortStatus"
Write-dsLog -Level info -Message "Querying dc $dc for rpc port restriction status"
try
{

      $stdReg = Get-WmiObject -List -Namespace root\default -ComputerName $dc -ErrorAction SilentlyContinue | Where-Object {$_.Name -eq "StdRegProv"}
      
      $hklm = 2147483650
      $value = $stdReg.getmultistringvalue($hklm,"Software\Microsoft\Rpc\Internet","Ports").sValue
      if(($value -ne $null) -and ($value -eq '49152-49407'))
      {
      return $true
      Remove-Indent -Footer "exit -> Get-ADDSRPCPortStatus"
      }
      else
      {
      return $false
      Remove-Indent -Footer "exit -> Get-ADDSRPCPortStatus"
      }
}
catch
{
return $false
Remove-Indent -Footer "exit -> Get-ADDSRPCPortStatus"
}

}


# get the status of AD hotfixes on the server
# $true indicate that the AD hotfix option was selected at the time of build
# $false indicate that the AD hotfix option was not selected
# -------------------------------------------
Function Get-ADDSHotfixStatus()
{
    Add-Indent -Header "enter -> Get-ADDSHotfixStatus"
    try{
        if(Test-path -path 'C:\support\logs\dssoe\hotfix.log' -PathType Leaf){
            return $true
            Remove-Indent -Footer "exit -> Get-ADDSHotfixStatus"
        }
        else {
            return $false
            Remove-Indent -Footer "exit -> Get-ADDSHotfixStatus"
        }
    }
    catch {
        return $false
        Remove-Indent -Footer "exit -> Get-ADDSHotfixStatus"
    }
}

# get the status of Hardened UNC paths on server for wincompliance check(Indent and Logging not required)
# $true indicate that the path and value exists
# $false indicate that the path and value does not exists
# -------------------------------------------
Function Get-ADDSHardenedPath([switch]$NetLogon,[switch]$sysvol)
{
$regpath = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\NetworkProvider\HardenedPaths'
$regvalue = Get-ItemProperty -Path $regpath
    if($NetLogon){$Hpath = "\\*\NETLOGON"}
    elseif($sysvol){$Hpath = "\\*\SYSVOL"}

    if($regvalue.$hpath -eq 'RequireMutualAuthentication=1,RequireIntegrity=1')
    {
    return $true
    }
    else
    {
    return $false
    }
}