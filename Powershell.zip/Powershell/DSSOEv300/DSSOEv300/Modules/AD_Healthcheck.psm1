# This code module includes those functions that are called during wincompliance inventory scan and few functions which are used for validation and reporting
# Name  : AD_HealthCheck.psm1
# Author: ArunKumar Bavirisetti
# Update Date  : 14-Feb-2017
# Copyright  : @Platform Wintel SOE, DXC. 
# ----------------------------------------------------------------------------------

#region ---validation functions---


# This function will return true if forest connection is successfull and sets global variables for credentials and forest info
# ----------------------------------------------------------------
Function Set-ADDSForest($Domain, $UserName, $Password)
{
    Add-Indent -Header "enter -> Set-ADDSForest"
    $domainContext = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext('domain', $Domain, $UserName, $Password)
    try {
        $domain = [System.DirectoryServices.ActiveDirectory.Domain]::GetDomain($domainContext)
        $forestFQDN = $Domain.Forest # fqdn of forest in which domain is member of
        $ForestContext = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext('forest', $forestFQDN, "$UserName@$Domain", $Password)
        $forest = [System.DirectoryServices.ActiveDirectory.Forest]::GetForest($ForestContext)
        # set forest object in the variable. Rest of the functions will use this var to get info
        $pwd = ConvertTo-SecureString -String $Password -AsPlainText -Force
        $Cred = New-Object System.Management.Automation.PSCredential("$domain\$username",$pwd)
        $Script:EntCred = $Cred
        $script:seForest = $forest
        Remove-Indent -Footer "exit -> Set-ADDSForest"
        return $true
        }
    catch {
        Write-DSLog -Level error -Message "[adhealthcheck]Failed to connect to domain $Domain using given credentials ($UserName)"
        Write-DSLog -Level error -Message $_.Exception.Message
         Remove-Indent -Footer "exit -> Set-ADDSForest"
        return $false
          }
     
}

Function Test-ADDSDomainExists($domain)
{
if(($domain -in $($script:seForest.Domains | select -ExpandProperty Name)) -or ($domain -eq 'All'))
{

return $true
}
else
{
return $false
}

}

Function Test-ADDSDomainValue($domainsToScan)
{
if($domainsToScan -ne "")
{
    $dArr = $domainsToScan.Split(",")
    if(($dArr.Count -gt 1) -and !($dArr -Contains "All"))
    {
      return $true  
    }
    elseif(($dArr.Count -eq 1) -and ($dArr -ne 'All'))
    {
    return $true
    }
    elseif(($darr.Count -eq 1) -and ($dArr -eq 'All'))
    {
    return $true
    }
    else
    {
    return $false
    }
}
else
{
return $false
}
}

#endregion ---validation functions



#region ---forest reporting---
Function Get-ADDSForestInfo()
{
Add-Indent -Header "enter -> Get-ADDSForestInfo"
try{
if($Script:seForest -ne $null)
{
$output=@()
$ReqArr = @("Name","DomainNamingMaster","SchemaMaster","ForestMode","Sites","Domains")
$rawdata = get-adforest -Server $Script:seForest.Name -Credential $Script:EntCred

$ReqArr | % {

if($rawdata.item($_).count -gt 1)
{
$jval = $rawdata.item($_) -join ", "
$output += Set-DSVariableProperty -name $_ -value $jval.tostring()
}
else
{
$output += Set-DSVariableProperty -name $_ -value $($rawdata.Item($_)).ToString()
}

}

#Get Schema version
$output += Set-DSVariableProperty -name "Schema Version" -value $(Get-ADObject -Credential $Script:EntCred $(Get-ADRootDSE -Server $Script:seForest.Name -Credential $script:EntCred).SchemaNamingContext -Property ObjectVersion -Server $Script:seForest.Name).ObjectVersion

#Get Tombstone value
$output += Set-DSVariableProperty -name "Tombstone lifetime (days)" -value $(Get-ADObject -Credential $Script:EntCred -Server $Script:seForest.Name "CN=Directory Service,CN=Windows NT,CN=Services,$((Get-ADRootDSE -Credential $Script:EntCred -Server $Script:seForest.Name).ConfigurationNamingContext)" -property tombstonelifetime).tombstonelifetime

#RecycleBin status
$RecFeature = Get-ADOptionalFeature -Credential $Script:EntCred -Filter 'name -like "Recycle Bin Feature"' -Server $Script:seForest.Name -ErrorAction SilentlyContinue
if($($RecFeature.EnabledScopes).Count -eq 0)
{
$output += Set-DSVariableProperty -name "AD RecycleBin status" -value "Disabled"
}
else
{
$output += Set-DSVariableProperty -name "AD RecycleBin status" -value "Enabled"
}

#SiteCount
$output += Set-DSVariableProperty -name "Site Count" -value $($seForest.Sites).Count

$output += Set-DSVariableProperty -name "Domain Count" -value ($seForest.Domains).Count



Export-html -output $output -header "Forest_Info" -folder $Script:seForest.Name
Remove-Indent -Footer "exit -> Get-ADDSForestInfo"
return $output

}
}
 catch
    {
    $obj = New-Object PSObject -Property @{Name = "Exception occured while quering for forest info"}
    Write-DSLog -Level error -Message "[adhealthcheck]Exception occured while quering for forest info"
    Write-DSLog -Level error -Message $_.Exception.Message
    Remove-Indent -Footer "exit -> Get-ADDSForestInfo"
    return $obj
    }
}



Function Get-ADDSTrustInfo()
{
Add-Indent -Header "enter -> Get-ADDSTrustInfo"
try{
if($Script:seForest -ne $null)
    {
        
        $alltrusts = @()
        [System.Collections.ArrayList]$output = @()
        Write-DSLog -Level info -Message "[adhealthcheck]Querying AD for list of trusts"
        $alltrusts = get-adtrust -Filter * -Server $Script:seForest.Name -Credential $Script:EntCred
        $alltrusts | % {
        Write-DSLog -Level info -Message "[adhealthcheck]Building report for ADtrust:$($_.Name)"
        $obj = New-Object PSObject -Property ([ordered]@{            
        Trust_Name =  $_.Name                
        Source_Domain = $($_.Source -replace "DC=","" -replace ",",".")
        Target_Domain = $_.Target
        Direction_of_Trust = $_.Direction
        Trust_type = $_.TrustType
        Selective_Authentication = $_.SelectiveAuthentication  
        SID_Filtering_Quarantined = $_.SIDFilteringQuarantined

                                      })
                                    
$output.Add($obj) | Out-Null

              }
        
        Export-html -output $output -header "Trust_Info" -folder $Script:seForest.Name
        Remove-Indent -Footer "exit -> Get-ADDSTrustInfo"
        return $output

    }
   } 
   catch
    {
    $obj = New-Object PSObject -Property @{Trust_Name = "Exception occured while quering for trust info"}
    Write-DSLog -Level error -Message "[adhealthcheck]Exception occured while quering for trust info"
    Write-DSLog -Level error -Message $_.Exception.Message
    Remove-Indent -Footer "exit -> Get-ADDSTrustInfo"
    return $obj
    }
}

Function Get-ADDSSites()
{
Add-Indent -Header "enter -> Get-ADDSSites"
try{
if($Script:seForest -ne $null)
    {
        $AllSites = @()
        [System.Collections.ArrayList]$Output = @()
        $AllSites = $seForest.Sites
        $AllSites | % {
        Write-DSLog -Level info -Message "[adhealthcheck]Building report for AD Site:$($_.Name)"
        $hash = [ordered]@{
        Site_Name =$_.Name
        InterSiteTopologyGenerator = $_.InterSiteTopologyGenerator
        BridgeheadServers = if($($_.BridgeheadServers).count -ne 0){if($($_.BridgeheadServers).count -gt 1){$_.BridgeheadServers -join ", "}else{$_.BridgeheadServers}}else{"None"}
        PreferredSmtpBridgeheadServers = if($($_.PreferredSmtpBridgeheadServers).count -ne 0){if($($_.PreferredSmtpBridgeheadServers).count -gt 1){$_.PreferredSmtpBridgeheadServers -join ", "}else{$_.PreferredSmtpBridgeheadServers}}else{"None"}
        PreferredRpcBridgeheadServers = if($($_.PreferredRpcBridgeheadServers).count -ne 0){if($($_.PreferredRpcBridgeheadServers).count -gt 1){$_.PreferredRpcBridgeheadServers -join ", "}else{$_.PreferredRpcBridgeheadServers}}else{"None"}
        }
        $obj = New-Object PSObject -Property $hash
      $Output.Add($obj) | Out-Null 
           
    }
    Export-html -output $output -header "Site_Info" -folder $Script:seForest.Name
    Remove-Indent -Footer "exit -> Get-ADDSSites"
    return $Output
    }
   }
    catch
    {
    $obj = New-Object PSObject -Property @{Site_Name = "Exception occured while querying for site info"}
    Write-DSLog -Level error -Message "[adhealthcheck]Exception occured while quering for site info"
    Write-DSLog -Level error -Message $_.Exception.Message
    Remove-Indent -Footer "exit -> Get-ADDSSites"
    return $obj
    }
}

Function Get-ADDSSiteLinks()
{
Add-Indent -Header "enter -> Get-ADDSSiteLinks"
try{
if($Script:seForest -ne $null)
{
    $slinks = @()
    [System.Collections.ArrayList]$Output = @()
    Write-DSLog -Level info -Message "[adhealthcheck] Querying AD for all the available site links"
    $slinks = Get-adobject -Credential $Script:EntCred -LDAPFilter "(objectclass=sitelink)" -SearchBase $($seForest.Schema -replace ("CN=Schema,","")) -Properties *
    $slinks | % {
    Write-DSLog -Level info -Message "[adhealthcheck] building report for site link $($_.Name)"
    $hash = [ordered]@{
    Site_Link = $_.Name
    Cost = $_.Cost
    Replication_Interval = $_.replInterval
    Type = $_.instanceType
    Site_list = $($_.SiteList | % {$_ -split ",",2 -replace "CN=","" | select -Index 0}) -join ","
     }
   $obj = New-Object PSObject -Property $hash
   $Output.Add($obj) | Out-Null 
     
    }
    Export-html -output $output -header "SiteLinks_Info" -folder $Script:seForest.Name
    Remove-Indent -Footer "exit -> Get-ADDSSiteLinks"
    return $Output
        }
   }
    catch
    {
    $obj = New-Object PSObject -Property @{Site_Link = "Exception occured while fetching report for site links"}
    Write-DSLog -Level error -Message "Exception occured while fetching report for site links"
    Write-DSLog -Level error -Message $_.Exception.Message
    Remove-Indent -Footer "exit -> Get-ADDSSiteLinks"
    return $obj
    }
}

Function Get-ADDSNtdsConnection()
{
Add-Indent -Header "enter -> Get-ADDSNtdsConnection"
try{
if($Script:seForest -ne $null)
{
    $nconnections = @()
    [System.Collections.ArrayList]$Output = @()
    Write-DSLog -Level info -Message "[adhealthcheck] Querying AD for all the available sites"
    $sites = Get-adobject -Credential $Script:EntCred -Filter {objectclass -eq 'site'} -SearchBase $($seForest.Schema -replace ("CN=Schema,","")) -Properties * -ErrorAction SilentlyContinue
    $sites | % {
    $NTDSConnection= Get-ADObject -Credential $Script:EntCred -SearchBase $_ -Filter {ObjectClass -eq 'nTDSConnection'} -Properties *
    foreach($conc in $NTDSConnection)
        {
        Write-DSLog -Level info -Message "[adhealthcheck] building report for NTDS Connection $($conc.CN)"
        $hash = [ordered]@{
        ConnectionName = $conc.CN
        Source_DC = $($conc.FromServer -split ",",3 -replace "CN=","" | select -Index 1)
        Destination_DC = $($conc.distinguishedname -split ",",4 -replace "CN=" | select -Index 2)
        Type = $conc.InstanceType
                 }
        $obj = New-Object PSObject -Property $hash
        $Output.Add($obj) | Out-Null 
       
       }
    }
   Export-Html -output $Output -header "NTDS Connection" -folder $Script:seForest.Name
   Remove-Indent -Footer "exit -> Get-ADDSNtdsConnection"
   return $Output 
    }
   } catch
    {
    $obj = New-Object PSObject -Property @{ConnectionName = "Exception occured while quering for NTDS Connections"}
    Write-DSLog -Level error -Message "Exception occured while quering for trust info"
    Write-DSLog -Level error -Message $_.Exception.Message
    Remove-Indent -Footer "exit -> Get-ADDSNtdsConnection"
    return $obj
    }
}

Function Get-ADDSSiteSubnet()
{
Add-Indent -Header "enter -> Get-ADDSSiteSubnet"
try{

    $subnets = @()
    [System.Collections.ArrayList]$Output = @()
    Write-DSLog -Level info -Message "[adhealthcheck] Querying AD for all the available subnets"
    $subnets = Get-adobject -Credential $Script:EntCred -Filter {objectclass -eq 'subnet'} -SearchBase $($seForest.Schema -replace ("CN=Schema,","")) -Properties * -ErrorAction SilentlyContinue
    $subnets | % {
    Write-DSLog -Level info -Message "[adhealthcheck] building report for subnet $($_.Name)"
        $hash = [ordered]@{
        Subnet = $_.Name
        Location = $_.Location
        SiteName = $($_.SiteObject -split "," -replace "CN=","" | select -Index 0)
                     }
        $obj = New-Object PSObject -Property $hash
        $Output.Add($obj) | Out-Null
    
    }
    Export-Html -output $Output -header "Site_Subnets" -folder $Script:seForest.Name
    Remove-Indent -Footer "exit -> Get-ADDSSiteSubnet"
  return $Output
    
  }  catch
    {
    $obj = New-Object PSObject -Property @{Subnet = "Exception occured while quering for subnet info"}
    Write-DSLog -Level error -Message "Exception occured while quering for trust info"
    Write-DSLog -Level error -Message $_.Exception.Message
    Remove-Indent -Footer "exit -> Get-ADDSSiteSubnet"
    return $obj
    } 
}

Function Get-ADDSReplInfo()
{
    Add-Indent -Header "enter -> Get-ADDSReplInfo"
    try
    {
    [System.Collections.ArrayList]$Output = @()
    Write-DSLog -Level info -Message "[adhealthcheck] starting process to run repadmin with enterprise credentials"
    $proc = Start-Process -FilePath "C:\Windows\System32\repadmin.exe" -ArgumentList "/showrepl * /csv" -Credential $Script:EntCred -NoNewWindow -Wait -RedirectStandardOutput "$PSScriptRoot\output.csv"
    Write-DSLog -Level info -Message "[adhealthcheck] importing output csv file to read repadmin output"
    $var = Import-Csv "$PSScriptRoot\output.csv" | Select-Object -Property @{Name = "DestinationDSASite";Expression = {$_."Destination DSA Site"}},@{Name = "DestinationDSA";Expression = {$_."Destination DSA"}},@{Name = "NamingContext";Expression = {$_."Naming Context"}},@{Name = "SourceDSASite";Expression = {$_."Source DSA Site"}},@{Name = "SourceDSA";Expression = {$_."Source DSA"}},@{Name = "TransportType";Expression = {$_."Transport Type"}},@{Name = "NumberofFailures";Expression = {$_."Number of Failures"}},@{Name = "LastFailureTime";Expression = {$_."Last Failure Time"}},@{Name = "LastSuccessTime";Expression = {$_."Last Success Time"}},@{Name = "LastFailureStatus";Expression = {$_."Last Failure Status"}} -ExcludeProperty showrepl_COLUMNS -ErrorAction SilentlyContinue
    $Output.Add($var) | Out-Null
        if($Output.Count -gt 0)
        {
         Export-Html -output $var -header "AD_Replication" -folder $Script:seForest.Name
         Remove-Item -Path $PSScriptRoot\output.csv -Force
         Remove-Indent -Footer "exit -> Get-ADDSReplInfo"
         return $Output
        }
        else
        {
        $obj = New-Object PSObject -Property @{DestinationDSASite = "Information not found"}
        Remove-Indent -Footer "exit -> Get-ADDSReplInfo"
        return $obj
        }
    }
    catch
    {
    $obj = New-Object PSObject -Property @{DestinationDSASite = "Error fetching information"}
    Write-DSLog -Level error -Message "Exception occured while quering for replication info"
    Write-DSLog -Level error -Message $_.Exception.Message
    Remove-Item -Path $PSScriptRoot\output.csv -Force
    Remove-Indent -Footer "exit -> Get-ADDSReplInfo"
    return $obj
    }
}
#endregion ---forest reporting---

#region ---Domain reporting---
Function Get-ADDSGPO($Domain)
{

Add-Indent -Header "enter -> Get-ADDSGPO"
    try
    {
      
        [System.Collections.ArrayList]$Output = @()
        $DN = (Get-ADDomain -Credential $Script:EntCred -Identity $Domain -ErrorAction Stop).DistinguishedName
        Write-DSLog -Level info -Message "[adhealthcheck] Querying domain $domain for GPO list"
        Get-ADObject -Credential $Script:EntCred -Filter {ObjectClass -eq 'grouppolicycontainer'} -Properties * -Server $domain | % {
        $hash = [ordered]@{
                DisplayName = $_.Displayname
                DomainName = $Domain
                GPOStatus = $_.flags | % {Switch($_){0{"All Settings Enabled"} 1{"Computer Configuration Enabled"} 2{"User Configuration Enabled"} 3{"Disabled"}}}
                CreationTime = $_.whenCreated
                ModificationTime = $_.whenChanged
                           }
            $obj = New-Object PSObject -Property $hash
            $Output.Add($obj) | Out-Null
            }
    if($Output.Count -gt 0){
  $netb = $domain.split(".",2)[0]
  Export-Html -output $output -header "GPO_Info_$netb" -folder $domain
  Remove-Indent -Footer "exit -> Get-ADDSGPO"
  return $Output
  }
  else{$obj = New-Object PSObject -Property @{DisplayName = "Information not found"}
    Remove-Indent -Footer "exit -> Get-ADDSGPO"
    return $obj}
    }
    catch
    {
    $obj = New-Object PSObject -Property @{DisplayName = "Exception occured while quering for GPO"}
    Write-DSLog -Level error -Message "Exception occured while quering for trust info"
    Write-DSLog -Level error -Message $_.Exception.Message
    Remove-Indent -Footer "exit -> Get-ADDSGPO"
    return $obj
    }
  
 }

Function Get-ADDSEnforcedGPO($domain)
{
Add-Indent -Header "enter -> Get-ADDSEnforcedGPO"
try{
[System.Collections.ArrayList]$Output = @()
$flag = 0
$DN = (Get-ADDomain -Credential $Script:EntCred -Identity $Domain -ErrorAction Stop).DistinguishedName
Write-DSLog -Level info -Message "[adhealthcheck] Querying domain $domain for OU list"
$OUList = Get-ADObject -Credential $Script:EntCred -Filter {ObjectClass -eq 'organizationalUnit'} -Properties * -Server $Domain
foreach($ou in $oulist)
    {
    if($($ou.gplink).Count -gt 0)
        {
        $gpos = $($ou.gplink).split("][")
        $gpos = @($gpos | ? {$_})
        $gpos = $gpos | ? {-Not [string]::IsNullOrWhiteSpace($_)}
        
        foreach($gpo in $gpos)
            {
                           
              $gponame = $gpo.substring($($gpo.indexof("{")),($($gpo.indexof("}")) - $($gpo.indexof("{")))+1)
              $gpoprop = Get-ADObject -Credential $Script:EntCred -Filter {ObjectClass -eq 'grouppolicycontainer'} -Properties * -Server $Domain | Where-Object {$_.Name -eq $gponame}
              
              $gpstatus = $gpo.split(";")[1]
              
              Switch($gpstatus)
              {
              {($_ -eq "1") -or($_ -eq "0")}{$enforce = $false}
              {($_ -eq "2") -or($_ -eq "3")}{$enforce = $true}
              }
              
              if($enforce)
              {
              $flag++
              $hash = [ordered]@{
                OU_DistinguishedName = $ou.distinguishedname
                GPO_DisplayName = $gpoprop.displayname
                GPO_UniqueID = $gpoprop.Name
                                }
                $obj = New-Object PSObject -Property $hash
                $Output.Add($obj) | Out-Null
             
              
              }
                          
            }   
        }
    }
if($flag -gt 0)
    {
    $netb = $domain.split(".",2)[0]
    Export-Html -output $output -header "Enforced_GPO_$netb" -folder $domain
    Remove-Indent -Footer "exit -> Get-ADDSEnforcedGPO"
    return $Output
    }
    else
    {
    $obj = New-Object PSObject -Property @{OU_DistinguishedName = "No Enforced GPOs found"}
    Remove-Indent -Footer "exit -> Get-ADDSEnforcedGPO"
    return $obj
    }
   }catch
    {
    $obj = New-Object PSObject -Property @{OU_DistinguishedName = "Exception occured while quering for Enforced GPOs"}
    Write-DSLog -Level error -Message "Exception occured while quering for Enforced GPOs"
    Write-DSLog -Level error -Message $_.Exception.Message
    Remove-Indent -Footer "exit -> Get-ADDSEnforcedGPO"
    return $obj
    }
}



Function Get-DSDCDiskInfo($domain)
{
    Add-Indent -Header "enter -> Get-DSDCDiskInfo"
    try
    {
    [System.Collections.ArrayList]$Output = @()
    Write-DSLog -Level info -Message "[adhealthcheck] Generating list of Domain controllers in domain $domain"
    $dclist = Get-ADDomainController -Credential $Script:EntCred -Server $domain -filter *
    foreach($dc in $dclist)
    {
    Write-DSLog -Level info -Message "[adhealthcheck] Quering DC $dc for disk report"
    try{
    if($env:COMPUTERNAME -eq $dc.Name){$diskreport = Get-WmiObject -Class Win32_Logicaldisk -ComputerName $dc.Name -Filter "DriveType=3" -ErrorAction SilentlyContinue}
    else{$diskreport = Get-WmiObject -Class Win32_Logicaldisk -Credential $Script:EntCred -ComputerName $dc.Name -Filter "DriveType=3" -ErrorAction SilentlyContinue}
    $hash = [ordered]@{
                    Server = $dc.Name
                    Drive = $diskreport.DeviceID
                    Size = "{0:N1}" -f ($diskreport.size/1gb)
                    Freespace = "{0:N1}" -f ($diskreport.freespace/1gb)
                    Freespace_Percentage = "{0:P0}" -f ($diskreport.freespace/$diskreport.size)
                
                                    }
                    $obj = New-Object PSObject -Property $hash
                    $Output.Add($obj) | Out-Null
        }
        catch
        {
        Write-DSLog -Level error -Message "Exception occured while quering disk info on domain controller $dc"
        Write-DSLog -Level error -Message $_.Exception.Message
        }
     }
    if($output.Count -gt 0)
    {
    $netb = $domain.split(".",2)[0]
    Export-Html -output $output -header "DCDisk_Info_$netb" -folder $domain
    Remove-Indent -Footer "exit -> Get-DSDCDiskInfo"
    return $Output
    }
    else
    {
    $obj = New-Object PSObject -Property @{Server = "Exception occured while quering disk info on domain controllers"}
    Remove-Indent -Footer "exit -> Get-DSDCDiskInfo"
    return $obj
    }
   }
    catch
    {
    $obj = New-Object PSObject -Property @{Server = "Exception occured while quering disk info on domain controllers"}
    Write-DSLog -Level error -Message "Exception occured while quering disk info on domain controllers"
    Write-DSLog -Level error -Message $_.Exception.Message
    Remove-Indent -Footer "exit -> Get-DSDCDiskInfo"
    return $obj
    }
}

Function Get-ADDSDomainController($domain)
{
    Add-Indent -Header "enter -> Get-ADDSDomainController"
    try
    {
    [System.Collections.ArrayList]$Output = @()
     Write-DSLog -Level info -Message "[adhealthcheck] Generating list of Domain controllers in domain $domain"
    $dclist = Get-ADDomainController -Credential $Script:EntCred -Server $domain -Filter *
    foreach($dc in $dclist)
    {
       try{
              if($env:COMPUTERNAME -eq $dc.Name)
              {
               $wmibios = Get-WmiObject Win32_BIOS -ComputerName $dc.Name -ErrorAction SilentlyContinue | Select-Object version,serialnumber 
               $wmisystem = Get-WmiObject Win32_ComputerSystem -ComputerName $dc.Name -ErrorAction SilentlyContinue | Select-Object model,manufacturer
               $boottime = Get-WmiObject Win32_OperatingSystem -ComputerName $dc.Name -ErrorAction SilentlyContinue | select @{label = 'LastRebootOn';Expression = {$_.ConverttoDatetime($_.Lastbootuptime)}}
        }
        else{$wmibios = Get-WmiObject Win32_BIOS -Credential $Script:EntCred -ComputerName $dc.Name -ErrorAction SilentlyContinue | Select-Object version,serialnumber
             $wmisystem = Get-WmiObject Win32_ComputerSystem -Credential $Script:EntCred -ComputerName $dc.Name -ErrorAction SilentlyContinue | Select-Object model,manufacturer
             $boottime = Get-WmiObject Win32_OperatingSystem -Credential $Script:EntCred -ComputerName $dc.Name -ErrorAction SilentlyContinue | select @{label = 'LastRebootOn';Expression = {$_.ConverttoDatetime($_.Lastbootuptime)}}
             }
                    $IsVirtual = $false 
                    $VirtualType = $null 
                
                    if ($wmibios.SerialNumber -like "*VMware*") {
                       $IsVirtual = $true
                        $VirtualType = "Virtual - VMWare"
                    }
                    else {
                        switch -wildcard ($wmibios.Version) {
                            'VIRTUAL' { 
                                $IsVirtual = $true 
                                $VirtualType = "Virtual - Hyper-V" 
                            } 
                            'A M I' {
                                $IsVirtual = $true 
                                $VirtualType = "Virtual - Virtual PC" 
                            } 
                            '*Xen*' { 
                                $IsVirtual = $true 
                                $VirtualType = "Virtual - Xen" 
                            }
                        }
                    }
                    if (-not $IsVirtual) {
                        if ($wmisystem.manufacturer -like "*Microsoft*") 
                        { 
                            $IsVirtual = $true 
                            $VirtualType = "Virtual - Hyper-V" 
                        } 
                        elseif ($wmisystem.manufacturer -like "*VMWare*") 
                        { 
                            $IsVirtual = $true 
                            $VirtualType = "Virtual - VMWare" 
                        } 
                        elseif ($wmisystem.model -like "*Virtual*") { 
                            $IsVirtual = $true
                            $VirtualType = "Unknown Virtual Machine"
                        }
                    }
                
    
             
    $hash = [ordered]@{
                    Name = $dc.Name
                    OperatingSystem = $dc.OperatingSystem
                    GlobalCatalog = $dc.IsGlobalCatalog
                    OperationMasterRoles = $dc.OperationMasterRoles -join ","
                    IPv4Address = $dc.IPv4Address
                    Site = $dc.Site
                    IsVirtual = if($IsVirtual){"True"}else{"False"}
                    LastRebootOn = $boottime.LastRebootOn
                                    }
                    $obj = New-Object PSObject -Property $hash
                    $Output.Add($obj) | Out-Null


        }
        catch
        {
        Write-DSLog -Level error -Message "Exception occured while quering DC $dc"
        Write-DSLog -Level error -Message $_.Exception.Message
        }

   }
    if($output.Count -gt 0)
    {
    $netb = $domain.split(".",2)[0]
    Export-Html -output $output -header "DC_Info_$netb" -folder $domain
    Remove-Indent -Footer "exit -> Get-ADDSDomainController"
    return $Output
    }
    else
    {
    $obj = New-Object PSObject -Property @{Name = "Exception occured while quering for DC info"}
    Remove-Indent -Footer "exit -> Get-ADDSDomainController"
        return $obj
    }
    }
    catch
        {
        $obj = New-Object PSObject -Property @{Name = "Exception occured while quering for DC info"}
        Write-DSLog -Level error -Message "Exception occured while quering for DC info"
        Write-DSLog -Level error -Message $_.Exception.Message
        Remove-Indent -Footer "exit -> Get-ADDSDomainController"
        return $obj
        }

}

Function Get-ADDSOUStructure($domain)
{
Add-Indent -Header "enter -> Get-ADDSOUStructure"
Try
{

#Create a variable for the domain DN
$DomainDn = (Get-ADDomain -Credential $Script:EntCred -Identity $Domain -ErrorAction Stop).DistinguishedName

#Create an array to  contain our custom PS objects
$TotalOus = @()

Write-DSLog -Level info -Message "[adhealthcheck] Querying domain $domain for complete list of OUs"
$Ous = Get-ADOrganizationalUnit -Credential $Script:EntCred -Filter * -SearchScope Subtree -Server $Domain -Properties ParentGuid,gpoptions -ErrorAction SilentlyContinue | 
       Select Name,DistinguishedName,ParentGuid,gpoptions

#Check that we have some output
if ($Ous) {

    #Loop through each OU, create a custom object and add to $TotalOUs
    foreach ($Ou in $Ous){

        #Convert the parentGUID attribute (stored as a byte array) into a proper-job GUID
        $ParentGuid = ([GUID]$Ou.ParentGuid).Guid

        #Attempt to retrieve the object referenced by the parent GUID
        $ParentObject = Get-ADObject -Credential $Script:EntCred -Identity $ParentGuid -Server $Domain -ErrorAction SilentlyContinue

        #Check that we've retrieved the parent
        if ($ParentObject) {

            #Create a custom PS object
            $OuInfo = [PSCustomObject]@{

                Name = $Ou.Name
                DistinguishedName = $Ou.DistinguishedName
                ParentDN = $ParentObject.DistinguishedName
                DomainDN = $DomainDn
                BlockedGPOInheritance = if($ou.gpoptions -eq '1'){"True"}else{"False"}
                        
             }   #End of $Properties...


            $TotalOus += $OuInfo

            

       }   #End of if ($ParentObject)

    }   #End of foreach ($Ou in $Ous) 
$netb = $domain.split(".",2)[0]
Export-Html -output $TotalOus -header "OUInfo_$netb" -folder $domain
Remove-Indent -Footer "exit -> Get-ADDSOUStructure"
return $TotalOus
}   
Else {
$obj = New-Object PSObject -Property @{Name = "No OUs found"}
Remove-Indent -Footer "exit -> Get-ADDSOUStructure"
return $obj
}   

}
catch
        {
        $obj = New-Object PSObject -Property @{Name = "Exception occured while quering for OU info"}
        Write-DSLog -Level error -Message "Exception occured while quering for OU info"
        Write-DSLog -Level error -Message $_.Exception.Message
        Remove-Indent -Footer "exit -> Get-ADDSOUStructure"
        return $obj
        }

}

Function Get-ADDSPrivGrpMembers($domain)
{
Add-Indent -Header "enter -> Get-ADDSPrivGrpMembers"
    try
    {
        [System.Collections.ArrayList]$Output = @()
        if($($Script:seForest.RootDomain | select -ExpandProperty Name) -eq $domain){$privGrps = @("Schema Admins","Enterprise Admins","Domain Admins")}
        else{$privGrps = @("Domain Admins")}
        
        foreach($grp in $privGrps)
        {
        try{
        Write-DSLog -Level info -Message "[adhealthcheck] Querying $domain for group $grp"
        $userlist = get-adgroup -Credential $script:EntCred -Server $domain -Identity $grp | Get-ADGroupMember -Credential $script:EntCred -Server $domain -Recursive
        
        $userlist | % {
        $hash = [ordered]@{
                        UserName = $_.Name
                        UserDN = $_.DistinguishedName
                        Memberof = $grp
                          
                                }
                $obj = New-Object PSObject -Property $hash
                $Output.Add($obj) | Out-Null
                        }
          }
          catch
          {
          Write-DSLog -Level error -Message "Exception occured while quering group $grp in domain $domain"
          Write-DSLog -Level error -Message $_.Exception.Message
          }       
        }
        if($Output.Count -gt 0)
        {
        $netb = $domain.split(".",2)[0]
        Export-Html -output $output -header "Privgrp_Members_$netb" -folder $domain
        Remove-Indent -Footer "exit -> Get-ADDSPrivGrpMembers"
        return $output
        }
        else
        {
        $obj = New-Object PSObject -Property @{UserName = "Exception occured while quering for members of privilege groups"}
        Remove-Indent -Footer "exit -> Get-ADDSPrivGrpMembers"
        return $obj
        }

    }
    catch{
        $obj = New-Object PSObject -Property @{UserName = "Exception occured while quering for members of privilege groups"}
        Write-DSLog -Level error -Message "Exception occured while quering for group info"
        Write-DSLog -Level error -Message $_.Exception.Message
        Remove-Indent -Footer "exit -> Get-ADDSPrivGrpMembers"
        return $obj
        }
}

Function Get-ADPWDPolicy($domain)
{
Add-Indent -Header "enter -> Get-ADPWDPolicy"
try
{
[System.Collections.ArrayList]$output = @()
Write-DSLog -Level info -Message "[adhealthcheck] generating password policy for domain $domain"
$pwdpolicy = Get-ADDefaultDomainPasswordPolicy -Credential $Script:EntCred -Server $domain -ErrorAction SilentlyContinue
$hash = [ordered]@{     ComplexityEnabled = $pwdpolicy.ComplexityEnabled
                        LockoutDuration = $pwdpolicy.LockoutDuration
                        LockoutThreshold = $pwdpolicy.lockoutThreshold
                        MaxPasswordAge = $pwdpolicy.MaxPasswordAge
                        MinPasswordAge = $pwdpolicy.MinPasswordAge
                        MinimumPasswordLength = $pwdpolicy.MinPasswordLength
                        PasswordHistoryCount = $pwdpolicy.PasswordHistoryCount

                  }
                $obj = New-Object PSObject -Property $hash
                $Output.Add($obj) | Out-Null
                $netb = $domain.split(".",2)[0]
                Export-Html -output $output -header "PasswordPolicy_$netb" -folder $domain
                Remove-Indent -Footer "exit -> Get-ADPWDPolicy"
                return $output
}
catch{
        $obj = New-Object PSObject -Property @{ComplexityEnabled = "Exception occured while quering for password policy"}
        Write-DSLog -Level error -Message "Exception occured while quering for password policy"
        Write-DSLog -Level error -Message $_.Exception.Message
        Remove-Indent -Footer "exit -> Get-ADPWDPolicy"
        return $obj
        }
}
#endregion ---domain reporting---

#region ---Forest Recommendations---
Function Find-DSEmptySites()
{
Add-indent -Header "Enter --> Find-DSEmptySites"
try
{
[System.Collections.ArrayList]$Output = @()
$flag = 0
    if($script:seForest -ne $null)
    {
    $AllSites = @()
    $AllSites = Get-ADObject -Credential $script:EntCred -Filter {ObjectClass -eq 'site'} -SearchBase (Get-ADRootDSE -Credential $script:EntCred).configurationnamingcontext -Properties *
    #$AllSites = $seForest.Sites
    $AllSites | % {

        if(($_.Siteobjectbl).count -eq 0)
        {
            if($flag -eq 0)
                {
                $hash = [ordered]@{
                ProblemDescription = "OrphanedSites: Following sites has no subnets associated with it."
                SiteDNorSubnet = ""
                CurrentValue = ""
                                  }
                $obj = New-Object PSObject -Property $hash
                $Output.Add($obj) | Out-Null
                $flag++
                }
        $hash = [ordered]@{
        ProblemDescription = ""
        SiteDNorSubnet =$_.DistinguishedName
        CurrentValue = ""}
        $obj = New-Object PSObject -Property $hash
        $Output.Add($obj) | Out-Null
        }
                 }

    }
    if($Output.Count -gt 0)
    {
     Remove-Indent -Footer "Exit --> FindDSEmptySites"
    return $Output
   
    }
    else
    {
    $hash = [ordered]@{
            ProblemDescription = "OrphanedSites: No Recommendations. All sites are at recommended level"
            SiteDNorSubnet = ""
            CurrentValue = ""
                              }
            $obj = New-Object PSObject -Property $hash
            Remove-Indent -Footer "Exit --> FindDSEmptySites"
        return $obj
    }
}
catch
{
Write-DSLog -Level error -Message "Exception occured while quering for site info"
Write-DSLog -Level error -Message $_.Exception.Message
$hash = [ordered]@{
            ProblemDescription = "OrphanedSites: Exception occured while querying for information"
            SiteDNorSubnet = ""
            CurrentValue = ""
                              }
            $obj = New-Object PSObject -Property $hash
             Remove-Indent -Footer "Exit --> FindDSEmptySites"
        return $obj
}

}

Function Find-DSOrphanedSubnets()
{
Add-indent -Header "Enter --> Find-DSOrphanedSubnets"
try
{
    if($script:seForest -ne $null)
    {
    $AllSubnets = @()
    $flag = 0
    [System.Collections.ArrayList]$Output = @()
    $AllSubnets = Get-adobject -Credential $Script:EntCred -Filter {objectclass -eq 'subnet'} -SearchBase $($seForest.Schema -replace ("CN=Schema,","")) -Properties * -ErrorAction SilentlyContinue
    $AllSubnets | % {

        if(($_.siteobject).count -eq 0)
        {
            if($flag -eq 0)
            {
            $hash = [ordered]@{
            ProblemDescription = "OrphanedSubnets: Following subnets are not linked to any sites."
            SiteDNorSubnet = ""
            CurrentValue = ""
                              }
            $obj = New-Object PSObject -Property $hash
            $Output.Add($obj) | Out-Null
            $flag++
            }
        $hash = [ordered]@{
        ProblemDescription = ""
        SiteDNorSubnet =$_.cn
        CurrentValue = ""}
        $obj = New-Object PSObject -Property $hash
        $Output.Add($obj) | Out-Null
        }
                 }

    }
    if($Output.Count -gt 0)
    {
    Remove-Indent -Footer "Exit --> Find-DSOrphanedSubnets"
    return $Output
    }
    else
    {
    $hash = [ordered]@{
            ProblemDescription = "OrphanedSubnets: No Recommendations. All subnets are at recommended level"
            SiteDNorSubnet = ""
            CurrentValue = ""
                              }
            $obj = New-Object PSObject -Property $hash
            Remove-Indent -Footer "Exit --> Find-DSOrphanedSubnets"
        return $obj
    }
}
catch
{
Write-DSLog -Level error -Message "Exception occured while quering for subnet info"
Write-DSLog -Level error -Message $_.Exception.Message
$hash = [ordered]@{
            ProblemDescription = "OrphanedSubnets: Exception occured while querying for information"
            SiteDNorSubnet = ""
            CurrentValue = ""
                              }
            $obj = New-Object PSObject -Property $hash
            Remove-Indent -Footer "Exit --> Find-DSOrphanedSubnets"
        return $obj
    
}

}

Function find-ADDSKCCStatus()
{
Add-Indent -Header "Enter --> Find-ADDSKCCStatus"
try
{
$flag = 0
[System.Collections.ArrayList]$Output = @()
Add-Type -TypeDefinition @" 
                                   [System.Flags]
                                   public enum nTDSSiteSettingsFlags {
                                   NTDSSETTINGS_OPT_IS_AUTO_TOPOLOGY_DISABLED            = 0x00000001,
                                   NTDSSETTINGS_OPT_IS_TOPL_CLEANUP_DISABLED             = 0x00000002,
                                   NTDSSETTINGS_OPT_IS_TOPL_MIN_HOPS_DISABLED            = 0x00000004,
                                   NTDSSETTINGS_OPT_IS_TOPL_DETECT_STALE_DISABLED        = 0x00000008,
                                   NTDSSETTINGS_OPT_IS_INTER_SITE_AUTO_TOPOLOGY_DISABLED = 0x00000010,
                                   NTDSSETTINGS_OPT_IS_GROUP_CACHING_ENABLED             = 0x00000020,
                                   NTDSSETTINGS_OPT_FORCE_KCC_WHISTLER_BEHAVIOR          = 0x00000040,
                                   NTDSSETTINGS_OPT_FORCE_KCC_W2K_ELECTION               = 0x00000080,
                                   NTDSSETTINGS_OPT_IS_RAND_BH_SELECTION_DISABLED        = 0x00000100,
                                   NTDSSETTINGS_OPT_IS_SCHEDULE_HASHING_ENABLED          = 0x00000200,
                                   NTDSSETTINGS_OPT_IS_REDUNDANT_SERVER_TOPOLOGY_ENABLED = 0x00000400,
                                   NTDSSETTINGS_OPT_W2K3_IGNORE_SCHEDULES                = 0x00000800,
                                   NTDSSETTINGS_OPT_W2K3_BRIDGES_REQUIRED                = 0x00001000  }
"@
        ForEach($Site In (Get-ADObject -Credential $script:EntCred -Filter 'objectClass -eq "site"' -Searchbase (Get-ADRootDSE -Credential $script:EntCred).ConfigurationNamingContext)) 
        {            
            $SiteSettings = Get-ADObject -Credential $script:EntCred "CN=NTDS Site Settings,$($Site.DistinguishedName)" -Properties Options
            If(!$SiteSettings.PSObject.Properties.Match('Options').Count -OR $SiteSettings.Options -EQ 0)
            {  }
            elseif($SiteSettings.Options -in(1,16,17))
             {
                 if($flag -eq 0)
                {
                $hash = [ordered]@{
                ProblemDescription = "OrphanedSubnets: Following subnets are not linked to any sites."
                SiteDNorSubnet = ""
                CurrentValue = ""
                                  }
                $obj = New-Object PSObject -Property $hash
                $Output.Add($obj) | Out-Null
                $flag++
                }
             $hash = [ordered]@{ProblemDescription = ""
                           SiteDNorSubnet=$Site.DistinguishedName
                           CurrentValue=[nTDSSiteSettingsFlags]$SiteSettings.Options
                            }
            $obj = New-Object PSObject -Property $hash
            $Output.Add($obj) | Out-Null
             }
        }

    if($Output.Count -gt 0)
    {
    Remove-indent -footer "Exit --> Find-ADDSKCCStatus"
    return $Output}
    else{
    $hash = [ordered]@{
            ProblemDescription = "KCC Status: No recommendations. All sites have KCC enabled."
            SiteDNorSubnet = ""
            CurrentValue = ""
                              }
            $obj = New-Object PSObject -Property $hash
            Remove-indent -footer "Exit --> Find-ADDSKCCStatus"
        return $obj
    }
}
catch
{
Write-DSLog -Level error -Message "Exception occured while quering for site info"
Write-DSLog -Level error -Message $_.Exception.Message
$hash = [ordered]@{
            ProblemDescription = "KCC status: Exception occured while querying for information"
            SiteDNorSubnet = ""
            CurrentValue = ""
                              }
            $obj = New-Object PSObject -Property $hash
            Remove-indent -footer "Exit --> Find-ADDSKCCStatus"
        return $obj
}
}

Function Get-ADDSSitesandSubnets()
{

Add-Indent -Header "enter -> Get-ADDSSitesandSubnets"

    [System.Collections.ArrayList]$Output = @()
    $arr = New-Object pscustomobject
    Write-HCLog -Level info -Message "[adhealthcheck] Calling function to find empty sites in forest"
    $arr = Find-DSEmptySites
    $arr | % {$output.Add($_) | Out-Null}
    
    Write-HCLog -Level info -Message "[adhealthcheck] Calling function to check KCC status of sites in forest"
    $arr = find-ADDSKCCStatus
    $arr | % {$output.Add($_) | Out-Null}
    
    Write-HCLog -Level info -Message "[adhealthcheck] Calling function to find empty subnets in forest"
    $arr = Find-DSOrphanedSubnets
    $arr | % {$output.Add($_) | Out-Null}
      
    Export-html -output $output -header "Recommendations_SitesandSubnets" -folder $script:seForest.Name
    Remove-Indent -Footer "exit -> Get-ADDSSitesandSubnets"
    return $Output
   
}

Function Get-GenRecom()
{
Add-Indent -Header "Get-GenRecom"
    [System.Collections.ArrayList]$Output = @()
    try
    {
    Write-DSLog -Level info -Message "[adhealthcheck] Querying forest for FSMO roles"
    $forest = Get-ADForest -Credential $script:EntCred -Identity ($Script:seForest).Name
    if($forest.schemamaster -ne $forest.domainnamingmaster)
    {
    $hash = [ordered]@{
    ProblemDescription = "Domain Naming Master and Scheme master roles are not held by same server. It is recommended to have these roles on same server"
    CurrentValue = $($forest.schemamaster) + "," + $forest.domainnamingmaster
           }
    
    }
    else
    {
    $hash = [ordered]@{
    ProblemDescription = "Server roles: No recommendation. Schema master and Domain naming master and held by same DC as recommended."
    CurrentValue = $($forest.schemamaster)
           }
    }
    
    }
    catch
    {
    Write-DSLog -Level error -Message "Exception occured while quering FSMO roles"
    Write-DSLog -Level error -Message $_.Exception.Message
    $hash = [ordered]@{
    ProblemDescription = "Server roles: Exception occured while quering FSMO roles"
    CurrentValue = ""
    }
    }
    $obj = New-Object PSObject -Property $hash
    $Output.Add($obj) | Out-Null
    

    Write-DSLog -Level info -Message "[adhealthcheck] Querying forest for tombstone value"
    try
    {
    $tvalue = $(Get-ADObject -Credential $Script:EntCred -Server $Script:seForest.Name "CN=Directory Service,CN=Windows NT,CN=Services,$((Get-ADRootDSE -Credential $Script:EntCred -Server $Script:seForest.Name).ConfigurationNamingContext)" -property tombstonelifetime).tombstonelifetime
    if($tvalue -lt 180)
    {
    $hash = [ordered]@{
    ProblemDescription = "The resultant backup lifetime of forest should be greater than or equal to 180 days"
    CurrentValue = $tvalue
           }
    
    }
    else
    {
    $hash = [ordered]@{
    ProblemDescription = "Resultant backup lifetime: No Recommendations. Attribute is set to recommended value"
    CurrentValue = $tvalue
           }
    }
    }
    catch
    {
    Write-DSLog -Level error -Message "Exception occured while quering tombstone value"
    Write-DSLog -Level error -Message $_.Exception.Message
    $hash = [ordered]@{
    ProblemDescription = "Resultant backup lifetime: Exception occured while quering tombstone value"
    CurrentValue = ""
           }
    }
    $obj = New-Object PSObject -Property $hash
    $Output.Add($obj) | Out-Null
    
    Export-html -output $output -header "Recommendations_General" -folder $script:seForest.Name
    Remove-Indent -Footer "exit -> Get-GenRecom"
    return $Output
    
}

#endregion ---Forest Recommendations---

#region ---Domain Recommendations---


Function Find-ADDSOrphanedGPO($domain)
{
Add-Indent -Header "enter -> Find-ADDSOrphanedGPO"
try
{

$DomainDistinguishedName = (Get-ADDomain -Credential $Script:EntCred -Identity $Domain -ErrorAction Stop).DistinguishedName
[System.Collections.ArrayList]$Output = @()
$GPOPoliciesDN = "CN=Policies,CN=System,$DomainDistinguishedName"
$GPOPoliciesSYSVOLUNC = "\\$Domain\SYSVOL\$Domain\Policies"
Write-DSLog -Level info -Message "[adhealthcheck] Querying domain $domain for all the available GPOs"
$GPOPoliciesADSI = Get-ADObject -Credential $Script:EntCred -Filter {ObjectClass -eq 'grouppolicycontainer'} -Properties * -Server $domain
ForEach ($GPO in $GPOPoliciesADSI) { [array]$DomainGPOList += $GPO.Name }
$DomainGPOList = $DomainGPOList | sort-object
Write-DSLog -Level info -Message "[adhealthcheck] searching for policies in sysvol UNC path $GPOPoliciesSYSVOLUNC"
[array]$GPOPoliciesSYSVOL = Get-ChildItem $GPOPoliciesSYSVOLUNC
ForEach ($GPO in $GPOPoliciesSYSVOL) {If ($GPO.Name -ne "PolicyDefinitions") {[array]$SYSVOLGPOList += $GPO.Name }}
$SYSVOLGPOList = $SYSVOLGPOList | sort-object

Write-DSLog -Level info -Message "[adhealthcheck] Comparing policy list from both the locations for orphaned gpos"
# Check for GPTs in SYSVOL that don't exist in AD
[array]$MissingADGPOs = Compare-Object $SYSVOLGPOList $DomainGPOList -passThru | Where-Object { $_.SideIndicator -eq '<=' }

# Check for GPCs in AD that don't exist in SYSVOL
[array]$MissingSYSVOLGPOs = Compare-Object $DomainGPOList $SYSVOLGPOList -passThru | Where-Object { $_.SideIndicator -eq '<=' }

    If (($MissingADGPOs).Count -gt 0 ) 
    {
     $MissingADGPOs | % {
     
     $hash = [ordered]@{
     Name = $_
     Location = "Active Directory" }
     
     $obj = New-Object PSObject -Property $hash
     $Output.Add($obj) | Out-Null

                        }
    }
    

    If (($MissingSYSVOLGPOs).Count -gt 0 ) 
    {
     $MissingSYSVOLGPOs| % {
     $hash = [ordered]@{
                Name = $_
                Location = "SYSVOL"
                       }
            $obj = New-Object PSObject -Property $hash
            $Output.Add($obj) | Out-Null

                           }
    }

if((($MissingADGPOs).Count -eq 0) -and (($MissingSYSVOLGPOs).Count -eq 0))
{
$hash = [ordered]@{
                Name = "No Orphaned GPOs"
                Location = "No Orphaned GPOs"
                       }
            $obj = New-Object PSObject -Property $hash
            $Output.Add($obj) | Out-Null
            Remove-Indent -Footer "exit -> Find-ADDSOrphanedGPO"
            return $Output
}
else
{
$netb = $domain.split(".",2)[0]
Export-Html -output $output -header "Orphaned_GPO_$netb" -folder $domain
Remove-Indent -Footer "exit -> Find-ADDSOrphanedGPO"
return $Output
}
}catch
    {
    $obj = New-Object PSObject -Property @{Name = "Exception occured while quering for Orphaned GPOs"}
    Write-DSLog -Level error -Message "Exception occured while quering for Orphaned GPOs"
    Write-DSLog -Level error -Message $_.Exception.Message
    Remove-Indent -Footer "exit -> Find-ADDSOrphanedGPO"
    return $obj
    }
}

Function Get-ADDSDisabledGPO($domain)
{
Add-Indent -Header "enter -> Get-ADDSDisabledGPO"
try{
[System.Collections.ArrayList]$Output = @()
$flag = 0
$DN = (Get-ADDomain -Credential $Script:EntCred -Identity $Domain -ErrorAction Stop).DistinguishedName
Write-DSLog -Level info -Message "[adhealthcheck] Querying domain $domain for OU list"
$OUList = Get-ADObject -Credential $Script:EntCred -Filter {ObjectClass -eq 'organizationalUnit'} -Properties * -Server $Domain
foreach($ou in $oulist)
    {
    if($($ou.gplink).Count -gt 0)
        {
        $gpos = $($ou.gplink).split("][")
        $gpos = @($gpos | ? {$_})
        $gpos = $gpos | ? {-Not [string]::IsNullOrWhiteSpace($_)}
        foreach($gpo in $gpos)
            {
                            
              $gponame = $gpo.substring($($gpo.indexof("{")),($($gpo.indexof("}")) - $($gpo.indexof("{")))+1)
              $gpoprop = Get-ADObject -Credential $Script:EntCred -Filter {ObjectClass -eq 'grouppolicycontainer'} -Properties * -Server $domain | Where-Object {$_.Name -eq $gponame}
              if($gpoprop.flags -eq '3')
              {
              $flag++
              $hash = [ordered]@{
                OU_DistinguishedName = $ou.distinguishedname
                GPO_DisplayName = $gpoprop.displayname
                GPO_UniqueID = $gpoprop.Name
                                }
                $obj = New-Object PSObject -Property $hash
                $Output.Add($obj) | Out-Null
             
              
              }
                          
            }   
        }
    }
if($flag -gt 0)
    {
    $netb = $domain.split(".",2)[0]
    Export-Html -output $output -header "Disabled_GPO_$netb" -folder $domain
    Remove-Indent -Footer "exit -> Get-ADDSDisabledGPO"
    return $Output
    }
    else
    {
    $obj = New-Object PSObject -Property @{OU_DistinguishedName = "No Disabled GPOs found"}
    Remove-Indent -Footer "exit -> Get-ADDSDisabledGPO"
    return $obj
    }
   }catch
    {
    $obj = New-Object PSObject -Property @{OU_DistinguishedName = "Exception occured while quering for disabled GPOs"}
    Write-DSLog -Level error -Message "Exception occured while quering for disabled GPOs"
    Write-DSLog -Level error -Message $_.Exception.Message
    Remove-Indent -Footer "exit -> Get-ADDSDisabledGPO"
    return $obj
    }
}


Function Get-ADDSUnLinkedGPO($domain)
{
Add-Indent -Header "enter -> Get-ADDSUnLinkedGPO"
try{
[System.Collections.ArrayList]$Output = @()

$DN = $Script:seForest.RootDomain | select -ExpandProperty Name | Get-AdDomain | select -expandproperty DistinguishedName
$configDN = "CN=Configuration,"+$DN
Write-DSLog -Level info -Message "[adhealthcheck] Querying domain $domain for GPO list"
$GPOPoliciesADSI = Get-ADObject -Credential $Script:EntCred -Filter {ObjectClass -eq 'grouppolicycontainer'} -Properties * -Server $Domain
ForEach ($GPO in $GPOPoliciesADSI) { [array]$DomainGPOList += $GPO.Name }
$DomainGPOList = $DomainGPOList | sort-object
Write-DSLog -Level info -Message "[adhealthcheck] Querying domain $domain for GPO list at OU level"
[array]$linkedgpos = Get-ADObject -Credential $Script:EntCred -Filter {ObjectClass -eq 'organizationalUnit'} -Properties gplink -Server $Domain | select -ExpandProperty gplink
Write-DSLog -Level info -Message "[adhealthcheck] Querying domain $domain for GPO list at Domain level"
$linkedgpos += Get-ADObject -Credential $Script:EntCred -Filter {ObjectClass -eq 'domaindns'} -Properties gplink -Server $Domain | select -ExpandProperty gplink
Write-DSLog -Level info -Message "[adhealthcheck] Querying domain $domain for GPO list at site level"
$linkedgpos += Get-ADObject -Credential $Script:EntCred -Filter {ObjectClass -eq 'site'} -Properties gplink -SearchBase $configdn | select -ExpandProperty gplink
$linkedgpos = $linkedgpos | ? {-Not [string]::IsNullOrWhiteSpace($_)}
Foreach($gpo in $linkedgpos)
{
  $gpos = $gpo.split("][")
  $gpos = @($gpos | ? {$_})
  if($gpos.Count -ne '0'){  [array]$linkedgponame += $gpos | % {$_.substring($($_.indexof("{")),($($_.indexof("}")) - $($_.indexof("{")))+1) }}
}
$linkedgponame = $linkedgponame | Sort-Object
[array]$MissingADGPOs = Compare-Object $DomainGPOList $linkedgponame -passThru | Where-Object { $_.SideIndicator -eq '<=' } -ErrorAction SilentlyContinue
if($MissingADGPOs.Count -gt 0)
{
   foreach($mgpo in $MissingADGPOs)
   {
   $gpoprop = Get-ADObject -Credential $Script:EntCred -Filter {ObjectClass -eq 'grouppolicycontainer'} -Properties * | Where-Object {$_.Name -eq $mgpo}
   $hash = [ordered]@{
                GPO_DisplayName = $gpoprop.displayname
                GPO_UniqueID = $gpoprop.Name
                                }
                $obj = New-Object PSObject -Property $hash
                $Output.Add($obj) | Out-Null
   }
   $netb = $domain.split(".",2)[0]
   Export-Html -output $output -header "Unlinked_GPOs_$netb" -folder $domain
   Remove-Indent -Footer "exit -> Get-ADDSUnLinkedGPO"
   return $Output
    
    
}
else
    {
    $obj = New-Object PSObject -Property @{GPO_DisplayName = "No Unlinked GPOs found"}
    Remove-Indent -Footer "exit -> Get-ADDSUnLinkedGPO"
    return $obj
    }
  }catch
    {
    $obj = New-Object PSObject -Property @{GPO_DisplayName = "Exception occured while quering for Unlinked GPOs"}
    Write-DSLog -Level error -Message "Exception occured while quering for Unlinked GPOs"
    Write-DSLog -Level error -Message $_.Exception.Message
    Remove-Indent -Footer "exit -> Get-ADDSUnLinkedGPO"
    return $obj
    }
}


Function Find-ADDSEvents($domain)
{

Add-Indent -Header "enter -> Find-ADDSEvents"
try{
      [System.Collections.ArrayList]$output = @()
      Write-HCLog -Level info -Message "[adhealthcheck] generating DC list in domain $domain"
      $dclist = $seForest.Domains | % {if($_.Name -eq $domain){$_.DomainControllers | select -ExpandProperty Name}}
      foreach($dc in $dclist)
      {
      try
      {
      $evnt,$evnt1,$evnt2,$evnt3,$evnt4,$evnt5 = $null
      $evnt = Get-WinEvent -Credential $Script:EntCred -ComputerName $dc -MaxEvents 1 -FilterHashtable @{LogName = "system";ProviderName = "NetLogon";ID = 5774,5781} -ErrorAction SilentlyContinue
      $evnt1 = Get-WinEvent -Credential $Script:EntCred -ComputerName $dc -MaxEvents 1 -FilterHashtable @{LogName = "Directory Service";ProviderName = "Microsoft-Windows-ActiveDirectory_DomainService";ID = 1925} -ErrorAction SilentlyContinue
      $evnt2 = Get-WinEvent -Credential $Script:EntCred -ComputerName $dc -MaxEvents 1 -FilterHashtable @{LogName = "DFS Replication";ProviderName = "DFSR";ID = 4612} -ErrorAction SilentlyContinue
      $evnt3 = Get-WinEvent -Credential $Script:EntCred -ComputerName $dc -MaxEvents 1 -FilterHashtable @{LogName = "DFS Replication";ProviderName = "DFSR";ID = 5002} -ErrorAction SilentlyContinue
      $evnt4 = Get-WinEvent -Credential $Script:EntCred -ComputerName $dc -MaxEvents 1 -FilterHashtable @{LogName = "Directory Service";ProviderName = "Microsoft-Windows-ActiveDirectory_DomainService";ID = 1388,1988} -ErrorAction SilentlyContinue
      $evnt5 = Get-WinEvent -Credential $Script:EntCred -ComputerName $dc -MaxEvents 1 -FilterHashtable @{LogName = "system";ProviderName = "Microsoft-Windows-Time-Service";ID = 36,50} -ErrorAction SilentlyContinue
      if($evnt -ne $null){$obj = New-ADDSObj -evnt $evnt -dc $dc;$Output.Add($obj) | Out-Null}
      if($evnt1 -ne $null){$obj = New-ADDSObj -evnt $evnt1 -dc $dc;$Output.Add($obj) | Out-Null}
      if($evnt2 -ne $null){$obj = New-ADDSObj -evnt $evnt2 -dc $dc;$Output.Add($obj) | Out-Null}
      if($evnt3 -ne $null){$obj = New-ADDSObj -evnt $evnt3 -dc $dc;$Output.Add($obj) | Out-Null}
      if($evnt4 -ne $null){$obj = New-ADDSObj -evnt $evnt4 -dc $dc;$Output.Add($obj) | Out-Null}
      if($evnt5 -ne $null){$obj = New-ADDSObj -evnt $evnt5 -dc $dc;$Output.Add($obj) | Out-Null}
       }
       catch
       {
        $obj = New-Object PSObject -Property @{DomainController = $dc
                                               EventID =  "Exception occured while quering for AD error events"}
        $Output.Add($obj) | Out-Null
        Write-HCLog -Level error -Message "Exception occured while quering for AD error events "
        Write-HCLog -Level error -Message $_.Exception.Message
       }     
      }
      if($output.count -gt 0)
      {
      $netb = $domain.split(".",2)[0]
      Export-Html -output $output -header "Recommendations_EventLog_$netb" -folder $domain
      Remove-Indent -Footer "exit -> Find-ADDSEvents"
      return $output
      }
      else
      {
      $obj = New-Object PSObject -Property @{DomainController = "No important event failures found"}
      Remove-Indent -Footer "exit -> Find-ADDSEvents"
      return $obj
      }
   }
catch{
        $obj = New-Object PSObject -Property @{DomainController = "Exception occured while quering for AD error events"}
        Write-HCLog -Level error -Message "Exception occured while quering for AD error events "
        Write-HCLog -Level error -Message $_.Exception.Message
        Remove-Indent -Footer "exit -> Find-ADDSEvents"
        return $obj
     }
}

Function Find-DSAgedComp($domain)
{
Add-Indent -Header "enter -> Find-DSAgedComp"
try
{
[System.Collections.ArrayList]$Output = @()
$complist = $null
$complist = Get-ADComputer -Filter * -Server $domain -Credential $Script:EntCred -Properties * | Where-Object {($_.operatingsystem -like "*XP*") -or ($_.operatingsystem -like "*2000*") -or ($_.operatingsystem -like "*2003*") -or ($_.operatingsystem -like "*4.0*")}
    if($complist -ne $null)
    {
        $hash = [ordered]@{ProblemDescription = "Following servers has OS which is not supported by microsoft "
                           Server = ""
                           DistinguishedName = ""
                           OperatingSystem = ""
                           Servicepack = ""
                           lastlogontimestamp = ""
                          }
        $obj = New-Object PSObject -Property $hash
        $Output.Add($obj) | Out-Null
        
        foreach($comp in $complist)
        {
        $hash = [ordered]@{ProblemDescription = ""
                           Server = $comp.Name
                           DistinguishedName = $comp.DistinguishedName
                           OperatingSystem = $comp.operatingsystem
                           Servicepack = $comp.OperatingSystemServicepack
                           lastlogontimestamp = [datetime]::FromFileTime(($comp.lastlogontimestamp))
                          }
        $obj = New-Object PSObject -Property $hash
        $Output.Add($obj) | Out-Null
        }
    }

    if($Output.count -gt 0)
    {
    $netb = $domain.split(".",2)[0]
    Export-Html -output $output -header "Recommendations_AgedCompObj_$netb" -folder $domain
    Remove-Indent -Footer "exit ->  Find-DSAgedComp"
    return $output
    }
    else
    {
    $obj = New-Object PSObject -Property @{ProblemDescription = "No Recommendations: All servers in the domain are supported by microsoft"}
    Remove-Indent -Footer "exit ->  Find-DSAgedComp"
    return $obj
    }
}
catch
{
$obj = New-Object PSObject -Property @{ProblemDescription = "Unable to fetch information"}
Write-DSLog -Level error -Message "Exception occured while quering for server info"
Write-DSLog -Level error -Message $_.Exception.Message
Remove-Indent -Footer "exit ->  Find-DSAgedComp"
return $obj
}

}

Function get-ADDSRegValueSRC($domain)
{
try
{
    [System.Collections.ArrayList]$Output = @()
    $regVal = $null
    $flag = 0
     $dclist = Get-ADDomainController -Credential $Script:EntCred -Server $domain -Filter *
      foreach($dc in $dclist)
      {
      try
      {
      Write-HCLog -Level info -Message "[adhealthcheck] Querying dc $dc.Name"
      $value = $null
      if([System.Net.Dns]::GetHostByName($env:COMPUTERNAME).HostName -eq $dc.HostName){$stdReg = Get-WmiObject -List -Namespace root\default -ComputerName $dc.HostName -ErrorAction SilentlyContinue | Where-Object {$_.Name -eq "StdRegProv"}}
      else{$stdReg = Get-WmiObject -Credential $Script:EntCred -List -Namespace root\default -ComputerName $dc.HostName -ErrorAction SilentlyContinue | Where-Object {$_.Name -eq "StdRegProv"}}
      $hklm = 2147483650
      $value = $stdReg.GetDWORDValue($hklm,"SYSTEM\CurrentControlSet\Services\NTDS\Parameters","Strict Replication Consistency").uValue
          if($value -ne '1')
          {
              if($flag -eq 0)
              {
                       $hash = [ordered]@{
                ProblemDescription = "Strict Replication Consistency: Following DCs are not set with recommended value. "
                Server = ""
                CurrentValue = ""
                RecommendedValue = ""
                                  }
                $obj = New-Object PSObject -Property $hash
                $Output.Add($obj) | Out-Null
                $flag++
              }

          $hash = [ordered]@{
                           ProblemDescription = ""
                           Server = $DC.HostName
                           CurrentValue = $value
                           RecommendedValue = "1"
                            }
          $obj = New-Object PSObject -Property $hash
          $Output.Add($obj) | Out-Null
          }
        }
        catch
        {
        Write-HCLog -Level error -Message "Exception occured while contacting server"
            Write-HCLog -Level error -Message $_.Exception.Message
            $hash = [ordered]@{
                           ProblemDescription = "Strict Replication Consistency"
                           Server = $dc
                           CurrentValue = "Exception occured while contacting server"
                           RecommendedValue = ""
                            }
          $obj = New-Object PSObject -Property $hash
          $Output.Add($obj) | Out-Null
        }
      }
      if($Output.Count -gt 0)
      {
      return $output
      }
      else
      {
      $hash = [ordered]@{
                           ProblemDescription = "Strict Replication Consistency: No recommendations.All DCs are set with recommended value in registry"
                           Server = ""
                           CurrentValue = ""
                           RecommendedValue = "1"
                            }
          $obj = New-Object PSObject -Property $hash
         
      return $obj
      }
}
catch
{
Write-HCLog -Level error -Message "Exception occured while contacting domain"
Write-HCLog -Level error -Message $_.Exception.Message
$hash = [ordered]@{
                           ProblemDescription = "Strict Replication Consistency: Exception occured while contacting domain"
                           Server = ""
                           CurrentValue = ""
                           RecommendedValue = ""
                            }
          $obj = New-Object PSObject -Property $hash
          
      return $obj
}
}

Function get-ADDSRegValueCAF($domain)
{
try
{
    [System.Collections.ArrayList]$Output = @()
    $regVal = $null
     $dclist = Get-ADDomainController -Credential $Script:EntCred -Server $domain -Filter *
      foreach($dc in $dclist)
      {
     try
     {
      $value = $null
      $flag = 0
      Write-HCLog -Level info -Message "[adhealthcheck] Querying dc $dc.Hostname"
      if([System.Net.Dns]::GetHostByName($env:COMPUTERNAME).HostName -eq $dc.hostname){$stdReg = Get-WmiObject -List -Namespace root\default -ComputerName $dc.hostname -ErrorAction SilentlyContinue | Where-Object {$_.Name -eq "StdRegProv"}}
      else{$stdReg = Get-WmiObject -Credential $Script:EntCred -List -Namespace root\default -ComputerName $dc.hostname -ErrorAction SilentlyContinue | Where-Object {$_.Name -eq "StdRegProv"}}
      $hklm = 2147483650
      $value = $stdReg.GetDWORDValue($hklm,"SYSTEM\CurrentControlSet\Control\Lsa","CrashOnAuditFail").uValue
          if($value -ne '2')
          {
          if($flag -eq 0)
              {
                       $hash = [ordered]@{
                ProblemDescription = "CrashOnAuditFail: Following DCs are not set with recommended value."
                Server = ""
                CurrentValue = ""
                RecommendedValue = ""
                                  }
                $obj = New-Object PSObject -Property $hash
                $Output.Add($obj) | Out-Null
                $flag++
              }
          $hash = [ordered]@{ProblemDescription = ""
                           Server = $DC.hostname
                           CurrentValue = $value
                           RecommendedValue = "2"
                            }
          $obj = New-Object PSObject -Property $hash
          $Output.Add($obj) | Out-Null
          }
         }
          catch
        {
        Write-HCLog -Level error -Message "Exception occured while contacting server"
            Write-HCLog -Level error -Message $_.Exception.Message
            $hash = [ordered]@{
                           ProblemDescription = "CrashOnAuditFail"
                           Server = $dc
                           CurrentValue = "Exception occured while contacting server"
                           RecommendedValue = ""
                            }
          $obj = New-Object PSObject -Property $hash
          $Output.Add($obj) | Out-Null
        }
      }
          if($Output.Count -gt 0)
          {        
            return $output
          }
          else
          {
          $hash = [ordered]@{
                           ProblemDescription = "CrashOnAuditFail:No recommendations.All DCs are set with recommended value in registry"
                           Server = ""
                           CurrentValue = ""
                           RecommendedValue = "2"
                            }
          $obj = New-Object PSObject -Property $hash
         
      return $obj
          }
      }
      catch
      {
      Write-HCLog -Level error -Message "Exception occured while contacting domain"
      Write-HCLog -Level error -Message $_.Exception.Message
      $hash = [ordered]@{
                           ProblemDescription = "CrashOnAuditFail: Exception occured while contacting domain"
                           Server = ""
                           CurrentValue = ""
                           RecommendedValue = ""
                            }
          $obj = New-Object PSObject -Property $hash
          
      return $obj
      }
}

Function get-ADDSRegVal($domain)
{
Add-Indent -Header "enter -> get-ADDSRegVal"

    [System.Collections.ArrayList]$Output = @()
    Write-HCLog -Level info -Message "[adhealthcheck] Calling function to check SRC reg value in domain $domain"
    $arr = get-ADDSRegValueSRC -domain $domain
    $arr | % {$output.Add($_) | Out-Null}
    
    Write-HCLog -Level info -Message "[adhealthcheck] Calling function to check CAF reg value in domain $domain"
    $arr = get-ADDSRegValueCAF -domain $domain
    $arr | % {$output.Add($_) | Out-Null}
    
    
      $netb = $domain.split(".",2)[0]
      Export-Html -output $output -header "Recommendations_Registry_$netb" -folder $domain
      Remove-Indent -Footer "exit -> get-ADDSRegVal"
      return $Output
 }

Function Find-PwdNvrExpires($domain)
{
Add-Indent -Header "enter -> Find-PwdNvrExpires"
try
{
    [System.Collections.ArrayList]$Output = @()
    $flag = 0
    
        if($($Script:seForest.RootDomain | select -ExpandProperty Name) -eq $domain){$privGrps = @("Schema Admins","Enterprise Admins","Domain Admins")}
        else{$privGrps = @("Domain Admins")}

        foreach($grp in $privGrps)
        {
        
        Write-DSLog -Level info -Message "[adhealthcheck] Querying group $grp for userlist on domain $domain"   
        $userlist = get-adgroup -Credential $script:EntCred -Server $domain -Identity $grp | Get-ADGroupMember -Credential $script:EntCred -Server $domain -Recursive
        if($userlist -ne $null)
            {
            foreach($username in $userlist){
             $user = Get-ADUser -Credential $script:EntCred -Identity $username.samaccountname -Properties * -Server $domain
            if($user.passwordneverexpires -eq 'True')
                {
                if($flag -eq 0)
                {
                $hash = [ordered]@{
                                   ProblemDescription = "Following users are member of privilege groups whose password never expire set to true"
                                   UserName = ""
                                   DistinguishedName = ""
                                   Group = ""
                                   PasswordNeverExpires = ""
                                   PasswordLastSet_Days = ""
                                  }
                $obj = New-Object PSObject -Property $hash
                $Output.Add($obj) | Out-Null
                $flag++
                }


                $hash = [ordered]@{ProblemDescription = ""
                                   UserName = $user.CN
                                   DistinguishedName = $user.DistinguishedName
                                   Group = $grp
                                   PasswordNeverExpires = $user.PasswordNeverExpires
                                   PasswordLastSet_Days = $(new-timespan  $([datetime]::FromFileTime($user.pwdlastset)) $(get-date)).days
                                  }
                $obj = New-Object PSObject -Property $hash
                $Output.Add($obj) | Out-Null
                }
                          
               }
           
           }
          
        }
        
        if($Output.count -gt 0)
        {
        Export-Html -output $output -header "Recommendations_Privgrp_Members_pwdnvrexp" -folder $script:seForest.Name
        Remove-Indent -Footer "exit -> Find-PwdNvrExpires"
        return $output
        }
        else
        {
        $obj = New-Object PSObject -Property @{ProblemDescription = "No Recommendations:All privilege users password settings are at recommended level"}
        Remove-Indent -Footer "exit -> Find-PwdNvrExpires"
        return $obj
        }
}
catch
{
Write-DSLog -Level error -Message "Exception occured while contacting domain"
Write-DSLog -Level error -Message $_.Exception.Message
$obj = New-Object PSObject -Property @{ProblemDescription = "Exception occured while querying for requested info"}
Remove-Indent -Footer "exit -> Find-PwdNvrExpires"
return $obj
}
}

Function Find-ExcessiveGrpMem($domain)
{

Add-Indent -Header "enter -> Find-ExcessiveGrpMem"
 try
    {
         if($($Script:seForest.RootDomain | select -ExpandProperty Name) -eq $domain){$privGrps = @("Schema Admins","Enterprise Admins","Domain Admins")}
        else{$privGrps = @("Domain Admins")}
        $probtext = "The Enterprise Admins group should contain no users on a day-to-day basis, with the possible exception of the forest root domain's Administrator account. As is the case with the Domain Admins group, membership in Domain Admins groups should be required only in build or disaster-recovery scenarios. There should be no day-to-day user accounts in the Domain Admins group with the exception of the local Administrator account for the domain. Same goes for Schema admins.
If a user is indeed needs to be added to these privilege groups, a time-bound restriction should be imposed (Just-in-time administration)."
        $flag = 0
        [System.Collections.ArrayList]$Output = @()
        foreach($grp in $privGrps)
        {       
        
        Write-DSLog -Level info -Message "[adhealthcheck] Querying group $grp for membership count in domain $domain"
        $userlist = get-adgroup -Credential $script:EntCred -Server $domain -Identity $grp | Get-ADGroupMember -Credential $script:EntCred -Server $domain -Recursive
        if($userlist.GetType().Basetype.tostring() -eq "system.array"){$count = $userlist.count}
        else{$count = $($userlist.ToString()).Count}
        if($count -gt 1)
        {
            if($flag -eq 0)
            {    $hash = [ordered]@{ProblemDescription=$probtext
                               GroupName = ""
                               MembersCount = ""
                                                       
                              }
            $obj = New-Object PSObject -Property $hash
            $Output.Add($obj) | Out-Null
            $flag++
            }
        $hash = [ordered]@{
                           ProblemDescription=""
                           GroupName = $grp
                           MembersCount = $count
                         }
        $obj = New-Object PSObject -Property $hash
        $Output.Add($obj) | Out-Null
        }
        }
       
        
        
                
        if($Output.Count -gt 0)
        {
        $netb = $domain.split(".",2)[0]
        Export-Html -output $output -header "Recommendations_Privgrp_Members_Count_$netb" -folder $domain
        Remove-Indent -Footer "exit -> Find-ExcessiveGrpMem"
        return $output
        }
        else
        {
        $obj = New-Object PSObject -Property @{ProblemDescription = "All privilege groups in this domain are at recommended level"}
        Remove-Indent -Footer "exit -> Find-ExcessiveGrpMem"
        return $obj
        }

    }
    catch{
    Write-DSLog -Level error -Message "Exception Occured while querying for group info"
      Write-DSLog -Level error -Message $_.Exception.Message
        $obj = New-Object PSObject -Property @{ProblemDescription = "Exception Occured while querying for group info"}
        Remove-Indent -Footer "exit -> Find-ExcessiveGrpMem"
        return $obj
        }
}

Function find-addsdupspn($domain)
{
Add-Indent -Header "enter ->  find-addsdupspn"
    try
    {
    $flag = 0 
    [System.Collections.ArrayList]$Output = @()
    $objectlist = Get-ADObject -Credential $script:EntCred -Server $domain -filter {(Objectclass -eq "user") -or (ObjectClass -eq "computer")} -Properties Name,distinguishedname,serviceprincipalname | where {$_.serviceprincipalname -ne $null}
      foreach($item in $objectlist)
       {
        foreach($object in $item.serviceprincipalname)
         {
         [array]$allspnlist += $object
         }         
       }
    [array]$allspnlist = $allspnlist | Sort-Object
    [array]$uniquespn = $allspnlist | select -Unique
    [array]$dupspn = Compare-Object -ReferenceObject $uniquespn -DifferenceObject $allspnlist
    if($dupspn.Count -gt 0)
    {
    foreach($dup in $dupspn)
    {    
    [array]$duplist += $dup.inputobject
    }
     
    if($flag -eq 0)
    {
     $hash = [ordered]@{ProblemDescription = "Following are duplicate SPNs found in this domain"
                               ObjectName = ""
                               ObjectClass = ""
                               DistinguishedName = ""
                               SPN = ""
                                }
             $obj1 = New-Object PSObject -Property $hash
             $Output.Add($obj1) | Out-Null
             $flag++
    }
    foreach($spn in $duplist)
        {
         $dupspnobj = $objectlist | where {$_.serviceprincipalname -eq $spn}
         foreach($obj in $dupspnobj)
             {
             $hash = [ordered]@{ProblemDescription = ""
                               ObjectName = $obj.Name
                               ObjectClass = $obj.ObjectClass
                               DistinguishedName = $obj.DistinguishedName
                               SPN = $spn
                                }
             $obj1 = New-Object PSObject -Property $hash
             $Output.Add($obj1) | Out-Null
             }
        }
    }
        if($Output.Count -gt 0)
        {
        $netb = $domain.split(".",2)[0]
      Export-Html -output $output -header "Recommendations_DupSPN_$netb" -folder $domain
      Remove-Indent -Footer "exit ->  find-addsdupspn"
      return $Output
      }
        else{$obj = New-Object PSObject -Property @{ProblemDescription = "Duplicate SPNs in Domain: Nothing found"}
        return $obj}
    }
    catch
    {
    Write-DSLog -Level error -Message "Exception Occured while querying for info"
      Write-DSLog -Level error -Message $_.Exception.Message
    $obj = New-Object PSObject -Property @{ProblemDescription = "Duplicate SPNs in Domain: Error contacting domain"}
        return $obj
    }
}

Function Get-ADDSDNSServerList($domain)
{
    try{
    
    $dnsservers =@()
    #$ns = Invoke-Expression -Command "nslookup.exe -querytype=NS $domain" -ErrorAction Stop
    Start-Process -FilePath "C:\windows\system32\nslookup.exe" -ArgumentList "-querytype=NS $domain" -NoNewWindow -Wait -RedirectStandardError "$PSScriptRoot\dnserror.log" -RedirectStandardOutput "$PSScriptRoot\dnsout.log"
    $ns = Get-Content "$PSScriptRoot\dnsout.log"
    $ns | % {
    if($_ -like '*nameserver*'){
    $fIndex = $_.Indexof("nameserver")
    $dnsservers += $_.SubString($findex+13)
    }
    }
    Remove-Item -Path "$PSScriptRoot\dns*.log" -Force
    return $dnsservers
    }
    catch
    {
    Write-DSLog -Level error -Message "Exception Occured while getting nameserver list"
    Write-DSLog -Level error -Message $_.Exception.Message
    }
}
Function Find-DSDNSScav($domain)
{

Add-indent -Header "Enter -> Find-DSDNSScav"
   try
   {
    [System.Collections.ArrayList]$Output = @()
    $dnsservers =@()
    $flag = 0
    $dnsservers = Get-ADDSDNSServerList -domain $domain
    if($dnsservers.Count -gt 0)
    {
    $dnsservers | % {
    try
    {
    if([System.Net.Dns]::GetHostByName($env:COMPUTERNAME).HostName -eq $_){$dnsprop = Get-WmiObject -ComputerName $_ -Namespace "Root\MicrosoftDNS" -Class "MicrosoftDNS_Server" -ErrorAction SilentlyContinue}
    else{$dnsprop = Get-WmiObject -ComputerName $_ -Namespace "Root\MicrosoftDNS" -Class "MicrosoftDNS_Server" -Credential $Script:EntCred -ErrorAction SilentlyContinue}
        if($dnsprop.ScavengingInterval -eq 0)
        {
        
            if($flag -eq 0)
            {
            $hash = [ordered]@{ProblemDescription = "Scavenging is not enabled on following DNS servers"
                                       Server = ""
                                       Zone = ""
                                        }
                     $obj = New-Object PSObject -Property $hash
                     $Output.Add($obj) | Out-Null
                     $flag++
            }
        
        $hash = [ordered]@{ProblemDescription = ""
                                   Server = $_
                                   Zone = ""
                                    }
                 $obj = New-Object PSObject -Property $hash
                 $Output.Add($obj) | Out-Null
                 
        }
        }
        catch
        {
        Write-HCLog -Level error -Message "Exception Occured while querying for info"
        Write-HCLog -Level error -Message $_.Exception.Message
        $hash = [ordered]@{ProblemDescription = "Exception Occured while querying for info"
                                       Server = "$_"
                                       Zone = ""
                                        }
                     $obj = New-Object PSObject -Property $hash 
                      $Output.Add($obj) | Out-Null
        }
    }
}
else
{
$hash = [ordered]@{ProblemDescription = "DNS Scavenging : No DNS servers found for domain $domain"
                                       Server = ""
                                       Zone = ""
                                        }
                     $obj = New-Object PSObject -Property $hash
                     Remove-indent -footer "Exit -> Find-DSDNSScav"
                     return $obj
}
    if($Output.Count -gt 0)
    {
    Remove-indent -footer "Exit -> Find-DSDNSScav"
    return $Output
    }
    else
    {
     $hash = [ordered]@{ProblemDescription = "DNS Scavenging : No recommendations"
                                       Server = ""
                                       Zone = ""
                                        }
                     $obj = New-Object PSObject -Property $hash
                     Remove-indent -footer "Exit -> Find-DSDNSScav"
                     return $obj
    }
}
catch
{
Write-HCLog -Level error -Message "Exception Occured while querying for info"
    Write-HCLog -Level error -Message $_.Exception.Message
$hash = [ordered]@{ProblemDescription = "DNS Scavenging : Exception occured while querying for information"
                                       Server = ""
                                       Zone = ""
                                        }
                     $obj = New-Object PSObject -Property $hash
                     Remove-indent -footer "Exit -> Find-DSDNSScav"
                     return $obj
}
}

Function Find-DSDNSUpdates($domain)
{
try
   {
    [System.Collections.ArrayList]$Output = @()
    $dnsservers =@()
    $flag = 0
    $dnsservers = Get-ADDSDNSServerList -domain $domain
    if($dnsservers.Count -gt 0)
    {
        foreach($dns in $dnsservers)
        {
        if([System.Net.Dns]::GetHostByName($env:COMPUTERNAME).HostName -eq $dns){$zonelist = Get-WmiObject -ComputerName $dns -Namespace "Root\MicrosoftDNS" -Class "MicrosoftDNS_Zone" -ErrorAction SilentlyContinue | Where {$_.Name -ne 'TrustAnchors'}}
        else{$zonelist = Get-WmiObject -ComputerName $dns -Namespace "Root\MicrosoftDNS" -Class "MicrosoftDNS_Zone" -Credential $Script:EntCred -ErrorAction SilentlyContinue | Where {$_.Name -ne 'TrustAnchors'}}
            foreach($zone in $zonelist)
            {
                if($zone.Allowupdate -ne 2)
                {
                    if($flag -eq 0)
                    {
                    $hash = [ordered]@{ProblemDescription = "Following zones on DNS servers are not allowed dynamic updates or allowed non secure dynamic updates"
                                       Server = ""
                                       Zone = ""
                                        }
                     $obj = New-Object PSObject -Property $hash
                     $Output.Add($obj) | Out-Null
                     $flag++
                    }

                    $hash = [ordered]@{ProblemDescription = ""
                                       Server = $dns
                                       Zone = $($zone.Name)
                                        }
                     $obj = New-Object PSObject -Property $hash
                     $Output.Add($obj) | Out-Null
                     
                }

            }
    
      }
    }
    else
{
$hash = [ordered]@{ProblemDescription = "Dynamic updates: No DNS servers found for domain $domain"
                                       Server = ""
                                       Zone = ""
                                        }
                     $obj = New-Object PSObject -Property $hash
                     return $obj
}
    if($Output.count -gt 0)
    {
    return $Output
    }
    else
    {
      $hash = [ordered]@{ProblemDescription = "Dynamic updates: No recommendation."
                                       Server = ""
                                       Zone = ""
                                        }
                     $obj = New-Object PSObject -Property $hash
                     return $obj
    }
}
catch
{
Write-HCLog -Level error -Message "Exception Occured while querying for info"
    Write-HCLog -Level error -Message $_.Exception.Message
$hash = [ordered]@{ProblemDescription = "Dynamic updates:Exception occured while querying for information"
                                       Server = ""
                                       Zone = ""
                                        }
                     $obj = New-Object PSObject -Property $hash
                     return $obj
}
}

Function Find-DSDNSZoneSec($domain)
{
try
   {
    [System.Collections.ArrayList]$Output = @()
    $dnsservers =@()
    $flag = 0
    $dnsservers = Get-ADDSDNSServerList -domain $domain
    if($dnsservers.Count -gt 0)
    {
        foreach($dns in $dnsservers)
        {
        if([System.Net.Dns]::GetHostByName($env:COMPUTERNAME).HostName -eq $dns){$zonelist = Get-WmiObject -ComputerName $dns -Namespace "Root\MicrosoftDNS" -Class "MicrosoftDNS_Zone" -ErrorAction SilentlyContinue | Where {$_.Name -ne 'TrustAnchors'}}
        else{$zonelist = Get-WmiObject -ComputerName $dns -Namespace "Root\MicrosoftDNS" -Class "MicrosoftDNS_Zone" -Credential $Script:EntCred -ErrorAction SilentlyContinue | Where {$_.Name -ne 'TrustAnchors'}}
            foreach($zone in $zonelist)
            {
                if($zone.SecureSecondaries -eq 1)
                {
                    if($flag -eq 0)
                    {
                    $hash = [ordered]@{ProblemDescription = "Zone transfers on following DNS servers are not secured"
                                       Server = ""
                                       Zone = ""
                                        }
                     $obj = New-Object PSObject -Property $hash
                     $Output.Add($obj) | Out-Null
                    }

                    $hash = [ordered]@{ProblemDescription = ""
                                       Server = $dns
                                       Zone = $($zone.Name)
                                        }
                     $obj = New-Object PSObject -Property $hash
                     $Output.Add($obj) | Out-Null
                     $flag++
                }

            }
    
      }
    }
    else
{
$hash = [ordered]@{ProblemDescription = "Zone Transfers: No DNS servers found for domain $domain"
                                       Server = ""
                                       Zone = ""
                                        }
                     $obj = New-Object PSObject -Property $hash
                     return $obj
}
    if($Output.count -gt 0)
    {
    return $Output
    }
    else
    {
    $hash = [ordered]@{ProblemDescription = "Zone Transfers: No recommendation."
                                       Server = ""
                                       Zone = ""
                                        }
                     $obj = New-Object PSObject -Property $hash
                     return $obj
    }
}
catch
{
Write-HCLog -Level error -Message "Exception Occured while querying for info"
    Write-HCLog -Level error -Message $_.Exception.Message
$hash = [ordered]@{ProblemDescription = "Zone Transfers: Exception occured while querying for information"
                                       Server = ""
                                       Zone = ""
                                        }
                     $obj = New-Object PSObject -Property $hash
                     return $obj
}
}

Function Get-ADDSDNSRecom($domain)
{
Add-Indent -Header "enter -> Get-ADDSDNSRecom"

    [System.Collections.ArrayList]$Output = @()
    Write-HCLog -Level info -Message "[adhealthcheck] Calling function to DNS scavenging domain $domain"
    $arr = Find-DSDNSScav -domain $domain
    $arr | % {$output.Add($_) | Out-Null}
    
    Write-HCLog -Level info -Message "[adhealthcheck] Calling function to check DNS Dynamic updates in domain $domain"
    $arr = Find-DSDNSUpdates -domain $domain
    $arr | % {$output.Add($_) | Out-Null}
    
    Write-HCLog -Level info -Message "[adhealthcheck] Calling function to check DNS zone transfers in domain $domain"
    $arr = Find-DSDNSZoneSec -domain $domain
    $arr | % {$output.Add($_) | Out-Null}

      $netb = $domain.split(".",2)[0]
      Export-Html -output $output -header "Recommendations_DNS_$netb" -folder $domain
      Remove-Indent -Footer "exit ->  Get-ADDSDNSRecom"
      return $Output
}


Function Get-ADDSDCRecom($domain)
{ 
    Add-Indent -Header "enter -> Get-ADDSDCRecom"
    [System.Collections.ArrayList]$Output = @()
    try
    {
    $dclist = Get-ADDomainController -Server $domain -Credential $script:EntCred -Filter *
    $objarr = @($dclist)
    if($objarr.Count -lt 2)
    {
    $hash = [ordered]@{ProblemDescription = "DC Count:All domains should have atleast 2 domain controllers for redundancy"
                                       CurrentValue = "1"
                                        }
                     
    }
    else
    {
    $hash = [ordered]@{ProblemDescription = "DC Count: No Recommendations. DC Count in this domain is at recommended level"
                                       CurrentValue = $objarr.Count
                                        }
    }
    
    }
    catch
    {
    Write-HCLog -Level error -Message "Exception Occured while querying for DC Count"
    Write-HCLog -Level error -Message $_.Exception.Message
    $hash = [ordered]@{ProblemDescription = "DC Count: Exception occured while querying for DC count"
                                       CurrentValue = ""
                                        }
    }
    $obj = New-Object PSObject -Property $hash
    $Output.Add($obj) | Out-Null
    try
    {
    $dsid = (Get-ADDomain -Credential $script:EntCred -Server $domain).domainSID
    $ba = $dsid.ToString() + "-500"
    $ustate = Get-ADUser -Identity $ba -Credential $script:EntCred -Properties * -Server $domain
    if($ustate.Enabled -eq $true)
    {
    $hash = [ordered]@{ProblemDescription = "As per AD DS security recommendations the built-in administrator account has to be in disabled state. Disable the account"
                                       CurrentValue = $($ustate.Name)
                                        }
                     
    }
    else
    {
     $hash = [ordered]@{ProblemDescription = "Builtin Administrator Account: No Recommendations. As per AD DS security recommendations the built-in administrator account has to be in disabled state."
                        CurrentValue = $($ustate.Name)
                       }
    }
    }
    catch
    {
    Write-HCLog -Level error -Message "Exception Occured while querying for Builtin Admin account"
    Write-HCLog -Level error -Message $_.Exception.Message
    $hash = [ordered]@{ProblemDescription = "Builtin Administrator Account: Exception occured while querying for builtin account state"
                        CurrentValue = ""
                       }
    }
    $obj = New-Object PSObject -Property $hash
    $Output.Add($obj) | Out-Null
    try
    {
    $dom = Get-ADDomain -Credential $script:EntCred -Server $domain
    if($dom.PDCEmulator -ne $dom.RIDMaster)
    {
    $hash = [ordered]@{ProblemDescription = "It is recommended to have  PDC Emulator and RID master roles on same server"
                                       CurrentValue = $($dom.PDCEmulator) + "," + $($dom.RIDMaster)
                                        }
                     
    }
    else
    {
    $hash = [ordered]@{ProblemDescription = "Server roles: No recommendations. PDC Emulator and RID master roles on same server"
                                       CurrentValue = $dom.RIDMaster
                                        }
    }
    }
    catch
    {
    Write-HCLog -Level error -Message "Exception Occured while querying for server roles"
    Write-HCLog -Level error -Message $_.Exception.Message
    $hash = [ordered]@{ProblemDescription = "Server roles: Exception occured while querying for server roles"
                                       CurrentValue = ""
                                        }
    }
    $obj = New-Object PSObject -Property $hash
    $Output.Add($obj) | Out-Null
    
    
    $flag = 0
    foreach($dc in $dclist)
    {
    try
    {
    if($env:COMPUTERNAME -eq $dc.Name){$sysvolshare = Get-WmiObject -Class win32_share -ComputerName $dc.Name -Filter "Name='SYSVOL'" -ErrorAction SilentlyContinue}
    else{$sysvolshare = Get-WmiObject -Class win32_share -ComputerName $dc.Name -Filter "Name='SYSVOL'" -Credential $script:EntCred -ErrorAction SilentlyContinue}

    $drive = $($sysvolshare.path).Substring(0,2)

    if($env:COMPUTERNAME -eq $dc.Name){$diskreport = Get-WmiObject -Class Win32_Logicaldisk -ComputerName $dc.Name -Filter "DeviceID='$drive'" -ErrorAction SilentlyContinue}
    else{$diskreport = Get-WmiObject -Class Win32_Logicaldisk -Credential $Script:EntCred -ComputerName $dc.Name -Filter "DeviceID='$drive'" -ErrorAction SilentlyContinue}
    if(($diskreport.freespace/$diskreport.size) -lt '0.1')
    {
    
    if($flag -eq 0)
    {
    $hash = [ordered]@{ProblemDescription = "Freespace in SYSVOL partition on following Domain Controllers is less than 10% "
                                       CurrentValue = ""
                                        }
                     $obj = New-Object PSObject -Property $hash
                     $Output.Add($obj) | Out-Null
                       $flag++
    }
    $hash = [ordered]@{ProblemDescription = ""
                                       CurrentValue = $dc.Name
                                        }
                     $obj = New-Object PSObject -Property $hash
                     $Output.Add($obj) | Out-Null
                   
    }
    
    }
    catch
    {
    Write-HCLog -Level error -Message "Exception Occured while querying for SYSVOL info"
    Write-HCLog -Level error -Message $_.Exception.Message
                     
    }

    }
    
    if($flag -eq 0)
    {
    $hash = [ordered]@{ProblemDescription = "SYSVOL partition: No Recommendations. Freespace on sysvol partition on all the DCs is above 10%"
                                       CurrentValue = ""
                                        }
                     $obj = New-Object PSObject -Property $hash
                     $Output.Add($obj) | Out-Null

    }
      $netb = $domain.split(".",2)[0]
      Export-Html -output $output -header "Recommendations_DC_$netb" -folder $domain
      Remove-Indent -Footer "exit ->  Get-ADDSDCRecom"
    return $Output
}

Function Get-ADDSOURecom($domain)
{
Add-Indent -Header "enter -> Get-ADDSDCRecom"
try
{
#Create a variable for the domain DN
$DomainDn = (Get-ADDomain -Credential $Script:EntCred -Identity $Domain -ErrorAction Stop).DistinguishedName
[System.Collections.ArrayList]$Output = @()
#Create an array to  contain our custom PS objects
$TotalOus = @()
$flag = 0

Write-DSLog -Level info -Message "[adhealthcheck] Querying domain $domain for complete list of OUs"
$TotalOus = Get-ADOrganizationalUnit -Credential $Script:EntCred -Filter * -SearchScope Subtree -Server $Domain -Properties * -ErrorAction SilentlyContinue

    foreach($ou in $TotalOus)
    {
        if($ou.ProtectedFromAccidentalDeletion -eq $false)
        {
        if($flag -eq 0)
        {
        $hash = [ordered]@{ProblemDescription = "Following OUs are not protected from Accidental Deletion"
                                      Name = ""
                                      DistinguishedName = ""
                                        }
                     $obj = New-Object PSObject -Property $hash
                     $Output.Add($obj) | Out-Null
        }
         $hash = [ordered]@{ProblemDescription = ""
                                      Name = $ou.Name
                                      DistinguishedName = $ou.DistinguishedName
                                        }
                     $obj = New-Object PSObject -Property $hash
                     $Output.Add($obj) | Out-Null


        $flag++
        }
    }
if($output.Count -gt 0)
{
Export-Html -output $output -header "Recommendations_OU_$netb" -folder $domain
Remove-Indent -Footer "exit ->  Get-ADDSDCRecom"
return $Output
}
else
{
$obj = New-Object PSObject -Property @{ProblemDescription = "Protected From Accidental Deletion: No Recommendations. All OUs have this attribute enabled "}
Remove-Indent -Footer "exit ->  Get-ADDSDCRecom"
return $obj
}
}

catch
{
Write-DSLog -Level error -Message "Exception Occured while querying for info"
Write-DSLog -Level error -Message $_.Exception.Message
$obj = New-Object PSObject -Property @{ProblemDescription = "Protected From Accidental Deletion: Exception occured while quering OU info"}
Remove-Indent -Footer "exit ->  Get-ADDSDCRecom"
return $obj
}

}

Function get-addsfilestatus([switch]$ou,[switch]$page)
{
try{

if($ou){$path = 'C:\support\logs\dssoe\noou.txt'}elseif($page){$path = 'C:\support\logs\dssoe\nopage.txt'}
    if(Test-path -path $path -PathType Leaf){
    Remove-Item -Path $path -Force
    return $true}
    else{return $false}
    }
    catch{return $false}
}
#endregion ---Domain Recommendations---

#region ---Inventory and reports---
Function Set-ReportPath($domainsToScan)
{
Add-Indent -Header "Enter -> Set-ReportPath"
try
{
$script:reportpath = $(New-Item -Path "C:\Support\Logs\DSSOE\ADHealthCheck\$(Get-Date -Format {ddMMyyhhmmss})" -ItemType Directory).FullName
 if(($domainsToScan.Count -eq 1) -and ($domainsToScan -eq 'All'))
    {
    $domainlist = $Script:seForest.Domains | select -ExpandProperty Name
    }
    else
    {
    $domainlist = $domainsToScan.Split(",")
    }
foreach($domain in $domainlist)
{
Write-DSLog -Level info -Message "[adhealthcheck] creating folder structure for domain $domain in reports folder"
$ret = New-Item -Path $script:reportpath\$domain -ItemType Directory -Force
}
Remove-Indent -footer "Exit -> Set-ReportPath"
}
catch
{
Write-DSLog -Level info -Message "Exception raised"
    Write-DSLog -Level info -Message $_.Exception.Message
Remove-Indent -footer "Exit -> Set-ReportPath"
}

}

Function New-ADDSObj($evnt,$dc)
{

foreach($evn in $evnt)
            {
            $hash = [ordered]@{
                            DomainController = $dc
                            EventID = $evn.ID
                            TimeCreated = $evn.TimeCreated
                            Level = $evn.LevelDisplayName
                            Message = $($evn.Message).ToString()
                              }
                    $obj = New-Object PSObject -Property $hash
                    
             }
return $obj
}

Function Set-DSVariableProperty($name,$value)
{
 $psarr=@()
 $objNew = New-Object pscustomobject
 $ObjNew | Add-Member -Type NoteProperty -Name "Name" -Value $name
 $ObjNew | Add-Member -Type NoteProperty -Name "Value" -Value $value
 $psarr += $objNew
 return $psarr
 
}

Function Export-Html ($output,$header,$folder)
{
$htmlpath = $script:reportpath
$htmlpath = $htmlpath+"\"+$folder+"\$header.html"

$a = "<style>"
$a = $a + "BODY{background-color:ivory;}"
$a = $a + "TABLE{border-width: 1px;border-style: solid;border-color: black;border-collapse: collapse;font-family:calibri;width:1px;white-space:nowrap;text-align:center}"
$a = $a + "TH{border-width: 1px;padding: 0px;border-style: solid;border-color: black;background-color:lightsteelblue;font-size:15px}"
$a = $a + "TD{border-width: 1px;padding: 0px;border-style: solid;border-color: black;background-color:gainsboro;font-size:14px}"
$a = $a + "</style>"

$output | Select-Object * | ConvertTo-HTML -head $a -Body "<H2>$header</H2>" | Out-File $htmlpath -Force

}

Function Set-ADWCInventory($domainsToScan)
{
Add-Indent -Header "Enter -> Set-ADWCInventory"
try
{
$filename = "AD_HealthCheck_$(Get-Date -Format ('MMddyyHHmmss'))"
$InvPath = "$(Split-Path -Path $PSScriptRoot)\ADHealthCheck\Config\$filename.xml"
[xml]$targetXML = Get-Content "$(Split-Path -Path $PSScriptRoot)\ADHealthCheck\Config\forestInventorytemplate.xml"
    
    if(($domainsToScan.Count -eq 1) -and ($domainsToScan -eq 'All'))
    {
    $domainlist = $Script:seForest.Domains | select -ExpandProperty Name
    }
    else
    {
    $domainlist = $domainsToScan.Split(",")
    }

$targetXML.WCInventory.Section | % {
    if($_.Name -eq 'Forest info')
    {
        $_.Category[0].Name = $($Script:seForest.Name).ToString()
    }
   }
[int]$InvID = "001"
[int]$RInvID = "001"

foreach($dom in $domainlist)
{
$netb = $dom.split(".",2)[0]
[xml]$tempXML = Get-Content "$(Split-Path -Path $PSScriptRoot)\ADHealthCheck\Config\domainInventorytemplate.xml"
$tempnode = $targetXML.ImportNode($tempXML.Section.Category[0],$true)
$tempnode.Name = $dom.ToString()
$tempnode.InventoryItem | % {
        $_.ID = "DI"+$InvID
        $currentval = $_.InventoryCommand
        $_.InventoryCommand = $currentval+$($dom).ToString()
        $curName = $_.Name
        $_.Name = "$curName $netb"
        $InvID++
        }
$ret = $targetXML.DocumentElement.LastChild.AppendChild($tempnode)

$tempnode = $targetXML.ImportNode($tempXML.Section.Category[1],$true)
$tempnode.Name = "Recommendations $Netb"
$tempnode.InventoryItem | % {
        $_.ID = "DR"+$RInvID
        $currentval = $_.InventoryCommand
        $_.InventoryCommand = $currentval+$dom
        $curName = $_.Name
        $_.Name = "$curName $netb"
        $RInvID++
        }
$ret = $targetXML.DocumentElement.LastChild.AppendChild($tempnode)

}

$targetXML.save($InvPath)
Remove-Indent -footer "Exit -> Set-ADWCInventory"
return $invpath.ToString()
}
catch
{
Write-DSLog -Level info -Message "Exception raised"
Write-DSLog -Level info -Message $_.Exception.Message
Remove-Indent -footer "Exit -> Set-ADWCInventory"
}
}


Function start-dscleanupinventoryxml($invpath)
{
Remove-Item -Path $invpath -Force
}
#endregion ---Inventory and reports---

