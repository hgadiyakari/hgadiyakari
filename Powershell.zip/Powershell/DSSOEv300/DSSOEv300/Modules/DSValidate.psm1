﻿# This module includes the functions that are meant to validate the user input via XML file
# The name of the module is DSValidate.psm1
# Author: Tarun Rajvanshi, Umesh Thakur & ArunKumar Bavirisetti
# Date  : 21-March-2017
# Copyright  : @Platform Wintel SOE, DXC. 
# ---------------------------------------------------------------------------------
# Updated July 15, 2015 by Umesh: Updated functions to write to log file
# Updated Feb 19, 2016 by Umesh: Updated functions to write log in hierarchical manner 
# -------------------------------------------------------------------------------------------------------------
# This function will check if the input value is a valid alpha-numeric value or not. Any value that does
# match with the regular expression [a-z 0-9] will be returned as $False. This function code is originally taken 
# from DSSOE 2.1.0 and optimized/Modified here.
# -------------------------------------------------------------------------------------------------------------
Function Test-CharNum ($Value)
{
    for($i=0;$i -lt $Value.length;$i++)
    { 
        # Matching the each character of the $Value against [a-z 0-9] expression. The loop will continue
        # until the value of $i is less than the length of the $Value parameter
        $Status = $Value.chars($i) -match "[a-z 0-9-]" 

        if ($Status -eq $false)
         {
            # if the above case does not match the value of $Status variable (i.e. False) will be returned
            return $Status
         }         
    }
}

# -------------------------------------------------------------------------------------------------------------
# This function will validate the TCP connection to the given DomainName or Computername on a particular port.
# If it succeed in connecting the function will return $True else $False.
# -------------------------------------------------------------------------------------------------------------
Function Test-TCPPort([String] $DomainName, $Port) {
    Add-Indent -Header "enter -> Test-TCPPort" # increase indent in log file

    # creating a new class object
	$tcpclient = new-Object system.Net.Sockets.TcpClient
    # BeginConnect() is a method in system.net.sockets.tcpclient class
    Write-DSLog -Level info -Message "Trying to connect to port $port on $DomainName"
	$connect = $tcpclient.BeginConnect($DomainName,$port,$null,$null)
	$wait = $connect.AsyncWaitHandle.WaitOne("3000",$false)
	if(-not($wait))
	{
	    $tcpclient.Close()
        Write-DSLog -Level info -Message "Port connect failed"
        Remove-Indent -Footer "exit -> Test-TCPPort" # decrease indent in log file
	    return $false
	}
	else
	{
        try{
            $tcpclient.EndConnect($connect) | out-Null -ErrorAction stop
            # close tcpclient and return true
            $tcpclient.Close()
            Write-DSLog -Level info -Message "Port connect successful"
            Remove-Indent -Footer "exit -> Test-TCPPort" # decrease indent in log file
            return $true
        }
        Catch{
            Write-DSLog -Level info -Message "Port connect failed"
            Remove-Indent -Footer "exit -> Test-TCPPort" # decrease indent in log file
            return $false
        }
	}
}


# -----------------------------------------------------------------------------------------------------------------
# This function checks whether the user provided domain name or Netbios name already exists / in use or not.
# The function returns a integer value. "0" is success; "1355" is Domain does not exist; "52" is duplicate name
# exists. Refer to the below links for description of the NetValidateName method and all the available exist codes.
# source: https://jrich523.wordpress.com/tag/netvalidatename/
# http://www.pinvoke.net/default.aspx/Enums/NET_API_STATUS.html
# https://msdn.microsoft.com/en-us/library/windows/desktop/aa370660%28v=vs.85%29.aspx
# -----------------------------------------------------------------------------------------------------------------
Function Test-NameValidation([string] $Name,[int] $NameType)
{
# The code between the @s is a C# code; used to import the "Netapi32.dll", a built-in windows api
Add-Type -TypeDefinition @" 
using System; 
using System.Runtime.InteropServices;

public class NetworkUtil 
{ 
    [DllImport("Netapi32.dll",CharSet=CharSet.Unicode)] 
    public static extern UInt32 NetValidateName(string lpServer,string lpName,string lpAccount,string lpPassword, 
        int NameType); 
} 
"@
    # calling the NetValidateName method
    [NetworkUtil]::NetValidateName($null,$Name,$null,$null,$NameType)
}


# --------------------------------------------------------------------------------------------------------------
# This function checks whether the user provided domain name is in valid syntax or not; a domain with the 
# provided name already exists or not; the domain name is already use or not. If either of the condition is not 
# met the function will return $False, else $True
# --------------------------------------------------------------------------------------------------------------
Function Test-DomainName([String] $Name) {
    Add-Indent -Header "enter -> Test-DomainName" # increase indent in log file
    Write-DSLog -Level info -Message "Testing domain name $Name"

    # define error/warning messages here
    $invalidDomainNameLength = "Invalid Domain Name Length - Please enter valid Domain Name consisting of minimum three characters."
    $invalidDomainNameSyntax1 = "Invalid Domain Name Syntax - Please enter valid Domain Name syntax consisting of characters [a-z 0-9.-]"
    $invalidDomainNameSyntax2 = "Invalid Domin Name Syntax - The first character cannot be '-' or '.'"
    $invalidDomainNameSyntax3 = "Invalid Domin Name Syntax - The last character cannot be '-' or '.'"
    $duplicateDomainName = "Duplicate Domain Name - There is already an existing domain with $Name name. Please ensure non-existence of the domain."
    $domainalreadyexists1 = "Domain Already Exist - Able to connect to $Name on port 389. Please ensure non-existence of the domain."
    $domainalreadyexists2 = "Domain Already Exist - Able to connect to $Name on port 88. Please ensure non-existence of the domain."
    $domainNameInUse = "The domain name $Name is already in use. Please use a non-existent domain name"
    
    $isNameValid = $false # by-default assume name is not valid
    Write-DSLog -Level info -Message "Validating given domain name: $Name"

    # switch thru various validation conditions and return true/false based on validation
    Switch($Name) {
        #Checking if the length of the $domainname is less than 3. If yes, $False will be returned.
        { $_.Length -lt 3 } { 
            Write-DSLog -Level error -Message $invalidDomainNameLength
            break
        }
        #checking if the chars in the $domainname matches the regular expression; if not, $false will be returned.
        { $_ -notmatch "^(?!\-)(?:[a-zA-Z\d\-]{0,62}[a-zA-Z\d]\.){1,126}(?!\d+)[a-zA-Z\d]{1,63}$" } { 
            Write-DSLog -Level error -Message $invalidDomainNameSyntax1
            break
        }
        # checking for invalid domain name syntax
        { ($_.chars(0) -eq [char] "-") -or ($_.chars(0) -eq [char] ".") } { 
            Write-DSLog -Level error -Message $invalidDomainNameSyntax2 
            break
        }
        # checking for invalid domain name syntax
        { ($_.Chars($_.Length-1) -eq [char] "-") -or ($_.Chars($_.Length-1) -eq [char] ".") } { 
            Write-DSLog -Level error -Message $invalidDomainNameSyntax3
            break
        }        
        
        #validating the connection to the specified domain name, the cmdlet returns $true or $false
        { (Test-Connection $_ -Quiet -Count 2) -eq $true } {
            Write-DSLog -Level error -Message $duplicateDomainName
            break
        }
        #calling the test-tcpport fn to check if tcp connection is being reached for specified domain on port 389
        { (Test-TCPPort -DomainName $_ -Port 389) -eq $true } {
            Write-DSLog -Level error -Message $domainalreadyexists1
            break
        }
        #calling the test-tcpport fn to check if tcp connection is being reached for specified domain on port 88
        { (Test-TCPPort -DomainName $_ -Port 88) -eq $true } {
            Write-DSLog -Level error -Message $domainalreadyexists2
            return $false
        }

        #if none of the above conditions are met, $true will be returned.
        Default { 
            Write-DSLog -Level info -Message "Domain name validated successfully"
            $isNameValid = $true # successfull validation
            break
        }
    }

    Remove-Indent -Footer "exit -> Test-DomainName" # decrease indent in log file
    return $isNameValid 
}


# ----------------------------------------------------------------------------------------------------
# This function will test if given name is a valid NetBIOS name, or blank, or more than 15 chars long,
# or is not already present on the network. If any of the condition fails the function will return
# $False, else $True.
# ----------------------------------------------------------------------------------------------------
Function Test-NetBIOSName([string]$Name) {
    Add-Indent -Header "enter -> Test-NetBIOSName" # increase indent in log file

    # This is the regular expression to  check the validity of the Netbios name syntax. All the below chars are invalid.
    $InvalidCharsRegEx  = "[\\*+=|:;`"`?`<`>`,`#`@`$`&`(`)`{`}`_`!``~ `[`%`^.`/`'\]]"
    
    $isNameValid = $false # by-default assume name is not valid
    Write-DSLog -Level info -Message " Validating NetBIOS name $Name"

    Switch ($Name) {
        # checking if Netbios name is blank or not
        { $_.Length -lt 1 } { 
            Write-DSLog -Level error -Message "Blank NetBIOS Name - The NetBIOS name cannot be blank."
            break
        }
        # checking if Netbios name is more than 15 chars long or not
        { $_.Length -gt 15 } { 
            Write-DSLog -Level error -Message "Invalid NetBIOS Name Length - The NetBIOS name cannot be more than 15 characters long."
            break
        }
        # checking if the netbios name contains an invalid char or not
        { $_ -match $InvalidCharsRegEx } { 
            Write-DSLog -Level error -Message "Invalid NetBIOS Name Syntax - Please enter the valid syntax for NetBios name. The valid characters are [a-z 0-9 -]."
            break
        }
        # checking for duplicate netbios name on the network
        { (Test-NameValidation -Name $_ -NameType 1) -ne [int] 0 } { 
            Write-DSLog -Level error -Message "Duplicate NetBIOS Name - Duplicate NetBIOS name is present on the network. Please verify."
            break
        }
        #if none of the above conditions are met, $true will be returned.
        Default { 
            Write-DSLog -Level info -Message "NetBIOS name validated successfully"
            $isNameValid = $true # validation successful
            break
        } 
    }
    Remove-Indent -Footer "exit -> Test-NetBIOSName" # decrease indent in log file
    return $isNameValid
}

   
# ----------------------------------------------------------------------------------------------------
# This function will test if given name is a valid Site name, or blank, or more than 63 chars long.
# If any of the condition fails the function will return # $False, else $True.
# ----------------------------------------------------------------------------------------------------
Function Test-SiteName([String] $Name) {
    Add-Indent -Header "enter -> Test-SiteName" # increase indent in log file
    # This is the regular expression to  check the validity of the Site name syntax. All the below chars are invalid.
    $InvalidCharsRegEx  = "[\\*+=|:;`"`?`<`>`,`#`@`$`&`(`)`{`}`_`!``~ `[`%`^.`/`'\]]"
    $isNameValid = $False # assume site name is not valid
    Write-DSLog -Level info -Message "Validating site name $Name"

    Switch($Name)
    {
        # checking if Site name is blank
        { $_.Length -lt 1 } { 
            Write-DSLog -Level error -Message "Blank Site Name - The Site name is blank."
            break
        }
        # checking if site name is greater than 63 chars in length
        { $_.Length -gt 63 } { 
            Write-DSLog -Level error -Message "Invalid Site Name Length - The length of the Site name should not be more than 63 chars."
            break
        }
        # checking if the site name contains valid chars 
        { $_ -match $InvalidCharsRegEx } { 
            Write-DSLog -Level error -Message "Invalid Site Name Syntax - Please enter the valid syntax for Site name. The valid characters are [a-z 0-9 -]."
            break
        }
        # checking if the last char is - or not
        { $_.Chars($_.Length-1) -eq [char] "-"} { 
            Write-DSLog -Level error -Message "Invalid Site Name Syntax - The last character of Site name cannot be '-'"
            break
        }
        # if none of the above conditions are met, $true will be returned
        Default { 
            Write-DSLog -Level info -Message "Site name validated successfully"
            $isValidName = $true # site name valid
            break
        }
    }
    Remove-Indent -Footer "exit -> Test-SiteName" # decrease indent in log file
    return $isNameValid
}

# ---------------------------------------------------------------------------------
# This function will validate whether user has provided a valid value for "Enable"
# option or not. For invalid value the function will prompt a warning message.
# ---------------------------------------------------------------------------------
Function Test-DSTrueFalse ([string] $value)
{
    #using -in operataor to determine if $Enabled is one of "True" or "False" and -not is to negate the returned value
    If(-not ($value -in ("True","False")))
    {
        Return $False
    }
    Else { Return $True }
}


# ---------------------------------------------------------------------------------
# This function validates whether user provided <NetworkAdapterName> match with the 
# available network adapter names on the local server. If not, the function ensures
# to display a warning.
# ---------------------------------------------------------------------------------
Function Test-DSNetworkAdapterName ($NetworkAdapterName) {
    Add-Indent -Header "enter -> Test-DSNetworkAdapterName" # increase indent in log file
    Write-DSLog -Level info -Message "Checking whether network adapter $NetworkAdapterName exist or not"
    #Using the Win32 Network Adapter WMI class to retreive the Network Adapter whose NetConnectionID property matches
    # with the user provided $NetworkAdapterName.
    $NetworkAdapter = Get-WmiObject -Class "Win32_NetworkAdapter" | where { $_.NetConnectionId -eq $NetworkAdapterName }
    
    #If none of the Network Adapters were retrieved, display warning and return $false; else $true.
    if($NetworkAdapter -eq $null) {
       Write-DSLog -Level error -Message "Invalid or Blank Network Adapter - The Network Adapter Name does not match with any of the Network Adapter names exist on the Server. Please verify."
       Remove-Indent -Footer "exit -> Test-DSNetworkAdapterName" # decrease indent in log file
       Return $false
    }
    Else { 
        Write-DSLog -Level info -Message "Network adapter $NetworkAdapterName exists."
        Remove-Indent -Footer "exit -> Test-DSNetworkAdapterName" # decrease indent in log file
        Return $True 
    }
     
}


# ---------------------------------------------------------------------------------
# This function validates the correctness of the user provided IP addresses. The
# function will return the boolean value of $True or $False. 
# ---------------------------------------------------------------------------------
Function Test-DSIPAddress ($IPAddress) {
   #using the tryparse() static method of the [system.net.ipaddress] class to validate the user provided $IPAddress.
   Return [System.Net.IPAddress]::TryParse($IPAddress, [Ref]$null)
}


# ---------------------------------------------------------------------------------
# This function is to validate whether the user provided IP address is a duplicate
# IP address or not. The function will return the boolean value of $True or $False
# ---------------------------------------------------------------------------------
Function Test-DSDuplicateIPAddress ($IPAddr)
{
   Add-Indent -Header "enter -> Test-DSDuplicateIPAddress" # increase indent in log file

   #Test-connection cmdlet try to connect to the supplied $IPAddr to check if able to connect to it or not.
   # -quiet makes the cmdlet return the boolean value, -count is the number of times cmdlet tries to connect
   # before returning the final boolean result.        
    Try {
        $result = Test-Connection -ComputerName $IPAddr -Quiet -Count 2 -ErrorAction stop
        Remove-Indent -Footer "exit -> Test-DSDuplicateIPAddress" # decrease indent in log file
        return $result
    }
    catch {
        Write-DSLog -Level error -Message $_.exception.message
        Remove-Indent -Footer "exit -> Test-DSDuplicateIPAddress" # decrease indent in log file
        return $false
    }
 }


# ---------------------------------------------------------------------------------
# This function is meant to test the validity of the user provided Subnet Mask.
# The function is taken from DSSOE 2.1.0 (Global.ps1) code.
# ---------------------------------------------------------------------------------
Function Test-DSIPSubnet($IPMask)
{
    # Common subnet mask values
    $common = '0|128|192|224|240|248|252|254|255'
		
    # Build a regular expression to represent all possible mask strings
    $masks = @(
	    "(^($common)\.0\.0\.0$)"
	    "(^255\.($common)\.0\.0$)"
	    "(^255\.255\.($common)\.0$)"
	    "(^255\.255\.255\.($common)$)"
        )
    # Join all possible strings with the regex "or" operator
    $subnetregex = [string]::Join('|', $masks)
    $m = [regex]::Match($IPMask, $subnetregex)
    return $m.Success
}


# --------------------------------------------------------------------------------------
# This function is meant to test the validity of the user provided DNS Suffix'.
# The valid value is a Fully Qualified Domain Name. 
# --------------------------------------------------------------------------------------
Function Test-DSDNSSuffix ($Suffix) {
    
    Add-Indent -Header "enter -> Test-DSDNSSuffix" # increase indent in log file
    
    Switch($Suffix)
    {
        { $_.Length -lt 3 } { 
            Write-DSLog -Level error -Message "Invalid DNS Suffix Length - Please enter valid DNS Suffix consisting of minimum three characters." 
            Remove-Indent -Footer "exit -> Test-DSDNSSuffix" # decrease indent in log file
            Return $False 
        }
        # "^(?!\-)(?:[a-zA-Z\d\-]{0,62}[a-zA-Z\d]\.){1,126}(?!\d+)[a-zA-Z\d]{1,63}$" is the regex to validate the Domain
        # DNS Names i.e. FQDN domain names.
        { $_ -notmatch "^(?!\-)(?:[a-zA-Z\d\-]{0,62}[a-zA-Z\d]\.){1,126}(?!\d+)[a-zA-Z\d]{1,63}$" } { 
            Write-DSLog -Level error -Message "Invalid DNS Suffix Syntax - Please enter valid DNS Suffix syntax consisting of characters [a-z 0-9.-]"
            Remove-Indent -Footer "exit -> Test-DSDNSSuffix" # decrease indent in log file
            Return $False 
        }
        # the first character cannot be a "-" or "."                                                                                   
        { ($_.chars(0) -eq [char] "-") -or ($_.chars(0) -eq [char] ".") } { 
            Write-DSLog -Level error -Message "Invalid DNS Suffix Syntax - The first character cannot be '-' or '.'"
            Remove-Indent -Footer "exit -> Test-DSDNSSuffix" # decrease indent in log file
            return $false 
        }
        # the last character cannot be a "-" or "."
        { ($_.Chars($_.Length-1) -eq [char] "-") -or ($_.Chars($_.Length-1) -eq [char] ".") } { 
            Write-DSLog -Level error -Message "Invalid DNS Suffix Syntax - The last character cannot be '-' or '.'"
            Remove-Indent -Footer "exit -> Test-DSDNSSuffix" # decrease indent in log file
            return $false 
        }
        Default { 
            #Write-DSLog -Level info -Message "Validated DNS Suffix $Suffix successfully"
            Remove-Indent -Footer "exit -> Test-DSDNSSuffix" # decrease indent in log file
            Return $True 
        }
    }
}


# --------------------------------------------------------------------------------------
# Validating the user provided value of True / False / "". Everything 
# other than True / False is invalid and function will return $False else $True.
# --------------------------------------------------------------------------------------
# This function will check for given $value in a range of values denoted by $range
# $range should be an array
# example: Test-ValueRange -value "true" -range ("true","false","yes","no")
# example: $var = "This is a test to see if this function works".split(" ")
#          Test-ValueRange -value "true" -range $var

function Test-ValuesRange($value, $range) { 
    $res = $false
    foreach($r in $range) { 
        if($r -eq $value) { $res = $true  }
    }
    return $res 
} 


# --------------------------------------------------------------------------------------
# Function to test the validity of the user provided file path
# --------------------------------------------------------------------------------------   
Function Test-InvalidPath {
    param([string] $path)

        try
        {
            #trying to write 'test' to the file specified by the user 
            out-file -FilePath $path -InputObject 'test' -ErrorAction Stop
            #if the above command is successful that means the file specified already exists, deleting the file
            Remove-Item -Path $path
            Return $True              
        }
        catch
        {
            #if commands in the try block fails, the catch block will execute
            #"errors occured"
            #$_.exception.Message
            Return $False
        }
}

           
# --------------------------------------------------------------------------------------
# Function to test the validity of the user provided reserver file options. Function will
# return $true or $false.
# --------------------------------------------------------------------------------------   
Function Test-DSConfigReserveFile ([string] $ReserveFilePath,[string] $SizeInMB)
{
    Add-Indent -Header "enter -> Test-DSConfigReserveFile" # increase indent in log file

    If($ReserveFilePath -eq "" -or $sizeinmb -eq "") {
        Write-DSLog -Level info -Message "Reserve file will not be created because one or both of the reserve file xml parameter is blank"
        Remove-Indent -Footer "exit -> Test-DSConfigReserveFile" # decrease indent in log file
        return $true 
    }
    Else {    
        Write-DSLog -Level info -Message "Validating ReserveFile Options; ReserveFilePath - $ReserveFilePath and SizeInMB - $sizeinmb"
        If((Test-InvalidPath -path $ReserveFilePath) -eq $false) { 
            Write-DSLog -Level error -Message "Invalid reserve file path"
            Remove-Indent -Footer "exit -> Test-DSConfigReserveFile" # decrease indent in log file
            return $false 
        }

        #checking if value provided in $sizeinmb parameter is an interger value or not
        If ([int]::TryParse($SizeInMB,[ref]$null) -eq $False) 
        {
            Write-DSLog -Level error -Message "Invalid Reserve File Value - Please enter a valid value for SizeInMB (Numeric Integer value)."
            Remove-Indent -Footer "exit -> Test-DSConfigReserveFile" # decrease indent in log file
            Return $False
        }

        #splitting the user provided reservefilepath value to retrieve the drive letter
        $ReserveFileDrive = ($ReserveFilePath.Split(":"))[0]
        #getting the free disk space on the identified partition in MBs
        $FreeSpace = (Get-PSDrive $ReserveFileDrive).Free / 1024KB

        #using invoke-expression to convert the string into expression. The reserve file size should not be less than 250 mb.
        #logic can be changed to - if($sizeInMB -lt 250) { code }
        If ((Invoke-Expression "${SizeInMB}mb/1024kb") -lt 250) 
        { 
            Write-DSLog -Level error -Message "Invalid Reserve File Size - Reserve file should not be less than 250mb in size"
            Remove-Indent -Footer "exit -> Test-DSConfigReserveFile" # decrease indent in log file
            return $false 
        }
    
        #the reserver file size should not be greater than 20% of the disk space available on the partion
        If ((Invoke-Expression "${SizeInMB}mb/1024kb") -gt ($FreeSpace/5)) 
        { 
            Write-DSLog -Level error -Message "Invalid Reserve File Size - Reserve file size should not be greater than 20% of the logical disk space available on the partition."
            Remove-Indent -Footer "exit -> Test-DSConfigReserveFile" # decrease indent in log file
            return $False 
        }
        Else { 
            Remove-Indent -Footer "exit -> Test-DSConfigReserveFile" # decrease indent in log file
            Return $true 
        }
        #Write-DSLog -Level info -Message "Reserve file options are successfully validated"
    }
}


# --------------------------------------------------------------------------------------
# To check whether the user provided $timeservername is valid and reachable. This function
# is taken from DSSOE 210 code and modified/optimized here.
# --------------------------------------------------------------------------------------
Function Test-DSTimeServer ($TimeServerName)
{
    Add-Indent -Header "enter -> Test-DSTimeServer" # increase indent in log file

    Write-DSLog -Level info -Message "Validating the Time Server - $TimeServerName"
    
    #If time server name is blank; return false
    If($TimeServerName -eq "") 
    { 
        Write-DSLog -Level info -Message "TimeServerName is not specified, thus external time server configurations will not be implemented"
        Remove-Indent -Footer "exit -> Test-DSTimeServer" # decrease indent in log file
        Return $true
    }

    #checking if user provided time server can be reached to or not. Passing the result of te w32tm command into 
    #the $TimeServerCheck variable
    
    #if time server name is not blank and Timeservercheck variable value contains Stratum:, return true else return false
    #  
    
    If($TimeServerName -ne "")
    {
        $TimeServerCheck = [String] $(W32tm /Monitor /Computers:$TimeServerName)

        If($TimeServerCheck.Contains("Stratum:") -eq $True)
        {
            Write-DSLog -Level info -Message "Time Server Name is successfully validated"
            Remove-Indent -Footer "exit -> Test-DSTimeServer" # decrease indent in log file
            Return $True
        }
        Else
        { 
            Write-DSLog -Level error -Message "Invalid Time Server - Not able to connect to the specified time server, please validate the name/IP provided or the connectivity to the server." 
            Remove-Indent -Footer "exit -> Test-DSTimeServer" # decrease indent in log file
            Return $False 
        }
    }
}

# --------------------------------------------------------------------------------------
# This function is to test the validity of rpc port range. The function will return $false
# if the specified port range is either blank or not a valid value in range 1-65535. 
# --------------------------------------------------------------------------------------

Function Test-DSPortRange([string]$portrange)
{
    try
    {
    if(($portrange -ne "") -and ($portrange.contains("-")))
    {
      $ports = $portrange.split("-",2)
      $fdigit = [convert]::ToInt32($ports[0],10)
      $sdigit = [convert]::ToInt32($ports[1],10)
      if(($fdigit -lt $sdigit) -and ($fdigit -gt 0) -and ($sdigit -le 65535) -and ($fdigit -match '^\d+$') -and ($sdigit -match '^\d+$'))
      {
      return $true
      }
      else
      {
       return $false
      }
    }
    else
    {
    
    return $false
    }
   }
   catch
   {
   return $false
   }
}

# --------------------------------------------------------------------------------------
# This function is to test the validity of DC OU Location. The function will return $false
# if the specified location is either blank or code is not able to bind to the it. If Default
# the function will return $True.
# --------------------------------------------------------------------------------------
Function Test-DSOULocation (
    [string] $Domain,
    [string] $Username,
    [string] $Password,
    [string] $OULocation)  
{
    Add-Indent -Header "enter -> Test-DSOULocation" # increase indent in log file

    $ObjectLDAP = "LDAP://$Domain/$OULocation"
   
    If($OULocation -eq "") { 
        Remove-Indent -Footer "exit -> Test-DSOULocation" # decrease indent in log file
        Return $False 
    }

    If($OULocation -eq "Default") { 
        Remove-Indent -Footer "exit -> Test-DSOULocation" # decrease indent in log file
        Return $True 
    }

    If(($OULocation -ne "") -and ($OULocation -ne "Default"))
    {
        #creating a new class object; using the directory entry class to encapsulate the OU object and 
        #initializes a new instance of the directory entry class.
        $Status = New-Object -TypeName System.DirectoryServices.DirectoryEntry($ObjectLDAP,$Username,$Password) -ErrorAction SilentlyContinue
        
        # checking whether the schemaclassname property of the directory entry instance is 'organizationalUnit' or not
        If($Status.SchemaClassName -ne "organizationalUnit")
        {
            Write-DSLog -Level error -Message "Invalid OU Value - Either the specified object is not a valid type (i.e. Organizational Unit) or the DSSOE program is not able to bind to the specifed OU LDAP path with the given parameters. Please verify"
            Remove-Indent -Footer "exit -> Test-DSOULocation" # decrease indent in log file
            Return $False
        }
        Else { 
            Remove-Indent -Footer "exit -> Test-DSOULocation" # decrease indent in log file
            Return $True 
        }
    }
}



# --------------------------------------------------------------------------------------
# Validating the values for $domainpolicy and $domaincontrollerpolicy parameters. The valid
# value is true or false.
# --------------------------------------------------------------------------------------
Function Test-DSBaselinePolicy ($DomainPolicy, $DomainControllerPolicy)
{
    Add-Indent -Header "enter -> Test-DSBaselinePolicy" # increase indent in log file

    Write-DSLog -Level Info -Message "Validating DS Baseline Policy options - Domain policy: $DomainPolicy and Domain controller policy: $DomainControllerPolicy"
    If(((Test-ValuesRange -value $DomainPolicy -range ("True","False")) -eq [Boolean] $False) -or 
    ((Test-ValuesRange -value $DomainControllerPolicy -range ("True","False")) -eq [boolean] $False)) 
    {
        Write-DSLog -Level error -Message "Invalid Policy Value - Please enter a valid value for the Domain Policy and Domain Controller Policy options. The valid value is True or False"
        Remove-Indent -Footer "exit -> Test-DSBaselinePolicy" # decrease indent in log file
        return $False
    }
    Else 
    { 
        Write-DSLog -Level Info -Message "DS Baseline Policy options are successfully validated"
        Remove-Indent -Footer "exit -> Test-DSBaselinePolicy" # decrease indent in log file
        Return $True 
    }
}


# --------------------------------------------------------------------------------------
# Validating if the input contains only alphabets, if not function will return False. This
# code is taken from DSSOE 210 and modified / optimized here.
# --------------------------------------------------------------------------------------
function Test-Chars ($value)
{
    # Matching the each character of the $Value against [a-z] regex. The loop will continue
    # until the value of $i is less than the length of the $Value parameter
    for($i=0;$i -lt $value.length;$i++)
    { 
        $Status = $value.chars($i) -match "[a-z]" 
        if ($Status -eq $false)
         {
            # if the above case does not match the value of $Status variable (i.e. False) will be returned
            return $Status
         }         
    }
}

# --------------------------------------------------------------------------------------
# Validating the DXC Baseline OU Structure creation options. If the Accounttype is not
# Standard or Multitenat the function will return false. If Accountcode is not exactly 3
# chars long or does not contain only alphabets the function will return false.
# --------------------------------------------------------------------------------------
Function Test-DSOUStructure ($AccountType, $AccountCode) {
    Add-Indent -Header "enter -> Test-DSOUStructure" # increase indent in log file
    
    Write-DSLog -Level info -Message "Validating DS OU structure options - Account Type: $AccountType and Account Code: $AccountCode"

    If (-Not ($AccountType -in ("Standard","MultiTenant")))
    {
        Write-DSLog -Level error -Message "Invalid OU AccountType Value - The valid value for AccountType option is either Standard or MultiTenant."
        Remove-Indent -Footer "exit -> Test-DSOUStructure" # decrease indent in log file
        Return $False
    }
    #checking if accountcode is exactly 3 chars long and calling the test-chars function here to check whether the 
    #accountcode contains only alphabets or not.
    If (($AccountCode.Length -ne 3) -or ((Test-Chars -value $AccountCode) -eq $false)) 
    {
        Write-DSLog -Level error -Message "Invalid OU Account Code - The account code should be exactly 3 character long and must contain alphabets only. For a list of all the DXC specific account codes refer to Global Device and Server Naming Standards document. Contact Platform_Wintel_SOE@csc.com for details." 
        Remove-Indent -Footer "exit -> Test-DSOUStructure" # decrease indent in log file
        Return $False
    }
    Else
    {
        Write-DSLog -Level info -Message "DS OU Structure options are successfully validated"
        Remove-Indent -Footer "exit -> Test-DSOUStructure" # decrease indent in log file
        Return $True
    }
}

    
# --------------------------------------------------------------------------------------
# Checking the validity of the backup and maintenance XML options. The valid values for 
# enablebackup and enablebackupmaintenance options is true or false. Backupvolumepath has 
# to be a valid folder path.
# --------------------------------------------------------------------------------------
Function Test-DSConfigureBackup ($EnableBackupMaintenance, $BackupVolumePath) {
    Add-Indent -Header "enter -> Test-DSConfigureBackup" # increase indent in log file

    Write-DSLog -Level info -Message "Validating DS Backup maintenance and volume path options - Backup Maintenance: $EnableBackupMaintenance and Volume Path: $BackupVolumePath"

    # calling the test-valuesrange function to check if parameter value is passed as true / false or not
    If((Test-ValuesRange -value $EnableBackupMaintenance -range ("True","False")) -eq $False)
    {
        Write-DSLog -Level error -Message "Invalid BackupMaintenance Value - Please enter a valid value for EnableBackupMaintenace options. The valid values are True or False."
        Remove-Indent -Footer "exit -> Test-DSConfigureBackup" # decrease indent in log file
        Return $False
    }
    # test-path cmdlet is validating the path
    If(($BackupVolumePath -eq "") -or ((Test-Path -Path $BackupVolumePath -ErrorAction SilentlyContinue) -eq $False))
    {
        Write-DSLog -Level error -Message "Invalid Backup Path - Please enter a valid BackupVolumePath. The path should not be blank, null or invalid."
        Remove-Indent -Footer "exit -> Test-DSConfigureBackup" # decrease indent in log file
        Return $False
    }
    Else 
    {
        Write-DSLog -Level info -Message "DS Backup options are successfully validated"
        Remove-Indent -Footer "exit -> Test-DSConfigureBackup" # decrease indent in log file
        return $true
    }
}



# --------------------------------------------------------------------------------------
# Function to test the file path and return true or false. Test-Path cmdlet checks whether
# the specified path is a valid file or not (-pathtype leaf confirms that).
# --------------------------------------------------------------------------------------
Function Test-DSFileExistence ($FilePath) {
    Add-Indent -Header "enter -> Test-DSFileExistence" # increase indent in log file

    Write-DSLog -Level info -Message "Validating the existence of UserListExcelFile - $FilePath"

    If($FilePath -eq "") {
        Write-DSLog -Level info -Message "The value for UserListExcelFile parameter is not specified, thus it will not be implemented."
        Remove-Indent -Footer "exit -> Test-DSFileExistence" # decrease indent in log file
        return $True
    }

    If(($FilePath -ne "") -and (Test-Path -Path $FilePath -PathType Leaf -ErrorAction SilentlyContinue) -eq $False)
    {
        Write-DSLog -Level error -Message "Invalid File Path - Not able to reach to the specified path; please verify"
        Remove-Indent -Footer "exit -> Test-DSFileExistence" # decrease indent in log file
        Return $False
    }
    Else 
    {
        Write-DSLog -Level info -Message "UserList Excel File is successfully validated"
        Remove-Indent -Footer "exit -> Test-DSFileExistence" # decrease indent in log file
        Return $True 
    }
}


# --------------------------------------------------------------------------------------
# This function is meant to validate the BPA report options. The function will return 
# the boolean value of true or false.
# --------------------------------------------------------------------------------------
<#Function Test-DSBPAReport($GenerateBPA, $ReportPath) {
    
    Add-Indent -Header "enter -> Test-DSBPAReport" # increase indent in log file

    Write-DSLog -Level info -Message "Validating the BPA report options - GenerateBPA: $GenerateBPA and ReportPath: $ReportPath"
    
    #calling the test-valuesrange function to make sure the specified input value is either true or false, 
    #if not $False will be returned
    If((Test-ValuesRange -value $GenerateBPA -range ("True","False")) -eq $False) {
        Write-DSLog -Level error -Message "Invalid <BPAReport Generate> Value - Please enter a valid value for Generate attribute. The valid values are True or False."
        Remove-Indent -Footer "exit -> Test-DSBPAReport" # decrease indent in log file
        Return $False
    }

    If($GenerateBPA -eq "True") {
        #test-path cmdlet is validating the correctness of the specified path
        If(($ReportPath -eq "") -or ((Test-Path -Path $ReportPath -ErrorAction SilentlyContinue) -eq $False)) {
            Write-DSLog -Level error -Message "Invalid <BPAReport ReportPath> value - Please enter a valid value. Either the ReportPath is blank or cannot be reached to. Please verify."
            Remove-Indent -Footer "exit -> Test-DSBPAReport" # decrease indent in log file
            Return $False
        }
        Else {
            Write-DSLog -Level info -Message "BPA Report options are successfully validated"
            Remove-Indent -Footer "exit -> Test-DSBPAReport" # decrease indent in log file
            return $true
        }
    }
    Else {
        Write-DSLog -Level info -Message "Generate BPA parameter is set to False, thus BPA report will not be generated."
        Remove-Indent -Footer "exit -> Test-DSBPAReport" # decrease indent in log file
        return $true
    }    
} - Not accepting BPAparameters, hence commenting this section - Arun 08-06-16#>
        
        
# --------------------------------------------------------------------------------------
# Function is meant to validate the IP address when one or more is specified as a comma
# separated value. TryParse() static method of the [System.Net.IPAddress] class does the 
# validation and return true or false.
# --------------------------------------------------------------------------------------

Function Test-MultipleIPAddress ($IPAddress) {
    
    Add-Indent -Header "enter -> Test-MultipleIPAddress" # increase indent in log file

    #if input value is blank, return $false
    If($IPAddress -eq "") 
    { 
        Write-DSLog -Level error -Message "Blank IP Address - Please specify an IP Address" 
        Remove-Indent -Footer "exit -> Test-MultipleIPAddress" # decrease indent in log file
        Return $False 
    }
    
    #split() function is splitting the values in $ipaddress variable. If there are multiple values,
    # they will be split by the "," to create an array of values.
    $IPList = $IPAddress.Split(",")

    #For each object in $IPList array variable, TryParse() static method of the [System.Net.IPAddress]
    # class is validating it and it will return $true or $false accordingly.
    $IPValidate = $IPList | ForEach-Object { [System.Net.IPAddress]::TryParse($_, [Ref]$null) }

    #using the -contains comparision operator to get the final boolean value
    If($IPValidate -contains $False)
    {
        Write-DSLog -Level error -Message "Invalid IP Address - Please specify a valid IP Address"
        Remove-Indent -Footer "exit -> Test-MultipleIPAddress" # decrease indent in log file
        Return $False
    }
    Else { 
        Remove-Indent -Footer "exit -> Test-MultipleIPAddress" # decrease indent in log file
        Return $True 
    }
}

# --------------------------------------------------------------------------------------
# Function to validate the Static ports value specified by the user. The valid value is 
# an interger value between 1 - 65535.
# --------------------------------------------------------------------------------------
Function Test-DSStaticPorts(
    [string] $ADReplicationPort,
    [string] $NetlogonPort,
    #[string] $FRSPort,
    [string] $DFSRPort) {
    
    Add-Indent -Header "enter -> Test-DSStaticPorts" # increase indent in log file

    Write-DSLog -Level info -Message "Validating the Static ports"
    
    #array with the port numbers
    #[Array]$PortList = $ADReplicationport,$NetlogonPort,$FRSPort,$DFSRPort
    [Array]$PortList = $ADReplicationport,$NetlogonPort,$DFSRPort

    <##frs and dfsr ports cannot be configured at the same time bcoz DC can only use either of them for sysvol replication
    If(($FRSPort -ne "") -and ($DFSRPort -ne "")) {
        Write-DSLog -Level error -Message "Static ports for both, FRS and DFSR, cannot be configured at the same time because the Domain Controller can either use FRS or DFSR for SYSVOL replication. So please set port value for either of them."
        Remove-Indent -Footer "exit -> Test-DSStaticPorts" # decrease indent in log file
        return $false
    }#>

    #to config AD repl on static port, both AD repl port and netlogon port must be specified
    If((($ADReplicationport -ne "") -and ($NetlogonPort -eq "")) -or (($ADReplicationport -eq "") -and ($NetlogonPort -ne ""))) {
        Write-DSLog -Level error -Message "To configure AD replication to Static port both AD Replication port and Netlogon Port must be specified. Refer to https://support.microsoft.com/en-us/kb/224196 article for details."
        Remove-Indent -Footer "exit -> Test-DSStaticPorts" # decrease indent in log file
        return $false
    }

    #if only AD repl ports are specified
    #If((($ADReplicationport -ne "") -and ($NetlogonPort -ne "")) -and (($FRSPort -eq "") -and ($DFSRPort -eq ""))) {
    If((($ADReplicationport -ne "") -and ($NetlogonPort -ne "")) -and ($DFSRPort -eq "")) {
        Write-DSLog -Level info -Message "Only AD replication ports are specified; AD Replication:$ADReplicationport & Netlogon:$NetlogonPort. Verifying the specified ports"
        [Array]$PortList = $ADReplicationport,$NetlogonPort
        $portArray = @() # empty array
        $PortList | ForEach-Object { $portArray+= (($_ -gt 1 -and $_ -le 65535) -and ([int]::TryParse($_, [Ref]$null))) }
    
        If($portArray -contains $False)
        {
            Write-DSLog -Level error -Message "Invalid Port - Please enter a valid Port Number. Valid port number is an integer between 1 - 65535."
            Remove-Indent -Footer "exit -> Test-DSStaticPorts" # decrease indent in log file
            Return $False
        }   
        Else 
        { 
            Write-DSLog -Level info -Message "Static ports are successfully validated"
            Remove-Indent -Footer "exit -> Test-DSStaticPorts" # decrease indent in log file
            Return $True 
        }
    }

    <##If AD repl, netlogon and FRS ports are specified
    If(($ADReplicationport -ne "") -and ($NetlogonPort -ne "") -and ($FRSPort -ne "")) {
        Write-DSLog -Level info -Message "AD replication ports and FRS replication port are specified; AD Replication:$ADReplicationport, Netlogon:$NetlogonPort FRS:$FRSPort. Verifying the specified ports"
        [Array]$PortList = $ADReplicationport,$NetlogonPort,$FRSPort
        $portArray = @() # empty array
        $PortList | ForEach-Object { $portArray+= (($_ -gt 1 -and $_ -le 65535) -and ([int]::TryParse($_, [Ref]$null))) }
    
        If($portArray -contains $False)
        {
            Write-DSLog -Level error -Message "Invalid Port - Please enter a valid Port Number. Valid port number is an integer between 1 - 65535."
            Remove-Indent -Footer "exit -> Test-DSStaticPorts" # decrease indent in log file
            Return $False
        }   
        Else 
        { 
            Write-DSLog -Level info -Message "Static ports are successfully validated"
            Remove-Indent -Footer "exit -> Test-DSStaticPorts" # decrease indent in log file
            Return $True 
        }
    }#>

    #if AD repl, netlogon and DFSR ports are specified
    If(($ADReplicationport -ne "") -and ($NetlogonPort -ne "") -and ($DFSRPort -ne "")) {
        Write-DSLog -Level info -Message "AD replication ports and DFSR replication port are specified; AD Replication:$ADReplicationport, Netlogon:$NetlogonPort DFSR:$DFSRPort. Verifying the specified ports"
        [Array]$PortList = $ADReplicationport,$NetlogonPort,$DFSRPort
        $portArray = @() # empty array
        $PortList | ForEach-Object { $portArray+= (($_ -gt 1 -and $_ -le 65535) -and ([int]::TryParse($_, [Ref]$null))) }
    
        If($portArray -contains $False)
        {
            Write-DSLog -Level error -Message "Invalid Port - Please enter a valid Port Number. Valid port number is an integer between 1 - 65535."
            Remove-Indent -Footer "exit -> Test-DSStaticPorts" # decrease indent in log file
            Return $False
        }   
        Else 
        { 
            Write-DSLog -Level info -Message "Static ports are successfully validated"
            Remove-Indent -Footer "exit -> Test-DSStaticPorts" # decrease indent in log file
            Return $True 
        }
    }

    #if only DFSR port is specified
    #If($ADReplicationport -eq "" -and $NetlogonPort -eq "" -and $FRSPort -eq "" -and $DFSRPort -ne "") {
    If($ADReplicationport -eq "" -and $NetlogonPort -eq "" -and $DFSRPort -ne "") {
        Write-DSLog -Level info -Message "Only DFSR replication port is specified; DFSR:$DFSRPort. Verifying the specified port"
        [Array]$PortList = $DFSRPort
        $portArray = @() # empty array
        $PortList | ForEach-Object { $portArray+= (($_ -gt 1 -and $_ -le 65535) -and ([int]::TryParse($_, [Ref]$null))) }
    
        If($portArray -contains $False)
        {
            Write-DSLog -Level error -Message "Invalid Port - Please enter a valid Port Number. Valid port number is an integer between 1 - 65535."
            Remove-Indent -Footer "exit -> Test-DSStaticPorts" # decrease indent in log file
            Return $False
        }   
        Else 
        { 
            Write-DSLog -Level info -Message "Static ports are successfully validated"
            Remove-Indent -Footer "exit -> Test-DSStaticPorts" # decrease indent in log file
            Return $True 
        }
    }

    <##if only FRS port is specified
    If($ADReplicationport -eq "" -and $NetlogonPort -eq "" -and $DFSRPort -eq "" -and $FRSPort -ne "") {
        Write-DSLog -Level info -Message "Only FRS replication port is specified; FRS:$FRSPort. Verifying the specified port"
        [Array]$PortList = $FRSPort
        $portArray = @() # empty array
        $PortList | ForEach-Object { $portArray+= (($_ -gt 1 -and $_ -le 65535) -and ([int]::TryParse($_, [Ref]$null))) }
    
        If($portArray -contains $False)
        {
            Write-DSLog -Level error -Message "Invalid Port - Please enter a valid Port Number. Valid port number is an integer between 1 - 65535."
            Remove-Indent -Footer "exit -> Test-DSStaticPorts" # decrease indent in log file
            Return $False
        }   
        Else 
        { 
            Write-DSLog -Level info -Message "Static ports are successfully validated"
            Remove-Indent -Footer "exit -> Test-DSStaticPorts" # decrease indent in log file
            Return $True 
        }
    }#>
    
    #if all the ports are blank, write error and return $false
    #If($ADReplicationport -eq "" -and $NetlogonPort -eq "" -and $FRSPort -eq "" -and $DFSRPort -eq "") {
    If($ADReplicationport -eq "" -and $NetlogonPort -eq "" -and $DFSRPort -eq "") {
        Write-DSLog -Level error -Message "None of the ports were specified. If you do not wish to configure static ports then set the configure tag to False"
        Remove-Indent -Footer "exit -> Test-DSStaticPorts" # decrease indent in log file
        return $false
    }
}


# ---------------------------------------------------------------------------------------
# This function is meant to check the AD database path, log file path and sysvol path. 
# The function will return a $true or $false accordingly to how the conditions are met
# ---------------------------------------------------------------------------------------
Function Test-ADContentPath ([String] $Path) {
    
    Add-Indent -Header "enter -> Test-ADContentPath" # increase indent in log file

    #using get-psdrive cmdlet to get the list of filesytem drives. Root property is listing the root names of the 
    #drives found, example C:\ or D:\
    $DirPath = @(Get-PSDrive -PSProvider FileSystem).Root
    #Fetching the data drives (read-write types)
    $DriveType = Get-WmiObject -Class Win32_LogicalDisk | Where-Object { $_.drivetype -eq 3 }
    #storing the device ID of the fetched data drives
    $DeviceID = $DriveType.DeviceID
    
    Switch($Path) {
                    
        { $_ -eq "" } { 
            Write-DSLog -Level error -Message "Blank Folder Path - The Path cannot be blank"
            Remove-Indent -Footer "exit -> Test-ADContentPath" # decrease indent in log file
            Return $False 
        }
        #checking if the length of the input value. Input value that has the length property less then 3 cannot be 
        #a valid input path.
        { $_.Length -lt 3 } { 
            Write-DSLog -Level error -Message "Length too Short - The path is too short to be a valid path. An example of a valid path is C:\FolderName"
            Remove-Indent -Footer "exit -> Test-ADContentPath" # decrease indent in log file
            return $False 
        }        
        #checking if the path specified is a valid syntax or not. -isvalid parameter checks if the path specified is 
        #valid or otherwise.
        { ((Test-Path -Path $_ -IsValid) -eq $False) } { 
            Write-DSLog -Level error -Message "Invalid Path - Please enter a valid folder path. For example, C:\FolderName"
            Remove-Indent -Footer "exit -> Test-ADContentPath" # decrease indent in log file
            Return $False
        }
        #the second and third character of the specified path should be : and \ respectively. If not, path is not valid.
        { (($_.Chars(1) -ne ":") -or ($_.Chars(2) -ne "\")) } { 
            Write-DSLog -Level error -Message "Invalid Path - Please enter a valid folder path. For example, C:\FolderName"
            Remove-Indent -Footer "exit -> Test-ADContentPath" # decrease indent in log file
            Return $False 
        }

        { (-not($_.Substring(0,2) -in $DeviceID)) } {
	        Write-DSLog -Level error -Message "Invalid Drive - The path does not exist. Please enter a valid path."
            Remove-Indent -Footer "exit -> Test-ADContentPath" # decrease indent in log file	        
            return $false
        }

        # root of filesystem drive is an invalid input path. AD folders should not be created on the root of the drives.
        { (($_ -in $DirPath) -eq $True) } { 
            Write-DSLog -Level error -Message "Drive Root - Please enter a valid folder path. The path cannot be the root of a drive. The path should be a folder path."
            Remove-Indent -Footer "exit -> Test-ADContentPath" # decrease indent in log file
            Return $False
        }        
        #if the test-path cmdlets returns a true value that means the folder already exists and it along with its sub-folders must be deleted first.
        { ((Test-Path -Path $_) -eq $True) } { 
            Write-DSLog -Level info -Message "The folder already exists. Delete the folder."
            [System.IO.Directory]::Delete($Path,$True)
            Remove-Indent -Footer "exit -> Test-ADContentPath" # decrease indent in log file
            return $true 
        }

        Default { 
            #Write-DSLog -Level error -Message "Creating the Folder"
            #[System.IO.Directory]::CreateDirectory($Path) 
            Remove-Indent -Footer "exit -> Test-ADContentPath" # decrease indent in log file
            Return $True 
        }
    }
}

                                             
# ---------------------------------------------------------------------------------------
# This function is to list all the DCs in the domain and then match the one user specified as
# input with the list to determine if its there or otherwise. If its there in the list 
# return $true, else $false.
# todo: pass domain, password, user etc. as parameters
# ---------------------------------------------------------------------------------------
Function Test-DCExists (
    [String] $DCFQDN,
    [String] $DomainName,
    [String] $UserName,
    [string] $Password)
{
    Add-Indent -Header "enter -> Test-DCExists" # increase indent in log file

    $UserID = "$DomainName\$UserName"

    # creating a new class object. DirectoryContext class identifies a specific directory
    # and the credentials that are used to access the directory 
    $DomainInfo = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext("Domain",$DomainName,$UserID,$Password)
        
    Try 
    {
        # Try to use the GetDomain static method of the [System.DirectoryServices.ActiveDirectory.Domain] class to find the list of all
        # the DCs in the DirectoryContext $DomainInfo
        $FindAllDCs = [System.DirectoryServices.ActiveDirectory.Domain]::GetDomain($DomainInfo).FindAllDomainControllers()
        
        # determining if the list of DCs have the one specified by the user; yes return $true otherwise $false
        If($FindAllDCs.Name -contains $DCFQDN) { 
            Write-DSLog -Level info -Message "The Domain Controller $DCFQDN exists"
            Remove-Indent -Footer "exit -> Test-DCExists" # decrease indent in log file
            Return $True 
        }
        Else { 
            Remove-Indent -Footer "exit -> Test-Test-DCExists" # decrease indent in log file    
            Return $False 
        }
    }
    Catch 
    {
        #catch the error from the try block and output the message
        Write-DSLog -Level error -Message $_.Exception.Message
        Remove-Indent -Footer "exit -> Test-DCExists" # decrease indent in log file
        Return $False
    }
}


# ---------------------------------------------------------------------------------------
# Function is meant to list all the sites in the configuration partition and then validate 
# that the user specified site is there in the list of sites fetched. If yes return 
# true else false. This function is taken from DSSOE 210 and modified / optimized here.
# ---------------------------------------------------------------------------------------
Function Test-DSSiteExist (
    [string] $Value,
    [string] $Domain,
    [string] $Username,
    [string] $Password)
    
    {
            Add-Indent -Header "enter -> Test-DSSiteExist" # increase indent in log file

            #calling Test-NameValidation function and checking if $Domain exists or not
            If((Test-NameValidation -Name $Domain -NameType 3) -ne 0)
            {
                Write-DSLog -Level error -Message "Domain does not exist"
                Remove-Indent -Footer "exit -> Test-DSSiteExist" # decrease indent in log file
                Return $False
            }

            #calling test-dscredentials function and checking if creds are valid or not
            If((Test-DSCredentials -ContextType Domain -ContextName $Domain -UserName $Username -Password $Password) -eq $False)
            {
                Write-DSLog -Level error -Message "Invalid Credentials"
                Remove-Indent -Footer "exit -> Test-DSSiteExist" # decrease indent in log file 
                Return $false
            } 

            # storing the ldap path of the $domain name parameter in the $ldappath variable
            $LDAPPath = "LDAP://$Domain"
                   
            #creating System.directoryservices.directoryentry class object. Using the directory entry class to
            # encapsulate the $LDAPPath value and initializes a new instance of the directory entry class.
            $DomainInfo = New-Object System.DirectoryServices.DirectoryEntry($LDAPPath,$Username,$Password)
        
            # fsmoroleowner property lists the DN of the DCs holding the FSMO roles. Split(",") method is splitting the 
            # DC names by comma. 
            $FsmoSplit = ($DomainInfo.fSMORoleOwner).Split(",")
        
            # using the for loop to check if any element of $fsmosplit array is equal to "CN=Configuration"; if yes the index number
            # of the element is stored in $index variable.
            For($i=0;$i -lt $FsmoSplit.count;$i++) 
            {
                if($FsmoSplit[$i] -eq "CN=Configuration")
                {
                    $index = $i
                }
            }
        
            # declaring a null value variable
            $FinalConfig = ""

            # the final value of the for loop will be "CN=configuration" + everything else that upto the last index value. 
            #i.e. the configuration partition DN.
            for($i=$index;$i -lt $fsmosplit.count;$i++)
	        {
		        $finalconfig = ($finalconfig + $fsmosplit[$i]) + ","
	        }
    
            # creating a new class object. DirectoryContext class identifies a specific directory
            # and the credentials that are used to access the directory 
            $DomaininfoDC = new-object System.DirectoryServices.ActiveDirectory.DirectoryContext("Domain",$Domain,$Username,$Password)

            #using the GetDomain static method of the [System.DirectoryServices.ActiveDirectory.Domain] class to find 
            #the DC holding the PDC role
            # in the DirectoryContext $DomainInfoDC. Combining pdc role owner info + configuration partition DN determined 
            #above to make the ldap path of the PDC role holder DC.
            $pdcLDAPname = "LDAP://" + ([System.DirectoryServices.ActiveDirectory.Domain]::getdomain($domaininfoDC)).pdcroleowner.name + "/" + $finalconfig.Substring(0,$finalconfig.LastIndexOf(","))
    
            # creating another class object for PDC object
            $configinfo = new-object DirectoryServices.DirectoryEntry($pdcLDAPname,$Username,$Password)
        
            # System.DirectoryServices.DirectorySearcher class performs queries against AD DS objects.
	        $searcher = New-Object System.DirectoryServices.DirectorySearcher($configinfo)
	    
            # filtering the searcher object for sites only
            $searcher.filter = "((objectClass=site))" 
	    
            $searcher.SearchRoot  = $configinfo

	        $PropertiestoLoad = $searcher.PropertiesToLoad.Add("name")
        
            # retrieving the list of all the sites
	        $allsites = ($searcher.FindAll()).properties.name
        
            # checking if Site value passed by the user is in the $allsite list, if yes the condition will return $true else $false.
            If($allsites -contains $Value) { 
                Remove-Indent -Footer "exit -> Test-DSSiteExist"
                Return $true                 
            }
            Else { 
                Write-DSLog -Level error -Message "Specified AD Site does not exist"
                Remove-Indent -Footer "exit -> Test-DSSiteExist" # decrease indent in log file
                Return $false 
            }  
    }
        
     
# ---------------------------------------------------------------------------------------
# Function is meant to test the validity of the Child domain FQDN. Internally it calls the
# Test-DomainName function to run the check against conditions and if returned value is not
# equal to $true the function will return $false else $true.
# ---------------------------------------------------------------------------------------
Function Test-DSChildDomainName (
    [string] $ChildDomainName,
    [string] $ParentDomainName)

    {
        Add-Indent -Header "enter -> Test-DSChildDomainName" # increase indent in log file

        If((Test-CharNum -Value $ChildDomainName) -eq $false) {
            Write-DSLog -Level error -Message "Invalid child domain name. Make sure that the specified name is a single-label name and contain [a-z 0-9-] chars only."
            Remove-Indent -Footer "exit -> Test-DSChildDomainName" # decrease indent in log file
            return $false
        }
        else {        
            Write-DSLog -Level info -Message "Single label child domain name is validated successfully"
            #combining child domain name and parent domain name to form the child domain fqdn
            $ChildDomainFQDN = "$ChildDomainName.$ParentDomainName"

            Write-DSLog -Level info -Message "Combined the single label child domain name and parent domain name to form the child domain FQDN: $ChildDomainFQDN"

            #calling test-domainname function to check the validity of the fqdn    
            If((Test-DomainName -Name $ChildDomainFQDN) -ne $True) 
            {
                Remove-Indent -Footer "exit -> Test-DSChildDomainName" # decrease indent in log file
                Return $False 
            }
            Else 
            {
                Remove-Indent -Footer "exit -> Test-DSChildDomainName" # decrease indent in log file
                Return $True
            }
        }
    }

    

# ----------------------------------------------------------------------------------------
# Function to validate the domain functional level value in the case of new forest new domain
# deployment. If user inputs a value outside the following ones, the function will return $false
# FFL - Windows2008Forest      DFL - Windows2008Domain / Windows2008R2Domain / Windows2012Domain / Windows2012R2Domain / Windows2016Domain
# FFL - Windows2008R2Forest    DFL - Windows2008R2Domain / Windows2012Domain / Windows2012R2Domain / Windows2016Domain
# FFL - Windows2012Forest      DFL - Windows2012Domain / Windows2012R2Domain / Windows2016Domain
# FFL - Windows2012R2Forest    DFL - Windows2012R2Domain / Windows2016Domain
# FFL - Windows2016Forest      DFL - Windows2016Domain
# ----------------------------------------------------------------------------------------
Function Test-ForestDomainLevel {
param([string] $ForestLevel,
      [string] $DomainLevel)

    Add-Indent -Header "enter -> Test-ForestDomainLevel" # increase indent in log file

    If(Test-OSIsWindowsServer2008R2){
     If((Test-ValuesRange -value $ForestLevel -range ("Windows2003Forest","Windows2008Forest","Windows2008R2Forest")) -eq $false)
     {
        Write-DSLog -Level error -Message "Invalid Forest Functional Level Value - Valid value for Windows Server 2008 R2 is Windows2003Forest / Windows2008Forest / Windows2008R2Forest"
        Remove-Indent -Footer "exit -> Test-ForestDomainLevel" # decrease indent in log file
        return $false
     }

     If((Test-ValuesRange -value $DomainLevel -range ("Windows2003Domain","Windows2008Domain","Windows2008R2Domain")) -eq $false)
     {
        Write-DSLog -Level error -Message "Invalid Domain Functional Level Value - Valid value is Windows2003Domain / Windows2008Domain / Windows2008R2Domain"
        Remove-Indent -Footer "exit -> Test-ForestDomainLevel" # decrease indent in log file
        return $false
     }

    }

    If(Test-OSIsWindowsServer2012){
     If((Test-ValuesRange -value $ForestLevel -range ("Windows2003Forest","Windows2008Forest","Windows2008R2Forest","Windows2012Forest")) -eq $false)
     {
        Write-DSLog -Level error -Message "Invalid Forest Functional Level Value - Valid value for Windows Server 2012 R1 is Windows2003Forest / Windows2008Forest / Windows2008R2Forest /Windows2012Forest"
        Remove-Indent -Footer "exit -> Test-ForestDomainLevel" # decrease indent in log file
        return $false
     }

     If((Test-ValuesRange -value $DomainLevel -range ("Windows2003Domain","Windows2008Domain","Windows2008R2Domain","Windows2012Domain")) -eq $false)
     {
        Write-DSLog -Level error -Message "Invalid Domain Functional Level Value - Valid value is Windows2003Domain / Windows2008Domain / Windows2008R2Domain / Windows2012Domain"
        Remove-Indent -Footer "exit -> Test-ForestDomainLevel" # decrease indent in log file
        return $false
     }

    }
    
   If(Test-OSIsWindowsServer2012R2){
     If((Test-ValuesRange -value $ForestLevel -range ("Windows2008Forest","Windows2008R2Forest","Windows2012Forest","Windows2012R2Forest")) -eq $false)
     {
        Write-DSLog -Level error -Message "Invalid Forest Functional Level Value - Valid value for Windows Server 2012 R2 is Windows2008Forest / Windows2008R2Forest / Windows2012Forest / Windows2012R2Forest"
        Remove-Indent -Footer "exit -> Test-ForestDomainLevel" # decrease indent in log file
        return $false
     }

     If((Test-ValuesRange -value $DomainLevel -range ("Windows2008Domain","Windows2008R2Domain","Windows2012Domain","Windows2012R2Domain")) -eq $false)
     {
        Write-DSLog -Level error -Message "Invalid Domain Functional Level Value - Valid value is Windows2008Domain / Windows2008R2Domain / Windows2012Domain / Windows2012R2Domain"
        Remove-Indent -Footer "exit -> Test-ForestDomainLevel" # decrease indent in log file
        return $false
     }
   }

   If(Test-OSIsWindowsServer2016) {
        If((Test-ValuesRange -value $ForestLevel -range ("Windows2008Forest","Windows2008R2Forest","Windows2012Forest","Windows2012R2Forest","Windows2016Forest")) -eq $false) {
            Write-DSLog -Level error -Message "Invalid Forest Functional Level Value - Valid value for Windows Server 2016 is Windows2008Forest / Windows2008R2Forest / Windows2012Forest / Windows2012R2Forest / Windows2016Forest"
            Remove-Indent -Footer "exit -> Test-ForestDomainLevel" # decrease indent in log file
            return $false
        }

        If((Test-ValuesRange -value $DomainLevel -range ("Windows2008Domain","Windows2008R2Domain","Windows2012Domain","Windows2012R2Domain","Windows2016Domain")) -eq $false) {
            Write-DSLog -Level error -Message "Invalid Domain Functional Level Value - Valid value is Windows2008Domain / Windows2008R2Domain / Windows2012Domain / Windows2012R2Domain / Windows2016Domain"
            Remove-Indent -Footer "exit -> Test-ForestDomainLevel" # decrease indent in log file
            return $false
        }
   }

    Switch($ForestLevel)
    { 
        {(($ForestLevel -eq "Windows2008Forest") -and `
        (-not ($DomainLevel -in ("Windows2008Domain","Windows2008R2Domain","Windows2012Domain","Windows2012R2Domain","Windows2016Domain"))))} {
            Write-DSLog -Level error -Message "Invalid Domain Functional Level - Valid value is Windows2008Domain / Windows2008R2Domain / Windows2012Domain / Windows2012R2Domain / Windows2016Domain"
            Remove-Indent -Footer "exit -> Test-ForestDomainLevel" # decrease indent in log file
            return $false
        }

        {(($ForestLevel -eq "Windows2008R2Forest") -and `
        (-not ($DomainLevel -in ("Windows2008R2Domain","Windows2012Domain","Windows2012R2Domain","Windows2016Domain"))))} {
            Write-DSLog -Level error -Message "Invalid Domain Functional Level - Valid value is Windows2008R2Domain / Windows2012Domain / Windows2012R2Domain / Windows2016Domain"
            Remove-Indent -Footer "exit -> Test-ForestDomainLevel" # decrease indent in log file
            return $false
        }

        {(($ForestLevel -eq "Windows2012Forest") -and `
        (-not ($DomainLevel -in ("Windows2012Domain","Windows2012R2Domain","Windows2016Domain"))))} {
            Write-DSLog -Level error -Message "Invalid Domain Functional Level - Valid value is Windows2012Domain / Windows2012R2Domain / Windows2016Domain"
            Remove-Indent -Footer "exit -> Test-ForestDomainLevel" # decrease indent in log file
            return $false
        }

        {(($ForestLevel -eq "Windows2012R2Forest") -and `
        (-not ($DomainLevel -in ("Windows2012R2Domain","Windows2016Domain"))))} {
            Write-DSLog -Level error -Message "Invalid Domain Functional Level - Valid value is Windows2012R2Domain / Windows2016Domain"
            Remove-Indent -Footer "exit -> Test-ForestDomainLevel" # decrease indent in log file
            return $false
        }

        {(($ForestLevel -eq "Windows2016Forest") -and `
        (-not ($DomainLevel -in ("Windows2016Domain"))))} {
            Write-DSLog -Level error -Message "Invalid Domain Functional Level - Valid value is Windows2016Domain"
            Remove-Indent -Footer "exit -> Test-ForestDomainLevel" # decrease indent in log file
            return $false
        }

        <#{(($ForestLevel -eq "Unknown") -and `
        (-not ($DomainLevel -in ("Windows2016Domain","Unknown"))))} {
            Write-DSLog -Level error -Message "Invalid Domain Functional Level - Valid value is Windows2016Domain / Unknown (for TP5)"
            Remove-Indent -Footer "exit -> Test-ForestDomainLevel" # decrease indent in log file
            return $false
        }#>

        Default { 
            Remove-Indent -Footer "exit -> Test-ForestDomainLevel" # decrease indent in log file
            return $true 
        }
    }
}

            
# --------------------------------------------------------------------------------------------------------------
# This function will return the Forest Functional Level of the forest. This function will particularly be used
# to get the forest functional level in the case of new child domain and new tree domain.
# ---------------------------------------------------------------------------------------------------------------
Function Get-DSForestFunctionalLevel {
Param([string] $Domain,
      [string] $username,
      [string] $password)
        
        #loading the AccountManagement assembly
        Add-Type -AssemblyName System.DirectoryServices.AccountManagement
        
        $DomainLDAP = "LDAP://$Domain/RootDSE"

        $DomainInfo = New-Object -TypeName System.DirectoryServices.DirectoryEntry($DomainLDAP,$username,$password)
        
        return ($DomainInfo.forestFunctionality)
    }



# --------------------------------------------------------------------------------------------------------------
# This function will validate the domain functional level based on the forest functional level of the forest
# retrieved via Get-DSForestFunctionalLevel function.
# ---------------------------------------------------------------------------------------------------------------
Function Test-DSDomainLevel {
Param([string] $Domainlevel,
      [string] $Domain,
      [string] $username,
      [string] $password)

    Add-Indent -Header "enter -> Test-DSDomainLevel" # increase indent in log file

    #calling the get-dsforestfunctionallevel function to retrieve the FFL of the forest
    $ForestLevel = Get-DSForestFunctionalLevel -Domain $Domain -username $username -password $password

    Write-DSLog -Level info -Message "The Forest Functional Level of the forest is $ForestLevel"

    #If((Test-ValuesRange -value $ForestLevel -range ("2","3","4","5","6")) -eq $false)
    If((Test-ValuesRange -value $ForestLevel -range ("3","4","5","6","7")) -eq $false) #for Windows Server 2016
    {
        #Write-DSLog -Level error -Message "Invalid forest functional level for Windows Server 2012 & Windows Server 2012 R2 Domain Controllers."
        Write-DSLog -Level error -Message "Invalid forest functional level for Windows Server 2016 Domain Controllers."
        Remove-Indent -Footer "exit -> Test-DSDomainLevel" # decrease indent in log file
        return $false
    }

    If(Test-OSIsWindowsServer2008R2){
     If((Test-ValuesRange -value $DomainLevel -range ("Windows2003Domain","Windows2008Domain","Windows2008R2Domain")) -eq $false)
     {
        Write-DSLog -Level error -Message "Invalid Domain Functional Level Value - Valid value is Windows2003Domain / Windows2008Domain / Windows2008R2Domain"
        Remove-Indent -Footer "exit -> Test-DSDomainLevel" # decrease indent in log file
        return $false
     }

    }

    If(Test-OSIsWindowsServer2012){
     If((Test-ValuesRange -value $DomainLevel -range ("Windows2003Domain","Windows2008Domain","Windows2008R2Domain","Windows2012Domain")) -eq $false)
     {
        Write-DSLog -Level error -Message "Invalid Domain Functional Level Value - Valid value is Windows2003Domain / Windows2008Domain / Windows2008R2Domain / Windows2012Domain"
        Remove-Indent -Footer "exit -> Test-DSDomainLevel" # decrease indent in log file
        return $false
     }

    }
    
   If(Test-OSIsWindowsServer2012R2){
    If((Test-ValuesRange -value $DomainLevel -range ("Windows2008Domain","Windows2008R2Domain","Windows2012Domain","Windows2012R2Domain")) -eq $false)
     {
        Write-DSLog -Level error -Message "Invalid Domain Functional Level Value - Valid value is Windows2008Domain / Windows2008R2Domain / Windows2012Domain / Windows2012R2Domain"
        Remove-Indent -Footer "exit -> Test-DSDomainLevel" # decrease indent in log file
        return $false
     }

   }

   If(Test-OSIsWindowsServer2016){
    If((Test-ValuesRange -value $DomainLevel -range ("Windows2008Domain","Windows2008R2Domain","Windows2012Domain","Windows2012R2Domain","Windows2016Domain")) -eq $false)
     {
        Write-DSLog -Level error -Message "Invalid Domain Functional Level Value - Valid value is Windows2008Domain / Windows2008R2Domain / Windows2012Domain / Windows2012R2Domain / Windows2016Domain"
        Remove-Indent -Footer "exit -> Test-DSDomainLevel" # decrease indent in log file
        return $false
     }

   }


    Switch($ForestLevel)
    {
        #{(($ForestLevel -eq "2") -and `
        #(-not ($DomainLevel -in ("Windows2003Domain","Windows2008Domain","Windows2008R2Domain","Windows2012Domain","Windows2012R2Domain"))))} {
         #   Write-DSLog -Level error -Message "Invalid Domain Functional Level - Valid value is Windows2003Domain / Windows2008Domain / Windows2008R2Domain / Windows2012Domain / Windows2012R2Domain because the forest functional level is Windows2003Forest"
          #  Remove-Indent -Footer "exit -> Test-DSDomainLevel" # decrease indent in log file
          #  return $false
        #}

        {(($ForestLevel -eq "3") -and `
        (-not ($DomainLevel -in ("Windows2008Domain","Windows2008R2Domain","Windows2012Domain","Windows2012R2Domain","Windows2016Domain"))))} {
            Write-DSLog -Level error -Message "Invalid Domain Functional Level - Valid value is Windows2008Domain / Windows2008R2Domain / Windows2012Domain / Windows2012R2Domain / Windows2016Domain because the forest functional level is Windows2008Forest"
            Remove-Indent -Footer "exit -> Test-DSDomainLevel" # decrease indent in log file
            return $false
        }

        {(($ForestLevel -eq "4") -and `
        (-not ($DomainLevel -in ("Windows2008R2Domain","Windows2012Domain","Windows2012R2Domain","Windows2016Domain"))))} {
            Write-DSLog -Level error -Message "Invalid Domain Functional Level - Valid value is Windows2008R2Domain / Windows2012Domain / Windows2012R2Domain / Windows2016Domain because the forest functional level is Windows2008R2Forest"
            Remove-Indent -Footer "exit -> Test-DSDomainLevel" # decrease indent in log file
            return $false
        }

        {(($ForestLevel -eq "5") -and `
        (-not ($DomainLevel -in ("Windows2012Domain","Windows2012R2Domain","Windows2016Domain"))))} {
            Write-DSLog -Level error -Message "Invalid Domain Functional Level - Valid value is Windows2012Domain / Windows2012R2Domain / Windows2016Domain because the forest functional level is Windows2012Forest"
            Remove-Indent -Footer "exit -> Test-DSDomainLevel" # decrease indent in log file
            return $false
        }

        {(($ForestLevel -eq "6") -and `
        (-not ($DomainLevel -in ("Windows2012R2Domain","Windows2016Domain"))))} {
            Write-DSLog -Level error -Message "Invalid Domain Functional Level - Valid value is Windows2012R2Domain / Windows2016Domain because the forest functional level is Windows2012R2Forest"
            Remove-Indent -Footer "exit -> Test-DSDomainLevel" # decrease indent in log file
            return $false
        }

        {(($ForestLevel -eq "7") -and `
        (-not ($DomainLevel -in ("Windows2016Domain"))))} {
            Write-DSLog -Level error -Message "Invalid Domain Functional Level - Valid value is Windows2016Domain because the forest functional level is Windows2016Forest"
            Remove-Indent -Footer "exit -> Test-DSDomainLevel" # decrease indent in log file
            return $false
        }

        Default { 
            Remove-Indent -Footer "exit -> Test-DSDomainLevel" # decrease indent in log file
            return $true 
        }
    }
}


#-----------------------------------------------------------------------------------------
# This function is meant to retrieve the AD details on a particular user account.
# The output of this function is a directoryentry() object.
#----------------------------------------------------------------------------------------
Function Get-DSActiveDirectoryObject (
[string]$Domain,
[string]$Username,
[string]$Password ) {
	
	$DomainLDAP = "LDAP://$Domain"
    #retrieve the details of the specified domain and then saving the DN in a variable
	$DomainInfo = New-Object -TypeName System.DirectoryServices.DirectoryEntry($DomainLDAP,$Username,$Password)
	$DomainDN = $DomainInfo.distinguishedName
	$DomainPath = "LDAP://$DomainDN"
	#creating a directory searcher object to search the domain details
	$searcher = New-Object System.DirectoryServices.DirectorySearcher($DomainInfo)
    #search filter is User Class and $username account    
	$searcher.filter = "(&(objectCategory=User)(samaccountname=$Username))"
	$searcher.SearchRoot  = $DomainInfo
    #retrieving the path of the user account object
	$Result = ($searcher.FindAll()).path    
	$UserObject = New-Object System.DirectoryServices.DirectoryEntry($Result,$Username,$Password)
    #returning the user account object with all the details about it
	return $UserObject
}


#---------------------------------------------------------------------------------------------
# This function checks group membership of given user account against 'domain admins' or
# 'enterprise admins' or 'schema admins' as specified by relevant parameters. Function also uses user credentials
# specified; 
#--------------------------------------------------------------------------------------------
Function Test-DSGroupMembership {
param(
    [string]$Domain, 
    [string]$UserName, 
    [string]$Password,
    [switch]$IsDomainAdmins, # is user member of Domain Admins
    [switch]$IsEnterpriseAdmins, # is user member of Enterprise Admins
    [switch]$IsSchemaAdmins # is user member of Schema Admins
)
    Add-Indent -Header "enter -> Test-DSGroupMembership" # increase indent in log file
    
    # get a reference to the user account using specified credentials
    Write-DSLog -Level info -Message "Binding to user $UserName in domain $Domain using $UserName credentials" 
    $user = Get-DSActiveDirectoryObject -Domain $Domain -Username $UserName -Password $Password

    # return if unable to bind
    if($user -isnot [object]) { 
        Write-DSLog -Level error -Message "Failed to bind to user $UserName" 
        Remove-Indent -Footer "exit -> Test-DSGroupMembership" # decrease indent in log file
        return $false 
    }

    # refresh tokengroups
    Write-DSLog -Level info -Message "Refreshing TokenGroups.." 
    $user.psbase.refreshCache(@("TokenGroups")) 
    $secirc = new-object System.Security.Principal.IdentityReferenceCollection

    # add tokenGroups to IdentityReference collection
    Write-DSLog -Level info -Message "Adding Identity references from TokenGroups to a collection" 
    foreach($sidByte in $user.TokenGroups) {
        $secirc.Add((new-object System.Security.Principal.SecurityIdentifier $sidByte,0))
    }

    # get group membership in a varialbe (may include names as well as SIDs)
    #$tgMembership = $secirc.Translate([System.Security.Principal.NTAccount])
    #Write-DSLog -Level info -Message "Group membership for user $UserName as identified are:" 
    #foreach($grp in $tgMembership) { Write-DSLog -Level info -Message $grp }

    # get Sid of user specified via $UserName parameter
    #Write-DSLog -Level info -Message "Finding out SID information of user $UserName and domain $Domain" 
    $sidInfo = New-Object System.Security.Principal.SecurityIdentifier($user.ObjectSid.Value,0)

    #region identify root domain sid
    # Bind to given domain and identify root domain for its Sid (for Ent admin sid construction)
    $objDom = New-Object -TypeName System.DirectoryServices.DirectoryEntry("LDAP://$Domain/rootDSE",$UserName,$Password)
    # now connect to root domain namign context and get its sid
    $rdnc = New-Object -TypeName System.DirectoryServices.DirectoryEntry("LDAP://$Domain/$($objDom.rootDomainNamingContext)", $UserName, $Password)
    $rootDomainName = $rdnc.name # single label name, eg.. for contoso.com, it will be contoso

    # get given domain name.. $domain parameter
    $dnc = New-Object -TypeName System.DirectoryServices.DirectoryEntry("LDAP://$Domain",$UserName,$Password)
    $domainName = $dnc.Name # name of the given domain in single label..eg, for test.contoso.com, it will be test

    # get Sid of root domain name.. to be used for sid contruction of ent admin
    #Write-DSLog -Level info -Message "Finding out SID of root domain $($objDom.rootDomainNamingContext)" 
    try {
        $rdncSid = New-Object System.Security.Principal.SecurityIdentifier($rdnc.ObjectSid.Value,0)
    }
    catch {
        $rdncSid = "" # unable to fetch root domain sid
    }
    #endregion

    # just extract account domain SID
    $userDomainSid = $sidInfo.AccountDomainSid.Value
    $userSid = $sidInfo.Value
    $domainAdminSid = "$userDomainSid-512" # -512 is domain admins SID
    $EntAdminSid = "$rdncSid-519" # construct enterprise admins Sid using root-domain SID
    $SchemaAdminSid = "$rdncSid-518" # construct enterprise admins Sid using root-domain SID
    $eaMember = $false; $daMember = $false; $saMember = $false # assume user is not a member of domain/entreprise/Schema admins

    Write-DSLog -Level info -Message "Root domain ($rootDomainName) SID is $rdncSid" 
    Write-DSLog -Level info -Message "Domain ($Domain) SID: $userDomainSid"
    Write-DSLog -Level info -Message "User ($UserName) SID: $userSid" 

    # check if user is member of Domain Admins group
    if($domainAdminSid -in $secirc.Value) { 
        Write-DSLog -Level info -Message "$UserName is member of $domainName\Domain Admins" 
        $daMember = $true
    }

    # check if user is member of Enterprise Admins group
    if($EntAdminSid -in $secirc.Value) { 
        Write-DSLog -Level info -Message "$UserName is member $rootDomainName\Enterprise Admins" 
        $eaMember = $true
    }

    # check if user is member of Enterprise Admins group
    if($SchemaAdminSid -in $secirc.Value) { 
        Write-DSLog -Level info -Message "$UserName is member of $rootDomainName\Schema Admins" 
        $saMember = $true
    }

    # return values based on what user has asked for
    if($IsDomainAdmins) { 
        Remove-Indent -Footer "exit -> Test-DSGroupMembership" # decrease indent in log file
        return $daMember 
    }
    elseif($IsEnterpriseAdmins) {
        Remove-Indent -Footer "exit -> Test-DSGroupMembership" # decrease indent in log file
        return $eaMember 
    }
    elseif($IsSchemaAdmins) {
        Remove-Indent -Footer "exit -> Test-DSGroupMembership" # decrease indent in log file
        return $saMember 
    }
    else { # user hasn't passed which group membersip he wants, return all
        $arAdm = '' | select IsDomainAdmins, IsEnterpriseAdmins, IsSchemaAdmins
        $arAdm.IsDomainAdmins = $daMember
        $arAdm.IsEnterpriseAdmins = $eaMember
        $arAdm.IsSchemaAdmins = $saMember
        Remove-Indent -Footer "exit -> Test-DSGroupMembership" # decrease indent in log file
        return $arAdm
    }   
} 


#----------------------------------------------------------------------------------------------------
#This fn will retrieve the list of all the domains in the forest and then validate whether the user
# specified domain is there in the fetched list of domains or not. Function will return $true or
# $false.
#----------------------------------------------------------------------------------------------------
Function Test-DSDomainExistence(
[string]$username,
[string]$password,
[string]$domain,
[string]$DomainToSearch,
[switch]$ChildDomainBuild,
[switch]$TreeDomainBuild) {
    
    Add-Indent -Header "enter -> Test-DSDomainExistence" # increase indent in log file

    # storing the ldap path of the $domain name parameter in the $ldappath variable
    $LDAPPath = "LDAP://$Domain"
                   
    #creating System.directoryservices.directoryentry class object. Using the directory entry class to
    # encapsulate the $LDAPPath value and initializes a new instance of the directory entry class.
    $DomainInfo = New-Object System.DirectoryServices.DirectoryEntry($LDAPPath,$Username,$Password)
        
    # fsmoroleowner property lists the DN of the DCs holding the FSMO roles. Split(",") method is splitting the 
    # DC names by comma. 
    $FsmoSplit = ($DomainInfo.fSMORoleOwner).Split(",")
        
    # using the for loop to check if any element of $fsmosplit array is equal to "CN=Configuration"; if yes the index number
    # of the element is stored in $index variable.
    For($i=0;$i -lt $FsmoSplit.count;$i++) 
    {
        if($FsmoSplit[$i] -eq "CN=Configuration")
        {
            $index = $i
        }
    }
        
    # declaring a null value variable
    $FinalConfig = ""

    # the final value of the for loop will be "CN=configuration" + everything else upto the last index value. 
    #i.e. the configuration partition DN.
    for($i=$index;$i -lt $fsmosplit.count;$i++)
    {
	    $finalconfig = ($finalconfig + $fsmosplit[$i]) + ","
    }
    
    # creating a new class object. DirectoryContext class identifies a specific directory
    # and the credentials that are used to access the directory 
    $DomaininfoDC = new-object System.DirectoryServices.ActiveDirectory.DirectoryContext("Domain",$Domain,$Username,$Password)

    #using the GetDomain static method of the [System.DirectoryServices.ActiveDirectory.Domain] class to find 
    #the DC holding the PDC role
    # in the DirectoryContext $DomainInfoDC. Combining pdc role owner info + configuration partition DN determined 
    #above to make the ldap path of the PDC role holder DC.
    $pdcLDAPname = "LDAP://" + ([System.DirectoryServices.ActiveDirectory.Domain]::getdomain($domaininfoDC)).pdcroleowner.name + "/" + $finalconfig.Substring(0,$finalconfig.LastIndexOf(","))
    
    # creating another class object for PDC object
    $configinfo = new-object DirectoryServices.DirectoryEntry($pdcLDAPname,$Username,$Password)
        
    # System.DirectoryServices.DirectorySearcher class performs queries against AD DS objects.
    $searcher = New-Object System.DirectoryServices.DirectorySearcher($configinfo)
	
    If($ChildDomainBuild) {    
        # filtering the searcher object to retrive list of domains
        $searcher.filter = "(&((objectClass=crossref)(Netbiosname=*)))"
        $PropertiestoLoad = $searcher.PropertiesToLoad.Add("dnsroot")
        $alldomains = $searcher.FindAll().properties.dnsroot
    
        # checking if parentdomainname value passed by the user is in the $alldomains list, if yes the condition will return $true else $false.
        If($alldomains -contains $DomainToSearch) { 
            Remove-Indent -Footer "exit -> Test-DSDomainExistence" # decrease indent in log file
            Return $true 
        }
        Else { 
            Write-DSLog -Level error -Message "Domain $DomainToSearch, does not exist"
            Remove-Indent -Footer "exit -> Test-DSDomainExistence" # decrease indent in log file
            Return $false 
        }
    }
    #checking if specified domain is a root domain or not
    If($TreeDomainBuild) {
        #searching for root domain name
        $RootLDAPname = "LDAP://" + ([System.DirectoryServices.ActiveDirectory.Domain]::getdomain($domaininfoDC)).pdcroleowner.name + "/RootDSE"
        $RootDSEinfo = new-object DirectoryServices.DirectoryEntry($RootLDAPname,$Username,$Password)
        $RootDomainDN = $RootDSEinfo.rootDomainNamingContext
        $Rootdomain = (($RootDomainDN -replace 'DC=','') -replace ',','.')
        
        If($DomainToSearch -eq $RootDomain) { 
            Remove-Indent -Footer "exit -> Test-DSDomainExistence" # decrease indent in log file
            return $true 
        }
        else {
            Write-DSLog -Level error -Message "Domain $DomainToSearch, is not the forest root domain"
            Remove-Indent -Footer "exit -> Test-DSDomainExistence" # decrease indent in log file
            return $false
        }
    }
}

Function Test-DSObjectExistence($domain,$username,$password,$Objectname,$Category){
$DomainLDAP = "LDAP://$Domain"
$DomainInfo = New-Object -TypeName System.DirectoryServices.DirectoryEntry($DomainLDAP,$Username,$Password)
#creating a directory searcher object to search the domain details
$searcher = New-Object System.DirectoryServices.DirectorySearcher($DomainInfo)
#search filter is User Class and $username account    
$searcher.filter = "(&(objectCategory=$Category)(samaccountname=$Objectname))"
$searcher.SearchRoot  = $DomainInfo
#retrieving the path of the user account object
try{
$Result = $searcher.FindAll()
if($result.Count -gt 0){return $true}
else{return $false}
}
catch{
return $false}
}

# ---------------------------------------------------------------------------------------------------
# 15072015: Added InputXMLFile parameter instead of directly reading xml file in the function - umesh
# ---------------------------------------------------------------------------------------------------    
Function Test-DSSOEXML($DSSOEXmlPath,[switch]$ExpressInstall,[switch]$ConfigADPathsToOSDrive, [string]$PassKey) {
    Add-Indent -Header "enter -> Test-DSSOEXML" # increase indent in log file
    Write-DSLog -Level info -Message "Validating DSSOE answer file $DSSOEXmlPath"
    # declaring the $xmldata variable which will store the contents of the XML file in the XML format.
    # $xmldata will be used to read the user inputs from the XML file
    [xml]$xmldata = Get-Content -Path $DSSOEXmlPath

    #region creds related checks misc
    # passkey given, proceed
    $selectedDCPromoOption = $xmldata.DSSOE.DCPromoOptions.Selected
    #$xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.Password = (Get-DSPassCode -Code $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.Password -PassKey $PassKey)
    #$xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.SafeModeAdminPassword = (Get-DSPassCode -Code $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.SafeModeAdminPassword -PassKey $PassKey)
    #if($xmldata.DSSOE.DCPromoOptions.Subnet.Password.Length -gt 0) { (Get-DSPassCode -Code $xmldata.DSSOE.DCPromoOptions.Subnet.Password -PassKey $PassKey) }
    
    $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.Password = (Unprotect-SOEString -string $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.Password -key $PassKey)
    $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.SafeModeAdminPassword = (Unprotect-SOEString -string $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.SafeModeAdminPassword -key $PassKey)
    if($xmldata.DSSOE.DCPromoOptions.Subnet.Password.Length -gt 0) { $xmldata.DSSOE.DCPromoOptions.Subnet.Password = (Unprotect-SOEString -string $xmldata.DSSOE.DCPromoOptions.Subnet.Password -key $PassKey) }
    If($xmldata.DSSOE.DSConfiguration.ADRecycleBin.Password.Length -gt 0) { $xmldata.DSSOE.DSConfiguration.ADRecycleBin.Password = (Unprotect-SOEString -string $xmldata.DSSOE.DSConfiguration.ADRecycleBin.Password -key $PassKey) }
    If($xmldata.DSSOE.DSConfiguration.ADHealthCheck.Password.Length -gt 0) { $xmldata.DSSOE.DSConfiguration.ADHealthCheck.Password = (Unprotect-SOEString -string $xmldata.DSSOE.DSConfiguration.ADHealthCheck.Password -key $PassKey) }
       
    #endregion

    # loading the System.DirectoryServices.AccountManagement assembly
    Add-Type -AssemblyName System.DirectoryServices.AccountManagement

    #validating if the $xmldata.DSSOE.DCPromoOptions.Selected is blank.
    Write-DSLog -Level info -Message "Validating the value of DCPromoOptions.Selected: $($xmldata.DSSOE.DCPromoOptions.Selected)"

    if((Test-ValuesRange -value $xmldata.DSSOE.DCPromoOptions.Selected -range ("NewDomainNewForest","AdditionalDC","NewChildDomain","NewTreeDomain")) -eq $false)
    {
        Write-DSLog -Level error -Message "Invalid DCPromoOptions Value - The valid value is NewDomainNewForest / AdditionalDC / NewChildDomain / NewTreeDomain. Empty tag is also an invalid value."
        return ($false,'InvalidDCPromoOptionSpecified')
    }
    Else
    {
        Write-DSLog -Level Info -Message "The value of DCPromoOptions.Selected is successfully validated; it is $($xmldata.DSSOE.DCPromoOptions.Selected)"
    }
    
    If($xmldata.DSSOE.DCPromoOptions.Selected -eq "NewDomainNewForest")
    {
        If($xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.UserName -eq "" -or $xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.Password -eq "")
        {
            Write-DSLog -Level error -Message "Username and Password should not be blank"
            return ($false,'BlankUserNameOrPassword')
        }
        Else
        {
            Write-DSLog -Level Info -Message "Username and Password is entered"
        }

        Write-DSLog -Level Info -Message "[NewDomainNewForest] Validating the Username: $($xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.UserName) and Password"
        #calling the test-dscredentials function to validate if able to bind to machine context with the user provided username or password
        If((Test-DSCredentials -ContextType Machine -ContextName ((Get-ChildItem Env:COMPUTERNAME).Value) -UserName $xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.UserName `
        -Password $xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.Password) -eq $false)
        {
            Write-DSLog -Level error -Message "Invalid credentials. Please specify a valid username and password"
            return ($false,'InvalidPromoOpCredentials')
        }
        Else
        {
            Write-DSLog -Level Info -Message "Username & Password has been validated successfully"
        }

        Write-DSLog -Level Info -Message "Validating if the specified user accont is a local administrator or not."
        try {
            If((Test-IsUserLocalAdmin -UserName $xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.UserName) -eq $false) {
                Write-DSLog -Level error -Message "Specified user account does not have local admin rights."
                return ($false,'UserIsNotLocalAdmin')
            }
            Else {
                Write-DSLog -Level Info -Message "Local admin rights for specified user account is validated successfully"
            }
        }
        catch {
            Write-DSLog -Level error -Message "An error occurred while validating the local admin rights for the specified user account."
            Write-DSLog -Level error -Message "$($Error[0].Exception.Message)"
            return ($false,'ErrorValidatingLocalAdminRights')
        }
        
        #calling the Test-DomainName function to check whether the user provided domain name is valid or not
        If((Test-DomainName -Name $xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.NewDomainFQDN) -eq $false)
        {
            return ($false,'InvalidDomainName')
        }

        #validating the Netbiosname by using the test-netbiosname function
        If((Test-NetBIOSName -Name $xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.NewDomainNetBIOS) -eq $false)
        {
            return ($false,'InvalidNetBIOSName')
        }

        If(-not($ConfigADPathsToOSDrive)) {
            Write-DSLog -Level Info -Message "Validating Active Directory Database Path - $($xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.ADDatabasePath)"
        
            If((Test-ADContentPath -Path $xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.ADDatabasePath) -eq $false)
            {
                return ($false,'InvalidADDatabasePath')
            }
            Else
            {
                Write-DSLog -Level Info -Message "Active Directory database path is validated successfully"       
            }

            Write-DSLog -Level Info -Message "Validating Active Directory Log File Path - $($xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.ADLogfilePath)"
        
            If((Test-ADContentPath -Path $xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.ADLogfilePath) -eq $false)
            {
                return ($false,'InvalidADLogfilePath')
            }
            Else
            {
                Write-DSLog -Level Info -Message "Active Directory Log File Path is validated successfully"
            }

            Write-DSLog -Level Info -Message "Validating Active Directory Sysvol Path - $($xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.SysvolPath)"

            If((Test-ADContentPath -Path $xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.SysvolPath) -eq $false)
            {
                return ($false,'InvalidADSysvolPath')
            }
            Else
            {
                Write-DSLog -Level Info -Message "Active Directory Sysvol Path is validated successfully"
            }
        }
        else {
            Write-DSLog -Level Info -Message "The switch parameter -ConfigADPathsToOSDrive is passed in the command, thus AD paths will be created on the system drive"
            $RootDrive = $env:SystemDrive       
            $ADDBFolder = "$RootDrive\NTDS-DB"
            $ADLogsFolder = "$RootDrive\NTDS-LOGS"
            $ADSysvolFolder = "$RootDrive\SYSVOL"
            Write-DSLog -Level Info -Message "Validating Active Directory Database Path - $ADDBFolder"
        
            If((Test-ADContentPath -Path $ADDBFolder) -eq $false)
            {
                return ($false,'InvalidADDatabasePath')
            }
            Else
            {
                Write-DSLog -Level Info -Message "Active Directory database path is validated successfully"       
            }

            Write-DSLog -Level Info -Message "Validating Active Directory Log File Path - $ADLogsFolder"
        
            If((Test-ADContentPath -Path $ADLogsFolder) -eq $false)
            {
                return ($false,'InvalidADLogfilePath')
            }
            Else
            {
                Write-DSLog -Level Info -Message "Active Directory Log File Path is validated successfully"
            }

            Write-DSLog -Level Info -Message "Validating Active Directory Sysvol Path - $ADSysvolFolder"

            If((Test-ADContentPath -Path $ADSysvolFolder) -eq $false)
            {
                return ($false,'InvalidADSysvolPath')
            }
            Else
            {
                Write-DSLog -Level Info -Message "Active Directory Sysvol Path is validated successfully"
            }
        }

        Write-DSLog -Level Info -Message "Validating SafeModeAdminPassword"

        If((Test-ComplexPassword -Password $xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.SafeModeAdminPassword) -eq $false)
        {
            Write-DSLog -Level error -Message "Invalid <SafeModeAdminPassword> Value - The password should not be blank and should meet the complexity requirements, which are as follows:`r`nMinimum Length of 8 Chars`r`nAtleast 1 uppercase alphabet`r`nAtleast 1 lowercase alphabet`r`nAtleast 1 numeric char`r`nAtleast 1 special char"
            return ($false,'InvalidSafeModeAdminPassword')
        }
        Else
        {
            Write-DSLog -Level Info -Message "SafeModeAdminPassword is validated successfully"
        }
        
        Write-DSLog -Level Info -Message "Validating Forest Functional Level: $($xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.ForestFunctionalLevel) and Domain Functional Level: $($xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.DomainFunctionalLevel)"

        If((Test-ForestDomainLevel -ForestLevel $xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.ForestFunctionalLevel `
        -DomainLevel $xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.DomainFunctionalLevel) -eq $false)
        {
            return ($false,'InvalidForestOrDomainFunctionalLevel')
        }
        Else
        {
            Write-DSLog -Level Info -Message "Forest and Domain functional levels are validated successfully"
        }

        Write-DSLog -Level Info -Message "Validating the value of InstallDNS - $($xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.InstallDNS)"
        If((Test-DSTrueFalse -value $xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.InstallDNS) -eq $false)
        {
            Write-DSLog -Level error -Message "Invalid <InstallDNS> Value - Valid value is either True or False"
            return ($false,'InvalidInstallDNSValue')
        }
        Else
        {
            Write-DSLog -Level Info -Message "Value of InstallDNS is validated successfully"
        }

        <#Write-DSLog -Level Info -Message "Validating the value of RebootOnCompletion - $($xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.RebootOnCompletion)"
        If((Test-DSTrueFalse -value $xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.RebootOnCompletion) -eq $false)
        {
            Write-DSLog -Level error -Message "Invalid <RebootOnCompletion> Value - Valid value is either True or False"
            return ($false,'InvalidRebootOnCompletionValue')
        }
        Else
        {
            Write-DSLog -Level Info -Message "Value of RebootOnCompletion is validated successfully"
        }#> #14-Jun-16: [TR] Removed reboot on completion

        Write-DSLog -Level Info -Message "Validating the value of ADSiteName - $($xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.ADSiteName)"
        If($xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.ADSiteName -ne "Default")
        {
            Write-DSLog -Level error -Message "Invalid <ADSiteName> value - Valid value is Default"
            return ($false,'InvalidADSiteNameValue')
        }
        Else
        {
             Write-DSLog -Level Info -Message "Value of ADSiteName is validated successfully"
        }
    }


    if($xmldata.DSSOE.DCPromoOptions.Selected -eq "AdditionalDC")
    {
        If($xmldata.DSSOE.DCPromoOptions.AdditionalDC.UserName -eq "" -or $xmldata.DSSOE.DCPromoOptions.AdditionalDC.Password -eq "")
        {
            Write-DSLog -Level Info -Message "Please enter a username or password for Additional DC configuration"
            return ($false,'BlankUserNameOrPassword')
        }
        Else
        {
            Write-DSLog -Level Info -Message "Username and password is entered. Username is $($xmldata.DSSOE.DCPromoOptions.AdditionalDC.UserName)"
        }

        Write-DSLog -Level Info -Message "Validating username and password"
        Write-DSLog -Level Info -Message "The domain name is $($xmldata.DSSOE.DCPromoOptions.AdditionalDC.Domain)"
        If((Test-DSCredentials -ContextType Domain -ContextName $xmldata.DSSOE.DCPromoOptions.AdditionalDC.Domain `
        -UserName $xmldata.DSSOE.DCPromoOptions.AdditionalDC.UserName `
        -Password $xmldata.DSSOE.DCPromoOptions.AdditionalDC.Password) -eq $false)
        {
            Write-DSLog -Level error -Message "Invalid domain name or credentials"
            return ($false,'InvalidPromoOpCredentials')
        }
        Else
        {
            Write-DSLog -Level Info -Message "Username and Password is successfully validated"
        }
        

        Write-DSLog -Level Info -Message "Validating if the specified username is a member of Domain Admins group or not"
        #Comment: 12-29-15 [Tarun]: Removed the calling of older function and added the calling the new function
        <#try {
            $UserObject = Get-DSActiveDirectoryObject -Domain $xmldata.DSSOE.DCPromoOptions.AdditionalDC.Domain `
            -Username $xmldata.DSSOE.DCPromoOptions.AdditionalDC.UserName -Password $xmldata.DSSOE.DCPromoOptions.AdditionalDC.Password
            $GroupStatus = Test-DSGroupMembership -ADObject $UserObject -GroupName "Domain Admins"            
        }
        catch {
            Write-DSLog -Level error -Message "An error occurred while validating the group membership of the user account"
            Write-DSLog -Level error -Message "$($Error[0].Exception.Message)"
            return $false
        }
        If($GroupStatus -eq $true) {
            Write-DSLog -Level Info -Message "Group membership is successfully validated"
        }
        Else {
            Write-DSLog -Level error -Message "Group membership validation failed. User is not a member of the Domain Admins group. Make sure the User account has Domain Admin rights to continue with the DC promotion."
            return $false
        }#>

        Try {
            $GroupStatus = Test-DSGroupMembership -Domain $xmldata.DSSOE.DCPromoOptions.AdditionalDC.Domain `
            -UserName $xmldata.DSSOE.DCPromoOptions.AdditionalDC.UserName -Password $xmldata.DSSOE.DCPromoOptions.AdditionalDC.Password `
            -IsDomainAdmins

            If($GroupStatus -eq $true) {
                Write-DSLog -Level Info -Message "Group membership is successfully validated"
            }
            Else {
                Write-DSLog -Level error -Message "Group membership validation failed. User is not a member of the Domain Admins group. Make sure the specified User account has Domain Admin rights to continue with the DC promotion."
                return ($false,'UserIsNotDomainAdmins')
            }
        }
        Catch {
            Write-DSLog -Level error -Message "An error occurred while validating the group membership of the user account"
            Write-DSLog -Level error -Message "$($_.Exception.Message)"
            return ($false,'ErrorValidatingDomainAdminRights')
        }

        If(-not($ConfigADPathsToOSDrive)) { #validating the AD paths when -ConfigADPathsToOSDrive parameter is not passed in the command
            Write-DSLog -Level Info -Message "Validating Active Directory Database Path - $($xmldata.DSSOE.DCPromoOptions.AdditionalDC.ADDatabasePath)"
            If((Test-ADContentPath -Path $xmldata.DSSOE.DCPromoOptions.AdditionalDC.ADDatabasePath) -eq $false)
            {
                return ($false,'InvalidADDatabasePath')
            }
            Else
            {
                Write-DSLog -Level Info -Message "Active Directory Database path is successfully validated"
            }

            Write-DSLog -Level Info -Message "Validating Active Directory Log file path - $($xmldata.DSSOE.DCPromoOptions.AdditionalDC.ADLogfilePath)"
            If((Test-ADContentPath -Path $xmldata.DSSOE.DCPromoOptions.AdditionalDC.ADLogfilePath) -eq $false)
            {
                return ($false,'InvalidADLogfilePath')
            }
            Else
            {
                Write-DSLog -Level Info -Message "Active Directory Log file path is successfully validated"
            }

            Write-DSLog -Level Info -Message "Validating Active Directory Sysvol Path - $($xmldata.DSSOE.DCPromoOptions.AdditionalDC.SysvolPath)"
            If((Test-ADContentPath -Path $xmldata.DSSOE.DCPromoOptions.AdditionalDC.SysvolPath) -eq $false)
            {
                return ($false,'InvalidADSysvolPath')
            }
            Else
            {
                Write-DSLog -Level Info -Message "Active Directory Sysvol path is successfully validated"
            }
        }
        Else { #validating the AD paths when -ConfigADPathsToOSDrive parameter is passed in the command
            Write-DSLog -Level Info -Message "The switch parameter -ConfigADPathsToOSDrive is passed in the command, thus AD paths will be created on the system drive"
            
            $RootDrive = $env:SystemDrive       
            $ADDBFolder = "$RootDrive\NTDS-DB"
            $ADLogsFolder = "$RootDrive\NTDS-LOGS"
            $ADSysvolFolder = "$RootDrive\SYSVOL"

            Write-DSLog -Level Info -Message "Validating Active Directory Database Path - $ADDBFolder"
            If((Test-ADContentPath -Path $ADDBFolder) -eq $false)
            {
                return ($false,'InvalidADDatabasePath')
            }
            Else
            {
                Write-DSLog -Level Info -Message "Active Directory Database path is successfully validated"
            }

            Write-DSLog -Level Info -Message "Validating Active Directory Log file path - $ADLogsFolder"
            If((Test-ADContentPath -Path $ADLogsFolder) -eq $false)
            {
                return ($false,'InvalidADLogfilePath')
            }
            Else
            {
                Write-DSLog -Level Info -Message "Active Directory Log file path is successfully validated"
            }

            Write-DSLog -Level Info -Message "Validating Active Directory Sysvol Path - $ADSysvolFolder"
            If((Test-ADContentPath -Path $ADSysvolFolder) -eq $false)
            {
                return ($false,'InvalidADSysvolPath')
            }
            Else
            {
                Write-DSLog -Level Info -Message "Active Directory Sysvol path is successfully validated"
            }
        }

        Write-DSLog -Level Info -Message "Validating Safe Mode Admin Password"
        If((Test-ComplexPassword -Password $xmldata.DSSOE.DCPromoOptions.AdditionalDC.SafeModeAdminPassword) -eq $false)
        {
            Write-DSLog -Level error -Message "Invalid <SafeModeAdminPassword> Value - The password should not be blank and should meet the complexity requirements, which are as follows:`r`nMinimum Length of 8 Chars`r`nAtleast 1 uppercase alphabet`r`nAtleast 1 lowercase alphabet`r`nAtleast 1 numeric char`r`nAtleast 1 special char" 
            return ($false,'InvalidSafeModeAdminPassword')
        }
        Else
        {
            Write-DSLog -Level Info -Message "Safe Mode Admin Password is successfully validated"
        }

        Write-DSLog -Level Info -Message "Validating the value of InstallDNS - $($xmldata.DSSOE.DCPromoOptions.AdditionalDC.InstallDNS)"
        If((Test-DSTrueFalse -value $xmldata.DSSOE.DCPromoOptions.AdditionalDC.InstallDNS) -eq $false)
        {
            Write-DSLog -Level error -Message "Invalid <InstallDNS> Value - Valid value is either True or False"
            return ($false,'InvalidInstallDNSValue')
        }
        Else
        {
            Write-DSLog -Level Info -Message "InstallDNS value is successfully validated"
        }

        Write-DSLog -Level Info -Message "Validating the value of GlobalCatalog - $($xmldata.DSSOE.DCPromoOptions.AdditionalDC.GlobalCatalog)"
        If((Test-DSTrueFalse -value $xmldata.DSSOE.DCPromoOptions.AdditionalDC.GlobalCatalog) -eq $false)
        {
            Write-DSLog -Level error -Message "Invalid <GlobalCatalog> Value - Valid value is either True or False"
            return ($false,'InvalidGlobalCatalogValue')
        }
        Else
        {
            Write-DSLog -Level Info -Message "GlobalCatalog value is successfully validated"
        }

        Write-DSLog -Level Info -Message "Validating the value of RODC - $($xmldata.DSSOE.DCPromoOptions.AdditionalDC.RODC)"
        If((Test-DSTrueFalse -value $xmldata.DSSOE.DCPromoOptions.AdditionalDC.RODC) -eq $false)
        {
            Write-DSLog -Level error -Message "Invalid <RODC> Value - Valid value is either True or False"
            return ($false,'InvalidRODCValue')
        }
        Else
        {
            Write-DSLog -Level Info -Message "RODC value is successfully validated"
        }

        Write-DSLog -Level Info -Message "Validating the value of ReplicateDatafromExistingDC.Enabled - $($xmldata.DSSOE.DCPromoOptions.AdditionalDC.ReplicateDatafromExistingDC.Enabled)"
        If((Test-DSTrueFalse -value $xmldata.DSSOE.DCPromoOptions.AdditionalDC.ReplicateDatafromExistingDC.Enabled) -eq $false)
        {
            Write-DSLog -Level error -Message "Invalid <ReplicateDataFromExistingDC Enabled> Value - Valid value is either True or False"
            return ($false,'InvalidReplicateDataFromExistingDC.EnabledValue')
        }
        Else
        {
            Write-DSLog -Level Info -Message "ReplicateDatafromExistingDC.Enabled value is successfully validated"
        }
        If($xmldata.DSSOE.DCPromoOptions.AdditionalDC.ReplicateDatafromExistingDC.Enabled -eq "False") {
            Write-DSLog -Level Info -Message "Value for ReplicateDatafromExistingDC parameter is set to False. Please make sure to select the other option for data replication i.e. Install from media."
        }
        Else {
            Write-DSLog -Level Info -Message "Validating the value of ReplicateDatafromExistingDC.ReplicaDC - $($xmldata.DSSOE.DCPromoOptions.AdditionalDC.ReplicateDatafromExistingDC.ReplicaDC)"
            If(($xmldata.DSSOE.DCPromoOptions.AdditionalDC.ReplicateDatafromExistingDC.ReplicaDC -ne "Automatic") -and `
            ((Test-DCExists -DCFQDN $xmldata.DSSOE.DCPromoOptions.AdditionalDC.ReplicateDatafromExistingDC.ReplicaDC -DomainName $xmldata.DSSOE.DCPromoOptions.AdditionalDC.Domain `
            -UserName $xmldata.DSSOE.DCPromoOptions.AdditionalDC.UserName -Password $xmldata.DSSOE.DCPromoOptions.AdditionalDC.Password) -eq $False))
            {
                Write-DSLog -Level error -Message "Invalid <ReplicateDataFromExistingDC ReplicaDC> Value - The valid value is either Automatic or an existing Domain Controller in the Domain. Please verify."
                return ($false,'InvalidReplicateDataFromExistingDC.ReplicaDCValue')
            }
            Else
            {
                Write-DSLog -Level info -Message "ReplicateDataFromExistingDC.ReplicaDC value is successfully validated"
            }
        }

        If($xmldata.DSSOE.DCPromoOptions.AdditionalDC.ReplicateDatafromExistingDC.Enabled -eq "False") {
            Write-DSLog -Level info -Message "Validating the value of InstallFromMedia.ReplicateDatafromMedia - $($xmldata.DSSOE.DCPromoOptions.AdditionalDC.InstallFromMedia.ReplicateDatafromMedia)"
            If((Test-DSTrueFalse -value $xmldata.DSSOE.DCPromoOptions.AdditionalDC.InstallFromMedia.ReplicateDatafromMedia) -eq $false)
            {
                Write-DSLog -Level error -Message "Invalid <InstallFromMedia ReplicateDatafromMedia> Value - Valid value is either True or False"
                return ($false,'InvalidInstallFromMediaValue')
            }
            Else
            {
                Write-DSLog -Level info -Message "InstallFromMedia.ReplicateDatafromMedia value is successfully validated"
            }       

            If($xmldata.DSSOE.DCPromoOptions.AdditionalDC.InstallFromMedia.ReplicateDatafromMedia -eq "False") {
                Write-DSLog -Level error -Message "Additional Domain Controller must replicate data either from an existing domain controller or via backup media. Both ReplicateDataFromExistingDC & InstallFromMedia are set to false, leaving no option for data replication. Please make sure to use either of the two option for data replication."
                return ($false,'InvalidReplicateDatafromMediaValue')
            }
            else {
                Write-DSLog -Level info -Message "Validating the value of InstallFromMedia.MediaPath - $($xmldata.DSSOE.DCPromoOptions.AdditionalDC.InstallFromMedia.MediaPath)"
                try {
                    $mediapathstatus = Test-Path -Path $xmldata.DSSOE.DCPromoOptions.AdditionalDC.InstallFromMedia.MediaPath -ErrorAction stop
                    If($mediapathstatus -eq $true) {
                        Write-DSLog -Level info -Message "InstallFromMedia.MediaPath value is successfully validated"
                    }
                    Else {
                        Write-DSLog -Level error -Message "Invalid <InstallFromMedia MediaPath> value - The specified value is an incorrect path"
                        return ($false,'InvalidInstallFromMedia.MediaPath')
                    }
                }
                catch {
                     Write-DSLog -Level error -Message "Invalid <InstallFromMedia MediaPath> value - The specified value is an incorrect path"
                     Write-DSLog -Level error -Message "$_.Exception.Message)"
                     return ($false,'IncorrectInstallFromMedia.MediaPath')
                }                
            }
        }
        Else {
            Write-DSLog -Level info -Message "Since ReplicateDataFromExistingDC parameter is set to True, thus InstallFromMedia options are skipped."
        }
        
        Write-DSLog -Level info -Message "Validating the value of CriticalReplicationOnly - $($xmldata.DSSOE.DCPromoOptions.AdditionalDC.CriticalReplicationOnly)"     
        If((Test-DSTrueFalse -value  $xmldata.DSSOE.DCPromoOptions.AdditionalDC.CriticalReplicationOnly) -eq $false)
        {
            Write-DSLog -Level error -Message "Invalid <CriticalReplicationOnly> Value - Valid value is either True or False"
            return ($false,'InvalidCriticalReplicationOnlyValue')
        }
        Else
        {
            Write-DSLog -Level info -Message "CriticalReplicationOnly value is successfully validated"
        }

        <#Write-DSLog -Level info -Message "Validating the value of RebootOnCompletion - $($xmldata.DSSOE.DCPromoOptions.AdditionalDC.RebootOnCompletion)"
        If((Test-DSTrueFalse -value  $xmldata.DSSOE.DCPromoOptions.AdditionalDC.RebootOnCompletion) -eq $false)
        {
            Write-DSLog -Level error -Message "Invalid <RebootOnCompletion> Value - Valid value is either True or False"
            return ($false,'InvalidRebootOnCompletionValue')
        }
        Else
        {
            Write-DSLog -Level info -Message "RebootOnCompletion value is successfully validated"
        }#> #14-Jun-16: [TR] Removed reboot on completion

        Write-DSLog -Level info -Message "Validating the user specified AD Site - $($xmldata.DSSOE.DCPromoOptions.AdditionalDC.ADSiteName)"
        If($xmldata.DSSOE.DCPromoOptions.AdditionalDC.ADSiteName -ne "") {
            if((Test-DSSiteExist -Value $xmldata.DSSOE.DCPromoOptions.AdditionalDC.ADSiteName -Domain $xmldata.DSSOE.DCPromoOptions.AdditionalDC.Domain `
            -Username $xmldata.DSSOE.DCPromoOptions.AdditionalDC.UserName -Password $xmldata.DSSOE.DCPromoOptions.AdditionalDC.Password) -eq $false)
            {
                return ($false,'GivenSiteDoesNotExist')
            }
            Else
            {
                Write-DSLog -Level info -Message "AD Site is successfully validated"
            }
        }
        Else {
            Write-DSLog -Level error -Message "Please specify a site name"
            return ($false,'BlankSiteName')
        }
    }


    if($xmldata.DSSOE.DCPromoOptions.Selected -eq "NewChildDomain")
    {        
        If($xmldata.DSSOE.DCPromoOptions.NewChildDomain.UserName -eq "" -or $xmldata.DSSOE.DCPromoOptions.NewChildDomain.Password -eq "")
        {
            Write-DSLog -Level error -Message "Please enter a username or password"
            return ($false,'BlankUserNameOrPassword')
        }
        Else
        {
            Write-DSLog -Level Info -Message "Username and password is entered. Username is $($xmldata.DSSOE.DCPromoOptions.NewChildDomain.UserName)"
        }

        Write-DSLog -Level Info -Message "Validating the username & password"
        Write-DSLog -Level Info -Message "The domain of the user account is $($xmldata.DSSOE.DCPromoOptions.NewChildDomain.Domain)"
        If((Test-DSCredentials -ContextType Domain -ContextName $xmldata.DSSOE.DCPromoOptions.NewChildDomain.Domain `
        -UserName $xmldata.DSSOE.DCPromoOptions.NewChildDomain.UserName `
        -Password $xmldata.DSSOE.DCPromoOptions.NewChildDomain.Password) -eq $false)
        {
            Write-DSLog -Level error -Message "Invalid domain name or credentials"
            return ($false,'InvalidPromoOpCredentials')
        }
        Else
        {
             Write-DSLog -Level Info -Message "Username & Password is successfully validated"
        }
        
        Write-DSLog -Level Info -Message "Validating if the specified username is a member of Enterprise Admins group or not"
        #Comment: 12-29-15 [Tarun]: Removed the calling of older function and added the calling of the new function
        <#
        try {
            $UserObject = Get-DSActiveDirectoryObject -Domain $xmldata.DSSOE.DCPromoOptions.NewChildDomain.Domain `
            -Username $xmldata.DSSOE.DCPromoOptions.NewChildDomain.UserName -Password $xmldata.DSSOE.DCPromoOptions.NewChildDomain.Password
            $GroupStatus = Test-DSGroupMembership -ADObject $UserObject -GroupName "Enterprise Admins"            
        }
        catch {
            Write-DSLog -Level error -Message "An error occurred while validating the group membership of the user account"
            Write-DSLog -Level error -Message "$($_.Exception.Message)"
            return ($false,'')
        }
        If($GroupStatus -eq $true) {
            Write-DSLog -Level Info -Message "Group membership is successfully validated"
        }
        Else {
            Write-DSLog -Level Info -Message "Group membership validation failed. User is not a member of the Enterprise Admins group. Make sure the User account has Enterprise Admin rights to continue with the DC promotion."
            return ($false,'')
        }
        #>
        Try {
            $GroupStatus = Test-DSGroupMembership -Domain $xmldata.DSSOE.DCPromoOptions.NewChildDomain.Domain `
            -UserName $xmldata.DSSOE.DCPromoOptions.NewChildDomain.UserName -Password $xmldata.DSSOE.DCPromoOptions.NewChildDomain.Password `
            -IsEnterpriseAdmins
            If($GroupStatus -eq $True) {
                Write-DSLog -Level Info -Message "Group membership is successfully validated"
            }
            Else {
                Write-DSLog -Level Info -Message "Group membership validation failed. User is not a member of the Enterprise Admins group. Make sure the specified User account has Enterprise Admin rights to continue with the DC promotion."
                return ($false,'UserNotEntAdmin')
            }
        }
        Catch {
            Write-DSLog -Level error -Message "An error occurred while validating the group membership of the user account"
            Write-DSLog -Level error -Message "$($_.Exception.Message)"
            return ($false,'GroupMembershipValidationError')
        }
        
        Write-DSLog -Level Info -Message "Validating the specified parent domain name: $($xmldata.DSSOE.DCPromoOptions.NewChildDomain.ParentDomain)"      
        If((Test-DSDomainExistence -username $xmldata.DSSOE.DCPromoOptions.NewChildDomain.UserName `
        -password $xmldata.DSSOE.DCPromoOptions.NewChildDomain.Password -domain $xmldata.DSSOE.DCPromoOptions.NewChildDomain.Domain `
        -DomainToSearch $xmldata.DSSOE.DCPromoOptions.NewChildDomain.ParentDomain -ChildDomainBuild) -eq $false) {
            Write-DSLog -Level error -Message "Parent domain validation has failed"
            return ($false,'ParentDomainValidationError')
        }
        else {
            Write-DSLog -Level Info -Message "Parent domain is successfully validated"
        }

        Write-DSLog -Level Info -Message "Validating the Child Domain Name: $($xmldata.DSSOE.DCPromoOptions.NewChildDomain.ChildDomainName)"
        If((Test-DSChildDomainName -ChildDomainName $xmldata.DSSOE.DCPromoOptions.NewChildDomain.ChildDomainName `
        -ParentDomainName $xmldata.DSSOE.DCPromoOptions.NewChildDomain.ParentDomain) -eq $false)
        {
            return ($false,'InvalidChildDomainName')
        }
        
        If((Test-NetBIOSName -Name $xmldata.DSSOE.DCPromoOptions.NewChildDomain.ChildDomainNameNetBIOS) -eq $false)
        {
            return ($false,'InvalidChildDomainNetBIOSName')
        }

        If(-not($ConfigADPathsToOSDrive)) {
            Write-DSLog -Level Info -Message "Validating Active Directory Database path - $($xmldata.DSSOE.DCPromoOptions.NewChildDomain.ADDatabasePath)"
            If((Test-ADContentPath -Path $xmldata.DSSOE.DCPromoOptions.NewChildDomain.ADDatabasePath) -eq $false)
            {
                return ($false,'InvalidADDatabasePath')
            }
            Else
            {
                Write-DSLog -Level Info -Message "AD Database path is successfully validated"
            }

            Write-DSLog -Level Info -Message "Validating AD Log file path - $($xmldata.DSSOE.DCPromoOptions.NewChildDomain.ADLogfilePath)"
            If((Test-ADContentPath -Path $xmldata.DSSOE.DCPromoOptions.NewChildDomain.ADLogfilePath) -eq $false)
            {
                return ($false,'InvalidADLogfilePath')
            }
            Else
            {
                Write-DSLog -Level Info -Message "AD log file path is successfully validated"
            }

            Write-DSLog -Level Info -Message "Validating AD Sysvol path - $($xmldata.DSSOE.DCPromoOptions.NewChildDomain.SysvolPath)"
            If((Test-ADContentPath -Path $xmldata.DSSOE.DCPromoOptions.NewChildDomain.SysvolPath) -eq $false)
            {
                return ($false,'InvalidADSysvolPath')
            }
            Else
            {
                Write-DSLog -Level Info -Message "AD Sysvol path successfully validated"
            }
        }
        Else {
            Write-DSLog -Level Info -Message "The switch parameter -ConfigADPathsToOSDrive is passed in the command, thus AD paths will be created on the system drive"            
            $RootDrive = $env:SystemDrive       
            $ADDBFolder = "$RootDrive\NTDS-DB"
            $ADLogsFolder = "$RootDrive\NTDS-LOGS"
            $ADSysvolFolder = "$RootDrive\SYSVOL"
            Write-DSLog -Level Info -Message "Validating Active Directory Database path - $ADDBFolder"
            If((Test-ADContentPath -Path $ADDBFolder) -eq $false)
            {
                return ($false,'InvalidADDatabasePath')
            }
            Else
            {
                Write-DSLog -Level Info -Message "AD Database path is successfully validated"
            }

            Write-DSLog -Level Info -Message "Validating AD Log file path - $ADLogsFolder"
            If((Test-ADContentPath -Path $ADLogsFolder) -eq $false)
            {
                return ($false,'InvalidADLogfilePath')
            }
            Else
            {
                Write-DSLog -Level Info -Message "AD log file path is successfully validated"
            }

            Write-DSLog -Level Info -Message "Validating AD Sysvol path - $ADSysvolFolder"
            If((Test-ADContentPath -Path $ADSysvolFolder) -eq $false)
            {
                return ($false,'InvalidADSysvolPath')
            }
            Else
            {
                Write-DSLog -Level Info -Message "AD Sysvol path successfully validated"
            }
        }

        Write-DSLog -Level Info -Message "Validating Safe mode admin password"
        If((Test-ComplexPassword -Password $xmldata.DSSOE.DCPromoOptions.NewChildDomain.SafeModeAdminPassword) -eq $false)
        {
            Write-DSLog -Level error -Message "Invalid <SafeModeAdminPassword> Value - The password should not be blank and should meet the complexity requirements, which are as follows:`r`nMinimum Length of 8 Chars`r`nAtleast 1 uppercase alphabet`r`nAtleast 1 lowercase alphabet`r`nAtleast 1 numeric char`r`nAtleast 1 special char" 
            return ($false,'InvalidSafeModeAdminPassword')
        }
        Else
        {
            Write-DSLog -Level Info -Message "Safe mode admin password is successfully validated"
        }

        Write-DSLog -Level Info -Message "Validating the Domain functional level - $($xmldata.DSSOE.DCPromoOptions.NewChildDomain.DomainFunctionalLevel)"
        If((Test-DSDomainLevel -Domainlevel $xmldata.DSSOE.DCPromoOptions.NewChildDomain.DomainFunctionalLevel`
         -Domain $xmldata.DSSOE.DCPromoOptions.NewChildDomain.Domain -username $xmldata.DSSOE.DCPromoOptions.NewChildDomain.UserName `
         -password $xmldata.DSSOE.DCPromoOptions.NewChildDomain.Password) -eq $false)
        {
            return ($false,'InvalidDomainFunctionalLevel')
        }
        Else
        {
            Write-DSLog -Level Info -Message "Domain functional level is successfully validated"
        }

        Write-DSLog -Level Info -Message "Validating GlobalCatalog value - $($xmldata.DSSOE.DCPromoOptions.NewChildDomain.GlobalCatalog)"
        If((Test-DSTrueFalse -value $xmldata.DSSOE.DCPromoOptions.NewChildDomain.GlobalCatalog) -eq $false)
        {
            Write-DSLog -Level error -Message "Invalid <GlobalCatalog> Value - Valid value is either True or False"
            return ($false,'InvalidGlobalCatalogValue')
        }
        Else
        {
            Write-DSLog -Level Info -Message "GlobalCatalog value is successfully validated"
        }

        Write-DSLog -Level Info -Message "Validating InstallDNS value - $($xmldata.DSSOE.DCPromoOptions.NewChildDomain.InstallDNS)"
        If((Test-DSTrueFalse -value $xmldata.DSSOE.DCPromoOptions.NewChildDomain.InstallDNS) -eq $false)
        {
            Write-DSLog -Level error -Message "Invalid <InstallDNS> Value - Valid value is either True or False"
            return ($false,'InvalidInstallDNSValue')
        }
        Else
        {
            Write-DSLog -Level info -Message "InstallDNS value is successfully validated"
        }

        <#Write-DSLog -Level info -Message "Validating RebootOnCompletion value - $($xmldata.DSSOE.DCPromoOptions.NewChildDomain.RebootOnCompletion)"
        If((Test-DSTrueFalse -value $xmldata.DSSOE.DCPromoOptions.NewChildDomain.RebootOnCompletion) -eq $false)
        {
            Write-DSLog -Level error -Message "Invalid <RebootOnCompletion> Value - Valid value is either True or False"
            return ($false,'InvalidRebootOnCompletionValue')
        }
        Else
        {
            Write-DSLog -Level info -Message "RebootOnCompletion value is successfully validated"
        }#> #14-Jun-16: [TR] Removed reboot on completion

        Write-DSLog -Level info -Message "Validating the user specified AD Site - $($xmldata.DSSOE.DCPromoOptions.NewChildDomain.ADSiteName)"
        If($xmldata.DSSOE.DCPromoOptions.NewChildDomain.ADSiteName -ne "") {
            if((Test-DSSiteExist -Value $xmldata.DSSOE.DCPromoOptions.NewChildDomain.ADSiteName -Domain $xmldata.DSSOE.DCPromoOptions.NewChildDomain.Domain `
            -Username $xmldata.DSSOE.DCPromoOptions.NewChildDomain.UserName -Password $xmldata.DSSOE.DCPromoOptions.NewChildDomain.Password) -eq $false)
            {
                return ($false,'GivenSiteDoesNotExist')
            }
            Else
            {
                Write-DSLog -Level info -Message "AD Site is successfully validated"
            }
        }
        Else {
            Write-DSLog -Level error -Message "Please specify a site name"
            return ($false,'BlankSiteName')
        }
    }


    if($xmldata.DSSOE.DCPromoOptions.Selected -eq "NewTreeDomain")
    {        
        If($xmldata.DSSOE.DCPromoOptions.NewTreeDomain.UserName -eq "" -or $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.Password -eq "")
        {
            Write-DSLog -Level error -Message "Please enter a username or password"
            return ($false,'BlankUserNameOrPassword')
        }
        Else
        {
            Write-DSLog -Level Info -Message "Username and password is entered. Username is $($xmldata.DSSOE.DCPromoOptions.NewTreeDomain.UserName)"
        }

        Write-DSLog -Level Info -Message "Validating username and password"
        Write-DSLog -Level Info -Message "The parent domain is $($xmldata.DSSOE.DCPromoOptions.NewTreeDomain.Domain)"
        If((Test-DSCredentials -ContextType Domain -ContextName $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.Domain `
        -UserName $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.UserName `
        -Password $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.Password) -eq $false)
        {
            Write-DSLog -Level error -Message "Invalid domain name or credentials"
            return ($false,'InvalidPromoOpCredentials')
        }
        Else
        {
            Write-DSLog -Level Info -Message "Username and password is successfully validated"
        }
        
        Write-DSLog -Level Info -Message "Validating if the specified username is a member of Enterprise Admins group or not"
        #Comment: 12-29-15 [Tarun]: Removed the calling of older function and added the calling of the new function
        <#
        try {
            $UserObject = Get-DSActiveDirectoryObject -Domain $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.Domain `
            -Username $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.UserName -Password $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.Password
            $GroupStatus = Test-DSGroupMembership -ADObject $UserObject -GroupName "Enterprise Admins"            
        }
        catch {
            Write-DSLog -Level error -Message "An error occurred while validating the group membership of the user account"
            Write-DSLog -Level error -Message "$($Error[0].Exception.Message)"
            return ($false,'')
        }
        If($GroupStatus -eq $true) {
            Write-DSLog -Level Info -Message "Group membership is successfully validated"
        }
        Else {
            Write-DSLog -Level Info -Message "Group membership validation failed. User is not a member of the Enterprise Admins group. Make sure the User account has Enterprise Admin rights to continue with the DC promotion."
            return ($false,'')
        }
        #>
        Try {
            $GroupStatus = Test-DSGroupMembership -Domain $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.Domain `
            -UserName $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.UserName -Password $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.Password `
            -IsEnterpriseAdmins
            If($GroupStatus -eq $true) {
                 Write-DSLog -Level Info -Message "Group membership is successfully validated"
            }
            Else {
                Write-DSLog -Level Info -Message "Group membership validation failed. User is not a member of the Enterprise Admins group. Make sure the User account has Enterprise Admin rights to continue with the DC promotion."
                return ($false,'UserNotEntAdmin')
            }
        }
        Catch {
            Write-DSLog -Level error -Message "An error occurred while validating the group membership of the user account"
            Write-DSLog -Level error -Message "$($_.Exception.Message)"
            return ($false,'GroupMembershipValidationError')
        }
        
        Write-DSLog -Level Info -Message "Validating the user specified Forest Root Domain: $($xmldata.DSSOE.DCPromoOptions.NewTreeDomain.ForestRootDomain)"
        If((Test-DSDomainExistence -username $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.UserName `
        -password $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.Password -domain $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.Domain `
        -DomainToSearch $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.ForestRootDomain -TreeDomainBuild) -eq $False) {
            Write-DSLog -Level error -Message "Forest Root Domain validation has failed"
            return ($false,'RootDomainNameValidationFailed')
        }
        Else {
            Write-DSLog -Level info -Message "Forest Root Domain is successfully validated"
        }

        If((Test-DomainName -Name $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.TreeDomainName) -eq $false)
        {
            return ($false,'TreeDomainNameValidationFailed')
        }

        If((Test-NetBIOSName -Name $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.TreeDomainNameNetbios) -eq $false)
        {
            return ($false,'TreeDomainNetBIOSNameValidationFailed')
        }

        If(-not($ConfigADPathsToOSDrive)) {
            Write-DSLog -Level Info -Message "Validating AD Database path - $($xmldata.DSSOE.DCPromoOptions.NewTreeDomain.ADDatabasePath)"
            If((Test-ADContentPath -Path $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.ADDatabasePath) -eq $false)
            {
                return ($false,'InvalidADDatabasePath')
            }
            Else
            {
                Write-DSLog -Level Info -Message "AD Database path is successfully validated"
            }

            Write-DSLog -Level Info -Message "Validating AD log file path - $($xmldata.DSSOE.DCPromoOptions.NewTreeDomain.ADLogfilePath)"
            If((Test-ADContentPath -Path $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.ADLogfilePath) -eq $false)
            {
                return ($false,'InvalidADLogfilePath')
            }
            Else
            {
                Write-DSLog -Level Info -Message "AD Log file path is successfully validated"
            }

            Write-DSLog -Level Info -Message "Validating AD Sysvol path - $($xmldata.DSSOE.DCPromoOptions.NewTreeDomain.SysvolPath)"
            If((Test-ADContentPath -Path $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.SysvolPath) -eq $false)
            {
                return ($false,'InvalidADSysvolPath')
            }
            Else
            {
                Write-DSLog -Level Info -Message "AD Sysvol path is successfully validated"
            }
        }
        Else {
            Write-DSLog -Level Info -Message "The switch parameter -ConfigADPathsToOSDrive is passed in the command, thus AD paths will be created on the system drive"            
            $RootDrive = $env:SystemDrive       
            $ADDBFolder = "$RootDrive\NTDS-DB"
            $ADLogsFolder = "$RootDrive\NTDS-LOGS"
            $ADSysvolFolder = "$RootDrive\SYSVOL"
            
            Write-DSLog -Level Info -Message "Validating AD Database path - $ADDBFolder"
            If((Test-ADContentPath -Path $ADDBFolder) -eq $false)
            {
                return ($false,'InvalidADDatabasePath')
            }
            Else
            {
                Write-DSLog -Level Info -Message "AD Database path is successfully validated"
            }

            Write-DSLog -Level Info -Message "Validating AD log file path - $ADLogsFolder"
            If((Test-ADContentPath -Path $ADLogsFolder) -eq $false)
            {
                return ($false,'InvalidADLogfilePath')
            }
            Else
            {
                Write-DSLog -Level Info -Message "AD Log file path is successfully validated"
            }

            Write-DSLog -Level Info -Message "Validating AD Sysvol path - $ADSysvolFolder"
            If((Test-ADContentPath -Path $ADSysvolFolder) -eq $false)
            {
                return ($false,'InvalidADSysvolPath')
            }
            Else
            {
                Write-DSLog -Level Info -Message "AD Sysvol path is successfully validated"
            }
        }
        
        Write-DSLog -Level Info -Message "Validating Safe mode admin password"
        If((Test-ComplexPassword -Password $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.SafeModeAdminPassword) -eq $false)
        {
            Write-DSLog -Level error -Message "Invalid <SafeModeAdminPassword> Value - The password should not be blank and should meet the complexity requirements, which are as follows:`r`nMinimum Length of 8 Chars`r`nAtleast 1 uppercase alphabet`r`nAtleast 1 lowercase alphabet`r`nAtleast 1 numeric char`r`nAtleast 1 special char" 
            return ($false,'InvalidSafeModeAdminPassword')
        }
        else
        {
            Write-DSLog -Level Info -Message "Safe mode admin password is successfully validated"
        }

        Write-DSLog -Level Info -Message "Validating Domain functional level - $($xmldata.DSSOE.DCPromoOptions.NewTreeDomain.DomainFunctionalLevel)"
        If((Test-DSDomainLevel -Domainlevel $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.DomainFunctionalLevel`
         -Domain $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.Domain -username $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.UserName `
         -password $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.Password) -eq $false)
        {
            return ($false,'InvalidDomainFunctionalLevel')
        }
        Else
        {
            Write-DSLog -Level Info -Message "Domain functional level is successfully validated"
        }

        Write-DSLog -Level Info -Message "Validating GlobalCatalog value - $($xmldata.DSSOE.DCPromoOptions.NewTreeDomain.GlobalCatalog)"
        If((Test-DSTrueFalse -value $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.GlobalCatalog) -eq $false)
        {
            Write-DSLog -Level error -Message "Invalid <GlobalCatalog> Value - Valid value is either True or False"
            return ($false,'InvalidGlobalCatalogValue')
        }
        Else
        {
            Write-DSLog -Level Info -Message "GlobalCatalog value is successfully validated"
        }

        Write-DSLog -Level Info -Message "Validating InstallDNS value - $($xmldata.DSSOE.DCPromoOptions.NewTreeDomain.InstallDNS)"
        If((Test-DSTrueFalse -value $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.InstallDNS) -eq $false)
        {
            Write-DSLog -Level error -Message "Invalid <InstallDNS> Value - Valid value is either True or False"
            return ($false,'InvalidInstallDNSValue')
        }
        Else
        {
            Write-DSLog -Level Info -Message "InstallDNS value is successfully validated"
        }

        <#Write-DSLog -Level Info -Message "Validating RebootOnCompletion value - $($xmldata.DSSOE.DCPromoOptions.NewTreeDomain.RebootOnCompletion)"
        If((Test-DSTrueFalse -value $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.RebootOnCompletion) -eq $false)
        {
            Write-DSLog -Level error -Message "Invalid <RebootOnCompletion> Value - Valid value is either True or False"
            return ($false,'InvalidRebootOnCompletionValue')
        }
        else
        {
            Write-DSLog -Level Info -Message "RebootOnCompletion value is successfully validated"
        }#> #14-Jun-16: [TR] Removed reboot on completion

        Write-DSLog -Level info -Message "Validating the user specified AD Site - $($xmldata.DSSOE.DCPromoOptions.NewTreeDomain.ADSiteName)"
        If($xmldata.DSSOE.DCPromoOptions.NewTreeDomain.ADSiteName -ne "") {
            if((Test-DSSiteExist -Value $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.ADSiteName -Domain $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.Domain `
            -Username $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.UserName -Password $xmldata.DSSOE.DCPromoOptions.NewTreeDomain.Password) -eq $false)
            {
                return ($false,'GivenSiteDoesNotExist')
            }
            Else
            {
                Write-DSLog -Level info -Message "AD Site is successfully validated"
            }
        }
        Else {
            Write-DSLog -Level error -Message "Please specify a site name"
            return ($false,'BlankSiteName')
        }
    }

    If($xmldata.dssoe.DCPromoOptions.Selected -ne "NewDomainNewForest")
    {
        Write-DSLog -Level Info -Message "Validating the value of Subnet.Association - $($xmldata.dssoe.DCPromoOptions.Subnet.Association)"        
        If((Test-DSTrueFalse -value $xmldata.dssoe.DCPromoOptions.Subnet.Association) -eq $false)
        {
            Write-DSLog -Level Error -Message "Invalid <Subnet.Association> value - Valid value is either true or false"
            return ($false,'InvalidSubnetAssociationValue')
        }
        Else
        {
            Write-DSLog -Level Info -Message "Subnet.Association value is successfully validated"
        }

        If($xmldata.dssoe.DCPromoOptions.Subnet.Association -ne "false")
        {
            Write-DSLog -Level Info -Message "Validating enterprise admin username & password"
            If((Test-DSCredentials -ContextType Domain -ContextName $xmldata.dssoe.DCPromoOptions.Subnet.Domain `
            -UserName $xmldata.dssoe.DCPromoOptions.Subnet.EntAdminUserName `
            -Password $xmldata.dssoe.DCPromoOptions.Subnet.Password) -eq $false)
            {
                Write-DSLog -Level error -Message "Invalid domain name or credentials"
                return ($false,'SiteSubnetAssociationCredentialValidationFailed')
            }
            Else
            {
                Write-DSLog -Level Info -Message "Username & password is successfully validated"
            }

            Write-DSLog -Level Info -Message "Validating if the specified username is a member of Enterprise Admins group or not"
            #Comment: 12-29-15 [Tarun]: Removed the calling of older function and added the calling of the new function
            <#
            try {
                $UserObject = Get-DSActiveDirectoryObject -Domain $xmldata.dssoe.DCPromoOptions.Subnet.Domain `
                -Username $xmldata.dssoe.DCPromoOptions.Subnet.EntAdminUserName -Password $xmldata.dssoe.DCPromoOptions.Subnet.Password
                $GroupStatus = Test-DSGroupMembership -ADObject $UserObject -GroupName "Enterprise Admins"            
            }
            catch {
                Write-DSLog -Level error -Message "An error occurred while validating the group membership of the user account"
                Write-DSLog -Level error -Message "$($Error[0].Exception.Message)"
                return ($false,'')
            }
            If($GroupStatus -eq $true) {
                Write-DSLog -Level Info -Message "Group membership is successfully validated"
            }
            Else {
                Write-DSLog -Level Info -Message "Group membership validation failed. User is not a member of the Enterprise Admins group. Make sure the User account has Enterprise Admin rights to continue with the DC promotion."
                return ($false,'')
            }
            #>
            Try {
                $GrpStatus = Test-DSGroupMembership -Domain $xmldata.dssoe.DCPromoOptions.Subnet.Domain `
                -UserName $xmldata.dssoe.DCPromoOptions.Subnet.EntAdminUserName -Password $xmldata.dssoe.DCPromoOptions.Subnet.Password `
                -IsEnterpriseAdmins
                If($GrpStatus -eq $true) {
                    Write-DSLog -Level Info -Message "Group membership is successfully validated"
                }
                Else {
                    Write-DSLog -Level Info -Message "Group membership validation failed. User is not a member of the Enterprise Admins group. Make sure the specified User account has Enterprise Admin rights to continue with the DC promotion."
                    return ($false,'UserNotEntAdmin')
                }
            }
            Catch {
                Write-DSLog -Level error -Message "An error occurred while validating the group membership of the user account"
                Write-DSLog -Level error -Message "$($_.Exception.Message)"
                return ($false,'GroupMembershipValidationError')
            }

            Write-DSLog -Level Info -Message "Validating the value of Subnet.SubnetMask parameter."
            If($xmldata.dssoe.DCPromoOptions.Subnet.SubnetMask -eq "")
            {
                Write-DSLog -Level error -Message "A value for Subnet.SubnetMask parameter is not specified"
                return ($false,'BlankSubnetMask')
            }
            Else
            {
                Write-DSLog -Level Info -Message "The specified SubnetMask is $($xmldata.dssoe.DCPromoOptions.Subnet.SubnetMask)"
            }
        }
        Else {
             Write-DSLog -Level Info -Message "The Subnet Association parameter is set to false, thus site to subnet association configuration parameters are skipped for validation"
        }
    }

    #Validating IP Configuration tags
    Write-DSLog -Level Info -Message "Validating the value of IPConfig.Enabled - $($xmldata.DSSOE.DSConfiguration.IPConfig.Enabled)"
    If((Test-DSTrueFalse -value $xmldata.DSSOE.DSConfiguration.IPConfig.Enabled) -eq $false)
    {
        Write-DSLog -Level error -Message "Invalid <IpConfig Enabled> Value - Valid value is either True or False"
        return ($false,'InvalidIPConfValue')
    }
    Else
    {
        Write-DSLog -Level info -Message "IPConfig.Enabled value is successfully validated"
    }
    
    #if ipconfig.enabled is true then only the other IP configuration parameters will be validated, else skip to else part
    If($xmldata.DSSOE.DSConfiguration.IPConfig.Enabled -eq "true")
    {
        Write-DSLog -Level Info -Message "IPConfig.Enabled is true; IP configuration parameters will now be validated"
        Write-DSLog -Level Info -Message "Validating the Network adapter name - $($xmldata.DSSOE.DSConfiguration.IPConfig.NetworkAdapterName)"
        If((Test-DSNetworkAdapterName -NetworkAdapterName $xmldata.DSSOE.DSConfiguration.IPConfig.NetworkAdapterName) -eq $false)
        {
            return ($false,'InvalidNetworkAdapter')
        }
        Else
        {
            Write-DSLog -Level info -Message "Network adapter name is successfully validated"
        }

        Write-DSLog -Level Info -Message "Validating IP Address - $($xmldata.DSSOE.DSConfiguration.IPConfig.IPAddress)"
        If((Test-DSIPAddress -IPAddress $xmldata.DSSOE.DSConfiguration.IPConfig.IPAddress) -eq $false)
        {
            Write-DSLog -Level error -Message "Invalid or blank IP Address" 
            return ($false,'InvalidIPAddress')
        }
        Else
        {
            Write-DSLog -Level Info -Message "IP Address is successfully validated"
        }

        $NetworkAdapter = Get-WmiObject -Class "Win32_NetworkAdapter" | Where-Object { $_.netconnectionid -eq $xmldata.DSSOE.DSConfiguration.IPConfig.NetworkAdapterName }
        $Networkinterface = Get-WmiObject -Class "Win32_NetworkAdapterConfiguration" | Where-Object { $_.interfaceindex -eq $NetworkAdapter.interfaceindex }
        $IPString = $NetworkInterface.IPAddress
        $ValidIPAddress = $xmldata.DSSOE.DSConfiguration.IPConfig.IPAddress
        If($($IPString) -ne $($ValidIPAddress)) {
            Write-DSLog -Level Info -Message "Validating IP Address duplicacy"
            If((Test-DSDuplicateIPAddress -IPAddr $xmldata.DSSOE.DSConfiguration.IPConfig.IPAddress) -eq $true)
            {
                Write-DSLog -Level error -Message "Duplicate IP Address is present on the network"
                return ($false,'DuplicateIPAddress')
            }
            Else {
                Write-DSLog -Level Info -Message "No duplicate IP on the network"
            }
        }

        Write-DSLog -Level Info -Message "Validating Subnet Mask - $($xmldata.DSSOE.DSConfiguration.IPConfig.SubnetMask)"
        If((Test-DSIPSubnet -IPMask $xmldata.DSSOE.DSConfiguration.IPConfig.SubnetMask) -eq $false)
        {
            Write-DSLog -Level error -Message "Invalid or blank Subnet Mask"
            return ($false,'InvalidSubnetMask')
        }
        Else
        {
             Write-DSLog -Level Info -Message "Subnet Mask is successfully validated"
        }

        If($xmldata.DSSOE.DSConfiguration.IPConfig.Gateway -ne "")
        {
            Write-DSLog -Level Info -Message "Validating Gateway IP - $($xmldata.DSSOE.DSConfiguration.IPConfig.Gateway)"
            If((Test-DSIPAddress -IPAddress $xmldata.DSSOE.DSConfiguration.IPConfig.Gateway) -eq $false)
            {
                Write-DSLog -Level error -Message "Invalid Gateway Address"
                return ($false,'InvalidGatewayAddress')
            }
            Else
            {
                Write-DSLog -Level Info -Message "Gateway IP is successfully validated"
            }
        }
        Else
        {
            Write-DSLog -Level info -Message "Gateway tag is blank and thus will not be configured"
        }

        Write-DSLog -Level Info -Message "Validating DNS IP Address(es) - $($xmldata.DSSOE.DSConfiguration.IPConfig.DNSAddress)"
        If((Test-MultipleIPAddress -IPAddress $xmldata.DSSOE.DSConfiguration.IPConfig.DNSAddress) -eq $false)
        {
            Write-DSLog -Level error -Message "Invalid or blank DNS Address"
            return ($false,'InvalidDNSAddress')
        }
        Else
        {
            Write-DSLog -Level Info -Message "DNS IP Address(es) are successfully validated"
        }

        <#If($xmldata.DSSOE.DSConfiguration.IPConfig.WINSAddress -ne "")
        {
            Write-DSLog -Level Info -Message "Validating WINS Address(es) - $($xmldata.DSSOE.DSConfiguration.IPConfig.WINSAddress)"
            If((Test-MultipleIPAddress -IPAddress $xmldata.DSSOE.DSConfiguration.IPConfig.WINSAddress) -eq $false)
            {
                Write-DSLog -Level error -Message "Invalid WINS Address"
                return ($false,'InvalidWINSAddress')
            }
            Else
            {
                 Write-DSLog -Level Info -Message "WINS Address(es) are successfully validated"
            }
            
            $WINSServer = $($xmldata.DSSOE.DSConfiguration.IPConfig.WINSAddress).split(",")
            Write-DSLog -Level Info -Message "Validating the count of WINS Server - $($WINSServer.count)"
            If($WINSServer.count -gt 2)
            {
                Write-DSLog -Level error -Message "Only two WINS server are allowed to be configured i.e. Primary and Secondary WINS server. Ensure that the count of IP addresses entered should not be greater than 2."
                return ($false,'OnlyTwoWINSServersAllowed')
            }
            Else
            {
                Write-DSLog -Level Info -Message "WINSServer count is successfully validated"
            }
        }
        Else
        {
            Write-DSLog -Level Info -Message "WINS address tag is blank, thus it will not be configured"
        }#> #-- Commenting since wins parameter is removed  - Arun 08-06-2016

        If($xmldata.DSSOE.DSConfiguration.IPConfig.NetworkAdapterDNSSuffix -ne "")
        {
            Write-DSLog -Level info -Message "Validating NetworkAdapterDNSSuffix - $($xmldata.DSSOE.DSConfiguration.IPConfig.NetworkAdapterDNSSuffix)"
            If((Test-DSDNSSuffix -Suffix $xmldata.DSSOE.DSConfiguration.IPConfig.NetworkAdapterDNSSuffix) -eq $false)
            {
                Write-DSLog -Level error -Message "Invalid DNS Suffix"
                return ($false,'InvalidNetDNSSuffix')
            }
            Else
            {
                Write-DSLog -Level info -Message "NetworkAdapterDNSSuffix is successfully validated"
            }
        }
        Else
        {
            Write-DSLog -Level info -Message "NetworkAdapterDNSSuffix tag is blank, thus it will not be configured"
        }

        If($xmldata.DSSOE.DSConfiguration.IPConfig.LmhostsLookup -ne "")
        {
            Write-DSLog -Level info -Message "Validating Lmhostslookup - $($xmldata.DSSOE.DSConfiguration.IPConfig.LmhostsLookup)"
            If((Test-DSTrueFalse -value $xmldata.DSSOE.DSConfiguration.IPConfig.LmhostsLookup) -eq $false)
            {
                Write-DSLog -Level error -Message "Invalid <LmhostsLookUp> Value - Valid value is either True or False"
                return ($false,'InvalidLmhostsLookUpValue')
            }
            Else
            {
                Write-DSLog -Level info -Message "LmhostsLookup is successfully validated"
            }
        }
        Else
        {
            Write-DSLog -Level info -Message "LmHostsLookup tag is blank, thus it will not be configured"
        }
    }
    Else
    {
        Write-DSLog -Level info -Message "IPConfig.Enabled parameter is set to false, thus IP configuration parameters will not be validated"
    }
    
    If($ExpressInstall) {
    Write-DSLog -Level info -Message "[dspromo] Pre and Post DSSOE configuration stands irrelevant if -ExpressInstall parameter is passed, thus skipping the validation of pre and post"
    }
    Else {
        #Write-DSLog -Level info -Message "[STARTUP_RECOVERY] Validating the value of StartupAndRecoverySettings.Enabled - $($xmldata.DSSOE.DSConfiguration.StartupAndRecoverySettings.Enabled)"
        #If((Test-DSTrueFalse -value $xmldata.DSSOE.DSConfiguration.StartupAndRecoverySettings.Enabled) -eq $false)
        #{
        #    Write-DSLog -Level error -Message "[STARTUP_RECOVERY] Invalid <StartupAndRecoverySettings Enabled> Value - Valid value is either True or False"
        #    return ($false,'')
        #}
        #Else
        #{
        #    Write-DSLog -Level info -Message "[STARTUP_RECOVERY] StartupAndRecoverySettings.Enabled is successfully validated"
        #}

        #If($xmldata.DSSOE.DSConfiguration.StartupAndRecoverySettings.Enabled -ne "false")
        #{
        #    If((Test-DSStartupRecovery -timetodisplayos $xmldata.DSSOE.DSConfiguration.StartupAndRecoverySettings.TimetoDisplayOS `
        #    -writedebuginfo $xmldata.DSSOE.DSConfiguration.StartupAndRecoverySettings.WriteDebugInfo) -eq $false)
        #    {
        #        return ($false,'')
        #    }
        #}
        #Else {
        #     Write-DSLog -Level info -Message "[STARTUP_RECOVERY] The value for Enabled parameter is set to False, thus Startup and recovery configuration will not be implemented."
        #}

        Write-DSLog -Level info -Message "Validating the value of ConfigureDSPageFile - $($xmldata.DSSOE.DSConfiguration.ConfigureDSPageFile)"
        If((Test-DSTrueFalse -value $xmldata.DSSOE.DSConfiguration.ConfigureDSPageFile) -eq $false)
        {
            Write-DSLog -Level error -Message "Invalid <ConfigureDSPageFile> Value - Valid value is either True or False"
            return ($false,'InvalidConfigureDSPageFileValue')
        }
        Else
        {
            Write-DSLog -Level info -Message "Value of ConfigureDSPageFile is successfully validated"
        }
        If($xmldata.DSSOE.DSConfiguration.ConfigureDSPageFile -eq "False") {
            Write-DSLog -Level info -Message "The value of ConfigureDSPageFile parameter is set to False, thus page file configuration will not be implemented."
        }

        Write-DSLog -Level info -Message "Validating the value of ClearEvents - $($xmldata.DSSOE.DSConfiguration.ClearEvents)"
        If((Test-DSTrueFalse -value $xmldata.DSSOE.DSConfiguration.ClearEvents) -eq $false)
        {
            Write-DSLog -Level error -Message "Invalid <ClearEvents> Value - Valid value is either True or False"
            return ($false,'InvalidClearEventsValue')
        }
        Else
        {
            Write-DSLog -Level info -Message "Value of ClearEvents is successfully validated"
        }
        If($xmldata.DSSOE.DSConfiguration.ClearEvents -eq "False") {
            Write-DSLog -Level info -Message "The value of ClearEvents parameter is set to False, thus event log will not be cleared."
        }

        If((Test-DSConfigReserveFile -ReserveFilePath $xmldata.DSSOE.DSConfiguration.ReserveFile.Path -SizeInMB $xmldata.DSSOE.DSConfiguration.ReserveFile.SizeMB) -eq $false)
        {
            return ($false,'ReserveFileValidationError')
        }
        Else
        {
            Write-DSLog -Level info -Message "Reserve file options are successfully validated"
        }

        Write-DSLog -Level info -Message "Validating the value of DisableNetBIOSOverTCPIP - $($xmldata.DSSOE.DSConfiguration.DisableNetBIOSOverTCPIP)"
        If((Test-DSTrueFalse -value $xmldata.DSSOE.DSConfiguration.DisableNetBIOSOverTCPIP) -eq $false)
        {
            Write-DSLog -Level error -Message "Invalid DisableNetBIOSOverTCPIP Value - Valid value is either True or False"
            return ($false,'InvalidDisableNetBIOSOverTCPIPValue')
        }
        Else
        {
            Write-DSLog -Level info -Message "Value of DisableNetBIOSOverTCPIP is successfully validated"
        }
        If($xmldata.DSSOE.DSConfiguration.DisableNetBIOSOverTCPIP -eq "False") {
            Write-DSLog -Level info -Message "The value of DisableNetBIOSOverTCPIP parameter is set to False, thus Netbios over tcpip will not be disabled."
        }

        Write-DSLog -Level info -Message "Validating the value of DisableSMB1 - $($xmldata.DSSOE.DSConfiguration.DisableSMB1)"
        If((Test-DSTrueFalse -value $xmldata.DSSOE.DSConfiguration.DisableSMB1) -eq $false)
        {
            Write-DSLog -Level error -Message "Invalid DisableSMB1 Value - Valid value is either True or False"
            return ($false,'InvalidDisableSMB1Value')
        }
        Else
        {
            Write-DSLog -Level info -Message "Value of DisableSMB1 is successfully validated"
        }
        If($xmldata.DSSOE.DSConfiguration.DisableSMB1 -eq "False") {
            Write-DSLog -Level info -Message "The value of DisableSMB1 parameter is set to False, thus SMB1 will not be disabled."
        }

        Write-DSLog -Level info -Message "Validating the value of ConfigureRPCPortRange.Configure - $($xmldata.DSSOE.DSConfiguration.ConfigureRPCPortRange.Configure)"
        If((Test-DSTrueFalse -value $xmldata.DSSOE.DSConfiguration.ConfigureRPCPortRange.Configure) -eq $false)
        {
            Write-DSLog -Level error -Message "Invalid ConfigureRPCPortRange.Configure Value - Valid value is either True or False"
            return ($false,'InvalidConfigureRPCPortRangeConfigureValue')
        }
        Else
        {
            Write-DSLog -Level info -Message "Value of ConfigureRPCPortRange.Configure is successfully validated"
        }
        If($xmldata.DSSOE.DSConfiguration.ConfigureRPCPortRange.Configure -eq "False") {
            Write-DSLog -Level info -Message "The value of ConfigureRPCPortRange.Configure parameter is set to False, thus rpc port ranges restriction will not be configured."
        }
        else
        {
        Write-DSLog -Level error -Message "Validating RPCPortRange Value"
            if((Test-DSPortRange -portrange $xmldata.DSSOE.DSConfiguration.ConfigureRPCPortRange.PortRange) -eq $false)
            {
            Write-DSLog -Level error -Message "Invalid ConfigureRPCPortRange.Portrange Value"
            return ($false,'InvalidConfigureRPCPortRangeValue')
            }
            else
            {
            Write-DSLog -Level info -Message "Value of ConfigureRPCPortRange.portrange is successfully validated"
            }
        }

        If((Test-DSTimeServer -TimeServerName $xmldata.DSSOE.DSConfiguration.ExternalTimeServer.Name) -eq $false)
        {
            return ($false,'TimeServerValidationError')
        }
        
        #Comment - Removed this section as antivirus exclusion is depracated from this version of dssoe.
        <#Write-DSLog -Level info -Message "[ANTIVIRUS] Validating the value of AntiVirusExclusion - $($xmldata.DSSOE.DSConfiguration.Antivirusexclusion)"
        If((Test-DSTrueFalse -value $xmldata.DSSOE.DSConfiguration.Antivirusexclusion) -eq $false)
        {
            Write-DSLog -Level error -Message "[ANTIVIRUS] Invalid <AntivirusExclusion> Value - Valid value is either True or False"
            return ($false,'')
        }
        Else
        {
            Write-DSLog -Level info -Message "[ANTIVIRUS] AntiVirusExclusion value is successfully validated"
        }#>
       
        If(($xmldata.DSSOE.DCPromoOptions.Selected -eq "AdditionalDC") -and ($xmldata.DSSOE.DCPromoOptions.AdditionalDC.RODC -eq "false"))
        {
            Write-DSLog -Level info -Message "Validating the value of DCOULocation - $($xmldata.DSSOE.DSConfiguration.DCOULocation.OU)"
            If((Test-DSOULocation -Domain $xmldata.DSSOE.DCPromoOptions.AdditionalDC.Domain -Username $xmldata.DSSOE.DCPromoOptions.AdditionalDC.UserName `
            -Password $xmldata.DSSOE.DCPromoOptions.AdditionalDC.Password -OULocation $xmldata.DSSOE.DSConfiguration.DCOULocation.OU) -eq $false)
            {
                return ($false,'InvalidDSOULocation')
            }
            Else
            {
                Write-DSLog -Level info -Message "Value of DCOULocation is successfully validated"
            }
        }

        If($xmldata.DSSOE.DCPromoOptions.Selected -ne "AdditionalDC")
        {
            If((Test-DSBaselinePolicy -DomainPolicy $xmldata.DSSOE.DSConfiguration.SecurityBaselinePolicies.ConfigureDomainPolicy `
            -DomainControllerPolicy $xmldata.DSSOE.DSConfiguration.SecurityBaselinePolicies.ConfigureDomainControllerPolicy) -eq $false)
            {
                return ($false,'InvalidDSBaselinePolicyValue')
            }
        }

        If($xmldata.DSSOE.DCPromoOptions.Selected -ne "AdditionalDC")
        {
            If(($xmldata.DSSOE.DSConfiguration.OUStructure.AccountType -eq "") -and ($xmldata.DSSOE.DSConfiguration.OUStructure.AccountCode -eq "")) {
                Write-DSLog -Level info -Message "The parameters for OU structure creation are not specified, thus this configuration will not be implemented"
            }
            else {
                If(($xmldata.DSSOE.DSConfiguration.OUStructure.AccountType -ne "") -and ($xmldata.DSSOE.DSConfiguration.OUStructure.AccountCode -ne "")) 
                {
                    If((Test-DSOUStructure -AccountType $xmldata.DSSOE.DSConfiguration.OUStructure.AccountType -AccountCode $xmldata.DSSOE.DSConfiguration.OUStructure.AccountCode) -eq $false)
                    {
                        return ($false,'InvalidOUStructureOptions')
                    }
                    elseif($xmldata.DSSOE.DSConfiguration.OUStructure.AccountType -eq "MultiTenant")
                    {
                        Write-DSLog -Level info -Message "Account type multitenant selected. validating addelegation value"
                        if((Test-DSTrueFalse -value $xmldata.DSSOE.DSConfiguration.OUStructure.ADDelegation) -eq $false)
                        {
                        Write-DSLog -Level error -Message "Invalid ADDelegation value. Valid values are true or false"
                        return ($false,'InvalidADDelegationValue')
                        }
                    }
                }
                Else {
                    Write-DSLog -Level error -Message "Either of the OU structure creation parameter is not specified. For OU structure creation both the parameters must be passed. If you do not want the DSSOE program to create the OU structure then leave both the parameters blank."
                    return ($false,'BlankOUStructureValues')
                }
            }
        }

        Write-DSLog -Level info -Message "Validating the value of DSBackup.Configure - $($xmldata.DSSOE.DSConfiguration.DSBackup.Configure)"
        If((Test-DSTrueFalse -value $xmldata.DSSOE.DSConfiguration.DSBackup.Configure) -eq $false)
        {
            Write-DSLog -Level error -Message "Invalid <DSBackup Configure> Value - Valid value is either True or False"
            return ($false,'InvalidDSBackupConfigValue')
        }
        Else
        {
            Write-DSLog -Level info -Message "DSBackup.Configure value is successfully validated"
        }

        If($xmldata.DSSOE.DSConfiguration.DSBackup.Configure -ne "false")
        {
            If((Test-DSConfigureBackup -EnableBackupMaintenance $xmldata.DSSOE.DSConfiguration.DSBackup.EnableBackupMaintenance `
            -BackupVolumePath $xmldata.DSSOE.DSConfiguration.DSBackup.BackupVolumePath) -eq $false)
            {
                return ($false,'DSBackupConfigValidationError')
            }
        }
        Else {
            Write-DSLog -Level info -Message "The value for configure parameter is set to false, thus backup configuration will not be implemented."
        }

        If((Test-DSFileExistence -FilePath $xmldata.DSSOE.DSConfiguration.CreateADUsers.UserListExcelFile) -eq $false)
        {
            return ($false,'InvalidUserListExcelFile')
        }

        <#If((Test-DSBPAReport -GenerateBPA $xmldata.DSSOE.DSConfiguration.BPAReport.Generate `
        -ReportPath $xmldata.DSSOE.DSConfiguration.BPAReport.ReportPath) -eq $false)
        {
            return ($false,'BPAReportOptionsValidationError')
        }-Not accepting BPA parameter hence commenting this section - Arun 8-6-16#>

        Write-DSLog -Level info -Message "Validating DNS Forwarders IP - $($xmldata.DSSOE.DSConfiguration.DNSForwarders.ForwardersIP)"
        If($xmldata.DSSOE.DSConfiguration.DNSForwarders.ForwardersIP -eq "") {
             Write-DSLog -Level info -Message "DNS Forwarders parameter isn't specified a value with, thus it will not be configured."
        }                
        If(($xmldata.DSSOE.DSConfiguration.DNSForwarders.ForwardersIP -ne "") -and `
        (Test-DSIPAddress -IPAddress $xmldata.DSSOE.DSConfiguration.DNSForwarders.ForwardersIP) -eq $false)
        {
            Write-DSLog -Level error -Message "Invalid <ForwardersIP> - Please enter a valid IP address."
            return ($false,'InvalidForwarderIPAddress')
        }
        Else
        {
             Write-DSLog -Level info -Message "DNS Forwarder option is successfully validated"
        }

        Write-DSLog -Level info -Message "Validating the value of ConfigDNSScavenging option - $($xmldata.DSSOE.DSConfiguration.ConfigDNSScavenging)"

        If($xmldata.DSSOE.DCPromoOptions.Selected -ne "AdditionalDC")
        {
            if((Test-DSTrueFalse -value $xmldata.DSSOE.DSConfiguration.ConfigDNSScavenging) -eq $false)
            {
            Write-DSLog -Level error -Message "Invalid ConfigDNSScavenging value."
            return ($false,'InvalidConfigDNSScavengingValue')
            }
        }
        Write-DSLog -Level info -Message "Validating the value of ConfigureDSRM option - $($xmldata.DSSOE.DSConfiguration.ConfigureDSRM)"
        if((Test-DSTrueFalse -value $xmldata.DSSOE.DSConfiguration.ConfigureDSRM) -eq $false)
            {
            Write-DSLog -Level error -Message "Invalid ConfigureDSRM value."
            return ($false,'InvalidConfigureDSRMValue')
            }
     Write-DSLog -Level info -Message "Validating the value of InstallADHotfixes option - $($xmldata.DSSOE.DSConfiguration.InstallADHotfixes)"
        if((Test-DSTrueFalse -value $xmldata.DSSOE.DSConfiguration.InstallADHotfixes) -eq $false)
            {
            Write-DSLog -Level error -Message "Invalid InstallADHotfixes value."
            return ($false,'InvalidInstallADHotfixesValue')
            }

        Write-DSLog -Level info -Message "Validating the value of StaticPort.Configure option - $($xmldata.DSSOE.DSConfiguration.StaticPort.Configure)"
        If((Test-ValuesRange -value $xmldata.DSSOE.DSConfiguration.StaticPort.Configure -range ("True","False")) -eq $false)
        {
            Write-DSLog -Level error -Message "Invalid <StaticPort Configure> value - The valid value is either True or False"
            return ($false,'InvalidStaticPortConfigValue')
        }
        Else
        {
            Write-DSLog -Level info -Message "StaticPort.Configure value is successfully validated"
        }

        If($xmldata.DSSOE.DSConfiguration.StaticPort.Configure -ne "false")
        {
            If((Test-DSStaticPorts -ADReplicationPort $xmldata.DSSOE.DSConfiguration.StaticPort.ADReplicationPort `
            -NetlogonPort $xmldata.DSSOE.DSConfiguration.StaticPort.NetLogonPort -DFSRPort $xmldata.DSSOE.DSConfiguration.StaticPort.DFSRReplicationPort) -eq $false)
            #-NetlogonPort $xmldata.DSSOE.DSConfiguration.StaticPort.NetLogonPort -FRSPort $xmldata.DSSOE.DSConfiguration.StaticPort.FRSReplicationPort `
            {
                return ($false,'StaticPortValidationError')
            }
        }
        Else {
            Write-DSLog -Level info -Message "The Static Port Configure parameter is set to False, thus static port configuration will not be implemented."
        }

        If($xmldata.DSSOE.DCPromoOptions.Selected -eq 'NewDomainNewForest') { # dcpromooptions is newdomainnewforest
             Write-DSLog -Level info -Message "newdomainnewforest build type is selected."
             Write-DSLog -Level info -Message "Validating the value of ADRecycleBin.Enable parameter - $($xmldata.DSSOE.DSConfiguration.ADRecycleBin.Enable)"
            If((Test-ValuesRange -value $xmldata.DSSOE.DSConfiguration.ADRecycleBin.Enable -range ("True","False")) -eq $false)
            {
                Write-DSLog -Level error -Message "Invalid ADRecycleBin.Enable value - The valid value is either True or False"
                return ($false,'InvalidADRecycleBinEnableValue')
            }
            Else
            {
                Write-DSLog -Level info -Message "ADRecycleBin.Enabled value is successfully validated"
            }

            If($xmldata.DSSOE.DSConfiguration.ADRecycleBin.Enable -ne "False") {                
                Write-DSLog -Level Info -Message "Validating the forest functional level requirements for AD Recycle Bin."
                If(!($xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.ForestFunctionalLevel -in ("Windows2008R2Forest","Windows2012Forest","Windows2012R2Forest","Windows2016Forest"))) {
                    Write-DSLog -Level error -Message "Invalid forest functional level. In order to enable AD Recycle Bin the forest functional level has to be Windows2008R2Forest and beyond."
                    return ($false,'InvalidADRecycleBinForestFunctionalLevel')
                }
                Else {
                    Write-DSLog -Level Info -Message "AD Recycle Bin forest functional level requirement has been successfully validated"
                }
            }
            #In case of newdomainnewforest build scenario, the rest of the AD Recycle Bin parameters are not validated because they are not used in the code 
            #to implement the AD recycle bin, instead the newdomainnewforest parameters are used.
        }
        Else { # DCpromoOptions is other than newdomainnewforest        
            Write-DSLog -Level info -Message "dcpromooptions value is not equal to newdomainnewforest"
            Write-DSLog -Level info -Message "Validating the Active Directory Recycle Bin parameter values"
            Write-DSLog -Level info -Message "Validating the value of ADRecycleBin.Enable parameter - $($xmldata.DSSOE.DSConfiguration.ADRecycleBin.Enable)"
            If((Test-ValuesRange -value $xmldata.DSSOE.DSConfiguration.ADRecycleBin.Enable -range ("True","False")) -eq $false)
            {
                Write-DSLog -Level error -Message "Invalid ADRecycleBin.Enabled value - The valid value is either True or False"
                return ($false,'InvalidADRecycleBinEnableValue')
            }
            Else
            {
                Write-DSLog -Level info -Message "ADRecycleBin.Enabled value is successfully validated"
            }

            If($xmldata.DSSOE.DSConfiguration.ADRecycleBin.Enable -ne "False") {            
            
                Write-DSLog -Level Info -Message "Validating the forest functional level requirements for AD Recycle Bin."
                <#If($xmldata.DSSOE.DCPromoOptions.Selected -eq "NewDomainNewForest") {
                    If(!($xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.ForestFunctionalLevel -in ("Windows2008R2Forest","Windows2012Forest","Windows2012R2Forest","Windows2016Forest"))) {
                        Write-DSLog -Level error -Message "Invalid forest functional level. In order to enable AD Recycle Bin the forest functional level has to be Windows2008R2Forest and beyond."
                        return ($false,'InvalidADRecycleBinForestFunctionalLevel')
                    }
                    Else {
                        Write-DSLog -Level Info -Message "AD Recycle Bin forest functional level requirement has been successfully validated"
                    }
                }
            Else {#>
                #Retrieving the forest functional level of the forest
                $DSFFL = Get-DSForestFunctionalLevel -Domain $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.Domain `
                -username $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.Username `
                -password $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.Password
                Write-DSLog -Level Info -Message "Forest functional level of the forest is $DSFFL"
                If(!($DSFFL -in ("4","5","6","7"))) {
                    Write-DSLog -Level error -Message "Invalid forest functional level. In order to enable AD Recycle Bin the forest functional level has to be Windows2008R2Forest and beyond."
                    return ($false,'InvalidADRecycleBinForestFunctionalLevel')
                }
                Else {
                    Write-DSLog -Level Info -Message "AD Recycle Bin forest functional level requirement has been successfully validated"
                }
            #}

            Write-DSLog -Level Info -Message "Validating username and password, specified to enable AD Recycle Bin."
            Write-DSLog -Level Info -Message "The domain name is $($xmldata.DSSOE.DSConfiguration.ADRecycleBin.Domain)"
            If((Test-DSCredentials -ContextType Domain -ContextName $xmldata.DSSOE.DSConfiguration.ADRecycleBin.Domain `
            -UserName $xmldata.DSSOE.DSConfiguration.ADRecycleBin.UserName `
            -Password $xmldata.DSSOE.DSConfiguration.ADRecycleBin.Password) -eq $false)
            {
                Write-DSLog -Level error -Message "Invalid domain name or credentials"
                return ($false,'InvalidADRecycleBinCredentials')
            }
            Else
            {
                Write-DSLog -Level Info -Message "AD Recycle Bin Username and Password is successfully validated"
            }

            Write-DSLog -Level Info -Message "Validating the access rights of the specified credentials"
            Try {
                $GroupStatus = Test-DSGroupMembership -Domain $xmldata.DSSOE.DSConfiguration.ADRecycleBin.Domain `
                -UserName $xmldata.DSSOE.DSConfiguration.ADRecycleBin.Username -Password $xmldata.DSSOE.DSConfiguration.ADRecycleBin.Password `
                -IsEnterpriseAdmins

                If($GroupStatus -eq $true) {
                    Write-DSLog -Level Info -Message "Group membership is successfully validated"
                }
                Else {
                    Write-DSLog -Level error -Message "Group membership validation failed. Specified User is not a member of the Enterprise Admins group. Make sure the specified User account has Enterprise Admin rights to continue with the AD Recycle Bin implementation."
                    return ($false,'UserIsNotEnterpriseAdmins')
                }
            }
            Catch {
                Write-DSLog -Level error -Message "An error occurred while validating the group membership of the user account"
                Write-DSLog -Level error -Message "$($_.Exception.Message)"
                return ($false,'ErrorValidatingEnterpriseAdminRights')
            }

            Write-DSLog -Level Info -Message "Validating the value of ADRecycleBinScope parameter - $($xmldata.DSSOE.DSConfiguration.ADRecycleBin.ADRecycleBinScope)"
            If(!($xmldata.DSSOE.DSConfiguration.ADRecycleBin.ADRecycleBinScope -in ("Domain","ForestOrConfigurationSet"))) {
                Write-DSLog -Level error -Message "Invalid ADRecycleBinScope value. The valid value is Domain or ForestOrConfigurationSet."
                return ($False,'InvalidADRecycleBinScope')
            }
            Else {
                Write-DSLog -Level Info -Message "ADRecycleBinScope is successfully validated"
            }

            Write-DSLog -Level Info -Message "Validating the value of ADRecycleBinTargetServer parameter and its requirements for AD Recycle Bin implementation"
            Write-DSLog -Level Info -Message "ADRecycleBinTargetServer is $($xmldata.DSSOE.DSConfiguration.ADRecycleBin.ADRecycleBinTargetServer)"
            #retrieving the forest info
            $ForestInfo = Get-DSADForest -Domain $xmldata.DSSOE.DSConfiguration.ADRecycleBin.Domain -UserName $xmldata.DSSOE.DSConfiguration.ADRecycleBin.Username `
            -Password $xmldata.DSSOE.DSConfiguration.ADRecycleBin.Password
            
            #splitting the DC FQDN to retrieve the domain name
            $ADRecycleBinTargetServerName = $xmldata.DSSOE.DSConfiguration.ADRecycleBin.ADRecycleBinTargetServer
            $ADRecycleBinTargetServerDomain = $ADRecycleBinTargetServerName.Split(".",2)[1]
            Write-DSLog -Level Info -Message "Domain of the ADRecycleBinTargetServer is $ADRecycleBinTargetServerDomain"
            #caling function to retrieve the list of all the DCs in the given domain name
            $AllDCs = Get-DSADDomainControllers -DomainName ($ADRecycleBinTargetServerDomain)
            Write-DSLog -Level Info -Message "Validating if specified ADRecycleBinTargetServer exists or not"
            If(!($AllDCs -contains $ADRecycleBinTargetServerName)) {
                Write-DSLog -Level error -Message "Invalid ADRecycleBinTargetServer value. The specified DC does not exists"
                return ($false,'InvalidADRecycleBinTargetServer')
            }
            Else {
                Write-DSLog -Level Info -Message "Successfully validated the ADRecycleBinTargetServer parameter value"
            }

            #Validating if specified target server is a domain naming master role holder         
            Write-DSLog -Level Info -Message "Validating if the specified target server is holding the Domain Name Master FSMO role"
            $DomainNamingMasterDC = (Get-DSADForestNamingRoleOwner).Name #retrieving the domain naming role owner
            Write-DSLog -Level Info -Message "Domain naming master of the forest is $DomainNamingMasterDC"
            
            If($DomainNamingMasterDC -ne $xmldata.DSSOE.DSConfiguration.ADRecycleBin.ADRecycleBinTargetServer) {
                Write-DSLog -Level error -Message "Invalid ADRecycleBinTargetServer. The specified server is not a Domain Naming Master role owner."
                return ($false,'InvalidADRecycleBinTargetServerRole')
            }
            Else {
                Write-DSLog -Level Info -Message "Role owner validation of ADRecycleBinTargetServer is successful"
            }
            
            Write-DSLog -Level Info -Message "Validating the ADRecycleBinTargetDomain value - $($xmldata.DSSOE.DSConfiguration.ADRecycleBin.ADRecycleBinTargetDomain)"
            $IsDomainExist = (Test-DSADDomainExists -DomainName $xmldata.DSSOE.DSConfiguration.ADRecycleBin.ADRecycleBinTargetDomain)
            If($IsDomainExist -eq $false) {
                Write-DSLog -Level error -Message "Invalid ADRecycleBinTargetDomain value. The specified domain does not exist."
                return ($false,'InvalidADRecycleBinTargetDomain')
            }
            Else {
                Write-DSLog -Level Info -Message "ADRecycleBinTargetDomain value is successfully validated"
            }
            
            If($xmldata.DSSOE.DSConfiguration.ADRecycleBin.ADRecycleBinScope -eq "ForestOrConfigurationSet") {
                Write-DSLog -Level Info -Message "Since scope is set to ForestOrConfigurationSet, thus Validating if the specified domain name is a root domain or not - $($xmldata.DSSOE.DSConfiguration.ADRecycleBin.ADRecycleBinTargetDomain)"
                #retrieving the root domain name and compare it with the specified value
                If(!($xmldata.DSSOE.DSConfiguration.ADRecycleBin.ADRecycleBinTargetDomain -eq (Get-DSADForestRootDomain))) {
                    Write-DSLog -Level error -Message "Invalid ADRecycleBinTargetDomain value. The specified domain name is not the forest root domain. Since scope is set to ForestOrConfigurationSet, thus the specified domain name should be the name of the root domain name only."
                    return ($false,'InvalidADRecycleBinTargetDomainNotRoot')
                }
                Else {
                    Write-DSLog -Level Info -Message "Validation successful; specified domain is a root domain"
                }
            }
        }
            Else {
                Write-DSLog -Level Info -Message "Option to enable AD Recycle Bin is not choosen by the user."
            }
         }
       
        if($xmldata.DSSOE.DCPromoOptions.Selected -ne "NewDomainNewForest")
        {
        Write-DSLog -Level info -Message "Validating IPAM Access configuration parameter values"
        Write-DSLog -Level info -Message "Validating the value of IPAMAccess.Configure parameter - $($xmldata.DSSOE.DSConfiguration.IPAMAccess.Configure)"
        If((Test-ValuesRange -value $xmldata.DSSOE.DSConfiguration.IPAMAccess.Configure -range ("True","False")) -eq $false)
        {
            Write-DSLog -Level error -Message "Invalid IPAMAccess.Configure value - The valid value is either True or False"
            return ($false,'InvalidIPAMAccessConfigureValue')
        }
        Else
        {
            Write-DSLog -Level info -Message "IPAMAccess.Configure value is successfully validated"
        }

        if($xmldata.DSSOE.DSConfiguration.IPAMAccess.Configure -ne "False")
        {
            if(($xmldata.DSSOE.DSConfiguration.IPAMAccess.IPAMUnivGroup -ne "") -and ($xmldata.DSSOE.DSConfiguration.IPAMAccess.IPAMServer -ne ""))
                {
                $gDomainname,$grpname = $($xmldata.DSSOE.DSConfiguration.IPAMAccess.IPAMUnivGroup).Split("\")
                Write-dslog -level info -message "Validating domain $gdomainname and group $grpname"
                If(((Test-NameValidation -Name $gDomainname -NameType 3) -eq 0) -and ((Test-DSCredentials -ContextType Domain -ContextName $gDomainname -UserName $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.Username -Password $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.Password) -eq $True))
                {        
                    Write-DSLog -Level info -Message "IPAMAccess IPAM Univ group domain value is successfully validated"
                    if((Test-DSObjectExistence -domain $gDomainname -username $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.Username -password $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.Password -Objectname $grpname -Category 'group') -eq $false)
                     {
                        Write-DSLog -Level error -Message "IPAMAccess IPAM Univ group not found in specified domain"
                        return ($false,'InvalidIPAMUnivGroup')
                        }
                        else
                        {
                        Write-DSLog -Level info -Message "IPAMAccess IPAM Univ group value is successfully validated"
                        }
                    }
                    else
                    {
                    Write-DSLog -Level error -Message "Given domain $gDomainname doesn't exist or provided credentials doesn't have rights to access the domain"
                    return ($false,'InvalidIPAMDomain')
                    }
                $srvname,$sDomainname = $($xmldata.DSSOE.DSConfiguration.IPAMAccess.IPAMServer).Split(".",2)
               
                If(((Test-NameValidation -Name $sDomainname -NameType 3) -eq 0) -and ((Test-DSCredentials -ContextType Domain -ContextName $sDomainname -UserName $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.Username -Password $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.Password) -eq $True))
                 {  
                    $srvname = $srvname +"$"       
                    Write-DSLog -Level info -Message "IPAMAccess IPAM server domain value is successfully validated"
                    if((Test-DSObjectExistence -domain $sDomainname -username $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.Username -password $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.Password -Objectname $srvname -Category 'computer') -eq $false)
                     {
                        Write-DSLog -Level error -Message "IPAMAccess IPAM server name not found in specified domain"
                        return ($false,'InvalidIPAMServerName')
                        }
                        else
                        {
                        Write-DSLog -Level info -Message "IPAMAccess IPAM server name is successfully validated"
                        }
                    }
                    else
                    {
                    Write-DSLog -Level error -Message "Given domain $sDomainname doesn't exist or provided credentials doesn't have rights to access the domain"
                    return ($false,'InvalidIPAMDomain')
                    }
            }
            else
            {
            Write-DSLog -Level error -Message "IPAM Univ group and IPAM server name not provided"
            return ($false,'IPAMParametersMissing')
            }
            
        
        }
        Else
        {
         Write-DSLog -Level info -Message "IPAMAccess value is set to false. Hence IPAM access parameters are not validated"
        }
        }
        else
        {
        Write-DSLog -Level Info -Message "NewDomainNewForest installation mode selected, hence skipping ipam access parameter validation"
        }
        
        #ADHealthCheck Validation
         If($xmldata.DSSOE.DCPromoOptions.Selected -eq 'NewDomainNewForest') { # dcpromooptions is newdomainnewforest
             Write-DSLog -Level info -Message "newdomainnewforest build type is selected. Only ADHealtCheck.Execute parameter value will be validated."
             Write-DSLog -Level info -Message "Validating the value of ADHealtCheck.Execute parameter - $($xmldata.DSSOE.DSConfiguration.ADHealtCheck.Execute)"
            If((Test-ValuesRange -value $xmldata.DSSOE.DSConfiguration.ADHealthCheck.Execute -range ("True","False")) -eq $false)
            {
                Write-DSLog -Level error -Message "Invalid ADHealtCheck.Execute value - The valid value is either True or False"
                return ($false,'InvalidADHealtCheckExecuteValue')
            }
            Else
            {
                Write-DSLog -Level info -Message "ADHealtCheck.Execute value is successfully validated"
            }

        }
        else
        {
        Write-DSLog -Level info -Message "Validating AD Healthcheck parameter values for build types other than newdomainnewforest"
        Write-DSLog -Level info -Message "Validating the value of ADHealthCheck.Execute parameter - $($xmldata.DSSOE.DSConfiguration.ADHealthCheck.Execute)"
        If((Test-ValuesRange -value $xmldata.DSSOE.DSConfiguration.ADHealthCheck.Execute -range ("True","False")) -eq $false)
        {
            Write-DSLog -Level error -Message "Invalid ADHealthCheck.Execute value - The valid value is either True or False"
            return ($false,'InvalidADHealthCheckExecuteValue')
        }
        Else
        {
            Write-DSLog -Level info -Message "ADHealthCheck.Execute value is successfully validated"
        }

        if($xmldata.DSSOE.DSConfiguration.ADHealthCheck.Execute -ne 'False')
        {
            if(($xmldata.DSSOE.DSConfiguration.ADHealthCheck.UserName -ne "") -and ($xmldata.DSSOE.DSConfiguration.ADHealthCheck.Password -ne "") -and ($xmldata.DSSOE.DSConfiguration.ADHealthCheck.Domain -ne "") -and ($xmldata.DSSOE.DSConfiguration.ADHealthCheck.DomainsToScan -ne ""))
            {

                if((Set-ADDSForest -domain $xmldata.DSSOE.DSConfiguration.ADHealthCheck.Domain -username $xmldata.DSSOE.DSConfiguration.ADHealthCheck.UserName -password $xmldata.DSSOE.DSConfiguration.ADHealthCheck.Password) -eq $false)
                {
                Write-DSLog -Level error -Message "Unable to connect to the domain $($xmldata.DSSOE.DSConfiguration.ADHealthCheck.Domain) with user account $($xmldata.DSSOE.DSConfiguration.ADHealthCheck.UserName)"
                return ($false,'ADHealthCheckDomainConnectFailed')
                }
                else
                {
                Write-DSLog -Level info -Message "Domain $($xmldata.DSSOE.DSConfiguration.ADHealthCheck.Domain) connection with user account $($xmldata.DSSOE.DSConfiguration.ADHealthCheck.UserName) successfull"
                }

                Try {
                $GroupStatus = Test-DSGroupMembership -Domain $xmldata.DSSOE.DSConfiguration.ADHealthCheck.Domain `
                -UserName $xmldata.DSSOE.DSConfiguration.ADHealthCheck.Username -Password $xmldata.DSSOE.DSConfiguration.ADHealthCheck.Password `
                -IsEnterpriseAdmins

                If($GroupStatus -eq $true) {
                    Write-DSLog -Level Info -Message "Group membership is successfully validated"
                }
                Else {
                    Write-DSLog -Level error -Message "Group membership validation failed. Specified User is not a member of the Enterprise Admins group. Make sure the specified User account has Enterprise Admin rights to perform adhealth check."
                    return ($false,'ADHealthCheckUserIsNotEnterpriseAdmins')
                }
            }
            Catch {
                Write-DSLog -Level error -Message "An error occurred while validating the group membership of the user account"
                Write-DSLog -Level error -Message "$($_.Exception.Message)"
                return ($false,'ADHealthCheckErrorValidatingEnterpriseAdminRights')
            }

                if(Test-ADDSDomainValue -DomainsToScan $xmldata.DSSOE.DSConfiguration.ADHealthCheck.DomainsToScan -eq $true)
                {
                $tempArr = $($xmldata.DSSOE.DSConfiguration.ADHealthCheck.DomainsToScan.ToString()).Split(",")
                foreach($dm in $tempArr)
                    {
                        if(!(Test-ADDSDomainExists -domain $dm))
                        {
                         Write-DSLog -Level error -Message "Invalid Domains to scan $dm parameter provided"
                         return ($false,'ADHealthInvalidDomainstoscan')
                        }
                    }
                
                }
                else
                {
                Write-DSLog -Level error -Message "Invalid Domains to scan $($xmldata.DSSOE.DSConfiguration.ADHealthCheck.DomainsToScan) parameter provided"
                return ($false,'ADHealthInvalidDomainstoscan')
                }


            }
            else
            {
            Write-DSLog -Level error -Message "ADHealthCheck parameters are not provided"
            return ($false,'ADHealthCheckParametersMissing')
            }
        }
        else
        {
        Write-DSLog -Level info -Message "ADHealthCheck execute is set to false. Hence AD Healthcheck parameters are not validated"
        }
       }
    }

    Write-DSLog -Level info -Message "DSSOE XML values are successfully validated"
    return ($true,'DSXMLValidatedSuccessfully')
}


