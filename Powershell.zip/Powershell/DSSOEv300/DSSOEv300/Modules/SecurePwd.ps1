﻿
Param(
[Parameter(ParameterSetName="enc")] [switch] $encrypt,
[Parameter(ParameterSetName="dec")] [switch] $decrypt,
[parameter (mandatory="true")][string[]]$String,
[string]$key = [guid]::newguid().guid.replace('-','')
)

# encrypt given string using given key and return back encrypted string (AES)
# -----------------------------------------------------------------------------
Function Protect-SOEString {
param(
    [parameter (mandatory="true")] [string[]] $String,
    #[string] $Key = [guid]::newGuid().Guid.Replace('-','')
    [string] $Key
)

    # create encryption key that will be used for encryption purposes
    if($key.Length -notin (16,24,32)) {
        Write-Warning "Key length should be either 16 or 24 or 32."
        $null # return null on failure
    }
    $epass = @() # blank array to hold encrypted passwords
    try {
        foreach($s in $String) {
            $keyBytes = [System.Text.Encoding]::UTF8.GetBytes($key)
            $ss = $s | ConvertTo-SecureString -AsPlainText -Force -ErrorAction Stop
            $es = $ss | ConvertFrom-SecureString -Key $keyBytes -ErrorAction Stop
            $epass+= $es # add this pass to array
        }
        [pscustomobject]@{password=$epass;key=$key} # return encrypted string
    }
        
    catch { 
        write-warning $_.exception.message
        $null # return null on error
    }
}

# decrypt given string using given key and return back decrypted string
# ----------------------------------------------------------------------
Function Unprotect-SOEString {
param(
    [parameter (mandatory="true")] [string] $String,
    [parameter (mandatory="true")] [string] $Key
)

    # create encryption key that will be used for encryption purposes
    if($key.Length -notin (16,24,32)) {
        Write-Warning "Key length should be either 16 or 24 or 32."
        $null # return null on failure
    }
    
    try {
        $keyBytes = [System.Text.Encoding]::UTF8.GetBytes($key)
        $ss = $String | ConvertTo-SecureString -Key $keyBytes -ErrorAction Stop
        $bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($ss)
        $pp = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr)
        $pp
    }
    catch { 
        write-warning $_.exception.message
        $null # return null on error
    }
}

#when $action is passed as Encrypt call the protect-soestring function
If($encrypt) {
    Protect-SOEString -String $String -Key $key
}
#when $action is passed as Decrypt, call the unprotect-soestring function
if($decrypt) { 
    Unprotect-SOEString -String $String[0] -Key $key
}
