﻿#region script/module support functions
# This function will return an object that could be used to return values, message 
# and return code from a function to caller. USeful as it can return lot of useful
# information instead of just a return value
# Copyright  : @Platform Wintel SOE, DXC.
# ---------------------------------------------------------------------------------
Function Get-ReturnObject($ReturnCode=0, $Message="Success", $Value="") {
    $outp = '' | Select-Object ReturnCode, Message, Value
    $outp.ReturnCode = $ReturnCode
    $outp.Message = $Message
    $outp.Value = $Value
    return $outp
}
#endregion

#region system and security related functions
# This function checks whether given local user account exist or not
# ------------------------------------------------------------------
Function Test-DSLocalUserExists([string] $UserName) {
    $srv = [ADSI]$srv = "WinNT://$($env:COMPUTERNAME)"
    try {
        $usr = $srv.children | where-object { $_.schemaclassname -eq "user" -and $_.name -eq $UserName }
        if($usr -eq $null) { return $false } else { return $true }
    }
    catch {
        return $false
    }
}

# This function will verify if valid credentials are given and whether user has arespective admin rights
# ------------------------------------------------------------------------------------------------------
Function Test-IsValidCredentials($UserName, $Password, $Domain) {
    $outp = Get-ReturnObject # create an object to hold return items

    # If localhost as domain specified then validate whether given account is local admin
    if(($Domain -eq $env:COMPUTERNAME)) { 
        # test if $userName is local user account, return false if not
        $lacct = Test-DSLocalUserExists -UserName $UserName
        if(-not $lacct) { # this is NOT a local user account
            $outp = Get-ReturnObject -ReturnCode 1 -Value $false -Message "Local user account $UserName does not exist on $env:COMPUTERNAME"
            return $outp
        }

        # $UserName is local account, check if it has local admin rights. Return false if not
        if(-not (Test-IsUserLocalAdmin -UserName $UserName)) {
            $outp = Get-ReturnObject -ReturnCode 2 -Value $false -Message "User $UserName is not a member of local Administrators group on $env:COMPUTERNAME"
            return $outp
        }
        else { # user is local admin
            # validate user credentials now
            $res = Test-DSCredentials -ContextType 'Machine' -ContextName $env:COMPUTERNAME -UserName $UserName -Password $Password
            # construct output object, update it as per credential test results
            $outp = Get-ReturnObject -ReturnCode 0 -Value $res -Message ""
            if($res) { $outp.Message = "Local user $UserName credentials validation successful" }
            else {
                $outp.Message = "Local user $UserName credentials validation failed"
                $outp.ReturnCode = 4
            }
            return $outp # return the output object
        }
    }
    else { # a domain account is specified for credentials validation
        #Write-Verbose "Validating credentials in domain context" -Verbose
        $res = Test-DSCredentials -ContextType 'domain' -ContextName $Domain -UserName $UserName -Password $Password
        
        # construct return object and return it accordingly
        if($res -eq $false) { 
            $outp = Get-ReturnObject -ReturnCode 8 -Value $res -Message "Domain user $UserName credentials validation failed"
        }
        else {
            $outp = Get-ReturnObject -ReturnCode 16 -Value $res -Message "Domain user $UserName credentials validation successful"
        }   
        return $outp # return object
    }
}
#endregion


#region useful script level functions 
# set given property of a given control to specified value based on given condition
# ----------------------------------------------------------------------------------
Function Set-DSControl([object[]]$Control, $Property, $Value, $When) {
    if($When) { 
        foreach($c in $Control) { $c.$Property = $Value }
    }
}

# This function will return an array of supported domain functional level
# based on given forest function level
# todo: remove this function..its replaced with Get-DSSupportedDomainModes in ADFromWorkgroup.psm1
# -----------------------------------------------------------------------
Function Get-DSDomainFunctionalLevels($ForestFunctionalLevel) {
    $dfl = ("Windows Server 2003","Windows Server 2008","Windows Server 2008 R2","Windows Server 2012","Windows Server 2012 R2")
    Switch($ForestFunctionalLevel) {
        "Windows Server 2003" { $dfl = $dfl }
        "Windows SErver 2008" { $dfl = $dfl[1..4] }
        "Windows Server 2008 R2" { $dfl = $dfl[2..4] }
        "Windows Server 2012" { $dfl = $dfl[3..4] }
        "Windows Server 2012 R2" { $dfl = @($dfl[4]) } # ensure it is array as well
    }
    return $dfl # reutrn supported domain functional levels
}


# this function will check whether this system is configured as per DSSOE Static IP addressing requirements
# There should be only one NIC with static IP configured on it. Returns type of ipconf on the server
# ----------------------------------------------------------------------------------------------------------
Function Test-DSIPConfigType { 
    $ifs = @(Get-WmiObject Win32_NetworkAdapter | Where-Object { 
        $_.PhysicalAdapter -eq $true -and $_.NetEnabled -eq $true})
    
    # unlikely to match below condition if Test-DSServferIPConfig is used
    if($ifs.Count -ge 2) { return 'multiple_nics' }
    if($ifs.Count -eq 0) { return 'no_nic' }

    # get available nic details
    $nic = Get-WmiObject Win32_NetworkAdapterConfiguration | Where-Object {
        $_.InterfaceIndex -eq $ifs[0].InterfaceIndex }
    
    # check if there are more than one IP assigned to this interface
    if($nic.IPAddress.Count -gt 1) { return 'multiple_ip_assigned' }
    if($nic.IPAddress.Count -eq 0) { return 'no_ip_assigned' }
    if($nic.IPAddress[0].StartsWith('169.254')) { return 'apipa_ip' }

    # identify whether this interface has static or dhcp ip configured
    if($nic.DHCPEnabld) { return 'dhcp' } else { return 'static' }
}

# this function will check and return whether the server has any interface configured with DHCP IP
# -------------------------------------------------------------------------------------------------
Function Test-DSServerHasDHCPIP([switch] $ReturnDHCPInterfaceIndexes) {
    $ifArray = @() # blank array to store interface indexes of those with dhcp config
    $hasDhcp = $false # indicate none of adapters has dhcp ip configured
    $ifs = @(Get-WmiObject Win32_NetworkAdapter | Where-Object { $_.PhysicalAdapter -eq $true -and $_.NetEnabled -eq $true})
    foreach($intf in $ifs) {
        # get network confif object of current interface only if it is IPEnabled (interface like hyper-v virtual switch are not IPEnabled!)
        $nic = Get-WmiObject Win32_NetworkAdapterConfiguration | Where-Object { $_.InterfaceIndex -eq $intf.InterfaceIndex -and $_.IPEnabled -eq $true }
        if($nic.DHCPEnabled) { $hasDhcp = $true; $ifArray+= ($intf.InterfaceIndex) } # this interface has dhcp ip configured!
    }
    # return what user want - array of dhcp indexes or whether at least one interface has dhcp ip
    if($ReturnDHCPInterfaceIndexes) { return $ifArray } else { return $hasDhcp } 
}

# This function will return an array of detected physical network adapters along with their status
# updated 29-feb-16 to add filter - return only those NICs that are TCP/IP networking enabled
# -------------------------------------------------------------------------------------------------
Function Get-DSNetworkAdapters {
    # Create a hash table of network adapters connection status
    $htNetConnectStatus = @{
        0 = "Disconnected"; 1 = "Connecting"; 2 = "Connected"; 3 = "Disconnecting"; 4 = "Hardware not present";
        5 = "Hardware disabled"; 6 ="Hardware malfunction"; 7 = "Media disconnected"; 8 = "Authenticating";
        9 = "Authentication succeeded"; 10 = "Authentication failed"; 11 = "Invalid address";
        12 = "Credentials required"
    }
  
    #get a list of all physical adapters
    $netAdapters = Get-WmiObject Win32_NetworkAdapter | Where-Object { $_.PhysicalAdapter -eq $true -and $_.NetEnabled -eq $true} 

    # Extract required details along with textual status and return the same
    $adaptersInfo = @($netAdapters | Select-Object @{Name='Status';Expression={
        $htNetConnectStatus.Item([int]$_.NetconnectionStatus)}}, NetconnectionStatus, NetConnectionID, Name, MACAddress, 
        InterfaceIndex | Sort-Object Status)
    
    return $adaptersInfo # return the filtered object
}

# This function will add given list of network adapters to given UI contral (list/combo)
# --------------------------------------------------------------------------------------
Function Add-DSNetAdaptersToUIControl($ContralName, $NetworkAdaptersList) {
    # Loop thru each network adapter found and add them to the dropdown list
    $NetworkAdaptersList | ForEach-Object {
        $cbi = new-Object Windows.Controls.ComboBoxItem
        #$cbi.Content = $_.Status + " : " + $_.Name + " (MAC " +  $_.MACAddress + ")"
        $cbi.Content = $_.Status + " : " + $_.NetConnectionID + " (MAC " +  $_.MACAddress + ")"
        $cbi.Tag = $_.InterfaceIndex
        if($_.NetconnectionStatus -ne 2) { $cbi.IsEnabled = $false }
        $ContralName.Items.Add($cbi) | Out-Null # discard output as it shows on powershell window, the index where item was added
    }
}

# Function to check if given network interface has a valid IP Address set
# ------------------------------------------------------------------------
Function Test-DSAdapterHasValidIP($AdapterIndex) {
    $i = (Get-WmiObject Win32_NetworkAdapterConfiguration | Where-Object {$_.InterfaceIndex -eq $AdapterIndex})
    if($i.IPAddress.Count -ne 0 -and $i.IPSubnet.Count -ne 0) { return $true } else { return $false }
}

# This function will validate given subnet mask and return an object (mask, isvalid)
# -----------------------------------------------------------------------------------
Function Test-IPSubnetMask($IPMask) {
    # Common subnet mask values
    $common = '0|128|192|224|240|248|252|254|255'
               
    # Build a regular expression to represent all possible mask strings
    $masks = @(
            "(^($common)\.0\.0\.0$)"
            "(^255\.($common)\.0\.0$)"
            "(^255\.255\.($common)\.0$)"
            "(^255\.255\.255\.($common)$)"
    )
               
    # Join all possible strings with the regex "or" operator
    $regex = [string]::Join('|', $masks)

    # Evaluate the IPMask input and output the result
    [regex]::Match($IPMask, $regex) | Select @{name='IPMask' ; expression={$IPMask}}, @{name='Valid' ; expression={$_.Success}}
}

# This function will display a customized dialog box with given message
# using it instead of winforms dialog due to issues with lostfocus event and dialog display
# (it keeps looping in message show and event trigger)
# ------------------------------------------------------------------------------------------
Function Show-DSDialog($Message) {
     [xml]$x = @'
    <Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Name="frmValidationWarning" Width="474" Height="200" Margin="0,5,0,0"
        AllowsTransparency="False" Background="{DynamicResource {x:Static SystemColors.ControlBrushKey}}"  
        FontFamily="Segoe UI" Topmost="True"
        FontSize="16" Foreground="Black" ResizeMode="NoResize" WindowStartupLocation="CenterScreen" 
        Title="DSSOE GUI Installer" SizeToContent="Height">
         <WrapPanel> 
            <Image Margin="12,4,4,4"
                Name="Image1"
                Stretch="None"
                Source="/WpfApplication1;component/Images/Warning.ico" />
            
            <TextBlock Name="tbMessage"
                Margin="8,8,8,6" FontSize="14" FontWeight="Normal" Width="370"
                Text="Message" TextWrapping="Wrap" HorizontalAlignment="Stretch" Foreground="Black"
                VerticalAlignment="Top" />
      
             <Button Content="_OK"
                Margin="367,18,0,8" 
                HorizontalAlignment="Right" 
                HorizontalContentAlignment="Center" VerticalContentAlignment="Center"
                IsDefault="True"
                Name="btnOK"
                VerticalAlignment="Top"
                Width="75" Height="32" /> </WrapPanel>
        
    </Window> 
'@
    $reader2=(New-Object System.Xml.XmlNodeReader $x) 
    $frmWarning=[Windows.Markup.XamlReader]::Load( $reader2 ) 
    #$frmWarning.FindName("frmValidationWarning").Margin = "0,400,0,0"
    $frmWarning.add_MouseDoubleClick({ $frmWarning.Close() })
    #$frmWarning.add_KeyUp({ $frmWarning.Close() })
    $frmWarning.add_MouseLeftButtonDown({ $frmWarning.DragMove() })
    $frmWarning.FindName("btnOK").add_Click({ $frmWarning.Close();return})
    
    $frmWarning.FindName("Image1").Source = "File://$($PSScriptRoot)\..\dsui\warning.ico"

    # Update textblock with user specified message
    $frmWarning.FindName("tbMessage").Text = $Message
    $frmWarning.ShowDialog() | Out-Null 
}
#endregion

#region hardware summary display related functions
# This function will return 1 line hardware summary
# -------------------------------------------------
function Get-HardwareSummary {
    $v = Get-WmiObject Win32_ComputerSystem
    $v = $v.Manufacturer.Split(" ")[0] + " " + $v.Model #re-use same variable to store vendor and model info
    $pc = @(Get-WmiObject Win32_Processor).Count.ToString() + " Processors" #Processor count
    $m = [Math]::Round(((gwmi win32_PhysicalMemory) | Measure-Object -Property Capacity -sum).Sum/1gb,2) # round to 2 decimals
    
    #$d = @(Get-PhysicalDisk).Count
    $d = @(Get-WmiObject win32_diskDrive).Count
    if($d -eq 0) { $d = "No Disk" } else {$d = $d.ToString() + " Disks" }

    return $v + " | " + $pc + " | " + $m + "GB Memory" + " | " + $d
}

# This function wil present you with 'browse for folder' dialog and return selected folder (or null if not selected)
# credit: http://powershell.com/cs/media/p/627.aspx
# ------------------------------------------------------------------------------------------------------------------
function Select-DSFolder($message='Select a folder', $path = 0) {

if((Get-OSInstallMode -shortname) -eq 'Core')
    {
        [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.VisualBasic") | Out-null
        $out = [Microsoft.VisualBasic.interaction]::Inputbox("Enter the location of installation media to be used to create the domain controller and configure AD DS","Install from media","C:\")
        if ($out.Length -ne 0)
        {
            if(($out.IndexOfAny([System.io.path]::GetInvalidPathChars()) -eq -1) -and ($out.Length -ge 3) -and (Test-path $out -PathType Container))
            {
            return $out
            }
            else
            {
            [System.Windows.Forms.MessageBox]::Show("Invalid path '$out'.","DSSOE GUI Installer","OK","Error") | Out-Null
            return $null
            }
        }
        else
        {
        return $null
        }
    }
    else
    { 
    $object = New-Object -comObject Shell.Application  
    $folder = $object.BrowseForFolder(0, $message, 0, $path) 
    if ($folder -ne $null) { 
        return $folder.self.Path 
    } 
    else { return $null }
    }  
}
#endregion
