﻿# DSSOE Post promotion related tasks script
# Apply DSSOE post promotion tasks to new DC build, based on promotion option specified
# Author: Umesh Thakur, Tarun Rajvanshi, ArunKumar Bavirisetti
# Update Date  : 21-March-2017
# 22-feb-16: Added Start-DSCleanup function to remove temp DSSOE files at end of build
# Copyright  : @Platform Wintel SOE, DXC.
# --------------------------------------------------------------------------------------
param(
    [string]$DSInstallMode = 'standard',
    [string]$AnswerFile,
    [string]$PassKey,
    [string]$ExportUnattendBuildFileTo
) 

#region script level functions goes here
# function to remove unwanted files once build process is complete
# ----------------------------------------------------------------
function Start-DSCleanup {
    # remove auto-gen xml file if parametr based install was performed
    $axml = @(Get-ChildItem -Path $LogPath\dssoe-*.xml -ErrorAction SilentlyContinue)
    foreach($xd in $axml) { Remove-Item -Path $xd.fullname -Force } # remove forcibly

    # remove dspost launcher
    if([System.IO.File]::Exists('c:\support\Logs\dssoe\dspost.cmd')) { 
        Remove-Item -Path 'c:\support\Logs\dssoe\dspost.cmd' -Force
    }
}

# function to export DSSOE build XML file to user given location
# --------------------------------------------------------------
function Export-DSSOEBuildXML {    
    Add-Indent -Header "enter -> Export-DSSOEBuildXML" # increase indent in log file    
    if($ExportUnattendBuildFileTo) {
        $dsselected = $xmldata.DSSOE.DCPromoOptions.Selected
        $xmldata.DSSOE.DCPromoOptions.$dsselected.Password = "******"
        $xmldata.DSSOE.DCPromoOptions.$dsselected.SafeModeAdminPassword = "******"
        $xmldata.Save($AnswerFile)
        Write-DSLog -Level info -Message "[dspost] User has provided parameter to export DSSOE Build XML file"
        Write-DSLog -Level info -Message "[dspost] Trying to export DSSOE Build XML file to $ExportUnattendBuildFileTo"
        try {
            Copy-Item -Path $AnswerFile -Destination $ExportUnattendBuildFileTo -Force
            Write-DSLog -Level info -Message "[dspost] Successfully exported DSSOE Build XML file to $ExportUnattendBuildFileTo"
        }
        catch {
            Write-DSLog -Level error -Message "[dspost] Failed to export DSSOE Build XML file to $ExportUnattendBuildFileTo"
            Write-DSLog -Level error -Message $_.Exception.Message
        }
    }
    Remove-Indent -Footer "exit -> Export-DSSOEBuildXML" # decrease indent in log file
}
#endregion

#region pre-requisites check and ensure all conditions to launch this script are met
#importing all the DSSOE modules
Import-Module "$PSScriptRoot\LogCallerPref.psm1" -Force
Import-Module "$PSScriptRoot\DSLogger.psm1" -Force
Import-Module "$PSScriptRoot\DSUtils.psm1" -Force
Import-Module "$PSScriptRoot\DSValidate.psm1" -Force
Import-Module "$PSScriptRoot\DSImplement.psm1" -Force
Import-Module "$PSScriptRoot\AD_Healthcheck.psm1" -Force

# call verbose writing functions
Set-CallerVerbosePreference
Set-CallerDebugPreference
#endregion Validate And Load DSSOE Modules

#region change verbose message background
((Get-Host).PrivateData).VerboseBackgroundColor =($host.UI.RawUI).BackGroundColor;
#endregion

#region Set log path to static location C:\Support\Logs\DSSOE
$LogPath = "C:\Support\Logs\DSSOE"
#endregion

#region create the logpath folder, set log file path & start the logging
#checking if logfile folder C:\Support\Logs\DSSOE exists; create if it does not
If(-not (Test-Path $LogPath)) {
    New-Item -ItemType Directory -Path $LogPath -Force | Out-Null
}

[string] $DSLogFile = "$($LogPath)\dssoe-post-$((Get-Date).ToString('MMddyyyy-hhmmss')).log"
#calling functions from the dslogger.psm1 module
Set-DSLogFile -LogPath $DSLogFile
# script name as log header
Write-DSLog -Level info -Message "[$($PSCommandPath.Split('\')[-1])]" 
Write-DSLog -Level info -Message "DSSOE script logging started" 
#endregion create the logpath folder, set log file path & start the logging

# try to load the xml file into a variable
Write-DSLog -Level info -Message "[dspost] Trying to load DSSOE answer file $AnswerFile"
try {
    [xml]$xmldata = Get-Content -Path $AnswerFile
    Write-DSLog -Level info -Message "[dspost] answer file loaded successfully"
}
catch {
    Write-DSLog -Level error -Message "[dspost] Error reading answer file $AnswerFile.`n$($error[0].exception.message)"
    return 'ds_answerfile_load_error'
    exit
}


#region creds related checks misc
$selectedDCPromoOption = $xmldata.DSSOE.DCPromoOptions.Selected
$xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.Password = (Unprotect-SOEString -string $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.Password -key $PassKey)
    $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.SafeModeAdminPassword = (Unprotect-SOEString -string $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.SafeModeAdminPassword -key $PassKey)
    if($xmldata.DSSOE.DCPromoOptions.Subnet.Password.Length -gt 0) { $xmldata.DSSOE.DCPromoOptions.Subnet.Password = (Unprotect-SOEString -string $xmldata.DSSOE.DCPromoOptions.Subnet.Password -key $PassKey) }
    If($xmldata.DSSOE.DSConfiguration.ADRecycleBin.Password.Length -gt 0) { $xmldata.DSSOE.DSConfiguration.ADRecycleBin.Password = (Unprotect-SOEString -string $xmldata.DSSOE.DSConfiguration.ADRecycleBin.Password -key $PassKey) }
    If($xmldata.DSSOE.DSConfiguration.ADHealthCheck.Password.Length -gt 0) { $xmldata.DSSOE.DSConfiguration.ADHealthCheck.Password = (Unprotect-SOEString -string $xmldata.DSSOE.DSConfiguration.ADHealthCheck.Password -key $PassKey) }
#endregion

#region Test If User Is Admin or not
# checking if script is running with administrative privileges; calling function from dsutils.psm1
If((Test-IsCurrentUserAdmin) -eq $false) {
    Write-DSLog -level error -message "[dspost] The script has not ran with administrative privileges (elevated powershel window). Re-run the script again with administrative privileges. Terminating DSSOE."
    return 'dspost_no_admin_privileges'
    Exit
}
#endregion Test If User Is Admin or not

#region Verify that this server is built using a valid supported SOE
# checking if running on a server built using Windows Server SOE
If((Test-WindowsSOEVersion) -ne $true) {
    Write-DSLog -Level error -Message "[dspost] The Operating System on this sever was detected to not have been provisioned using a supported DXC SOE. DSSOE does not support non-SOE provisioned servers. Please ensure the server has been prepared using the latest supportable Windows Server SOE and POST-SOE production patching has been applied prior to running the DS-SOE. Running the DS-SOE without the core baseline OS configuration provided by the Windows Server SOE will result in a non-standard Domain Controller subject to a diminished security posture and Best Effort Support. If you need to proceed with this, obtain approval from your Cybersecurity Account Security Manager and contact Platform_Wintel_SOE@csc.com for more information."
    return 'dspost_not_soe'
    Exit
}
Else {
    Write-DSLog -Level info -Message "[dspost] Windows SOE Version is successfully validated"
}
#endregion Verify that this server is built using a valid supported SOE

#region Validating if the baseline operating system is supported by DSSOE or not
# The DSSOE 3.0.0 supported operating systems are Windows Server 2016
#using get-osversion function from DSUtils.psm1 module to retrieve the version of the operating system
If(-not((Get-OSVersion) -in ("6.1","6.2","6.3","10.0"))) {
    Write-DSLog -Level error -Message "[dssoe] The baseline operating system is not supported by this version of DSSOE. DSSOE program is terminating. For more information contact platform_wintel_soe@csc.com."
    return 'ds_unsupported_os'
    Exit
}
#endregion Validating if the baseline operating system is supported by DSSOE or not
#endregion

#Removes startup command and autologon entry in registry
    Remove-DSAutoLogon
    Remove-DSPostRunEntry -EntryName "DSSOE Post Promotion Tasks"
    Write-DSLog -Level info -Message "[dspost] Cleared post run entry and autologon in regsitry"
    Write-DSLog -Level info -Message "[dspost] Checking for running status of AD dependent services with a timeout of 1 minute"
    #AD + dependent services to load fully and write progress on screen
    #Arraylist with service names
    [system.collections.arraylist]$serviceArr = @("NTDS","DFSR","IsmServ","Kdc","ADWS","gpsvc","Netlogon","RpcEptMapper","RpcSs","LanmanServer","LanmanWorkstation")
    [system.collections.arraylist]$removeSer = @()
    $timeout = New-TimeSpan -Minutes 1
    $sw = [Diagnostics.stopwatch]::StartNew()
    do
    {
        foreach($service in $serviceArr)
        {
            if((get-service -Name $service).Status -eq 'Running')
            {
            $removeSer.Add($service) | Out-Null
            }
        }
        $removeSer | % {$serviceArr.Remove($_)}
        $removeSer.Clear()
        $count = $serviceArr.count
        $percentage = [math]::Round(((11-$count)/11) * 100)
        $message = "Waiting for Active Directory services to load"
        Write-Progress -Activity $message  -PercentComplete $percentage
        sleep -Seconds 1
 
    }
    while(($sw.Elapsed -lt $timeout) -and ($count -ne 0))
    $sw.Stop()
    if($count -ne 0)
    {
    Write-Warning "Timeout:Dependent services failed to start."
    }

# start script processing
if($DSInstallMode -eq 'express') {
    # perform DS verification only
    Write-DSLog -Level info -Message "[dspost] Build option is Express Install."
    
    #try block to load AD module and check AD connectivty, exit if fails
    Write-DSLog -Level info -Message "[dspost] Validating the domain bind"
    try {
        Import-Module activedirectory -ErrorAction Stop
        $domaininfo = Get-ADDomain -Server $(hostname) -ErrorAction Stop
        Write-DSLog -Level info -Message "[dspost] Loaded active directory module and found domain: $($domaininfo.Name)"
    }
    catch {
        Write-DSLog -Level error -Message "[dspost] Unable to find AD domain: $($error[0].exception.message)" -Verbose
        #Enable UAC
        Set-ItemProperty -Path HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\system -Name EnableLUA -Value 1 -Force -ErrorAction SilentlyContinue
        Write-DSLog -Level info -Message "[dspost] Enabled user account control"

        # added by umesh 22-feb-16: call cleanup function (declared at top) to remove temp items
        Write-DSLog -Level info -Message "[dspost] Calling start-dscleanup function to remove temp items, such as Auto-generated XML answer file and dspost batch file used for launching post promo tasks" 
        Start-DSCleanup
        Write-DSLog -Level info -Message "[dspost] Terminating the script"
        return 'ds_domain_not_found'
        exit
    }
    
    <#Write-DSLog -Level info -Message "[dspost] Adding the DFS management tools for SYSVOL folder replication management" -Verbose
    $OSInstallMode = (Get-OSInstallMode -ShortName)
    Write-DSLog -Level info -Message "[dspost] The server operating system install mode is $OSInstallMode"
    If($OSInstallMode -in ("Core","Nano","Minshell")) {
        Write-DSLog -Level info -Message "[dspost] Since the OS install mode is $OSInstallMode, thus DFS Management Console will not be installed." -Verbose
    }
    Else {
        Write-DSLog -Level info -Message "[dspost] OS install mode is $OSInstallMode. Adding DFS Management console."
        Add-DFSTools #Adding the DFS management tool for sysvol folder replication management
    }#> 
    #Removed DFS mgmt tools installation, dsrepair mode and hotfix installation in express mode 21-02-2107 :Arun
    
    # set registry branding 
    Write-DSLog -Level info -Message "[dspost] Calling function to set the DSSOE registry branding" -Verbose
    Add-DSRegistrySignature

    Write-DSLog -Level info -Message "[dspost] Creating C:\Support\DSSOE directory"
    New-Item -Path 'c:\support\DSSOE' -ItemType directory -Force # target for AD scripts
    $ADScriptsPath = $(split-path -path $PSScriptRoot) + "\ADAutomationScripts"
    Write-DSLog -Level info -Message "[dspost] Copying AD automation scripts folder to C:\support\DSSOE" -Verbose
    Invoke-Copy -source $ADScriptsPath -destination "C:\support\DSSOE" #copy ad scripts folder to c:\support\DSSOE

    for($i=1;$i -lt 10; $i++) {
        if(Test-DSSetup) {
            Write-DSLog -Level info -Message "[dspost] All the tests are successful"
            #Enable UAC
            Set-ItemProperty -Path HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\system -Name EnableLUA -Value 1 -Force -ErrorAction SilentlyContinue
            Write-DSLog -Level info -Message "[dspost] Enabled UAC"
            Write-DSLog -Level info -Message "[dspost] Calling function to save the AD replication Status to a text file" -Verbose
            Save-ADReplicationStatus -ADReplFilePath "C:\support\logs\dssoe\ADReplStatus.txt"  #Saving AD repication status to a file
            Write-DSLog -Level info -Message "[dspost] DSSOE Program Completed successfully" 
            Write-Host "DSSOE Program Completed successfully" -ForegroundColor Green

            # export DSSOE build xml file if user has specified to do so
            Export-DSSOEBuildXML

            # added by umesh 22-feb-16: call cleanup function (declared at top) to remove temp items
            Write-DSLog -Level info -Message "[dspost] Calling start-dscleanup function to remove temp items, such as Auto-generated XML answer file and dspost batch file used for launching post promo tasks" 
            Start-DSCleanup

            do{
                Write-host "Press 'Y' key to exit"
                $x = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeydown")
            }while($x.character -ne 'y')
            exit
        }
        else {
            Start-Sleep -Seconds 60
        }
    }

    Write-DSLog -Level error -Message "[dspost] DSSOE Program Completed with timeout." "Netlogon and Sysvol not shared even after 10 minutes of reboot. Please check."
    #Enable UAC
    Set-ItemProperty -Path HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\system -Name EnableLUA -Value 1 -Force -ErrorAction SilentlyContinue
    Write-DSLog -Level info -Message "Enabled UAC"
    # export DSSOE build xml file if user has specified to do so
    Export-DSSOEBuildXML

    # added by umesh 22-feb-16: call cleanup function (declared at top) to remove temp items
    Write-DSLog -Level info -Message "[dspost] Calling Start-DSCleanup function to remove temp items, such as Auto-generated XML answer file and dspost batch file used for launching post promo tasks" 
    Start-DSCleanup
    do{
                Write-host "Press 'Y' key to exit"
                $x = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeydown")
            }while($x.character -ne 'y')
    exit
    
}

# if 'standard' dssoe promotion option was selected, corresponding post processing will go here
if($DSInstallMode -eq 'standard') {
    # call post-promotion functions for standard setup
    Write-DSLog -Level info -Message "[dspost] Build option is Standard Install."
       
    #try block to load AD module and check AD connectivty, exit if fails
    Write-DSLog -Level info -Message "[dspost] Validating the domain bind"
    try {
        Import-Module activedirectory -ErrorAction Stop
        $domaininfo = Get-ADDomain -Server $(hostname) -ErrorAction Stop
        Write-DSLog -Level info -Message "[dspost] Loaded active directory module and found domain: $($domaininfo.Name)"
    }
    catch {
        Write-DSLog -Level error -Message "[dspost] Unable to find AD domain: $($error[0].exception.message)"
        #Enable UAC
        Set-ItemProperty -Path HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\system -Name EnableLUA -Value 1 -Force -ErrorAction SilentlyContinue
        Write-DSLog -Level info -Message "[dspost] Enabled UAC"
        Write-DSLog -Level info -Message "[dspost] Calling start-dscleanup function to remove temp items, such as Auto-generated XML answer file and dspost batch file used for launching post promo tasks" 
        Start-DSCleanup
        Write-DSLog -Level info -Message "[dspost] Terminating the script"
        return 'ds_domain_not_found'
        exit
    }

    #Adding backup feature in server manager for server 2008 R2
   If($xmldata.DSSOE.DSConfiguration.DSBackup.Configure -ne "false")
  {
    if(Test-OSIsWindowsServer2008R2) {
    Write-DSLog -Level info -Message "[dspost] Installing server manager backup feature for Windows Server 2008 R2" -Verbose
        try {
            Import-Module ServerManager -ErrorAction SilentlyContinue
            if($(Add-WindowsFeature Backup-Tools).Success) {
                Add-PsSnapin Windows.ServerBackup -ErrorAction Stop
                Write-DSLog -Level info -Message "[dspost] Succesfully added Backup feature" -Verbose
            }
            else {
                Write-DSLog -Level error -Message "[dspost] Failed adding backup feature" -Verbose
            }
        }
        catch {
            Write-DSLog -Level error -Message "[dspost] Failed adding backup feature, error: $($error[0].exception.message)" -Verbose
        }
    }

    
    #Adding backup feature in server manager for server 2012/2012R2
    if((Test-OSIsWindowsServer2012) -or (Test-OSIsWindowsServer2012R2) -or (Test-OSIsWindowsServer2016)){ 
    Write-DSLog -Level info -Message "[dspost] Installing server manager backup feature" -Verbose
        if($(Add-WindowsFeature Windows-server-backup).Success) {     
            Write-DSLog -Level info -Message "[dspost] Succesfully added Backup feature" -Verbose
        }
        else {    
            Write-DSLog -Level error -Message "[dspost] Failed adding backup feature" -Verbose
        }
    }
}

    Write-DSLog -Level info -Message "[dspost] Adding the DFS management tools for SYSVOL folder replication management" -Verbose
    $OSInstallMode = (Get-OSInstallMode -ShortName)
    Write-DSLog -Level info -Message "[dspost] The server operating system install mode is $OSInstallMode"
    If($OSInstallMode -in ("Core","Nano","Minshell")) {
        Write-DSLog -Level info -Message "[dspost] Since the OS install mode is $OSInstallMode, thus DFS Management Console will not be installed." -Verbose
    }
    Else {
        Write-DSLog -Level info -Message "[dspost] OS install mode is $OSInstallMode. Adding DFS Management console."
        Add-DFSTools #Adding the DFS management tool for sysvol folder replication management
    }

    if($xmldata.DSSOE.DSConfiguration.ConfigureDSRM -eq 'True')
    {
    Write-DSLog -Level info -Message "[dspost] calling function to configure the directory services repair mode option on the startup menu" -Verbose
    Set-DSRepairMode #configure the directory services repair mode option on the startup menu
    }

    #Configuring external time server parameters
    if($xmldata.DSSOE.DSConfiguration.ExternalTimeServer.Name -ne "")
    {
        Write-DSLog -Level info -Message "[dspost] Calling function to configure external time server" -Verbose
        Set-DSExternalTimeServer -TimeServerName $xmldata.DSSOE.DSConfiguration.ExternalTimeServer.Name
    }

    #Move the computer object to location specified in xml file
    if(($xmldata.DSSOE.DSConfiguration.DCOULocation.OU -ne 'default') -and ($xmldata.DSSOE.DSConfiguration.DCOULocation.OU -ne "") -and ($xmldata.DSSOE.DCPromoOptions.Selected -eq "AdditionalDC") -and ($xmldata.DSSOE.DCPromoOptions.AdditionalDC.RODC -eq "false"))
    {
        $Targetpath = $xmldata.DSSOE.DSConfiguration.DCOULocation.OU
        Set-DSDCOULocation -TargetPath $Targetpath
        Write-DSLog -Level info -Message "[dspost] Moved the computer object to OU: $Targetpath"
    }

    #Configure GPO based on user input
    Write-DSLog -Level info -Message "[dspost] Configuration of group policies" -Verbose
    If($xmldata.DSSOE.DCPromoOptions.Selected -ne "AdditionalDC") {
        if(($xmldata.DSSOE.DSConfiguration.SecurityBaselinePolicies.ConfigureDomainPolicy -eq "True") -and ($xmldata.DSSOE.DSConfiguration.SecurityBaselinePolicies.ConfigureDomainControllerPolicy -eq "True")){
            Write-DSLog -Level info -Message "[dspost] User opted to configure both the policies"
            Set-DSBaseLineGPOs -DCPromoOptionsSelected -ConfigureDomainPolicy -ConfigureDomainControllerPolicy
        }
        elseif(($xmldata.DSSOE.DSConfiguration.SecurityBaselinePolicies.ConfigureDomainPolicy -eq "True") -and ($xmldata.DSSOE.DSConfiguration.SecurityBaselinePolicies.ConfigureDomainControllerPolicy -eq "False")){
            Write-DSLog -Level info -Message "[dspost] User opted to configure only Domain policy"
            Set-DSBaseLineGPOs -DCPromoOptionsSelected -ConfigureDomainPolicy
        }
        elseif(($xmldata.DSSOE.DSConfiguration.SecurityBaselinePolicies.ConfigureDomainPolicy -eq "False") -and ($xmldata.DSSOE.DSConfiguration.SecurityBaselinePolicies.ConfigureDomainControllerPolicy -eq "True")){
            Write-DSLog -Level info -Message "[dspost] User opted to configure only Domain controller policy"
            Set-DSBaseLineGPOs -DCPromoOptionsSelected -ConfigureDomainControllerPolicy
        }
        elseif(($xmldata.DSSOE.DSConfiguration.SecurityBaselinePolicies.ConfigureDomainPolicy -eq "False") -and ($xmldata.DSSOE.DSConfiguration.SecurityBaselinePolicies.ConfigureDomainControllerPolicy -eq "False")){
            Write-DSLog -Level info -Message "[dspost] User have not opted to configure group policies"
        }
    }

    #Creation of OU structure as per DXC standards if not Additional DC
    
    If($xmldata.DSSOE.DCPromoOptions.Selected -ne "AdditionalDC")
    {
        If(($xmldata.DSSOE.DSConfiguration.OUStructure.AccountType -eq "") -and ($xmldata.DSSOE.DSConfiguration.OUStructure.AccountCode -eq "")) 
        {
                Write-DSLog -Level info -Message "The parameters for OU structure creation are not specified, thus this configuration will not be implemented"
                New-Item -Path "C:\support\logs\dssoe\noou.txt" -ItemType file -Force | Out-Null #this temporary file is being created to identify if uer not opted for ou creation and will be reported in wincompliance
        }    
       else
       {       
         Write-DSLog -Level info -Message "[dspost] Calling function to create OU structure" -Verbose
         if(($xmldata.DSSOE.DSConfiguration.OUStructure.AccountType -eq "MultiTenant") -and ($xmldata.DSSOE.DSConfiguration.OUStructure.ADDelegation -eq "True"))
         {
            Set-DSCustomerOUStructure -AccountType $xmldata.DSSOE.DSConfiguration.OUStructure.AccountType -AccountCode $xmldata.DSSOE.DSConfiguration.OUStructure.AccountCode -ADDelegation
            Write-DSLog -Level info -Message "[dspost] Created OU structure and AD delegation as per user request" -Verbose
         }
         else
         {
         Set-DSCustomerOUStructure -AccountType $xmldata.DSSOE.DSConfiguration.OUStructure.AccountType -AccountCode $xmldata.DSSOE.DSConfiguration.OUStructure.AccountCode
         Write-DSLog -Level info -Message "[dspost] Created Standard or Multitenant OU structure without delegation" -Verbose
         }
       }
    }

    #Calling Backup configuration function
    Write-DSLog -Level info -Message "[dspost] Calling function for backup and maintenance" -Verbose
    If($xmldata.DSSOE.DSConfiguration.DSBackup.Configure -ne "false"){
        if($xmldata.DSSOE.DSConfiguration.DSBackup.EnableBackupMaintenance -eq "True"){
            Set-DSBackupConfiguration -EnableBackupMaintenance -BackupVolumePath $xmldata.DSSOE.DSConfiguration.DSBackup.BackupVolumePath
            Write-DSLog -Level info -Message "[dspost] Successfully configured backup and maintenance" -Verbose
        }
        else{
            Set-DSBackupConfiguration -BackupVolumePath $xmldata.DSSOE.DSConfiguration.DSBackup.BackupVolumePath
            Write-DSLog -Level info -Message "[dspost] Successfully configured backup" -Verbose
        }
    }
    else {
        Write-DSLog -Level info -Message "[dspost] The backup configuration is chosen as false, thus standard backup and maintenance task will not be configured."
    }

    #Creation of Bulk users if in case user has provided an input file
    if($xmldata.DSSOE.DSConfiguration.CreateADUsers.UserListExcelFile -ne "") {
        if($xmldata.DSSOE.DCPromoOptions.Selected -eq "AdditionalDC" -and $xmldata.DSSOE.DCPromoOptions.AdditionalDC.RODC -eq "True") {
            Write-DSLog -Level info -Message "[dspost] Server is selected to be an RODC. Since RODC is a read-only copy of AD database, thus bulk user creation cannot happen. Skipping the bulk user creation."
        }
        else {
            Write-DSLog -Level info -Message "[dspost] Calling function to create users in bulk based on input file" -Verbose
            New-DSCreateADUsers -ExcelPath $xmldata.DSSOE.DSConfiguration.CreateADUsers.UserListExcelFile
        }
    }
    Else { Write-DSLog -Level info -Message "[dspost] Create AD users in bulk is not chosen for configuration" }

    #Calling BPA report generation
    Write-DSLog -Level info -Message "[dspost] calling function to generate BPA report" -Verbose
    Set-DSBPAReport -HTMLReportPath "C:\support\Logs\DSSOE\BPA Reports"
        <#If($xmldata.DSSOE.DCPromoOptions.Selected -ne "AdditionalDC"){
            Write-DSLog -Level info -Message "[dspost] calling function to generate BPA report with all severeties" -Verbose
            Set-DSBPAReport -HTMLReportPath "C:\support\Logs\DSSOE\BPA Reports" -ReportAllSevereties
        }
        else{
            Write-DSLog -Level info -Message "[dspost] calling function to generate BPA report" -Verbose
            Set-DSBPAReport -HTMLReportPath "C:\support\Logs\DSSOE\BPA Reports"
        }#>
    

     #Calling DNS scaveneging function
    if($xmldata.DSSOE.DSConfiguration.ConfigDNSScavenging -eq 'True')
    {   
    $dnsstate = (Get-WindowsFeature -Name dns).InstallState
    if($dnsstate -eq 'Installed')
    {
    Write-DSLog -Level info -Message "[dspost] DNS role installed on server"
    If($xmldata.DSSOE.DCPromoOptions.Selected -eq "NewDomainNewForest"){
        Write-DSLog -Level info -Message "[dspost] calling function to configure dns scavenging with NewDomainNewForest" -Verbose
        Set-DSDNSScavenging -NewDomainNewForest
    }
    else {
        if($xmldata.DSSOE.DCPromoOptions.Selected -ne "AdditionalDC") {
            Write-DSLog -Level info -Message "[dspost] calling function to configure dns scavenging" -Verbose
            Set-DSDNSScavenging
        }
        Else {
            Write-DSLog -Level info -Message "[dspost] DNS scavenging is not allowed on Additonal DCs." -Verbose
        }
     }
   }
    else {
        Write-DSLog -Level info -Message "[dspost] DNS role not installed on server, skipping dns scavenging"
    }
  }
#$selectedDCPromoOption = $xmldata.DSSOE.DCPromoOptions.Selected
#Calling site configuration function
If(($xmldata.DSSOE.DCPromoOptions.Selected -ne "NewDomainNewForest") -and ($xmldata.dssoe.DCPromoOptions.Subnet.Association -ne "false")){
    Write-DSLog -Level info -Message "[dspost] calling function to perform site to subnet association configuration for DCPromo types other than new forest" -Verbose
    #$xmldata.dssoe.DCPromoOptions.Subnet.Password = (Get-DSPassCode -Code $xmldata.dssoe.DCPromoOptions.Subnet.Password -PassKey $PassKey)
    #$xmldata.dssoe.DCPromoOptions.Subnet.Password = (Unprotect-SOEString -String $xmldata.dssoe.DCPromoOptions.Subnet.Password -Key $PassKey).ToString()
    Set-NewSubnetSiteAssociation -domain $xmldata.dssoe.DCPromoOptions.Subnet.Domain -username $xmldata.dssoe.DCPromoOptions.Subnet.EntAdminUserName -password $xmldata.dssoe.DCPromoOptions.Subnet.Password -subnetmask $xmldata.dssoe.DCPromoOptions.Subnet.SubnetMask -sitename $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.ADSiteName
}
elseif($xmldata.DSSOE.DCPromoOptions.Selected -eq "NewDomainNewForest"){
    Write-DSLog -Level info -Message "[dspost] calling function to perform site to subnet association configuration for new domain new forest" -Verbose
    Set-SiteSubnetAssociation -Sitename "Default-First-Site-Name"
}

#Calling function to configure DNS forwarders
if(($xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.InstallDNS -ne "False") -and ($xmldata.DSSOE.DSConfiguration.DNSForwarders.ForwardersIP -ne ""))
{
    Write-DSLog -Level info -Message "[dspost] calling function to configure DNS forwarders "
    Set-DSDNSForwarders -ForwardersIP $xmldata.DSSOE.DSConfiguration.DNSForwarders.ForwardersIP
}

Write-DSLog -Level info -Message "[dspost] Calling function to set the DSSOE registry branding" -Verbose
# set registry branding 
Add-DSRegistrySignature

Write-DSLog -Level info -Message "[dspost] Calling function save the server's configuration in a text file for inventory purposes." -Verbose
#Save AD config
Save-ADServerConfig -ADConfigFilePath "C:\Support\Logs\dssoe\ADServerConfig.txt"

#Calling function to configure static ports
If($xmldata.DSSOE.DSConfiguration.StaticPort.Configure -ne "false")
 {
 Write-DSLog -Level info -Message "[dspost] calling function to configure AD static ports" -Verbose
 Set-DSStaticPorts -ADReplicationPort $xmldata.DSSOE.DSConfiguration.StaticPort.ADReplicationPort -NetlogonPort $xmldata.DSSOE.DSConfiguration.StaticPort.NetLogonPort -DFSRPort $xmldata.DSSOE.DSConfiguration.StaticPort.DFSRReplicationPort
 #-NetlogonPort $xmldata.DSSOE.DSConfiguration.StaticPort.NetLogonPort -FRSPort $xmldata.DSSOE.DSConfiguration.StaticPort.FRSReplicationPort `

 }
 Else { Write-DSLog -Level info -Message "[dspost] AD Static port configuration is set to false, thus the static ports will not be configured." }

 #calling function to enable AD recycle bin
 #if newdomainnewforest build was selected
 If($xmldata.DSSOE.DCPromoOptions.Selected -eq 'NewDomainNewForest') {
    Write-DSLog -Level info -Message "[dspost] build type is newdomainnewforest"
    If($xmldata.DSSOE.DSConfiguration.ADRecycleBin.Enable -eq "true") { # AD recycle bin 'enable' parameter is true
        Write-DSLog -Level info -Message "[dspost] ADRecycleBin.Enable parameter is true"
        $ADRecycleBinTarSrv = "$($env:COMPUTERNAME).$($xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.NewDomainFQDN)"
        Write-DSLog -Level info -Message "[dspost] decrypting the password"
        #$xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.Password = (Unprotect-SOEString -String $xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.Password -Key $PassKey).ToString()
        Write-DSLog -Level info -Message "[dspost] calling function to enable AD Recycle Bin" -Verbose
        Enable-DSADRecycleBin -Username $xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.UserName -Password $xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.Password `
        -Domain $xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.NewDomainFQDN -ADRecycleBinScope 'ForestOrConfigurationSet' `
        -ADRecycleBinTargetServer $ADRecycleBinTarSrv -ADRecycleBinTargetDomain $xmldata.DSSOE.DCPromoOptions.NewDomainNewForest.NewDomainFQDN
    }
    else {
        Write-DSLog -Level info -Message "[dspost] AD recycle bin 'enable' parameter is set to false. AD Recycle Bin will not be enabled."     
    }
 }
 Else { #build type is other than newdomainnewforest
    Write-DSLog -Level info -Message "[dspost] build type is other than newdomainnewforest"   
     If(($xmldata.DSSOE.DSConfiguration.ADRecycleBin.Enable -eq "true") -and ($xmldata.DSSOE.DCPromoOptions.AdditionalDC.RODC -ne "True")) { #enable parameter is true
        Write-DSLog -Level info -Message "[dspost] calling function to enable AD Recycle Bin"
        Write-DSLog -Level info -Message "[dspost] decrypting the password"
        #$xmldata.DSSOE.DSConfiguration.ADRecycleBin.Password = (Unprotect-SOEString -String $xmldata.DSSOE.DSConfiguration.ADRecycleBin.Password -Key $PassKey).ToString()
        Enable-DSADRecycleBin -Username $xmldata.DSSOE.DSConfiguration.ADRecycleBin.UserName -Password $xmldata.DSSOE.DSConfiguration.ADRecycleBin.Password `
        -Domain $xmldata.DSSOE.DSConfiguration.ADRecycleBin.Domain -ADRecycleBinScope $xmldata.DSSOE.DSConfiguration.ADRecycleBin.ADRecycleBinScope `
        -ADRecycleBinTargetServer $xmldata.DSSOE.DSConfiguration.ADRecycleBin.ADRecycleBinTargetServer `
        -ADRecycleBinTargetDomain $xmldata.DSSOE.DSConfiguration.ADRecycleBin.ADRecycleBinTargetDomain
     }
     Else {
        If($xmldata.DSSOE.DCPromoOptions.AdditionalDC.RODC -ne "False") {
            Write-DSLog -Level info -Message "[dspost] RODC is selected, AD Recycle Bin implementation will be skipped."
        }
        Else {
            Write-DSLog -Level info -Message "[dspost] AD Recycle Bin is set to False, thus it will not be enabled."
        }
     }
 }


#Calling function to configure IPAM access
 If($xmldata.DSSOE.DSConfiguration.IPAMAccess.Configure -eq "True")
 {
    if($xmldata.DSSOE.DCPromoOptions.Selected -ne "NewDomainNewForest")
    {
        If($xmldata.DSSOE.DCPromoOptions.AdditionalDC.RODC -ne "True") {
            if($dnsstate -eq "Installed") {
            Write-DSLog -Level info -Message "[dspost] calling function to configure IPAM access" -Verbose
            Set-DSIPAMConfig -group $xmldata.DSSOE.DSConfiguration.IPAMAccess.IPAMUnivGroup -server $xmldata.DSSOE.DSConfiguration.IPAMAccess.IPAMServer
            }
            else {
            Write-DSLog -Level error -Message "[dspost] DNS role not found, thus IPAM access will not be configured."
            }
        }
        Else {
            Write-DSLog -Level info -Message "[dspost] Since RODC option has been selected, the IPAM configuration will be skipped."
        }
    }
    else
    {
    Write-DSLog -Level info -Message "[dspost] NewDomainNewForest installation mode detected, thus IPAM access will not be configured."
    }
 }
 else
 {
 Write-DSLog -Level info -Message "[dspost] IPAM access configure is set to false, thus it will not be configured."
 }

 
$Disclaimer = "`"`"`"The built-in Administrator Account i.e. SOE-LOAD, must not be used beyond the Forest / Domain build process. It is strongly recommended to disable the SOE-LOAD account after setting a complex password on it. SOE-LOAD should only be revived and used if in case administrator want to reboot the DC in DSRM mode. For AD configuration beyond this point create new accounts in Active Directory and delegate Domain Admin or Enterprise Admin rights (should be rarely used) as appropriate. Setup new accounts with appropriate previleges and delegated rights for day to day administrative tasks. It should be noted that not all tasks needs Domain Admin or Enterprise Admin rights and hence it is imperative to delegate rights wisely. `n`r`n`r`n`r As an administrator of the Active Directory Environment we highly recommend to make yourself aware of Pass the Hash (PtH) Attacks & Other Credential Thefts and their mitigation practices (http://www.microsoft.com/en-in/download/details.aspx?id=36036)`"`"`""
Write-DSLog -Level info -Message $Disclaimer #Disclaimer message written to the log

# copy AD automation scripts to C:\SUPPORT\DSSOE folder
Write-DSLog -Level info -Message "[dspost] Creating C:\Support\DSSOE directory"
New-Item -Path 'c:\support\DSSOE' -ItemType directory -Force # target for AD scripts
$ADScriptsPath = $(split-path -path $PSScriptRoot) + "\ADAutomationScripts"
Write-DSLog -Level info -Message "[dspost] Copying AD automation scripts folder to C:\support\DSSOE" -Verbose
Invoke-Copy -source $ADScriptsPath -destination "C:\support\DSSOE" #copy ad scripts folder to c:\support\DSSOE

#Calling function to check setup installation status
for($i=1;$i -lt 10; $i++)
{
  if(Test-DSSetup)
  {
      Write-DSLog -Level info -Message "[dspost] All the tests are successful"

      #if(Test-OSIsWindowsServer2012R2) 14-Jan (Tarun) removed it as OS verification is not being done in the install-dshotfix function itself
      #{
      Write-DSLog -Level info -Message "[dspost] Calling function to install Hotfix.Refer C:\support\logs\dssoe\hotfix.log for hotfix installation status" -Verbose
      #Calling function to install DS hotfix
      if($xmldata.DSSOE.DSConfiguration.InstallADHotfixes -eq 'True')
      {
      Install-DSHotfix -Hotfixlogpath "C:\SUPPORT\Logs\DSSOE\hotfix.log" 
      }
      #}

      
      #Enable UAC
      Set-ItemProperty -Path HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\system -Name EnableLUA -Value 1 -Force -ErrorAction SilentlyContinue
      Write-DSLog -Level info -Message "[dspost] Enabled UAC"
      
      Write-DSLog -Level info -Message "[dspost] Calling function to save the AD replication Status to a text file" -Verbose
      Save-ADReplicationStatus -ADReplFilePath "C:\support\logs\dssoe\ADReplStatus.txt"  #Saving AD repication status to a file

            
      Write-DSLog -Level info -Message "[dspost] DSSOE Program Completed successfully"
      Write-Host "DSSOE Program Completed successfully" -ForegroundColor Green
      
      

      #Calling WinCompliance - region start
      $wincompath = "$(split-path $PSScriptRoot)\ADHealthCheck\WinCompliance"
      if(Test-Path $wincompath -PathType Container)
      {
          Write-DSLog -Level info -Message "[dspost] Found wincompliance folder, Calling wincompliance script" -Verbose
          
          $winCmd = "`'$winCompath\WCReportGen.ps1`' -BaseLineFile `'$winCompath\baseline\DSSOE\DSSOE300.xml`' -ShowGUIReport"
          if($xmldata.DSSOE.DSConfiguration.ADHealthCheck.Execute -eq 'True')
          {
          Write-DSLog -Level info -Message "[dspost] ADHealthCheck execute is true. Calling AD health check with wincompliance"
          #$xmldata.DSSOE.DSConfiguration.ADHealthCheck.Password = (Unprotect-SOEString -String $xmldata.DSSOE.DSConfiguration.ADHealthCheck.Password -Key $PassKey).ToString()
          #$xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.Password = (Unprotect-SOEString -String $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.Password -Key $PassKey).ToString()
              if($xmldata.DSSOE.DCPromoOptions.Selected -ne "NewDomainNewForest")
              {
              Write-DSLog -Level info -Message "[dspost] calling function to set ad forest"
              $obj = Set-ADDSForest -domain $xmldata.DSSOE.DSConfiguration.ADHealthCheck.Domain -username $xmldata.DSSOE.DSConfiguration.ADHealthCheck.Username -password $xmldata.DSSOE.DSConfiguration.ADHealthCheck.Password
              Write-DSLog -Level info -Message "[dspost] calling function to create inventory xml file"
              $invpath = Set-ADWCInventory -domainstoscan $xmldata.DSSOE.DSConfiguration.ADHealthCheck.DomainsToScan
              Write-DSLog -Level info -Message "[dspost] calling function to create report path folder structure"
              $ret = set-reportpath -domainsToScan $xmldata.DSSOE.DSConfiguration.ADHealthCheck.DomainsToScan #folder creation for saving html output
              }
              else
              {
              Write-DSLog -Level info -Message "[dspost] calling function to set ad forest"
              $obj = Set-ADDSForest -domain $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.NewDomainFQDN -username $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.Username -password $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.Password
              Write-DSLog -Level info -Message "[dspost] calling function to create inventory xml file"
              $invpath = Set-ADWCInventory -domainstoscan $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.NewDomainFQDN
              Write-DSLog -Level info -Message "[dspost] calling function to create report path folder structure"
              $ret = set-reportpath -domainsToScan $xmldata.DSSOE.DCPromoOptions.$selectedDCPromoOption.NewDomainFQDN #folder creation for saving html output
              }
          
          $winCmd = "$winCmd -CollectInventory -InventoryConfigFile `'$invpath`'"
          }
          $winCmd = "& $winCmd"
          Invoke-Expression -command $winCmd
      }
      else {
        Write-DSLog -Level error -Message "[dspost] WinCompliance folder not found"
      }
      #Wincompliance - region end
      
      # export DSSOE build xml file if user has specified to do so
      Export-DSSOEBuildXML

      # added by umesh 22-feb-16: call cleanup function (declared at top) to remove temp items
      Write-DSLog -Level info -Message "[dspost] Calling start-dscleanup function to remove temp items, such as Auto-generated XML answer file and dspost batch file used for launching post promo tasks" 
      Start-DSCleanup

      If($xmldata.DSSOE.DSConfiguration.StaticPort.Configure -ne "false"){
      if($AnswerFile -like "*dssoe-gui*"){
        Write-DSLog -Level info -Message "[dspost] Static port configuration selected, restart required"
        Write-Host "You must restart the server to apply the changes" -ForegroundColor Red
        }
        else{
        Write-DSLog -Level info -Message "[dspost] Static port configuration selected, restart required"
        Shutdown -r -t 10 /c "DSSOE Setup need to restart this server to complete installation. This server will restart in 10 seconds."    
        }      
      }

      
      do{
                Write-host "Press 'Y' key to exit"
                $x = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeydown")
            }while($x.character -ne 'y')
      exit
  }
  else
  {
    Start-Sleep -Seconds 60
  }

}
  
  

  Write-DSLog -Level error -Message "[dspost] DSSOE Program Completed with timeout." "Netlogon and Sysvol not shared even after 10 minutes of reboot. Please check."
  #Enable UAC
  Set-ItemProperty -Path HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\system -Name EnableLUA -Value 1 -Force -ErrorAction SilentlyContinue
  Write-DSLog -Level info -Message "[dspost] Enabled UAC"

  # export DSSOE build xml file if user has specified to do so
  Export-DSSOEBuildXML
  
  # added by umesh 22-feb-16: call cleanup function (declared at top) to remove temp items
  Write-DSLog -Level info -Message "[dspost] Calling start-dscleanup function to remove temp items, such as Auto-generated XML answer file and dspost batch file used for launching post promo tasks" 
  Start-DSCleanup

  If($xmldata.DSSOE.DSConfiguration.StaticPort.Configure -ne "false"){
  if($AnswerFile -like "*dssoe-gui*"){
  Write-DSLog -Level info -Message "[dspost] Static port configuration selected, restart required"
  Write-Host "You must restart the server to apply the changes" -ForegroundColor Red
  }
  else{
    Write-DSLog -Level info -Message "[dspost] Static port configuration selected, restart required"
    Shutdown -r -t 10 /c "DSSOE Setup need to restart this server to complete installation. This server will restart in 10 seconds."    
  }}

 
  Write-Host "DSSOE Program Completed with timeout." "Netlogon and Sysvol not shared even after 10 minutes of reboot. Please check." -ForegroundColor Red
  do{
                Write-host "Press 'Y' key to exit"
                $x = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeydown")
            }while($x.character -ne 'y')
  exit
}