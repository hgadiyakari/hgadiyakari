﻿<# 
.SYNOPSIS   
    This script is used to create a  progress bar 
.DESCRIPTION   
    This script uses a Powershell Runspace to create and manage a WPF progress bar that can be manipulated to show 
    script progress and details.  There are no arguments for this script because it is just an example of how this can be done.   
    The components within the script are what's important for setting this up for your own purposes. 
.NOTES   
    Version        : 2.0 
    Author        : Marc R Kellerman 
    Email        : mkellerman@outlook.com   
    Credit Due    : Rhys Edwards & Boe Prox wrote in detail about this method of using runspaces and forms, I just applied it to  
                  a very common problem 
    Link        : https://gallery.technet.microsoft.com/scriptcenter/New-ProgressBar-8468da5c/view/Discussions#content 
#> 

# Modified by Umesh to make it marquee type progress bar with ability to just updates messages. Added more comments
# 02-feb-2015

function Test-PSPWin2K8R2OS {
    if((Get-WmiObject -Class win32_operatingSystem).Version.StartsWith('6.1')) { return $true } else { return $false }
}
# This function will show a WPF window that hsows a marquee progress bar with given text
# --------------------------------------------------------------------------------------
Function Show-ProgressWindow($Activity="Please wait while task is being processed", $Status="Processing task") { 
    if((Test-PSPWin2K8R2OS)) { return } # exit on w2k8r2 as it has issue on this OS
    [void][System.Reflection.Assembly]::LoadWithPartialName('presentationframework') 
    $global:syncHash = [hashtable]::Synchronized(@{}) 
    $global:newRunspace =[runspacefactory]::CreateRunspace() 
    $newRunspace.ApartmentState = "STA" 
    $newRunspace.ThreadOptions = "ReuseThread"           
    $newRunspace.Open() 
    $newRunspace.SessionStateProxy.SetVariable("syncHash",$syncHash)           
    $newRunspace.SessionStateProxy.SetVariable("newRunspace",$newRunspace)           
    $global:psCmd = [PowerShell]::Create().AddScript({    
    [xml]$xaml = @" 
    <Window 
        xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" 
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml" 
        x:Name="Window" Title="Please wait..." WindowStartupLocation = "CenterScreen" 
        Width="539.906" Height="122.075" ShowInTaskbar="True" Topmost="True">
    <Grid>
        <ProgressBar x:Name="ProgressBar"
                     Width="512"
                     Height="9"
                     Margin="10,10,0,0"
                     HorizontalAlignment="Left"
                     VerticalAlignment="Top"
                     Background="#FFDBDBDB"
                     BorderBrush="#FFDBDBDB"
                     BorderThickness="0"
                     IsIndeterminate="True"
                     Opacity="0.7">
            <ProgressBar.Foreground>
                <LinearGradientBrush MappingMode="RelativeToBoundingBox" StartPoint="0.5,0" EndPoint="0.5,1">
                    <GradientStop Offset="0" Color="#FF2F95CF" />
                    <GradientStop Offset="1" Color="#FF0C35A2" />
                </LinearGradientBrush>
            </ProgressBar.Foreground>
        </ProgressBar>
        <Label x:Name="Label1"
               Width="512"
               Height="30"
               Margin="10,24,0,0"
               HorizontalAlignment="Left"
               VerticalAlignment="Top"
               Content=""
               FontSize="16"
               Padding="2" />
        <Label x:Name="Label2"
               Width="512"
               Height="30"
               Margin="10,54,0,0"
               HorizontalAlignment="Left"
               VerticalAlignment="Top"
               Content=""
               FontSize="16"
               Padding="2"
               RenderTransformOrigin="0.5,0.5" />
    </Grid>
    </Window>  
"@ 
  
        $reader=(New-Object System.Xml.XmlNodeReader $xaml) 
        $syncHash.Window=[Windows.Markup.XamlReader]::Load( $reader ) 
 
        $syncHash.IsClosed = $False 
        $syncHash.Error = $Error 
 
        $syncHash.ProgressBar = $syncHash.Window.FindName("ProgressBar") 
        $syncHash.Label1 = $syncHash.Window.FindName("Label1") 
        $syncHash.Label2 = $syncHash.Window.FindName("Label2") 
        $syncHash.Window.Add_Closing( { If ($syncHash.IsClosed -ne $True) { $_.Cancel = $True; $syncHash.IsClosed = $True; } } )  
        $syncHash.Window.ShowDialog() | Out-Null 
    }) 
    $psCmd.Runspace = $newRunspace 
    $data = $psCmd.BeginInvoke() 
    While (!($syncHash.Window.IsInitialized)) { Start-Sleep -Milliseconds 100 }
    Set-ProgressControls -Label1 $Activity -Label2 $Status 
 
} # End Function Load-Window 
 
# This function will update given control's given property with given value
# --------------------------------------------------------------------------
Function Update-Window { 
    Param ( 
        $Control, 
        $Property, 
        $Value, 
        [switch]$AppendContent 
    ) 
    if((Test-PSPWin2K8R2OS)) { return $False } # exit on w2k8r2 as it has issue on this OS
    $syncHash.IsRunning = $true 
    If ($newRunspace.RunspaceStateInfo.State -ne 'Opened') { Return $False } 
 
    # User is closing the window. 
    If ($syncHash.IsClosed) { $Property = "Close" } 
 
    # This is kind of a hack, there may be a better way to do this 
    If ($Property -eq "Close") { 
        $syncHash.IsClosed = $True 
        If($PSVersionTable.PSVersion.Major -eq 2) { 
          $Global:syncHash.$Control.Dispatcher.invoke(“Normal”,[action]{ $Global:syncHash.Window.Close() }) 
        } Else { 
          $Global:syncHash.Window.Dispatcher.invoke([action]{ $Global:syncHash.Window.Close() },"Normal") 
        } 
 
        $newRunspace.Close() 
        Return $False 
    } 
   
    # This updates the control based on the parameters passed to the function 
    If (($Control) -and ($Property) -and ($Value)) { 
        If($PSVersionTable.PSVersion.Major -eq 2) { 
            $Global:syncHash.$Control.Dispatcher.invoke(“Normal”,[action]{  
            If ($PSBoundParameters['AppendContent']) { $syncHash.$Control.AppendText($Value) }  
                                                Else { $syncHash.$Control.$Property = $Value } 
            }) 
        } Else { 
            $Global:syncHash.Window.Dispatcher.invoke([action]{  
            If ($PSBoundParameters['AppendContent']) { $syncHash.$Control.AppendText($Value) }  
                                                Else { $syncHash.$Control.$Property = $Value } 
            },"Normal") 
        } 
 
    } 
 
    Return $True 
 
} # End Function Update-Window 
 
# This function will close the progress window
# --------------------------------------------
Function Close-ProgressWindow { 
    if((Test-PSPWin2K8R2OS)) { return } # exit on w2k8r2 as it has issue on this OS
    Update-Window Window Close | Out-Null 
} # End Function Close-Window 
 
# This function will set activity/status labels value
# ----------------------------------------------------
Function Set-ProgressControls($Label1, $Label2) {
    if((Test-PSPWin2K8R2OS)) { return } # exit on w2k8r2 as it has issue on this OS
    If ($Label1) { $Result = Update-Window Label1 Content $Label1 } 
    If ($Label2) { $Result = Update-Window Label2 Content $Label2 } 
}