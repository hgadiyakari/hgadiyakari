#!/bin/bash
sudo yum remove -y falcon-sensor