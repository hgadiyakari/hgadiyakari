﻿<#
=========================================================================================================================
Required - Powershell Version 5.1, Powershell Azure module 5.0.0
=========================================================================================================================
AUTHOR:  Harika Gadiyakari
DATE:    18/7/2019
Version: 1.0
Documentation: 
=========================================================================================================================
.SYNOPSIS
This script is meant to Migrate from Crowdstrike to symantec CWP for all qualified Windows and Linux VMs in a specified Resource Group of provided subscription. 

It collects all the running VMs, checks if they have the Symantec CWP extension installed, if no - install the Symantec CWP and Uninstall the Crowdstrike extension if installed, if yes - skip installation of symantec CWP amd UnInstall the Crowdstrike Extension if installed.

Important Note : "BulkMaintenanceToken, DomainIDforWindows, CustomerIDforWindows, ClientIDforWindows, CustomerSecretKeyforWindows, ClientSecretKeyforWindows, DomainIDforLinux, CustomerIDforLinux, CustomerSecretKeyforLinux " are the secret names for the respective values stored in the given key vault.

.PARAMETER CustomerSubscriptionID
Specify a valid Customer SubscriptionID where the Resource Group is located.

.PARAMETER ResourceGroupName
Specify a valid Resource Group Name where the target VMs are located.

.PARAMETER VaultName
Specify a Key Vault Name where the secret are saved.

.PARAMETER AllVMs
Specify this parameter, if you want run the script on both Windows & Linux VMs.

.PARAMETER WindowsVMs
Specify this parameter, if you want run the script only on Windows VMs.

.PARAMETER LinuxVMs
Specify this parameter, if you want run the script only on Linux VMs.

.PARAMETER BulkMaintenanceToken
Specify the secreat name of BulkMaintenance Token for Crowdstrike to Uninstall Crowstrike extension for Windows VMs.

.PARAMETER DomainIDforWindows
Specify the screat name of DomainIDforWindows required for Symantec CWP extension installation on Windows VMs.

.PARAMETER CustomerIDforWindows
Specify the screat name of CustomerIDforWindows required for Symantec CWP extension installation on Windows VMs.

.PARAMETER ClientIDforWindows
Specify the screat name of ClientIDforWindows required for Symantec CWP extension installation on Windows VMs.

.PARAMETER ClientSecretKeyforWindows
Specify the screat name of ClientSecretKeyforWindows required for Symantec CWP extension installation on Windows VMs.

.PARAMETER CustomerSecretKeyforWindows
Specify the screat name of CustomerSecretKeyforWindows required for Symantec CWP extension installation on Windows VMs.

.PARAMETER DomainIDforLinux
Specify the screat name of DomainIDforLinux required for Symantec CWP extension installation on Linux VMs.

.PARAMETER CustomerIDforLinux
Specify the screat name of CustomerIDforLinux required for Symantec CWP extension installation on Linux VMs.

.PARAMETER CustomerSecretKeyforLinux
Specify the screat name of CustomerSecretKeyforLinux required for Symantec CWP extension installation on Linux VMs.

.EXAMPLE
To run the script on all VMs in the resource group, run the following command .\CStoCWPMigration.ps1 -CustomerSubscriptionID <Subscription ID> -ResourceGroupName <Name of your ResourceGroup> -VaultName <Name of the KeyVault> -AllVMs -BulkMaintenanceToken <Secret name for BulkMaintenanceToken> -DomainIDforWindows <Secret name for DomainIDforWindows> -CustomerIDforWindows <Secret name for CustomerIDforWindows> -ClientIDforWindows <Secret name for DomainIDforWindows> -CustomerSecretKeyforWindows <Secret name for CustomerSecretKeyforWindows> -ClientSecretKeyforWindows <Secret name for ClientSecretKeyforWindows> -DomainIDforLinux <Secret name for DomainIDforLinux> -CustomerIDforLinux <Secret name for CustomerIDforLinux> -CustomerSecretKeyforLinux <Secret name for CustomerSecretKeyforLinux>

To run the script on Windows VMs in the resource group, run the following command .\CStoCWPMigration.ps1 -CustomerSubscriptionID <Subscription ID> -ResourceGroupName <Name of your ResourceGroup> -VaultName <Name of the KeyVault> -WindowsVMs -BulkMaintenanceToken <Secret name for BulkMaintenanceToken> -DomainIDforWindows <Secret name for DomainIDforWindows> -CustomerIDforWindows <Secret name for CustomerIDforWindows> -ClientIDforWindows <Secret name for DomainIDforWindows> -CustomerSecretKeyforWindows <Secret name for CustomerSecretKeyforWindows> -ClientSecretKeyforWindows <Secret name for ClientSecretKeyforWindows>

To run the script on linux VMs in the resource group, run the following command .\CStoCWPMigration.ps1 -CustomerSubscriptionID <Subscription ID> -ResourceGroupName <Name of your ResourceGroup> -VaultName <Name of the KeyVault> -LinuxVMs -DomainIDforLinux <Secret name for DomainIDforLinux> -CustomerIDforLinux <Secret name for CustomerIDforLinux> -CustomerSecretKeyforLinux <Secret name for CustomerSecretKeyforLinux>
#>
#=========================================================================================================================
[CmdletBinding(DefaultParametersetName='AllVMs')]
param(
    [Parameter(Mandatory=$true)][String]$CustomerSubscriptionID,
    [Parameter(Mandatory=$true)][String]$ResourceGroupName,
    [Parameter(Mandatory=$true)][String]$VaultName,
    [Parameter(ParameterSetName="AllVMs")][switch]$AllVMs,
    [Parameter(ParameterSetName="Windows")][switch]$WindowsVMs,
    [Parameter(ParameterSetName="Linux")][switch]$LinuxVMs,
    [Parameter(ParameterSetName="Windows", Mandatory=$true)][Parameter(ParameterSetName="AllVMs", Mandatory=$true)][String]$BulkMaintenanceToken,
    [Parameter(ParameterSetName="Windows", Mandatory=$true)][Parameter(ParameterSetName="AllVMs", Mandatory=$true)][string]$DomainIDforWindows,
    [Parameter(ParameterSetName="Windows", Mandatory=$true)][Parameter(ParameterSetName="AllVMs", Mandatory=$true)][string]$CustomerIDforWindows,
    [Parameter(ParameterSetName="Windows", Mandatory=$true)][Parameter(ParameterSetName="AllVMs", Mandatory=$true)][string]$ClientIDforWindows,
    [Parameter(ParameterSetName="Windows", Mandatory=$true)][Parameter(ParameterSetName="AllVMs", Mandatory=$true)][string]$CustomerSecretKeyforWindows,
    [Parameter(ParameterSetName="Windows", Mandatory=$true)][Parameter(ParameterSetName="AllVMs", Mandatory=$true)][string]$ClientSecretKeyforWindows,    
    [Parameter(ParameterSetName="Linux", Mandatory=$true)][Parameter(ParameterSetName="AllVMs", Mandatory=$true)][string]$DomainIDforLinux,
    [Parameter(ParameterSetName="Linux", Mandatory=$true)][Parameter(ParameterSetName="AllVMs", Mandatory=$true)][string]$CustomerIDforLinux,
    [Parameter(ParameterSetName="Linux", Mandatory=$true)][Parameter(ParameterSetName="AllVMs", Mandatory=$true)][string]$CustomerSecretKeyforLinux
    
)

#========================================================================================================================
#Function for creating and writing to log file
#========================================================================================================================
Function Write-Log($logText){
    $logFile = "$PSscriptroot\ReplacingCSwithCWP.log"
    If(!(Test-Path $logFile)){New-Item -Path $logFile -ItemType File -Force}
    Out-File -FilePath ($logFile) -InputObject ("[" + (Get-Date).ToString("MM-dd-yyyy HH:mm:ss") + "] " + $logText) -Append -Encoding ascii
    Write-Host $logText -ForegroundColor Yellow
}

#========================================================================================================================
# CHECK ENVIRONMENT FOR Powershell Version 5.1 and for AZ modules
#========================================================================================================================
Write-Log "INFORMATION: Checking for Powershell 5.1 and AZ Modules."
$PSVersion= "5.1"
IF ((($PSVersionTable.psversion.major) + ($psversiontable.PSVersion.Minor)/10) -ge $PSVersion)
        {
        Write-Log "INFORMATION: Powershell $PSVersion or higher found. "
        } 
    else 
        {
        Write-Log "WARNING: Powershell $PSVersion or higher is required, please exit and install the latest version."
        Exit
	    }
IF ((Get-Module -ListAvailable Az.Accounts) -and (Get-Module -ListAvailable Az.Resources)) 
{ Write-Log "INFORMATION: AZ Modules are installed."}
    else
{
        Write-Log "WARNING: Powershell AZ Modules are required, please exit and install them."
        Exit
	    }

#==========================================================================================================================
#validating windowsCSUninstall.ps1 & linuxCSUninstall.sh files exists in the root file
#========================================================================================================================== 
foreach( $module in ('windowsCSUninstall.ps1','linuxCSUninstall.sh')) {
    $cModulePath = "$PSScriptRoot\$module"
    if(-not (Test-Path -Path $cModulePath)) {
        Write-Log "Unable to find and load $cModulePath. Verify that this files exists and try again."
        Exit
    }
}  
 

#==========================================================================================================================
#Login Section
#==========================================================================================================================
$error.Clear()
Write-Log "INFORMATION: Please login to Azure Resource Manager."
    Login-AzAccount -EA SilentlyContinue -WA SilentlyContinue >$null
 
    if ($error) 
        { 
        Write-Log "WARNING:     Unable to connect to Azure. Check your internet connection and verify authentication details."
        
        exit
        }
        Else {
    Write-Log "INFORMATION: Connected to Azure with provided authentication."}

    Set-AzContext -Subscription $CustomerSubscriptionID -EA SilentlyContinue -WA SilentlyContinue >$null

    if ($error) 
        { 
        Write-Log "WARNING:     Invalid Subscription ID. Please make sure you have proper access to this Azure Subscription."  
        Write-Log "             Run the Powershell Command: " -NoNewLine 
        Write-Log "Login-AzAccount -Subscription $dxcSubscriptionID " -NoNewLine
        Write-Log "and login with your authentication details."
        Write-Log "             If you get error, you have access issues with the subscription."

        exit 
        }
        else {
    Write-Log "INFORMATION: Connected to Azure Subscription " -NoNewline
    Write-Log $dxcSubscriptionID -NoNewline
    Write-Log " with provided authentication."
    }


#========================================================================================================================
# Creating the variables
#========================================================================================================================
#Taking all the VMs in the subscription
$vms = get-azvm -ResourceGroupName $ResourceGroupName -Status
#Taking all the Windows VMs in the subscription
$vmlistWindows = $vms | Where-Object {$_.storageprofile.osdisk.ostype -like 'Windows'} | Select name, resourcegroupname , storageprofile, powerstate, Location | Where-Object {$_.powerstate -eq 'VM running'} | Sort-Object Name 
#Taking all the linux VMs in the subscription
$vmlistlinux = $vms | Where-Object {$_.Storageprofile.ImageReference.Offer | Select-String -Pattern 'RHEL|CENTOS|UbuntuServer'} | select name, resourcegroupname, storageprofile, powerstate, Location | Where-Object {$_.powerstate -eq 'VM running'} | Sort-Object Name 
#RHEL supported OS versions
$rhelsupport = 6.7, 6.8, 6.9, 7.2, 7.3, 7.4, 7.5, 7.6
#CENTOS supported Os versions
$centsupport = 6.7, 6.8, 6.9, 7.2, 7.3, 7.4, 7.5, 7.6
#UBUNTU Supported OS versions
$ubuntusupport = "18.04-LTS", "16.04-LTS", "14.04-LTS"
#Windows Supported OS versions
$WinSupport = "2016-Datacenter", "2012-R2-Datacenter", "2012-Datacenter", "2008-R2-SP1"

#validating if Linux VMs or All VMs are selected
if($LinuxVMs -or $AllVMs){
    #========================================================================================================================
    # Retrieving  the Secret Values from Key vault Secrets
    #========================================================================================================================
    $DomainIDforLinux = (Get-AzKeyVaultSecret -VaultName "$VaultName" -Name $DomainIDforLinux).SecretValueText
    $CustomerIDforLinux = (Get-AzKeyVaultSecret -VaultName "$VaultName" -Name $CustomerIDforLinux).SecretValueText
    $CustomerSecretKeyforLinux = (Get-AzKeyVaultSecret -VaultName "$VaultName" -Name $CustomerSecretKeyforLinux).SecretValueText

    #========================================================================================================================
    #Installing symantec CWP extension on the Linux VMs.
    #========================================================================================================================
    #Looping all Linux VMs to install Symantec CWP 
    Write-Log "`n####################### Performing Migration on Linux VMs ###################################"
    foreach($vm in $vmlistlinux)
	{
	#check if symantec exists
        try{
            $OS = $vm.StorageProfile.ImageReference.Offer
            $version = $vm.StorageProfile.ImageReference.sku
            if ((($OS -match 'RHEL') -and ($rhelsupport -contains $version)) -or (($OS -match 'CENTOS') -and ($centsupport -contains $version)) -or (($OS -match 'UBUNTU') -and ($ubuntusupport -contains $version)))
            {
                $ListofExtension = Get-AzVMExtension -ResourceGroupName $vm.resourcegroupname -VMName $vm.name | Select-Object Name
                if (!($ListofExtension.Name -contains "SCWPAgentForLinux"))
                {
                    #Install Symantec on the VM and output result
                    Write-log "Installing Symantec CWP on VM named $($vm.name) It could take 7 to 10 minutes for installtion..."
                    
                    #Get VM location
                    $vmlocation = (Get-AzVm -ResourceGroupName $vm.ResourceGroupName -Status | ? {$_.Name -eq $vm.name}).Location

                    $settings = @{"domainId"="$DomainIDforLinux"; "customerId"="$CustomerIDforLinux"; "forceReboot"="yes"}
                    $protectedSettings = @{"customerSecretKey"="$CustomerSecretKeyforLinux"}
                    $cwpresult = Set-AzVMExtension -VMName $vm.name -ResourceGroupName $vm.resourcegroupname -Location $vm.location -Publisher Symantec.CloudWorkloadProtection -ExtensionName SCWPAgentForLinux -ExtensionType SCWPAgentForLinux -Version 2.5 -Settings $settings -ProtectedSettings $protectedSettings
                }
                    else
                    {	
                    Write-log "Symantec CWP extension already installed on $($vm.name)"
                    }  
            }
                else
                {
                Write-Log "$($vm.name)'s OS version is not supported by Symantec CWP"
                }
        }
        catch 
        {
        Write-log "$($_.ErrorMessage)"
        }
	}
    #========================================================================================================================
    #Uninstalling crowdstrike extension on the Linux VMs.
    #========================================================================================================================
    #Looping all Linux VMs to uninstall crowdstrike
    foreach($vm in $vmlistlinux)
	{
        try{
            #check if Crowdstrike exists
            $ListofExtension = Get-AzVMExtension -ResourceGroupName $vm.resourcegroupname -VMName $vm.name | Select-Object Name
            $extension = Get-AzVMExtension -ResourceGroupName $vm.resourcegroupname -VMName $vm.name | Where-Object {$_.Name | Select-String -Pattern 'CrowdStrikeSensor|CrowdStrikeAgent'} | select name 

            if ($ListofExtension.Name -contains "CrowdStrikeSensor" -or $ListofExtension.Name -contains "CrowdStrikeAgent")
            {
                #Uninstall Crowdstrike on the VM and output result
                Write-log "Uninstalling Crowdstrike on VM named $($vm.name)"

                $guiresult = Remove-AzVMExtension -ResourceGroupName $vm.resourcegroupname -VMName $vm.name -ExtensionName $extension.name -Force
                $cmdresult =(invoke-azvmruncommand -ResourceGroupName $vm.resourcegroupname -Name $vm.name -CommandId 'RunShellScript' -ScriptPath .\linuxCSUninstall.sh)
            }
                Else
                {	
                Write-log "CrowdstrikeSensor extension not found on $($vm.name)"
                }  
        }
        catch 
        {
        Write-log "$($_.ErrorMessage)"
        }
     
	}
}

#validating if Windows VMs or ALL VMs are selected
if($WindowsVMs -or $AllVMs){
    #========================================================================================================================
    # Retrieving  the Secret Values from Key vault Secrets
    #========================================================================================================================
    $BulkMaintenanceToken = (Get-AzKeyVaultSecret -VaultName "$VaultName" -Name $BulkMaintenanceToken).SecretValueText
    $DomainIDforWindows = (Get-AzKeyVaultSecret -VaultName "$VaultName" -Name $DomainIDforWindows).SecretValueText
    $CustomerIDforWindows = (Get-AzKeyVaultSecret -VaultName "$VaultName" -Name $CustomerIDforWindows).SecretValueText
    $ClientIDforWindows = (Get-AzKeyVaultSecret -VaultName "$VaultName" -Name $ClientIDforWindows).SecretValueText
    $CustomerSecretKeyforWindows = (Get-AzKeyVaultSecret -VaultName "$VaultName" -Name $CustomerSecretKeyforWindows).SecretValueText
    $ClientSecretKeyforWindows = (Get-AzKeyVaultSecret -VaultName "$VaultName" -Name $ClientSecretKeyforWindows).SecretValueText

    #========================================================================================================================
    #Installing symantec CWP extension on the Windows VMs.
    #========================================================================================================================
    Write-Log "`n####################### Performing Migration on Windows VMs ###################################"
    #Looping all Windows VMs to install Symantec CWP
    foreach($vm in $vmlistWindows)
        {
        try{
            $OS = $vm.StorageProfile.OsDisk.OsType
            $version = $vm.StorageProfile.ImageReference.sku
            if(($OS -match 'Windows') -and ($WinSupport -contains $version))
            {
                #check if symantec exists
                $ListofExtension = Get-AzVMExtension -ResourceGroupName $vm.resourcegroupname -VMName $vm.name | Select-Object Name
                if (!($ListofExtension.Name -contains "SCWPAgentForWindows"))
                {

                    #Install Symantec on the VM and output result
                    Write-log "Installing Symantec CWP on VM named $($vm.name) It could take 10 to 12 minutes for installtion..."
                    
                    #Get VM location
                    $vmlocation = (Get-AzVm -ResourceGroupName $vm.ResourceGroupName -Status | ? {$_.Name -eq $vm.name}).Location

                    $settings = @{"domainId"="$DomainIDforWindows"; "customerId"="$CustomerIDforWindows"; "clientId"="$ClientIDforWindows"; "forceReboot"="yes"}
                    $protectedSettings = @{"customerSecretKey"="$CustomerSecretKeyforWindows"; "clientSecretKey"="$ClientSecretKeyforWindows"}
                    $cwpresult = Set-AzVMExtension -VMName $vm.name -ResourceGroupName $vm.resourcegroupname -Location $vm.location -Publisher Symantec.CloudWorkloadProtection -ExtensionName SCWPAgentForWindows -ExtensionType SCWPAgentForWindows -Version 2.2 -Settings $settings -ProtectedSettings $protectedSettings
                }
                Else
                {	
                Write-log "Symantec CWP extension already installed on $($vm.name)"
                }  
            }
            Else
            {
            Write-Log "$($vm.name)'s OS version is not supported by Symantec CWP"
            }
        }
        catch {
        Write-log "$($_.ErrorMessage)"
        }
    }
    #========================================================================================================================
    #Uninstalling crowdstrike extension on the Windows VMs.
    #========================================================================================================================
    #Looping all Windows VMs to uninstall crowdstrike
    foreach($vm in $vmlistWindows)
        {
        #check if Crowdstrike exists
        try{
            $ListofExtension = Get-AzVMExtension -ResourceGroupName $vm.resourcegroupname -VMName $vm.name | Select-Object Name
            $extension = Get-AzVMExtension -ResourceGroupName $vm.resourcegroupname -VMName $vm.name | Where-Object {$_.Name | Select-String -Pattern 'CrowdStrikeSensor|CrowdStrikeAgent'} | select name
            if ($ListofExtension.Name -contains "CrowdStrikeSensor" -or $ListofExtension.Name -contains "CrowdStrikeAgent")
            {

                #Uninstall Crowdstrike on the VM and output result
                Write-log "Uninstalling Crowdstrike on VM named $($vm.name)"

                $guiresult = Remove-AzVMExtension -ResourceGroupName $vm.resourcegroupname -VMName $vm.name -ExtensionName $extension.name -Force
                $cmdresult = (invoke-azvmruncommand -ResourceGroupName $vm.resourcegroupname -Name $vm.name -CommandId 'RunPowerShellScript' -ScriptPath .\windowsCSUninstall.ps1 -Parameter @{MaintenanceToken = $BulkMaintenanceToken})
                if($cmresult.Value[0].Message -eq "Unsupported crowdstrike Version")
                    {
                    Write-Log -logText "Unable to uninstall Crowdstrike on VM name $($vm.Name) because the Crowdstrike version is below 5.10.9106 "
                    }
            }
            Else
            {	
            Write-log "CrowdstrikeSensor extension not found on $($vm.name)"
            }  
        }
        catch 
        {
        Write-log "$($_.ErrorMessage)"
        }
	}
  
}
Write-Log "`n####################### END OF SCRIPT EXECUTION ###################################"