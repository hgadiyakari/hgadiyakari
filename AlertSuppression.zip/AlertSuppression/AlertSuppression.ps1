﻿<#=========================================================================================================================
AUTHOR:  Harika Gadiyakari 
DATE:    27/11/2020
Version: 1.0
Details: Script to create Action Rule to supress alerts at subscription level, ResourceGroup level & Log Analytics Workspace & resource scope level.	

#=====================================================================================================================
# DOCUMENTATION LINK
# https://confluence.dxc.com/pages/viewpage.action?pageId=221793392
#=====================================================================================================================
.SYNOPSIS
Script to create Action Rule to supress alerts at subscription level, ResourceGroup level & Log Analytics Workspace & resource scope level.

.PARAMETER SubscriptionId
Specify a valid Subscription ID of Subscription where the ActionRule will be deployed

.PARAMETER TenantId
Specify a valid Active Directory Tenand Id.

.PARAMETER ResourceGroupName
Specify a valid Resource Group Name where the ActionRule will be deployed.

.PARAMETER ActionRuleName
Specify a valid Action Rule Name

.PARAMETER SubscriptionScope
Specify this parameter, if you want run the script on Subscription Scope level.

.PARAMETER ResourceGroupScope
Specify this parameter, if you want run the script on Resource Group Scope level.

.PARAMETER LogAnalyticsWorkspaceScope
Specify this parameter, if you want run the script on Log Analytics Workspace Scope level.

.PARAMETER ResourceScope
Specify this parameter, if you want run the script on Resource Scope level.

.PARAMETER ResourceGroups
Specify ResourceGroup in a array on which you want to suppress the alerts.

.PARAMETER WorkSpaceRGName
Specify LogAnalytics Workspace Resource Group Name in which your Log Analytics Workspace is located.

.PARAMETER WorkSpaceName
Specify LogAnalytics Workspace Name on which you want to suppress the alerts.

.PARAMETER Status
Specify Status of Action Rule whether it should be Enabled or Disabled

.PARAMETER ReccurenceType
Specify the duration when the suppression should be applied, Once or Weekly or Monthly

.PARAMETER SuppressionStartTime
Specify Suppression Start Time. Format 12/09/2018 06:00:00 +Should be mentioned in case of Reccurent Supression Schedule - Once, Daily, Weekly or Monthly.

.PARAMETER SuppressionEndTime
Suppression End Time. Format 12/09/2018 06:00:00 +Should be mentioned in case of Reccurent Supression Schedule - Once, Daily, Weekly or Monthly.

.PARAMETER ReccurentValue
Specify Reccurent values, if applicable.In case of Weekly or Monthly

.PARAMETER SeverityCondition
Specify Severity Condition, Expected format - {<operation>:<comma separated list of values>} For eg. Equals:Sev0,Sev1 

.PARAMETER MonitorCondition
Specify Severity Condition, Expected format - {<operation>:<comma separated list of values>} For eg. NotEquals:Fired

.PARAMETER Description
Specify Description of Action Rule

.PARAMETER AlertContextCondition
Specify AlertContext Condition, Expected format - {<operation>:<comma separated list of values>} For eg. Contains:testRG

.EXAMPLE
To run the script on Subscription Scope level, run the following command .\AlertSuppression.ps1 -SubscriptionId <SubscriptionID> -TenantId <TenantID> -ResourceGroupName "testRG" -ActionRuleName "testAR" -SubscriptionScope -Status Enabled -ReccurenceType Monthly -SuppressionStartTime "02/12/2020 20:00:00" -SuppressionEndTime "02/12/2020 22:00:00" -ReccurentValue 1,2 -SeverityCondition "Equals:Sev0,Sev1" -MonitorCondition "NotEquals:Resolved" -Description "Test Description" -AlertContextCondition "Contains:dxcmetric3e94c00e8041stg,DXC-EA1C-41de-loganalyticsWorkspace"

.EXAMPLE
To run the script on Resource Group Scope level, run the following command .\AlertSuppression.ps1 -SubscriptionId <SubscriptionID> -TenantId <TenantID> -ResourceGroupName "testRG" -ActionRuleName "testAR" -ResourceGroupScope -ResourceGroups @("testRG1","testRG2") -Status Enabled -ReccurenceType Monthly -SuppressionStartTime "02/12/2020 20:00:00" -SuppressionEndTime "02/12/2020 22:00:00" -ReccurentValue 1,2 -SeverityCondition "Equals:Sev0,Sev1" -MonitorCondition "NotEquals:Resolved" -Description "Test Description" -AlertContextCondition "Contains:dxcmetric3e94c00e8041stg,DXC-EA1C-41de-loganalyticsWorkspace"

.EXAMPLE
To run the script on Subscription Scope level, run the following command .\AlertSuppression.ps1 -SubscriptionId <SubscriptionID> -TenantId <TenantID> -ResourceGroupName "testRG" -ActionRuleName "testAR" -LogAnalyticsWorkspaceScope -WorkSpaceRGName "testRG" -WorkSpaceName "DXC-Ea1-Workspace" -Status Enabled -ReccurenceType Monthly -SuppressionStartTime "02/12/2020 20:00:00" -SuppressionEndTime "02/12/2020 22:00:00" -ReccurentValue 1,2 -SeverityCondition "Equals:Sev0,Sev1" -MonitorCondition "NotEquals:Resolved" -Description "Test Description" -AlertContextCondition "Contains:dxcmetric3e94c00e8041stg,DXC-EA1C-41de-loganalyticsWorkspace"

.EXAMPLE
To run the script on Subscription Scope level, run the following command .\AlertSuppression.ps1 -SubscriptionId <SubscriptionID> -TenantId <TenantID> -ResourceGroupName "testRG" -ActionRuleName "testAR" -ResourceScope -Status Enabled -ReccurenceType Monthly -SuppressionStartTime "02/12/2020 20:00:00" -SuppressionEndTime "02/12/2020 22:00:00" -ReccurentValue 1,2 -SeverityCondition "Equals:Sev0,Sev1" -MonitorCondition "NotEquals:Resolved" -Description "Test Description" -AlertContextCondition "Contains:dxcmetric3e94c00e8041stg,DXC-EA1C-41de-loganalyticsWorkspace"

#>
[CmdletBinding(DefaultParametersetName='ResourceScope')]
Param
    (
    
    [Parameter(Mandatory=$true)] [String]$SubscriptionId,
    [Parameter(Mandatory=$true)] [String]$TenantId,
    [Parameter(Mandatory=$true)] [String]$ResourceGroupName,
    [Parameter(Mandatory=$true)] [String]$ActionRuleName,
    [Parameter(ParameterSetName="SubscriptionScope")][switch]$SubscriptionScope,
    [Parameter(ParameterSetName="ResourceGroupScope")][switch]$ResourceGroupScope,
    [Parameter(ParameterSetName="LogAnalyticsWorkspaceScope")][switch]$LogAnalyticsWorkspaceScope,
    [Parameter(ParameterSetName="ResourceScope")][switch]$ResourceScope,
    
    [Parameter(ParameterSetName="ResourceGroupScope", Mandatory=$true)][Array]$ResourceGroups,
    [Parameter(ParameterSetName="LogAnalyticsWorkspaceScope", Mandatory=$true)][string]$WorkSpaceRGName,
    [Parameter(ParameterSetName="LogAnalyticsWorkspaceScope", Mandatory=$true)][string]$WorkSpaceName,
    
    [Parameter(Mandatory=$true)] [ValidateSet("Enabled","Disabled")] [String]$Status,

    [Parameter(Mandatory=$true)] [ValidateSet("Once","Daily","Weekly","Monthly")] [String]$ReccurenceType,
    [Parameter(Mandatory=$true)] [String]$SuppressionStartTime,
    [Parameter(Mandatory=$true)] [String]$SuppressionEndTime,
    [ValidateRange(0, 31)][Parameter(Mandatory=$false)] [Int32[]]$ReccurentValue,
    [Parameter(Mandatory=$false)] [String]$SeverityCondition,
    [Parameter(Mandatory=$false)] [String]$MonitorCondition,
    [Parameter(Mandatory=$false)] [String]$Description,
    [Parameter(ParameterSetName="SubscriptionScope", Mandatory=$false)][Parameter(ParameterSetName="ResourceGroupScope", Mandatory=$false)][Parameter(ParameterSetName="LogAnalyticsWorkspaceScope", Mandatory=$false)][Parameter(ParameterSetName="ResourceScope", Mandatory=$true)][String]$AlertContextCondition
    )
#=====================================================================================================================
# IMPORTCUSTOM MODULES AND CHECK ENVIRONMENT FOR NECESSERY MODULES
#=====================================================================================================================
$dxcModuleList = "DXCEnvCheckV2.psm1", "DXCUtilityFunctions.psm1"
foreach ($dxcModule in $dxcModuleList)
    {
    [String]$dxcModuleURL = "https://dxcazuretools.blob.core.windows.net/installers/DXCPowershellModules/" + $dxcModule
    [String]$dxcLocalModule = $PSScriptRoot + "\" + $dxcModule
    (New-Object System.Net.WebClient).DownloadFile($dxcModuleURL, $dxcLocalModule)
    Import-Module $dxcLocalModule -WA 0
    Remove-Item -Path $dxcLocalModule
    }
$dxcPSCore = Check-PSCore -Version 7.0.0
if ($dxcPSCore) { $dxcAZ = Check-AzModule -Version 2.5.0 }
if ($dxcAZ) { $dxcAZMonitor = Check-PSModule -Name "Az.Monitor" -Version 1.5.0 }
if ($dxcAZMonitor) {$dxcAZAlertsManagement = Check-PSModule -Name "Az.AlertsManagement" -Version 0.2.0 }
if (!$dxcAZAlertsManagement)
    {
    Read-Host "`nPress 'ENTER'to exit the script........"
    exit
    }
#=====================================================================================================================
# LOGIN SECTION
#=====================================================================================================================
Write-Host "`nINFORMATION: Please login to Azure Resource Manager." -ForegroundColor Green
Utility-LoginAZTenant -TenantId $TenantId -SubscriptionId $SubscriptionId

#====================================================================================================================
# Variable Declaration
#====================================================================================================================
$subID = "/subscriptions/$SubscriptionId"
$Severity = $null
$Monitor = $null
$des = $null
$AlertContext = $null

if ($SeverityCondition) {
    $Severity = $SeverityCondition    
}
if ($MonitorCondition) {
    $Monitor = $MonitorCondition
}
if ($Description) {
    $Des = $Description
}

if ($AlertContextCondition) {
    $AlertContext = $AlertContextCondition
}
#=====================================================================================================================
#ActionRule Creation for Subscription Scope
#=====================================================================================================================
if ($SubscriptionScope)
    {
        Set-AzActionRule -ResourceGroupName $ResourceGroupName -Name $ActionRuleName -Scope $subID -SeverityCondition $Severity -MonitorCondition $Monitor -Description $Des -Status $Status -ActionRuleType "Suppression" -ReccurenceType $ReccurenceType -SuppressionStartTime $SuppressionStartTime -SuppressionEndTime $SuppressionEndTime -ReccurentValue $ReccurentValue -AlertContextCondition $AlertContext
                       
    }
    elseif ($ResourceGroupScope) {
        foreach ($RGName in $ResourceGroups) {
            $RGID = $subID +"/resourceGroups/$RGName"
            Set-AzActionRule -ResourceGroupName $ResourceGroupName -Name $ActionRuleName -Scope $RGID -SeverityCondition $Severity -MonitorCondition $Monitor -Description $Des -Status $Status -ActionRuleType "Suppression" -ReccurenceType $ReccurenceType -SuppressionStartTime $SuppressionStartTime -SuppressionEndTime $SuppressionEndTime -ReccurentValue $ReccurentValue -AlertContextCondition $AlertContext
        }
        
    }
    elseif ($LogAnalyticsWorkspaceScope) {
        Write-Host "Creating Action rule for LogAnalyticsWorkspace Scope"
        $WSID = $subID+"/resourceGroups/$WorkSpaceRGName"+"/providers/microsoft.operationalinsights/workspaces/$WorkSpaceName"
        Set-AzActionRule -ResourceGroupName $ResourceGroupName -Name $ActionRuleName -Scope $WSID -SeverityCondition $Severity -MonitorCondition $Monitor -Description $Des -Status $Status -ActionRuleType "Suppression" -ReccurenceType $ReccurenceType -SuppressionStartTime $SuppressionStartTime -SuppressionEndTime $SuppressionEndTime -ReccurentValue $ReccurentValue -AlertContextCondition $AlertContext
    }
    elseif ($ResourceScope) {
        Write-Host "Creating Action rule for Resource Scope" -ForegroundColor Green
        Set-AzActionRule -ResourceGroupName $ResourceGroupName -Name $ActionRuleName -Scope $subID -SeverityCondition $Severity -MonitorCondition $Monitor -Description $Des -Status $Status -ActionRuleType "Suppression" -ReccurenceType $ReccurenceType -SuppressionStartTime $SuppressionStartTime -SuppressionEndTime $SuppressionEndTime -ReccurentValue $ReccurentValue -AlertContextCondition $AlertContext
        Write-Host "Action Rule named $ActionRuleName is created in subscription $SubscriptionId"
    }


