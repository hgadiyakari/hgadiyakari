# IaaS
This directory contains all deployable resources from Azure Engineering in the area of Infrastructure as a Service (IaaS)

Current resources for for IaaS include:
* MakeManaged
* VM Deployment Flavors
