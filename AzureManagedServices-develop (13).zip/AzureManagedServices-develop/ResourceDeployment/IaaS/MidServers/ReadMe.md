# Mid Server Deployment and Configuration

Cloud Management Platform (CMP) requires a Mid Server for Cloud Discovery and Catalog Provisioning which is used to facilitate communication between ServiceNow 
instance and external systems like Cloud Providers to populate and keep up to date ServiceNow CMDB.  The script deployMidServer.ps1 executes the following:

## Supported
Creates a Network Security Group 
Creates a subnet on an existing vNet (preferably on the DXC Management Network)
Creates the Mid Server VM (preferably on the DXC Management Resource Group)
Installs and configures the ServiceNow installable on the Mid Server


## Jira Epic
https://jira.dxc.com/browse/AZR-22241

## Deployment
For more information on how to execute script, please see:
https://confluence.dxc.com/display/CSA/Azure+Mid+Server+Automated+Installation+Guide

## Members of this directory are:
* CMPMidServerComplimentaryResources.json	ARM Template to deply NSG and Subnet on existing VNet for use by the Mid Server - available in artifacts storage account
* deployMidServer.ps1						Main execution PowerShell script
* SNOWInstaller.sh							Shell script that is executed on the Mid Server itself to install and configure SNOW Mid Server application
											called from deployMidServer.ps1 and available in artifacts storage account
## Authors
* **Anthony Borucki**

##Last ReadMe Update = 05/13/2021