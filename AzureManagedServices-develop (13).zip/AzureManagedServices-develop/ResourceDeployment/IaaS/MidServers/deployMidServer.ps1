#Requires -PSEdition Core
#Requires -Modules @{ ModuleName="Az"; ModuleVersion="3.1.0" }

<#
.SYNOPSIS
Deploys Mid Server for CMP SNOW

.DESCRIPTION
This powershell creates and configures a Mid Server for SNOW integration with and Azure subscription

MANDATORY PARAMETERS

.PARAMETER Subscription         
(Mandatory) The name of the subscription this session is to be running under.  If 
not entered, then the default subscription for the type of login used will be used.
This does not apply if the user is prompted for a login.          

.PARAMETER $DXCManagementResourceGroup
(Mandatory) Resource group of the DXC LA workspace - dxc-maint-rg

.PARAMETER DXCManagementResourceGroupLocation
(Mandatory) Region for Resource group of the DXC LA workspace

.PARAMETER midServerVMName
(Mandatory) Name of the mid server vm itself

.PARAMETER midServerSubnetAddressPrefix
(Mandatory) Subnet address prefix for mid server vm on DXC managed vnet provided or defaulted to i.e. 10.171.2.0/24

.PARAMETER MidServerKeyVaultName
(Mandatory) name for the key vault for the mid server vm

.PARAMETER existingBootDiagStorageName
(Mandatory) Name for the boot diagnostic storage account for the mid server vm

.PARAMETER workspaceId
(Mandatory) Workspace ID for the DXC-Maint-EG log analytics workspace

.PARAMETER workspaceKey
(Mandatory) Workspace Key for the DXC-Maint-EG log analytics workspace

.PARAMETER csCID
(Mandatory) Crowdstrike ID

.PARAMETER existingRecoveryServicesVaultRG
(Mandatory) Resource Group for the Recovery Services Vault for the mid server vm

.PARAMETER existingRecoveryServicesVault
(Mandatory) Name of the Recovery Services Vault for the mid server vm

.PARAMETER SNOWMidServerName
(Mandatory) Name of Mid Server in SNOW. Must follow PDXC naming conventions

.PARAMETER SNOWInstallUrl
(Mandatory) Full URL for the SNOW install zip file to be installed on this mid server. See confluence instructions on how to construct the URL to be passed in.

.PARAMETER SNOWUrl
(Mandatory) Full URL for the SNOW instance this mid server will be connecting to - I.e https://cscdev.service-now.com

.PARAMETER SNOWMidInstanceUserName
(Mandatory) SNOW user name created on the SNOW instance to use to connect from the mid server

.PARAMETER SNOWMidInstanceUserPassword
(Mandatory) Password for the SNOW user name created on the SNOW instance to use to connect from the mid server

Author:  Anthony Borucki
Date:    04/01/2021
Version: 1.0
Documentation: Initial version 

Example Script execution: 
.\deployMidServer.ps1 -Subscription b47b134f-d1e7-4f79-8a4c-043a355acf6d -DXCManagementResourceGroupLocation "UK South" -HighAvailability "True" -midServerVMName USYDSMDPRDEUSAZR01 -midServerVMNameHighAvailability USYDSMDPRDEUSAZR02 -midServerSubnetAddressPrefix "10.171.2.0/24"  -MidServerKeyVaultName "DXC-EA2-Maint-Vault" -existingBootDiagStorageName dxcmaintuksouth -workspaceId "0027f3cd-a1e8-4567-9e13-8a10382047a4" -workspaceKey "1p2NtuZRmRVzkSOGV8dNcLIvKVlS/Gp7GosxXJwOx+U7ifB/UldjFxpnRH6s/SXp1SZm2uGDaHmIGeGVmKNaqw==" -csCID "D37C5F63236A4FE69DEABB9893DCF41D-D3" -existingRecoveryServicesVault "DXC-Maint-Vault" -SNOWMidServerName USYDSMDPRDEUSAZR01 -SNOWMidServerNameHighAvailability USYDSMDPRDEUSAZR02 -SNOWInstallURL� "https://install.service-now.com/glide/distribution/builds/package/mid/2021/01/21/mid.paris-06-24-2020__patch5-hotfix2-01-20-2021_01-21-2021_0752.linux.x86-64.zip" -SNOWUrl "cscdev.service-now.com" -SNOWMidInstanceUserName "oms_mid_gtc2" -SNOWMidInstanceUserPassword "gtc2" -ArtifactsKeyVaultName "DXC-EA2-Maint-Vault" -rootPassword "MyPassword1!!" -dxcPatchGroup '{"Required":"True","PatchGroupName":"LinuxMonthly"}'
#>

Param(
	[Parameter(Mandatory=$true)] [String]$Subscription,
	[Parameter(Mandatory=$false)] [String]$DXCManagementResourceGroup = "DXC-Maint-RG",
    [Parameter(Mandatory=$true)] [String]$DXCManagementResourceGroupLocation,
	[Parameter(Mandatory=$false)] [String]$HighAvailability = "False",
	[Parameter(Mandatory=$true)] [String]$midServerVMName,
	[Parameter(Mandatory=$false)] [String]$midServerVMNameHighAvailability = "",
	[Parameter(Mandatory=$false)] [String]$midServerAvailabilityZone = "1",
	[Parameter(Mandatory=$false)] [String]$midServerHighAvailabilityAvailabilityZone = "2",
	[Parameter(Mandatory=$false)] [String]$rootUserName = "sysadmin",
	[Parameter(Mandatory=$true)] [String]$rootPassword,
	[Parameter(Mandatory=$false)] [String]$dXCMidServerNSGName = "DXC-MID-Subnet",
	[Parameter(Mandatory=$false)] [String]$existingDXCVNETName = "DXC-Maint-vNet",
	[Parameter(Mandatory=$false)] [String]$midServerSubnetName = "DXC-MID-Subnet",
	[Parameter(Mandatory=$true)] [String]$midServerSubnetAddressPrefix,
	[Parameter(Mandatory=$true)] [String]$MidServerKeyVaultName,
	[Parameter(Mandatory=$false)] [String]$MidServerKeyVaultRG = "DXC-Maint-RG",
	[Parameter(Mandatory=$false)] [String]$osVersion = "ubuntu18.04-LTS",
	[Parameter(Mandatory=$false)] [String]$vmSize = "Standard_D2_v3",
	[Parameter(Mandatory=$false)] [String]$OSDiskType = "Standard_LRS",
	[Parameter(Mandatory=$false)] [int]$numberOfDataDisks = 0,
	[Parameter(Mandatory=$false)] [String]$dataDiskType = "StandardSSD_LRS",
	[Parameter(Mandatory=$false)] [String]$dataDiskSize = "128",
	[Parameter(Mandatory=$false)] [String]$dataDiskHostCaching = "None",
	[Parameter(Mandatory=$false)] [String]$existingBootDiagStorageResourceGroup = "DXC-Maint-RG",
	[Parameter(Mandatory=$true)] [String]$existingBootDiagStorageName,
	[Parameter(Mandatory=$false)] [String]$publicIPRequired = "no",
	[Parameter(Mandatory=$false)] [String]$application = "Mid Server",
	[Parameter(Mandatory=$false)] [String]$departmentName = "Mid Server",
	[Parameter(Mandatory=$false)] [String]$project = "Mid Server",
	[Parameter(Mandatory=$true)] [String]$workspaceId,
	[Parameter(Mandatory=$true)] [String]$workspaceKey,
	[Parameter(Mandatory=$false)] [String]$dxcEPAgent = "crowdstrike",
	[Parameter(Mandatory=$true)] [String]$csCID,
	[Parameter(Mandatory=$false)] [String]$existingRecoveryServicesVaultRG = "DXC-Maint-RG",
	[Parameter(Mandatory=$false)] [String]$existingRecoveryServicesVault = "DXC-Maint-Vault",
	[Parameter(Mandatory=$false)] [String]$existingBackupPolicy = "DefaultPolicy",
	[Parameter(Mandatory=$true)] [String]$SNOWMidServerName,
	[Parameter(Mandatory=$false)] [String]$SNOWMidServerNameHighAvailability = "",
	[Parameter(Mandatory=$true)] [String]$SNOWUrl,
	[Parameter(Mandatory=$true)] [String]$SNOWInstallUrl,
	[Parameter(Mandatory=$true)] [String]$SNOWMidInstanceUserName,
	[Parameter(Mandatory=$true)] [String]$SNOWMidInstanceUserPassword,
	[Parameter(Mandatory=$false)][String]$artifactsdev = "False",
	[Parameter(Mandatory=$false)][String]$ArtifactsKeyVaultName,
	[Parameter(Mandatory=$false)][String]$dxcPatchGroup = '{"Required":"False"}'
)

#tagging variables. Modify these or make them parameters if it becomes desire to allow these values to be changed. The story requirement was to hardcode them right now.
$dxcManaged = $true
$dxcMonitored = $true
$dxcBackup = $false

#========================================================================================================================
# IMPORT CUSTOM MODULE
#========================================================================================================================
$dxcModuleList = "DXCUtilityFunctions.psm1"

foreach ($dxcModule in $dxcModuleList)
{
    [String]$dxcModuleURL = "https://dxcazuretoolsdev.blob.core.windows.net/installers/DXCPowershellModules/" + $dxcModule
    [String]$dxcLocalModule = $PSScriptRoot + "\" + $dxcModule
    (New-Object System.Net.WebClient).DownloadFile($dxcModuleURL, $dxcLocalModule)
    Import-Module $dxcLocalModule -WA 0
}

#Connect to Tenant
Utility-LoginAZ -dxcSubscriptionId $Subscription

#Check password used for SNOW Instance. It cannot have " & ' < >
If (($SNOWMidInstanceUserPassword -match '["&<>]') -or ($SNOWMidInstanceUserPassword -match "[']"))
{
	Write-Host "The SNOWMidInstanceUserPassword contains ', &, <, > or a double quote. This is not allowed. Please change your password in SNOW and then re-run this script." -ForegroundColor Red
	exit
}

#Check and remove https:// or http:// from SNOWURL in order to avoid needing to escape // in config.xml on Mid Server
$SNOWUrl = $SNOWUrl.Replace("https://","").Replace("http://","")

#Parse the SNOWInstallURL for use by the installation shell script
Try{
	$SNOWInstallUrlPath = $SNOWInstallUrl.Substring(0, ($SNOWInstallUrl.LastIndexOf('/')+1))
	$SNOWInstallFileName = $SNOWInstallUrl.Substring(($SNOWInstallUrl.LastIndexOf('/')+1), ($SNOWInstallUrl.Length-($SNOWInstallUrl.LastIndexOf('/')+1)))
}
Catch{
	Write-Host "Could not properly parse SNOWInstallUrl ($SNOWInstallUrl). Please verify URL is correct and try again." 
	exit
}

#Check High Availability parameters for completeness
if ($HighAvailability -eq "True")
{
	if ($midServerVMNameHighAvailability -eq "")
	{
		write-host "HighAvailability is set to True, but midServerVMNameHighAvailability was not set. Please correct and re-execute script" -ForegroundColor Red
		exit
	}
	if ($SNOWMidServerNameHighAvailability -eq "")
	{
		write-host "HighAvailability is set to True, but SNOWMidServerNameHighAvailability was not set. Please correct and re-execute script" -ForegroundColor Red
		exit
	}
}
#Verify availibility zone for VM exists. If it doesn't create the VM without one
$Availability = ""
$SKU = Get-AzComputeResourceSku -Location $DXCManagementResourceGroupLocation | where {$_.Name -icontains $vmSize} |  Where-Object {$_.LocationInfo.Zones -contains $midServerAvailabilityZone}
$SKUHA = Get-AzComputeResourceSku -Location $DXCManagementResourceGroupLocation | where {$_.Name -icontains $vmSize} |  Where-Object {$_.LocationInfo.Zones -contains $midServerHighAvailabilityAvailabilityZone}
if ($SKU -eq $null -or $SKUHA -eq $null)
{
	Write-Host "Availability Zones Not available for region/vm. Would you still like to proceed creating MidServer/s without Availability Zones? (Y/y to proceed, or N/n to quit)" -ForegroundColor Yellow -NoNewline
	$Proceed=read-host 
	if ($Proceed -ne "Y" -and $Proceed -ne "y") {
		exit
	}
	$Availability = "No Availability Required"
}
else
{
	Write-Host "Availability Zones available for region/vm. Will create MidServer/s with Availability Zones" -ForegroundColor Green
	$Availability = "AvailabilityZone"
}

#Artifacts used - URL and tokens to access
$linuxTemplateUri = "https://dxcazuretoolsdev.blob.core.windows.net/iaas-templates-r214/DXC_Linux_AllExt.json"
$CMPMidServerComplimentaryResourcesUri = "https://dxcazuretoolsdev.blob.core.windows.net/templates/CMPMidServerComplimentaryResources.json"
$ArtifactsStorageAccountName = "dxcazuretoolsdev"
$SNOWInstallerScriptContainerName = "installers"
$SNOWInstallerScript = "SNOWInstaller.sh"

#Get SAS token Build full URLs for the 2 templates needed from storage
$token = ""
if ($artifactsdev -eq "True") 
{
	Try {
			$secretvalue = Get-AzKeyVaultSecret -VaultName $ArtifactsKeyVaultName -Name makeMgdSasTokendev
			$token = [System.Net.NetworkCredential]::new("", $secretvalue.SecretValue).Password
        }
	Catch {
			$token = $null
		}
    if ($token -eq "" -or $null -eq $token) {
		write-host "makeMgdSasTokendev not found in key vault. Please fix this issue and re-run this script"
		Exit
	}
}
else
{
	Try {
			$secretvalue = Get-AzKeyVaultSecret -VaultName $ArtifactsKeyVaultName -Name makeMgdSasToken
			$token = [System.Net.NetworkCredential]::new("", $secretvalue.SecretValue).Password
        }
	Catch {
			$token = $null
		}
    if ($token -eq "" -or $null -eq $token) {
		write-host "makeMgdSasToken not found in key vault. Please fix this issue and re-run this script"
		Exit
	}
}
$linuxTemplateUri = "$($linuxTemplateUri)$($token)"
$CMPMidServerComplimentaryResourcesUri = "$($CMPMidServerComplimentaryResourcesUri)$($token)"

#pull SNOWInstaller locally as it cannot be referenced as a URL to storage account in Invoke-AzVMRunCommand as it must be local.
$Ctx = New-AzStorageContext -StorageAccountName $ArtifactsStorageAccountName -SasToken $token
Get-AzStorageBlobContent -Blob $SNOWInstallerScript -Container $SNOWInstallerScriptContainerName -Context $Ctx

#Code to build names built off of subnet address prefix
$subnetString = $midServerSubnetAddressPrefix -replace '/','_'
$dXCMidServerNSGName = $dXCMidServerNSGName + '_' + $subnetString +'-NSG'
$midServerSubnetName = $midServerSubnetName + '_' + $subnetString

#Code to display values to be used and allow the user to proceed or exit
write-host 
write-host "Below are the values to be used in the creation and configuration of the mid server. Many of them are default values. Please review before proceeding" -ForegroundColor Green
write-host 
write-host "Subscription = $Subscription"
write-host "DXCManagementResourceGroup = $DXCManagementResourceGroup"
write-host "DXCManagementResourceGroupLocation = $DXCManagementResourceGroupLocation"
write-host "HighAvailability = $HighAvailability"
write-host "midServerVMName = $midServerVMName"
write-host "midServerVMNameHighAvailability = $midServerVMNameHighAvailability"
write-host "midServerAvailabilityZone = $midServerAvailabilityZone"
write-host "midServerHighAvailabilityAvailabilityZone = $midServerHighAvailabilityAvailabilityZone"
write-host "rootUserName = $rootUserName"
write-host "rootPassword = $rootPassword"
write-host "dXCMidServerNSGName = $dXCMidServerNSGName"
write-host "existingDXCVNETName = $existingDXCVNETName"
write-host "midServerSubnetName = $midServerSubnetName"
write-host "midServerSubnetAddressPrefix = $midServerSubnetAddressPrefix"
write-host "MidServerKeyVaultName = $MidServerKeyVaultName"
write-host "MidServerKeyVaultRG = $MidServerKeyVaultRG"
write-host "osVersion = $osVersion"
write-host "vmSize = $vmSize"
write-host "OSDiskType = $OSDiskType"
write-host "numberOfDataDisks = $numberOfDataDisks"
write-host "dataDiskType = $dataDiskType"
write-host "dataDiskSize = $dataDiskSize"
write-host "dataDiskHostCaching = $dataDiskHostCaching"
write-host "existingBootDiagStorageResourceGroup = $existingBootDiagStorageResourceGroup"
write-host "existingBootDiagStorageName = $existingBootDiagStorageName"
write-host "publicIPRequired = $publicIPRequired"
write-host "application = $application"
write-host "departmentName = $departmentName"
write-host "project = $project"
write-host "workspaceId = $workspaceId"
write-host "workspaceKey = $workspaceKey"
write-host "dxcEPAgent = $dxcEPAgent"
write-host "csCID = $csCID"
write-host "existingRecoveryServicesVaultRG = $existingRecoveryServicesVaultRG"
write-host "existingRecoveryServicesVault= $existingRecoveryServicesVault"
write-host "existingBackupPolicy = $existingBackupPolicy"
write-host "SNOWMidServerName = $SNOWMidServerName"
write-host "SNOWMidServerNameHighAvailability = $SNOWMidServerNameHighAvailability"
write-host "SNOWInstallUrl = $SNOWInstallUrl"
write-host "SNOWUrl = $SNOWUrl"
write-host "SNOWMidInstanceUserName = $SNOWMidInstanceUserName"
write-host "SNOWMidInstanceUserPassword = $SNOWMidInstanceUserPassword"
write-host "artifactsdev = $artifactsdev"
write-host "ArtifactsKeyVaultName = $ArtifactsKeyVaultName"
write-host "dxcPatchGroup = $dxcPatchGroup"

write-host "Are these the values you wish to proceed with? (Y/y to proceed, or N/n to quit)" -ForegroundColor Green -NoNewline
$Proceed=read-host 
if ($Proceed -ne "Y" -and $Proceed -ne "y") {
	exit
}
write-host

#Networking Provisioning
write-host "Creating NSG and Subnet for Mid Server/s" -ForegroundColor Green
try{
	New-AzResourceGroupDeployment -ResourceGroupName $DXCManagementResourceGroup -TemplateUri $CMPMidServerComplimentaryResourcesUri -networkSecurityGroups_DXC_MidServer_NSG_name $dXCMidServerNSGName -location $DXCManagementResourceGroupLocation -existingDXCVNETName $existingDXCVNETName -midServerSubnetName $midServerSubnetName -midServerSubnetAddressPrefix $midServerSubnetAddressPrefix -ErrorAction Stop
}
catch{
	write-host "Error Creating NSG and/or Subnet for Mid Server" -ForegroundColor Red
	$ErrorMessage = $_.Exception.Message
	write-host $ErrorMessage -ForegroundColor Red
	exit
}

#Primary Mid Server deployment
#-------------------------------------------
write-host "Deploying Primary Mid Server VM" -ForegroundColor Green
#Check if VM already exists - re-run of script catch
try{
	$existingVM = Get-AzVM -ResourceGroupName $DXCManagementResourceGroup -name $midServerVMName -ErrorAction Stop
	if ($existingVM.Name.Length -gt 0) 
	{
		$existingVMName = $existingVM.Name
		Write-Host "VM $existingVMName already exists. Exiting..."
		exit
	}
}
catch{}

try {
	New-AzResourceGroupDeployment -ResourceGroupName $DXCManagementResourceGroup -TemplateUri $linuxTemplateUri -rootUsername $rootUserName -rootPassword  (ConvertTo-SecureString -Force -AsPlainText $rootPassword) -KeyVaultName $MidServerKeyVaultName -KeyVaultRG $MidServerKeyVaultRG -osVersion $osVersion -vmName $midServerVMName -vmSize $vmSize -vmLocation $DXCManagementResourceGroupLocation -OSDiskType $OSDiskType -numberOfDataDisks $numberOfDataDisks -dataDiskType $dataDiskType -dataDiskSize $dataDiskSize -dataDiskHostCaching $dataDiskHostCaching -existingBootDiagStorageResourceGroup $existingBootDiagStorageResourceGroup -existingBootDiagStorageName $existingBootDiagStorageName -existingvNetResourceGroup $DXCManagementResourceGroup -existingvNetName $existingDXCVNETName -subnetName $midServerSubnetName -publicIPRequired $publicIPRequired -Availability $Availability -zone $midServerAvailabilityZone -application $application -departmentName $departmentName -project $project -workspaceId $workspaceId -workspaceKey $workspaceKey -dxcEPAgent $dxcEPAgent -csCID $csCID -existingRecoveryServicesVaultRG $existingRecoveryServicesVaultRG -existingRecoveryServicesVault $existingRecoveryServicesVault -existingBackupPolicy $existingBackupPolicy -dxcManaged $dxcManaged -dxcMonitored $dxcMonitored -dxcBackup $dxcBackup -dxcPatchGroup $dxcPatchGroup -ErrorAction Stop
	
}
catch{
	$ErrorMessage = $_.Exception.Message
	if ($ErrorMessage -notcontains "error retrieving the managed service access token")
	{
		write-host "Error Deploying Primary Mid Server VM" -ForegroundColor Red
		write-host $ErrorMessage -ForegroundColor Red
		exit
	}
}

#Execute SNOWInstaller.sh on Primary Mid Server
write-host "Execute SNOWInstaller.sh on Primary Mid Server and starting Mid Server application" -ForegroundColor Green
$InstallSuccess = $false
$Count = 0
Do {
	Try{
		Start-Sleep -s 30
		Invoke-AzVMRunCommand -ResourceGroupName $DXCManagementResourceGroup -Name $midServerVMName -CommandId 'RunShellScript' -ScriptPath (Join-Path (Get-Location).ProviderPath $SNOWInstallerScript) -Parameter @{"MidInstanceUsername"=$SNOWMidInstanceUserName;"MidInstancePassword"=$SNOWMidInstanceUserPassword;"SNOWMidServerName"=$SNOWMidServerName;"SNOWURL"=$SNOWUrl;"SNOWInstallUrlPath"=$SNOWInstallUrlPath;"SNOWInstallFileName"=$SNOWInstallFileName} -ErrorAction Stop
		$InstallSuccess = $true
	}
	Catch{
		$ErrorMessage = $_.Exception.Message
		if ($ErrorMessage.Contains("The operation requires the VM to be running"))
		{
			Write-Host "Waiting for Primary Mid Server to start up..." -ForegroundColor White
			$Count++
		}
		else
		{
			write-host "Error Executing SNOWInstaller.sh on Primary Mid Server and starting Mid Server application" -ForegroundColor Red
			Write-Host $ErrorMessage -ForegroundColor Red
			exit
		}
	}
} Until ($InstallSuccess -or ($Count -eq 10))

if ($InstallSuccess -eq $false -and $Count -ge 10)
{
	Write-Host "Primary Mid Server installation failed due to not being able to connect to the VM. - Timeout" -ForegroundColor Red
	exit
}
if ($InstallSuccess)
{
	Write-Host "Primary Mid Server installation completed!" -ForegroundColor Green
}

if ($HighAvailability -eq "True")
{
	#High Availability Secondary Mid Server deployment
	#-----------------------------------------------------
	write-host "Deploying High Availability Secondary Mid Server VM" -ForegroundColor Green
	#Check if VM already exists - re-run of script catch
	try{
		$existingVM = Get-AzVM -ResourceGroupName $DXCManagementResourceGroup -name $midServerVMNameHighAvailability -ErrorAction Stop
		if ($existingVM.Name.Length -gt 0) 
		{
			$existingVMName = $existingVM.Name
			Write-Host "VM $existingVMName already exists. Exiting..."
			exit
		}
	}
	catch{}

	try {
		New-AzResourceGroupDeployment -ResourceGroupName $DXCManagementResourceGroup -TemplateUri $linuxTemplateUri -rootUsername $rootUserName -rootPassword  (ConvertTo-SecureString -Force -AsPlainText $rootPassword) -KeyVaultName $MidServerKeyVaultName -KeyVaultRG $MidServerKeyVaultRG -osVersion $osVersion -vmName $midServerVMNameHighAvailability -vmSize $vmSize -vmLocation $DXCManagementResourceGroupLocation -OSDiskType $OSDiskType -numberOfDataDisks $numberOfDataDisks -dataDiskType $dataDiskType -dataDiskSize $dataDiskSize -dataDiskHostCaching $dataDiskHostCaching -existingBootDiagStorageResourceGroup $existingBootDiagStorageResourceGroup -existingBootDiagStorageName $existingBootDiagStorageName -existingvNetResourceGroup $DXCManagementResourceGroup -existingvNetName $existingDXCVNETName -subnetName $midServerSubnetName -publicIPRequired $publicIPRequired -Availability $Availability -zone $midServerHighAvailabilityAvailabilityZone -application $application -departmentName $departmentName -project $project -workspaceId $workspaceId -workspaceKey $workspaceKey -dxcEPAgent $dxcEPAgent -csCID $csCID -existingRecoveryServicesVaultRG $existingRecoveryServicesVaultRG -existingRecoveryServicesVault $existingRecoveryServicesVault -existingBackupPolicy $existingBackupPolicy -dxcManaged $dxcManaged -dxcMonitored $dxcMonitored -dxcBackup $dxcBackup -dxcPatchGroup $dxcPatchGroup -ErrorAction Stop
	}
	catch{
		$ErrorMessage = $_.Exception.Message
		if ($ErrorMessage -notcontains "error retrieving the managed service access token")
		{
			write-host "Error Deploying High Availability Secondary Mid Server VM" -ForegroundColor Red
			write-host $ErrorMessage -ForegroundColor Red
			exit
		}
	}

	#Execute SNOWInstaller.sh on High Availability Secondary Mid Server
	write-host "Execute SNOWInstaller.sh on High Availability Secondary Mid Server and starting Mid Server application" -ForegroundColor Green
	$InstallSuccess = $false
	$Count = 0
	Do {
		Try{
			Start-Sleep -s 30
			Invoke-AzVMRunCommand -ResourceGroupName $DXCManagementResourceGroup -Name $midServerVMNameHighAvailability -CommandId 'RunShellScript' -ScriptPath (Join-Path (Get-Location).ProviderPath $SNOWInstallerScript) -Parameter @{"MidInstanceUsername"=$SNOWMidInstanceUserName;"MidInstancePassword"=$SNOWMidInstanceUserPassword;"SNOWMidServerName"=$SNOWMidServerNameHighAvailability;"SNOWURL"=$SNOWUrl;"SNOWInstallUrlPath"=$SNOWInstallUrlPath;"SNOWInstallFileName"=$SNOWInstallFileName} -ErrorAction Stop
			$InstallSuccess = $true
		}
		Catch{
			$ErrorMessage = $_.Exception.Message
			if ($ErrorMessage.Contains("The operation requires the VM to be running"))
			{
				Write-Host "Waiting for High Availability Secondary Mid Server to start up..." -ForegroundColor White
				$Count++
			}
			else
			{
				write-host "Error Executing SNOWInstaller.sh on High Availability Secondary Mid Server and starting Mid Server application" -ForegroundColor Red
				Write-Host $ErrorMessage -ForegroundColor Red
				exit
			}
		}
	} Until ($InstallSuccess -or ($Count -eq 10))

	if ($InstallSuccess -eq $false -and $Count -ge 10)
	{
		Write-Host "High Availability Secondary Mid Server installation failed due to not being able to connect to the VM. - Timeout" -ForegroundColor Red
		exit
	}
	if ($InstallSuccess)
	{
		Write-Host "High Availability Secondary Mid Server installation completed!" -ForegroundColor Green
	}
}

Write-Host "Mid Server Installation Process Complete!"
