#!/bin/bash
# ----------------------------------------------------------
# Purpose:   Copy and configure SNOW connectivity on Mid Server
# Author:    Anthony Borucki 
# Date:      Apr 29th 2021

echo "################################################################" > /var/tmp/SNOWInstall.log
echo "Deployment date and Time: `date`" >> /var/tmp/SNOWInstall.log
echo "################################################################" >> /var/tmp/SNOWInstall.log
echo "SNOWURL = $SNOWURL" >> /var/tmp/SNOWInstall.log
echo "MidInstanceUsername = $MidInstanceUsername" >> /var/tmp/SNOWInstall.log
echo "MidInstancePassword = $MidInstancePassword" >> /var/tmp/SNOWInstall.log
echo "SNOWMidServerName = $SNOWMidServerName" >> /var/tmp/SNOWInstall.log
echo "SNOWInstallUrlPath = $SNOWInstallUrlPath" >> /var/tmp/SNOWInstall.log
echo "SNOWInstallFileName = $SNOWInstallFileName" >> /var/tmp/SNOWInstall.log

# Create Mid Server Folder
sudo mkdir -p /opt/ServiceNow/MidServer
echo "mkdir MidServer retcode ($?)" >> /var/tmp/SNOWInstall.log

# Install Unzip
# Mirror
mymirror="mirror.us.leaseweb.net"
cd /etc/apt/
sudo mkdir /tempfiles
echo "mkdir tempfiles retcode ($?)" >> /var/tmp/SNOWInstall.log

sudo cp sources.list /tempfiles/sources.list
echo "cp sources.list retcode ($?)" >> /var/tmp/SNOWInstall.log
sudo sed -i "s/http:/https:/g" sources.list
echo "sed http retcode ($?)" >> /var/tmp/SNOWInstall.log

sudo sed -i "s/azure.archive.ubuntu.com/$mymirror/g" sources.list
echo "sed /azure.archive.ubuntu.com retcode ($?)" >> /var/tmp/SNOWInstall.log
sudo sed -i "s/security.ubuntu.com/$mymirror/g" sources.list
echo "sed security.ubuntu.com retcode ($?)" >> /var/tmp/SNOWInstall.log
  
# Package
sudo apt-get update
echo "apt-get update retcode ($?)" >> /var/tmp/SNOWInstall.log
sudo apt-get install -y unzip
echo "Install unzip retcode ($?)" >> /var/tmp/SNOWInstall.log

# Download SNOW Install
cd /tempfiles 
sudo wget -P /tempfiles -O ${SNOWInstallFileName} "${SNOWInstallUrlPath}${SNOWInstallFileName}"
echo "Primary SNOW Download Operation retcode ($?)" >> /var/tmp/SNOWInstall.log

#Unzip Mid Server Zip to the target location
sudo unzip $SNOWInstallFileName -d /opt/ServiceNow/MidServer
echo "unzip SNOW Install File retcode ($?)" >> /var/tmp/SNOWInstall.log

#Configure Mid Server via config.xml changes
cd /opt/ServiceNow/MidServer/agent
sudo sed -i "s/YOUR_INSTANCE.service-now.com/$SNOWURL/g" config.xml
sudo sed -i "s/YOUR_INSTANCE_USER_NAME_HERE/$MidInstanceUsername/g" config.xml
sudo sed -i "s/YOUR_INSTANCE_PASSWORD_HERE/$MidInstancePassword/g" config.xml
sudo sed -i "s/YOUR_MIDSERVER_NAME_GOES_HERE/$SNOWMidServerName/g" config.xml
echo "modify config.xml ($?)" >> /var/tmp/SNOWInstall.log

#Modify mid.shconf_override with proper values for midserver
cd /opt/ServiceNow/MidServer/agent/bin
sudo sed -i "s/#APP_NAME/APP_NAME/g" mid.shconf_override
sudo sed -i "s/this_mid_app_name/$SNOWMidServerName/g" mid.shconf_override
sudo sed -i "s/RUN_AS_USER=/RUN_AS_USER=miduser/g" mid.shconf_override
sudo sed -i "s/PROMPT_BEFORE_OWNERSHIP_CHANGE=true/PROMPT_BEFORE_OWNERSHIP_CHANGE=false/g" mid.shconf_override
echo "modify mid.shconf_override ($?)" >> /var/tmp/SNOWInstall.log

#Run Mid Server to Run as Non Root User
sudo useradd miduser

#Install and Start Mid Server
sudo /opt/ServiceNow/MidServer/agent/bin/mid.sh install >> /var/tmp/SNOWInstall.log
sudo /opt/ServiceNow/MidServer/agent/bin/mid.sh start >> /var/tmp/SNOWInstall.log
