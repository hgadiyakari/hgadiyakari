#Script to verify Powershell version on Windows servers and update powershell version from 2.0 to 4.0

#Get PS version info
$PowerShellVersion = $PSVersionTable.PSVersion.Major.ToString() + "." + $PSVersionTable.PSVersion.Minor.ToString()
#Check PS version greater than or equal to 4
    if ($PSVersionTable.PSVersion.Major -ge 4) {
    exit
    }
	else 
    {

    #Storing patch in blob
    $PatchUrl = "https://dxcazuretoolsdev.blob.core.windows.net/installers/Windows6.1-KB2819745-x64-MultiPkg.msu"
    #Location to store the downloaded patch
    $PatchLocation = "C:\Windows\Temp\Windows6.1-KB2819745-x64-MultiPkg.msu"
    #Command to download patch from storage blob
    (New-Object System.Net.WebClient).DownloadFile($PatchUrl, $PatchLocation)
    #Installs patch on the server
    $Installer = Start-Process -FilePath WUSA.EXE -argumentlist "`"$PatchLocation`" /quiet /restart" -Wait -PassThru 
    #Write exit code
    Write-Host "The exit code is $($Installer.ExitCode)"

    }

  
    


