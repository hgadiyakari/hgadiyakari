#!/bin/bash
yum  install dmidecode -y
