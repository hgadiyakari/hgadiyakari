[CmdletBinding(SupportsShouldProcess=$true)]
Param
(
    [Parameter(Mandatory=$true)]
    $CID,
	[Parameter(Mandatory=$true)]
	$UninstallPW
)

$SanUrl = "https://dxcazuretoolsdev.blob.core.windows.net/installers/WindowsSensor.exe"
$SanLocation = "C:\Windows\Temp\WindowsSensor.exe"
$SanSwitches = "/install /quiet /norestart CID=" + $CID + ' PW="' + $UninstallPW + '"'

Write-Host "Downloading Crowdstrike Sensor installation file"
(New-Object System.Net.WebClient).DownloadFile($SanUrl, $SanLocation)

#Check for Windows 2019 or 2016
#Get OS Version
$osversion = (Get-WmiObject -class Win32_OperatingSystem).version
#If it's 2019 or 2016 attempt to disable defender
if(($osversion -like '*17763') -or ($osversion -like '*14393'))
{
    write-host "Windows 2019 or 2016 found"
    Write-Host "Disabling Windows Defender"
    Set-MpPreference -DisableRealtimeMonitoring $true
    $disableRTMsettingValue = (Get-MpPreference | Select-Object DisableRealtimeMonitoring).disablerealtimemonitoring
    if ($disableRTMsettingValue -eq $true){
	    Write-Host "disabling defender successful"
    } 
    else {
    	Write-Host "Disabling Defender failed, exiting with code 100"
    	Exit 100
    }
}


Write-Host "Installing Crowdstrike Sensor"
$Installer = Start-Process -FilePath $SanLocation -ArgumentList $SanSwitches -Wait -PassThru
Write-Host "The exit code is $($Installer.ExitCode)"
Exit $Installer.ExitCode
