﻿# Virtual Machine Deployment

This folder contains the json and powershell files that are used to deploy virtual machines within DXC Azure Managed Services

Virtual machines are deployed using different ARM templates. There is one ARM template for Windows VM and a separate template for each variant of Linux. 
Each supported OS ARM template now supports CIS Image deployments. See the Confluence page for a list of supported CIS Images

## Supported

Windows
CentOS
OracleLinux
RHEL
SUSE
Ubuntu

## Jira Epic
N/A

## Deployment
For more information on how to deploy VMs, please see:
Section 3.2.2 of Operations Guide

## Members of this directory are:
* AvailabilitySet.json						Internal ARM template not to be called directly 
* CrowdStrikeInstallerWithPassword.ps1		Crowdstrike Powershell Install script
* DXC_CentOS_OpenLogic_AllExt.json			VM ARM Template for CentOS
* DXC_CentOS_Parameters.json				Example Parameter file for CentOS
* DXC_OracleLinux_AllExt.json				VM ARM Template for OracleLinux
* DXC_OracleLinuxParms.json					Example Parameter file for OracleLinux
* DXC_RHEL_AllExt.json						VM ARM Template for RHEL
* DXC_RHEL_Parameters.json					Example Parameter file for RHEL
* DXC_SUSE_Sles_AllExt.json					VM ARM Template for SUSE
* DXC_SUSE_Sles_Parms.json					Example Parameter file for SUSE
* DXC_Ubuntu_AllExt.json					VM ARM Template for Ubuntu
* DXC_UbuntuParms.json						Example Parameter file for Ubuntu
* DXC_Win_AllExt.json						VM ARM Template for Windows
* DXC_WindowsParms.json						Example Parameter file for Windows
* ResourceGroup.json						ARM template to deploy a Resource Group
* UpgradePStoV4.ps1							Script to verify Powershell version on Windows servers and update powershell version from 2.0 to 4.0
* csInstaller.sh							Falcon Sensor Installer


## Authors

* Azure Engineering Team
