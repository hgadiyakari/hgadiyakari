#!/bin/bash
# ----------------------------------------------------------
# Purpose:   Falcon Sensor Installer
# Author:    Santanu Sengupta
# Date:      6th Dec 2018
# Author:    Miroslav Dimitrov (Kernel revert part)
# Date:      23rd Jan 2019
# Author:    Dalius Varkulevicius (OracleLinux support and Blob version merge)
# Date:      28rd Aug 2019
# Author:    Miroslav Dimitrov
# Date:      25th Oct. 2019 (falcon install on SLES15, kernel revert on SLES15)
# Author:    Harika Gadiyakari
# Date:      15th Nov. 2019 (yum rhui update on RHEL )
# Author:    Miroslav Dimitrov
# Date:      8th May 2020 (update crowdstrike installers to fix falcon sensors)
# Author:    Micah Castorina
# Date:		 9th Sept 2020 (updated crowdstrike installers and add CIS image support. Updated Suse 12 offer to SLES to match ARM)
# Author:    Natalie Paremski
# Date:		 17th Mar 2021 (updated falcon-sensor and kernel revert to support Ubuntu 20.04)
# Author:    Iain Babeu
# Date:      17th March 2021 (updated FALCONRPM selector so final else statement causes script to fail. AZR-21444)
# Author:    Amreen Islam
# Date:      30th March 2021 (Crowdstrike install , python2 install and kernel revert for SUSE15 SP1
# Author:    Kusuma Sesetti
# Date:      31th Mar 2021 (kernel revert on SUSE12 sp5)
# Author:    Kusuma Sesetti
# Date:      12th Apr 2021 (Updated Crowdstrike install , python2 install and kernel revert for SUSE12 SP5,SUSE15 SP1. AZR-17958 & AZR-18566)

# ----------------------------------------------------------
OSTYPE=$1
FALCONCID=$2

echo "################################################################" >> /var/tmp/CSfalcon.log
echo "Deployment date and Time: `date`" >> /var/tmp/CSfalcon.log
echo "################################################################" >> /var/tmp/CSfalcon.log

echo "################################################################" >> /var/tmp/kernelrevert.log
echo "Deployment date and Time: `date`" >> /var/tmp/kernelrevert.log
echo "################################################################" >> /var/tmp/kernelrevert.log

echo "################################################################" >> /var/tmp/rhelrepoupdate.log
echo "Deployment date and Time: `date`" >> /var/tmp/kernelrevert.log
echo "################################################################" >> /var/tmp/rhelrepoupdate.log

# Setting variables
BlobURL="https://dxcazuretoolsdev.blob.core.windows.net/installers/KernalSensors/"
DrBlobURL="https://dxcazuretoolsdr.blob.core.windows.net/installers/KernalSensors/"

#Note 'suse15' is not the product offer being past from ARM
if [[ $1 == ubuntuserver* ]] || [[ $1 == cis-ubuntu* ]] || [[ $1 == *ubuntu* ]]; then
	FALCONRPM="falcon-sensor_5.43.0-10807_amd64.deb"
elif [[ $1 ==  sles-15-sp1* ]] || [[ $1 ==  sles15* ]] ; then 
    FALCONRPM="falcon-sensor-5.43.0-10807.suse15.x86_64.rpm"
elif [[ $1 ==  sles2* ]] || [[ $1 == cis-suse-linux-12* ]] || [[ $1 == sles-12-sp5* ]] || [[ $1 ==  sles12* ]] ; then
    FALCONRPM="falcon-sensor-5.43.0-10807.suse12.x86_64.rpm"
elif [ $1 ==  'rhel6' ]  || [ $1 ==  'centos6' ] || [[ $1 == cis-centos-6* ]] || [[ $1 == oracle-linux6* ]] || [[ $1 == cis-oracle-linux-6* ]]; then
    FALCONRPM="falcon-sensor-5.38.0-10402.el6.x86_64.rpm"
elif [[ $1 ==  rhel7* ]] || [[ $1 == cis-rhel-7* ]] || [ $1 ==  'centos7' ] || [[ $1 == cis-centos-7* ]] || [[ $1 ==  oracle-linux7* ]] || [[ $1 == cis-oracle-linux-7* ]]; then
    FALCONRPM="falcon-sensor-5.38.0-10402.el7.x86_64.rpm"
elif [[ $1 ==  rhel8* ]] || [[ $1 == cis-rhel-8* ]] || [ $1 ==  'centos8' ] || [[ $1 == cis-centos-8* ]] || [[ $1 ==  oracle-linux8* ]] || [[ $1 == cis-oracle-linux-8* ]]; then
    FALCONRPM="falcon-sensor-6.12.0-10912.el8.x86_64.rpm"
elif [[ $1 == cis-rhel* ]]; then 
    FALCONRPM="falcon-sensor-5.38.0-10402.el6.x86_64.rpm"
else
	echo "Parameter osType is invalid. No FalconRPM selected."
	exit -1
fi

echo "OS Type Selected: $OSTYPE" >> /var/tmp/CSfalcon.log
echo "Falcon RPM Selected: $FALCONRPM" >> /var/tmp/CSfalcon.log

# Download prerequsite for OracleLinux
if [[ $1 ==  oracle-linux7* ]] || [[ $1 == oracle-linux6* ]] || [[ $1 == cis-oracle-linux-6* ]]; then
	yum install wget -y
   	echo "Oracle wget not found, then installed retcode ($?)" >> /var/tmp/CSfalcon.log
fi

# Download Falcon Sensor
wget -O ${FALCONRPM} "${BlobURL}${FALCONRPM}"
ErrorCode="$?"
echo "Primary Download Operation retcode (${ErrorCode})" >> /var/tmp/CSfalcon.log

if [ "$ErrorCode" -ne "0" ]; then
    wget -O ${FALCONRPM} "${DrBlobURL}${FALCONRPM}"
    echo "Dr Download Operation retcode ($?)" >> /var/tmp/CSfalcon.log
fi

#Suse Repo update and Linux Diagnostic Extension package requirement 
#Suse was not installing CS with the code below. This is a temporary workaround.
if [[ $1 ==  *sles* ]] || [[ $1 == cis-suse-linux-12* ]]; then
zypper --non-interactive addrepo https://download.opensuse.org/repositories/openSUSE:Leap:15.1:Update/standard/openSUSE:Leap:15.1:Update.repo
zypper mr --all -f
zypper --gpg-auto-import-keys ref
zypper install -y libgthread-2_0-0
fi

#Rhel 8 Python2 install and set as default
if [[ $1 ==  rhel8* ]] || [[ $1 == cis-rhel-8* ]] || [ $1 ==  'centos8' ] || [[ $1 == cis-centos-8* ]] || [[ $1 ==  oracle-linux8* ]] || [[ $1 == cis-oracle-linux-8* ]]; then
sudo yum install -y python2
sudo alternatives --set python /usr/bin/python2
fi
# Suse Python2
if [[ $1 ==  *sles* ]] || [[ $1 == cis-suse-linux-12* ]] || [[ $1 == sles-15-sp1* ]]; then
sudo zypper install -y python2
sudo update-alternatives --install /usr/bin/python python /usr/bin/python2 1
fi

# Install Falcon Sensor
if [[ $1 == ubuntuserver* ]] || [[ $1 == cis-ubuntu* ]]  || [[ $1 == *ubuntu* ]]; then
	sudo apt install libnl-genl-3-200
	echo "apt-get libnl-gen1-3-200 retcode ($?)" >> /var/tmp/CSfalcon.log
	sudo dpkg -i ${FALCONRPM}
	echo "Ubuntu installation Operation retcode ($?)" >> /var/tmp/CSfalcon.log
	sudo apt-get --force-yes -f install --yes --no-install-recommends --yes-upgrade
    echo "apt-get install retcode ($?)" >> /var/tmp/CSfalcon.log
elif [ $1 == 'suse15' ]; then
	rpm -ivh ${FALCONRPM}
	echo "SuSe Linux installation Operation rpm -ivh retcode ($?)" >> /var/tmp/CSfalcon.log
elif [[ $1 ==  *sles* ]] || [[ $1 == cis-suse-linux-12* ]] || [[ $1 == sles-15-sp1* ]]; then
    sudo zypper --non-interactive --no-gpg-checks install ${FALCONRPM}
	echo "SuSe Linux installation Operation rpm -ivh retcode ($?)" >> /var/tmp/CSfalcon.log
else
	yum -y --nogpgcheck localinstall ${FALCONRPM}
	echo "RHEL or CentOS or OracleLinux installation Operation retcode ($?)" >> /var/tmp/CSfalcon.log
fi

rm -f ${FALCONRPM}

# Configure Falcon Sensor
if [[ $1 ==  *rhel* ]] ||  [[ $1 == *centos* ]] || [[ $1 ==  *oracle* ]]; then
	setenforce 0
	sed -i "s/SELINUX=enforcing/SELINUX=permissive/g" /etc/sysconfig/selinux
	/opt/CrowdStrike/falconctl -s -f --cid=${FALCONCID}
	echo "RHEL or CentOS or OracleLinux configure CID retcode ($?)" >> /var/tmp/CSfalcon.log
	/opt/CrowdStrike/falconctl -s --feature=enableLog,disableLogBuffer --update	
	echo "RHEL or CentOS or OracleLinux configure Log settings retcode ($?)" >> /var/tmp/CSfalcon.log
	service falcon-sensor start
	echo "RHEL or CentOS or OracleLinux service falcon-sensor start retcode ($?)" >> /var/tmp/CSfalcon.log
	ErrorCode="$?"
		if [ "$ErrorCode" -ne "0" ]; then
			systemctl start falcon-sensor
			echo "RHEL or CentOS or OracleLinux systemctl start falcon-sensor retcode (${ErrorCode})" >> /var/tmp/CSfalcon.log
		fi	
    
elif [[ $1 ==  *sles* ]] || [[ $1 == cis-suse-linux-12* ]] || [[ $1 == sles-15-sp1* ]] ; then
	sudo /opt/CrowdStrike/falconctl -s --cid=${FALCONCID}
	sudo service falcon-sensor start	
else
	sudo /opt/CrowdStrike/falconctl -s --cid=${FALCONCID}
	echo "Configure CID retcode ($?)" >> /var/tmp/CSfalcon.log	
	sudo /opt/CrowdStrike/falconctl -s --feature=enableLog,disableLogBuffer --update
	echo "Configure Log settings retcode ($?)" >> /var/tmp/CSfalcon.log
	sudo systemctl start falcon-sensor
	sudo service falcon-sensor start
	echo "Service Start retcode ($?)" >> /var/tmp/CSfalcon.log
fi	
	
#rhelrepoupdate? Update
if [ $1 ==  'rhel6' ] || [[ $1 == cis-rhel-6* ]] || [[ $1 ==  rhel7* ]] || [[ $1 == cis-rhel-7* ]] || [ $1 ==  'centos6' ] || [[ $1 == cis-centos-6* ]]; then
yum update -y --disablerepo='*' --enablerepo='*microsoft*'
echo "rhelrepo update is successful" >> /var/tmp/yumrhuiupdate.log
fi
echo "OS Type Selected: $OSTYPE" >> /var/tmp/kernelrevert.log

# Kernel revert
echo "starting Ubuntu kernel revert prerequisite check" >> /var/tmp/kernelrevert.log
if [[ $1 == ubuntuserver16* ]] || [[ $1 == cis-ubuntu-linux-16* ]]; then
sudo apt-get update
echo "Ubuntu 16 detected, apt-get update operation" >> /var/tmp/kernelrevert.log
sudo cp /boot/grub/grub.cfg /boot/grub/grub.cfg-`date -I`
echo "backup grub operation" >> /var/tmp/kernelrevert.log
sudo apt-get install -y linux-image-4.4.0-141-generic linux-cloud-tools-4.4.0-141-generic
echo "install generic kernel operation" >> /var/tmp/kernelrevert.log
sudo sed -i 's/set default="0"/set default="Advanced options for Ubuntu>Ubuntu, with Linux 4.4.0-141-generic"/g' /boot/grub/grub.cfg
echo "set default kernel operation" >> /var/tmp/kernelrevert.log
sudo shutdown -r 1
echo "reboot operation" >> /var/tmp/kernelrevert.log

elif [[ $1 == ubuntuserver18* ]] || [[ $1 == cis-ubuntu-linux-18* ]]; then
sudo apt-get update
echo "Ubuntu 18 detected, apt-get update operation" >> /var/tmp/kernelrevert.log
sudo cp /boot/grub/grub.cfg /boot/grub/grub.cfg-`date -I`
echo "backup grub operation" >> /var/tmp/kernelrevert.log
sudo apt-get install -y linux-image-4.15.0-43-generic linux-cloud-tools-4.15.0-43-generic
echo "install generic kernel operation" >> /var/tmp/kernelrevert.log
sudo sed -i 's/set default="0"/set default="Advanced options for Ubuntu>Ubuntu, with Linux 4.15.0-43-generic"/g' /boot/grub/grub.cfg
echo "set default kernel operation" >> /var/tmp/kernelrevert.log
sudo shutdown -r 1
echo "reboot operation" >> /var/tmp/kernelrevert.log

elif [[ $1 == ubuntuserver20* ]] || [[ $1 == cis-ubuntu-linux-20* ]]  || [[ $1 == *com-ubuntu-server-focal* ]]; then
sudo apt-get update
echo "Ubuntu 20 detected, apt-get update operation" >> /var/tmp/kernelrevert.log
sudo cp /boot/grub/grub.cfg /boot/grub/grub.cfg-`date -I`
echo "backup grub operation" >> /var/tmp/kernelrevert.log
sudo apt-get install -y linux-image-5.4.0-66-generic linux-cloud-tools-5.4.0-66-generic
echo "install generic kernel operation" >> /var/tmp/kernelrevert.log
sudo sed -i 's/set default="0"/set default="Advanced options for Ubuntu>Ubuntu, with Linux 5.4.0-66-generic"/g' /boot/grub/grub.cfg
echo "set default kernel operation" >> /var/tmp/kernelrevert.log
sudo shutdown -r 1
echo "reboot operation" >> /var/tmp/kernelrevert.log
else
echo "no conditions for the Ubuntu kernel revert found" >> /var/tmp/kernelrevert.log
fi

echo "starting Suse kernel revert prerequisite check" >> /var/tmp/kernelrevert.log
if [ "$1" == "suse15" ]; then
kernelname=$(uname -r)
echo "current kernel is $kernelname retcode ($?)" >> /var/tmp/kernelrevert.log
	if [[ $kernelname  == *"azure"* ]]; then
	sudo zypper refresh
	echo "refreshing repositories retcode ($?)" >> /var/tmp/kernelrevert.log
	sudo zypper -n in kernel-default-4.12.14-150.35
	echo "reverting kernel retcode ($?)" >> /var/tmp/kernelrevert.log
	sudo shutdown -r 1
	echo "reboot operation" >> /var/tmp/kernelrevert.log
	fi

elif [[ $1 == sles2019* ]] || [[ $1 == cis-suse-linux-12* ]] || [[ $1 == sles-15-sp1* ]] || [[ $1 == sles15* ]] || [[ $1 == 'sles12-sp4' ]] || [[ $1 == 'sles12' ]]; then
kernelname=$(uname -r)
echo "current kernel is $kernelname retcode ($?)" >> /var/tmp/kernelrevert.log
	if [[ $kernelname  == *"azure"* ]]; then
	sudo zypper refresh
	echo "refreshing repositories retcode ($?)" >> /var/tmp/kernelrevert.log
	zypper -n in kernel-default
	echo "reverting kernel retcode ($?)" >> /var/tmp/kernelrevert.log
	sudo shutdown -r 1
	echo "reboot operation" >> /var/tmp/kernelrevert.log
	fi

elif [[ $1 == *12-sp5* ]] || [[ $1 == 'sles12-sp5' ]]; then
kernelname=$(uname -r)
echo "current kernel is $kernelname retcode ($?)" >> /var/tmp/kernelrevert.log
	if [[ $kernelname  == *azure* ]]; then
	echo "refreshing repositories retcode ($?)" >> /var/tmp/kernelrevert.log
	sudo zypper in -y kernel-default-4.12.14-122.63
	echo "reverting kernel retcode ($?)" >> /var/tmp/kernelrevert.log
	sudo shutdown -r 1
	echo "reboot operation" >> /var/tmp/kernelrevert.log
	fi
else
echo "no conditions for the Suse kernel revert found" >> /var/tmp/kernelrevert.log
fi
