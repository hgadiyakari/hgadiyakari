## Windows_2019_Datacener_VM_no_domain_join

## Supported

Windows 2019 ONLY

This json powershell file is used to deploy virtual machine within DXC Azure Managed Services

There is one ARM template for Windows 2019 VM deployment

Run in Powershell to deploy code:

1. Run command with json code file location as well as the parameters file:

New-AzResourceGroupDeployment -ResourceGroupName hub-spoke01 -TemplateFile 'C:\Blueprints\Windows_2019_Datacenter\Artifacts\bc8825f9-dbde-4863-b8a2-204585c89754.json' -TemplateParameterFile 'C:\Blueprints\Windows_2019_Datacenter\Artifacts\DXC_Windows_2019_Datacener_VM_no_domain_join_param.json'
