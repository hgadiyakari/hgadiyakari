#Requires -PSEdition Core
#Requires -Version 7.0
#Requires -Modules @{ ModuleName="Az"; ModuleVersion="3.1.0" }

param(
    [Parameter(Mandatory = $false)][string]$clientid,
    [Parameter(Mandatory = $false)][string]$clientkey,
    [Parameter(Mandatory = $false)][string]$tenantid,
    [Parameter(Mandatory = $false)][string]$subscription,

    # Only log missing VM's
    [Parameter(Mandatory = $false)][switch]$missing = $false,

    # logger parameters
    [Parameter(Mandatory = $false)][switch]$log = $false,
    [Parameter(Mandatory = $false)][string]$logName = "log4ps.log",
    [Parameter(Mandatory = $false)][string]$fatalColor = "DarkRed",
    [Parameter(Mandatory = $false)][string]$errorColor = "Red",
    [Parameter(Mandatory = $false)][string]$warnColor = "Yellow",
    [Parameter(Mandatory = $false)][string]$infoColor = "Green",
    [Parameter(Mandatory = $false)][string]$debugColor = "Cyan",
    [Parameter(Mandatory = $false)][string]$traceColor = "Magenta"
)

#################################################################
# logger variables
#################################################################
$executionPath = $null
$logRequired = $false
$logger = $null

#################################################################
# logger functions
#################################################################
Function initializeLogger() {

    $log4Console = '<LOG4PS level="debug">
        <APPENDER type="ConsoleAppender" name="ConsoleAppender" >
        <LAYOUT type="PatternLayout" pattern="[%lvl]: %log_data"/>
        </APPENDER>
        </LOG4PS> '

    $log4PS = '<LOG4PS level="debug">
        <APPENDER type="ConsoleAppender" name="ConsoleAppender" >
        <LAYOUT type="PatternLayout" pattern="[%lvl]: %log_data"/>
        </APPENDER>
        <APPENDER type="RollingFileAppender" name="log.log" maxFileSize="10240" maxBackupFiles="5">
        <LAYOUT type="PatternLayout" pattern="%d %t [%lvl]: %log_data"/>
        </APPENDER>
        </LOG4PS> '


    $parent = [System.IO.Path]::GetTempPath()
    [string] $name = [System.Guid]::NewGuid()
    $tmpDir = New-Item -ItemType Directory -Path (Join-Path $parent $name.replace('-', ''))
    New-Item -Path $tmpDir -Name "release" -ItemType "directory" | Out-Null
    New-Item -Path $tmpDir -Name "config" -ItemType "directory" | Out-Null
    $configDir = "{0}/{1}" -f $tmpDir.ToString().Trim(), 'config'
    New-Item -Path $configDir -Name "log4ps.xml" -ItemType "file" | Out-Null
    $configFile = "{0}/{1}" -f $configDir, 'log4ps.xml'
    $configFile = $configFile.replace('/', '\')
    Set-Alias -Scope GLOBAL -Name Logger -Value Logger

    Try {
        if ($log -eq $false) {
            $log4Console | Out-File $configFile
        }
        else {
            $log4PS | Out-File $configFile
            $logRequired = $true
        }
    }
    Catch {
        Write-Host "ERROR: Failure to set Config file.  Processing terminated." -ForegroundColor Red
        Remove-Item -LiteralPath $tmpDir -Force -Recurse 1>$null 2>$null 3>$null
        Remove-Item –path $configFile –recurse
    }

    # Finish up logger initialization
    $executionPath = Split-Path $script:MyInvocation.MyCommand.Path
    $global:logger = global:Logger;
    $global:logger.load($configFile, $logName, $logRequired, $executionPath);
    Remove-Item –path $configFile –recurse
}

Function destroyLogger() {
    $logger.Destroy();
    Remove-Variable -Name logger -Scope Global -Force
}


<#
#>
function global:ConsoleAppender {
    $obj = New-Object PSObject -Property @{        
        logFileName        = $null;
        logFileChildFolder = $null;
        logFileFolder      = $null;
        backupFolder       = $null;
        logFileFullPath    = $null;
        maxFileSize        = 10000;
        maxBackupFiles     = 0;
        layout             = $null;
        currentCount       = 0;
        currentFileName    = $null;
        currentFileSize    = 0;
    };
    
    $obj | Add-Member -MemberType ScriptMethod -Name load -Value {
    
        <#
            $dateString = Get-Date -format dd\_MM\_yyyy\_HH\_mm\_ss;
        #>        
        
    };       
    
    $obj | Add-Member -MemberType ScriptMethod -Name log -Value {
    
        param($data, $levelType);
        
        $dataToLog = $this.layout.FormatData($data, $levelType);       
        switch ($levelType) {
            'FATAL' { 
                Write-Host $dataToLog -ForegroundColor $fatalColor
            }
            'ERROR' {
                Write-Host $dataToLog -ForegroundColor $errorColor
            }
            'WARN' {
                Write-Host $dataToLog -ForegroundColor $warnColor
            }
            'INFO' {
                Write-Host $dataToLog -ForegroundColor $infoColor
            }
            'DEBUG' {
                Write-Host $dataToLog -ForegroundColor $debugColor
            }
            'TRACE' {
                Write-Host $dataToLog -ForegroundColor $traceColor
            }
            default {
                Write-Host $dataToLog -ForegroundColor WHITE
            }
        }
    };
    
    <#
        Function: Destroy
        Purpose: Destructor for the class
            
        Params: none
        Returns: none
    #>
    $obj | Add-Member -MemberType ScriptMethod -Name Destroy -Value {

        $this.logFileName = $null;
        $this.logFileChildFolder = $null;
        $this.logFileFolder = $null;
        $this.backupFolder = $null;
        $this.logFileFullPath = $null;
        $this.layout = $null;
        $this.currentFileName = $null; 

    };
        
    <#
        Return object closure
    #>
    return $obj;
}
<#
    Modeled after log4j logger.
#>
function global:Logger {
    $obj = New-Object PSObject -Property @{
    
        className    = $MyInvocation.MyCommand.Name;
        appenders    = @();
        mainLogLevel = 0;
        level        = @{DEBUG = 0; INFO = 1; WARN = 2; ERROR = 3; FATAL = 4 };
        
    };
    
    $obj | Add-Member -MemberType ScriptMethod -Name CallAppenders -Value {
    
        param($data, [int]$levelHeight, $levelType);
        
        if ($levelHeight -ge $this.mainLogLevel) {
            foreach ($appender in $this.appenders) {
                $appender.log($data, $levelType);
            }    
        }
    
    };
    
    $obj | Add-Member -MemberType ScriptMethod -Name debug -Value {
    
        param([string]$data);
        
        $this.CallAppenders($data, $this.level.DEBUG, "DEBUG");
    };

    $obj | Add-Member -MemberType ScriptMethod -Name trace -Value {
    
        param([string]$data);
        
        $this.CallAppenders($data, $this.level.TRACE, "TRACE");
    };
    
    $obj | Add-Member -MemberType ScriptMethod -Name info -Value {
    
        param([string]$data);
        
        $this.CallAppenders($data, $this.level.INFO, "INFO");
    };
    
    $obj | Add-Member -MemberType ScriptMethod -Name warn -Value {
    
        param([string]$data);
        
        $this.CallAppenders($data, $this.level.WARN, "WARN");
    };
    
    $obj | Add-Member -MemberType ScriptMethod -Name error -Value {
    
        param([string]$data);
        
        $this.CallAppenders($data, $this.level.ERROR, "ERROR");
        
    };
    
    $obj | Add-Member -MemberType ScriptMethod -Name fatal -Value {
    
        param([string]$data);
        
        $this.CallAppenders($data, $this.level.FATAL, "FATAL");

    };
    
    $obj | Add-Member -MemberType ScriptMethod -Name load -Value {
    
        param($logFileConfigPath, $logFileName, $logRequired, $executionPath);

        [xml]$config = Get-Content $logFileConfigPath;
        $log4psNode = $config.LOG4PS;
        $defaultLevel = $log4psNode.getAttribute("level");
        $defaultLevel = $defaultLevel.ToUpper();
        
        switch ($defaultLevel) {
            "DEBUG" { $this.mainLogLevel = $this.level.DEBUG; };
            "TRACE" { $this.mainLogLevel = $this.level.TRACE; };
            "INFO" { $this.mainLogLevel = $this.level.INFO; };
            "WARN" { $this.mainLogLevel = $this.level.WARN; };
            "ERROR" { $this.mainLogLevel = $this.level.ERROR; };
            "FATAL" { $this.mainLogLevel = $this.level.FATAL; };            
        };
        
        $appenders = $log4psNode.selectNodes("APPENDER");
        foreach ($appender in $appenders) {
            $type = $appender.getAttribute("type");
            $name = $appender.getAttribute("name");
            $maxFileSize = $appender.getAttribute("maxFileSize");
            $maxBackupFiles = $appender.getAttribute("maxBackupFiles");
            $appenderInstance = & (Get-Item function:$type);
            $logFilePath = $logFileConfigPath.replace("\config\log4ps.xml", "");

            if ($logRequired -eq $true) {
                $logFilePath = $executionPath + "\logs\";
            }
            else {
                $logFilePath = $logFilePath + "\logs\";
            }

            $appenderInstance.logFileFolder = $logFilePath;            
            if (!$logFileName) {
                $appenderInstance.logFileName = $name;
            }
            else {
                $appenderInstance.logFileName = $logFileName;
            }
                        
            $appenderInstance.maxFileSize = $maxFileSize;
            $appenderInstance.maxBackupFiles = $maxBackupFiles;
            
            $layout = $appender.selectSingleNode("LAYOUT");
            $type = $layout.getAttribute("type");
            $pattern = $layout.getAttribute("pattern");
            
            $layoutInstance = & (Get-Item function:$type);
            $layoutInstance.pattern = $pattern;
            
            $appenderInstance.layout = $layoutInstance;
            
            $appenderInstance.load();
            
            $this.appenders += $appenderInstance;          
        }
        
    };
    
    $obj | Add-Member -MemberType ScriptMethod -Name SendEmail -Value {
    
        param([string]$emailFrom, [string]$emailTo, [string]$smtpServer, [string]$subject, [string]$body);
     
        $smtp = new-object Net.Mail.SmtpClient($smtpServer);
        $smtp.Send($emailFrom, $emailTo, $subject, $body);

    };

    <#
        Function: Destroy
        Purpose: Destructor for the class
            
        Params: none
        Returns: none
    #>
    $obj | Add-Member -MemberType ScriptMethod -Name Destroy -Value {
        
        $this.appenders = $null;

    };
        
    <#
        Return object closure
    #>
    return $obj;
}
<#
#>
function global:PatternLayout {
    $obj = New-Object PSObject -Property @{
    
        pattern = $null;
        
    };
    
    $obj | Add-Member -MemberType ScriptMethod -Name FormatData -Value {
    
        param($data, $levelType);
        
        $dateString = Get-Date -format dd/MM/yyyy;
        $timeString = Get-Date -format HH:mm:ss;
        $ret = $this.pattern.replace("%d", $dateString);
        $ret = $ret.replace("%t", $timeString);
        $ret = $ret.replace("%lvl", $levelType);
        $ret = $ret.replace("%log_data", $data);
        
        return $ret;
        
    };

    <#
        Function: Destroy
        Purpose: Destructor for the class
            
        Params: none
        Returns: none
    #>
    $obj | Add-Member -MemberType ScriptMethod -Name Destroy -Value {
        
        $this.pattern = $null;
        
    };
        
    <#
        Return object closure
    #>
    return $obj;
}
<#
#>
function global:RollingFileAppender {
    $obj = New-Object PSObject -Property @{
    
        logFileName        = $null;
        logFileChildFolder = $null;
        logFileFolder      = $null;
        backupFolder       = $null;
        logFileFullPath    = $null;
        maxFileSize        = 10000;
        maxBackupFiles     = 0;
        layout             = $null;
        currentCount       = 0;
        currentFileName    = $null;
        currentFileSize    = 0;
        
    };
    
    $obj | Add-Member -MemberType ScriptMethod -Name load -Value {
    
        <#
            $dateString = Get-Date -format dd\_MM\_yyyy\_HH\_mm\_ss;
        #>
        
        if (!$this.logFileChildFolder) {
            $this.logFileFullPath = $this.logFileFolder + $this.logFileName;
        }
        else {
            $this.logFileFullPath = $this.logFileFolder + $this.logFileChildFolder + "\" + $this.logFileName;
        }
        
        if (!(Test-Path -path $this.logFileFolder)) {
            New-Item -path $this.logFileFolder -type directory 1>$null 2>$null 3>$null
        }
        
        if ($this.logFileChildFolder) {
            $p = $this.logFileFolder + "\" + $this.logFileChildFolder;
            if (!(Test-Path -path $p)) {
                New-Item -path $p -type directory 1>$null 2>$null 3>$null
            }
        }
        
        $this.backupFolder = $this.logFileFolder + "backup";
        if (!(Test-Path -path $this.backupFolder)) {
            New-Item -path $this.backupFolder -type directory 1>$null 2>$null 3>$null
        }
        
        if (!(Test-Path -path $this.logFileFullPath)) {
            New-Item $this.logFileFullPath -type file 1>$null 2>$null 3>$null
        }
        else {
            $this.currentFileSize = (Get-ChildItem -path $this.logFileFullPath | Select-Object Length).Length;
        }
        
        $this.currentCount = $this.DetermineCurrentLogCount();
        
    };
    
    $obj | Add-Member -MemberType ScriptMethod -Name DetermineCurrentLogCount -Value {
    
        $currentLogCount = 1;
        
        
        if ((Test-Path $this.backupFolder)) {
            $fileCount = (Get-ChildItem $this.backupFolder | Measure-Object).Count;
            if ($fileCount -lt $this.maxBackupFiles) {
                $currentLogCount = $fileCount + 1;
            }
        }
        
        return $currentLogCount;
    
    };
    
    $obj | Add-Member -MemberType ScriptMethod -Name WeCanLog -Value {
    
        param([int]$dataToLogSize);
        
        $ret = $false;
        $this.currentFileSize = $this.currentFileSize + $dataToLogSize;
        
        if ([int]$this.currentFileSize -lt ([int]$this.maxFileSize * 1024)) {
            $ret = $true;
        }
        
        return $ret;
        
    };
    
    $obj | Add-Member -MemberType ScriptMethod -Name RollLogFile -Value {
            
        if ($this.currentCount -le $this.maxBackupFiles) {      
            $ext = "_" + $this.currentCount + ".log";
            $dest = $this.backupFolder + "\" + $this.logFileName.replace(".log", $ext);
            Move-Item $this.logFileFullPath $dest -force 1>$null 2>$null 3>$null
            
            $this.currentCount++;
        }
        else {
            $ext = "_1" + ".log";
            $dest = $this.backupFolder + "\" + $this.logFileName.replace(".log", $ext);
            Move-Item $this.logFileFullPath $dest -force 1>$null 2>$null 3>$null
            $this.currentCount = 2;
        }
        
        $this.currentFileSize = 0;
    
    };
    
    $obj | Add-Member -MemberType ScriptMethod -Name log -Value {
    
        param($data, $levelType);
        
        $dataToLog = $this.layout.FormatData($data, $levelType);
        
        if (!$this.WeCanLog(($dataToLog.length + 2))) {
            $this.RollLogFile();
        }
        
        Add-Content -path $this.logFileFullPath -value $dataToLog;
    
    };
    
    <#
        Function: Destroy
        Purpose: Destructor for the class
            
        Params: none
        Returns: none
    #>
    $obj | Add-Member -MemberType ScriptMethod -Name Destroy -Value {
        
        $this.logFileName = $null;
        $this.logFileChildFolder = $null;
        $this.logFileFolder = $null;
        $this.backupFolder = $null;
        $this.logFileFullPath = $null;
        $this.layout = $null;
        $this.currentFileName = $null;
        
    };
        
    <#
        Return object closure
    #>
    return $obj;
}
Function validateLoggerColors() {
    $colors = @("Black", "DarkBlue", "DarkGreen", "DarkCyan", "DarkRed", "DarkMagenta", "DarkYellow",
        "Gray", "DarkGray", "Blue", "Green", "Cyan", "Red", "Magenta", "Yellow", "White" 
    );
    if ($null -ne ($fatalColor | ? { $colors -match $_ })) {
    }
    else {
        Write-Host "Fatal color selected ($fatalColor) is not available."
        Exit
    }
    if ($null -ne ($errorColor | ? { $colors -match $_ })) {
    }
    else {
        Write-Host "Error color selected ($errorColor) is not available."
        Exit
    }
    if ($null -ne ($warnColor | ? { $colors -match $_ })) {
    }
    else {
        Write-Host "Warn color selected ($warnColor) is not available."
        Exit
    }

    if ($null -ne ($infoColor | ? { $colors -match $_ })) {
    }
    else {
        Write-Host "Info color selected ($infoColor) is not available."
        Exit
    }
    if ($null -ne ($debugColor | ? { $colors -match $_ })) {
    }
    else {
        Write-Host "Debug color selected ($debugColor) is not available."
        Exit
    }
    if ($null -ne ($traceColor | ? { $colors -match $_ })) {
    }
    else {
        Write-Host "Trace color selected ($traceColor) is not available."
        Exit
    }
}
#################################################################
# end logger functions
#################################################################


Function getCredentials {
    $shell = (Get-ChildItem Env:AZURE_HTTP_USER_AGENT).Value  2>$null 3>$null

    if ($shell -eq "" -or $null -eq $shell ) {
    }
    else {
        $logger.info(" ") 
        $logger.info("Running under Azure Cloud Shell") 
        $logger.info(" ") 
        if ($null -eq $subscription -or $subscription -eq "") {
            return
        }
        setSubscription
        return
    }

    # Just need to check one of the service principal variables to assume it is valid
    if ($null -ne $clientid -and $clientid -ne "") {
        $error.Clear()
        $passwd = ConvertTo-SecureString $clientkey -AsPlainText -Force
        $pscredential = New-Object System.Management.Automation.PSCredential($clientid, $passwd)
        Connect-AzAccount -ServicePrincipal -Credential $pscredential -TenantId $tenantid   1>$null 2>$null 3>$null

        if ($error) {
            $logger.fatal("Unable to connect to Azure. Check your Service Principal variables to ensure they are correct and valid.")
            destroyLogger
            exit
        }
        else {
            $logger.info(" ")
            $logger.info("Connected to Azure with submitted Service Principal")
            $logger.info(" ") 
            if ($null -eq $subscription -or $subscription -eq "") {
                return
            }
            setSubscription
            return
        }
    }
    # check if we are currently connected and use that if possible
    $currentLogin = (Get-AzContext).Account.Id
    if ($currentLogin -ne "" -and $null -ne $currentLogin) {
        $logger.info(" ")
        $logger.info("Running with current logged on account")
        $logger.info(" ")
        if ($null -eq $subscription -or $subscription -eq "") {
            return
        }
        setSubscription
        return
    }
    # apparently no other connection options are available, so force an Azure connect
    Connect-AzAccount
    $currentLogin = (Get-AzContext).Account.Id
    if ($currentLogin -eq "" -or $null -eq $currentLogin) {
        $logger.fatal("Unable to determine connection status.  Please re-run and connect with valid credentials.")
        destroyLogger
        exit  
    }
    $subscriptionId = Read-Host "Please enter the subscriptionID"
    if ($null -ne $subscriptionId -and $subscriptionId -ne "") {
        Select-AzSubscription -Subscription  "$subscriptionId" 1>$null 2>$null 3>$null
        $logger.info(" ") 
        $logger.info("Running with new login on account") 
        $logger.info(" ") 
    }
    else {
        $logger.fatal("Unable to determine the subscription required.  Please re-run and submit valid subscription when prompted.")
        destroyLogger
        exit
    }
}

Function setSubscription {
    # If subscription was not entered, then we don't need to be here 
    if ($null -eq $subscription -or $subscription -eq "") {
        # Get subscription ID that we are currently running under
        $subscription_id = Get-AzContext
        # Check if more than one subscription has been returned.
        $subscriptionCheck = $subscription_id.Subscription -split ' '
        if ($subscriptionCheck.Count -gt 1) {
            $logger.fatal(" ")
            $logger.fatal("Multiple subscriptions found.  Please run again with '-subscription' parameter to set a default subscription")
            destroyLogger
            Exit
        }
        return
    }
    $found = $false
    # Get all subscriptions we currently have access to           
    $subscriptions = Get-AzContext -ListAvailable
    $subscriptions.Name | ForEach-Object {
        $sub = ($_ -split "\(|\)")[1]
        if ($sub -eq $subscription) {
            $found = $true
        }
    }		

    if ($found -eq $true) {
        $logger.info(" ")
        $logger.info("Setting connection subscription to: $subscription")
        Select-AzSubscription -Subscription  "$subscription" 1>$null 2>$null 3>$null
    }
    else {
        $logger.fatal("Requested subscription $subscription is not contained in your connection context")
        destroyLogger
        Exit
    }
}


#####################################################################################################
#                                               MAIN                                                #
#####################################################################################################
$vmHash = @{}
$label1 = "VM: "
$label2 = " has boot diagnostics on:"
$with = 0
$without = 0

initializeLogger
$logger = $global:logger

# Get started with isBootDiagnostics processing
getCredentials

$logger.info("#########################################################################")
$logger.info("#         Result of boot diagnostics on VM's in subscription            #")
if ($missing -eq $true) {
    $logger.info("#        Reporting only VMs that do not have boot diagnostics           #")
}$logger.info("#########################################################################")

$VMs = Get-AzVM 
foreach ($VM in $VMs) {
    $vmname = $VM.Name
    $installed = ""
    if ($VM.DiagnosticsProfile.BootDiagnostics.Enabled -eq $true) {
        $installed = " yes"
        $with++
        if ($missing -eq $true) {
            continue
        }
    }
    else {
        $installed = " no"
        $without++
    }
    $vmHash.add($vmname, $installed)
}

$sHash = $vmHash.GetEnumerator() | Sort-Object Name
foreach ($h in $sHash.GetEnumerator()) {   
    if ($missing -eq $true) {
        $line = $h.Key
        $logger.info($line)
    }
    else {
        $line = $label1
        $vmname = $h.Key
        if ($vmname.Length -gt 25) {
            $vmname = $vmname.Substring(0, 25) + '...'
        }
        $line = $line + $vmname + (" " * (33 - $vmname.Length))
        $line = $line + $label2 
        $installed = $h.Value
        $line = $line + $installed + (" " * (10 - $installed.Length))
        if ($installed -match "yes") {
            $logger.info($line)
        }
        else {
            $logger.warn($line)
        }
    }
}
$logger.info(" ")
$logger.info("Count of VM's with boot diagnostics on: $with")
$logger.info("Count of VM's without boot diagnostics on: $without")
$total = $with + $without
$logger.info("Total number of VM's in subscription: $total")
destroyLogger