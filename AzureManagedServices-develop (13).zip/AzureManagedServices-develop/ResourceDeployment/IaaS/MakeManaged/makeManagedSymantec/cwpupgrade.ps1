﻿<#
This script upgrade VMs CWP agents to version 3.1.


Version 1.0 - 10-1-2020
Author: Micah Castorina
Notes: Running this script will prompt user to enter Symantec Parameters for CWP installation. 
The script will scan the entire subscription for running Windows Virtual Machines with a CWP extension older than 3.1, remove and upgrade the extension and reboot the VM.

Version 1.1
* Added ability to specify ResourceGroup and/or VM name
- Added default reboot to No, to force reboot user needs to add parameter $forceReboot and set to "yes"
#>

# Enter Information for Windows CWP installation 
param(
	[Parameter(Mandatory = $true)] $cwpdomainid,
	[Parameter(Mandatory = $true)] $cwpCustomerID,
	[Parameter(Mandatory = $true)] $cwpclientID,
    [Parameter(Mandatory = $true)] $Customerkey,
    [Parameter(Mandatory = $true)] $clientkey,
    [Parameter(Mandatory = $true)] $ResourceGroup,
    [Parameter(Mandatory = $true)] $VMname,
    [Parameter(Mandatory = $false)][String] $forceReboot = "no"
)

# Combines CWP Parameters for deployment
$settings = @{"domainId"=$cwpdomainid; "customerId"= $cwpCustomerID; "clientId"= $cwpclientID; "forceReboot"= $forceReboot};
$protectedSettings = @{"customerSecretKey"= $Customerkey; "clientSecretKey"= $clientkey};

$command = 'Get-AzVM'
#if user specified resource group then inc it in the command

Write-Host $ResourceGroup
if ($ResourceGroup) { $command = $command + " -resourcegroupname " + $ResourceGroup }

#if user specified the vm name then inc it in the command
if ($VMname) { $command = $command + " -name " + $VMname }

$command = $command + '| Where-Object {$_.StorageProfile.OSDisk.OSType -eq "Windows"}'

Write-Host "Executing " $command
$vms = Invoke-Expression $command

foreach ($vm in $vms)
    {
    $T=get-date 
    Write-Host $T "Checking CWP Extension version on RG:" $vm.resourcegroupname " VM:" $vm.name -ForegroundColor DarkGreen   
    $cwpcheck = get-azvmextension -resourcegroupname $vm.resourcegroupname -vmname $vm.name | where {($_.extensiontype -match "scwpagentforwindows") -and ($_.typehandlerversion -ne "3.1")}

    if ($cwpcheck -ne $null) {
        Write-Host $T "Checking running state on RG:" $vm.resourcegroupname " VM:" $vm.name  -ForegroundColor Green
        $vs=get-azvm -name $vm.name -ResourceGroupName $vm.resourcegroupname -status
        if ($vs.Statuses.code -match "running"){   
#            Write-Host $T "Removing existing agent SCWPAgentForWindows on RG:" $vm.resourcegroupname " VM:" $vm.name  -ForegroundColor Cyan
#            Remove-AzVMExtension -VMName  $vm.name  -ResourceGroupName $vm.resourcegroupname -Name "SCWPAgentForWindows" -force
            Write-Host $T "Upgrading CWP on RG:" $vm.resourcegroupname " VM:" $vm.name " forceReboot:" $forceReboot -ForegroundColor Cyan
            Set-AzVMExtension -VMName $vm.name -ResourceGroupName $vm.resourcegroupname -Location $vm.location -Publisher Symantec.CloudWorkloadProtection -ExtensionName SCWPAgentForWindows -ExtensionType SCWPAgentForWindows -Version 3.1 -Settings $settings -ProtectedSettings $protectedSettings
          }
     } 
}


