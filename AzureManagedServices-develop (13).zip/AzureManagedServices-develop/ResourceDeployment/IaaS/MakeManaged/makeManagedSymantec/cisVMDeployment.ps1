﻿

#Install the Az module if you haven't done so already.
#Install-Module Az
 
#Login to your Azure account.
#Connect-AzAccount
 
#Define the following parameters for the virtual machine.For multiple deployments # out $vmcredential and and run $vmcredential = Get-Credential only once.
#$vmCredential = Get-Credential

#version 1.0 - script creates a basic VM with a public IP address
#Version 1.1 - Creted a condition to detect CIS Publisher, offer, sku



param(
        [Parameter(Mandatory = $true)][string]$ostype,
        [Parameter(Mandatory = $false)][string]$vMLocalAdminUser= "sysadmin",
        [Parameter(Mandatory = $false)][string]$vmLocalAdminPassword= "C0mpl3x$11!",
        [Parameter(Mandatory = $true)][string]$vmComputerName,
        [Parameter(Mandatory = $false)][string]$location="central us",
        [Parameter(Mandatory = $false)][string]$resourceGroup= "mc-cisimagedev-rg",
        [Parameter(Mandatory = $false)][string]$vmSize="Standard_B2s",
        [Parameter(Mandatory = $false)][string]$vnetRG= "mc-cisimagedev-rg",
        [Parameter(Mandatory = $false)][string]$vnetName  = "mc-cisimagedev-vnet",
        [Parameter(Mandatory = $false)][string]$vnetSubnetName        = "subnet1",
        [Parameter(Mandatory = $true)][string]$vmPublisherName,
        [Parameter(Mandatory = $true)][string]$vmSKU,
        [Parameter(Mandatory = $true)][string]$vmOffer,
        [Parameter(Mandatory = $true)][string]$version
        
)




#$VMLocalAdminUser = "smadmin"
#$VMLocalAdminSecurePassword = ConvertTo-SecureString "myPass@word123#" -AsPlainText -Force
$vMLocalAdminSecurePassword = ConvertTo-SecureString $vMLocalAdminPassword -AsPlainText -Force
#$vmCredential = New-Object System.Management.Automation.PSCredential ($vMLocalAdminUser, $vMLocalAdminSecurePassword)
#$vmComputerName = "dxcbbcent72217"
 
#Define the following parameters for the Azure resources.
#$location              = "eastus"
#$ResourceGroup         = "dxc-bb-ea2-eastus-azr-12503-rg"
$vmName                = $vmComputerName
$vmOsDiskName          = $vmname+"osdisk"
#$vmSize                = "Standard_B1ms"
 
#Define the networking information.
$nicName               = $vmname+"nic"
$publicIpName          = $VmName + "-publicIP"
 
#Define the existing VNet information.
#$vnetRG = "dxc-bb-ea2-eastus-networks-rg"
#$vnetName              = "dxc-bb-ea2-eastus-vnet"
#$vnetSubnetName        = "dxcbbea2eastussubnet"
 
#Define the VM marketplace image details.
#$vmPublisherName = "center-for-internet-security-inc"
#$VmOffer = "cis-centos-7-v2-1-1-l1"
#$VmSkus = "cis-centos7-l1"
#$version     = "2.2.17"
 
Write-Host "Deploying VM " $vmName
$rgexists = get-azresourcegroup -Name $resourceGroup -ea 0
if($null -eq $rgexists){
  Write-Host "`nERROR: The Resource Group " $resourceGroup " is not present, exiting" -ForegroundColor Red
  exit
}

#Get the subnet details for the specified virtual network + subnet combination.
$vnetSubnet = (Get-AzVirtualNetwork -Name $vnetName -ResourceGroupName $vnetRG).Subnets | Where-Object {$_.Name -eq $vnetSubnetName}
 
#Create the public IP address.
$publicIp = New-AzPublicIpAddress -Name $publicIpName -ResourceGroupName $resourceGroup -Location $location -AllocationMethod Dynamic
 
#Create the NIC and associate the public IpAddress.
$nic = New-AzNetworkInterface -Name $nicName -ResourceGroupName $resourceGroup -Location $location -SubnetId $vnetSubnet.Id -PublicIpAddressId $publicIp.Id

 
#Define the parameters for the new virtual machine.
$virtualMachine = New-AzVMConfig -VMName $vmName -VMSize $vmSize
#Set-AzVMPlan is used for accepting 3rd party Marketplace VMs. Plan must be enabled on the subscription.
#$virtualMachine = Set-AzVMOperatingSystem -VM $VirtualMachine -$os -ComputerName $vmComputerName -Credential $vmCredential -ProvisionVMAgent -EnableAutoUpdate
if ($ostype -eq 'windows')
{
    $virtualMachine = Set-AzVMOperatingSystem -VM $virtualMachine -Windows -ComputerName $vmComputerName -Credential $VMCredential
} else {
    $virtualMachine = Set-AzVMOperatingSystem -VM $virtualMachine -Linux -ComputerName $vmComputerName -Credential $VMCredential
}
$virtualMachine = Set-AzVMSourceImage -VM $virtualMachine -PublisherName $vmPublisherName -Offer $vmOffer -Skus $vmSKU -Version $version
$virtualMachine = Set-AzVMOSDisk -VM $virtualMachine -StorageAccountType "Standard_LRS" -Caching ReadWrite -Name $vmOsDiskName -CreateOption FromImage
$virtualMachine = Add-AzVMNetworkInterface -VM $virtualMachine -Id $nIC.Id

#Sets CIS Plan
if ($vmPublisherName -eq 'center-for-internet-security-inc')
{
$virtualMachine = Set-AzVMPlan -VM $virtualmachine -Publisher $vmPublisherName -Product $vmOffer -Name $vmSKU
}
 
#Create the virtual machine.
New-AzVM -ResourceGroupName $resourceGroup -Location $location -VM $virtualMachine -Verbose
