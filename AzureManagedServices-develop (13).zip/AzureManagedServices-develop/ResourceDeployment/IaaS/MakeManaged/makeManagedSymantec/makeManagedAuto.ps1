#Requires -PSEdition Core
#Requires -Version 7.1.3
#Requires -Modules @{ ModuleName="Az"; ModuleVersion="3.1.0" }

<#
.SYNOPSIS
Run makeManaged ARM template on VM.
.DESCRIPTION
This powershell will determined required parameters and run a makeManaged ARM template on the requested VM
(identified by vmname parameter).
.PARAMETER clientid
(Required if run from command line) The userid from a service principal on the subscription.
.PARAMETER clientkey
(Required if run from command line) The password of the service principal.
.PARAMETER tenantid
(Required if run from command line) The tenantid of the service principal.
.PARAMETER vmname
(Required) The name of the VM to run the makeManaged ARM template against.
(Assumption that the VM name will be unique across a given subscription)
.PARAMETER subscription         
(Optional) The name of the subscription this session is to be running under.  If 
not entered, then the default subscription for the type of login used will be used.
This does not apply if the user is prompted for a login.          
.PARAMETER resourcegroup or rg
(Optional) The name of the resource group that contains the VM to be managed.
(This is to allow for duplicate VM names in a given subscription.  If not entered
this script will use the first one returned from a get VM call)
.PARAMETER keyvault
(Required) The name of a keyvault that contains the additional information required
to run the ARM template. This currently contains subscription wide variables.
.SWITCH noazurebackup
(Optional) Switch used to not install azurebackup.  Without this switch,
the default is to install azurebackup.
.SWITCH noomsmonitoring
(Optional) Switch used to not install omsmonitoring extension.  Without
this switch, the default is to install omsmonitoring.
.SWITCH nodiagnosticextension
(Optional) Switch used to not install the diagnostic extension.  Without
this switch, the default is to install the diagnostic extension.
.SWITCH nobootdiagnostics
(Optional) Switch used to not install the boot diagnostics.  Without
this switch, the default is to install the boot diagnostics.
.SWITCH noendpointprotection
(Optional) Switch used to not install any endpoint protection (crowdstrike/CWP).  Without
this switch, the default is to install whatever the securityAgent parm in the key vault
is set to.
.PARAMETER dxcManaged
(Optional) Determines if DXC is required to manage this resource. Default set to true. Enter the tag value if otherwise.
.PARAMETER dxcPatchGroup
(Required) Creates tag that specifies the group (and therefore schedule) for system updates/patches. Enter the tag value.
.SWITCH armqa
(Internal Support) Switch used to change the location used to pull the makeManaged
ARM templates from.
.SWITCH armdev
(Internal Support) Switch used to change the location used to pull the makeManaged
ARM templates from.
.SWITCH trace
(Internal Support) Switch used to trace script flow and variables.
.SWITCH prototype
(Internal Support) Switch used to exercise the script, but not deploy an ARM template
.SWITCH notags
(Internal Support) Switch used to for other possible new features
.PARAMETER recoveryvault or rv
(Required unless noazurebackup) Parameter used to name the recovery vault that can
be used by Azure backup.  The default is that this parameter is required unless
specifically overridden.
.PARAMETER recoveryvaultresourcegroup or rvrg
(Required unless noazurebackup) Parameter used to name the recovery group that the
recovery vault resides in.  The default is that this parameter is required unless
specifically overridden.
.PARAMETER bootdiagnosticstoragename or bds
(Required unless nobootdiagnosticextension) Parameter used to name the storage account that can
be used by the boot diagnostic extension.  The default is that this parameter is required unless
specifically overridden.
.PARAMETER bootdiagnosticstorageresourcegroup or bdsrg
(Required unless nobootdiagnosticextension) Parameter used to name the resource group that the
storage account resides that is to be used by the boot diagnostic extension.  The default is that
this parameter is required unless specifically overridden.
.SWITCH log
(Optional) Switch used to indicate that a log file is created for the run.
.PARAMETER logName
(Optional) This is used to define a name for the log when the above 'log' parameter is used.  The default is 'log4ps.log'
and it is placed in the same directory that this script is run from.
.PARAMETER fatalColor
(Optional) This is used to set all "fatal" messages to the color of your choice.  Please refer to the makeManagedAuto wiki
page for a list of available colors.
.PARAMETER errorColor
(Optional) This is used to set all "error" messages to the color of your choice.  Please refer to the makeManagedAuto wiki
page for a list of available colors.
.PARAMETER warnColor
(Optional) This is used to set all "warn" messages to the color of your choice.  Please refer to the makeManagedAuto wiki
page for a list of available colors.
.PARAMETER infoColor
(Optional) This is used to set all "info" messages to the color of your choice.  Please refer to the makeManagedAuto wiki
page for a list of available colors.
.PARAMETER debugColor
(Optional) This is used to set all "debug" messages to the color of your choice.  Please refer to the makeManagedAuto wiki
page for a list of available colors.
.PARAMETER traceColor
(Optional) This is used to set all "trace" messages to the color of your choice.  Please refer to the makeManagedAuto wiki
page for a list of available colors.
.SWITCH overrideCWPCheck
(DO NOT USE UNLESS INSTRUCTED BY AZURE ENGINEERING) Switch used to ignore the CWP kernel check and go ahead and install the CWP agent
Author:  Kevin Bilderback
Date:    15/05/2019
Version: 0.1
Documentation: https://confluence.csc.com/display/CSA/AZR-7186+Create+wrapper+script+for+makeManaged
NOTES:
        There are three fixes required on this script in the near future.  One, is noted in the code about the makeManagedRHEL/CentOS
        offer returning a "7-RAW", which is not allowed by the current ARM template.  Two, where the code to determine if the VM
        already is being backed up.  This code is showing as depreciated, but still functions in the current Az release.  At some
        point in time, Microsoft will upgrade their code and this script will fail. Finally, there is a 'bug' in the makeManaged
        ARM templates where if diagnosticextensions are not selected, the ARM template will still attempt to install it.  When this
        is addressed in the ARM templates, then that section of this script can be changed.
Version: 0.2
Date: 22/05/2019
        - Remove OMS agent if found so that the correct OMS agent will be installed pointing to the correct log analytics
        - Validate that the Az modules are installed and at a minimum version of 2.0
        - Added makeManagedVersion to keyVault to check if the latest version is being executed
Version: 0.3
Date: 03/06/2019
        - Check if running under Azure Cloud Shell, if so, then user has already been authenticated, so skip requirements
        - Put error logic around Azure connect so that if the connect fails, then it will abort the script instead of throwing
          errors and continuing with the original user context.
        - Added trace parameter for tracing purposes
        - Documentation update: https://confluence.csc.com/display/CSA/AZR-7186+Create+wrapper+script+for+makeManaged
Version: 0.4
Date: 24/09/2019
        - Update documentation link above to correct site.
        - Removed version requirement from keyvault.
        - Changed code about forcing diagnostic extensions.  This "bug" was fixed in AZR-6682.
        - Remove code that forced RHEL from "7-RAW" to "7-3" "bug" in the makeManagedRHEL ARM template
        - Add resourcegroup as optional parameter (string) in case there are duplicate vmnames in the subscription
        - Added armqa to use arm templates from the qa location or production location
Version: 0.4a
Date: 26/09/2019
        - Add Oracle Linux back in.
        - Update documentation link (got lost somewhere)
        - Change csuninstallpw to csuninstall
Version: 0.4b
Date: 26/09/2019
        - Fix csuninstallpw to only check csuninstall
        - Removed code that checked versioning
        - Added code to pull makeManged token from key vault
Version: 1.0
Date: 16/10/2019
        - Change managed command parameters to switch so that to "NOT" install a feature you would enter -nocrowdstrike
        - Changed code flow to not check/validate if feature is not requested
        - Changed code flow so that unless you bypass backup and/or diagnostic extensions you will need to specify
       	        command-line parameters for recovery vault name/RG and storage account/RG
        - Removed code to pull backup and storage information from key vault.
		- Changed production location used to pull ARM templates
		- Added display to show what parameters are actually being used for run
		- Added shortcut command line parameters
		- Fixed check for previous backup image detection (previous code was deprecated)
		- Added random string to deployment name to allow multiple makemanagedauto deployments to run at the same time
		- Suppress OMS workspace key and Crowdstrike csCID from display on console
Version: 1.1
Date: 25/10/2019
        - Changed key vault csuninstall to CSuninstall to match with DXCMaintKV.json key vault build
	- Changed key vault to only pick up only makeMgdSasToken for production or makeMgdSasTokenqa if -armqa selected
Version: 1.2
Date: 29/10/2019
        - Added powershell check routine to require PS v6 or above
        - Changed Az module check to allow for powershell versions less then v6.2
Version: 1.3
Date: 22/11/2019
        - For Windows VM : renamed AzureDiagnosticExtension variable DiagnosticExtension to have the same name for Linux and Windows VMs
        - The AzureDiagnosticExtension parameter has been renamed DiagnosticExtension in :
            - the related ARM template called : makeManagedWindows.json
            - the parameter file called : makeManagedWindowsParms.json
Version: 2.0
Date: 11/11/2019
        - This is the CWP initial install.  Two additional switches are utilized
		- cs to install Crowdstrike
		- cwp to install Symantec CWP
		If neither switch is used, then it doesn't install any endpoint protection.
		Likewise you can not have both switchs active for any given execution.
	- This is also the initial release to support CIS OS's.  These are hardened images provided by the center for internet
		security(CIS) in the Azure Marketplace.
	- Fix: validateBackup throws an error if the recovery vault has never been used.
        - If running under prototype do not remove OMS agent if found
Version: 2.0.1
Date: 05/12/2019
        - Add check for CWP extension already being installed if -cwp selected
        - Fix bug where if neither -cs or -cwp is selected, at least pull in crowdstrike default parameter values
Version: 2.0.2
Date: 08/12/2019
        - Fix bug validating existing extension were not using the global variables to check if requested.
Version: 2.0.3
Date: 10/12/2019
        - Remove -cs/-cwp switches and convert endpoint protection choice to the securityAgent entry in the keyvault.
        - Call checkCWP instead of embedded CWP calls.
        - Added -nosymantec and -nocrowdstrike to override securityAgent entry if needed.
Version: 2.0.4
Date: 12/12/2019
        - Remove -nosymantec and -nocrowdstrike switches.  If crowdstrike/Symantec CWP needs to be installed then
          the securityAgent entry in the keyvault needs to be changed to reflect which endpoint security to install.
        - Add -noendpointprotection switch to disable installing endpoint protection regardless of what type is in
          the key vault securityAgent key.
Version: 2.0.5
Date: 16/12/2019
        - Remove -nosymantec from deprecated command list since makeManagedAuto that used that switch was not formally released.
Version: 2.1.0
Date: 02/01/2020
        - If CWP selected and already installed, the wrong makeManaged ARM template is selected (AZR-11470)
        - Change location checkCWP is called from to the installers folder (AZR-11470)
        - makeManagedAuto does not recognize OMS agent (new name: MicrosoftMonitoringAgent) installed (AZR-11439)
        - Added 'notags' to suppress adding standard makeManaged tags (possible other feature uses).
Version: 2.1.1
Date: 08/01/2020
        - Changed PS/AZ check functions to #requires so that it will fail with error instead of showing invalid code
        - Change logic flow to verify that makeManaged ARM template can be downloaded prior to removing the OMS agent, if needed (AZR-11535)
        - Change the connect-azure function to, at last resort, issue a Connect-AzConnect if the user has no other connections available (AZR-11533)
Version: 2.1.2
Date: 13/01/2020
        - When -noazurebackup was selected, the backuppolicy field was picking up a '-' instead of null.  Code changed to validate backuppolicy
          field and if one of the valid entries are not entered, then the 'DefaultPolicy' value is chosen.
        - Remove global variables on end of script (or early termination) to keep them from being carried over in subsequent executions (AZR-11621)
Version: 2.1.2.1
Date: 13/01/2020
        - makeManagedAuto remove.Extension was coded incorrectly for MicrosoftMonitoringAgent.  This has been resolved to function the same as for the OMSAgent.
Version: 2.1.3
Date: 29/01/2020
        - MakeManagedAuto script fails when existing VM tags contain a double quotation mark (").  Excape all double quotes that come in as existing tags (AZR-11317)
        - Fixed 'notags' to erase all existings tags prior to replacing the existing tags found at the start of the script run.
Version: 2.1.4
Date: 19/02/2020
        - makeManagedLinuxCWP ARM template needs 2 additional tags because of RHEL/CentOS being required to adjust the yum repository (AZR-11379)
        - Removed duplicate Functions.
Version: 2.1.5
Date: 05/01/2020
        - Sometimes the CWP Symantec API call takes too long and it is imposible to abort the process by 'ctrl+c' (AZR-13102)
        - Added a timer so after up to three iterations, aborts the API call and logs error message.
Version: 2.1.6
Date: 19/05/2020
        - Added dev storage to be able to test pre-released ARM templates (AZR-13102)
        - Added a timer so after up to three iterations, aborts the API call and logs error message.
Version: 2.1.7
Date: 19/05/2020
        - Added code to check if application, project and departmentName are already being used as tags.  If so
          then do not overlay them (AZR-13944)
       
Version: 2.1.8
Date: 17/06/2020
        - Added code to have an optional parameter (-subscription), where if present will be used 
	  after login to set which subscription the user is running under (AZR-13769).
	- Updated required powershell core version to 7.0 and Az modules to 3.1.0
Version: 2.1.9
Date: 15/07/2020
        - Added code to detect CIS SUSE. CIS Suse returns cis suse Linux, instead of SLES
Version: 2.1.10
Date: 20/07/2020
        - Added code check if VM is a Windows 2008R2-SP1.  If so, check the powershell version on
          the VM.  If we are installing CWP and the powershell version is < 4, then attempt
          to upgrade the VM to powershell V4 (AZR-14475).    
Version: 2.1.11
Date: 24/07/2020
        - When an Azure backup is requested, the code currently just checks to see if a backup exists for the
          VM and if so, will bypass adding the backup request.  This request wants makeManagedAuto to notify
          the user of the protection status instead of just bypassing the backup (AZR-12117)
Version: 3.0.0
Date: 28/07/2020
        - Convert makeManagedAuto to use $logger instead of Write-Hosts.  This will allow for creating a log
          file as well as writing to the console.
        - Ability to select your own message color for console display.  For instance, the color of "info" type
          displays are normally "green".  You can change the color for "info" display by using "-infoColor White",
          which will turn all "info" displays white. 
Version: 3.0.1
Date: 06/08/2020
        - Add boot diagnostics to VMs. (AZR-12862)
Version: 3.0.2
Date: 15/09/2020
        - Fix setting global resource group if -resourcegroup or -rg input from the command line (AZR-17391)
Version: 3.0.3
Date: 17/09/2020
        - Changed calls for keyvault secrets to use .NET instead of SecretValueText (AZR-17221)
        
   
Version: 3.0.4
Date: 13/10/2020
        - Merge crowdstrike Linux ARM templates down to one Linux ARM template (AZR-17902)      
Version: 3.0.5
Date: 20/10/2020
        - Remove any "custom script" extensions prior to installing managed components (AZR-17663)      
Version: 3.0.6
Date: 20/10/2020
        - Put in check to force vmName length to match what standard ARM templates use (AZR-11984) 
        - Added code for RHEL/CentOS 7.x/8.x to increase the LVM 'opt' filesystem if installing CWP (AZR-11984)     
Version: 3.0.7
Date: 18/12/2020
        - Put in code to run a python2 install if the VM is RHEL8  (AZR-20035) 
        - Disable diagnostic extensions on RHEL8 VM's if selected.
Version: 3.0.8
Date: 20/01/2021
        - Remove 'DepartmentName', 'Project' and 'Application' standard tags (AZR-13945)
Version: 3.0.9
Date: 12/02/2021
        - Added logic to support CentOS 8+ for Make Managed (AZR-19900).
Version: 3.0.10
Date: 22/02/2021
	- Added logic to support Oracle Linux 8+ for Make Managed (AZR-20929).
Version: 3.0.11
Date: 23/02/2021
	- Fixed bug so if no offer is present in VM information the script will generate fatal error (AZR-21444).
Date: 16/03/2021
	- Added logic to support Ubuntu Linux 20.04 for Make Managed (AZR-21595).

Version: 3.0.12
Date: 01/04/2021
	- Change develop environment over to dxcazuretoolsdev (AZR-22087).
        - Fix problem causes by AZR-18295 in github
Version: 3.0.13
Date: 09/04/2021
	- Updated OSType values for SUSE/SLES to support sles12-sp5 & sles15-sp1 (AZR-18566,AZR-17671)
Version: 3.1.0
Date:05/04/2021
    - Update MakeManaged to support new tagging schema (AZR-20522).
Version: 3.1.1
Date: 05/25/2021
        - Updated dxcBackup and dxcPatchGroup tags to output in correct format.(AZR-23613).
        - Changed dxcManaged to a variable from a parameter.
                          




#>



param(
        [Parameter(Mandatory = $true)]  [String]$vmname,
        [Parameter(Mandatory = $true)]  [String]$keyvault,
        [Parameter(Mandatory = $false)][switch]$noazurebackup,
        [Parameter(Mandatory = $false)][switch]$noomsmonitoring,
        [Parameter(Mandatory = $false)][switch]$nodiagnosticextension,
        [Parameter(Mandatory = $false)][switch]$noendpointprotection,
        [Parameter(Mandatory = $false)][switch]$nobootdiagnostics,
        
        #tagging related parameters       
        [Parameter(Mandatory = $false)][switch]$dxcPatchGroup,
        [Parameter(Mandatory = $false)][string]$dxcPatchGroupName,

        [Parameter(Mandatory = $false)][switch]$trace,
        [Parameter(Mandatory = $false)][switch]$armqa,
        [Parameter(Mandatory = $false)][switch]$armdev,
        [Parameter(Mandatory = $false)][switch]$notags,
        [Parameter(Mandatory = $false)][switch]$prototype,
        [Parameter(Mandatory = $false)][string]$backuppolicy,
        # This parameter is used to basically ignore the kernel check 
        # for CWP and let the CWP agent be installed.
        [Parameter(Mandatory = $false)][switch]$overrideCWPCheck = $false,

        [Parameter(Mandatory = $false)][string]$fatalColor = "DarkRed",       
        [Parameter(Mandatory = $false)][string]$errorColor = "Red",       
        [Parameter(Mandatory = $false)][string]$warnColor = "Yellow",       
        [Parameter(Mandatory = $false)][string]$infoColor = "Green",       
        [Parameter(Mandatory = $false)][string]$debugColor = "Cyan",       
        [Parameter(Mandatory = $false)][string]$traceColor = "Magenta",

        [Parameter(Mandatory = $false)][switch]$log = $false,
        [Parameter(Mandatory = $false)][string]$logName = "log4ps.log",

        [Parameter(Mandatory = $false)][string]$clientid,
        [Parameter(Mandatory = $false)][string]$clientkey,
        [Parameter(Mandatory = $false)][string]$tenantid,
        [Parameter(Mandatory = $false)][string]$subscription,

        [Parameter(Mandatory = $false)][string]$resourcegroup,
        [Parameter(Mandatory = $false)][string]$recoveryvault = '',
        [Parameter(Mandatory = $false)][string]$recoveryvaultresourcegroup = '',
        [Parameter(Mandatory = $false)][string]$bootdiagnosticstoragename = '',
        [Parameter(Mandatory = $false)][string]$bootdiagnosticstorageresourcegroup = '',

        # deprecated commands
        [Parameter(Mandatory = $false)][switch]$nocrowdstrike,

        # shortcut parameters
        [Parameter(Mandatory = $false)][string]$rg,
        [Parameter(Mandatory = $false)][string]$rv = '',
        [Parameter(Mandatory = $false)][string]$rvrg = '',
        [Parameter(Mandatory = $false)][string]$bds = '',
        [Parameter(Mandatory = $false)][string]$bdsrg = ''
)

################################
#       GLOBALS                #
################################
$OSNAME = ""
$KERNEL = ""
$resourceGroup = ""
$sku = ""
$offer = ""

$tags = ""
$omsWorkspaceId = ""
$omsWorkspaceKey = ""
$crowdStrikeCID = ""

$SymantecClientId = ""
$SymantecClientSecretKey = ""
$SymantecCustomerId = ""
$SymantecCustomerSecretKey = ""
$SymantecDomainId = ""

$gblbackuppolicy = ""
$csuninstallpw = ""
$gblcrowdstrike = $null
$gblsymantec = $null
$gblazurebackup = $null
$gblomsmonitoring = $null
$gbldiagnosticextension = $null
$gblbootdiagnostics = $null
$azurecloudshell = 'yes'
[string]$gblresourcegroup = ""
[string]$gblrecoveryvault = ""
[string]$gblrecoveryvaultresourcegroup = ""
[string]$gblbootdiagnosticstoragename = ''
[string]$gblbootdiagnosticstorageresourcegroup = ''
$endpointProtection = ""
$removeExtension = ""

$CRLF = [Environment]::NewLine
$extendoptCmd = "#!/bin/bash   " + $CRLF +                                    
"MAPPER=`"mapper`" " + $CRLF +
"OUTPUT=`$(df /opt -h | sed -e /Filesystem/d) " + $CRLF +
"if echo `"`$OUTPUT`" | grep -q `"`$MAPPER`"; then " + $CRLF +
"    echo `"`${OUTPUT}`" | " + $CRLF +
"    while read -r line " + $CRLF +
"    do " + $CRLF +
"        IFS=' ' read -r -a array <<< `"`$line`" " + $CRLF +
"        # get opt lvm map name " + $CRLF +
"        read mapper < <(echo `${array[0]}) " + $CRLF +
"        # get freesize of opt " + $CRLF +
"        read freesize < <(echo `${array[3]} | sed -r 's/<//g') " + $CRLF +
"        # remove the 'G' from the size " + $CRLF +
"        g=`${freesize%%G*} " + $CRLF +
"        # remove a '.' from the size if not whole number " + $CRLF +
"        number=`${g%%.*} " + $CRLF +
"        # check if free number is big enough for CWP " + $CRLF +
"        # if not, then run lvextend to increase the size " + $CRLF +
"        if [ `$number -lt 6 ]; then " + $CRLF +
"            lvextend -r -L +4G `$mapper " + $CRLF + 
"        fi " + $CRLF +
"    done " + $CRLF +
"fi"

#################################################################
# When making updates to this script, increment the scriptVersion
# to match the version from the script history above.
#################################################################
$scriptVersion = '3.1.1'
#################################################################

#################################################################
# logger variables
#################################################################
$executionPath = $null
$logRequired = $false
$logger = $null

#################################################################
# Production storage blob for makeManaged ARM templates .
$uri = "https://dxcazuretools.blob.core.windows.net/templates/"
#$token = ""
#################################################################
# Development/QA storage blob for makeManaged ARM templates and checkCWP powershell script .
$uriqa = "https://sqlpaastestlinktemplates.blob.core.windows.net/dxc-e1-sqlpaaspoc-rg-stageartifacts/makeManagedPaaS/"
$tokenqa = ""
#################################################################
# Production storage blob for checkCWP powershell script.
$checkuri = "https://dxcazuretools.blob.core.windows.net/installers/"
#################################################################
# Development storage blob for pre-release makeManaged ARM templates and checkCWP powershell script(internal development only)
$uridev = "https://dxcazuretoolsdev.blob.core.windows.net/"
$tokendev = ""
#################################################################

#################################################################
# logger functions
#################################################################
Function initializeLogger() {

        $log4Console = '<LOG4PS level="debug"> 
        <APPENDER type="ConsoleAppender" name="ConsoleAppender" >             
        <LAYOUT type="PatternLayout" pattern="[%lvl]: %log_data"/>         
        </APPENDER>             
        </LOG4PS> '

        $log4PS = '<LOG4PS level="debug">
        <APPENDER type="ConsoleAppender" name="ConsoleAppender" >
        <LAYOUT type="PatternLayout" pattern="[%lvl]: %log_data"/>
        </APPENDER>
        <APPENDER type="RollingFileAppender" name="log.log" maxFileSize="10240" maxBackupFiles="5">
        <LAYOUT type="PatternLayout" pattern="%d %t [%lvl]: %log_data"/>
        </APPENDER>
        </LOG4PS> '


        $parent = [System.IO.Path]::GetTempPath()
        [string] $name = [System.Guid]::NewGuid()
        $tmpDir = New-Item -ItemType Directory -Path (Join-Path $parent $name.replace('-', ''))    
        New-Item -Path $tmpDir -Name "release" -ItemType "directory" | Out-Null   
        New-Item -Path $tmpDir -Name "config" -ItemType "directory" | Out-Null   
        $configDir = "{0}/{1}" -f $tmpDir.ToString().Trim(), 'config' 
        New-Item -Path $configDir -Name "log4ps.xml" -ItemType "file" | Out-Null   
        $configFile = "{0}/{1}" -f $configDir, 'log4ps.xml'
        $configFile = $configFile.replace('/', '\')
        Set-Alias -Scope GLOBAL -Name Logger -Value Logger

        Try {
                if ($log -eq $false) {
                        $log4Console | Out-File $configFile  
                }
                else {
                        $log4PS | Out-File $configFile
                        $logRequired = $true    
                }
        }
        Catch {
                Write-Host "ERROR: Failure to set Config file.  Processing terminated." -ForegroundColor Red
                Remove-Item -LiteralPath $tmpDir -Force -Recurse 1>$null 2>$null 3>$null
                # [System.IO.File]::Delete($configFile)
        }

        # Finish up logger initialization
        $executionPath = Split-Path $script:MyInvocation.MyCommand.Path
        $global:logger = global:Logger;
        $global:logger.load($configFile, $logName, $logRequired, $executionPath);
        Remove-Item $configFile -Force  
        # [System.IO.File]::Delete($configFile)
}
Function destroyLogger() {
        $logger.Destroy();
        Remove-Variable -Name logger -Scope Global -Force
}

<#
#>
function global:ConsoleAppender {
        $obj = New-Object PSObject -Property @{        
                logFileName        = $null;
                logFileChildFolder = $null;
                logFileFolder      = $null;
                backupFolder       = $null;
                logFileFullPath    = $null;
                maxFileSize        = 10000;
                maxBackupFiles     = 0;
                layout             = $null;
                currentCount       = 0;
                currentFileName    = $null;
                currentFileSize    = 0;
        };
    
        $obj | Add-Member -MemberType ScriptMethod -Name load -Value {
    
                <#
            $dateString = Get-Date -format dd\_MM\_yyyy\_HH\_mm\_ss;
        #>        
        
        };       
    
        $obj | Add-Member -MemberType ScriptMethod -Name log -Value {
    
                param($data, $levelType);
        
                $dataToLog = $this.layout.FormatData($data, $levelType);       
                switch ($levelType) {
                        'FATAL' { 
                                Write-Host $dataToLog -ForegroundColor $fatalColor
                        }
                        'ERROR' {
                                Write-Host $dataToLog -ForegroundColor $errorColor
                        }
                        'WARN' {
                                Write-Host $dataToLog -ForegroundColor $warnColor
                        }
                        'INFO' {
                                Write-Host $dataToLog -ForegroundColor $infoColor
                        }
                        'DEBUG' {
                                Write-Host $dataToLog -ForegroundColor $debugColor
                        }
                        'TRACE' {
                                Write-Host $dataToLog -ForegroundColor $traceColor
                        }
                        default {
                                Write-Host $dataToLog -ForegroundColor WHITE
                        }
                }
        };
    
        <#
        Function: Destroy
        Purpose: Destructor for the class
            
        Params: none
        Returns: none
    #>
        $obj | Add-Member -MemberType ScriptMethod -Name Destroy -Value {

                $this.logFileName = $null;
                $this.logFileChildFolder = $null;
                $this.logFileFolder = $null;
                $this.backupFolder = $null;
                $this.logFileFullPath = $null;
                $this.layout = $null;
                $this.currentFileName = $null; 

        };
        
        <#
        Return object closure
    #>
        return $obj;
}
<#
    Modeled after log4j logger.
#>
function global:Logger {
        $obj = New-Object PSObject -Property @{
    
                className    = $MyInvocation.MyCommand.Name;
                appenders    = @();
                mainLogLevel = 0;
                level        = @{DEBUG = 0; INFO = 1; WARN = 2; ERROR = 3; FATAL = 4 };
        
        };
    
        $obj | Add-Member -MemberType ScriptMethod -Name CallAppenders -Value {
    
                param($data, [int]$levelHeight, $levelType);
        
                if ($levelHeight -ge $this.mainLogLevel) {
                        foreach ($appender in $this.appenders) {
                                $appender.log($data, $levelType);
                        }    
                }
    
        };
    
        $obj | Add-Member -MemberType ScriptMethod -Name debug -Value {
    
                param([string]$data);
        
                $this.CallAppenders($data, $this.level.DEBUG, "DEBUG");
        };

        $obj | Add-Member -MemberType ScriptMethod -Name trace -Value {
    
                param([string]$data);
        
                $this.CallAppenders($data, $this.level.TRACE, "TRACE");
        };
    
        $obj | Add-Member -MemberType ScriptMethod -Name info -Value {
    
                param([string]$data);
        
                $this.CallAppenders($data, $this.level.INFO, "INFO");
        };
    
        $obj | Add-Member -MemberType ScriptMethod -Name warn -Value {
    
                param([string]$data);
        
                $this.CallAppenders($data, $this.level.WARN, "WARN");
        };
    
        $obj | Add-Member -MemberType ScriptMethod -Name error -Value {
    
                param([string]$data);
        
                $this.CallAppenders($data, $this.level.ERROR, "ERROR");
        
        };
    
        $obj | Add-Member -MemberType ScriptMethod -Name fatal -Value {
    
                param([string]$data);
        
                $this.CallAppenders($data, $this.level.FATAL, "FATAL");

        };
    
        $obj | Add-Member -MemberType ScriptMethod -Name load -Value {
    
                param($logFileConfigPath, $logFileName, $logRequired, $executionPath);

                [xml]$config = Get-Content $logFileConfigPath;
                $log4psNode = $config.LOG4PS;
                $defaultLevel = $log4psNode.getAttribute("level");
                $defaultLevel = $defaultLevel.ToUpper();
        
                switch ($defaultLevel) {
                        "DEBUG" { $this.mainLogLevel = $this.level.DEBUG; };
                        "TRACE" { $this.mainLogLevel = $this.level.TRACE; };
                        "INFO" { $this.mainLogLevel = $this.level.INFO; };
                        "WARN" { $this.mainLogLevel = $this.level.WARN; };
                        "ERROR" { $this.mainLogLevel = $this.level.ERROR; };
                        "FATAL" { $this.mainLogLevel = $this.level.FATAL; };            
                };
        
                $appenders = $log4psNode.selectNodes("APPENDER");
                foreach ($appender in $appenders) {
                        $type = $appender.getAttribute("type");
                        $name = $appender.getAttribute("name");
                        $maxFileSize = $appender.getAttribute("maxFileSize");
                        $maxBackupFiles = $appender.getAttribute("maxBackupFiles");
                        $appenderInstance = & (Get-Item function:$type);
                        $logFilePath = $logFileConfigPath.replace("\config\log4ps.xml", "");

                        if ($logRequired -eq $true) {
                                $logFilePath = $executionPath + "\logs\";
                        }
                        else {
                                $logFilePath = $logFilePath + "\logs\";
                        }

                        $appenderInstance.logFileFolder = $logFilePath;            
                        if (!$logFileName) {
                                $appenderInstance.logFileName = $name;
                        }
                        else {
                                $appenderInstance.logFileName = $logFileName;
                        }
                        
                        $appenderInstance.maxFileSize = $maxFileSize;
                        $appenderInstance.maxBackupFiles = $maxBackupFiles;
            
                        $layout = $appender.selectSingleNode("LAYOUT");
                        $type = $layout.getAttribute("type");
                        $pattern = $layout.getAttribute("pattern");
            
                        $layoutInstance = & (Get-Item function:$type);
                        $layoutInstance.pattern = $pattern;
            
                        $appenderInstance.layout = $layoutInstance;
            
                        $appenderInstance.load();
            
                        $this.appenders += $appenderInstance;          
                }
        
        };
    
        $obj | Add-Member -MemberType ScriptMethod -Name SendEmail -Value {
    
                param([string]$emailFrom, [string]$emailTo, [string]$smtpServer, [string]$subject, [string]$body);
     
                $smtp = new-object Net.Mail.SmtpClient($smtpServer);
                $smtp.Send($emailFrom, $emailTo, $subject, $body);

        };

        <#
        Function: Destroy
        Purpose: Destructor for the class
            
        Params: none
        Returns: none
    #>
        $obj | Add-Member -MemberType ScriptMethod -Name Destroy -Value {
        
                $this.appenders = $null;

        };
        
        <#
        Return object closure
    #>
        return $obj;
}
<#
#>
function global:PatternLayout {
        $obj = New-Object PSObject -Property @{
    
                pattern = $null;
        
        };
    
        $obj | Add-Member -MemberType ScriptMethod -Name FormatData -Value {
    
                param($data, $levelType);
        
                $dateString = Get-Date -format dd/MM/yyyy;
                $timeString = Get-Date -format HH:mm:ss;
                $ret = $this.pattern.replace("%d", $dateString);
                $ret = $ret.replace("%t", $timeString);
                $ret = $ret.replace("%lvl", $levelType);
                $ret = $ret.replace("%log_data", $data);
        
                return $ret;
        
        };

        <#
        Function: Destroy
        Purpose: Destructor for the class
            
        Params: none
        Returns: none
    #>
        $obj | Add-Member -MemberType ScriptMethod -Name Destroy -Value {
        
                $this.pattern = $null;
        
        };
        
        <#
        Return object closure
    #>
        return $obj;
}
<#
#>
function global:RollingFileAppender {
        $obj = New-Object PSObject -Property @{
    
                logFileName        = $null;
                logFileChildFolder = $null;
                logFileFolder      = $null;
                backupFolder       = $null;
                logFileFullPath    = $null;
                maxFileSize        = 10000;
                maxBackupFiles     = 0;
                layout             = $null;
                currentCount       = 0;
                currentFileName    = $null;
                currentFileSize    = 0;
        
        };
    
        $obj | Add-Member -MemberType ScriptMethod -Name load -Value {
    
                <#
            $dateString = Get-Date -format dd\_MM\_yyyy\_HH\_mm\_ss;
        #>
        
                if (!$this.logFileChildFolder) {
                        $this.logFileFullPath = $this.logFileFolder + $this.logFileName;
                }
                else {
                        $this.logFileFullPath = $this.logFileFolder + $this.logFileChildFolder + "\" + $this.logFileName;
                }
        
                if (!(Test-Path -path $this.logFileFolder)) {
                        New-Item -path $this.logFileFolder -type directory 1>$null 2>$null 3>$null
                }
        
                if ($this.logFileChildFolder) {
                        $p = $this.logFileFolder + "\" + $this.logFileChildFolder;
                        if (!(Test-Path -path $p)) {
                                New-Item -path $p -type directory 1>$null 2>$null 3>$null
                        }
                }
        
                $this.backupFolder = $this.logFileFolder + "backup";
                if (!(Test-Path -path $this.backupFolder)) {
                        New-Item -path $this.backupFolder -type directory 1>$null 2>$null 3>$null
                }
        
                if (!(Test-Path -path $this.logFileFullPath)) {
                        New-Item $this.logFileFullPath -type file 1>$null 2>$null 3>$null
                }
                else {
                        $this.currentFileSize = (Get-ChildItem -path $this.logFileFullPath | Select-Object Length).Length;
                }
        
                $this.currentCount = $this.DetermineCurrentLogCount();
        
        };
    
        $obj | Add-Member -MemberType ScriptMethod -Name DetermineCurrentLogCount -Value {
    
                $currentLogCount = 1;
        
        
                if ((Test-Path $this.backupFolder)) {
                        $fileCount = (Get-ChildItem $this.backupFolder | Measure-Object).Count;
                        if ($fileCount -lt $this.maxBackupFiles) {
                                $currentLogCount = $fileCount + 1;
                        }
                }
        
                return $currentLogCount;
    
        };
    
        $obj | Add-Member -MemberType ScriptMethod -Name WeCanLog -Value {
    
                param([int]$dataToLogSize);
        
                $ret = $false;
                $this.currentFileSize = $this.currentFileSize + $dataToLogSize;
        
                if ([int]$this.currentFileSize -lt ([int]$this.maxFileSize * 1024)) {
                        $ret = $true;
                }
        
                return $ret;
        
        };
    
        $obj | Add-Member -MemberType ScriptMethod -Name RollLogFile -Value {
            
                if ($this.currentCount -le $this.maxBackupFiles) {      
                        $ext = "_" + $this.currentCount + ".log";
                        $dest = $this.backupFolder + "\" + $this.logFileName.replace(".log", $ext);
                        Move-Item $this.logFileFullPath $dest -force 1>$null 2>$null 3>$null
            
                        $this.currentCount++;
                }
                else {
                        $ext = "_1" + ".log";
                        $dest = $this.backupFolder + "\" + $this.logFileName.replace(".log", $ext);
                        Move-Item $this.logFileFullPath $dest -force 1>$null 2>$null 3>$null
                        $this.currentCount = 2;
                }
        
                $this.currentFileSize = 0;
    
        };
    
        $obj | Add-Member -MemberType ScriptMethod -Name log -Value {
    
                param($data, $levelType);
        
                $dataToLog = $this.layout.FormatData($data, $levelType);
        
                if (!$this.WeCanLog(($dataToLog.length + 2))) {
                        $this.RollLogFile();
                }
        
                Add-Content -path $this.logFileFullPath -value $dataToLog;
    
        };
    
        <#
        Function: Destroy
        Purpose: Destructor for the class
            
        Params: none
        Returns: none
    #>
        $obj | Add-Member -MemberType ScriptMethod -Name Destroy -Value {
        
                $this.logFileName = $null;
                $this.logFileChildFolder = $null;
                $this.logFileFolder = $null;
                $this.backupFolder = $null;
                $this.logFileFullPath = $null;
                $this.layout = $null;
                $this.currentFileName = $null;
        
        };
        
        <#
        Return object closure
    #>
        return $obj;
}
Function validateLoggerColors() {
        $colors = @("Black", "DarkBlue", "DarkGreen", "DarkCyan", "DarkRed", "DarkMagenta", "DarkYellow",
                "Gray", "DarkGray", "Blue", "Green", "Cyan", "Red", "Magenta", "Yellow", "White" 
        );
        if ($null -ne ($fatalColor | ? { $colors -match $_ })) {
        }
        else {
                Write-Host "Fatal color selected ($fatalColor) is not available."
                Exit
        }
        if ($null -ne ($errorColor | ? { $colors -match $_ })) {
        }
        else {
                Write-Host "Error color selected ($errorColor) is not available."
                Exit
        }
        if ($null -ne ($warnColor | ? { $colors -match $_ })) {
        }
        else {
                Write-Host "Warn color selected ($warnColor) is not available."
                Exit
        }

        if ($null -ne ($infoColor | ? { $colors -match $_ })) {
        }
        else {
                Write-Host "Info color selected ($infoColor) is not available."
                Exit
        }
        if ($null -ne ($debugColor | ? { $colors -match $_ })) {
        }
        else {
                Write-Host "Debug color selected ($debugColor) is not available."
                Exit
        }
        if ($null -ne ($traceColor | ? { $colors -match $_ })) {
        }
        else {
                Write-Host "Trace color selected ($traceColor) is not available."
                Exit
        }
}
#################################################################
# end logger functions
#################################################################

Function getCredentials {
        $shell = (Get-ChildItem Env:AZURE_HTTP_USER_AGENT).Value  2>$null 3>$null

        if ($shell -eq "" -or $null -eq $shell ) {
                $global:azurecloudshell = 'no'
        }
        else {
                $global:azurecloudshell = 'yes'
               	$logger.info(" ") 
                $logger.info("Running under Azure Cloud Shell, bypassing login/connect processing") 
                if ($null -eq $subscription -or $subscription -eq "") {
                        return
                }
                setSubscription
                return
        }

        # Just need to check one of the service principal variables to assume it is valid
        if ($null -ne $clientid -and $clientid -ne "") {
                if ($trace -eq $true) {
                        $logger.trace("Attempting to connect with submitted credentials:")
                        $logger.trace("    clientid: $clientid") 
                        $logger.trace("    clientkey: $clientkey") 
                        $logger.trace("    tenantid: $tenantid") 
                }

                $error.Clear()

                $passwd = ConvertTo-SecureString $clientkey -AsPlainText -Force
                $pscredential = New-Object System.Management.Automation.PSCredential($clientid, $passwd)
                Connect-AzAccount -ServicePrincipal -Credential $pscredential -TenantId $tenantid   1>$null 2>$null 3>$null

                if ($error) {
                        $logger.fatal("Unable to connect to Azure. Check your Service Principal variables to ensure they are correct and valid.")
                        removeGlobalVariables
                        destroyLogger
                        exit
                }
                else {
                        $logger.info(" ")
                        $logger.info("Connected to Azure with submitted Service Principal.")
                        if ($null -eq $subscription -or $subscription -eq "") {
                                return
                        }
                        setSubscription
                        return
                }
        }
        # check if we are currently connected and use that if possible
        $currentLogin = (Get-AzContext).Account.Id
        if ($currentLogin -ne "" -and $null -ne $currentLogin) {
                $logger.info("Running with current logged on account")
                if ($null -eq $subscription -or $subscription -eq "") {
                        return
                }
                setSubscription
                return
        }
        # apparently no other connection options are available, so force an Azure connect
        Connect-AzAccount
        $currentLogin = (Get-AzContext).Account.Id
        if ($currentLogin -eq "" -or $null -eq $currentLogin) {
                $logger.fatal("Unable to determine connection status.  Please re-run and connect with valid credentials.")
                removeGlobalVariables
                destroyLogger
                exit  
        }
        $subscriptionId = Read-Host "Please enter the subscriptionID"
        if ($null -ne $subscriptionId -and $subscriptionId -ne "") {
                Select-AzSubscription -Subscription  "$subscriptionId" 1>$null 2>$null 3>$null
        }
        else {
                $logger.fatal("Unable to determine the subscription required.  Please re-run and submit valid subscription when prompted.")
                removeGlobalVariables
                destroyLogger
                exit
        }
}

Function setSubscription {
       	# If subscription was not entered, then we don't need to be here 
        if ($null -eq $subscription -or $subscription -eq "") {
                # Get subscription ID that we are currently running under
                $subscription_id = Get-AzContext
                # Check if more than one subscription has been returned.
                $subscriptionCheck = $subscription_id.Subscription -split ' '
                if ($subscriptionCheck.Count -gt 1) {
                        $logger.fatal(" ")
                        $logger.fatal("Multiple subscriptions found.  Please run again with '-subscription' parameter to set a default subscription")
                        removeGlobalVariables
                        destroyLogger
                        Exit
                }
                return
        }
        $found = $false
        # Get all subscriptions we currently have access to           
        $subscriptions = Get-AzContext -ListAvailable
        $subscriptions.Name | ForEach-Object {
                $sub = ($_ -split "\(|\)")[1]
                if ($trace -eq $true) {
                        $logger.trace("subscriptionId $sub")
                }
                if ($sub -eq $subscription) {
                        $found = $true
                }
        }		

        if ($found -eq $true) {
                $logger.info(" ")
                $logger.info("Setting connection subscription to: $subscription")
                Select-AzSubscription -Subscription  "$subscription" 1>$null 2>$null 3>$null
        }
        else {
                $logger.fatal("Requested subscription $subscription is not contained in your connection context")
                removeGlobalVariables
                destroyLogger
                Exit
        }
}

Function getEndPointProtection {
        if ($trace -eq $true) {
                $logger.trace(" ")
                $logger.trace("GetEndPointProtection: ")
                $logger.trace("keyvault value:$keyvault ")
        }

        Try {
                $secretvalue = Get-AzKeyVaultSecret -VaultName $keyvault -Name securityAgent
                $global:endpointProtection = ([System.Net.NetworkCredential]::new("", $secretvalue.SecretValue).Password).ToLower()
        }
        Catch {
                $global:endpointProtection = "crowdstrike"
        }
        if ($trace -eq $true) {
                $logger.trace("endPointProtection: $global:endpointProtection")
        }

        if ($global:endpointProtection -eq 'symantec') {
                $global:gblcrowdstrike = "no"
                if ($trace -eq $true) {
                        $logger.trace("    disable CrowdStrike from install")
                        $logger.trace("    enable Symantec CWP in install")
                }
                $global:gblsymantec = "yes"
        }
        else {
                $global:gblsymantec = "no"
                if ($trace -eq $true) {
                        $logger.trace("    disable Symantec CWP from install")
                        $logger.trace("    enable Crowdstrike in install")
                }
                $global:gblcrowdstrike = "yes"
        }
}


Function getKeyVaultValues {

        if ($trace -eq $true) {
                $logger.trace(" ")
                $logger.trace("GetKeyVaultValues: ")
                $logger.trace("keyvault value:$keyvault ")
        }

        if ($global:gblomsmonitoring -eq "yes") {
                Try {
                        $secretvalue = Get-AzKeyVaultSecret -VaultName $keyvault -Name omsid
                        $global:omsWorkspaceId = [System.Net.NetworkCredential]::new("", $secretvalue.SecretValue).Password
                }
                Catch {
                        $global:omsWorkspaceId = $null
                }
                if ($global:omsWorkspaceId -eq "" -or $null -eq $global:omsWorkspaceId) {
                        $logger.fatal("OMS workspaceID not found in key vault. Please fix this issue and re-run this script")
                        removeGlobalVariables
                        destroyLogger
                        Exit
                }
                if ($trace -eq $true) {
                        $logger.trace("    OMS workspaceId: $global:omsWorkspaceId")
                }

                Try {
                        $secretvalue = Get-AzKeyVaultSecret -VaultName $keyvault -Name omskey
                        $global:omsWorkspaceKey = [System.Net.NetworkCredential]::new("", $secretvalue.SecretValue).Password
                }
                Catch {
                        $global:omsWorkspaceKey = [System.Net.NetworkCredential]::new("", $secretvalue.SecretValue).Password
                }
                if ($global:omsWorkspaceKey -eq "" -or $null -eq $global:omsWorkspaceKey ) {
                        $logger.fatal("OMS workspace Key not found in key vault. Please fix this issue and re-run this script")
                        removeGlobalVariables
                        destroyLogger
                        Exit
                }
                if ($trace -eq $true) {
                        $logger.trace("    OMS workspaceKey: $global:omsWorkspaceKey") 
                }
        }

        if ($global:gblcrowdstrike -eq "yes") {
                Try {
                        $secretvalue = Get-AzKeyVaultSecret -VaultName $keyvault -Name cscid
                        $global:crowdStrikeCID = [System.Net.NetworkCredential]::new("", $secretvalue.SecretValue).Password
                }
                Catch {
                        $global:crowdStrikeCID = $null
                }
                if ($global:crowdStrikeCID -eq "" -or $null -eq $global:crowdStrikeCID) {
                        $logger.fatal("CrowdStrike CID not found in key vault. Please fix this issue and re-run this script")
                        removeGlobalVariables
                        destroyLogger
                        Exit
                }
                if ($trace -eq $true) {
                        $logger.trace("    crowdStrikdCID: $global:crowdStrikeCID")
                }
                Try {
                        $secretvalue = Get-AzKeyVaultSecret -VaultName $keyvault -Name CSuninstall
                        $global:csuninstallpw = [System.Net.NetworkCredential]::new("", $secretvalue.SecretValue).Password
                }
                Catch {
                        $global:csuninstallpw = $null
                }
                if ($global:csuninstallpw -eq "" -or $null -eq $global:csuninstallpw) {
                        $logger.fatal("Crowdstrike uninstall password not found in key vault. Please fix this issue and re-run this script")
                        removeGlobalVariables
                        destroyLogger
                        Exit
                }
                if ($trace -eq $true) {
                        $logger.trace("    csuninstallpw: $global:csuninstallpw")
                }
        }

        if ($armdev -eq $true) {
                Try {
                        $secretvalue = Get-AzKeyVaultSecret -VaultName $keyvault -Name makeMgdSasTokendev
                        $global:tokendev = [System.Net.NetworkCredential]::new("", $secretvalue.SecretValue).Password
                }
                Catch {
                        $global:tokendev = $null
                }
                if ($global:tokendev -eq "" -or $null -eq $global:tokendev) {
                        $logger.fatal("makeMgdSasTokendev not found in key vault. Please fix this issue and re-run this script")
                        removeGlobalVariables
                        destroyLogger
                        Exit
                }
                if ($trace -eq $true) {
                        $logger.trace("    makeMgdSasTokendev: $global:tokendev")
                }
        }
        elseif ($armqa -eq $true) {
                Try {
                        $secretvalue = Get-AzKeyVaultSecret -VaultName $keyvault -Name makeMgdSasTokenqa
                        $global:tokenqa = [System.Net.NetworkCredential]::new("", $secretvalue.SecretValue).Password
                }
                Catch {
                        $global:tokenqa = $null
                }
                if ($global:tokenqa -eq "" -or $null -eq $global:tokenqa) {
                        $logger.fatal("makeMgdSasTokenqa not found in key vault. Please fix this issue and re-run this script")
                        removeGlobalVariables
                        destroyLogger
                        Exit
                }
                if ($trace -eq $true) {
                        $logger.trace("    makeMgdSasTokenqa: $global:tokenqa")
                }
        }
        else {
                Try {
                        $secretvalue = Get-AzKeyVaultSecret -VaultName $keyvault -Name makeMgdSasToken
                        $global:token = [System.Net.NetworkCredential]::new("", $secretvalue.SecretValue).Password
                }
                Catch {
                        $global:token = $null
                }
                if ($global:token -eq "" -or $null -eq $global:token) {
                        $logger.fatal("makeMgdSasToken not found in key vault. Please fix this issue and re-run this script")
                        removeGlobalVariables
                        destroyLogger
                        Exit
                }
                if ($trace -eq $true) {
                        $logger.trace("    makeMgdSasToken: $global:token")
                }
        }

        if ($global:gblsymantec -eq "yes") {
                Try {
                        $secretvalue = Get-AzKeyVaultSecret -VaultName $keyvault -Name SymantecClientId
                        $global:SymantecClientId = [System.Net.NetworkCredential]::new("", $secretvalue.SecretValue).Password
                }
                Catch {
                        $global:SymantecClientId = $null
                }
                if ($global:SymantecClientId -eq "" -or $null -eq $global:SymantecClientId ) {
                        $logger.fatal("SymantecClientId not found in key vault. Please fix this issue and re-run this script")
                        removeGlobalVariables
                        destroyLogger
                        Exit
                }
                if ($trace -eq $true) {
                        $logger.trace("    Symantec Client Id: $global:SymantecClientId")
                }

                Try {
                        $secretvalue = Get-AzKeyVaultSecret -VaultName $keyvault -Name SymantecClientSecretKey
                        $global:SymantecClientSecretKey = [System.Net.NetworkCredential]::new("", $secretvalue.SecretValue).Password
                }
                Catch {
                        $global:SymantecClientSecretKey = $null
                }
                if ($global:SymantecClientSecretKey -eq "" -or $null -eq $global:SymantecClientId) {
                        $logger.fatal("SymantecClientSecretKey not found in key vault. Please fix this issue and re-run this script")
                        removeGlobalVariables
                        destroyLogger
                        Exit
                }
                if ($trace -eq $true) {
                        $logger.trace("    Symantec Client Secret Key: $global:SymantecClientSecretKey")
                }

                Try {
                        $secretvalue = Get-AzKeyVaultSecret -VaultName $keyvault -Name SymantecCustomerId
                        $global:SymantecCustomerId = [System.Net.NetworkCredential]::new("", $secretvalue.SecretValue).Password
                }
                Catch {
                        $global:SymantecCustomerId = $null
                }
                if ($global:SymantecCustomerId -eq "" -or $null -eq $global:SymantecClientSecretKey ) {
                        $logger.fatal("SymantecCustomerId not found in key vault. Please fix this issue and re-run this script")
                        removeGlobalVariables
                        destroyLogger
                        Exit
                }
                if ($trace -eq $true) {
                        $logger.trace("    Symantec Customer Id: $global:SymantecCustomerId")
                }

                Try {
                        $secretvalue = Get-AzKeyVaultSecret -VaultName $keyvault -Name SymantecCustomerSecretKey
                        $global:SymantecCustomerSecretKey = [System.Net.NetworkCredential]::new("", $secretvalue.SecretValue).Password
                }
                Catch {
                        $global:SymantecCustomerSecretKey = $null
                }
                if ($global:SymantecCustomerSecretKey -eq "" -or $null -eq $global:SymantecCustomerId ) {
                        $logger.fatal("SymantecCustomerSecretKey not found in key vault. Please fix this issue and re-run this script")
                        removeGlobalVariables
                        destroyLogger
                        Exit
                }
                if ($trace -eq $true) {
                        $logger.trace("    Symantec Customer Secret Key: $global:SymantecCustomerSecretKey")
                }

                Try {
                        $secretvalue = Get-AzKeyVaultSecret -VaultName $keyvault -Name SymantecDomainId
                        $global:SymantecDomainId = [System.Net.NetworkCredential]::new("", $secretvalue.SecretValue).Password
                }
                Catch {
                        $global:SymantecDomainId = $null
                }
                if ($global:SymantecDomainId -eq "" -or $null -eq $global:SymantecDomainId ) {
                        $logger.fatal("SymantecDomainId not found in key vault. Please fix this issue and re-run this script")
                        removeGlobalVariables
                        destroyLogger
                        Exit
                }
                if ($trace -eq $true) {
                        $logger.trace("    Symantec Domain Id: $global:SymantecDomainId")
                }
        }
}

Function Check-Parameters {

        # Transcribe command line requests to global parameters

        # Check vmName length matches approved length of 50
        if ($vmName.length -gt 50) {                 
                $logger.fatal("vmName length greater then approved length of 50, please correct and run again.")
                removeGlobalVariables
                destroyLogger
                Exit
        }

        if ($noazurebackup -eq $true) {
                $global:gblazurebackup = "no"
                if ($trace -eq $true) {
                        $logger.trace("    disable azurebackup from install")
                }
        }
        else {
                $global:gblazurebackup = "yes"
        }

        if ($noomsmonitoring -eq $true) {
                $global:gblomsmonitoring = "no"
                if ($trace -eq $true) {
                        $logger.trace("    disable omsmonitoring from install")
                }
        }
        else {
                $global:gblomsmonitoring = "yes"
        }

        if ($nodiagnosticextension -eq $true) {
                $global:gbldiagnosticextension = "no"
                if ($trace -eq $true) {
                        $logger.trace("    disable diagnosticextenstion from install")
                }
        }
        else {
                $global:gbldiagnosticextension = "yes"
        }

        if ($nobootdiagnostics -eq $true) {
                $global:gblbootdiagnostics = "no"
                if ($trace -eq $true) {
                        $logger.trace("    disable bootdiagnostics from install")
                }
        }
        else {
                $global:gblbootdiagnostics = "yes"
        }       

        #  populate resource group parameter if input
        if ($rg -ne "" -And $resourcegroup -ne "") {
               	$logger.fatal("specified both shortcut and regular resource group parameters, please correct and run again.")
                removeGlobalVariables
                destroyLogger
                Exit
        }
        else {
                if ($rg -ne "") {
                        $global:gblresourcegroup = $rg
                }
                else {
                        if ($resourcegroup -ne "") {
                                $global:gblresourcegroup = $resourcegroup
                        }
                }
        }

        # Copy over shortcut parameters if used
        if ($noazurebackup -eq $false) {
                if ($rv -ne "" -And $recoveryvault -ne "") {
                        $logger.fatal("specified both shortcut and regular recovery vault parameters, please correct and run again.")
                        removeGlobalVariables
                        destroyLogger
                        Exit
                }
                else {
                        if ($rv -eq "" -And $recoveryvault -eq "") {
                                $logger.fatal("recovery vault parameters not specified, please correct and run again.")
                                removeGlobalVariables
                                destroyLogger
                                Exit
                        }
                        else {
                                if ($rv -ne "") {
                                        $global:gblrecoveryvault = $rv
                                }
                                else {
                                        $global:gblrecoveryvault = $recoveryvault
                                }
                        }
                }

                if ($trace -eq $true) {
                        $logger.trace(" ")
                        $logger.trace("recovery vault value: $global:gblrecoveryvault")
                }
                if ($rvrg -ne "" -And $recoveryvaultresourcegroup -ne "") {
                        $logger.fatal("specified both shortcut and regular recovery vault resource group parameters, please correct and run again.")
                        removeGlobalVariables
                        destroyLogger
                        Exit
                }
                else {
                        if ($rvrg -eq "" -And $recoveryvaultresourcegroup -eq "") {
                                $logger.fatal("recovery vault resource group parameters not specified, please correct and run again.")
                                removeGlobalVariables
                                destroyLogger
                                Exit
                        }
                        else {
                                if ($rvrg -ne "") {
                                        $global:gblrecoveryvaultresourcegroup = $rvrg
                                }
                                else {
                                        $global:gblrecoveryvaultresourcegroup = $recoveryvaultresourcegroup
                                }
                        }
                }
                if ($trace -eq $true) {
                        $logger.trace("recovery vault resource group value:$global:gblrecoveryvaultresourcegroup")
                }

        }

        if (($nodiagnosticextension -eq $false) -Or ($nobootdiagnostics -eq $false)) {
                if ($bds -ne "" -And $bootdiagnosticstoragename -ne "") {
                        $logger.fatal("specified both shortcut and regular boot diagnostic storage name parameters, please correct and run again.")
                        removeGlobalVariables
                        destroyLogger
                        Exit
                }
                else {
                        if ($bds -eq "" -And $bootdiagnosticstoragename -eq "") {
                                $logger.fatal("boot diagnostic storage name parameters not specified, please correct and run again.")
                                removeGlobalVariables
                                destroyLogger
                                Exit
                        }
                        else {
                                if ($bds -ne "") {
                                        $global:gblbootdiagnosticstoragename = $bds
                                }
                                else {
                                        $global:gblbootdiagnosticstoragename = $bootdiagnosticstoragename
                                }
                        }
                }
                if ($trace -eq $true) {
                        $logger.trace(" ")
                        $logger.trace("boot diagnostic storage name value:$global:gblbootdiagnosticstoragename")
                }

                if ($bdsrg -ne "" -And $bootdiagnosticstorageresourcegroup -ne "") {
                        $logger.fatal("specified both shortcut and regular boot diagnostic storage name parameters, please correct and run again.")
                        removeGlobalVariables
                        destroyLogger
                        Exit
                }
                else {
                        if ($bdsrg -eq "" -And $bootdiagnosticstorageresourcegroup -eq "") {
                                $logger.fatal("boot diagnostic storage name parameters not specified, please correct and run again.")
                                removeGlobalVariables
                                destroyLogger
                                Exit
                        }
                        else {
                                if ($bdsrg -ne "") {
                                        $global:gblbootdiagnosticstorageresourcegroup = $bdsrg
                                }
                                else {
                                        $global:gblbootdiagnosticstorageresourcegroup = $bootdiagnosticstorageresourcegroup
                                }
                        }
                }
                if ($trace -eq $true) {
                        $logger.trace("boot diagnostic storage resource group value: $global:gblbootdiagnosticstorageresourcegroup")
                }
        }

        #  populate backuppolicy parameter if input
        # Valid options for backuppolicy: "DefaultPolicy", "DXC30day", "DXC60day", "DXC90day"
        if ($backuppolicy -ne "") {
                if (($backuppolicy -eq "DefaultPolicy") -or ($backuppolicy -eq "DXC30day") -or ($backuppolicy -eq "DXC60day") -or ($backuppolicy -eq "DXC90day")) {
                        $global:gblbackuppolicy = $backuppolicy
                }
                else {
                        $global:gblbackuppolicy = "DefaultPolicy"
                }
        }
        else {
                $global:gblbackuppolicy = "DefaultPolicy"
        }
        $global:gblbackuppolicytag = $global:gblbackuppolicy

        #Check dxcPatchGroupName is inputted if dxcPatchgroup is set to true
        if (($dxcPatchGroup -eq $true) -and ($dxcPatchGroupName.length -eq 0)) {
                $logger.fatal("dxcPatchGroup set to true. dxcPatchGroupName must be set")
                removeGlobalVariables
                destroyLogger
                Exit
        }


        $logger.info(" ")
        $logger.info("Parameters have been validated.")
        $logger.info(" ")
}

Function selectedOptions {
        $logger.info(" ")
        $logger.info("Parameters selected for this run:")
        if ( $global:gblsymantec -eq "yes") {
                $logger.info("    Symantec CWP: yes")
        }
        else {
                $logger.info("    Symantec CWP: no")
        }

        if ($global:gblcrowdstrike -eq "yes") {
                $logger.info("    Crowdstrike: yes")
        }
        else {
                $logger.info("    Crowdstrike: no")
        }
        if ($global:gblazurebackup -eq "yes") {
                $logger.info("    Azure Backup: yes")
        }
        else {
                $logger.info("    Azure Backup: no")
        }
        if ($global:gblomsmonitoring -eq "yes") {
                $logger.info("    OMS Monitoring: yes")
        }
        else {
                $logger.info("    OMS Monitoring: no")
        }
        if ($global:gbldiagnosticextension -eq "yes") {
                $logger.info("    Diagnostic Extensions: yes")
        }
        else {
                $logger.info("    Diagnostic Extensions: no")
        }

        if ($global:gblbootdiagnostics -eq "yes") {
                $logger.info("    Boot Diagnostics: yes")
        }
        else {
                $logger.info("    Boot Diagnostics: no")
        }
}
Function getVMFromSubscription {
        if ($global:gblresourcegroup -eq "" -or $null -eq $global:gblresourcegroup ) {
                $allVMs = Get-AzVM
        }
        else {
                $allVMs = Get-AzVM -ResourceGroupName $global:gblresourcegroup
        }
        foreach ($vm in $allVMs) {
                if ($vm.Name -eq $vmname) {
                        return $vm
                }
        }
        return $null
}

Function getExistingTags([Microsoft.Azure.Commands.Compute.Models.PSVirtualMachineList]$vm) {

        # Check for existing tags on the VM
        if ($vm.Tags.Count) {
                $global:tags = makeJsonTags($vm.Tags)
                $logger.info(" ")
                $logger.info("Existing tags found: $global:tags")
        }
        Else {
                $global:tags = "{}"
                $logger.info(" ")
                $logger.info("No existing tags found")
        }
}
Function getVMStatus() {
        $running = 'no'
        $dc = Get-AzVM -ResourceGroupName $global:gblresourcegroup  -Name $vmname  -Status
        foreach ($status in $dc.Statuses.DisplayStatus) {
                if ($status -eq "VM running") {
                        $running = 'yes'
                }
        }
        return $running
}


Function getOperatingSystem() {
        $VMs = Get-AzVM -ResourceGroupName $global:gblresourcegroup | Select-Object Name, @{Name = "OSType"; Expression = { $_.StorageProfile.OSDisk.OSType } } | ForEach-Object { $_.Name + ";" + $_.OSType }
        #Write-Output $VMs
        foreach ($vm in $VMs) {
                $Name, $Type = $vm -split ";"
                if ($Name -eq $vmname) {
                        return $Type
                }
        }
        return $null
}

Function UpgradePStoV4($resourcegroup, $vmname, $level) {
        $PatchLocation = "C:\Windows\Temp\Windows6.1-KB2819745-x64-MultiPkg.msu"
        $CRLF = "`r`n"

        $f = New-TemporaryFile
        $line1 = '$PatchUrl = "https://dxcazuretoolsdev.blob.core.windows.net/installers/Windows6.1-KB2819745-x64-MultiPkg.msu"'
        $line2 = '$PatchLocation = "' + $PatchLocation + '"'
        $line3 = '(New-Object System.Net.WebClient).DownloadFile($PatchUrl, $PatchLocation)'
        $line1 + $CRLF + $line2 + $CRLF + $line3 | Out-File -FilePath $f -Force

        $logger.info("Invoke command to copy KB2819745 to VM")
        Invoke-AzVMRunCommand -ResourceGroupName $resourcegroup  -Name $vmname -CommandId 'RunPowerShellScript' -ScriptPath $f  1>$null 2>$null 3>$null  
 
        $line1 = 'Start-Process -FilePath WUSA.EXE -argumentlist "'
        $line2 = "$PatchLocation"
        $line3 = '  /quiet /norestart"  -Wait -PassThru'
        $line1 + $line2 + $line3 | Out-File -FilePath $f -Force

        $logger.info("Invoke command to install KB2819745 on VM")
        Invoke-AzVMRunCommand -ResourceGroupName $resourcegroup  -Name $vmname -CommandId 'RunPowerShellScript' -ScriptPath $f  1>$null 2>$null 3>$null 
        $logger.info("Install command returned")

        $line1 = '$pd = (Get-ChildItem C:\Windows\winsxs -recurse -include powershell.exe) '
        $line2 = 'foreach ($d in $pd) { '
        $line3 = '	$psv = (Get-Item $d).VersionInfo '
        $line4 = '	Write-Host $psv.ProductVersion '
        $line5 = '} '

        $line1 + $CRLF + $line2 + $CRLF + $line3 + $CRLF + $line4 + $CRLF + $line5 | Out-File -FilePath $f -Force

        $result = Invoke-AzVMRunCommand -ResourceGroupName $resourcegroup  -Name $vmname -CommandId 'RunPowerShellScript' -ScriptPath $f  -ErrorAction Ignore     
        $r = $result.Value[0].Message
        $vers = $r.Split([Environment]::NewLine, [StringSplitOptions]::RemoveEmptyEntries)
        $h = $vers.Length
        if ($trace -eq $true) {
                $logger.trace("ProductVersions found: $h") 
        }
        $v4Found = $false
        foreach ($v in $vers) {
                if ($v -match "6.3.9600.16406") {
                        $v4Found = $true
                }
        }
        $logger.info(" ")
        if (($h -ge 4) -And ($v4Found -eq $true)) {
                $logger.info("Restarting $vmname")
                Restart-AzVM -ResourceGroupName $resourcegroup -Name $vmname 1>$null 2>$null 3>$null
        }
        Remove-Item -Path $f  
}

Function windowsPowershellVersion($resourcegroup, $vmname, $attempt) {
        $setErrorAction = $ErrorActionPreference
        $ErrorActionPreference = 'silentlycontinue'
        $CRLF = "`r`n"
        $i = 0
        $powershellVersion = New-TemporaryFile
        '$ver = $PSVersionTable.PSVersion' + $CRLF + 'Write-Host $ver' | out-file -filepath $powershellVersion -Force

        $psv = Invoke-AzVMRunCommand -ResourceGroupName $resourcegroup -Name $vmname -CommandId 'RunPowerShellScript' -ScriptPath $powershellVersion -ErrorAction Ignore
        Remove-Item -Path $powershellVersion

        if ($trace -eq $true) {
                $msg = Write-Output $psv | Out-Host
                $logger.trace($msg)
        }

        if ($null -eq $psv.Value[1].Message -Or 
                $psv.Value[1].Message -Match "used by another process" -Or 
                $psv.Value[1].Message -Match "Run command extension execution is in progress") {
                $attempt = $attempt + 1
                if ($attempt -gt 3) {
                        $ErrorActionPreference = $setErrorAction
                        return $i
                }
                $logger.warn("windowsPowershellVersion stalled because of an error.  Retry attempt $attempt")
                Start-Sleep -Seconds 180
                $i = windowsPowershellVersion $resourcegroup $vmname $attempt
        }

        if ($psv.Value[0].DisplayStatus -Match "succeeded") {
                $v = $psv.Value[0].Message | Out-String
                if ($v.startsWith("1")) {
                        $i = 1
                }
                elseif ($v.startsWith("2")) {
                        $i = 2
                }
                elseif ($v.startsWith("3")) {
                        $i = 3
                }
                elseif ($v.startsWith("4")) {
                        $i = 4
                }
                elseif ($v.startsWith("5")) {
                        $i = 5
                }
                elseif ($v.startsWith("6")) {
                        $i = 6
                }
                elseif ($v.startsWith("7")) {
                        $i = 7
                }
                elseif ($v.startsWith("8")) {
                        $i = 8
                }
        }
        $ErrorActionPreference = $setErrorAction
        return $i
}

Function symantecCheckKernelSupport() {
        $content = $null
        $checkScript = 'checkCWP.ps1'
        $checkURL = ""

        # Get a temporary file and set its suffix to '.ps1' so it will be able to execute the powershell script
        $f = [IO.Path]::GetTempFileName() | Rename-Item -NewName { $_ -replace 'tmp$', 'ps1' } -PassThru

        if ($trace -eq $true) {
                $logger.trace("Temporary file $f")
        }
        $logger.info(" ")
        $logger.info("Calling checkCWP for kernel support")

        if ($armdev -eq $true) {
                $checkURL = "$($uridev)powershell/$($checkScript)$($global:tokendev)"
                $logger.info(" ")
                $logger.info("Running checkCWP from dev storage.")
                if ($trace -eq $true) {
                        $logger.trace(" ")
                        $logger.trace("checkURL:$checkURL")
                }
        }
        elseif ($armqa -eq $true) {
                $checkURL = "$($uriqa)$($checkScript)$($global:tokenqa)"
                $logger.trace(" ")
                $logger.info("Running checkCWP from QA storage.")
                if ($trace -eq $true) {
                        $logger.trace(" ") 
                        $logger.trace("checkURL:$checkURL")
                }
        }
        else {
                # Pull script from production installer storage
                $checkURL = "$($checkuri)$($checkScript)"
                if ($trace -eq $true) {
                        $logger.trace(" ") 
                        $logger.trace("checkURL:$checkURL")
                }
        }

        Try {
                . { Invoke-WebRequest $checkURL -OutFile $f }
        }
        Catch {
                $logger.fatal("Failure to retrieve checkCWP script.  Processing terminated.")
                removeGlobalVariables
                destroyLogger
                Exit
        }

        Try {
                if ($global:azurecloudshell -eq 'yes') {
                        if ($trace -eq $true) {
                                $content = . $f $vmname $keyvault -trace
                        }
                        else {
                                $content = . $f $vmname $keyvault
                        }
                }
                else {
                        if ($trace -eq $true) {
                                $content = . $f $vmname $keyvault -clientid $clientid -clientkey $clientkey -tenantid $tenantid -trace
                        }
                        else {
                                $content = . $f $vmname $keyvault -clientid $clientid -clientkey $clientkey -tenantid $tenantid
                        }
                }
        }
        Catch {
                $msg = $Error[0]
                $logger.fatal("checkCWP error: $msg")
                $logger.fatal("Failure on call to checkCWP.  Processing terminated.")
                removeGlobalVariables
                destroyLogger
                Exit
        }
        # Remove the temporary file, if it still exists
        if (Test-Path $f) {
                Remove-Item $f
        }

        if ($null -eq $content ) {
                $logger.fatal("ERROR: Failure detected in checkCWP processing.  Session terminated.")
                removeGlobalVariables
                destroyLogger
                Exit
        }


        return $content
}

Function runCmdOnVM($cmd, $resourcegroup, $vmname) {
        try {
                # Get temporary file to write out commands to be run on the server
                $TempFile = New-TemporaryFile
                $cmd | out-file -filepath $TempFile -append
                # Invoke Azure to run commands on the server
                $getReturn = Invoke-AzVMRunCommand -ResourceGroupName "$resourcegroup" -Name "$vmname" -CommandId 'RunShellScript' -ScriptPath $TempFile | Out-String
        }
        catch {
                $logger.trace("Failed to run cmd on VM: $getReturn")
                Exit
        }
        finally {
                # Remove temporary file
                Remove-Item -Path $TempFile
        }
        return $getReturn
}

Function makeJsonTags($tags) {
        $json = "{ "
        $count = 1
        foreach ($key in $tags.Keys) {
                If ($count -lt $tags.count) {

                        $json = "$($json) `"$($key -replace '"', '\"')`" : `"$($($tags[$key] -replace '"', '\"'))`","
                }
                Else {
                        $json = "$($json) `"$($key -replace '"', '\"')`" : `"$($($tags[$key] -replace '"', '\"'))`" }"
                }
                $count = $count + 1
        }
        return $json
}

Function validateOMSExtension() {
        $logger.info("Validating that the OMS/MicrosoftMonitoringAgent extension is not already installed")
        $vm = Get-AzVM -ResourceGroupName $global:gblresourceGroup -Name $vmname
        $ext = $vm.Extensions
        $global:removeExtension = ""
        foreach ($e in $ext) {
                if ($global:gblomsmonitoring -eq "yes") {
                        if ($e.Name.ToLower() -match 'omsagent') {
                                # OMS found on the VM, remove it so that a correct OMS can be installed
                                # v0.1 Write-Host "OMSAgent already installed on VM.  New install is disabled" -ForegroundColor yellow
                                # v0.1$global:gblomsmonitoring = "no"
                                if ($prototype -eq $true) {
                                        $logger.warn("OMSAgent already installed on VM.  Prototype notification only")
                                }
                                else {
                                        if ($global:removeExtension -eq "") {
                                                $logger.warn("OMSAgent already installed on VM.  Marked for removal before installing new agent")
                                                $global:removeExtension = "Remove-AzVMExtension -ResourceGroupName {0} -VMName {1} -Name {2} -Force" -f $global:gblresourcegroup, $vmname, $e.Name
                                        }
                                }
                        }

                        if ($e.Name.ToLower() -match 'microsoftmonitoringagent') {
                                if ($prototype -eq $true) {
                                        $logger.warn("MicrosoftMonitoringAgent already installed on VM.  Prototype notification only")
                                }
                                else {
                                        $logger.warn("MicrosoftMonitoringAgent already installed on VM.  Marked for removal before installing new agent")
                                        $global:removeExtension = 'Remove-AzVMExtension -ResourceGroupName {0} -VMName {1} -Name {2} -Force' -f $global:gblresourcegroup, $vmname, $e.Name
                                }
                        }
                }
        }
}
Function removeCustomScriptExtension() {
        #  Removing custom script extension, only if customer has selected CrowdStrike to be installed.
        if ($global:gblcrowdstrike -eq "yes") {
                $logger.info(" ")
                $logger.info("Removing CustomScript Extensions")
                $vm = Get-AzVM -ResourceGroupName $global:gblresourceGroup -Name $vmname
                $ext = $vm.Extensions

                foreach ($e in $ext) {
                        if ($e.VirtualMachineExtensionType.ToLower() -match "customscript") {
                                $csext = $e.Name
                                $vmname = $vm.Name
                                $cs = "Remove-AzVMExtension -ResourceGroupName {0} -VMName {1} -Name {2} -Force" -f $global:gblresourcegroup, $vmname, $csext
                                Invoke-Expression -Command $cs 1>$null 2>$null 3>$null
                        }
                }
        }
}
Function validateCrowdStrikeExtension() {
        $logger.info(" ")
        $logger.info("Validating that the CrowdStrike extension is not already installed")
        $vm = Get-AzVM -ResourceGroupName $global:gblresourceGroup -Name $vmname
        $ext = $vm.Extensions

        foreach ($e in $ext) {
                if ($global:gblcrowdstrike -eq "yes") {
                        if ($e.Name.ToLower() -match 'crowd') {
                                $logger.warn("CrowdStrike already installed on VM.  New install is disabled")
                                $global:gblcrowdstrike = "no"
                        }
                }
        }
}

Function validateCWPExtension() {
        $logger.info(" ")
        $logger.info("Validating that the Symantec CWP extension is not already installed")
        $vm = Get-AzVM -ResourceGroupName $global:gblresourceGroup -Name $vmname
        $ext = $vm.Extensions

        foreach ($e in $ext) {
                if ($global:gblsymantec -eq "yes") {
                        if ($e.Name.ToLower() -match 'cwp') {
                                $logger.warn("Symantec CWP already installed on VM.  New install is disabled")
                                $global:gblsymantec = "no"
                        }
                }
        }
}
Function validateDiagnosticExtension() {
        $logger.info(" ")
        $logger.info("Validating that the Diagnostic Extension is not already installed")
        $vm = Get-AzVM -ResourceGroupName $global:gblresourceGroup -Name $vmname
        $ext = $vm.Extensions

        foreach ($e in $ext) {
                if ($global:gbldiagnosticextension -eq "yes") {
                        if ($e.Name.ToLower() -match 'diag') {
                                $logger.warn("Diagnostic extension already installed on VM.  New install is disabled")
                                $global:gbldiagnosticextension = "no"
                        }
                }
        }

        if ($global:offer.ToUpper().Contains("RHEL") -Or $global:offer.ToUpper().Contains("CENTOS") -Or $global:offer.ToUpper().Contains("ORACLE")) {
                if ($global:osType -eq "rhel8" -Or $global:osType -eq "centos8" -Or $global:osType -eq "oracle-linux8") {
                        if ($global:gbldiagnosticextension -eq "yes" ) {
                                $logger.warn("Diagnostic extension is not supported on this VM.  New install is disabled")
                                $global:gbldiagnosticextension = "no"    
                        }
                }
        }
}

Function validateBackup() {
        $logger.info(" ")
        $logger.info("Validating that VM is not already defined in azure backup")
        $vault = Get-AzRecoveryServicesVault -ResourceGroupName $global:gblrecoveryvaultresourcegroup -Name $global:gblrecoveryvault 2>$null 3>$null
        if ($null -eq $vault) {
                return
        }
        $Container = Get-AzRecoveryServicesBackupContainer -ContainerType AzureVM -Status Registered -FriendlyName $vmname  -VaultId $vault.ID  2>$null 3>$null
        if ($null -ne $Container) {
                $logger.warn("VM already in azure backup.  New install is disabled")
                $global:gblazurebackup = "no"
                # get additional information about the VM backup status
                $backupitem = Get-AzRecoveryServicesBackupItem -Container $container -WorkloadType AzureVM -VaultId $vault.ID
                $backupData = $backupitem | Select-Object Name, HealthStatus, ProtectionStatus, ProtectionState, LastBackupStatus
                if ($backupData.ProtectionState -eq "IRPending") {
                        $logger.info("Azure backup protection state: initial backup pending")
                }
                elseif ($backupData.ProtectionState -eq "ProtectionStopped") {
                        $logger.info("Azure backup protection state: backup disabled")
                }
                elseif ($backupData.ProtectionState -eq "Protected") {
                        $logger.info("Azure backup protection state: successful backup")
                }
                else {
                        $msg = $backupData.ProtectionState
                        $logger.info("Azure backup protection state: $msg")
                }
                $logger.info(" ")
        }
}


Function commonParameters([string[]]$a) {

        $a += "`"azureBackup`" : `"{0}`"," -f $global:gblazurebackup
        if ($global:gblsymantec -eq "yes") {
                $a += "`"symantec`" : `"{0}`"," -f $global:gblsymantec
                if ($type -ne "Windows") {
                        $a += "`"osType`" : `"{0}`"," -f $global:osType
                }
        }
        else {
                $a += "`"crowdstrike`" : `"{0}`"," -f $global:gblcrowdstrike
                if ($type -ne "Windows") {
                        $a += "`"osType`" : `"{0}`"," -f $global:osType
                }
        }
        $a += "`"diagnosticExtension`" : `"{0}`"," -f $global:gbldiagnosticextension
        $a += "`"omsMonitoring`" : `"{0}`"," -f $global:gblomsmonitoring
        $a += "`"existingTags`" : {0}," -f $global:tags
        $a += "`"newTags`" : {0}," -f $global:newtags
        $a += "`"vmLocation`" : `"{0}`"," -f $location
        return $a
}

Function lastParameter([string[]]$a) {
        $a += "`"vmName`" : `"{0}`"" -f $vmname
        return $a
}

Function symantecParameters([string[]]$a) {
        $a += "`"SymantecCustomerId`" : `"{0}`"," -f $global:SymantecCustomerId
        $a += "`"SymantecCustomerSecretKey`" : `"{0}`"," -f $global:SymantecCustomerSecretKey
        $a += "`"SymantecDomainId`" : `"{0}`"," -f $global:SymantecDomainId
        if ($type -eq "Windows") {
                $a += "`"SymantecClientId`" : `"{0}`"," -f $global:SymantecClientId
                $a += "`"SymantecClientSecretKey`" : `"{0}`"," -f $global:SymantecClientSecretKey
        }
        return $a
}
Function crowdStrikeParameters([string[]]$a) {
        $a += "`"csCID`" : `"{0}`"," -f $global:crowdStrikeCID
        if ($type -ne "Linux") {
                $a += "`"csuninstallpw`" : `"{0}`"," -f $global:csuninstallpw
        }
        return $a
}

Function omsMonitoringParameters([string[]]$a) {
        $a += "`"workspaceId`" : `"{0}`"," -f $global:omsWorkspaceId
        $a += "`"workspaceKey`" : `"{0}`"," -f $global:omsWorkspaceKey
        return $a
}

Function diagnosticExtensionParameters([string[]]$a) {
        $a += "`"existingBootDiagStorageName`" : `"{0}`"," -f $global:gblbootdiagnosticstoragename
        $a += "`"existingBootDiagStorageResourceGroup`" : `"{0}`"," -f $global:gblbootdiagnosticstorageresourcegroup
        return $a
}

Function azurebackupParameter([string[]]$a) {
        $a += "`"existingBackupPolicy`" : `"{0}`"," -f $global:gblbackuppolicy
        $a += "`"existingRecoveryServicesVault`" : `"{0}`"," -f $global:gblrecoveryvault
        $a += "`"existingRecoveryServicesVaultResourceGroup`" : `"{0}`"," -f $global:gblrecoveryvaultresourcegroup
        return $a
}

Function ConvertTo-HashTable {
        [CmdletBinding()]
        [OutputType('hashtable')]
        param (
                [Parameter(ValueFromPipeline)]
                $InputObject
        )

        process {
                ## Return null if the input is null. This can happen when calling the function
                ## recursively and a property is null
                if ($null -eq $InputObject) {
                        return $null
                }

                ## Check if the input is an array or collection. If so, we also need to convert
                ## those types into hash tables as well. This function will convert all child
                ## objects into hash tables (if applicable)
                if ($InputObject -is [System.Collections.IEnumerable] -and $InputObject -isnot [string]) {
                        $collection = @(
                                foreach ($object in $InputObject) {
                                        ConvertTo-Hashtable -InputObject $object
                                }
                        )

                        ## Return the array but don't enumerate it because the object may be pretty complex
                        Write-Output -NoEnumerate $collection
                }
                elseif ($InputObject -is [psobject]) {
                        ## If the object has properties that need enumeration
                        ## Convert it to its own hash table and return it
                        $hash = @{ }
                        foreach ($property in $InputObject.PSObject.Properties) {
                                $hash[$property.Name] = ConvertTo-Hashtable -InputObject $property.Value
                        }
                        $hash
                }
                else {
                        ## If the object isn't an array, collection, or other object, it's already a hash table
                        ## So just return it.
                        $InputObject
                }
        }
}

Function buildParameterList() {
        $parameters = "{ "
        # First off, build the parameters that are common to all ARM templates
        $parameters = commonParameters($parameters)
        # Then check to see if we are putting on CWP otherwise default everything to crowdstrike
        if ($global:gblsymantec -eq "yes") {
                $parameters = symantecParameters($parameters)
        }
        else {
                $parameters = crowdStrikeParameters($parameters)
        }
        # Put on OMS monitoring
        $parameters = omsMonitoringParameters($parameters)
        # Put on diagnostic extensions
        $parameters = diagnosticExtensionParameters($parameters)
        # Put in azure backup if requested
        $parameters = azurebackupParameter($parameters)
        # Finally throw out the vmName, because we know that we will always have a vmName
        # and it makes it a good parameter to end with.
        $parameters = lastParameter($parameters)
        $parameters += " }"
        return $parameters
}

Function getRandomDeploymentName() {
        $randStr = -join ((65..90) + (97..122) | Get-Random -Count 5 | ForEach-Object { [char]$_ })
        $randName = "makeManagedAuto-$randStr"
        return($randName)
}

Function deployARMTemplate($template, $parameters) {
        $Error.Clear()
        $deploymentName = getRandomDeploymentName
        $logger.info("Azure deployment name for this run: $deploymentName")
        $output = New-AzResourceGroupDeployment -Name $deploymentName -ResourceGroupName $global:gblresourcegroup -TemplateParameterObject $parameters -TemplateUri $template
        $msg = $output.DeploymentName
        $logger.info(" ")
        $logger.info("Deployment Name: $msg")
        $msg = $output.ResourceGroupName
        $logger.info("Resource Group Name: $msg")
        $msg = $output.ProvisioningState
        $logger.info("Provisioning State: $msg")
        $msg = $output.Timestamp
        $logger.info("Timestamp: $msg")
        If ($Error) {
                $logger.fatal("ARM Template Deployment failed. For detailed error message, please check deployment error in the Resource Group from Azure Portal.")
                removeGlobalVariables
                destroyLogger
                Exit
        }
        else {
                $logger.info("successful deployment: Adding dxcConfigurationCheck tag")
                $OrrDate = Get-Date -Format "yyyyMMddTHHmmssZ" -asUTC
                $allTags = (Get-AzResource -ResourceGroupName $global:gblresourcegroup -Name $vmname).Tags
                $allTags.Remove("dxcConfigurationCheck")
                $allTags += @{dxcConfigurationCheck=$OrrDate}
                Set-AzResource -ResourceGroupName $global:gblresourcegroup -Name $vmname -ResourceType "Microsoft.Compute/VirtualMachines" -Tag $allTags -Force
        }
}

Function checkDeprecated() {
        if ($nocrowdstrike -eq $true ) {
                $logger.fatal("Parameter (-nocrowdstrike) has been deprecated and is no longer supported in this release")
                removeGlobalVariables
                destroyLogger
                Exit
        }
}

Function replaceTags($vm) {
        if ($trace -eq $true) {
                $logger.trace(" ")
                $logger.trace("Replacing existing tags found before makeManaged run")
        }
        # Clean out existing tags.
        $tags = "{}"
        $tags = $tags | ConvertFrom-Json | ConvertTo-HashTable
        Set-AzResource -ResourceGroupName $vm.ResourceGroupName -ResourceName $vm.Name -Tag $tags -Force -ResourceType Microsoft.Compute/VirtualMachines  1>$null 2>$null 3>$null
        # Apply existing tags found at start of run
        $tags = $global:tags | ConvertFrom-Json | ConvertTo-HashTable
        Set-AzResource -ResourceGroupName $vm.ResourceGroupName -ResourceName $vm.Name -Tag $tags -Force -ResourceType Microsoft.Compute/VirtualMachines  1>$null 2>$null 3>$null
}

Function removeGlobalVariables() {
        $globalVariables = @(
                'OSNAME',
                'SymantecClientId',
                'SymantecClientSecretKey',
                'SymantecCustomerId',
                'SymantecCustomerSecretKey',
                'SymantecDomainId',
                'azurecloudshell',
                'crowdStrikeCID',
                'csuninstallpw',
                'endpointProtection',
                'gblazurebackup',
                'gblbackuppolicy',
                'gblbootdiagnosticstoragename',
                'gblbootdiagnosticstorageresourcegroup',
                'gblcrowdstrike',
                'gbldiagnosticextension',
                'gblomsmonitoring',
                'gblrecoveryvault',
                'gblrecoveryvaultresourcegroup',
                'gblresourceGroup',
                'gblresourcegroup',
                'gblsymantec',
                'location',
                'offer',
                'omsWorkspaceId',
                'omsWorkspaceKey',
                'osVersion',
                'osType',
                'removeExtension',
                'sku',
                'tags',
                'token',
                'tokenqa')

        $logger.info(" ")
        $logger.info("Removing global variables")

        foreach ($globalName in $globalVariables) {
                Remove-Variable -Name $globalName -Force -Scope Global  1>$null 2>$null 3>$null
        }
	
        # Remove Microsoft hack for "Breaking News" ouitput
        Set-Item Env:\SuppressAzurePowerShellBreakingChangeWarnings "false"


}

Function checkActivateScript($f) {
        $line1 = 'cscript c:\windows\system32\slmgr.vbs /dlv'
        $line1 | Out-File -FilePath $f -Force
}

Function activateScript($f) {
        $line1 = 'cscript c:\windows\system32\slmgr.vbs /ato'
        $line1 | Out-File -FilePath $f -Force
        #return $f
}

Function installBootDiagnostics() {
        $logger.info(" ")
        $logger.info("Installing boot diagnostics")
        $vm = Get-AzVM -ResourceGroupName $global:gblresourceGroup -Name $vmname
        Set-AzVMBootDiagnostic -VM $vm -Enable -ResourceGroupName $global:gblbootdiagnosticstorageresourcegroup -StorageAccountName $global:gblbootdiagnosticstoragename     1>$null 2>$null 3>$null    
        Update-AzVM -VM $vm -ResourceGroupName $global:gblresourceGroup  1>$null 2>$null 3>$null
}


Function getOSType() {
        if ($null -eq $global:OSNAME) {
                $logger.warn("VM has no offer specified in Azure")
                return $null
        }        
        ElseIf ($global:OSNAME.ToUpper().Contains("RED HAT") -or $global:OSNAME.ToUpper().Contains("RHEL")) {
                if ($global:sku.ToLower().StartsWith("cis")) {
                        $s = $global:offer -split ('-')
                        $v = $s[2]
                }
                else {
                        $v = $global:sku.Substring(0, 1)
                }
                return "rhel$v"
        }
        ElseIf ($global:OSNAME.ToUpper().Contains("SLES") -or $global:OSNAME.ToUpper().Contains("SUSE")) {
                 if ($global:sku.ToLower().StartsWith("cis")) {
                        $cisoffer = $global:offer -split ('-')
                        $v = $cisoffer[3]
                } 
                elseif ($global:sku.Contains('12-sp4')) {
                        $v = '12-sp4'
                }
                elseif ($global:offer.Contains('12-sp5')) {
                        $v = '12-sp5'
                }
                elseif ($global:offer.Contains('15-sp1')) {
                        $v = '15-sp1'
                }
                return "sles$v"
        }
        ElseIf ($global:OSNAME.ToUpper().Contains("UBUNTU")) {
                if ($global:sku.ToLower().StartsWith("cis")) {
                        $s = $global:offer -split ('-')
                        if ($global:offer.Contains('1604')) {
                                $v = '16'
                        }
                        elseif ($global:offer.Contains('1804')) {
                                $v = '18'
                        }
                        elseif ($global:offer.Contains('2004')) {
                                $v = '20'
                        }
                }
                else {
                        $v = $global:sku.Substring(0, 2)
                }
                return "ubuntuserver$v"
        }
        ElseIf ($global:OSNAME.ToUpper().Contains("CENTOS")) {
                if ($global:offer.ToLower().StartsWith("cis")) {
                        $s = $global:offer -split ('-')
                        $v = $s[2]
                }
                else {
                        $v = $global:sku.Substring(0, 1)
                }
                return "centos$v"
        }
        ElseIf ($global:OSNAME.ToUpper().Contains("ORACLE")) {
                if ($global:sku.ToLower().StartsWith("cis")) {
                        $s = $global:offer -split ('-')
                        $v = $s[3]
                }
                else {
                        $v = $global:sku.Substring(0, 1)
                }
                return "oracle-linux$v"
        }
        ElseIf ($global:OSNAME.ToUpper().Contains("DEBIAN")) {
                $v = $global:sku.Substring(0, 1)
                return "debian$v"
        }
        Else {
                return $null
        }
}

Function checkVersion($sku) {
        $index = 0
        Do {
                if ($sku[$index] -eq '.' -Or $sku[$index] -match "^\d+$") {
                }
                else {
                        return $false
                }
                $index = $index + 1
        } while ($index -lt $sku.length)
        return $true
}


######################################################################
#                                MAIN                                #
######################################################################
validateLoggerColors
initializeLogger
$logger = $global:logger

# Put in Microsoft hack to suppress "Breaking New" messages
Set-Item Env:\SuppressAzurePowerShellBreakingChangeWarnings "true"



# Write out verson of script running
$logger.info(" ")
$logger.info("makeManagedAuto Version: $scriptVersion")
if ($prototype -eq $true) {
        $logger.info("running in prototype mode")
}

# Check for any deprecated commands that might have been entered
checkDeprecated

# Check if all the parameters are valid
if ($trace -eq $true) {
        $logger.trace("Check parameters input")
}
Check-Parameters

# Get started with makeManagedAuto processing
getCredentials

# if bypassing endpoint protection set the variables and skip any other checks
if ($noendpointprotection -eq $true) {
        $global:gblcrowdstrike = "no"
        $global:gblsymantec = "no"
        $logger.info(" ")
        $logger.info("disable CrowdStrike from install")
        $logger.info("disable Symantec CWP from install")
}
else {
        # Get endpoint protection on the subscription
        getEndPointProtection
}
# Display options being used for this run
selectedOptions

# Get key vault values for variables
getKeyVaultValues

# Find VM in subscription
$vm = getVMFromSubscription
if ($null -eq $vm ) {
        $logger.fatal("VM was not found in the subscription. Please check name and rerun.")
        removeGlobalVariables
        destroyLogger
        Exit
}

# Get existing tags if any exist
getExistingTags($vm)

$global:gblresourcegroup = $vm.ResourceGroupName
$logger.info(" ")
$logger.info("Found $vmname in Resource Group $global:gblresourcegroup")
$global:location = $vm.Location


# Verify that the VM is in a running state
$running = getVMStatus
if ($running -ne 'yes') {
        $logger.fatal("VM does not appear to be running.  Processing halted")
        removeGlobalVariables
        destroyLogger
        Exit
}
else {
        $logger.info("VM appears to be running.")
}

# Get to where the information is about sku and offer
$storageProfile = $vm.StorageProfile
$imageReference = $storageProfile.ImageReference
$publisher = $imageReference.Publisher
$global:offer = $imageReference.Offer
$global:sku = $imageReference.Sku
$logger.info(" ")
$logger.info("Offer: $global:offer    Sku: $global:sku     Publisher: $publisher")

# Get the type of VM  (linux/windows)
$type = getOperatingSystem
$logger.info("operatingSystem: $type")
if ($type -eq "Linux") {
        $global:OSNAME = $global:offer
        $global:osType = getOSType
        $logger.info("osType: $global:osType")
}
else {
        $global:OSNAME = "Windows"
        if ($global:gblsymantec -eq "yes") {
                if ($global:sku.ToLower().Contains("2008-r2")) {
                        $logger.info("Windows 2008-R2 found and CWP requested.  Beginning powershell installation check")
                        # OK, we are dealing with a Windows 2008R2-SP1 VM
                        $logger.info("Checking if Windows on $vmname is authorized.")
                        # Get a temporary file to stuff powershell script into
                        $f = New-TemporaryFile
                        checkActivateScript $f
                        $query = $null
                        $attempt = 0
                        Do {
                                $query = Invoke-AzVMRunCommand -ResourceGroupName $global:gblresourcegroup -Name $vmname -CommandId 'RunPowerShellScript' -ScriptPath $f   -ErrorAction Ignore
                                if ($query.Value[0].Message -Match "License Status:") {
                                        break
                                }
                                $attempt = $attempt + 1
                                if ($attempt -gt 4) {
                                        $logger.fatal("Unable to determine if $vmname is activated. Processing halted.")
                                        removeGlobalVariables
                                        destroyLogger
                                        Exit
                                }
                                $logger.info("Trying to determine Windows activation: $activateAttempts attempt(s).")
                                Start-Sleep -Seconds 180
                        } Until ($query.Value[0].Message -Match "License Status:")

                        if ($trace -eq $true) {
                                $msg = $query.Value[0].Message
                                $logger.trace($msg) 
                        }
                        if ($query.Value[0].Message -Match "License Status: Notification") {
                                $logger.info("Windows is not authorized on $vmname.  Attempting to authorize it.")
                                activateScript $f
                                $activateAttempts = 0
                                do {
                                        $activate = Invoke-AzVMRunCommand -ResourceGroupName $global:gblresourcegroup -Name $vmname -CommandId 'RunPowerShellScript' -ScriptPath $f
                                        if ($trace -eq $true) {
                                                $msg = $activate.Value[0].Message
                                                $logger.trace($msg)
                                        }  
                                        if ($activate.Value[0].Message -Match "Product activated successfully") {
                                                $logger.info("$vmname authorized successfully.")
                                                break
                                        }
                                        else {
                                                $activateAttempts = $activateAttempts + 1
                                                if ($activateAttempts -gt 3) {
                                                        $logger.fatal("$vmname does not appear to be activated. Processing halted.")
                                                        removeGlobalVariables
                                                        destroyLogger
                                                        Exit
                                                }
                                                $logger.warn("Windows did not activate. Retry attempt $activateAttempts")
                                                Start-Sleep -Seconds 180
                                        }
                                } while ($activateAttempts -lt 100)
                        }
                        else {
                                $logger.info("$vmname currently activated.")
                        }
                        Remove-Item -Path $f

                        $psVersion = windowsPowershellVersion $global:gblresourcegroup $vmname 0
                        $logger.info("VM: $vmname has powershellVersion $psVersion")
                        if ($psVersion -lt 4) {
                                $logger.warn("VM does not have high enough powershell version for CWP. Attempting to upgrade the powershell version.")
                                $attemptLoop = 0
                                Do {
                                        $performance = Measure-Command { UpgradePStoV4 $global:gblresourcegroup $vmname 0 }
                                        $msg = $performance.TotalMinutes
                                        $logger.info("UpgradePStoV4 execution time: $msg minutes")
                                        Start-Sleep -Seconds 60
                                        # Check if we actually upgraded the powershell version
                                        $psVersion = windowsPowershellVersion $vm.ResourceGroupName $vmname 0
                                        if ($psVersion -lt 4) {
                                                $attemptLoop = $attemptLoop + 1
                                                if ($attemptLoop -lt 4) {
                                                        $logger.warn("Powershell not upgraded. Retry attempt $attemptLoop")
                                                        Restart-AzVM -ResourceGroupName $vm.ResourceGroupName -Name $vmname 1>$null 2>$null 3>$null
                                                        Start-Sleep -Seconds 120
                                                }
                                                else {
                                                        break
                                                }
                                        }
                                        else {
                                                break
                                        }
                                } while ($attemptLoop -lt 100)

                                $logger.info("VM: $vmname now has powershellVersion $psVersion")
                                if ($psVersion -lt 4) {
                                        # Something went wrong, we need to stop this deployment
                                        $logger.fatal("Powershell does not appear to have been upgraded on $vmname.  Processing halted.")
                                        removeGlobalVariables
                                        destroyLogger
                                        Exit
                                }
                        } 
                }
        }
}

# Validate extensions already installed
if ($global:gblomsmonitoring -eq "yes") {
        # Validate that oms is not already installed
        validateOMSExtension
}

if ($global:gblcrowdstrike -eq "yes") {
        # Validate a valid offer (RHEL, Debian, etc.) is present.
        if (($null -eq $global:OSNAME) -and ($global:endpointProtection -eq 'crowdstrike')) {
                $logger.fatal("VM has no offer specified, which is required for crowdstrike installer.")
                removeGlobalVariables
                destroyLogger
                Exit
        }
        else {}
        # Validate that crowdstrike is not already installed
        validateCrowdStrikeExtension
}

if ($global:gblsymantec -eq "yes") {
        # Validate that symantec cwp is not already installed
        validateCWPExtension
}

if ($global:gbldiagnosticextension -eq "yes") {
        # Validate that diagnostic extension is not already installed
        validateDiagnosticExtension





}
# Validate that vm isn't aleady in azure backup
if ($global:gblazurebackup -eq "yes") {
        validateBackup
}

if ($global:gblsymantec -eq "yes") {
        if ($overrideCWPCheck -eq $false) {
                $performance = Measure-Command { $content = symantecCheckKernelSupport }
                $msg = $content.supported
                $logger.info("$vmname supported by CWP: $msg")
                $msg = $performance.TotalSeconds
                $logger.info("Symantec check kernel execution time: $msg seconds") 
                if ($trace -eq $true) {
                        $msg = $content.description
                        $logger.trace("Description: $msg")
                        $logger.trace(" ")
                }
                if ($content.supported -ne "True") {
                        if ($type -eq "Linux") {
                                $logger.fatal("VM of type $global:OSNAME and kernel version of $global:KERNEL is not supported by CWP.  Processing halted.")
                        }
                        else {
                                $logger.fatal("VM of type $global:OSNAME is not supported by CWP.  Processing halted.")
                        }
                        removeGlobalVariables
                        destroyLogger
                        Exit
                }
        }
        else {
                $logger.warn("Overriding CWP kernel check for VM: $vmname")
        }

        if ($type -eq "Linux") {
                # We are doing CWP, so get the correct ARM template for that
                $makeManagedJson = "makeManagedLinuxCWP.json"
                $logger.info("makeManaged Json to use: $makeManagedJson")
        }
        else {
                # Must be doing Windows CWP
                $makeManagedJson = "makeManagedWindowsCWP.json"
                $logger.info("makeManaged Json to use: $makeManagedJson")
        }
        
        if ($armdev -eq $true) {
                $logger.info(" ")
                $logger.info("Running with dev makeManaged ARM templates.")
                if ($trace -eq $true) {
                        $logger.trace(" ")
                        $msg = "URL:$($uridev)templates/$($makeManagedJson)$($global:tokendev)"
                        $logger.trace($msg)
                }
                $makeManagedTemplate = "$($uridev)templates/$($makeManagedJson)$($global:tokendev)"
        }
        elseif ($armqa -eq $true) {
                $logger.info(" ")
                $logger.info("Running with QA makeManaged ARM templates.")
                if ($trace -eq $true) {
                        $logger.trace(" ")
                        $msg = "URL:$($uriqa)$($makeManagedJson)$($global:tokenqa)"
                        $logger.trace($msg)
                }
                $makeManagedTemplate = "$($uriqa)$($makeManagedJson)$($global:tokenqa)"
        }
        else {
                if ($trace -eq $true) {
                        $logger.trace(" ")
                        $msg = "URL:$($uri)$($makeManagedJson)$($global:token)"
                        $logger.trace($msg)
                }
                $makeManagedTemplate = "$($uri)$($makeManagedJson)$($global:token)"
        }
}
else {
        If ($global:OSNAME.ToUpper().Contains("WINDOWS")) {
                $makeManagedJson = "makeManagedWindows.json"
        }
        Else {
                $makeManagedJson = "makeManagedLinux.json"
        }

        $logger.info("makeManaged Json to use: $makeManagedJson")
        if ($armdev -eq $true) {
                $logger.info(" ")
                $logger.info("Running with dev makeManaged ARM templates.")
                if ($trace -eq $true) {
                        $logger.trace(" ")
                        $msg = "URL:$($uridev)templates/$($makeManagedJson)$($global:tokendev)"
                        $logger.trace($msg)
                }
                $makeManagedTemplate = "$($uridev)templates/$($makeManagedJson)$($global:tokendev)"
        }
        elseif ($armqa -eq $true) {
                $logger.info(" ")
                $logger.info("Running with QA makeManaged ARM templates.")
                if ($trace -eq $true) {
                        $logger.trace(" ")
                        $msg = "URL:$($uriqa)$($makeManagedJson)$($global:tokenqa)"
                        $logger.trace($msg)
                }
                $makeManagedTemplate = "$($uriqa)$($makeManagedJson)$($global:tokenqa)"
        }
        else {
                if ($trace -eq $true) {
                        $logger.trace(" ")
                        $msg = "URL:$($uri)$($makeManagedJson)$($global:token)"
                        $logger.trace($msg)
                }
                $makeManagedTemplate = "$($uri)$($makeManagedJson)$($global:token)"
        }
}

if ($null -ne $makeManagedTemplate -and $makeManagedTemplate -ne "") {
        # check if we have to remove an OMS/microsoftmanagedagent before we call the ARM template
        if ($global:removeExtension -ne "" -and $null -ne $global:removeExtension) {
                $logger.warn("Removing OMS/microsoftmonitoringagent....")
                Invoke-Expression -Command $global:removeExtension 1>$null 2>$null 3>$null
        }
}

# Check if VM falls within the selected few that need to have their repos adjusted
# Pulled this out of the ARM templates because they used a custom script to run this which is causing problems elsewhere.
if ($prototype -eq $false) {
        if ($global:offer.ToUpper().Contains("CENTOS")) {
                if ($global:sku -eq "6.7" -or $global:sku -eq "6.8" -or $global:sku -eq "6.9") {
                        # Run yum command here
                        $logger.info("Running yum command to adjust the repo.")
                        $cmd = "yum update -y --disablerepo='*' --enablerepo='*microsoft*'"
                        $ret = runCmdOnVM $cmd $global:gblresourcegroup $vmname
                } 
        }
        elseif ($global:offer.ToUpper().Contains("RHEL")) {
                if ($global:sku -eq "6.7" -or $global:sku -eq "6.8" -or $global:sku -eq "6.9" -or $global:sku -eq "6.10" -or $global:sku -eq "7.3") {
                        # Run yum command here
                        $logger.info("Running yum command to adjust the repo.")
                        $cmd = "yum update -y --disablerepo='*' --enablerepo='*microsoft*'"
                        $ret = runCmdOnVM $cmd $global:gblresourcegroup $vmname
                }
        }
        elseif ($global:offer.ToUpper().Contains("ORACLE")) {
                if ($global:sku -eq "6.7" -or $global:sku -eq "6.8" -or $global:sku -eq "6.9" -or $global:sku -eq "6.10" -or $global:sku -eq "7.3") {
                        # Run yum command here
                        $logger.info("Running yum command to adjust the repo.")
                        $cmd = "yum update -y --disablerepo='*' --enablerepo='*microsoft*'"
                        $ret = runCmdOnVM $cmd $global:gblresourcegroup $vmname
                }
        }
        elseif ($global:offer.ToUpper().Contains("SUSE") -Or $global:offer.ToUpper().Contains("SLES")) {
                if ($global:sku.ToUpper().Contains("12-SP4") -Or $global:sku.ToUpper().Contains("12-SP5") -Or $global:sku.ToUpper().Contains("12-SP4-GEN2") -Or $global:offer.ToUpper().Contains("CIS-SUSE-12-11")) {
                        # Run zypper command here
                        $logger.info("Running zypper command to adjust the repo.")
                        $cmd = "zypper --non-interactive addrepo https://download.opensuse.org/repositories/openSUSE:Leap:15.1:Update/standard/openSUSE:Leap:15.1:Update.repo ; zypper mr --all -f ; zypper --gpg-auto-import-keys ref ; zypper install -y libgthread-2_0-0"
                        $ret = runCmdOnVM $cmd $global:gblresourcegroup $vmname
                }  
        } 
}
else {
        if ($global:gblbootdiagnostics -eq "yes") {
                $logger.warn("In prototype mode, skipping repo adjustment.")
        }      
}
# Check if we are doing CWP agent install AND the VM type is (RHEL or CentOS) AND the version is 7 or 8, then attempt to run extendOPT
if ($prototype -eq $false) {
        if ($global:gblsymantec -eq "yes") {
                if ($global:offer.ToUpper().Contains("CENTOS") -Or $global:offer.ToUpper().Contains("RHEL")) {
                        if ($global:osType -eq "centos7" -Or $global:osType -eq "centos8" -Or $global:osType -eq "rhel7" -Or $global:osType -eq "rhel8") {
                                $logger.info("Running extendopt command to adjust the opt filesystem if required.")
                                $ret = runCmdOnVM $extendoptCmd $global:gblresourcegroup $vmname
                        }
                        else {
                                $logger.warn("Unable to determine osType for VM: $vmname skipping extendopt command")
                        }
                }
        }
}
else {
        $logger.warn("In prototype mode, skipping extendOpt check.")    
}

# Check if VM type is RHEL, CentOS or Oracle Linux AND the version is 8 or above, then attempt to run install python
if ($prototype -eq $false) {

        if ($global:offer.ToUpper().Contains("RHEL") -Or $global:offer.ToUpper().Contains("CENTOS") -Or $global:offer.ToUpper().Contains("ORACLE")) {
                if ( $global:osType -eq "rhel8" -Or $global:osType -eq "centos8" -Or $global:osType -eq "oracle-linux8") {
                        $logger.info("Running yum install python command if needed.")
                        $cmd = "python --version"
                        $ret = runCmdOnVM $cmd $global:gblresourcegroup $vmname
                        if ($ret.contains("not found")) {
                                $cmd = "yum -y install python2;alternatives --set python /usr/bin/python2"
                                $ret = runCmdOnVM $cmd $global:gblresourcegroup $vmname
                        }
                }
                else {
                        $logger.info("Python install not required for VM: $vmname")
                }
        }
       
}
else {
        $logger.warn("In prototype mode, skipping python install.")    
}



# Check if boot diagnostics should be installed.
if ($prototype -eq $false) {
        if ($global:gblbootdiagnostics -eq "yes") {
                installBootDiagnostics
        }
}
else {
        if ($global:gblbootdiagnostics -eq "yes") {
                $logger.warn("In prototype mode, skipping boot diagnostics install.")
        }      
}

# Check if any custom script extensions should be removed.
if ($prototype -eq $false) {
        removeCustomScriptExtension
}
else {
        $logger.warn("In prototype mode, skipping custom script removals.")      
}

# Build list of new tags to be added

$global:newTags = @{}
$global:newTags.add( 'dxcManaged', "true" )

if ($global:gblsymantec -eq "yes") {$global:newTags.add( 'dxcEPAgent', 'Symantec' )} 
        elseif ($global:gblcrowdstrike -eq "yes") {$global:newTags.add( 'dxcEPAgent', 'Crowdstrike' )} 
        elseif ($vm.tags.keys -notcontains "dxcEPAgent") {$global:newTags.add( 'dxcEPAgent', 'False' )}

if ( $global:gblomsmonitoring -eq 'yes' ){
        $global:newTags.add( 'dxcMonitored', 'true' )
}
        elseif ($vm.tags.keys -notcontains "dxcMonitored") {
                $global:newTags.add( 'dxcMonitored', 'false' )
        }

if ( $global:gblazurebackup -eq 'yes' ){
        $Backuptag = '{"Required":"true","RecoveryVault":"' + $global:gblrecoveryvault + '","BackupPolicy":"' + $global:gblbackuppolicytag + '"}'
        $global:newTags.add( 'dxcBackup', $Backuptag )
}
        elseif ($vm.tags.keys -notcontains "dxcBackup") {
                $global:newTags.add( 'dxcBackup', '{"Required":"false"}' )
        }
if (( $dxcPatchGroup -eq $true) -and ($dxcPatchGroupName.length -gt 0)){
        $patchgrouptag = '{"Required":"true","PatchGroupName":"' + $dxcPatchGroupName + '"}'
        $global:newTags.add( 'dxcPatchGroup', $patchgrouptag )
}
else {
        $patchgrouptag = '{"Required":"false"}'
        $global:newTags.add( 'dxcPatchGroup', $patchgrouptag)
}

$global:newTags = makeJsonTags($global:newTags)


# Now we have to build the parameter list to pass to the respective ARM template
$logger.info(" ")
$logger.info("Building parameter list")
$parameterList = buildParameterList
$parameters = $parameterList | ConvertFrom-Json | ConvertTo-HashTable
# Suppress secret values in display parameters
$global:omsWorkspaceKey = "****SUPPRESSED****"
$global:csuninstallpw = "****SUPPRESSED****"
$global:crowdStrikeCID = "****SUPPRESSED****"
$global:SymantecClientSecretKey = "****SUPPRESSED****"
$global:SymantecCustomerSecretKey = "****SUPPRESSED****"
$displayParameters = buildParameterList
$logger.info($displayParameters)

if ($prototype -eq $true) {
        $logger.warn("Running in prototype mode")
        removeGlobalVariables
}
Else {
        $logger.info("Deploying ARM template")
        $performance = Measure-Command { deployARMTemplate $makeManagedTemplate $parameters }
        $msg = $performance.TotalMinutes
        $logger.info("Deploy ARM template execution time: $msg minutes")
        # Check if the request is for no tags and if so, then replace existing tags
        if ($notags -eq $true) {
                replaceTags($vm)
        }
        removeGlobalVariables
        $logger.info(" ")
        $logger.info("ARM deployment ended")
}
# Remove logger global variable and data from run
destroyLogger
