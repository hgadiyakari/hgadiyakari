<#

Date: 15/09/2020
        - global resource name was wrong.  Setting to gblresourcegroup to match what is set in makeManagedAuto (AZR-17392)

#>



param(
	[Parameter(Mandatory = $true)]  [string]$vmname,
	[Parameter(Mandatory = $true)]  [string]$keyvault,
	[Parameter(Mandatory = $false)][string]$clientid,
	[Parameter(Mandatory = $false)][string]$clientkey,
	[Parameter(Mandatory = $false)][string]$tenantid,
	[Parameter(Mandatory = $false)][switch]$trace
)

$SymantecCustomerId = ""
$SymantecDomainId = ""
$SymantecClientId = ""
$SymantecClientSecretKey = ""
$OSNAME = ""
$KERNEL = ""
$resourceGroup = ""
$sku = ""
$offer = ""
$useLogger = $false
$logger = $null

Function ConnectAzure() {
	if ($trace -eq $true) {
		if ($useLogger -eq $true) {
			$logger.trace("Connect to Azure")
		}
		else {
			Write-Host "Connect to Azure" -ForegroundColor White
		}
	}
	$shell = (Get-ChildItem Env:AZURE_HTTP_USER_AGENT).Value  2>$null 3>$null
	if ($shell -eq "" -or $null -eq $shell) {
		$currentLogin = (Get-AzContext).Account.Id
		if ($currentLogin -eq "" -or $null -eq $currentLogin) {
			if ($trace -eq $true) {
				if ($useLogger -eq $true) {
					$logger.trace("Attempting to log on with service principal")
				}
				else {
					Write-Host "Attempting to log on with service principal" -ForegroundColor Green
				}
			}
			if ($clientid -eq "" -or $null -eq $clientid) {
				if ($useLogger -eq $true) {
					$logger.error("Service principal parameters not input. Aborting run")
				}
				else {
					Write-Host "ERROR: Service principal parameters not input. Aborting run" -ForegroundColor Red
				}	
				Exit
			}
			$error.Clear()

			$passwd = ConvertTo-SecureString $clientkey -AsPlainText -Force
			$pscredential = New-Object System.Management.Automation.PSCredential($clientid, $passwd)
			Connect-AzAccount -ServicePrincipal -Credential $pscredential -TenantId $tenantid

			if ($error) {
				if ($useLogger -eq $true) {
					$logger.error("Unable to connect to Azure. Check your Service Principal variables to ensure they are correct and valid.")
				}
				else {
					Write-Host "`nERROR: Unable to connect to Azure. Check your Service Principal variables to ensure they are correct and valid." -ForegroundColor Red
				}	
				Exit
			}
		}
		else {
			if ($trace -eq $true) {
				if ($useLogger -eq $true) {
					$logger.trace("Running with current logged on account")
				}
				else {
					Write-Host "Running with current logged on account" -ForegroundColor Green
				}
			}
		}
	}
	else {
		if ($trace -eq $true) {
			if ($useLogger -eq $true) {
				$logger.trace("Running under Azure Cloud Shell")
			}
			else {
				Write-Host "Running under Azure Cloud Shell" -ForegroundColor Green
			}
		}
	}
}

Function getCWPType() {
	if ($global:OSNAME.ToUpper().Contains("RED HAT") -or $global:OSNAME.ToUpper().Contains("RHEL")) {
		if ($global:sku.ToLower().StartsWith("cis")) {
			$s = $global:offer -split ('-')
			$v = $s[2]
		}
		else {
			$v = $global:sku.Substring(0, 1)
		}
		return "rhel$v"
	}
	ElseIf ($global:OSNAME.ToUpper().Contains("SLES")) {
		$v = $global:sku.Substring(0, 2)
		return "sles$v"
	}
	ElseIf ($global:OSNAME.ToUpper().Contains("UBUNTU")) {
		if ($global:sku.ToLower().StartsWith("cis")) {
			$s = $global:offer -split ('-')
			if ($global:offer.Contains('1604')) {
				$v = '16'
			}
			elseif (if $global:offer.Contains('1804')) {
				$v = '18'
			}
		}
		else {
			$v = $global:sku.Substring(0, 2)
		}
		return "ubuntu$v"
	}
	ElseIf ($global:OSNAME.ToUpper().Contains("CENTOS")) {
		if ($global:offer.ToLower().StartsWith("cis")) {
			$s = $global:offer -split ('-')
			$v = $s[2]
		}
		else {
			$v = $global:sku.Substring(0, 1)
		}
		return "centos$v"
	}
	ElseIf ($global:OSNAME.ToUpper().Contains("ORACLE")) {
		if ($global:sku.ToLower().StartsWith("cis")) {
			$s = $global:offer -split ('-')
			$v = $s[3]
		}
		else {
			$v = $global:sku.Substring(0, 1)
		}
		return "oel$v"
	}
	ElseIf ($global:OSNAME.ToUpper().Contains("DEBIAN")) {
		$v = $global:sku.Substring(0, 1)
		return "debian$v"
	}
	ElseIf ($global:OSNAME.ToUpper().Contains("WINDOWS")) {
		if ($global:sku.ToLower().StartsWith("cis")) {
			$s = $global:offer -split ('-')
			if ($s[3] -eq '2008' -And $s[4] -eq 'r2') {
				return("2008r2")
			}
			ElseIf ($s[3] -eq '2012' -And $s[4] -eq 'r2') {
				return("2012r2")
			}
			ElseIf ($s[3] -eq '2012') {
				return("2012")
			}
			ElseIf ($s[3] -eq '2016') {
				return("2016")
			}
			ElseIf ($s[3] -eq '2019') {
				return("2019")
			}
			else {
				return($null)
			}
		}
		if ($global:sku.ToLower().Contains("2008-r2")) {
			return("2008r2")
		}
		ElseIf ($global:sku.ToLower().Contains("2012-r2")) {
			return("2012r2")
		}
		ElseIf ($global:sku.ToLower().Contains("2012")) {
			return("2012")
		}
		ElseIf ($global:sku.ToLower().Contains("2016")) {
			return("2016")
		}
		ElseIf ($global:sku.ToLower().Contains("2019")) {
			return("2019")
		}
		else {
			return($null)
		}
	}
	Else {
		return $null
	}
}


Function getOSType() {
	$VMs = Get-AzVM -ResourceGroupName $global:gblresourcegroup | Select-Object Name, @{Name = "OSType"; Expression = { $_.StorageProfile.OSDisk.OSType } } | ForEach-Object { $_.Name + ";" + $_.OSType }
	#Write-Output $VMs
	foreach ($vm in $VMs) {
		$Name, $Type = $vm -split ";"
		if ($Name -eq $vmname) {
			return $Type
		}
	}
	return $null
}


Function getVMFromSubscription {
	if ($null -eq $global:gblresourcegroup -Or $global:gblresourcegroup -eq "") {
		$VMs = Get-AzVM 
	}
	else {
		$VMs = Get-AzVM -ResourceGroupName $global:gblresourcegroup
	}
	foreach ($vm in $VMs) {
		if ($vm.Name -eq $vmname) {
			return $vm
		}
	}
	return $null
}


Function getVMValues {
	try {
		# Get temporary file to write out commands to be run on the server
		$TempFile = New-TemporaryFile
		'if [ -f "/etc/system-release" ] || [ -h "/etc/system-release" ]; then echo NAME=\"$(cat /etc/system-release)\"; else cat /etc/os-release; fi'  | out-file -filepath $TempFile -append
		'echo KERNEL=\"$(uname -r)\"' | out-file -filepath $TempFile -append
		# Invoke Azure to run commands on the server
		$getKernel = Invoke-AzVMRunCommand -ResourceGroupName "$global:gblresourcegroup" -Name "$vmname" -CommandId 'RunShellScript' -ScriptPath $TempFile | Out-String
	}
	catch {
		if ($useLogger -eq $true) {
			$logger.trace("Failed to get OS values from VM")
		}
		else {
			Write-Host "Failed to get OS values from VM" -Foregroundcolor Red
		}
		Exit
	}
	finally {
		# Remove temporary file
		Remove-Item -Path $TempFile
	}
	# Process results from commands
	$outArray = $getKernel.Split([Environment]::NewLine)

	foreach ($line in $outArray) {
		if ($line.startsWith("NAME=")) {
			$global:OSNAME = $line.Substring(6, $line.Length - 7)
		}
		else {
			if ($line.startsWith("KERNEL=")) {
				$global:KERNEL = $line.Substring(8, $line.Length - 9)
			}
		}
	}
	if ($trace -eq $true) {
		if ($useLogger -eq $true) {
			$logger.trace("os Distribution name: $global:OSNAME")
			$logger.trace("os Kernel version: $global:KERNEL")
		}
		else {
			Write-Host "os Distribution name:"$global:OSNAME -Foregroundcolor Green
			Write-Host "os Kernel version:"$global:KERNEL -Foregroundcolor Green
		}
	}
}

Function getSymantecValues() {
	$global:SymantecCustomerId = (Get-AzKeyVaultSecret -vaultName $keyvault -name "SymantecCustomerId").SecretValueText
	$global:SymantecDomainId = (Get-AzKeyVaultSecret -vaultName $keyvault -name "SymantecDomainId").SecretValueText
	$global:SymantecClientId = (Get-AzKeyVaultSecret -vaultName $keyvault -name "SymantecClientId").SecretValueText
	$global:SymantecClientSecretKey = (Get-AzKeyVaultSecret -vaultName $keyvault -name "SymantecClientSecretKey").SecretValueText
}


Function symantecToken() {
	[int] $MaxRetries = 3
	[int] $WaitBetweenRetries = 1

	$URI = "https://scwp.securitycloud.symantec.com/dcs-service/dcscloud/v1/oauth/tokens"

	$header = @{
		"Accept"             = "application/json"
		"x-epmp-customer-id" = $global:SymantecCustomerId
		"x-epmp-domain-id"   = $global:SymantecDomainId
		"Content-Type"       = "application/json"
	}

	$body = @{
		"client_id"     = $global:SymantecClientId
		"client_secret" = $global:SymantecClientSecretKey
	} | ConvertTo-Json


	$Success = $false
	$RetriesLeft = $MaxRetries
	$StatusCode = $null
	$StatusText = $null

	do {
		try {
			if ($RetriesLeft -lt $MaxRetries) {
				if ($useLogger -eq $true) {
					$logger.warn("Trying to obtain Symantec token takes too long. Retries left: $RetriesLeft")
				}
				else {
					Write-Host "Trying to obtain Symantec token takes too long. Retries left:"  $RetriesLeft -Foregroundcolor Red
				}
			}
			$Response = Invoke-WebRequest -Uri $URI -Method POST -TimeoutSec 180 -Body $body -Headers $header
			$StatusCode = $Response.StatusDescription
			$StatusCodeInt = $Response.StatusCode
			$ExceptionOccurred = $false
		}
		catch {
			if ($_.Exception.Response.StatusCode) {
				$StatusCode = $_.Exception.Response.StatusCode
				$StatusCodeInt = $StatusCode.value__
				$StatusText = "Invoke-WebRequest get token returned $StatusCode ($StatusCodeInt)"
			}
			else {
				$StatusText = $_.Exception.Message
			}
			$ExceptionOccurred = $true
		}

		if ($trace -eq $true) {
			if ($useLogger -eq $true) {
				$logger.trace($StatusText)
			}
			else {
				Write-Host $StatusText -Foregroundcolor Yellow
			}
		}
		$Success = (($StatusCodeInt -eq 200) -and -not($ExceptionOccurred))
		$RetriesLeft--
		Start-Sleep $WaitBetweenRetries
	}
	while (($Success -eq $false) -and ($RetriesLeft -ge 0))

	if ($Success -eq $false) {
		Write-Host "Unable to obtain a Symantec token.  Processing stopped" -Foregroundcolor Red
		Write-Host "StatusCode: $StatusCode" -ForegroundColor Red
		Write-Host "Status Text: $StatusText" -ForegroundColor Red
		if ($RetriesLeft -eq 0) {
			Write-Host "Expended all retry attempts" -ForegroundColor Red
		}
		Exit
	}

	$token = $Response.Content | ConvertFrom-Json
	return $token.access_token
}

Function symantecCheckKernelSupport($token) {
	[int] $MaxRetries = 3
	[int] $WaitBetweenRetries = 1

	$URI = "http://scwp.securitycloud.symantec.com/dcs-service/dcscloud/v1/agents/packages/supported-platforms"

	$header = @{
		"Accept"             = "application/json"
		"x-epmp-customer-id" = $global:SymantecCustomerId
		"x-epmp-domain-id"   = $global:SymantecDomainId
		"Content-Type"       = "application/json"
		"Authorization"      = "Bearer " + $token
	}

	$body = @{
		"osDistribution" = $global:OSNAME
		"kernelVersion"  = $global:KERNEL
	} | ConvertTo-Json

	if ($trace -eq $true) {
		if ($useLogger -eq $true) {
			$logger.trace("Parameters:$body")
		}
		else {
			Write-Host "Parameters:$body" -ForegroundColor White
		}
	}
	$Success = $false
	$RetriesLeft = $MaxRetries
	$StatusCode = $null
	$StatusText = $null

	do {
		try {
			if ($RetriesLeft -lt $MaxRetries) {
				if ($useLogger -eq $true) {
					$logger.warn("Trying to obtain Symantec kernel information takes too long. Retries left: $RetriesLeft")
				}
				else {
					Write-Host "Trying to obtain Symantec kernel information takes too long. Retries left:"  $RetriesLeft -Foregroundcolor Red
				}
			}
			$Response = Invoke-WebRequest -Uri $URI -Method PUT -TimeoutSec 180 -Body $body -Headers $header
			$StatusCode = $Response.StatusDescription
			$StatusCodeInt = $Response.StatusCode
			$ExceptionOccurred = $false
		}
		catch {
			if ($_.Exception.Response.StatusCode) {
				$StatusCode = $_.Exception.Response.StatusCode
				$StatusCodeInt = $StatusCode.value__
				$StatusText = "Invoke-WebRequest check kernel support returned $StatusCode ($StatusCodeInt)"
			}
			else {
				$StatusText = $_.Exception.Message
			}
			$ExceptionOccurred = $true
		}

		if ($trace -eq $true) {
			if ($useLogger -eq $true) {
				$logger.trace($StatusText)
			}
			else {
				Write-Host $StatusText -Foregroundcolor Yellow
			}
		}
		$Success = (($StatusCodeInt -eq 200) -and -not($ExceptionOccurred))
		$RetriesLeft--
		Start-Sleep $WaitBetweenRetries
	}
	while (($Success -eq $false) -and ($RetriesLeft -ge 0))

	if ($Success -eq $false) {
		Write-Host "Unable to obtain Symantec kernel information.  Processing stopped" -Foregroundcolor Red
		Write-Host "StatusCode: $StatusCode" -ForegroundColor Red
		Write-Host "Status Text: $StatusText" -ForegroundColor Red
		if ($RetriesLeft -eq 0) {
			Write-Host "Expended all retry attempts" -ForegroundColor Red

		}
		Exit
	}
	$content = $Response.Content | ConvertFrom-Json
	return $content
}

$useLogger = Test-Path variable:global:logger
if ($useLogger -eq $true) {
	$logger = $global:logger
}

ConnectAzure
# Find VM in subscription
$vm = getVMFromSubscription
if ($null -eq $vm) {
	if ($useLogger -eq $true) {
		$logger.error(" ")
		$logger.error("VM was not found in the subscription. Please check name and rerun.")
	}
	else {
		Write-Host "`nVM was not found in the subscription. Please check name and rerun.`n" -ForegroundColor Red
	}
	Exit
}

$global:gblresourcegroup = $vm.ResourceGroupName
if ($trace -eq $true) {
	if ($useLogger -eq $true) {
		$logger.trace(" ")
		$logger.trace("Found $vmname in Resource Group $global:gblresourcegroup")
	}
	else {
		Write-Host "`nFound $vmname in Resource Group $global:gblresourcegroup"  -ForegroundColor Green
	}
}

# Get to where the information is about sku and offer
$storageProfile = $vm.StorageProfile
$imageReference = $storageProfile.ImageReference
$publisher = $imageReference.Publisher
$global:offer = $imageReference.Offer
$global:sku = $imageReference.Sku

if ($trace -eq $true) {
	if ($useLogger -eq $true) {
		$logger.trace("Offer: $global:offer    Sku: $global:sku     Publisher: $publisher")
	}
	else {
		Write-Host "`nOffer:"$global:offer   "Sku:"$global:sku    "Publisher:"$publisher -ForegroundColor Green
	}
}
$type = getOSType
if ($trace -eq $true) {
	if ($useLogger -eq $true) {
		$logger.trace("type returned: $type")
	}
	else {
		Write-Host "type returned:"$type
	}
}
if ($type -eq "Linux") {
	getVMValues
	$global:OSNAME = getCWPType
}
else {
	$global:OSNAME = "Windows"
	$OS = getCWPType
	$global:OSNAME = "windows$OS"
	$global:KERNEL = ""
}

getSymantecValues
$token = symantecToken
$content = symantecCheckKernelSupport($token)

if ($trace -eq $true) {
	Write-Host "$vmname supported by CWP: "  -NoNewline -Foregroundcolor Green
	Write-Host $content.supported -Foregroundcolor White
	Write-Host "Description:"$content.description -Foregroundcolor Green
	Write-Host " "

}
@{"supported" = $($content.supported); "description" = $($content.description) }
