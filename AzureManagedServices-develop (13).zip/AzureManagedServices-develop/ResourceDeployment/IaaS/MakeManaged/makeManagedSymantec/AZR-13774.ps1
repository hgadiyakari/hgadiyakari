#Requires -PSEdition Core
#Requires -Version 6.2
#Requires -Modules @{ ModuleName="Az"; ModuleVersion="2.4.0" }

<#
 This in response to a critical bug filed because of the rotation
 of the security keys on the dxcazuretools container.
 
 The problem was that the SAS tokens for the templates folder was
 generated using Key1, which was replaced with Key2 and rotated.
 This caused the SAS token, which is used by makeManagedAuto and
 retrieved from the key vault to be obsolete.  
 
 This script will validate that the keyvault secret matches the
 old key and if so, it will replace it with the new key.
#>

param (
    [Parameter(Mandatory = $true)]  [String]$keyvault, 
    [Parameter(Mandatory = $true)]  [String]$newkey   
)

$oldkey = '3f00730076003d0032003000310039002d00300032002d00300032002600730072003d00630026007300690067003d004b0037004d0033007100570061004d005700680048007a0037004f0078006e006f004b0076006d00770066004b0079006800250032004200370068006c006f0038004b00780053004800320038005000580063004d00480073002500330044002600730074003d0032003000310039002d00310030002d003200350054003100330025003300410032003400250033004100300038005a002600730065003d0032003000320031002d00310032002d003200350054003100350025003300410032003400250033004100300038005a002600730070003d0072006c00'

Write-Host "Starting AZR-13774, keyvault secret replacement" -ForegroundColor Green
try {
    $check = Get-AzKeyVault -VaultName $keyvault
    if ($check.Length -eq 1) {
        $secretvalue = Get-AzKeyVaultSecret -VaultName $keyvault -Name makeMgdSasToken
        if ($secretvalue.Length -eq 1) {
            $keyVaultSecret = $secretvalue.SecretValue | ConvertFrom-SecureString
        }
        else {
            Write-Host "Keyvault secret can not be found in keyvault($keyvault)" -ForegroundColor Red
            Exit
        }
    }
    else {
        Write-Host "Keyvault($keyvault) can not be found" -ForegroundColor Red
        Exit
    }
}
catch {
    Write-Host "An error occurred:" -ForegroundColor Red
    Write-Host $_ -ForegroundColor Red
    Exit
}

# if the two are the same, then we need to replace it
if ($keyVaultSecret -eq $oldkey) {
    $newVaultSecret = ConvertTo-SecureString -String $newkey
    Write-Host "Replacing keyvault value with new token." -ForegroundColor Green
    Set-AzKeyVaultSecret -VaultName $keyvault -Name 'makeMgdSasToken' -SecretValue $newVaultSecret
}
else {
    Write-Host "Keyvault secret does not match old value.  Replacement is being skipped." -ForegroundColor Yellow
}
Write-Host "Finished" -ForegroundColor Green
