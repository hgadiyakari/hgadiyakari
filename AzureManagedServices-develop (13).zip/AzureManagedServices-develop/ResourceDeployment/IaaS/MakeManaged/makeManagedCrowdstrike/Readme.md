# MakeManaged Crowdstrike

This folder contains the json files that are used to implement the makeManaged support for Crowdstrike supported VMs
**NOTE:** Do not directly run any of the makeManaged JSON files included in this folder.  Instead, 
use the "makeManagedAuto.ps1" script that will invoke the required JSON file from cloud storage.

The makeManaged ARM templates add the "managed" features on to an existing VM.  This Powershell wrapper script (makeManagedAuto) will run as an 
Azure Cloud Shell to allow OD&T/CloudOps to execute without having all the required features installed on their laptop/desktop.  
It can also be run from a Powershell window on either Windows or Linux/Mac (with appropriate installed helper modules).  
This wrapper script will determine the OS of the VM requested and will execute the correct makeManaged ARM template for that OS. 

## Supported
makeManaged Crowdstrike currently supports the following:

oms monitoring (Log Analytics)
CrowdStrike (endpoint security)
Azure Backup
Diagnostic Extensions (cloudcheckr)
Boot diagnostics

## Jira Epic
https://jira.dxc.com/browse/AZR-9968

## Deployment 
For more information on how to execute script, please see:
https://confluence.dxc.com/display/CSA/AZR-9968+Create+Wrapper+Script+for+Make+Managed+on+Symantec

## Members of this directory are:

* makeManagedLinux.json	            makeManaged ARM template for Linux
* makeManagedWindows.json	    makeManaged ARM template for Windows

## Authors

* **Kevin Bilderback** 
