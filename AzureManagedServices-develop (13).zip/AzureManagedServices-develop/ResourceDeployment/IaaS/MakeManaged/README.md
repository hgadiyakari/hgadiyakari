# MakeManaged
This directory contains the two different types of MakeManaged relative to the diagnostic agent used:

* Crowdstrike
* Symantec

**NOTE:** Do not directly run any of the makeManaged JSON files included in this folder.  Instead, 
use the "makeManagedAuto.ps1" script that will invoke the required JSON file from cloud storage.