# AKS Managed Services
> Code and artefacts to support the Azure AKS Managed Services Offering

---
## AKS Repository

AKS repository

**NOTE**
the author has provided detailed documentation that specifically addresses the scripts provided.  The reader may find additional scripts within each folder that has been intentionally left in place to aid engineers to further develop their own scripts but has stated clearly as to whether they are now obsolete for the offering.


----
## Deployment
Deploys an AKS cluster via the **deploy-pipeline.yml**. Variables are setup using the pipelines.sh script in the Azure-CLI-Container folder

> 1. Create an Organisation in [Azure DevOps](https://dev.azure.com)
> 2. Create a Project in [Azure DevOps](https://dev.azure.com)
> 3. Create an approval environment in [Azure DevOps](https://dev.azure.com)
> 4. Add a Service Connection to [Github Enterprise Server](https://github.dxc.com)
> 5. Add the variables via the **pipelines.sh**
> 6. Add the pipeline with the **deploy-pipeline.yml** file
> 7. Run the pipeline to deploy the AKS Cluster

For further details see **AKS documentation**

----
## Deletion
Deletes and AKS cluster via the **delete-pipeline.yml**. Variables are setup using the **pipelines.sh** script in the Azure-CLI-Container folder

> 1. Add the variables via the **pipelines.sh**
> 2. Add the pipeline with the **delete-pipeline.yml** file
> 3. Run the pipeline to delete the AKS Cluster

For further details see **AKS documentation**

----
## Upgrade
Upgrade and AKS cluster via the **upgrade-pipeline.yml**. Variables are setup using the **pipelines.sh** script in the Azure-CLI-Container folder

> 1. Add the variables via the **pipelines.sh**
> 2. Add the pipeline with the **upgrade-pipeline.yml** file
> 3. Run the pipeline to upgrade the AKS Cluster

**NOTE**
if the pipeline has already been created, the upgrade will be ready for approval automatically when a change is made to the GitRepo

For further details see **AKS documentation**

----
## Deploy Velero
Install, configure, and monitor Velero via the **deploy-velero.yml**. Variables are setup using the **pipelines.sh** script in the Azure-CLI-Container folder

> 1. Add the variables via the **pipelines.sh**
> 2. Add the pipeline with the **deploy-velero.yml** file
> 3. Run the pipeline to enable Velero backup of the AKS Cluster namespaces

For further details see **AKS documentation**

----
## Deploy Application Gateway Ingress Controller
Deploy an Application Gateway with an Ingress Controller via the **deploy-agic.yml**. Variables are setup using the **pipelines.sh** script in the Azure-CLI-Container folder

> 1. Add the variables via the **pipelines.sh**
> 2. Add the pipeline with the **deploy-agic.yml** file
> 3. Run the pipeline to add an Application Gateway with Ingress Controller to an AKS Cluster

For further details see **AKS documentation**



----
## Azure CLI Container
Contains the scripts required to perform the following

> 1. **aad-admin-group.sh** - configures an AAD Admin group to administer an AKS Cluster (OD&T)
> 2. **aad-client-group.sh** - configures an AAD client group to access an AKS Cluster namespace (Customer)
> 3. **aad-external-group.sh** - configures an AAD external group to administer an AKS Cluster namespace (CloudOps)
> 4. **add-acr-sp.sh** - creates an ACR, and associated Service Principal, and attaches the ACR to AKS
> 5. **add-devops-role.sh** - add roles and rolebindings to allow an App to be deployed from Azure DevOps (workaround)
> 6. **aks-login.sh** - provides a simple way to login into Azure and AKS using AAD or the cluster admin account
> 7. **app-gateway.sh (OBSOLETED)** - used to deploy an App Gateway to an AKS cluster (now deployed via Azure DevOps)
> 8. **azuredevops.yaml** - used to deploy a Ubuntu docker container with Kubectl, Azure CLI and HELM pre-installed
> 9. **build-azcli-container.sh** - used to deploy a Ubuntu docker container with Kubectl, Azure CLI and HELM pre-installed
> 10. **config.sh** - used to deploy a Ubuntu docker container with Kubectl, Azure CLI and HELM pre-installed
> 11. **login-to-node.sh** - aids in login to an AKS Node for maintainence and testing
> 12. **pipelines.sh** - deploys Azure DevOps variables required for Deploy, Delete and Upgrade pipelines
> 13. **upgrade-cluster.sh** - aids in upgrading an AKS Cluster if the Azure DevOps pipelines are not run consistently
> 14. **variables.sh** - the variables parsed by all of the scripts
> 15. **velero-tenant.sh (OBSOLETED)** - _deploys_ a Heptio Velero backup server for namespace based backups and service restoration. This is now deployed using an Azure DevOps pipeline



For further details see **AKS documentation**

---
## Contact Details
    Roland Balgobind
    rbalgobi@dxc.com
    +44 (0) 20 8786 0743

> Email preferred.

## Changelog

| Date | Author | Comment |
| ---- | ------ | ------- |
| 26th February 2020 |  Roland Balgobind | Initial version                |
| 30th February 2020 | Roland Balgobind | Minor updates                   |
|  7th May      2020 | Roland Balgobind | added login-to-node.sh          |
|  28th May     2020 | Roland Balgobind | added fileshares.sh             |
|  11th July     2020 | Roland Balgobind | added add-devops-role.sh       |
|  1th September     2020 | Roland Balgobind | added add-acr-sp.sh       |

### © Copyright DXC Technology, 2020. All rights reserved
