#!/bin/bash

# -------------------------------------------------------
# Name:     Roland Balgobind
# Date:     10th February 2020
# Comments: Configure a BASH shell for AKS management
#
# (c) Copyright DXC Technology, 2020. All rights reserved
# -------------------------------------------------------

apt-get update
apt-get -y install sudo
apt-get -y install wget
apt-get -y install git
apt-get -y install vim
apt-get -y install curl
apt-get -y install openssl
apt-get -y install chrony

# Install Azure CLI
curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash

# Fallback
sudo apt-get update
sudo apt-get install ca-certificates curl apt-transport-https lsb-release gnupg
curl -sL https://packages.microsoft.com/keys/microsoft.asc |
    gpg --dearmor |
    sudo tee /etc/apt/trusted.gpg.d/microsoft.asc.gpg > /dev/null
AZ_REPO=$(lsb_release -cs)
echo "deb [arch=amd64] https://packages.microsoft.com/repos/azure-cli/ $AZ_REPO main" |
    sudo tee /etc/apt/sources.list.d/azure-cli.list
sudo apt-get update
sudo apt-get -y install azure-cli

# Add DevOps extension
az extension add --name azure-devops

# Install Kubectl
curl -LO https://storage.googleapis.com/kubernetes-release/release/`curl -s https://storage.googleapis.com/kubernetes-release/release/stable.txt`/bin/linux/amd64/kubectl
chmod +x ./kubectl
mv ./kubectl /usr/local/bin/kubectl

# Install HELM
wget https://raw.githubusercontent.com/helm/helm/master/scripts/get-helm-3
# wget https://raw.githubusercontent.com/helm/helm/master/scripts/get
mv get-helm-3 install-helm.sh
chmod 755 install-helm.sh
./install-helm.sh
rm -rf ./install-helm.sh

