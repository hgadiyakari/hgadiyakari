#!/bin/bash
echo
echo "# -------------------------------------------------------"
echo "# Name:     Roland Balgobind"
echo "# Date:     10th November 2020"
echo "# Version:  5.0"
echo "# Comments: Login to an AKS node using a docker-engine"
echo "#           server with Azure CLI and kubectl installed"
echo "#"
echo "# (c) Copyright DXC Technology, 2020. All rights reserved"
echo "# -------------------------------------------------------"
echo

TERM=vt100
export TERM

. ./variables.sh

if [ x$MySPN == xtrue ]; then
    myup="secret"
    echo -n "Enter Service Principal ID: "
    read myusername
else
    myup="password"
fi

# Main code
echo -n "Enter $myup for $myusername: "
read -rs mypassword
echo

# Login to Azure
if [ x$MySPN == xtrue ]; then
	az login --service-principal -u $myusername -p $mypassword --tenant $MyTenantId
else
	az login -u $myusername -p $mypassword
fi
echo
az account set --subscription ${MySubscription}
az aks get-credentials --resource-group $MyResGrp --name $MyClusterName --admin --overwrite-existing

ssh-keygen -t rsa -C "rbalgobi@dxc.com"

CLUSTER_RESOURCE_GROUP=$(az aks show --resource-group $MyResGrp --name $MyClusterName --query nodeResourceGroup -o tsv)
SCALE_SET_NAME=$(az vmss list --resource-group $CLUSTER_RESOURCE_GROUP --query [0].name -o tsv)
echo "Scaleset name: $SCALE_SET_NAME"

az vmss extension set  \
    --resource-group $CLUSTER_RESOURCE_GROUP \
    --vmss-name $SCALE_SET_NAME \
    --name VMAccessForLinux \
    --publisher Microsoft.OSTCExtensions \
    --version 1.4 \
    --protected-settings "{\"username\":\"azureuser\", \"ssh_key\":\"$(cat ~/.ssh/id_rsa.pub)\"}"

az vmss update-instances --instance-ids '*' \
    --resource-group $CLUSTER_RESOURCE_GROUP \
    --name $SCALE_SET_NAME

echo
echo
kubectl get nodes -o wide
echo
echo "Enter Internal IP of Node to login to"
read ans

echo
echo "    --------------------------------------------------------------------------------"
echo "   |   The following will need to be performed once the debian container is built.  |"
echo "   |   The Steps are provided then the container is built for you.                  |"
echo "    --------------------------------------------------------------------------------"
echo
echo "    1) From a new session, copy the key into the debian container"
echo "       ---------------------------------------------------------------------------"
echo "       *** Ensure az login OR aks-login.sh has been run in the new session"
echo
echo "       kubectl cp ~/.ssh/id_rsa \$(kubectl get pod -l run=aks-ssh -o jsonpath='{.items[0].metadata.name}'):/id_rsa"

echo
echo "    2) Run the following in the debian container when built"
echo "       ----------------------------------------------------"
echo "       apt-get update && apt-get install openssh-client -y > /dev/null 2>&1"
echo "       chmod 0600 id_rsa"
echo "       ssh -i id_rsa azureuser@$ans"
echo

echo "<Return> to start the debian container"
read

kubectl run -it --rm aks-ssh --image=debian
