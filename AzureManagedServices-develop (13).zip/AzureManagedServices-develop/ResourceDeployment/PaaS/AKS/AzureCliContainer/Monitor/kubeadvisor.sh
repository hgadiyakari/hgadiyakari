#!/bin/bash
echo
echo "# -------------------------------------------------------"
echo "# Name:     Roland Balgobind"
echo "# Date:     16th February 2021"
echo "# Version:  1.0"
echo "# Comments: Invoke Kube-Advisor"
echo "#"
echo "# (c) Copyright DXC Technology, 2021. All rights reserved"
echo "# -------------------------------------------------------"
echo
TERM=vt100
export TERM

. $(cd -P "$(dirname "$0")" && pwd)/../variables.sh

if [ x$MySPN == xtrue ]; then
    myup="secret"
    echo -n "Enter Service Principal ID: "
    read myusername
else
    myup="password"
fi

# Main code
echo -n "Enter $myup for $myusername: "
read -rs mypassword
echo

# Login to Azure
if [ x$MySPN == xtrue ]; then
        az login --service-principal -u $myusername -p $mypassword --tenant $MyTenantId
else
        az login -u $myusername -p $mypassword
fi
echo
az account set --subscription ${MySubscription}
az aks get-credentials --resource-group $MyResGrp --name $MyClusterName --admin --overwrite-existing

# Deploy Kubeadvisor
kubectl delete pod/kubeadvisor  > /dev/null 2>&1
kubectl delete -f https://raw.githubusercontent.com/Azure/kube-advisor/master/sa.yaml > /dev/null 2>&1
kubectl apply -f https://raw.githubusercontent.com/Azure/kube-advisor/master/sa.yaml
kubectl run --rm -i -t kubeadvisor --image=mcr.microsoft.com/aks/kubeadvisor --restart=Never --overrides="{ \"apiVersion\": \"v1\", \"spec\": { \"serviceAccountName\": \"kube-advisor\" } }" --namespace default

# Clean up
kubectl delete -f https://raw.githubusercontent.com/Azure/kube-advisor/master/sa.yaml
