#!/bin/bash
echo
echo "# -------------------------------------------------------"
echo "# Name:     Roland Balgobind"
echo "# Date:     20th November 2020"
echo "# Version:  2.0"
echo "# Comments: Deploys a simple NGINX application"
echo "#"
echo "# (c) Copyright DXC Technology, 2020. All rights reserved"
echo "# -------------------------------------------------------"
echo
. ./variables.sh
cd AKSDEV
myrandom=$(( $RANDOM % 1000 + 1 ))
sed -i "s/mysimpleapp[0-9]*/mysimpleapp$myrandom/g" simple-app.yaml
sed -i "s/eastus/${MyLocation}/g" simple-app.yaml

if [ -f scsimple.yaml ]; then
  kubectl create -f scsimple.yaml
  kubectl patch storageclass/myazurefile \
  --type json \
  --patch '[{"op":"add","path":"/mountOptions/-","value":"nouser_xattr"}]'
fi

if [ -f simple-app.yaml ]; then
  myappns=simplens
  kubectl create ns $myappns
  kubectl config set-context --current --namespace=$myappns
  kubectl create -f simple-app.yaml
fi
echo
echo "Site URL: mysimpleapp$myrandom.$MyLocation.cloudapp.azure.com"
echo
cd ..
kubectl config set-context --current --namespace=default
