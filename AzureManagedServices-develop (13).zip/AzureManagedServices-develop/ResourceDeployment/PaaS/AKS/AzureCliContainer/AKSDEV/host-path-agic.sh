#!/bin/bash
echo
echo "# -------------------------------------------------------"
echo "# Name:     Roland Balgobind"
echo "# Date:     24th May 2021"
echo "# Version:  2.0"
echo "# Comments: Deploys a simple application with host-based"
eho "#            and path-based routing for validating AGICs"
echo "#"
echo "# (c) Copyright DXC Technology, 2021. All rights reserved"
echo "# -------------------------------------------------------"
echo

myappdns1="eastus.rolandtestdomain.com"
myappdns2="westus.rolandtestdomain.com"
mynamespace="demons"

rm -f mypod.yaml

tee mypod.yaml << \EOF
---
apiVersion: v1
kind: Namespace
metadata:
  name: mynamespaceplaceholder

---
apiVersion: v1
kind: ConfigMap
metadata:
  name: svrdetails
data:
  server-details.conf: |
    server {
        listen 80;
        location / {
            default_type text/plain;
            expires -1;
            return 200 '\n ----------------------------------------------\n  Host:       $http_host\n  URI:        $request_uri\n  Pod name:   $hostname\n  Pod IP:     $server_addr\n  Pod Port:   $server_port\n  Date:       $time_local\n ----------------------------------------------\n  Request ID: $request_id\n ----------------------------------------------';
        }
    }
  init.sh: |
    rm /etc/nginx/conf.d/*
    cp /svrdetails/server-details.conf /etc/nginx/conf.d/
    /usr/sbin/nginx

---
apiVersion: extensions/v1beta1
kind: Ingress
metadata:
  name: myhp5demo-ingress
  namespace: mynamespaceplaceholder
  annotations:
    kubernetes.io/ingress.class: azure/application-gateway
    appgw.ingress.kubernetes.io/backend-hostname: myappdnsplaceholder1
    ####  This will force all paths to /test ####
    # appgw.ingress.kubernetes.io/backend-path-prefix: "/test/"
spec:
 rules:
  - host: myappdnsplaceholder1
    http:
      paths:
      - path: /android
        backend:
          serviceName: android-svc
          servicePort: 80
      - path: /ios
        backend:
          serviceName: ios-svc
          servicePort: 80

---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ios
  namespace: mynamespaceplaceholder
spec:
  replicas: 2
  selector:
    matchLabels:
      app: ios
  template:
    metadata:
      labels:
        app: ios
    spec:
      volumes:
      - name: svrdetails
        configMap:
          name: svrdetails
          defaultMode: 0777
      containers:
      - command: ["sh","-c","/svrdetails/init.sh; sleep infinity"]
        image: nginx:mainline-alpine
        ports:
        - containerPort: 80
        name: mycontainer
        volumeMounts:
          - mountPath: /svrdetails
            name: svrdetails

---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: android
  namespace: mynamespaceplaceholder
spec:
  replicas: 2
  selector:
    matchLabels:
      app: android
  template:
    metadata:
      labels:
        app: android
    spec:
      volumes:
      - name: svrdetails
        configMap:
          name: svrdetails
          defaultMode: 0777
      containers:
      - command: ["sh","-c","/svrdetails/init.sh; sleep infinity"]
        image: nginx:mainline-alpine
        ports:
        - containerPort: 80
        name: mycontainer
        volumeMounts:
          - mountPath: /svrdetails
            name: svrdetails

---
apiVersion: v1
kind: Service
metadata:
  name: android-svc
  namespace: mynamespaceplaceholder
  labels:
spec:
  ports:
  - port: 80
    targetPort: 80
    protocol: TCP
    name: http
  selector:
    app: android

---
apiVersion: v1
kind: Service
metadata:
  name: ios-svc
  namespace: mynamespaceplaceholder
  labels:
spec:
  ports:
  - port: 80
    targetPort: 80
    protocol: TCP
    name: http
  selector:
    app: ios

#### Host based
---
apiVersion: extensions/v1beta1
kind: Ingress
metadata:
  name: myhp6demo-ingress
  namespace: mynamespaceplaceholder
  annotations:
    kubernetes.io/ingress.class: azure/application-gateway
    appgw.ingress.kubernetes.io/backend-hostname: myappdnsplaceholder2
spec:
 rules:
  - host: myappdnsplaceholder2
    http:
      paths:
      - path: /android
        backend:
          serviceName: wileyfox-svc
          servicePort: 80

---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: wileyfox
  namespace: mynamespaceplaceholder
spec:
  replicas: 2
  selector:
    matchLabels:
      app: wileyfox
  template:
    metadata:
      labels:
        app: wileyfox
    spec:
      volumes:
      - name: svrdetails
        configMap:
          name: svrdetails
          defaultMode: 0777
      containers:
      - command: ["sh","-c","/svrdetails/init.sh; sleep infinity"]
        image: nginx:mainline-alpine
        ports:
        - containerPort: 80
        name: mycontainer
        volumeMounts:
          - mountPath: /svrdetails
            name: svrdetails

---
apiVersion: v1
kind: Service
metadata:
  name: wileyfox-svc
  namespace: mynamespaceplaceholder
  labels:
spec:
  ports:
  - port: 80
    targetPort: 80
    protocol: TCP
    name: http
  selector:
    app: wileyfox

EOF

sed -i "s/myappdnsplaceholder1/$myappdns1/g" mypod.yaml
sed -i "s/myappdnsplaceholder2/$myappdns2/g" mypod.yaml
sed -i "s/mynamespaceplaceholder/$mynamespace/g" mypod.yaml

# Create Solution
kubectl delete -f mypod.yaml -n $mynamespace > /dev/null 2>&1
sleep 2
kubectl create -f mypod.yaml -n $mynamespace
rm -f mypod.yaml
