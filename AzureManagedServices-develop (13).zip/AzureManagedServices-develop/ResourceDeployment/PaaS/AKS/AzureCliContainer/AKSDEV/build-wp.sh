#!/bin/bash
echo
echo "# -------------------------------------------------------"
echo "# Name:     Roland Balgobind"
echo "# Date:     20th November 2020"
echo "# Version:  2.0"
echo "# Comments: Deploys a Wordpress application"
echo "#"
echo "# (c) Copyright DXC Technology, 2020. All rights reserved"
echo "# -------------------------------------------------------"
echo
. ./variables.sh
cd AKSDEV
myrandom=$(( $RANDOM % 1000 + 1 ))
sed -i "s/mywpapp/mywpapp$myrandom/g" wp-app.yaml

if [ -f scwp.yaml ]; then
  kubectl create -f scwp.yaml
  kubectl patch storageclass/azurefile1 \
  --type json \
  --patch '[{"op":"add","path":"/mountOptions/-","value":"nouser_xattr"}]'
fi

if [ -f wp-app.yaml ]; then
  myappns=wpns
  kubectl create ns $myappns
  kubectl config set-context --current --namespace=$myappns
  kubectl create secret generic my-password --from-literal=db-password="mypass"
  kubectl create -f wp-app.yaml
fi
echo
echo "Site URL: mywpapp$myrandom.$MyLocation.cloudapp.azure.com"
echo
cd ..
kubectl config set-context --current --namespace=default
