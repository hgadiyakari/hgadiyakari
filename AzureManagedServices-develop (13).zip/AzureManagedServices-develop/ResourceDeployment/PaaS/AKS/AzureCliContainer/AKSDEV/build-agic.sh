#!/bin/bash
echo
echo "# -------------------------------------------------------"
echo "# Name:     Roland Balgobind"
echo "# Date:     25th May 2021"
echo "# Version:  3.0"
echo "# Comments: Deploys an AGIC application"
echo "#"
echo "# (c) Copyright DXC Technology, 2021. All rights reserved"
echo "# -------------------------------------------------------"
echo
. ./variables.sh
cd AKSDEV

if [ -f scagic.yaml ]; then
  kubectl create -f scagic.yaml
  kubectl patch storageclass/agicsc \
  --type json \
  --patch '[{"op":"add","path":"/mountOptions/-","value":"nouser_xattr"}]'
fi

if [ -f agic-app.yaml ]; then
  myappns=myappagicns
  kubectl create ns $myappns
  kubectl config set-context --current --namespace=$myappns
  kubectl create -f agic-app.yaml
fi
echo
sleep 20

echo "<"'!'"DOCTYPE html>" > index.html
echo "<html>" >> index.html
echo "<head>" >> index.html
echo "<title>Nginx App</title>" >> index.html
echo "<style>" >> index.html
echo "    body {" >> index.html
echo "        width: 35em;" >> index.html
echo "        margin: 0 auto;" >> index.html
echo "        font-family: Tahoma, Verdana, Arial, sans-serif;" >> index.html
echo "    }" >> index.html
echo "</style>" >> index.html
echo "</head>" >> index.html
echo "<body>" >> index.html
echo "<h1>AGIC Validation</h1>" >> index.html
echo "<p>If you see this page, the nginx web server together with" >> index.html
echo "the <i>App Gateway Ingress Controller</i> has been" >> index.html
echo "successfully installed </p>" >> index.html
echo "" >> index.html
echo "<p>Invoke <i><b>kubectl delete ns myappagicns</b></i> to remove the validation" >> index.html
echo "pod and service after testing has been completed</p>" >> index.html
echo "" >> index.html
echo "<p>(c) Copyright DXC Technology, 2020. All rights reserved</p>" >> index.html
kubectl cp index.html ${myappns}/nginx:/usr/share/nginx/html/index.html
rm -f index.html

myagicip=$(az network public-ip show \
    --resource-group ${MyResGrp} \
    --name ${MyClusterName}AppgwIp \
    --query [ipAddress] \
    --output tsv)
echo
echo "AGIC IP Address: ${myagicip}"
echo
echo "Please wait..."
sleep 20

cd ..
kubectl config set-context --current --namespace=default
