#!/bin/bash
echo
echo "# -------------------------------------------------------"
echo "# Name:     Roland Balgobind"
echo "# Date:     17th September 2020"
echo "# Version:  7.0"
echo "# Comments: Velero backup and service restoration"
echo "#"
echo "# (c) Copyright DXC Technology, 2020. All rights reserved"
echo "# -------------------------------------------------------"
echo

TERM=vt100
export TERM

. ./variables.sh

echo "+-------------------------------------------------------------------+"
echo "| This script will only deploy the Velero client in the current CLI |"
echo "+-------------------------------------------------------------------+"
echo -n "<return to continue ...> "
read ans

# Download velero
wget $linuxTarball
tar zxf velero-v*.tar.gz
rm -f velero-v*.tar.gz
cd velero-v*
