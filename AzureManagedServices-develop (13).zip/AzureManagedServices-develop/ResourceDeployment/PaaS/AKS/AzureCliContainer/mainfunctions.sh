#!/bin/bash
# --------------------------------------------------------
# Name:     Roland Balgobind
# Date:     23rd June 2021
# Version:  6.0
# Comments: Functions for reusable code
#
# (c) Copyright DXC Technology, 2021. All rights reserved
# --------------------------------------------------------

# ----------------------------- VARIABLES -------------------------------
mintimer=5
oldveleroplugin="v1.1.0"
veleroplugin="v1.2.0"
# -----------------------------------------------------------------------

#
#  Function velerobackupfunction
#
function velerobackupfunction {

    # create Velero credentials file
    echo "AZURE_SUBSCRIPTION_ID=${MySubscription}" > credentials-velero
    echo "AZURE_TENANT_ID=${MyTenantId}" >> credentials-velero
    echo "AZURE_CLIENT_ID=${myveleromidsp}" >> credentials-velero
    echo "AZURE_CLIENT_SECRET=\"${myveleromidsecret}\"" >> credentials-velero
    echo "AZURE_RESOURCE_GROUP=$MyNewResGrp" >> credentials-velero
    echo "AZURE_CLOUD_NAME=AzurePublicCloud" >> credentials-velero

    # install Velero
    velero install --provider azure \
    --bucket ${MyVeleroBlob} \
    --secret-file ./credentials-velero \
    --backup-location-config resourceGroup=${MyVeleroResGrp},storageAccount=${MyVeleroStrgAcct} \
    --snapshot-location-config apiTimeout="5m",resourceGroup=${MyVeleroResGrp},subscriptionId=$mysubscriptionid \
    --plugins velero/velero-plugin-for-microsoft-azure:${veleroplugin} \
    --use-volume-snapshots=true \
    --velero-pod-cpu-request "200m" \
    --velero-pod-mem-request "512Mi" \
    --velero-pod-cpu-limit "1" \
    --velero-pod-mem-limit "2048Mi" \
    --use-restic \
    --namespace velero \
    --restic-pod-cpu-request "200m" \
    --restic-pod-mem-request "512Mi" \
    --restic-pod-cpu-limit "1" \
    --restic-pod-mem-limit "2048Mi"

    # housekeeping
    rm -f credentials-velero
    rm -rf velero-v*-linux-amd64
    sleep 10
    kubectl config set-context --current --namespace=velero
    kubectl get pod
    kubectl config set-context --current --namespace=default
}


#
#  Function veleromonitoringfunction
#
function veleromonitoringfunction {
    echo
    echo "+-------------------------------------------------------------+"
    echo "|                     Velero Monitoring                       |"
    echo "+-------------------------------------------------------------+"

    # Set current working directory
    mycurdir=$(pwd)
    cd /root

    # Create the secret data
    mynamespace=dxc-maint-ns
    kubectl delete secret velero-monitor -n $mynamespace > /dev//null 2>&1
    kubectl create secret generic velero-monitor -n $mynamespace \
    --from-literal="linuxtarball=${linuxTarball}" \
    --from-literal="mysubscription=${MySubscription}" \
    --from-literal="myresgrp=${MyResGrp}" \
    --from-literal="myclustername=${MyClusterName}" \
    --from-literal="mylocation=${MyLocation}" \
    --from-literal="myworkspacekey=${MyAMWorkspacekey}" \
    --from-literal="myworkspaceid=${MyAMWorkspaceid}" \
    --from-literal="mytenantid=${MyTenantId}" \
    --from-literal="spnname=${myveleromidsp}" \
    --from-literal="spnpass=${myveleromidsecret}" \
    --from-literal="mintimer=${mintimer}"

# Deploy application to AKS
tee mypod.yaml << \EOF
apiVersion: v1
kind: ConfigMap
metadata:
  name: veleromonitor
data:
  velero-monitor.sh: |
    #!/bin/bash
    . /myvars
    dataid="MonitorTypeId"
    LogType=VeleroCustomLog
    datanum=Backup
    datakey1=AKSClusterId
    datakey2=AKSLocation
    datavalue1="/subscriptions/$MYSUBSCRIPTION/resourceGroups/$MYRESGRP/providers/Microsoft.ContainerService/managedClusters/$MYCLUSTERNAME"
    datavalue2=$MYLOCATION
    datakey3=Message
    alerts=Critical
    function sendlog {
       timestamp=$(date -u +"%a, %d %b %Y %H:%M:%S GMT")
       stringToSign=$(echo -e "POST\n${#data}\napplication/json\nx-ms-date:${timestamp}\n/api/logs")
       decodedkey=$(printf %s $MYWORKSPACEKEY | base64 -d)
       encodedHash=$(printf %s "$stringToSign" | openssl dgst -sha256 -binary -hmac "$decodedkey" | sed "s/^.* //" | base64)
       Signature="SharedKey $MYWORKSPACEID:$encodedHash"
       curl -H "Content-Type:application/json" -d "${data}" "https://$MYWORKSPACEID.ods.opinsights.azure.com/api/logs?api-version=2016-04-01" -H "x-ms-date:${timestamp}" -H "Log-Type:${LogType}" -H "Authorization:${Signature}" -v
    }
    function keyvaluepair {
       data="{"$dataid":"\"$datanum\"","AlertsSeverity":"\"$alerts\"","$datakey1:\"$datavalue1\"","$datakey2:\"$datavalue2\"","$datakey3:\"$datavalue3\""}"
       sendlog
    }
    mycheck=$(/usr/sbin/velero backup get | grep -v Completed | grep -v InProgress | grep -v STATUS)
    if [ "x$mycheck" != x ]; then
       datavalue3="$mycheck"
       keyvaluepair
    fi
  login.sh: |
    az login --service-principal -u $SECRET_USERNAME -p $SECRET_PASSWORD --tenant $MYTENANTID
    az account set --subscription $MYSUBSCRIPTION
    az aks get-credentials --resource-group $MYRESGRP --name $MYCLUSTERNAME --admin --overwrite-existing
    /usr/sbin/velero create schedule dailyfullbackup --schedule="@every 13h" --include-namespaces "*" --include-resources "*" --include-cluster-resources=true --ttl 336h0m0s
  init.sh: |
    echo "export MYWORKSPACEID=$MYWORKSPACEID" > /myvars
    echo "export MYLOCATION=$MYLOCATION" >> /myvars
    echo "export MYWORKSPACEKEY=$MYWORKSPACEKEY" >> /myvars
    echo "export MYSUBSCRIPTION=$MYSUBSCRIPTION" >> /myvars
    echo "export MYCLUSTERNAME=$MYCLUSTERNAME" >> /myvars
    echo "export MYRESGRP=$MYRESGRP" >> /myvars
    chmod 700 /myvars

    apt-get update
    apt-get install -y curl
    apt-get install -y wget
    apt-get install -y cron
    apt-get install -y azure-cli
    curl -LO https://storage.googleapis.com/kubernetes-release/release/$(curl -s https://storage.googleapis.com/kubernetes-release/release/stable.txt)/bin/linux/amd64/kubectl
    chmod +x /kubectl
    mv /kubectl /usr/local/bin/kubectl
    wget $LINUXTARBALL
    tar zxf velero-v*.tar.gz
    rm -f velero-v*.tar.gz
    mv velero-v*/velero /usr/sbin
    rm -rf velero-v*linux*
    service cron start
    (crontab -l 2>/dev/null; echo "*/$MINTIMER * * * * /veleromonitor/velero-monitor.sh > /tmp/cronjob.log 2>&1") | crontab -
    /veleromonitor/login.sh
    service cron restart

---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: velero-monitor
spec:
  selector:
    matchLabels:
      app: velero-monitor
  template:
    metadata:
      labels:
        app: velero-monitor
    spec:
      volumes:
      - name: veleromonitor
        configMap:
          name: veleromonitor
          defaultMode: 0777
      containers:
      - command: ["sh","-c","/veleromonitor/init.sh; sleep infinity"]
        image: ubuntu
        name: velero
        volumeMounts:
          - mountPath: /veleromonitor
            name: veleromonitor
        env:
        - name: LINUXTARBALL
          valueFrom:
            secretKeyRef:
              name: velero-monitor
              key: linuxtarball
        - name: MYSUBSCRIPTION
          valueFrom:
            secretKeyRef:
              name: velero-monitor
              key: mysubscription
        - name: MYRESGRP
          valueFrom:
            secretKeyRef:
              name: velero-monitor
              key: myresgrp
        - name: MYCLUSTERNAME
          valueFrom:
            secretKeyRef:
              name: velero-monitor
              key: myclustername
        - name: MYLOCATION
          valueFrom:
            secretKeyRef:
              name: velero-monitor
              key: mylocation
        - name: MYWORKSPACEKEY
          valueFrom:
            secretKeyRef:
              name: velero-monitor
              key: myworkspacekey
        - name: MYWORKSPACEID
          valueFrom:
            secretKeyRef:
              name: velero-monitor
              key: myworkspaceid
        - name: MYTENANTID
          valueFrom:
            secretKeyRef:
              name: velero-monitor
              key: mytenantid
        - name: SECRET_USERNAME
          valueFrom:
            secretKeyRef:
              name: velero-monitor
              key: spnname
        - name: SECRET_PASSWORD
          valueFrom:
            secretKeyRef:
              name: velero-monitor
              key: spnpass
        - name: MINTIMER
          valueFrom:
            secretKeyRef:
              name: velero-monitor
              key: mintimer
        resources:
          requests:
            cpu: 300m
            memory: 256Mi
          limits:
            cpu: 400m
            memory: 512Mi
        readinessProbe:
          exec:
            command:
            - "cat"
            - "/var/spool/cron/crontabs/root"
          periodSeconds: 5
EOF

    # Create Solution
    kubectl delete -f mypod.yaml -n $mynamespace > /dev//null 2>&1
    kubectl create -f mypod.yaml -n $mynamespace
    rm -f mypod.yaml

    # Wait for a running Pod or timeout
    echo
    echo -n "Please wait."
    for i in {1..60}; do
        mycheck=$(kubectl get pod -n $mynamespace | grep velero-monitor | grep -v RESTARTS | grep -v Terminating | awk '{print $3}')
        if [ "x$mycheck" != x"Running" ]; then
            sleep 3
            echo -n .
        else
            break
        fi
    done
    echo

    cd $mycurdir

}

#
#  Function kuredinstall
#
function kuredinstall {

    kuredget="https://github.com/weaveworks/kured/releases/download/${MyKuredVersion}/kured-${MyKuredVersion}-dockerhub.yaml"
    wget $kuredget
    kuredget="kured-${MyKuredVersion}-dockerhub.yaml"

    # Check for pre-existing (simplify upgrade)
    mycheck=$(kubectl get ds -n kube-system | grep kured | awk '{print $1}')
    if [ x$mycheck != x ]; then
        kubectl delete -f $kuredget
    fi

    echo "            - --reboot-days=${MyKuredRebootdays}" >> $kuredget
    echo "            - --start-time=${MyKuredStarttime}" >> $kuredget
    echo "            - --end-time=${MyKuredEndtime}" >> $kuredget
    echo "            - --period=${MyKuredPeriod}" >> $kuredget
    echo "            - --time-zone=${MyKuredTZ}" >> $kuredget
    kubectl create -f $kuredget
    rm -f $kuredget
}

#
#  Function CoreDNS
#
function corednsconfigure {
    echo "apiVersion: v1" > coredns.yaml
    echo "kind: ConfigMap" >> coredns.yaml
    echo "metadata:" >> coredns.yaml
    echo "  name: coredns-custom" >> coredns.yaml
    echo "  namespace: kube-system" >> coredns.yaml
    echo "data:" >> coredns.yaml
    echo "  mycoredns.server: | " >> coredns.yaml
    echo "    ${MyCoreDNSDomain}:53 {" >> coredns.yaml
    echo "        forward . ${MyCoreDNSForwarderIp}" >> coredns.yaml
    echo "    }" >> coredns.yaml
    kubectl apply -f coredns.yaml
    kubectl delete pod --namespace kube-system --selector k8s-app=kube-dns
    rm -f coredns.yaml
}

#
#  Function agicconfigure
#
function agicconfigure {
{MyClusterName}
    # None existant network (greenfield/brownfield)
    if [ x${MyExtvNetResGrp} == xdisabled ] ; then
        echo "-------> vNET and subnet in AKS resource group"
        myagicresgrpparam=${MyResGrp}
    # Pre-existing vNET and subnet in another resource group (Hub and Spoke)
    else
        echo "-------> Pre-existing vNET in another resource group"
        myagicresgrpparam=${MyExtvNetResGrp}
    fi

    # Create pubilc IP Address in AppGW resource group
    echo "-------> Create Public IP Address"
    az network public-ip create -n  $AppgwIp -g ${MyResGrp} --allocation-method Static --sku Standard

    # None existant network (greenfield/brownfield)
    if [ x${MyExtvNetResGrp} == xdisabled ] ; then
        echo "-------> Create AppGW Subnet in AKS vNET"
        az network vnet subnet create --name ${MyAGICSubnet} --resource-group ${myagicresgrpparam} --vnet-name ${MyVnetName} --address-prefix ${MyAGICSubnetPrefix}
        sleep 30
    # Pre-existing vNET and subnet in another resource group (Hub and Spoke)
    else
        mycheck=$(az network vnet subnet list -g ${myagicresgrpparam} --vnet-name ${MyVnetName} --query [].name -o tsv | grep ${MyAGICSubnet})
        if [ x$mycheck == x ]; then
            echo "-------> Create AppGW Subnet in vNET in another resource group"
            az network vnet subnet create -g ${myagicresgrpparam} --vnet-name ${MyVnetName} -n ${MyAGICSubnet} --address-prefixes ${MyAGICSubnetPrefix}
            sleep 30
        fi
    fi

    appgwpubipresid=$(az network public-ip show -g ${MyResGrp} -n ${MyClusterName}AppgwIp --query id -o tsv)

    echo "-------> Create AppGW in ${myagicresgrpparam} Resource Group"
    subnet_id=$(az network vnet show -g ${myagicresgrpparam} -n ${MyVnetName} --subscription ${MySubscription} --query subnets[].id -o tsv | grep ${MyAGICSubnet})
    az network application-gateway create -n ${MyClusterName}AppGateway -l ${MyLocation} -g ${MyResGrp} --sku ${MyWAFStd} --public-ip-address ${appgwpubipresid} --subnet $subnet_id

    # For Kubenet and Hub and Spoke
    if [ x${MyCNIEnabled} == xfalse ] && [ x${MyExtvNetResGrp} != xdisabled ]; then
        echo "-------> Assigning AGIC subnet to route table"
        myrouteresgrp=${MyResGrp}
        myrouteids=$(az network route-table list -g ${myrouteresgrp} --subscription ${MySubscription} --query [].id -o tsv)
        appGatewaySubnetId=$(az network application-gateway show -n ${MyClusterName}AppGateway -g ${MyResGrp} -o tsv --query "gatewayIpConfigurations[0].subnet.id")
        az network vnet subnet update --id ${appGatewaySubnetId} --route-table ${myrouteids}
    fi

    # Enable AppGW add-on
    appgwId=$(az network application-gateway show -n ${MyClusterName}AppGateway -g ${MyResGrp} -o tsv --query "id") 
    echo "-------> Enable Add-on"
    az aks enable-addons -n ${MyClusterName} -g ${MyResGrp} -a ingress-appgw --appgw-id $appgwId

    echo "+------------------------------------+"
    echo "|       App Gateway IP Address       |"
    echo "+------------------------------------+"
    az network public-ip show \
        --resource-group ${MyResGrp} \
        --name ${MyClusterName}AppgwIp \
        --query [ipAddress] \
        --output tsv
    echo
}

