#!/bin/bash
echo
echo "# -------------------------------------------------------"
echo "# Name:     Roland Balgobind"
echo "# Date:     16th November 2020"
echo "# Version:  4.0"
echo "# Comments: This script is used to add the roles and"
echo "#           role bindings to allow an App to be deployed"
echo "#           from Azure DevOps to an AKS Cluster specific"
echo "#           namespace"
echo "#"
echo "# (c) Copyright DXC Technology, 2020. All rights reserved"
echo "# -------------------------------------------------------"
echo

. ./variables.sh

if [ x$MySPN == xtrue ]; then
    myup="secret"
else
    myup="password"
fi

# Main code
echo
echo -n "Enter $myup for $myusername: "
read -rs mypassword
echo

# Login to Azure
if [ x$MySPN == xtrue ]; then
	az login --service-principal -u $myusername -p $mypassword --tenant $MyTenantId
else
	az login -u $myusername -p $mypassword
fi
echo
az account set --subscription ${MySubscription}
az aks get-credentials --resource-group $MyResGrp --name $MyClusterName --admin --overwrite-existing

# Create ClusterRole
echo "kind: ClusterRole" > role-namespace.yaml
echo "apiVersion: rbac.authorization.k8s.io/v1beta1" >> role-namespace.yaml
echo "metadata:" >> role-namespace.yaml
echo "  name: ${myclientns}-services" >> role-namespace.yaml
echo "rules:" >> role-namespace.yaml
echo "- apiGroups: [\"\", \"extensions\", \"apps\"]" >> role-namespace.yaml
echo "  resources: [\"*\"]" >> role-namespace.yaml
echo "  verbs: [\"*\"]" >> role-namespace.yaml
echo "- apiGroups: [\"\"]" >> role-namespace.yaml
echo "  resources: [\"*\"]" >> role-namespace.yaml
echo "  verbs: [\"*\"]" >> role-namespace.yaml

kubectl apply -f role-namespace.yaml
rm -f role-namespace.yaml

# Create tenant binding
echo "apiVersion: rbac.authorization.k8s.io/v1" > rolebinding-namespace.yaml
echo "kind: RoleBinding" >> rolebinding-namespace.yaml
echo "metadata:" >> rolebinding-namespace.yaml
echo "  name: ${myclientns}-deployment" >> rolebinding-namespace.yaml
echo "  namespace: ${myclientns}" >> rolebinding-namespace.yaml
echo "subjects:" >> rolebinding-namespace.yaml
echo "- kind: ServiceAccount" >> rolebinding-namespace.yaml
echo "  name: deploysa" >> rolebinding-namespace.yaml
echo "  namespace: ${myclientns}" >> rolebinding-namespace.yaml
echo "roleRef:" >> rolebinding-namespace.yaml
echo "  apiGroup: rbac.authorization.k8s.io" >> rolebinding-namespace.yaml
echo "  kind: ClusterRole" >> rolebinding-namespace.yaml
echo "  name: ${myclientns}-services" >> rolebinding-namespace.yaml

kubectl apply -f rolebinding-namespace.yaml
kubectl get rolebinding -n ${myclientns}
