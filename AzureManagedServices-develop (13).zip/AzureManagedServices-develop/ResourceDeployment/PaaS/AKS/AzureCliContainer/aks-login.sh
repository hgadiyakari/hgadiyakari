#!/bin/bash
echo
echo "# -------------------------------------------------------"
echo "# Name:     Roland Balgobind"
echo "# Date:     16th March 2021"
echo "# Version:  6.0"
echo "# Comments: Login to an AKS cluster"
echo "#"
echo "# (c) Copyright DXC Technology, 2021. All rights reserved"
echo "# -------------------------------------------------------"
echo

if [ x$1 == x ]; then
	echo
	echo "Usage: ./aks-login.sh [aad|admin|spn]"
	echo
else
	. ./variables.sh

	if [ x$1 == xspn ]; then
		myun="Service Principal ID"
		myup="secret"
	else
		myun="username"
		myup="password"
	fi

	if [ x$2 != x ]; then
		myusername=$2
	fi

    echo -n "Enter $myun [$myusername]: "
    read ans
    if [ x$ans != x ]; then
        myusername=$ans
    fi
    echo -n "Enter $myup for $myusername: "
    read -rs mypassword
    echo

	# AAD
	if [ x$1 == xaad ]; then
		az login -u $myusername -p $mypassword
		az account set --subscription ${MySubscription}
		echo
		az aks get-credentials --resource-group $MyResGrp --name $MyClusterName --overwrite-existing
	fi

	# Administrator
	if [ x$1 == xadmin ]; then
		az login -u $myusername -p $mypassword
		az account set --subscription ${MySubscription}
		echo
		az aks get-credentials --resource-group $MyResGrp --name $MyClusterName --admin --overwrite-existing
	fi

	# Service Principal
	if [ x$1 == xspn ]; then
		az login --service-principal -u $myusername -p $mypassword --tenant $MyTenantId
		az account set --subscription ${MySubscription}
		echo
		az aks get-credentials --resource-group $MyResGrp --name $MyClusterName --admin --overwrite-existing
	fi
fi
