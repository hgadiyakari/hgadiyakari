#!/bin/bash
echo
echo "+-----------------------------------------------------------+"
echo "|  Name     : Roland Balgobind                              |"
echo "|  Date     : 2nd June 2021                                 |"
echo "|  Version  : 21.0                                          |"
echo "|  Comments : Add variables to Azure DevOps library         |"
echo "|                                                           |"
echo "|  (c) Copyright DXC Technology, 2021. All rights reserved  |"
echo "+-----------------------------------------------------------+"
TERM=vt100
export TERM
RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m' # No Color

echo "+-----------------------------------------------------------+"
echo "|      Please see the following documentation to fully      |"
echo "|            understand the variables being used            |"
echo "|              - Azure AKS Variables File -                 |"
echo "+-----------------------------------------------------------+"
echo -n " < Return to continue > "
read
echo

. ./variables.sh
errorgen=false
rm -f /tmp/myerrlog

#######################################################################
#                         CURRENTLY DISABLED                          #
#######################################################################
if [ x${MyAzurePolicy} != x"false" ]; then
   echo " * Unsupported or missing: MyAzurePolicy" >> /tmp/myerrlog
   errorgen=true
fi
if [ x${MyAzureDefender} != x"false" ]; then
   echo " * Unsupported or missing: MyAzureDefender" >> /tmp/myerrlog
   errorgen=true
fi
#######################################################################

myname="DXC AKS Variable group"
mydesc="Variables required to deploy, upgrade and delete an AKS cluster"

# Add variables
myarray=( MySPN 
MyTenantId 
MyAMWorkspace 
MyAMWorkspaceResGrp 
MyResGrp 
MyClusterPrefix 
MyLocation 
MyNodeCount 
MyAKSPodPerNode 
MyNodeDiskSize 
MyVMSize 
MySelfHosted 
MyExtvNetResGrp  
MyDXCGenResGrp 
MyCNIEnabled 
MyVnetExists 
MyVnetName 
MyVnetSubnetName 
MyPolicy 
MyDockerBrdgAddr 
MyAKSVnetCIDR 
MyAKSVnetDNSIP 
MyAKSVnetwork 
MyAKSVnetSubnet 
MyAuthRange 
MyPrivateCluster 
MyDeployValidationVMs  
MyUserResGrp 
MyUserVnet 
MyUserVnetCIDR 
MyUserSubnet 
MyUserSnetName 
MyMgMtSnetName 
MyMgMtSubnet 
MyPrivLinkSubnet 
MyAKSPodCIDR 
MyAGIC 
MyWAFStd  
MyAGICSubnetPrefix 
MyAGICSubnet 
linuxTarball 
MyVeleroResGrp 
MyVeleroStrgAcct 
MyVeleroBlob 
MyVeleroSKU 
MyAutoscalerEnabled 
MyASMin 
MyASMax 
MyAadGroup 
MyACREnabled 
MyACRResGrp 
MyACRName 
MyACRSKU 
MyDXCACRName 
MyDXCACRSKU 
MyKuredVersion 
MyKuredRebootdays 
MyKuredStarttime 
MyKuredEndtime 
MyKuredPeriod 
MyKuredTZ 
MyAzurePolicy 
MyAzureDefender 
MyCoreDNSDomain 
MyCoreDNSForwarderIp )

# Blanks check
for mykey in "${myarray[@]}"
do
   myvar=${!mykey}
   myvarcheck=$(cat variables.sh | grep ^$mykey\= | cut -f1 -d=)
   if [ -z $myvar ]; then
      echo " ^ Blank entries: $mykey"  >> /tmp/myerrlog
      errorgen=true
   fi
done

# Case check
for mykey in "${myarray[@]}"
do
   myvar=${!mykey}
   myvarcheck=$(cat variables.sh | grep ^$mykey\= | cut -f1 -d=)
   mytrvar=$(echo "$myvar" | tr '[:upper:]' '[:lower:]')
   if [ x$mytrvar != x$myvar ]; then
      shopt -s nocasematch
      case "$mytrvar" in
         true|false )
            echo " ? Lower-case required: $myvarcheck"  >> /tmp/myerrlog
            errorgen=true
      esac
   fi
done

# Multiple entries check
for mykey in "${myarray[@]}"
do
   myvar=${!mykey}
   mynumcheck=$(cat variables.sh | grep ^$mykey\= | wc -l)
   if [ $mynumcheck -gt 1 ]; then
       echo " + Multiple entries: $mykey"  >> /tmp/myerrlog
       errorgen=true
   fi
done

# Missing variables check
for mykey in "${myarray[@]}"
do
   myvar=${!mykey}
   myvarcheck=$(cat variables.sh | grep ^$mykey\= | cut -f1 -d= | head -1)
   if [ x$myvarcheck == x ]; then
       echo " - Missing variable: $mykey" >> /tmp/myerrlog
       errorgen=true
   fi
done

# Error code
if [ x$errorgen == xtrue ]; then
   clear
   printf "${RED}"
   echo
   echo "+-----------------------------------------------------------+"
   echo "|      Please see the following documentation to fully      |"
   echo "|            understand the variables being used            |"
   echo "|              - Azure AKS Variables File -                 |"
   echo "+-----------------------------------------------------------+"
   printf "${NC}"
   echo >> /tmp/myerrlog
   cat /tmp/myerrlog
   rm -f /tmp/myerrlog
   exit
else
   printf "${GREEN}"
   echo " Variables file validated"
   echo
   printf "${NC}"
fi

# Login
if [ x$1 == xtoken ]; then
    echo "+-----------------------------------------------------------+"
    echo " Token access to Azure DevOps enabled"
    echo "+-----------------------------------------------------------+"
    echo -n " Enter Azure DevOps PAT token : "
    read mytoken
    if [ x$MySPN != xtrue ]; then
        echo
        echo "+-----------------------------------------------------------+"
        echo " Azure AAD deployment login account"
        echo "+-----------------------------------------------------------+"
        echo -n " Enter password for $myusername : "
        read -rs mypassword1
        myusername1=$myusername
        echo
    fi
else
    echo "+-----------------------------------------------------------+"
    echo " Azure AAD DevOps/deployment login account"
    echo "+-----------------------------------------------------------+"
    echo -n " Enter password for $myusername : "
    read -rs mypassword1
    myusername1=$myusername
    echo
fi

if [ x$MySPN == xtrue ]; then
    echo -n " Enter deployment Service Principal ID : "
    read myusername
    echo -n " Enter Service Principal Secret : "
    read mypassword
else
    mypassword=$mypassword1
fi

if [ x$MySPN == xtrue ]; then
    echo -n " Enter Velero Backup Service Principal ID : "
    read myvelerosp
    echo -n " Enter Velero Backup Service Principal Secret : "
    read myvelerosecret

    if [ x$MyAGIC == xtrue ]; then
        echo -n " Enter AGIC Service Principal ID : "
        read myagicsp
        echo -n " Enter AGIC Service Principal Secret : "
        read myagicsecret
    fi
fi

echo -n " Enter primary key for workspace $MyAMWorkspace : "
read MyAMWorkspacekey

if [ x$MyPrivateCluster = xtrue ]; then
   echo -n " Enter password for Management Jumpserver : "
   read mymgmtjspasswd
   echo -n " Enter password for User Jumpserver : "
   read myuserjspasswd
else
   mymgmtjspasswd="Praff78Emmfuurrj@@"
   myuserjspasswd="MRyvvhfMp45faFFoo@@"
fi

# Add DevOps extension
az extension add --name azure-devops

# Login to Azure
if [ x$1 == xtoken ]; then
    #echo $mytoken | az devops login --organization https://dev.azure.com/${myorg}
    export AZURE_DEVOPS_EXT_PAT=$mytoken
else
    az login -u $myusername1 -p $mypassword1
fi

# Create variable group in a DevOps library
az pipelines variable-group create \
--name "$myname" \
--variables "MyClusterName=$MyClusterName" \
--authorize "true" \
--description "$mydesc" \
--detect "false" \
--organization "https://dev.azure.com/$myorg" \
--project $myproject

# Obtain group id
mygrupid=$(az pipelines variable-group list \
--group-name "DXC AKS Variable group" \
--organization "https://dev.azure.com/$myorg" \
--project $myproject \
| grep -A1 "$mydesc" | grep -v "$mydesc" \
| awk '{print $2}' | cut -d, -f1)

# Add non-hidden variables
for mykey in "${myarray[@]}"
do
   myvar=${!mykey}
   az pipelines variable-group variable create \
      --group-id $mygrupid \
      --name $mykey \
      --organization "https://dev.azure.com/$myorg" \
      --project $myproject \
      --value $myvar
done

# Add additional non-hidden variables
for mykey in "${myarray1[@]}"
do
   myvar=${!mykey}
   az pipelines variable-group variable create \
      --group-id $mygrupid \
      --name $mykey \
      --organization "https://dev.azure.com/$myorg" \
      --project $myproject \
      --value $myvar
done

# Add hidden variables to variables group
myarray=( MyAMWorkspaceid MySubscription MyAMWorkspacekey )
for mykey in "${myarray[@]}"
do
   myvar=${!mykey}
   az pipelines variable-group variable create \
      --group-id $mygrupid \
      --name $mykey \
      --organization "https://dev.azure.com/$myorg" \
      --project $myproject \
      --secret true \
      --value $myvar
done

# Add NSG to variable to DevOps library
az pipelines variable-group variable create \
   --group-id $mygrupid \
   --name MyNSGSourceCIDR \
   --organization "https://dev.azure.com/$myorg" \
   --project $myproject \
   --secret false \
   --value "$MyNSGSourceCIDR"

# Add zones variable to DevOps library
az pipelines variable-group variable create \
   --group-id $mygrupid \
   --name MyZones \
   --organization "https://dev.azure.com/$myorg" \
   --project $myproject \
   --secret false \
   --value "$MyZones"

# Add AKS Cluster tags
az pipelines variable-group variable create \
   --group-id $mygrupid \
   --name MyClusterTags \
   --organization "https://dev.azure.com/$myorg" \
   --project $myproject \
   --secret false \
   --value "$MyClusterTags"

# Add AKS Cluster nodepool tags
az pipelines variable-group variable create \
   --group-id $mygrupid \
   --name MyNodePoolsTags \
   --organization "https://dev.azure.com/$myorg" \
   --project $myproject \
   --secret false \
   --value "$MyNodePoolsTags"

# Add username variable to DevOps library
az pipelines variable-group variable create \
   --group-id $mygrupid \
   --name MyLoginName \
   --organization "https://dev.azure.com/$myorg" \
   --project $myproject \
   --secret true \
   --value $myusername

# Add password variable to DevOps library
az pipelines variable-group variable create \
   --group-id $mygrupid \
   --name MyLoginPassword \
   --organization "https://dev.azure.com/$myorg" \
   --project $myproject \
   --secret true \
   --value $mypassword

# Add Management Jumpserver password variable to DevOps library
az pipelines variable-group variable create \
   --group-id $mygrupid \
   --name MyMgmtJSPassword \
   --organization "https://dev.azure.com/$myorg" \
   --project $myproject \
   --secret true \
   --value $mymgmtjspasswd

# Add User Jumpserver password variable to DevOps library
az pipelines variable-group variable create \
   --group-id $mygrupid \
   --name MyUserJSPassword \
   --organization "https://dev.azure.com/$myorg" \
   --project $myproject \
   --secret true \
   --value $myuserjspasswd

if [ x$MySPN == xtrue ]; then
    # Add Velero SP variable to DevOps library
    az pipelines variable-group variable create \
       --group-id $mygrupid \
       --name MyVeleroSP \
       --organization "https://dev.azure.com/$myorg" \
       --project $myproject \
       --secret true \
       --value $myvelerosp

    # Add Velero Secret variable to DevOps library
    az pipelines variable-group variable create \
       --group-id $mygrupid \
       --name MyVeleroSecret \
       --organization "https://dev.azure.com/$myorg" \
       --project $myproject \
       --secret true \
       --value $myvelerosecret

        if [ x$MyAGIC == xtrue ]; then
            # Add AGIC SP variable to DevOps library
            az pipelines variable-group variable create \
                --group-id $mygrupid \
                --name MyAGICSP \
                --organization "https://dev.azure.com/$myorg" \
                --project $myproject \
                --secret true \
                --value $myagicsp

            # Add AGIC Secret variable to DevOps library
            az pipelines variable-group variable create \
                --group-id $mygrupid \
                --name MyAGICSecret \
                --organization "https://dev.azure.com/$myorg" \
                --project $myproject \
                --secret true \
                --value $myagicsecret
        fi
fi
