#!/bin/bash
echo
echo "# --------------------------------------------------------"
echo "# Name:     Roland Balgobind"
echo "# Date:     5th February 2021"
echo "# Version:  1.0"
echo "# Comments: Add a private link to a primary site Velero"
echo "#           backup storage account"
echo "#"
echo "# (c) Copyright DXC Technology, 2021. All rights reserved"
echo "# --------------------------------------------------------"
echo

TERM=vt100
export TERM

# dot-source variables and functions
. ../variables.sh
myorigcluster=$MyClusterName
. ./variables.sh
mycluster=$MyClusterName
MyClusterName=$myorigcluster

. ../mainfunctions.sh

# Main code
if [ x$MySPN == xtrue ]; then
    myup="secret"
    echo -n "Enter Service Principal ID: "
    read myusername
else
    myup="password"
fi

echo -n "Enter $myup for $myusername: "
read -rs mypassword
echo

# echo -n "Enter primary key for workspace $MyAMWorkspace: "
# read MyAMWorkspacekey

if [ x$MySPN == xtrue ]; then
    echo -n "Enter Velero Backup Service Principal ID : "
    read MyVeleroSP
    echo -n "Enter Velero Backup Service Principal Secret : "
    read MyVeleroSecret

    if [ x$MyAGIC == xtrue ]; then
        echo -n "Enter AGIC Service Principal ID : "
        read MyAGICSP
        echo -n "Enter AGIC Service Principal Secret : "
        read MyAGICSecret
    fi
fi

# Login to Azure
if [ x$MySPN == xtrue ]; then
    az login --service-principal -u $myusername -p $mypassword --tenant $MyTenantId
else
    az login -u $myusername -p $mypassword
fi
echo

subcheck=$(az account show --subscription ${MySubscription} --query id --output tsv)
retVal=$?
if [ $retVal -ne 0 ]; then
    echo " +--------------------------------------------------------+"
    echo " |       Subscription could not be found. Exiting...      |"
    echo " +--------------------------------------------------------+"
    echo
   exit $retVal
fi

echo
az account set --subscription ${MySubscription}
az aks get-credentials --resource-group $MyResGrp --name $MyClusterName --admin --overwrite-existing

# Install extension
az extension add --name azure-devops

echo
echo "      ========================================================="
echo "                     AZURE STORAGE PRIVATE LINK                "
echo "      ========================================================="
# Create Azure Storage (files or blobs) private link
function azure-storage-private-links {

    # Get storage account ID 
    storageAccount=$(az storage account show \
        --resource-group ${backendprivatelink} \
        --name ${storageprivatelink} \
        --query "id" | \
        tr -d '"')

    # Get virtual network ID
    virtualNetwork=$(az network vnet show \
        --resource-group $resgroupprivatelink \
        --name $vnetnameprivatelink \
        --query "id" | \
        tr -d '"')

    # Get subnet ID
    subnet=$(az network vnet subnet show \
        --resource-group $resgroupprivatelink \
        --vnet-name $vnetnameprivatelink \
        --name $subnetName \
        --query "id" | \
        tr -d '"')

    # Disable private endpoint network policies
    az network vnet subnet update \
        --ids $subnet \
        --disable-private-endpoint-network-policies \
        --output none

    # Get virtual network location
    region=$(az network vnet show \
            --ids $virtualNetwork \
            --query "location" | \
        tr -d '"')

    # Create a private endpoint
    privateEndpoint=$(az network private-endpoint create \
        --resource-group ${resgroupprivatelink} \
        --name "${storageprivatelink}-PrivateEndpoint" \
        --location $region \
        --subnet $subnet \
        --private-connection-resource-id $storageAccount \
        --group-id ${storagetype} \
        --connection-name "${storageprivatelink}-Connection" \
        --query "id" | \
        tr -d '"')  

    # Find a DNS zone matching desired name attached to this virtual network.
    possibleDnsZones=""
    possibleDnsZones=$(az network private-dns zone list \
        --query "[?name == '$dnsZoneName'].id" \
        --output tsv)

    dnsZone=""
    possibleDnsZone=""
    for possibleDnsZone in $possibleDnsZones
    do
        possibleResourceGroupName=$(az resource show \
            --ids $possibleDnsZone \
            --query "resourceGroup" | \
            tr -d '"')

        link=$(az network private-dns link vnet list \
            --resource-group $possibleResourceGroupName \
            --zone-name $dnsZoneName \
            --query "[?virtualNetwork.id == '$virtualNetwork'].id" \
            --output tsv)

        if [ -z $link ]
        then
            echo "1" > /dev/null
        else 
            dnsZoneResourceGroup=$possibleResourceGroupName
            dnsZone=$possibleDnsZone
            break
        fi  
    done

    if [ -z $dnsZone ]
    then
        # No matching DNS zone attached to virtual network, so create a new one
        dnsZone=$(az network private-dns zone create \
            --resource-group $resgroupprivatelink \
            --name $dnsZoneName \
            --query "id" | \
            tr -d '"')

        # Blob DNS Link
        az network private-dns link vnet create \
            -g $resgroupprivatelink \
            -z $dnsZoneName \
            -n "${vnetnameprivatelink}dnslink" \
            -v $virtualNetwork \
            -e false \
            --output none

        # Blob Usernet DNS Link
        UserVnetID=$(az network vnet show \
            -g ${MyUserResGrp} \
            -n ${MyUserVnet} --query 'id' -o tsv)

        az network private-dns link vnet create \
            -g $resgroupprivatelink \
            -z $dnsZoneName \
            -n ${MyUserVnet}dnsink \
            -v $UserVnetID \
            -e false  \
            --output none

        dnsZoneResourceGroup=$resgroupprivatelink
    fi

    privateEndpointNIC=$(az network private-endpoint show \
        --ids $privateEndpoint \
        --query "networkInterfaces[0].id" | \
        tr -d '"')

    privateEndpointIP=$(az network nic show \
        --ids $privateEndpointNIC \
        --query "ipConfigurations[0].privateIpAddress" | \
        tr -d '"')

    az network private-dns record-set a create \
        --resource-group $dnsZoneResourceGroup \
        --zone-name $dnsZoneName \
        --name ${storageprivatelink} \
        --output none

    az network private-dns record-set a add-record \
        --resource-group $dnsZoneResourceGroup \
        --zone-name $dnsZoneName \
        --record-set-name ${storageprivatelink} \
        --ipv4-address $privateEndpointIP \
        --output none

    az storage account update \
        --resource-group ${backendprivatelink} \
        --name ${storageprivatelink} \
        --bypass "AzureServices" \
        --default-action "Deny" \
        --output none

    # Validate output
    if [ $customersa == xusernet ]; then
        httpEndpoint=$(az storage account show \
        --resource-group ${backendprivatelink} \
        --name ${storageprivatelink} \
        --query "primaryEndpoints.${storagetype}" | \
        tr -d '"')

        hostName=$(echo $httpEndpoint | cut -c7-$(expr length $httpEndpoint) | tr -d "/")
        nslookup $hostName
    fi
}

# Get the desired storage account suffix (core.windows.net for public cloud).
storageAccountSuffix=$(az cloud show \
    --query "suffixes.storageEndpoint" | \
    tr -d '"')

echo "-----------------------------------------------"
echo "-       AKS to Azure BLOBS private link       -"
echo "-----------------------------------------------"
customersa="aks"
storagetype="blob"
resgroupprivatelink=${MyResGrp}
vnetnameprivatelink=${MyVnetName}
storageprivatelink=${MyVeleroStrgAcct}
backendprivatelink=${MyVeleroResGrp}
subnetName=MyPrivLinkSubnet
dnsZoneName="privatelink.${storagetype}.$storageAccountSuffix"
azure-storage-private-links
            
            