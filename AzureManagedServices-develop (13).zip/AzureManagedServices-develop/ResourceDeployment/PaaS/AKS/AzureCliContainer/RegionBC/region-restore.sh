#!/bin/bash
echo
echo "# --------------------------------------------------------"
echo "# Name:     Roland Balgobind"
echo "# Date:     5th February 2021"
echo "# Version:  1.0"
echo "# Comments: Install a second instance of Velero backup"
echo "#"
echo "#"
echo "# (c) Copyright DXC Technology, 2021. All rights reserved"
echo "# --------------------------------------------------------"
echo

TERM=vt100
export TERM

# dot-source variables and functions
. ../variables.sh
myorigcluster=$MyClusterName
. ./variables.sh
mycluster=$MyClusterName
MyClusterName=$myorigcluster

. ../mainfunctions.sh

# Main code
if [ x$MySPN == xtrue ]; then
    myup="secret"
    echo -n "Enter Service Principal ID: "
    read myusername
else
    myup="password"
fi

echo -n "Enter $myup for $myusername: "
read -rs mypassword
echo

# echo -n "Enter primary key for workspace $MyAMWorkspace: "
# read MyAMWorkspacekey

if [ x$MySPN == xtrue ]; then
    echo -n "Enter Velero Backup Service Principal ID : "
    read MyVeleroSP
    echo -n "Enter Velero Backup Service Principal Secret : "
    read MyVeleroSecret

    if [ x$MyAGIC == xtrue ]; then
        echo -n "Enter AGIC Service Principal ID : "
        read MyAGICSP
        echo -n "Enter AGIC Service Principal Secret : "
        read MyAGICSecret
    fi
fi

# Login to Azure
if [ x$MySPN == xtrue ]; then
    az login --service-principal -u $myusername -p $mypassword --tenant $MyTenantId
else
    az login -u $myusername -p $mypassword
fi
echo

subcheck=$(az account show --subscription ${MySubscription} --query id --output tsv)
retVal=$?
if [ $retVal -ne 0 ]; then
    echo " +--------------------------------------------------------+"
    echo " |       Subscription could not be found. Exiting...      |"
    echo " +--------------------------------------------------------+"
    echo
   exit $retVal
fi

echo
az account set --subscription ${MySubscription}
az aks get-credentials --resource-group $MyResGrp --name $MyClusterName --admin --overwrite-existing

# Install extension
az extension add --name azure-devops


#
#  Velero Backup and Restore
#
echo "+-------------------------------------------------------------+"
echo "|                  Velero Backup and Restore                  |"
echo "+-------------------------------------------------------------+"
# Deploy Velero Backup Solution
echo "Deploy Velero Backup Solution"
myvelero=$(echo ${linuxTarball} | cut -f8 -d/)
wget ${linuxTarball}
tar zxf velero-v*.tar.gz
rm -f velero-v*.tar.gz
yes | cp velero-${myvelero}-linux-amd64/velero /usr/sbin

MyNewResGrp=$(az aks show --resource-group $MyResGrp --name $MyClusterName --query nodeResourceGroup --output tsv)

# Checking for resource group
mycheck=$(az group exists --name ${MyVeleroResGrp} --subscription ${MySubscription})
if [ x$mycheck == xtrue ]; then
    echo
    echo " INFO : ${MyVeleroResGrp} resource group already exists"
    echo
else
    # create velero resource group
    az group create --location ${MyLocation} --name ${MyVeleroResGrp}

    # create storage account
    az storage account create --name ${MyVeleroStrgAcct} --resource-group ${MyVeleroResGrp} --location ${MyLocation} --kind StorageV2 --sku Standard_LRS --encryption-services blob --https-only true --access-tier Hot

    # create blob container
    az storage container create --name ${MyVeleroBlob} --public-access off --account-name ${MyVeleroStrgAcct}
fi

# Create the SPN if not deployed using an SPN
if [ x${MySPN} == xtrue ]; then
    myveleromidsp=${MyVeleroSP}
    myveleromidsecret=${MyVeleroSecret}
else
    myveleromidsp=${MyClusterName}velerosp
    myapp=$(az ad app list --display-name  ${MyClusterName}velerosp --query [].appId -o tsv)
    if [ x$myapp != x ]; then
        DXCRandomNo=$(shuf -i 1-10000 -n 1)
        myveleromidsecret=$(az ad sp credential reset \
        --append \
        --name ${MyClusterName}velerosp \
        --years 10 \
        --credential-description "VELERO${DXCRandomNo}" \
        --query password -o tsv)
    else
        myveleromidsecret=$(az ad sp create-for-rbac --name ${myveleromidsp} --role "Contributor" --query 'password' --output tsv)
        myveleromidsecret=$(az ad sp credential reset --name ${myveleromidsp} --years 10 --credential-description "VeleroSecret" --query password -o tsv)
    fi
    myveleromidsp=$(az ad sp list --display-name ${myveleromidsp} --query [0].appId --output tsv)
    sleep 30
fi

# create Velero credentials file
echo "AZURE_SUBSCRIPTION_ID=${MySubscription}" > credentials-velero
echo "AZURE_TENANT_ID=${MyTenantId}" >> credentials-velero
echo "AZURE_CLIENT_ID=${myveleromidsp}" >> credentials-velero
echo "AZURE_CLIENT_SECRET=\"${myveleromidsecret}\"" >> credentials-velero
echo "AZURE_RESOURCE_GROUP=$MyNewResGrp" >> credentials-velero
echo "AZURE_CLOUD_NAME=AzurePublicCloud" >> credentials-velero

# install Velero
velero install --provider azure \
--bucket ${MyVeleroBlob} \
--secret-file ./credentials-velero \
--backup-location-config resourceGroup=${MyVeleroResGrp},storageAccount=${MyVeleroStrgAcct} \
--snapshot-location-config apiTimeout="5m",resourceGroup=${MyVeleroResGrp},subscriptionId=$mysubscriptionid \
--plugins velero/velero-plugin-for-microsoft-azure:${veleroplugin} \
--use-volume-snapshots=true \
--velero-pod-cpu-request "200m" \
--velero-pod-mem-request "512Mi" \
--velero-pod-cpu-limit "1" \
--velero-pod-mem-limit "2048Mi" \
--use-restic \
--namespace drvelero \
--restic-pod-cpu-request "200m" \
--restic-pod-mem-request "512Mi" \
--restic-pod-cpu-limit "1" \
--restic-pod-mem-limit "2048Mi"

# housekeeping
rm -f credentials-velero
rm -rf velero-v*-linux-amd64

sleep 10
kubectl config set-context --current --namespace=drvelero
kubectl get pod
kubectl config set-context --current --namespace=default

# Patch for second Velero instance
kubectl patch clusterrolebinding velero -p '{"subjects":[{"kind": "ServiceAccount", "name": "velero","namespace": "velero"},{"kind": "ServiceAccount", "name": "velero", "namespace": "drvelero"}]}'
kubectl describe clusterrolebinding velero 

# Set current working directory
mycurdir=$(pwd)
cd /root
