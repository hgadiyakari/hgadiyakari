# -------------------------------------------------------
# Name:     Roland Balgobind
# Date:     8th February 2021
# Version:  1.0
# Comments: Variables required to install a second
#           instance of Velero backup
#
# (c) Copyright DXC Technology, 2021. All rights reserved
# -------------------------------------------------------

MyClusterName="mybck8scluster"
MyVeleroResGrp="mybck8sveleroresgrp"
MyVeleroStrgAcct="mybck8sstrgaccount"
MyVeleroBlob="mybck8scontainer"
