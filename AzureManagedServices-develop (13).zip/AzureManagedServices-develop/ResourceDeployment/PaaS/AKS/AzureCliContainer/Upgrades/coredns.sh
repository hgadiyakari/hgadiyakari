#!/bin/bash
echo
echo "# -------------------------------------------------------"
echo "# Name:     Roland Balgobind"
echo "# Date:     14th April 2021"
echo "# Version:  1.0"
echo "# Comments: FEATURE UPDATE"
echo "#           Add support for CoreDNS forwarding"
echo "#"
echo "# (c) Copyright DXC Technology, 2021. All rights reserved"
echo "# -------------------------------------------------------"
echo

. $(cd -P "$(dirname "$0")" && pwd)/../variables.sh

#  CoreDNS Forwarding
if [ ${MyCoreDNSDomain} != disabled ] && [ ${MyCoreDNSForwarderIp} != disabled ]; then

    if [ x$MySPN == xtrue ]; then
        myup="secret"
        echo -n "Enter Service Principal ID: "
        read myusername
    else
        myup="password"
    fi

    # Main code
    echo -n "Enter $myup for $myusername: "
    read -rs mypassword
    echo

    # Login to Azure
    if [ x$MySPN == xtrue ]; then
	    az login --service-principal -u $myusername -p $mypassword --tenant $MyTenantId
    else
	    az login -u $myusername -p $mypassword
    fi
    echo
    az account set --subscription ${MySubscription}
    az aks get-credentials --resource-group $MyResGrp --name $MyClusterName --admin --overwrite-existing

    echo "apiVersion: v1" > coredns.yaml
    echo "kind: ConfigMap" >> coredns.yaml
    echo "metadata:" >> coredns.yaml
    echo "  name: coredns-custom" >> coredns.yaml
    echo "  namespace: kube-system" >> coredns.yaml
    echo "data:" >> coredns.yaml
    echo "  mycoredns.server: | " >> coredns.yaml
    echo "    ${MyCoreDNSDomain}:53 {" >> coredns.yaml
    echo "        forward . ${MyCoreDNSForwarderIp}" >> coredns.yaml
    echo "    }" >> coredns.yaml
    cat coredns.yaml
    kubectl apply -f coredns.yaml
    kubectl delete pod --namespace kube-system --selector k8s-app=kube-dns
    rm -f coredns.yaml

fi
