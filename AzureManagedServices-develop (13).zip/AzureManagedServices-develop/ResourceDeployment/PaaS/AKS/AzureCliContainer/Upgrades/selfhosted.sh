#!/bin/bash
echo
echo "# -------------------------------------------------------"
echo "# Name:     Roland Balgobind"
echo "# Date:     29th March 2021"
echo "# Version:  1.0"
echo "# Comments: FEATURE UPDATE"
echo "#           Add support for Self hosted agents"
echo "#"
echo "# (c) Copyright DXC Technology, 2021. All rights reserved"
echo "# -------------------------------------------------------"
echo

. $(cd -P "$(dirname "$0")" && pwd)/../variables.sh

# Variables
mypool=${MyClusterName}agentpool1

#  Ubuntu Self-hosted Agents
if [ x${MySelfHosted} != x0 ]; then

    if [ x$MySPN == xtrue ]; then
        myup="secret"
        echo -n "Enter Service Principal ID: "
        read myusername
    else
        myup="password"
    fi

    # Main code
    echo -n "Enter $myup for $myusername: "
    read -rs mypassword
    echo

    # Login to Azure
    if [ x$MySPN == xtrue ]; then
	    az login --service-principal -u $myusername -p $mypassword --tenant $MyTenantId
    else
	    az login -u $myusername -p $mypassword
    fi
    echo
    az account set --subscription ${MySubscription}
    az aks get-credentials --resource-group $MyResGrp --name $MyClusterName --admin --overwrite-existing

    # Add public IP address to VMSS to circumvent Auth IP Ranges
    echo "az vmss create \\" > myvmss.sh
    echo "--name $mypool \\" >> myvmss.sh
    echo "--resource-group ${MyResGrp} \\" >> myvmss.sh
    echo "--image UbuntuLTS \\" >> myvmss.sh
    echo "--vm-sku Standard_D2_v3 \\" >> myvmss.sh
    echo "--storage-sku StandardSSD_LRS \\" >> myvmss.sh
    echo "--authentication-type SSH \\" >> myvmss.sh
    echo "--instance-count ${MySelfHosted} \\" >> myvmss.sh
    echo "--disable-overprovision \\" >> myvmss.sh
    echo "--upgrade-policy-mode manual \\" >> myvmss.sh
    echo "--single-placement-group false \\" >> myvmss.sh
    echo "--platform-fault-domain-count 1 \\" >> myvmss.sh
    echo "--load-balancer \"\"  \\" >> myvmss.sh

    if [ x${MyPrivateCluster} != xtrue ]; then
        echo "--public-ip-per-vm \\" >> myvmss.sh
    fi

    echo "--generate-ssh-keys" >> myvmss.sh
    chmod 755 myvmss.sh
    ./myvmss.sh
    echo

    # Add custom extension
    myvar=$(curl -s https://storage.googleapis.com/kubernetes-release/release/stable.txt)
    echo "az vmss extension set \\" > myvmss.sh
    echo "--publisher Microsoft.Azure.Extensions \\" >> myvmss.sh
    echo "--version 2.0 \\" >> myvmss.sh
    echo "--name CustomScript \\" >> myvmss.sh
    echo "--resource-group ${MyResGrp} \\" >> myvmss.sh
    echo "--vmss-name $mypool \\" >> myvmss.sh
    echo "--settings '{ \"commandToExecute\": \"sudo apt-get update; sudo curl -LO https://storage.googleapis.com/kubernetes-release/release/$myvar/bin/linux/amd64/kubectl; sudo chmod +x ./kubectl; sudo mv ./kubectl /usr/local/bin/kubectl; curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash\" }'" >> myvmss.sh

    chmod 755 myvmss.sh
    ./myvmss.sh
    rm -f ./myvmss.sh

fi
