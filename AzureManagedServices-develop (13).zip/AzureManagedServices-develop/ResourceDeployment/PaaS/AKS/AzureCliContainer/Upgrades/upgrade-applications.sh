#!/bin/bash
echo
echo "# -------------------------------------------------------"
echo "# Name:     Roland Balgobind"
echo "# Date:     6th March 2021"
echo "# Version:  3.0"
echo "# Comments: Upgrade various applications"
echo "#"
echo "#               o Velero Backup"
echo "#               o Velero Monitoring"
echo "#               o Kubernetes Reboot Daemon (KuRed)"
echo "#"
echo "# (c) Copyright DXC Technology, 2021. All rights reserved"
echo "# -------------------------------------------------------"
echo
TERM=vt100
export TERM

# dot-source variables and functions
. $(cd -P "$(dirname "$0")" && pwd)/../variables.sh
. $(cd -P "$(dirname "$0")" && pwd)/../mainfunctions.sh


if [ x$MySPN == xtrue ]; then
    myup="secret"
    echo -n "Enter Service Principal ID: "
    read myusername
else
    myup="password"
fi

# Main code
echo -n "Enter $myup for $myusername: "
read -rs mypassword
echo

echo -n "Enter primary key for workspace $MyAMWorkspace: "
read MyAMWorkspacekey

if [ x$MySPN == xtrue ]; then
    echo -n "Enter Velero Backup Service Principal ID : "
    read MyVeleroSP
    echo -n "Enter Velero Backup Service Principal Secret : "
    read MyVeleroSecret

    if [ x$MyAGIC == xtrue ]; then
        echo -n "Enter AGIC Service Principal ID : "
        read MyAGICSP
        echo -n "Enter AGIC Service Principal Secret : "
        read MyAGICSecret
    fi
fi

# Login to Azure
if [ x$MySPN == xtrue ]; then
	az login --service-principal -u $myusername -p $mypassword --tenant $MyTenantId
else
	az login -u $myusername -p $mypassword
fi
echo

subcheck=$(az account show --subscription ${MySubscription} --query id --output tsv)
retVal=$?
if [ $retVal -ne 0 ]; then
   echo " +--------------------------------------------------------+"
   echo " |       Subscription could not be found. Exiting...      |"
   echo " +--------------------------------------------------------+"
   echo
   exit $retVal
fi

echo
az account set --subscription ${MySubscription}
az aks get-credentials --resource-group $MyResGrp --name $MyClusterName --admin --overwrite-existing

# Install extension
az extension add --name azure-devops

# Check tags
tagmanaged=dxcManaged
tagmonitored=dxcMonitored
tagbackup=dxcBackup
tagendpoint=dxcEPAgent
tagpolicy=dxcAKSPolicy
myrandom=$(cat /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 32 | head -n 1)

# Subscrption tags
myresourceid=$(az account show --subscription ${MySubscription} --query id -o tsv)
az tag list --resource-id /subscriptions/${myresourceid} -o yaml | sed -n '/tags:/,/resourceGroup:/p' | sed '1d;$d' > /tmp/$myrandom.txt

# Resource group tags
myresourceid=$(az group show -g ${MyResGrp} --query id -o tsv)
az tag list --resource-id ${myresourceid} -o yaml | sed -n '/tags:/,/resourceGroup:/p' | sed '1d;$d' >> /tmp/$myrandom.txt

# Node Resource tags
mynoderesgrp=$(az aks show -n ${MyClusterName} -g ${MyResGrp} --query nodeResourceGroup -o tsv)
myresourceid=$(az vmss list --resource-group $mynoderesgrp --query [].id -o tsv)
az tag list --resource-id ${myresourceid} -o yaml | sed -n '/tags:/,/resourceGroup:/p' | sed '1d;$d' >> /tmp/$myrandom.txt

# Resource tags
myresourceid=$(az aks show -g ${MyResGrp} -n ${MyClusterName} --query id -o tsv)
az tag list --resource-id ${myresourceid} -o yaml | sed -n '/tags:/,/resourceGroup:/p' | sed '1d;$d' >> /tmp/$myrandom.txt

mymanaged=$(cat /tmp/$myrandom.txt | grep -w $tagmanaged | tail -1 | awk '{print $2}' | cut -f2 -d\')
mybackup=$(cat /tmp/$myrandom.txt | grep -w $tagbackup | tail -1 | awk '{print $2}' | cut -f2 -d\')
mypolicy=$(cat /tmp/$myrandom.txt | grep -w $tagpolicy | tail -1 | awk '{print $2}' | cut -f2 -d\')
mymonitored=$(cat /tmp/$myrandom.txt | grep -w $tagmonitored | tail -1 | awk '{print $2}' | cut -f2 -d\')
mydefender=$(cat /tmp/$myrandom.txt | grep -w $tagendpoint | tail -1 | awk '{print $2}' | cut -f2 -d\')

#
#  Velero Backup and Restore
#
if [ x$mybackup != xfalse ] && [ x$mymanaged != xfalse ]; then
    mycurrent=$(velero version | tail -1 | awk '{print $2}')
    myupgrade=$(echo ${linuxTarball} | cut -f8 -d/)
    if [ x${mycurrent} != x${myupgrade} ]; then
        echo "+-------------------------------------------------------------+"
        echo "|                  Velero Backup and Restore                  |"
        echo "+-------------------------------------------------------------+"
        # Deploy Velero Backup Solution
        echo
        echo "Deploy Velero Backup Solution"
        echo "-----------------------------"
        myvelero=$(echo ${linuxTarball} | cut -f8 -d/)
        wget ${linuxTarball}
        tar zxf velero-v*.tar.gz
        rm -f velero-v*.tar.gz
        yes | cp velero-${myvelero}-linux-amd64/velero /usr/sbin

        # Create the SPN if not deployed using an SPN
        if [ x${MySPN} == xtrue ]; then
            myveleromidsp=${MyVeleroSP}
            myveleromidsecret=${MyVeleroSecret}
        else
            myveleromidsp=${MyClusterName}velerosp
            myapp=$(az ad app list --display-name  ${MyClusterName}velerosp --query [].appId -o tsv)
            if [ x$myapp != x ]; then
                DXCRandomNo=$(shuf -i 1-10000 -n 1)
                myveleromidsecret=$(az ad sp credential reset \
                --append \
                --name ${MyClusterName}velerosp \
                --years 1 \
                --credential-description "VELERO${DXCRandomNo}" \
                --query password -o tsv)
            else
                myveleromidsecret=$(az ad sp create-for-rbac --name ${myveleromidsp} --role "Contributor" --query 'password' --output tsv)
                myveleromidsecret=$(az ad sp credential reset --name ${myveleromidsp} --years 1 --credential-description "VeleroSecret" --query password -o tsv)
            fi
            myveleromidsp=$(az ad sp list --display-name ${myveleromidsp} --query [0].appId --output tsv)
            sleep 30
        fi

        # Update Velero Backup Solution
        echo "Updating Velero Backup Solution"
        velero install --crds-only --dry-run -o yaml | kubectl apply -f -
        kubectl set image deployment/velero \
            velero=velero/velero:${myvelero} \
            --namespace velero
        kubectl set image daemonset/restic \
            restic=velero/velero:${myvelero} \
            --namespace velero

        # Update Velero plugin
        mycheck=$(kubectl describe deployment.apps/velero -n velero | grep $veleroplugin | grep Image | grep plugin | cut -f3 -d:)
        if [ x${mycheck} == x ]; then
            velero plugin remove velero/velero-plugin-for-microsoft-azure:${oldveleroplugin}
            velero plugin add velero/velero-plugin-for-microsoft-azure:${veleroplugin}
        fi

        sleep 20
        echo
        echo "Velero Backup updated"
        echo "---------------------"
        velero version
        echo

        if [ x$mymonitored != xfalse ]; then
            # Updating Velero Monitoring Solution
            echo
            echo "Updating Velero Monitoring Solution"
            echo "-----------------------------------"
            echo "Removing old version ..."
            kubectl delete deployment.apps/velero-monitor -n dxc-maint-ns
            kubectl delete secret velero-monitor -n dxc-maint-ns
            sleep 5
            kubectl get all -n dxc-maint-ns
            docker rmi -f veleroimg > /dev/null 2>&1

            # Set current working directory
            mycurdir=$(pwd)
            cd /root

            # Call function
            veleromonitoringfunction
        fi
    fi
fi
rm -f /tmp/$myrandom.txt

#
#  Kubernetes reboot daemon
#
echo "+-------------------------------------------------------------+"
echo "|              Kubernetes Reboot Daemon (KuRed)               |"
echo "+-------------------------------------------------------------+"
# Call function
kuredinstall
