#!/bin/bash
echo
echo "# -------------------------------------------------------"
echo "# Name:     Roland Balgobind"
echo "# Date:     18th January 2021"
echo "# Version:  1.0"
echo "# Comments: FEATURE UPDATE"
echo "#           Add Auth IP Ranges to an existing AKS Cluster"
echo "#"
echo "# (c) Copyright DXC Technology, 2021. All rights reserved"
echo "# -------------------------------------------------------"
echo

. $(cd -P "$(dirname "$0")" && pwd)/../variables.sh

# If not running a Private Cluster
if [ x${MyPrivateCluster} != xtrue ]; then

    if [ x$MySPN == xtrue ]; then
        myup="secret"
        echo -n "Enter Service Principal ID: "
        read myusername
    else
        myup="password"
    fi

    # Main code
    echo -n "Enter $myup for $myusername: "
    read -rs mypassword
    echo

    # Login to Azure
    if [ x$MySPN == xtrue ]; then
	    az login --service-principal -u $myusername -p $mypassword --tenant $MyTenantId
    else
	    az login -u $myusername -p $mypassword
    fi
    echo
    az account set --subscription ${MySubscription}
    az aks get-credentials --resource-group $MyResGrp --name $MyClusterName --admin --overwrite-existing

    # Add Authorized ranges to non-private clusters
    az aks update \
    --resource-group ${MyResGrp} \
    --name ${MyClusterName} \
    --api-server-authorized-ip-ranges ${MyAuthRange}
fi

