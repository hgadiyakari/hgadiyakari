#!/bin/bash
echo
echo "+-----------------------------------------------------------+"
echo "|  Name     : Roland Balgobind                              |"
echo "|  Date     : 27th April 2021                               |"
echo "|  Version  : 1.0                                           |"
echo "|  Comments : FEATURE UPDATE                                |" 
echo "|             Adds an App Gateway Ingress Controller        |"
echo "|                                                           |"
echo "|  (c) Copyright DXC Technology, 2021. All rights reserved  |"
echo "+-----------------------------------------------------------+"
echo

. $(cd -P "$(dirname "$0")" && pwd)/../variables.sh
. $(cd -P "$(dirname "$0")" && pwd)/../mainfunctions.sh

if [ x${MyAGIC} == xtrue ]; then

    if [ x$MySPN == xtrue ]; then
        myup="secret"
        echo -n "Enter Service Principal ID: "
        read myusername
    else
        myup="password"
    fi

    # Main code
    echo -n "Enter $myup for $myusername: "
    read -rs mypassword
    echo

    # Login to Azure
    if [ x$MySPN == xtrue ]; then
	    az login --service-principal -u $myusername -p $mypassword --tenant $MyTenantId
    else
	    az login -u $myusername -p $mypassword
    fi
    echo
    az account set --subscription ${MySubscription}
    az aks get-credentials --resource-group $MyResGrp --name $MyClusterName --admin --overwrite-existing

    # Call function
    agicconfigure

fi

