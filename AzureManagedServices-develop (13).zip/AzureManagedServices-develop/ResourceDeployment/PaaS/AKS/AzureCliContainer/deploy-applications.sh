#!/bin/bash
echo
echo "+-----------------------------------------------------------+"
echo "|  Name     : Roland Balgobind                              |"
echo "|  Date     : 6th May 2021                                  |"
echo "|  Version  : 11.0                                          |"
echo "|  Comments : Deploy various applications                   |"
echo "|                                                           |"
echo "|               o Velero Backup                             |"
echo "|               o Kubernetes Reboot Daemon (KuRed)          |"
echo "|               o CoreDNS (Forwarder)                       |"
echo "|               o Test Harness (validates build)            |"
echo "|                                                           |"
echo "|  (c) Copyright DXC Technology, 2021. All rights reserved  |"
echo "+-----------------------------------------------------------+"
echo
TERM=vt100
export TERM

# dot-source variables and functions
. ./variables.sh
. ./mainfunctions.sh

# Main code
if [ x$MySPN == xtrue ]; then
    myup="secret"
    echo -n "Enter Service Principal ID: "
    read myusername
else
    myup="password"
fi

echo -n "Enter $myup for $myusername: "
read -rs mypassword
echo

echo -n "Enter primary key for workspace $MyAMWorkspace: "
read MyAMWorkspacekey

if [ x$MySPN == xtrue ]; then
    echo -n "Enter Velero Backup Service Principal ID : "
    read MyVeleroSP
    echo -n "Enter Velero Backup Service Principal Secret : "
    read MyVeleroSecret
fi

# Login to Azure
if [ x$MySPN == xtrue ]; then
    az login --service-principal -u $myusername -p $mypassword --tenant $MyTenantId
else
    az login -u $myusername -p $mypassword
fi
echo

subcheck=$(az account show --subscription ${MySubscription} --query id --output tsv)
retVal=$?
if [ $retVal -ne 0 ]; then
    echo " +--------------------------------------------------------+"
    echo " |       Subscription could not be found. Exiting...      |"
    echo " +--------------------------------------------------------+"
    echo
   exit $retVal
fi

echo
az account set --subscription ${MySubscription}
az aks get-credentials --resource-group $MyResGrp --name $MyClusterName --admin --overwrite-existing

# Install extension
az extension add --name azure-devops

# Check tags
tagmanaged=dxcManaged
tagmonitored=dxcMonitored
tagbackup=dxcBackup
tagendpoint=dxcEPAgent
tagpolicy=dxcAKSPolicy
myrandom=$(cat /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 32 | head -n 1)

# Subscrption tags
myresourceid=$(az account show --subscription ${MySubscription} --query id -o tsv)
az tag list --resource-id /subscriptions/${myresourceid} -o yaml | sed -n '/tags:/,/resourceGroup:/p' | sed '1d;$d' > /tmp/$myrandom.txt

# Resource group tags
myresourceid=$(az group show -g ${MyResGrp} --query id -o tsv)
az tag list --resource-id ${myresourceid} -o yaml | sed -n '/tags:/,/resourceGroup:/p' | sed '1d;$d' >> /tmp/$myrandom.txt

# Node Resource tags
mynoderesgrp=$(az aks show -n ${MyClusterName} -g ${MyResGrp} --query nodeResourceGroup -o tsv)
myresourceid=$(az vmss list --resource-group $mynoderesgrp --query [].id -o tsv)
az tag list --resource-id ${myresourceid} -o yaml | sed -n '/tags:/,/resourceGroup:/p' | sed '1d;$d' >> /tmp/$myrandom.txt

# Resource tags
myresourceid=$(az aks show -g ${MyResGrp} -n ${MyClusterName} --query id -o tsv)
az tag list --resource-id ${myresourceid} -o yaml | sed -n '/tags:/,/resourceGroup:/p' | sed '1d;$d' >> /tmp/$myrandom.txt

mymanaged=$(cat /tmp/$myrandom.txt | grep -w $tagmanaged | tail -1 | awk '{print $2}' | cut -f2 -d\')
mybackup=$(cat /tmp/$myrandom.txt | grep -w $tagbackup | tail -1 | awk '{print $2}' | cut -f2 -d\')
mypolicy=$(cat /tmp/$myrandom.txt | grep -w $tagpolicy | tail -1 | awk '{print $2}' | cut -f2 -d\')
mymonitored=$(cat /tmp/$myrandom.txt | grep -w $tagmonitored | tail -1 | awk '{print $2}' | cut -f2 -d\')
mydefender=$(cat /tmp/$myrandom.txt | grep -w $tagendpoint | tail -1 | awk '{print $2}' | cut -f2 -d\')

#
#  Velero Backup and Restore
#
if [ x$mybackup != xfalse ] && [ x$mymanaged != xfalse ]; then

    echo "+-------------------------------------------------------------+"
    echo "|                  Velero Backup and Restore                  |"
    echo "+-------------------------------------------------------------+"
    # Deploy Velero Backup Solution
    echo "Deploy Velero Backup Solution"
    myvelero=$(echo ${linuxTarball} | cut -f8 -d/)
    wget ${linuxTarball}
    tar zxf velero-v*.tar.gz
    rm -f velero-v*.tar.gz
    yes | cp velero-${myvelero}-linux-amd64/velero /usr/sbin

    MyNewResGrp=$(az aks show --resource-group $MyResGrp --name $MyClusterName --query nodeResourceGroup --output tsv)

    # Checking for resource group
    mycheck=$(az group exists --name ${MyVeleroResGrp} --subscription ${MySubscription})
    if [ x$mycheck == xtrue ]; then
        echo
        echo " INFO : ${MyVeleroResGrp} resource group already exists"
        echo
    else
        # create velero resource group
        az group create --location ${MyLocation} --name ${MyVeleroResGrp}
        # az group update --name ${MyVeleroResGrp} --tags ${MyClusterTags}

        # create storage account
        az storage account create --name ${MyVeleroStrgAcct} --resource-group ${MyVeleroResGrp} --location ${MyLocation} --kind StorageV2 --sku Standard_LRS --encryption-services blob --https-only true --access-tier Hot

        # create blob container
        az storage container create --name ${MyVeleroBlob} --public-access off --account-name ${MyVeleroStrgAcct}
    fi

    # Create the SPN if not deployed using an SPN
    if [ x${MySPN} == xtrue ]; then
        myveleromidsp=${MyVeleroSP}
        myveleromidsecret=${MyVeleroSecret}
    else
        myveleromidsp=${MyClusterName}velerosp
        myapp=$(az ad app list --display-name  ${MyClusterName}velerosp --query [].appId -o tsv)
        if [ x$myapp != x ]; then
            DXCRandomNo=$(shuf -i 1-10000 -n 1)
            myveleromidsecret=$(az ad sp credential reset \
            --append \
            --name ${MyClusterName}velerosp \
            --years 1 \
            --credential-description "VELERO${DXCRandomNo}" \
            --query password -o tsv)
        else
            myveleromidsecret=$(az ad sp create-for-rbac --name ${myveleromidsp} --role "Contributor" --query 'password' --output tsv)
            myveleromidsecret=$(az ad sp credential reset --name ${myveleromidsp} --years 1 --credential-description "VeleroSecret" --query password -o tsv)
        fi
        myveleromidsp=$(az ad sp list --display-name ${myveleromidsp} --query [0].appId --output tsv)
        sleep 30
    fi

    # Call Velero backup function
    velerobackupfunction

    # Set current working directory
    mycurdir=$(pwd)
    cd /root

    # Enabling monitoring
    if [ x$mymonitored != xfalse ]; then
        # +-------------------------------------------------------------+
        # |                      Velero Monitoring                      |
        # +-------------------------------------------------------------+
        # Call Velero monitoring function
        kubectl create ns dxc-maint-ns > /dev/null 2>&1
        veleromonitoringfunction

        # Apply Network Policies
        echo "Applying Network Policies"

        echo "apiVersion: networking.k8s.io/v1" > deny-all.yaml
        echo "kind: NetworkPolicy" >> deny-all.yaml
        echo "metadata:" >> deny-all.yaml
        echo "  name: deny-all-ingress" >> deny-all.yaml
        echo "  namespace: dxc-maint-ns" >> deny-all.yaml
        echo "spec:" >> deny-all.yaml
        echo "  podSelector: {}" >> deny-all.yaml
        echo "  policyTypes:" >> deny-all.yaml
        echo "  - Ingress" >> deny-all.yaml

        kubectl create -f deny-all.yaml
        rm -f deny-all.yaml

        echo "apiVersion: networking.k8s.io/v1" > velero-access.yaml
        echo "kind: NetworkPolicy" >> velero-access.yaml
        echo "metadata:" >> velero-access.yaml
        echo "  name: veleromonnetpolicy" >> velero-access.yaml
        echo "  namespace: dxc-maint-ns" >> velero-access.yaml
        echo "spec:" >> velero-access.yaml
        echo "  podSelector:" >> velero-access.yaml
        echo "    matchLabels:" >> velero-access.yaml
        echo "      app: velero-monitor" >> velero-access.yaml
        echo "  policyTypes:" >> velero-access.yaml
        echo "  - Egress" >> velero-access.yaml
        echo "" >> velero-access.yaml
        echo "  egress:" >> velero-access.yaml
        echo "  - to:" >> velero-access.yaml
        echo "    ports:" >> velero-access.yaml
        echo "    - protocol: TCP" >> velero-access.yaml
        echo "      port: 8085" >> velero-access.yaml
        echo "    - protocol: UDP" >> velero-access.yaml
        echo "      port: 53" >> velero-access.yaml
        echo "    - protocol: TCP" >> velero-access.yaml
        echo "      port: 80" >> velero-access.yaml
        echo "    - protocol: TCP" >> velero-access.yaml
        echo "      port: 443" >> velero-access.yaml

        kubectl create -f velero-access.yaml
        rm -f velero-access.yaml
    fi
fi
rm -f /tmp/$myrandom.txt

# Set current working directory
cd ${mycurdir}


#
#  Kubernetes reboot daemon
#
echo "+-------------------------------------------------------------+"
echo "|              Kubernetes Reboot Daemon (KuRed)               |"
echo "+-------------------------------------------------------------+"
# Call function
kuredinstall


#
#  CoreDNS
#
if [ x${MyCoreDNSDomain} != xdisabled ] && [ x${MyCoreDNSForwarderIp} != xdisabled ]; then
    echo "+-------------------------------------------------------------+"
    echo "|                     Core DNS Forwarding                     |"
    echo "+-------------------------------------------------------------+"
    # Call function
    corednsconfigure
fi


#
#  Test Harness
#
echo
echo "+-------------------------------------------------------------+"
echo "|              Test Harness (build validation)                |"
echo "+-------------------------------------------------------------+"
echo "Please wait..."
sleep 30

# Validating Build
echo
echo "+---------------------------------------------+"
echo "|            Validating AKS Build             |"
echo "+---------------------------------------------+"
mycheck=$(kubectl get nodes | grep -v NotReady | grep Ready | wc -l)
if [ "x$mycheck" != "x${MyNodeCount}" ]; then
    echo "FAILED:  AKS deployment - check logs"
else
    echo "SUCCESSFUL:  AKS deployment"
fi

# Validating ACR
echo
echo "+---------------------------------------------+"
echo "|               Validating ACR                |"
echo "+---------------------------------------------+"
# Wait for ACR or timeout
for i in {1..5}; do
    mycheck=$(az acr list --resource-group ${MyACRResGrp} --subscription ${MySubscription} --query "[].{acrLoginServer:loginServer}" --output table | grep ${MyACRName}.azurecr.io)
    if [ "x$mycheck" == x ]; then
        sleep 60
    fi
done

mycheck=$(az acr list --subscription ${MySubscription} -o table | grep -w ${MyACRResGrp} | grep -w ${MyACRName}.azurecr.io | awk '{print $1}')
if [ "x$mycheck" == "x" ]; then
    echo "FAILED:  ACR deployment - check logs"
else
    echo "SUCCESSFUL:  ACR deployment"
fi

# Validating DXC ACR
echo
echo "+---------------------------------------------+"
echo "|             Validating DXC ACR              |"
echo "+---------------------------------------------+"
for i in {1..5}; do
    mycheck=$(az acr list --subscription ${MySubscription} -o table | grep -w ${MyDXCGenResGrp} | grep -w ${MyDXCACRName}.azurecr.io | awk '{print $1}')
    if [ "x$mycheck" == x ]; then
        sleep 60
    fi
done

mycheck=$(az acr list --subscription ${MySubscription} -o table | grep -w ${MyDXCGenResGrp} | grep -w ${MyDXCACRName}.azurecr.io | awk '{print $1}')
if [ "x$mycheck" == "x" ]; then
    echo "FAILED:  DXC ACR deployment - check logs"
else
    echo "SUCCESSFUL:  DXC ACR deployment"
fi

# Validating KuReD
echo
echo "+---------------------------------------------+"
echo "|              Validating KuReD               |"
echo "+---------------------------------------------+"
mycheck=$(kubectl get pod -n kube-system | grep kured | grep "1/1" | head -1 | awk '{print $1}')
if [ "x$mycheck" == x ]; then
    echo "FAILED:  KuReD deployment - check logs"
else
    echo "SUCCESSFUL:  KuReD deployment"
fi
echo

# Validating CoreDNS
if [ ${MyCoreDNSDomain} != disabled ] && [ ${MyCoreDNSForwarderIp} != disabled ]; then
    echo
    echo "+---------------------------------------------+"
    echo "|            Validating CoreDNS               |"
    echo "+---------------------------------------------+"
    mycheck=$(kubectl get configmaps --namespace=kube-system coredns-custom -o yaml | grep ${MyCoreDNSDomain} | head -1 | awk '{print $1}')
    if [ "x$mycheck" == x ]; then
        echo "FAILED:  CoreDNS configuration - check logs"
    else
        echo "SUCCESSFUL:  CoreDNS configuration"
    fi
fi
echo

# Validating Velero Backup and Monitoring
if [ x$mybackup != xfalse ] && [ x$mymanaged != xfalse ]; then
    echo "+---------------------------------------------+"
    echo "|          Validating Velero Backup           |"
    echo "+---------------------------------------------+"

    # Wait for Running process or timeout
    for i in {1..10}; do
            mycheck=$(kubectl get pod -n velero | grep velero | grep Running | awk '{print $3}')
        if [ "x$mycheck" == x ]; then
            sleep 30
        else
            break
        fi
    done

    mycheck=$(kubectl get pod -n velero | grep velero | grep Running | awk '{print $3}')
    if [ "x$mycheck" == "x" ]; then
        echo "FAILED:  Velero backup deployment - check logs"
    else
        echo "SUCCESSFUL:  Velero backup deployment"
    fi

    # Wait for Running process or timeout
    if [ x$mymonitored != xfalse ] && [ x$mymanaged != xfalse ]; then
        for i in {1..10}; do
            mycheck=$(kubectl get pod -n dxc-maint-ns | grep velero-monitor | grep Running | awk '{print $3}')
            if [ "x$mycheck" == x ]; then
                sleep 30
            else
                break
            fi
        done

        mycheck=$(kubectl get pod -n dxc-maint-ns | grep velero-monitor | grep Running | awk '{print $3}')
        if [ "x$mycheck" == "x" ]; then
            echo "FAILED:  Velero monitoring - check logs"
        else
            echo "SUCCESSFUL:  Velero monitoring"
        fi
        echo
    fi
fi

