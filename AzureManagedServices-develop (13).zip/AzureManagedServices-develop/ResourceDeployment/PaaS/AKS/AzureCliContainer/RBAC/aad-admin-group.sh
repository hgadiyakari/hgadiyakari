#!/bin/bash
echo
echo "+-----------------------------------------------------------+"
echo "|  Name     : Roland Balgobind                              |"
echo "|  Date     : 24th March 2021                               |"
echo "|  Version  : 17.0                                          |"
echo "|  Comments : Enable AAD administrator access to AKS        |"
echo "|                                                           |"
echo "|  (c) Copyright DXC Technology, 2021. All rights reserved  |"
echo "+-----------------------------------------------------------+"
TERM=vt100
export TERM

echo "+-----------------------------------------------------------+"
echo "|  This script is no longer required. An Azure AAD Cluster  |"
echo "|  Administrator group is now added via the Azure DevOps    |"
echo "|  AKS deployment pipeline.                                 |"
echo "+-----------------------------------------------------------+"
echo
exit

. $(cd -P "$(dirname "$0")" && pwd)/../variables.sh

if [ x$MySPN == xtrue ]; then
    myup="secret"
    echo -n "Enter Service Principal ID: "
    read myusername
else
    myup="password"
fi

# Main code
echo -n "Enter $myup for $myusername: "
read -rs mypassword
echo

# Login to Azure
if [ x$MySPN == xtrue ]; then
	az login --service-principal -u $myusername -p $mypassword --tenant $MyTenantId
else
	az login -u $myusername -p $mypassword
fi
echo
az account set --subscription ${MySubscription}
az aks get-credentials --resource-group $MyResGrp --name $MyClusterName --admin --overwrite-existing

# Obtain AKS resource Id
AKS_ID=$(az aks show \
   --resource-group ${MyResGrp} \
   --name ${MyClusterName} \
   --query id -o tsv)
echo

# Obtain the Group ID
GROUP_ID=$(az ad group show --group ${MyAadGroup} \
   --query objectId \
   --output tsv)

if [ x${GROUP_ID} == x ]; then
   echo
   echo " ERROR"
   echo " -----"
   echo " AAD Group ${MyAadGroup} must already exist"
   echo
   exit 0
fi

# Assign the role Contributor access for the Admin Group
az role assignment create --role "Contributor" \
   --assignee-object-id $GROUP_ID \
   --scope $AKS_ID

# Assign the role Contributor access for the Admin Group
az role assignment create --role "User Access Administrator" \
   --assignee-object-id $GROUP_ID \
   --scope $AKS_ID

# Create role
echo "apiVersion: rbac.authorization.k8s.io/v1" > admin-binding.yaml
echo "kind: ClusterRoleBinding" >> admin-binding.yaml
echo "metadata:" >> admin-binding.yaml
echo "  name: ${MyClusterName}-admins" >> admin-binding.yaml
echo "roleRef:" >> admin-binding.yaml
echo "  apiGroup: rbac.authorization.k8s.io" >> admin-binding.yaml
echo "  kind: ClusterRole" >> admin-binding.yaml
echo "  name: cluster-admin" >> admin-binding.yaml
echo "subjects:" >> admin-binding.yaml
echo "- apiGroup: rbac.authorization.k8s.io" >> admin-binding.yaml
echo "  kind: Group" >> admin-binding.yaml
echo "  name: ${GROUP_ID}" >> admin-binding.yaml

kubectl apply -f admin-binding.yaml
sleep 10
mv admin-binding.yaml /tmp

# Post validation
echo
echo "Validation"
echo "----------"
echo "Add an AAD Admin Account to the ${MyAadGroup} Admin group"
echo "Login via './aks-login.sh aad' specifying the username"
echo

# kubectl get clusterrolebinding ${MyClusterName}-admins -o yaml
# kubectl delete clusterrolebinding ${MyClusterName}-admins
