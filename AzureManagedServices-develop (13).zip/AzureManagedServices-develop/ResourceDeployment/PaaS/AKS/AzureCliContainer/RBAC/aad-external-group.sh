#!/bin/bash
echo
echo "+-----------------------------------------------------------+"
echo "|  Name     : Roland Balgobind                              |"
echo "|  Date     : 15th April 2021                               |"
echo "|  Version  : 9.0                                           |"
echo "|  Comments : Enable AAD support group access to AKS        |"
echo "|                                                           |"
echo "|  (c) Copyright DXC Technology, 2021. All rights reserved  |"
echo "+-----------------------------------------------------------+"
echo

TERM=vt100
export TERM

. $(cd -P "$(dirname "$0")" && pwd)/../variables.sh

if [ x$1 == x ] || [ x$2 == x ]; then
    echo "Usage: ./aad-external-group.sh [AAD Group] [Namespace]"
    echo
    exit
else
    myextaadgroup=$1
    myextns=$2
fi

if [ x$MySPN == xtrue ]; then
    myup="secret"
    echo -n "Enter Service Principal ID: "
    read myusername
else
    myup="password"
fi

# Main code
echo -n "Enter $myup for $myusername: "
read -rs mypassword
echo

# Login to Azure
if [ x$MySPN == xtrue ]; then
	az login --service-principal -u $myusername -p $mypassword --tenant $MyTenantId
else
	az login -u $myusername -p $mypassword
fi
echo
az account set --subscription ${MySubscription}
az aks get-credentials --resource-group $MyResGrp --name $MyClusterName --admin --overwrite-existing

# Obtain AKS resource Id
AKS_ID=$(az aks show \
   --resource-group ${MyResGrp} \
   --name ${MyClusterName} \
   --query id -o tsv)
echo

# Check for AAD group
GROUP_ID=$(az ad group list --display-name ${myextaadgroup} --query [0].objectId -o tsv)
if [ x${GROUP_ID} == x ]; then
   echo
   echo " ERROR"
   echo " -----"
   echo " AAD Group ${myextaadgroup} must already exist"
   echo
   exit 0
fi

# Allow members of the group access to the AKS cluster by the "Azure Kubernetes Service Cluster User Role"
az role assignment create \
  --assignee $GROUP_ID \
  --role "Azure Kubernetes Service Cluster User Role" \
  --scope $AKS_ID

# Assign the role Reader access for the Admin Group
az role assignment create --role "Reader" \
   --assignee-object-id $GROUP_ID \
   --scope $AKS_ID

# Create a namespace - should already exist
kubectl create namespace ${myextns} > /dev/null 2>&1

# Create roles file (including HPA)
echo "kind: Role" > role-dev-namespace.yaml
echo "apiVersion: rbac.authorization.k8s.io/v1beta1" >> role-dev-namespace.yaml
echo "metadata:" >> role-dev-namespace.yaml
echo "  name: ${MyClusterName}-full-${myextns}-ops-access" >> role-dev-namespace.yaml
echo "  namespace: ${myextns}" >> role-dev-namespace.yaml
echo "rules:" >> role-dev-namespace.yaml
echo "- apiGroups: [\"\", \"extensions\", \"apps\"]" >> role-dev-namespace.yaml
echo "  resources: [\"*\"]" >> role-dev-namespace.yaml
echo "  verbs: [\"*\"]" >> role-dev-namespace.yaml
echo "- apiGroups: [\"batch\"]" >> role-dev-namespace.yaml
echo "  resources:" >> role-dev-namespace.yaml
echo "  - jobs" >> role-dev-namespace.yaml
echo "  - cronjobs" >> role-dev-namespace.yaml
echo "  verbs: [\"*\"]" >> role-dev-namespace.yaml
echo "- apiGroups: [\"autoscaling\"]" >> role-dev-namespace.yaml
echo "  resources: [\"horizontalpodautoscalers\"]" >> role-dev-namespace.yaml
echo "  verbs: [\"*\"]" >> role-dev-namespace.yaml

# Apply roles
kubectl apply -f role-dev-namespace.yaml
sleep 5
mv role-dev-namespace.yaml /tmp

# Create role binding yaml file
echo "kind: RoleBinding" > rolebinding-dev-namespace.yaml
echo "apiVersion: rbac.authorization.k8s.io/v1beta1" >> rolebinding-dev-namespace.yaml
echo "metadata:" >> rolebinding-dev-namespace.yaml
echo "  name: ${MyClusterName}-full-${myextns}-ops-access" >> rolebinding-dev-namespace.yaml
echo "  namespace: ${myextns}" >> rolebinding-dev-namespace.yaml
echo "roleRef:" >> rolebinding-dev-namespace.yaml
echo "  apiGroup: rbac.authorization.k8s.io" >> rolebinding-dev-namespace.yaml
echo "  kind: Role" >> rolebinding-dev-namespace.yaml
echo "  name: ${MyClusterName}-full-${myextns}-ops-access" >> rolebinding-dev-namespace.yaml
echo "subjects:" >> rolebinding-dev-namespace.yaml
echo "- kind: Group" >> rolebinding-dev-namespace.yaml
echo "  namespace: ${myextns}" >> rolebinding-dev-namespace.yaml
echo "  name: ${GROUP_ID}" >> rolebinding-dev-namespace.yaml

# Apply role binding
kubectl apply -f rolebinding-dev-namespace.yaml
sleep 10
mv rolebinding-dev-namespace.yaml /tmp

# Clean-up and resign in
echo
echo "Validation"
echo "----------"
echo "Add an AAD Account to the ${myextaadgroup} AAD group"
echo "Login via './aks-login.sh aad' specifying the username"
echo

# az role definition list --name "Azure Kubernetes Service Cluster User Role"
# az role assignment list --scope $AKS_ID
# kubectl get role -n ${myextns} -o yaml
# kubectl get rolebinding -n ${myextns} -o yaml
