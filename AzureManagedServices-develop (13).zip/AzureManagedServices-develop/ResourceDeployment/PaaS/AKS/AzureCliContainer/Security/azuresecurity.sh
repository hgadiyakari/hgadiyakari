#!/bin/bash
echo
echo "# --------------------------------------------------------"
echo "# Name:     Roland Balgobind"
echo "# Date:     5th March 2021"
echo "# Version:  2.0"
echo "# Comments: Enable Azure Defender and Azure Policy"
echo "#           for Azure Kubernetes Service"
echo "#"
echo "# (c) Copyright DXC Technology, 2021. All rights reserved"
echo "# --------------------------------------------------------"
TERM=vt100
export TERM

. $(cd -P "$(dirname "$0")" && pwd)/../variables.sh
myscope=$(az group show -g ${MyResGrp} --query id -o tsv)

if [ x$MySPN == xtrue ]; then
    myup="secret"
    echo -n "Enter Service Principal ID: "
    read myusername
else
    myup="password"
fi

# Main code
echo -n "Enter $myup for $myusername: "
read -rs mypassword
echo

# Login to Azure
if [ x$MySPN == xtrue ]; then
    az login --service-principal -u $myusername -p $mypassword --tenant $MyTenantId
else
    az login -u $myusername -p $mypassword
fi
echo
az account set --subscription ${MySubscription}
az aks get-credentials --resource-group $MyResGrp --name $MyClusterName --admin --overwrite-existing


# ------------------------------------
# Enable Azure Defender on AKS and ACR
# ------------------------------------
MyAzureDefender="false"  # Disabled
if [ x${MyAzureDefender} == xtrue ]; then
    myarray=( KubernetesService ContainerRegistry )
    for mykey in "${myarray[@]}"
    do
       az security pricing create -n $mykey --tier 'standard' --subscription $MySubscription
    done
fi


# ------------------------------------
# Enable Azure Policies AKS and ACR
# ------------------------------------
# Policy Function - parameters
function applypolicy-params {
   mydname=${mypolicy}
   echo "#!/bin/bash" > myrun.sh
   echo "az policy assignment create \\" >> myrun.sh
   echo "-n \"${mypolicy}\" \\" >> myrun.sh
   echo "--display-name \"${mydname}\" \\" >> myrun.sh
   echo "--policy ${policyname} \\" >> myrun.sh
   echo "-p \""${myparams}\"" \\" >> myrun.sh
   echo "--scope ${myscope}" >> myrun.sh
   chmod 755 myrun.sh; ./myrun.sh; rm -f myrun.sh
}

# Policy Function - parameters
function applypolicy-action {
   if [ x${MyAzurePolicyTSize} == xalldeny ]; then
      myaction="deny"
   fi
   if [ x${MyAzurePolicyTSize} == xallaudit ]; then
      myaction="audit"
   fi
}


# -----------------------------------
#  Azure Kubernetes Service Policies
# -----------------------------------
MyAzurePolicy="false"  # Disabled
if [ x${MyAzurePolicy} == xtrue ]; then

    # Enable Azure Policy
    az aks enable-addons --addons azure-policy --resource-group ${MyResGrp} --name ${MyClusterName} --subscription ${MySubscription}

    # 1. Do not allow privileged containers in Kubernetes cluster
    mypolicy="DXC AKS Do not allow privileged containers in AKS"
    policyname="95edb821-ddaf-4404-9732-666045e056b4"
    myaction="deny"
    applypolicy-action
    myparams="{ \\\"excludedNamespaces\\\": { \\\"value\\\": [ \\\"kube-system\\\", \\\"gatekeeper-system\\\", \\\"azure-arc\\\", \\\"velero\\\", \\\"dxc-maint-ns\\\"  ] }, \\\"effect\\\": { \\\"value\\\": \\\"${myaction}\\\" } }"
    applypolicy-params

    # 2. Kubernetes clusters should not allow container privilege escalation
    mypolicy="DXC AKS Do not allow privileged escalation"
    policyname="1c6e92c9-99f0-4e55-9cf2-0c234dc48f99"
    myaction="audit"
    applypolicy-action
    myparams="{ \\\"excludedNamespaces\\\": { \\\"value\\\": [ \\\"kube-system\\\", \\\"gatekeeper-system\\\", \\\"azure-arc\\\", \\\"velero\\\", \\\"dxc-maint-ns\\\"  ] }, \\\"effect\\\": { \\\"value\\\": \\\"${myaction}\\\" } }"
    applypolicy-params

    # 3. Ensure container CPU and memory resource limits do not exceed the specified limits in Kubernetes cluster
    # 4 vCPU, 8GB memory
    mypolicy="DXC AKS CPU and memory limits do not exceed AKS limits"
    policyname="e345eecc-fa47-480f-9e88-67dcc122b164"
    myaction="deny"
    applypolicy-action
    myparams="{ \\\"excludedNamespaces\\\": { \\\"value\\\": [ \\\"kube-system\\\", \\\"gatekeeper-system\\\", \\\"azure-arc\\\", \\\"velero\\\", \\\"dxc-maint-ns\\\"  ] }, \\\"effect\\\": { \\\"value\\\": \\\"${myaction}\\\"  }, \\\""cpuLimit\\\"":{\\\""value\\\"":\\\""${mycpulimit}\\\""}, \\\""memoryLimit\\\"":{\\\""value\\\"":\\\""${mymemorylimit}\\\""} }"
    applypolicy-params

    # 4. Ensure only allowed container images in Kubernetes cluster    
    mypolicy="DXC AKS Ensure only allowed container images in AKS"
    policyname="febd0533-8e55-448f-b837-bd0e06f16469"
    myaction="deny"
    applypolicy-action
    myparams="{ \\\"excludedNamespaces\\\": { \\\"value\\\": [ \\\"kube-system\\\", \\\"gatekeeper-system\\\", \\\"azure-arc\\\", \\\"velero\\\", \\\"dxc-maint-ns\\\"  ] }, \\\"effect\\\": { \\\"value\\\": \\\"${myaction}\\\" }, \\\""allowedContainerImagesRegex\\\"":{\\\""value\\\"":\\\""^.+azurecr.io/.+$\\\""} }"
    applypolicy-params

    # 5. Kubernetes cluster containers should run with a read only root file system
    mypolicy="DXC AKS containers should run with RO root file system"
    policyname="df49d893-a74c-421d-bc95-c663042e5b80"
    myaction="audit"
    applypolicy-action
    myparams="{ \\\"excludedNamespaces\\\": { \\\"value\\\": [ \\\"kube-system\\\", \\\"gatekeeper-system\\\", \\\"azure-arc\\\", \\\"velero\\\", \\\"dxc-maint-ns\\\"  ] }, \\\"effect\\\": { \\\"value\\\": \\\"${myaction}\\\" } }"
    applypolicy-params

    # 6. Kubernetes cluster pods should only use allowed volume types
    mypolicy="DXC AKS Pods uses only allowed volume types"
    policyname="16697877-1118-4fb1-9b65-9898ec2509ec"
    myaction="audit"
    applypolicy-action
    myparams="{ \\\"excludedNamespaces\\\": { \\\"value\\\": [ \\\"kube-system\\\", \\\"gatekeeper-system\\\", \\\"azure-arc\\\", \\\"velero\\\", \\\"dxc-maint-ns\\\"  ] }, \\\"effect\\\": { \\\"value\\\": \\\"${myaction}\\\" }, \\\"allowedVolumeTypes\\\": { \\\"value\\\": [ \\\"emptyDir\\\", \\\"configMap\\\", \\\"secret\\\", \\\"persistentVolumeClaim\\\", \\\"hostPath\\\", \\\"nfs\\\", \\\"iscsi\\\", \\\"flexVolume\\\" ] } }"
    applypolicy-params

    # 7. Kubernetes cluster containers should not share host process ID or host IPC namespace
    mypolicy="DXC AKS containers should not share host process ID or IPC"
    policyname="47a1ee2f-2a2a-4576-bf2a-e0e36709c2b8"
    myaction="audit"
    applypolicy-action
    myparams="{ \\\"excludedNamespaces\\\": { \\\"value\\\": [ \\\"kube-system\\\", \\\"gatekeeper-system\\\", \\\"azure-arc\\\", \\\"velero\\\", \\\"dxc-maint-ns\\\"  ] }, \\\"effect\\\": { \\\"value\\\": \\\"${myaction}\\\" } }"
    applypolicy-params

    # 8. Ensure containers listen only on allowed ports in Kubernetes cluster
    mypolicy="DXC AKS containers listen only on allowed ports in AKS"
    policyname="440b515e-a580-421e-abeb-b159a61ddcbc"
    myaction="deny"
    applypolicy-action
    myportlist=$(echo $myallowedports | sed 's/ //g' | sed 's/,/\\", \\"/g' | sed 's/^/\\"/' | sed 's/$/\\"/')
    myparams="{ \\\"excludedNamespaces\\\": { \\\"value\\\": [ \\\"kube-system\\\", \\\"gatekeeper-system\\\", \\\"azure-arc\\\", \\\"velero\\\", \\\"dxc-maint-ns\\\"  ] }, \\\"effect\\\": { \\\"value\\\": \\\"${myaction}\\\" }, \\\""allowedContainerPortsList\\\"":{\\\""value\\\"": [ ${myportlist} ] } }"
    applypolicy-params

    # 9. Kubernetes cluster pods should only use approved host network and port range
    mypolicy="DXC AKS Pods can only use approved host network and port range"
    policyname="82985f06-dc18-4a48-bc1c-b9f4f0098cfe"
    myaction="audit"
    applypolicy-action
    myparams="{ \\\"excludedNamespaces\\\": { \\\"value\\\": [ \\\"kube-system\\\", \\\"gatekeeper-system\\\", \\\"azure-arc\\\", \\\"velero\\\", \\\"dxc-maint-ns\\\"  ] }, \\\"effect\\\": { \\\"value\\\": \\\"${myaction}\\\" }, \\\""allowHostNetwork\\\"":{\\\""value\\\"":true}, \\\""minPort\\\"":{\\\""value\\\"":${myhostportmin}}, \\\""maxPort\\\"":{\\\""value\\\"":${myhostportmax}} }"
    applypolicy-params

    # 10. Ensure services listen only on allowed ports in Kubernetes cluster
    mypolicy="DXC AKS services listen on allowed ports in AKS"
    policyname="233a2a17-77ca-4fb1-9b6b-69223d272a44"
    myaction="deny"
    applypolicy-action
    myportlist=$(echo $myallowedsvcports | sed 's/ //g' | sed 's/,/\\", \\"/g' | sed 's/^/\\"/' | sed 's/$/\\"/')
    myparams="{ \\\"excludedNamespaces\\\": { \\\"value\\\": [ \\\"kube-system\\\", \\\"gatekeeper-system\\\", \\\"azure-arc\\\", \\\"velero\\\", \\\"dxc-maint-ns\\\"  ] }, \\\"effect\\\": { \\\"value\\\": \\\"${myaction}\\\" }, \\\""allowedServicePortsList\\\"":{\\\""value\\\"": [ ${myportlist} ] } }"
    applypolicy-params

    # 11. Kubernetes clusters should be accessible only over HTTPS
    mypolicy="DXC AKS Cluster should be accessible only over HTTPS"
    policyname="1a5b4dca-0b6f-4cf5-907c-56316bc1bf3d"
    myaction="deny"
    applypolicy-action
    myparams="{ \\\"excludedNamespaces\\\": { \\\"value\\\": [ \\\"kube-system\\\", \\\"gatekeeper-system\\\", \\\"azure-arc\\\", \\\"velero\\\", \\\"dxc-maint-ns\\\"  ] }, \\\"effect\\\": { \\\"value\\\": \\\"${myaction}\\\" } }"
    applypolicy-params


    # -----------------------------------
    #  Azure Container Registry Policies
    # -----------------------------------
    # Container registries should use private link
    # Private Clusters ONLY
    # DISABLED
    MyPrivateCluster="false"
    if [ x${MyPrivateCluster} == xtrue ]; then
        mypolicy="DXC AKS ACR use Private Links"
        policyname="e8eef0a8-67cf-4eb4-9386-14b0e78733d4"
        mydname="DXC AKS ACR use Private Links"
        applypolicy-params
    fi

    # Container registries should not allow unrestricted network access
    if [ x${MyPrivateCluster} == xtrue ]; then
        mypolicy="DXC AKS ACR restricted network access"
        policyname="d0793b48-0edc-4296-a390-4c75d1bdfd71"
        mydname="DXC AKS ACR restricted network access"
        applypolicy-params
    fi
fi


# Removed until enablement of custom Policies
# -------------------------------------------
    # Enforce labels on pods in Kubernetes cluster
    # mypolicy="DXC AKS enforces Pod labels"
    # policyname="46592696-4c7b-4bf3-9e45-6c2763bdc0a6"
    # mydname="DXC AKS enforces Pod labels"
    # mylabellist=$(echo $myallowedlabels | sed 's/ //g' | sed 's/,/\\", \\"/g' | sed 's/^/\\"/' | sed 's/$/\\"/')
    # myparams="{ \\\"labelsList\\\": { \\\"value\\\": [ ${mylabellist} ] } }"
    # applypolicy-params


# Removed until out of preview
# -------------------------------------------
# https://docs.microsoft.com/en-us/azure/aks/enable-host-encryption
    # Temp disks and cache for agent node pools in Azure Kubernetes Service clusters should be encrypted at host
    # mypolicy="DXC AKS Temp disks and cache encrypted"
    # policyname="41425d9f-d1a5-499a-9932-f8ed8453932c"
    # mydname="DXC AKS Temp disks and cache encrypted"
    # applypolicy-params
