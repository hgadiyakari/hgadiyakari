#!/bin/bash

# -------------------------------------------------------
# Name:     Roland Balgobind
# Date:     20th May 2020
# Version:  3.0
# Comments: Deploy an AKS management container
#
# (c) Copyright DXC Technology, 2020. All rights reserved
# -------------------------------------------------------

if [ x$1 == x ]; then
   echo; echo " Usage ./build-azcli-container.sh [Container Name]"; echo
   exit
else
   mycntr=$1
fi

echo
echo " Clearing up current docker environment ..."
echo
read -p "  < Return to continue ... >"
echo

docker kill $mycntr > /dev/null 2>&1
docker rm $mycntr > /dev/null 2>&1
docker rmi ${mycntr}img > /dev/null 2>&1

# +------------------------------------------+
# | BUILD CONTAINER  NODE                    |
# +------------------------------------------+
docker build -f azuredevops.yaml --rm --no-cache -t ${mycntr}img .
docker run \
--privileged \
--name $mycntr \
--hostname $mycntr \
--restart always \
-v /sys/fs/cgroup:/sys/fs/cgroup:ro \
-itd ${mycntr}img

docker exec $mycntr /config.sh

# +------------------------------------------+
# | CONNECT TO CONTAINER                     |
# +------------------------------------------+
docker exec -it $mycntr bash

exit

# Clean-up
docker kill $(docker ps -a -q)
docker rm $(docker ps -a -q)
docker rmi $(docker images -a -q)
