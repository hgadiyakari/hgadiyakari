#!/bin/bash
echo
echo "# -------------------------------------------------------"
echo "# Name:     Roland Balgobind"
echo "# Date:     10th November 2020"
echo "# Version:  2.0"
echo "# Comments: This script has been created to compliment"
echo "#           the Azure DevOps pipeline for upgrading the"
echo "#           AKS Cluster to the latest DXC support version"
echo "#"
echo "# (c) Copyright DXC Technology, 2020. All rights reserved"
echo "# -------------------------------------------------------"
echo

. ./variables.sh

if [ x$MySPN == xtrue ]; then
    myup="secret"
    echo -n "Enter Service Principal ID: "
    read myusername
else
    myup="password"
fi

# Main code
echo -n "Enter $myup for $myusername: "
read -rs mypassword
echo

# Login to Azure
if [ x$MySPN == xtrue ]; then
	az login --service-principal -u $myusername -p $mypassword --tenant $MyTenantId
else
	az login -u $myusername -p $mypassword
fi
echo
az account set --subscription ${MySubscription}
az aks get-credentials --resource-group $MyResGrp --name $MyClusterName --admin --overwrite-existing

echo "--------------"
echo "Latest version"
echo "--------------"
kubectl get node | grep agent | awk '{print $5}' | head -1
echo

echo "-----------------------"
echo "Current upgrade options"
echo "-----------------------"
myopts=`az aks get-upgrades --resource-group $MyResGrp --name $MyClusterName | grep kubernetesVersion | sed -n '1!p' | cut -f 4 -d\"`
echo $myopts | sed s/" "/"\n"/g
echo

read -p "Enter upgrade value: " ans
echo
if [[ $myopts =~ $ans ]]; then
   echo "+--------------------"
   echo "| Upgrading cluster |"
   echo "+--------------------"
   echo
   az aks upgrade --resource-group $MyResGrp --name $MyClusterName --kubernetes-version $ans
else
   echo "+----------------------------------------------------+"
   echo "| ERROR: Choose one of the available upgrade options |"
   echo "+----------------------------------------------------+"
   echo
fi
