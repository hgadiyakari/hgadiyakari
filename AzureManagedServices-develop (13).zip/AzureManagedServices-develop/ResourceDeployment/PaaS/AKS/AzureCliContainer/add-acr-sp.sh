#!/bin/bash
echo
echo "# -------------------------------------------------------"
echo "# Name:     Roland Balgobind"
echo "# Date:     21st June 2021"
echo "# Version:  7.0"
echo "# Comments: Create an ACR and SP to access an ACR."
echo "#           Also, attaches the ACR to AKS"
echo "#"
echo "# (c) Copyright DXC Technology, 2021. All rights reserved"
echo "# -------------------------------------------------------"
echo

. ./variables.sh

if [ x$MySPN == xtrue ]; then
    echo "+-----------------------------------------------------------------------------------------+"
    echo "|  A Service Principal cannot be used to add Service Principals to the ACR. Login with an |"
    echo "|  AAD user with authorisation to create an ACR and add the permissions to create a       |"
    echo "|  Service Principal.  This is likely to be Contributor and User access administrator     |"
    echo "|  role(s) at the ACR resource group scope. Together with Application Developer AAD       |"
    echo "|  privileges.                                                                            |"
    echo "|  Alternatively, ensure a Service Principal is created before running this script. This  |"
    echo "|  Service Principal MUST have Contributor role access to the ACR.                        |"
    echo "+-----------------------------------------------------------------------------------------+"
    echo -n "Enter username [$myusername]: "
    read ans
    if [ x$ans != x ]; then
        myusername=$ans
    fi
fi

echo -n "Enter password for $myusername: "
read -rs mypassword
echo

# Request an SPN name
MyACRSPname=${MyACRName}sp
echo -n "Enter existing SP or SP to be created [$MyACRSPname]: "
read ans
if [ x$ans != x ]; then
   MyACRSPname=$ans
fi

# Login to Azure
az login -u $myusername -p $mypassword
az account set --subscription ${MySubscription}
az aks get-credentials --resource-group $MyResGrp --name $MyClusterName --admin --overwrite-existing

# Generate random number
DXCRandomNo=`shuf -i 1-10000 -n 1`

# Add ACR and resource group if required
mycheck=$(az group exists --name ${MyACRResGrp})
if [ x$mycheck != xtrue ]; then
   echo "Create resrouce group"
   az group create --location ${MyLocation} --name ${MyACRResGrp} --subscription ${mysubscription}
   # az group update --name ${MyACRResGrp} --tags ${MyClusterTags}
   echo "Create ACR"
   az acr create --resource-group ${MyACRResGrp} --name ${MyACRName} --sku ${MyACRSKU}
   sleep 5
   echo "Attach ACR"
   az aks update -n ${MyClusterName} -g ${MyResGrp} --attach-acr ${MyACRName}
fi

tenantId=$(az account show --query tenantId -o tsv)
ACR_REGISTRY_ID=$(az acr show --name ${MyACRName} --query id --output tsv)
SP_APP_ID=$( az ad app list --filter "displayName eq '${MyACRSPname}'" --query [].appId -o tsv)

# Add ID and secret
if [ x$SP_APP_ID == x ]; then
   echo
   echo "+------------------------------------------------------------------------------+"
   echo "| Service Principal will be created.  To provide SP details to clients wishing |"
   echo "| to access the ACR, an ID and secret will be generated.                       |"
   echo "| This Service Principal will be given Contributor role access to the ACR.     |"
   echo "+------------------------------------------------------------------------------+"
   SP_PASSWD=$(az ad sp create-for-rbac --name ${MyACRSPname} --scopes $ACR_REGISTRY_ID --role Contributor --years 1 --query password --output tsv)
   SP_APP_ID=$(az ad app list --filter "displayName eq '${MyACRSPname}'" --query [].appId -o tsv)
else
   echo
   echo "+------------------------------------------------------------------------------+"
   echo "| Service Principal already exists.  To provide SP details to clients wishing  |"
   echo "| to access the ACR, another secret will be generated.                         |"
   echo "| ENSURE this Service Principal has Contributor role access to the ACR.        |"
   echo "+------------------------------------------------------------------------------+"
   SP_PASSWD=$(az ad sp credential reset \
   --append \
   --name ${MyACRSPname} \
   --years 1 \
   --credential-description "ACR${DXCRandomNo}" \
   --query password -o tsv)
fi
# az role assignment create --assignee http://${MyACRSPname} --role Contributor --scope $ACR_REGISTRY_ID

echo
echo "---------------------------------------------------------------"
echo "Service Principal:         ${MyACRSPname}"
echo "Client Secret:             ACR${DXCRandomNo}"
echo "---------------------------------------------------------------"

echo
echo "Service Principal ID:      $SP_APP_ID"
echo "Service Principal Secret:  $SP_PASSWD"
echo "TenantId:                  $tenantId"
echo
