#!/bin/bash
# -------------------------------------------------------
# Name:     Roland Balgobind
# Date:     10th May 2021
# Version:  13.0
# Comments: Variables used to manage an AKS Cluster
#
# (c) Copyright DXC Technology, 2021. All rights reserved
# -------------------------------------------------------
# Azure DevOps
myusername="roland@dxccsptest1.onmicrosoft.com"
myorg="myaksdevorg"
myproject="tenant1"

# Service principal installation
MySPN="true"

# Cluster
MyAMWorkspace="myworkspace"
MyAMWorkspaceid="220a1f97-xxxx-xxxx-xxxx-xxxxxxxxxxxxxxx"
MyAMWorkspaceResGrp="mymonitorresgrp"

MySubscription="43d6df49-xxxx-xxxx-xxxx-xxxxxxxxxxxxxxx"
MyTenantId="ef090f83-ff2f-4c42-a8ab-649e8b356b59"
MyResGrp="myk8sresgroup1"
MyClusterName="mycluster"
MyClusterPrefix="myk8s"
MyLocation="eastus"

MyNodeCount="3"
MyAKSPodPerNode="30"
MyNodeDiskSize="35"
MyVMSize="Standard_D2s_v3"
MyZones="1 2"

# Self hosted agents
MySelfHosted="2"

# BYO routing table - vNET in separate resource group
MyExtvNetResGrp="disabled"

# Tags - dxcConfigurationCheck set in deployment code
MyClusterTags="dxcManaged=true dxcMonitored=true dxcBackup=true myk8sclustertag=mycluster1"
MyNodePoolsTags="dxcManaged=true dxcMonitored=true myk8snodepooltag=nodepool1"

# DXC Generic resource group
MyDXCGenResGrp="myk8sdxcgenresgrp"

# Generic Networking
MyCNIEnabled="true"
MyVnetExists="false"
MyVnetName="myAKSVnet"
MyVnetSubnetName="myAKSSubnet"
MyPolicy="calico"
MyDockerBrdgAddr="172.17.0.1/16"
MyAKSVnetCIDR="10.0.0.0/16"
MyAKSVnetDNSIP="10.0.0.10"
MyAKSVnetSubnet="10.8.0.0/16"
MyAKSVnetwork="10.0.0.0/12"
MyAuthRange="93.97.0.0/16,51.145.14.119,20.32.21.91"

# Private Cluster Only
MyPrivateCluster="false"
MyDeployValidationVMs="both"
MyNSGSourceCIDR="93.97.0.0/16"
MyUserVnet="myk8svnetusers"
MyUserResGrp="myk8susersresgrp"
MyUserVnetCIDR="10.100.0.0/16"
MyUserSnetName="myk8suserssubnet"
MyUserSubnet="10.100.100.0/24"
MyMgMtSnetName="myk8smgmntsubnet"
MyMgMtSubnet="10.100.110.0/28"

# Private Links Only
MyPrivLinkSubnet="10.10.1.0/27"

# Kubenet Network Only
MyAKSPodCIDR="10.244.0.0/16"

# CoreDNS
MyCoreDNSDomain="disabled"
MyCoreDNSForwarderIp="disabled"

# App Gateway
MyAGIC="false"
MyWAFStd="WAF_v2"
MyAGICSubnetPrefix="10.11.0.0/24"
MyAGICSubnet="myk8agicsubnet"

# Heptio Velero
linuxTarball="https://github.com/vmware-tanzu/velero/releases/download/v1.6.0/velero-v1.6.0-linux-amd64.tar.gz"
MyVeleroResGrp="myk8sveleroresgrp"
MyVeleroStrgAcct="myk8sstrgaccount"
MyVeleroBlob="myk8scontainer"
MyVeleroSKU="Standard_LRS"

# Autoscaler
MyAutoscalerEnabled="true"
MyASMin="3"
MyASMax="10"

# AAD Integration - Admin
MyAadGroup="DXCAKSAdminGroup"

# AAD Integration - Customer/support
mycustomeraad="dxccsptest1.onmicrosoft.com"
myaadclientgroup="DXCClientGroup"
myextaadgroup="DXCExtOpsGroup"
myclientns="tenant1ns"
myextns="tenant1ns"

# Azure Container Registry (Premium for private links)
MyACREnabled="true"
MyACRResGrp="myk8sacrresgroup"
MyACRName="myk8sclusteracr"
MyACRSKU="Premium"

# DXC Azure Container Registry (Premium for private links)
MyDXCACRName="myk8sclusterdxcacr"
MyDXCACRSKU="Basic"

# Kured
MyKuredVersion="1.6.1"
MyKuredRebootdays="sun,sat"
MyKuredStarttime="0:00"
MyKuredEndtime="3:00"
MyKuredPeriod="1h"
MyKuredTZ="UTC"


# -------------------------------------------------------------------------------------------
# NOT CURRENTLY AVAILABLE
# -------------------------------------------------------------------------------------------
# Azure Policy for AKS
MyAzurePolicy="false"
# 3 sizes available default, alldeny, allaudit
MyAzurePolicyTSize="default"
# DXC AKS CPU and memory limits
mycpulimit="4200m"
mymemorylimit="8200Mi"
# Ensure containers listen only on allowed ports in Kubernetes cluster
# 8085 is required for Velero Backup
myallowedports="8085, 443, 80"
# Kubernetes cluster pods should only use approved host network and port range
myhostportmin="1024"
myhostportmax="49151"
# Ensure services listen only on allowed ports in Kubernetes cluster
myallowedsvcports="443, 80"

# Azure Defender for AKS
MyAzureDefender="false"

