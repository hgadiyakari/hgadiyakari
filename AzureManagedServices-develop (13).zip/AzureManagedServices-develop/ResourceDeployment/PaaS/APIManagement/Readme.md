# API Management

This folder contains the powershell scripts, json ARM template and function app used to deploy API Managemment Instance within DXC Azure Managed Services.

# Pre-requisites

* Make sure the service principal/user account used to connect to the subscription has relevenat access to the keyvault and subscription contributor access in the case of monitoring.
* Power shell window
* Requires PS Core 7.0 and Az module 3.1.0

# makeManagedAPIM 

## In keeping with the way makeManaged operates, the API instance is created outside of this process.

### makeManagedAPIM.ps1 parameters

*PARAMETER clientid
(Required/Optional) The userid from a service principal on the subscription.
*PARAMETER clientkey
(Required/Optional) The password of the service principal.
*PARAMETER tenantid
(Required/Optional) The tenantid of the service principal.
*PARAMETER subscription         
(Required/Optional) The name of the subscription this session is to be running under. 
*PARAMETER apimname
(Required) The name of the API management instance.         
*PARAMETER keyvault
(Required) The name of a keyvault that contains the additional information required
to run the ARM template. This currently contains subscription wide variables.
*SWITCH dxcBackup
(Optional) Switch used to install azurebackup logic app.  Without this switch,
the default is to not install azurebackup.
*SWITCH dxcMonitored
(Optional) Switch used to install api monitoring function app.  Without
this switch, the default is to not install any monitoring.
*PARAMETER bds
(Required/Optional) Parameter used to name the storage account that can
be used by the backup parameter.  The default is that this parameter is required unless overridden by the noapimbackup switch.
*PARAMETER bdsrg
(Required/Optional) Parameter used to name the resource group that the storage account resides that is to be used by the 
backup process.  The default is that this parameter is required unless overridden by the noapimbackup switch.
*PARAMETER servicesrg
(Required) Parameter used to name the resource group that the all the functional services are to be placed.  This includes
the logic app and all function apps that are created during automation.
*SWITCH log
(Optional) Switch used to indicate that a log file is created for the run.
*PARAMETER logName
(Optional) This is used to define a name for the log when the above 'log' parameter is used.  The default is 'log4ps.log'
and it is placed in the same directory that this script is run from.
*PARAMETER fatalColor
(Optional) This is used to set all "fatal" messages to the color of your choice.  Please refer to the makeManagedAuto wiki
page for a list of available colors.
*PARAMETER errorColor
(Optional) This is used to set all "error" messages to the color of your choice.  Please refer to the makeManagedAuto wiki
page for a list of available colors.
*PARAMETER warnColor
(Optional) This is used to set all "warn" messages to the color of your choice.  Please refer to the makeManagedAuto wiki
page for a list of available colors.
*PARAMETER infoColor
(Optional) This is used to set all "info" messages to the color of your choice.  Please refer to the makeManagedAuto wiki
page for a list of available colors.
*PARAMETER debugColor
(Optional) This is used to set all "debug" messages to the color of your choice.  Please refer to the makeManagedAuto wiki
page for a list of available colors.
*PARAMETER traceColor
(Optional) This is used to set all "trace" messages to the color of your choice.  Please refer to the makeManagedAuto wiki
page for a list of available colors.



## Jira Epic
https://jira.dxc.com/browse/AZR-15144


## Members of this directory are:
* backupAPIM.ps1 - Powershell used to backup an API instance
* restoreAPIM.ps1 - Powershell used to restore an API instance
* dxcApiMonitor - Function app directory for API monitoring.  This is loaded into the storage blob and called from there.
* makeManagedAPIM.ps1 - main makeManaged powershell script
* dxcAPIMbkupLA.json - json ARM template used to create logic app for backup/restore.  This is loaded into the storage blob template directory.
* readme.md - this file

## Author
Kevin Bilderback
kevin.bilderback@dxc.com
