<#
====================================================================================================================================================
Contributors:  Anthony Borucki
DATE:    06/07/2020
Version: 1.0
====================================================================================================================================================
.SYNOPSIS
    AzureRelease.ps1

.DESCRIPTION
    The script will create a release with the source as the master branch in AMS and the destination AO_SN. It will create the release branch in both repos 
	The master branch in AO_SN is no longer needed.

	This script will create a release tag in AO_SN repo. The only manual intervention is after running this script, someone will need to go to the github link below and create the release from the tag
	https://github.dxc.com/cloud/AzureOffering_ServiceNow/tags

	This script must be run from a Windows machine or cloud shell

    Syntax: 
     ./AzureRelease.ps1 -releaseVersion <release version> -gittoken <git token>

    Parameters:
      releaseVersion :  i.e. 2.4.5
      gittoken : Personal access token for user that has admin rights to both AMS and AO_SN
      dxcaztoolsdevtoken : SaS token with Blob allowed Service and Service, container, and Object Allowed Types for dxcazuretoolsdev storage account
	  dxcaztoolstoken : SaS token with Blob allowed Service and Service, container, and Object Allowed Types for dxcazuretools storage account
	  sqlpaastoken : SaS token with Blob allowed Service and Service, container, and Object Allowed Types for sqlpaasprodlinktemplates storage account
      
    Notes:

        
.EXAMPLE
	.\AzureRelease.ps1 "2.4.5" "sdfsfjlsajflsjflnesdkfsjf"     

================================================================================================================================================================================================================================================
#>

#
########### Parameters section ###########
#
Param
(
    [Parameter(Mandatory=$true)] [String]$releaseVersion,
	[Parameter(Mandatory=$true)] [String]$gittoken,
    [Parameter(Mandatory=$true)] [String]$dxcaztoolsdevtoken,
    [Parameter(Mandatory=$true)] [String]$dxcaztoolstoken,
    [Parameter(Mandatory=$true)] [String]$sqlpaastoken
)

########### Variable section ###########
$releasePathExists = test-path ~\Release
$releaseBranch = "release-v" + $releaseVersion
#Change above to below for testing
#$releaseBranch = "tonytest1-v" + $releaseVersion
$releaseTag = "v" + $releaseVersion

########### Main Body ##############
Write-Host "Create ~\Release"
Write-Host
if ($releasePathExists) {
	Remove-Item -Path ~\Release -Recurse -Force 
}
New-Item -Path ~ -ItemType Directory -Name Release
cd ~\Release

#clone master of AMS
Write-Host "Clone AzureManagedServices"
Write-Host
git clone https://$gittoken@github.dxc.com/cloud/AzureManagedServices.git --branch=master AzureManagedServices

#create release branch in AMS from master
cd AzureManagedServices
git checkout -b $releaseBranch

#clone master of AO_SN
Write-Host "Clone AzureOffering_ServiceNow"
Write-Host

cd ..
git clone https://$gittoken@github.dxc.com/cloud/AzureOffering_ServiceNow.git --branch=master AzureOffering_ServiceNow
cd AzureOffering_ServiceNow

#create release branch in AO_SN from master
Write-Host "Create release branch on AO_SN"
Write-Host
git checkout -b $releaseBranch

#delete all files in release branch on AO_SN, except git files
Write-Host "Remove all files from release branch"
Write-Host
cd ..
Remove-Item ~\Release\AzureOffering_ServiceNow\* -Recurse  -Exclude "*.git*"

#copy all files from AMS folders to AO_SN folder, except git files
Write-Host "Move all files from AMS master branch to AO_SN release branch"
Write-Host
cd AzureManagedServices
Copy-Item * -Destination "..\AzureOffering_ServiceNow" -Recurse -Exclude "*.git*","*.sln","Deploy-AzureResourceGroup.ps1","*.targets","*.deployproj","DeploymentHelper.cs"

#replace all instances of dxcazuretoolsdev storage account in all files with dxcazuretools for production use
Write-Host "Replace all instances of dxcazuretoolsdev storage account in all files with dxcazuretools for production use. Files searched for replacement are below:"
Write-Host
cd ..\AzureOffering_ServiceNow 
Get-ChildItem -Recurse -File -Include "*.ps1","*.json","*.psm1" -Exclude "uploadArtifacts.ps1","artifacts.json","AzureRelease.ps1","makeManagedAuto.ps1" | ForEach-Object {
	write-host $_
    (Get-Content $_).replace('dxcazuretoolsdev','dxcazuretools') | Set-Content $_
}

#add, commit and push release branch in AO_SN
Write-Host "Add, Commit and Push release branch"
Write-Host
git add --all
git commit -am "Release $releaseVersion automated process"
git push --set-upstream origin $releaseBranch

.\uploadArtifacts.ps1 -releaseversion $releaseVersion -dxcaztoolsdevtoken $dxcaztoolsdevtoken -dxcaztoolstoken $dxcaztoolstoken -sqlpaastoken $sqlpaastoken

#commit and push release branch in AMS
Write-Host "Commit and Push release branch to AMS"
Write-Host
cd ..\AzureManagedServices
git commit -am "Release $releaseVersion automated process"
git push --set-upstream origin $releaseBranch

#tag release
Write-Host "Create basic tag for release"
Write-Host
cd ..\AzureOffering_ServiceNow
git tag $releaseTag -a
git push origin --tags
