# AzureManagedServices
This is a new repository for source code, dev and testing tools of the Azure Engineering team
This repository is a consolidation of the following repositories:

https://github.dxc.com/cloud/AzureOffering_ServiceNow
https://github.dxc.com/cloud/DXC-Azure
-More to be added

Releases from the Azure Engineering team will continue to be deployed to https://github.dxc.com/cloud/AzureOffering_ServiceNow as that repo is now for 
releases and legacy read-only access.