#Requires -PSEdition Core
#Requires -Version 7.0

#Requires -Module @{ ModuleName = 'Az'; ModuleVersion = '2.5.0' }
#Requires -Module @{ ModuleName = 'Az.Resources'; ModuleVersion = '1.6.1' }
#Requires -Module @{ ModuleName = 'Az.Functions'; ModuleVersion = '1.0.1' }

#=====================================================================================================================
# DOCUMENTATION LINK
# https://confluence.dxc.com/display/CSA/Generic+Security+Implementation+for+FunctionApp
#=====================================================================================================================

[CmdletBinding(SupportsShouldProcess=$true)]
Param
    (
    [Parameter(Mandatory=$true)]    [String]$SubscriptionId,
    [Parameter(Mandatory=$true)]    [String]$TenantId,
    [Parameter(Mandatory=$true)]    [String]$FunctionAppName,
    [Parameter(Mandatory = $false)] [Switch]$AppServiceAuthOn,
    [Parameter(Mandatory = $false)] [Switch]$HTTPSOnly,
    [Parameter(Mandatory = $false)] [Switch]$HTTP20Enabled,
    [Parameter(Mandatory = $false)] [Switch]$FTPDisabled,
    [Parameter(Mandatory = $false)] [Switch]$FTPSOnly
    )
#=====================================================================================================================
# IMPORT CUSTOM MODULES, CHECK ENVIRONMENT FOR NECESSERY MODULES CHECK SWITCHES
#=====================================================================================================================

If (-not($AppServiceAuthOn -or $HTTPSOnly -or $HTTP20Enabled -or $FTPDisabled -or $FTPSOnly))  
    {
    Write-Host "WARNING:     No Switch selected, the script will exit now as it has nothing to deploy." -ForegroundColor Yellow 
    Read-Host "`nPress 'ENTER'to exit the script........"
    exit
    }

If ($FTPDisabled -and $FTPSOnly)   
    {
    Write-Host "WARNING:     Cannot push both 'FTPDisabled' and 'FTPSOnly' settings. Please remove one of these switches and try again." -ForegroundColor Yellow 
    Read-Host "`nPress 'ENTER'to exit the script........"
    exit
    }

$dxcModuleList = "DXCEnvCheckV2.psm1", "DXCUtilityFunctions.psm1"
foreach ($dxcModule in $dxcModuleList)
    {
    [String]$dxcModuleURL = "https://dxcazuretoolsdev.blob.core.windows.net/installers/DXCPowershellModules/" + $dxcModule
    [String]$dxcLocalModule = $PSScriptRoot + "\" + $dxcModule
    (New-Object System.Net.WebClient).DownloadFile($dxcModuleURL, $dxcLocalModule)
    Import-Module $dxcLocalModule -WA 0
    Remove-Item -Path $dxcLocalModule
    }



#=====================================================================================================================
# LOGIN SECTION
#=====================================================================================================================
$error.Clear()
Utility-LoginAZTenant -TenantId $TenantId -SubscriptionId $SubscriptionId

#=====================================================================================================================
# VARIABLE SECTION
#=====================================================================================================================
$ErrorActionPreference = "SilentlyContinue"
$WarningPreference = "SilentlyContinue"

[string]$WebAppApiVersion = "2015-08-01"
[String]$dxcWebResource = $FunctionAppName + "/web"
[String]$dxcAuthResource = $FunctionAppName + "/authsettings"
$dxcAuthSettings =    @{
                            "enabled" = "True";
                            "unauthenticatedClientAction" = "1";
                            "defaultProvider" = "0";
                            "tokenStoreEnabled" = "False";
                       }
 If ($HTTP20Enabled) { $dxcWebSecuritySettings += @{ "http20Enabled" = "True"; } }
 If ($FTPDisabled)   { $dxcWebSecuritySettings += @{ "ftpsState"="Disabled";   } }
 If ($FTPSOnly)   { $dxcWebSecuritySettings += @{ "ftpsState"="FtpsOnly";   } }
       
#========================================================================================================================
# MAIN BODY OF THE SCRIPT
#========================================================================================================================

#Collect FunctionApp Details.

$dxcObjFunctionApp = Get-AzFunctionApp | ? { $_.Name -Match $FunctionAppName }

If ($dxcObjFunctionApp)
    {
    [String]$dxcResourceGroup = $dxcObjFunctionApp.ResourceGroupName
    Utility-DisplayInfo -dxcstr1 "INFORMATION: Function App named" -dxcstr2 $FunctionAppName -dxcstr3 "located under ResourceGroup" -dxcstr4 $dxcResourceGroup
    }
else
    {
    Write-Host "WARNING:     Function App not found. Please enter correct Function App name while running the script." -ForegroundColor Yellow
    Read-Host "`nPress 'ENTER'to exit the script........"
    exit
    }

#Deploying Security Settings.

Write-Host "INFORMATION: Deploying security settings, this may take few minutes..." -ForegroundColor Green

$error.Clear()
If ($httpsOnly) 
    {
    $dxcObjFunctionApp = Get-AzResource -ResourceGroupName $dxcResourceGroup -ResourceType "Microsoft.Web/sites" -Name $FunctionAppName 
    $dxcObjFunctionApp.Properties.httpsOnly=$true
    $dxcObjFunctionApp|Set-AzResource -Force >$null
    }
If ($AppServiceAuthOn) { New-AzResource -PropertyObject $dxcAuthSettings -ResourceGroupName $dxcResourceGroup -ResourceType "Microsoft.Web/sites/config" -ResourceName $dxcAuthResource -ApiVersion $WebAppApiVersion -Force >$null}
If ($HTTP20Enabled -or $FTPDisabled -or $FTPSOnly) { New-AzResource -PropertyObject $dxcWebSecuritySettings -ResourceGroupName $dxcResourceGroup -ResourceType "Microsoft.Web/sites/config" -ResourceName $dxcWebResource -ApiVersion $WebAppApiVersion -Force >$null }

If ($error) 
    {
    Write-Host "WARNING:     Failed to deploy some or all the security settngs, follow the below Wiki document to set the security settings manually if rest of the deployment is successfull." -ForegroundColor Yellow
    Write-Host "             https://confluence.dxc.com/pages/viewpage.action?pageId=207312130"
    }
else { Write-Host "INFORMATION: Security settings implemented successfully." -ForegroundColor Green }

Write-Host "`n*****************End OF SCRIPT EXECUTION*****************"
