# Azure Reporting through Power BI
This is a step by step guide for how to run various governance reports for Azure Clients using Power BI

## Jira Epic
N/A - Before switch to AZR project in Jira

## Deployment
For more information on Power BI Reporting, please see Section 3.6 of the Operations Guide

# Current Scope : Patching, backup, Capacity, VM Availability Reports
The Power BI templates for each of these reportings are  hardcoded with Log Analytics query to fetch the necessary reports. The Power BI Templates are DXC Proprietary and not to be shared with anyone outisde of Azure Engineering/ CloudOps.

# Prerequisites:

- Reader or contributor level permission
- Log Analytics workspace id(s) for the client(s) subscription(s)
- Log Analytics workspace name(s) for the client(s) subscription(s)
- Power BI desktop on your local machine ( download the Power BI desktop from https://app.powerbi.com/home )

# How to use the template:
Below is an example of running the backup and patching report 

1. Download the appropriate Power BI template from the Github Repo [https://github.dxc.com/cloudops/Reporting-through-power-bi/tree/master/Templates]
2. Launch the Power BI template on your local machine by launching it from the location where you downloaded it to.
3. Fill in the workspace id ( if you are executing it for multiple subscriptions for the same client, enter any one workspace id)
4. Fill in the workspacename in the next 4 tables as requested in the below format
    workspace("LA workspace name").table name  
    **Please note the tables names Perf, Heartbeat, Update, AddOnAzureBackupJobs, AddOnAzureBackupPolicies, CoreAzureBackup, ExtensionHealth_CL and Alert are case sensitive.**
    You must enter the information in the same format.
    ![](./Images/Inputs.png)
    ```                 
    For example :- if the LA workspace name is DXC-AVAN-483b-loganalyticsWorkspace, then fill the information as shown below
    workspace("DXC-ABCD-483b-loganalyticsWorkspace").Perf
    workspace("DXC-ABCD-483b-loganalyticsWorkspace").Heartbeat
    workspace("DXC-ABCD-483b-loganalyticsWorkspace").Update
    workspace("DXC-ABCD-483b-loganalyticsWorkspace").AddonAzureBackupJobs
    workspace("DXC-ABCD-483b-loganalyticsWorkspace").AddonAzureBackupPolicies
    workspace("DXC-ABCD-483b-loganalyticsWorkspace").CoreAzureBackup
    workspace("DXC-ABCD-483b-loganalyticsWorkspace").ExtensionHealth_CL
    workspace("DXC-ABCD-483b-loganalyticsWorkspace").Alert

    For example : if you have multiple workspaces, then separate each LA with a comma.
    workspace("DXC-ABCD-38c2-loganalyticsWorkspace").Perf,workspace("DXC-EFGH-54d3-loganalyticsWorkspace").Perf and so on
    workspace("DXC-ABCD-38c2-loganalyticsWorkspace").Heartbeat,workspace("DXC-EFGH-54d3-loganalyticsWorkspace").Heartbeat and so on
    workspace("DXC-ABCD-38c2-loganalyticsWorkspace").Update,workspace("DXC-EFGH-54d3-loganalyticsWorkspace").Update and so on
    workspace("DXC-ABCD-38c2-loganalyticsWorkspace").AddonAzureBackupJobs,workspace("DXC-EFGH-54d3-loganalyticsWorkspace").AddonAzureBackupJobs and so on
    workspace("DXC-ABCD-38c2-loganalyticsWorkspace").AddonAzureBackupPolicies,workspace("DXC-EFGH-54d3-loganalyticsWorkspace").AddonAzureBackupPolicies and so on
    workspace("DXC-ABCD-38c2-loganalyticsWorkspace").CoreAzureBackup,workspace("DXC-EFGH-54d3-loganalyticsWorkspace").CoreAzureBackup and so on
    workspace("DXC-ABCD-38c2-loganalyticsWorkspace").ExtensionHealth_CL,workspace("DXC-EFGH-54d3-loganalyticsWorkspace").ExtensionHealth_CL and so on
    workspace("DXC-ABCD-38c2-loganalyticsWorkspace").Alert,workspace("DXC-EFGH-54d3-loganalyticsWorkspace").Alert and so on
    ```
5. After filling the information correctly , click on LOAD
6. It will then prompt you to sign in, select organizational account and click on sign in.
    ![](./Images/Access.png)
7. Enter the credentials for authentication.
8. click on connect when the sign in completes.
    ![](./Images/Authorization.png)
9. After successfull authentication, the data will be fetched in the Power BI template.
    ![](./Images/DataLoad.png)
10. You can save the power BI template as a local copy with appropriate naming convention.
    ![](./Images/Dashboard.png)

If you wish to use the same template for another client , follow the below steps to clear the previous authentication before you could run it for another client 

1. Launch the Power BI template.
2. click on files -> Options and Settings -> DataSource Settings
    ![](./Images/Settings.png)
3. Select Global Permissions -> Click on clear permissions -> Click on Close
    ![](./Images/Permissions.png)
    ![](./Images/DeletePermissions.png)
4. Then re-launch the template and follow the same steps above 1-10 to run the report for another Client

To avoid multiple re-authentication, you can authorize once and save multiple local copies of your template with your client names as appropriate.

The next time when you need to re-run the report for the same client, just launch the template and click on refresh.

# How to export the data from Power BI:

After the report has executed successfully, click on the publish button on the top right hand corner of the template.
It will prompt to sign in, use your DXC email address to Sign into Power BI or use the Client login.
It will prompt you to publish the report to a workspace ( always select your own workspace, if you dont wish the public to view)
Go to the published location on your https://app.powerbi.com/home page .
Then download the file to PDF / power point clicking on the File Option.

If you wish to export the data table, highlight the table and click on export to tab.

Please note you will be able to share the Power BI report directly from the portal if you are signed in using a Power BI Pro License user.

# Capacity reporting:

The data stores for metrics and logs, which are the two fundamental types of data use by Azure Monitor.
On the left are the sources of monitoring data that populate these data stores. 
On the right are the different functions that Azure Monitor performs with this collected data such as analysis, alerting, and streaming to external systems.
 
To run the Capacity Report, We use the data store "Logs" analyze through Log Analytics and Visualize through Power BI.
 
The data from the LA workspace is extracted using Kusto Queries and exported to Power BI through the Azure Log analytics REST API.

 ![](./Images/Visualization.png)
 
## Requirements:
 Counters to be configured in Log Analytics:
**Linux:**

* CPU:
  * % Processor Time
* Memory:
  * Used Memory
  * Available MBytes Memory	
* Disk:	
  * Used Space
  * Free Megabytes
 
**Windows:**

* CPU:
  * % Processor Time
* Memory:
  * Available MBytes
  * % Committed Bytes In Use
* Disk:	
  * % Free Space
  * Free Megabytes	

## Limitations:

1. Queries cannot return more than 500,000 rows (Log analytics REST API)
2. Queries cannot return more than 64,000,000 bytes (~61 MiB total data) (Log analytics REST API)
3. Queries cannot run longer than 10 minutes by default (Log analytics REST API)
4. Power BI pro License needed for sharing report with others
5. LA workspace queries are restricted to 10,000 results

## Considerations:

* The report can run as a Free Power BI user
* Limit the number of queries executed in the LA workspace
* Faster Queries avoiding Join and Union Statements
* Different templates for daily and monthly data
* Provide only the list of Overutilized systems
* The data is calculated at an Average of 5 mins in the last 24 hrs for daily report 
* The data is calculated at an Average of 5 mins in the last 30 days for the monthly report

# VM Availability reporting:
Availability Report for VM's is calculated based on the Heartbeat Signals captured in the Heartbeat Table of the LA Workspace.

## IMPORTANT TO READ :

The output is always dependent on the LA workspace retention period. This is why we have provided Start Date and End Date as input parameters in the Power BI template to restrict the report for a specific time period only. 

Recommended to run the report on first of every month to get the full availability report for the previous month, the default retention on LA workspace is 30 days.

The Start Date cannot be earlier than the retention days on the LA workspace and the end date cannot be greater than the current date.

The date format is YYYY-MM-DD

DXC Managed Azure Offering does not commit on VM availability SLA, all SLA's are applicable as outlined by Microsoft and owned by Microsoft. Refer to the Client signed Azure SOW if you have questions on SLA's.

This report does not consider the factors that impacts the Heartbeat such as VM is stopped , scheduled restart , maintenance activities, ingestion latencies, extension health issues, VM agent health issues while calculating the % availability.

The Power BI template will give you the list of VM's per subscription and their availability in the time period you have selected.

## Mathematical Derivation for Availability % Calculation:

Availability % = (Total number of HB  Signals received / Total number of HB signals expected )* 100

Where,

Total number of HB signal received = The count of signals captured in the Heartbeat table of the LA workspace for the time period ( Startdate…End Date)

Total number of HB signal expected = 1440 * number of days ( difference between the end date and the start date of the query)

The above logic is used the LA query to provide the VM availability Report.

## How to identify at what time the HB signals were dropped :
See the CloudOps Confluence page documentation https://confluence.dxc.com/display/COPS/Azure+Reports on How to run these validations.
