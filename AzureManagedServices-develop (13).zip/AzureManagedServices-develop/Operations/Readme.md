# Operations

This folder holds operational artifacts used to support day to day activities for Gold Managed Customers

## Supported
* AgentHealthDashboard
* Backup
* LogAnalyticsAgentRestart
* PowerBIReporting
* Reporting
* RestartLinusOMSAgent
* SelfHeal
* StandardAutomationAccount

## Jira Epic
N/A

## Deployment
For more information on resources in this root folder, see the Operations guide

## Members of this directory are:
* automateDiagnosticExtension.ps1		Used to automate the deployment of the Diagnostic Extension on existing VMs
* CS2CWPMigration.ps1					Run CS2CWPMigration to install Symantec CWP protection on VMs and replace CrowdStrike protection if present.
* linuxCSUninstall.sh					Removes Falcon sensor
* removeOrphanedResources.ps1			Tool for removing vNIC, Public IP and Disk resources that are not associated with any VM
* removeVMAndResources					Tool for removing a VM and its associated Public IP, vNIC and Disk resources
* redhatcertupdate.sh					Invoked from within the automateDiagnosticExtension.ps1 and used to update expired client certificate of RHEL VMs
* windowsCSUninstall.ps1				Uninstalls Crowdstrike
* disableDefenderOnOlderCSinstalls.ps1	Disables Windows Defender realtime monitoring on Windows 2016 and 2019 servers that were deployed with it enabled.

## Authors
* Azure Engineering



