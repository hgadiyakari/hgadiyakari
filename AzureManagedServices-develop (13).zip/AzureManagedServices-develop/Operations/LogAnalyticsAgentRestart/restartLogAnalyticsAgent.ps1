#-----------------------------------------------------------[Comments]-------------------------------------------------------------
<#
.DOCUMENTATION LINK
https://confluence.dxc.com/display/CSA/AZR-11972+-+Remediation+Guide+enhancement+to+include+-+OMI+services+not+restarting+correctly+after+agent+upgrade

.SYNOPSIS
This PowerShell script will perform a clean restart of the Log Analytics Agent based on reported VMs without performance data on AgentHealth report
and capture the results of the action in a report file.
This scripts uses a mandatory parameter to input a file which contains a list of VMs wherein the Log Analytics agent service will be restarted on. 
The AgentHealth report file can be used as the input file or another file which must contain these headers - VMName, ResourceGroupName, SubscriptionId.

The script will create output files - the report in Excel format and a log file in text format.

.EXAMPLES
 .\restartLogAnalyticsAgent.ps1 -dxcVMsforAgentRestartFile <myVMsforAgentRestartFile>

.REVISION HISTORY
    07-Feb-2020 - Initial script development
    19-Feb-2020 - Modified scope to include input file aside from AgentHealth report
#>

#---------------------------------------------------------[Initializations]-------------------------------------------------------- 
[CmdletBinding()]
Param(
    [Parameter(HelpMessage = "Please enter file path for AgentHealthReport or VM list for agent restart.", Position=1, Mandatory = $true, ValueFromPipeline = $True)]
    [ValidateNotNullOrEmpty()][string]$dxcVMsforAgentRestartFile
)

#----------------------------------------------------------[Declarations]----------------------------------------------------------
$scriptName = "restartLogAnalyticsAgent"
$ErrorActionPreference = 'SilentlyContinue'
$Global:LogFilePath = (Get-Item -Path .\ -Verbose).Fullname + '\' + $scriptName + '-{0:dd-MMM-yyyy_HHmm}' -f (Get-Date) + '.log'
$reportFile = (Get-Item -Path .\ -Verbose).Fullname + '\' + "AgentsRestarted" + '-{0:dd-MMM-yyyy_HHmm}' -f (Get-Date) + '.xlsx'
$dxcScriptFiles = @(
"mmagent-clean-restart.ps1"
"omsagent-clean-restart.sh"
)
$dxcfileURL = "https://dxcazuretoolsdev.blob.core.windows.net/forautomation/AgentFix/"

[PSObject[]] $resultsAllAgentsRestart=@()

#-----------------------------------------------------------[Functions]------------------------------------------------------------

function Write-Log { # This function writes script messages to active session and outputs to log file.
Param ([ValidateSet('Cyan','Gray','Green','Red','White','Yellow')][string]$logColor,
[string]$logText, [int]$logCode)

$logTimeStamp = Get-Date -Format MM-dd-yyyy-hh:mm:ss
switch ($logCode) {
    0 { Write-Output $logText | Tee-Object -FilePath $global:LogFilePath -Append | Out-Null;
        Write-Host -F $logColor $logText } # Use for general messages
    1 { Write-Output "$logTimeStamp INFO: $logText"| Tee-Object -FilePath $global:LogFilePath -Append | Out-Null;
        Write-Host -F $logColor "$logTimeStamp INFO: $logText" } # Use for Informational messages
    2 { Write-Output "$logTimeStamp ERROR: $logText"| Tee-Object -FilePath $global:LogFilePath -Append | Out-Null;
        Write-Host -F $logColor "$logTimeStamp ERROR: $logText" } # Use for Error messsages
    3 { Write-Output "$logTimeStamp WARN: $logText"| Tee-Object -FilePath $global:LogFilePath -Append | Out-Null;
        Write-Host -F $logColor "$logTimeStamp WARN: $logText" } # Use for Warning messages
}

}

function Run-PreChecks { # This function performs required prerequisite checks.

# Check for ImportExcel module
Write-Log White "Perform prerequisite checks." 1
$checkModule = Get-Module -Name ImportExcel -ListAvailable -ErrorAction $ErrorActionPreference
if ($checkModule -eq $null) {
    Install-Module ImportExcel -AllowClobber -Force -ErrorAction $ErrorActionPreference
    Write-Log White "Module ImportExcel installed successfully." 1
} else { Write-Log White "Module ImportExcel found." 1 } 

if ($error) { Write-Log Red "Installation of required module - ImportExcel failed. Try to install manually (refer to https://www.powershellgallery.com/packages/ImportExcel/5.4.2)." 2; exit}

# Check for valid input file
$requiredHeaders = @('VMName','ResourceGroupName','SubscriptionId')
if (!($dxcVMsforAgentRestartFile)) {
    Write-Log Red "VM list for agent service restart not provided; script will exit." 1; exit
} else { 
    if (Test-Path -Path $dxcVMsforAgentRestartFile) {
        switch ($dxcVMsforAgentRestartFile.Split(".")[-1]) {
            'csv' { $global:dxcVMsforAgentRestart = Import-Csv $dxcVMsforAgentRestartFile -ErrorAction $ErrorActionPreference; $inputCode = 1 }
            'xls' { if ($dxcVMsforAgentRestartFile -like "*AgentHealth*") {
                    $global:dxcVMsforAgentRestart = (Import-Excel -Path $dxcVMsforAgentRestartFile -ErrorAction $ErrorActionPreference) `
                        | ? {($_.Heartbeat -eq $true) -and ($_.Performance -eq $false) -and ($_.LogAnalyticsAgentProvisioningStatus -eq "Succeeded")}
                } else { $global:dxcVMsforAgentRestart = Import-Excel -Path $dxcVMsforAgentRestartFile -ErrorAction $ErrorActionPreference }
            }
            'xlsx' { if ($dxcVMsforAgentRestartFile -like "*AgentHealth*") {
                    $global:dxcVMsforAgentRestart = (Import-Excel -Path $dxcVMsforAgentRestartFile -ErrorAction $ErrorActionPreference) `
                        | ? {($_.Heartbeat -eq $true) -and ($_.Performance -eq $false) -and ($_.LogAnalyticsAgentProvisioningStatus -eq "Succeeded")}
                } else { $global:dxcVMsforAgentRestart = Import-Excel -Path $dxcVMsforAgentRestartFile -ErrorAction $ErrorActionPreference }
            }
        }
        if ($global:dxcVMsforAgentRestart) {
            $inputfileHeaders = $global:dxcVMsforAgentRestart[0].PSObject.Properties.Name
            if (($inputfileHeaders | ? -FilterScript { $_ -in $requiredHeaders}).Count -eq 3) {
                Write-Log Green "Input file successfully imported." 1
            } else {
                Write-Log Red "Failed to import input due to missing headers; should contain 'VMName','ResourceGroupName','SubscriptionId'." 2; exit             
            }
        } else {
            Write-Log Red "Failed to import input file from the provided file path. Please ensure file contains valid input, path is correct and file type is either in .csv or .xls format." 2; exit
        }
    } else {
        Write-Log Red "Failed to import input file from the provided file path. Please ensure file contains valid input, path is correct and file type is either in .csv or .xls format." 2; exit
    }
}

# Download AgentRestart scripts
if ($dxcScriptFiles -ne $null) {
    foreach ($dxcScript in $dxcScriptFiles) {
        $dxcfileURLforDownload = $dxcfileURL + $dxcScript
        $dxcScriptFilePath = Join-Path (Get-Location).ProviderPath $dxcScript
        (New-Object System.Net.WebClient).DownloadFile($dxcfileURLforDownload, $dxcScriptFilePath)
    }
}
    if ($error) { Write-Log Red "Unable to download AgentRestart scripts. Try downloading manually from here: `n$dxcfileURL/omsagent-clean-restart.sh ` 
        `n$dxcfileURL/mmagent-clean-restart.sh" 2; exit} 

Write-Log White "Prerequisite checks completed." 1
}

#-----------------------------------------------------------[Execution]------------------------------------------------------------

try {

$error.Clear()

# Create the log file
New-Item $Global:LogFilePath -ItemType File | Out-Null

Write-Log Yellow "Script execution started." 1

# Run prerequisite checks
Run-PreChecks 
if ($error) { Write-Log Red $error 2; exit }

# Login to Azure
Write-Log Cyan "Please login to Azure Resource Manager." 0
Connect-AzAccount | Out-Null
if ($error) { Write-Log Red "Unable to connect to Azure. Check your internet connection and verify authentication details." 2; exit }
Write-Log Cyan "Connected to Azure with provided authentication." 0
Sleep 3

Write-Log White "Start processing VMs for Log Analytics Agent service restart." 1
foreach ($dxcVM in $Global:dxcVMsforAgentRestart) {
    if ((!($dxcVM.VMName)) -or (!($dxcVM.ResourceGroupName)) -or (!($dxcVM.SubscriptionId))) {
        Write-Log Red "Missing input. Please ensure valid input for VMName, ResourceGroupName, and SubscriptionId is entered in file." 2; continue
    } else {
        Select-AzSubscription -Subscription $dxcVM.SubscriptionId | Out-Null
        $dxcVMName = $dxcVM.VMName  
        if (Get-AzVM -status -Name $dxcVM.VMName | ? {$_.PowerState -match "running"}) {
            if ($dxcVM.OSType -eq $null) { $dxcVM | Add-Member NoteProperty -Name OSType -Value (Get-AzVM -Status -Name $dxcVM.VMName).StorageProfile.OsDisk.OsType }
            $checkAgentState = ((Get-AzVMExtension -ResourceGroupName $dxcVM.ResourceGroupName -VMName $dxcVM.VMName) | ? {($_.ExtensionType -eq 'OmsAgentForLinux') -or ($_.ExtensionType -eq 'MicrosoftMonitoringAgent')}).ProvisioningState
                if ($checkAgentState -eq "Succeeded") { 
                    Write-Log White "Restarting LogAnalytics Agent service on $dxcVMName" 1
                    switch ($dxcVM.OSType) {
                        'Linux' {
                            $dxcAgentRestartScript = "omsagent-clean-restart.sh"
                            $dxcAgentRestartResult = Invoke-AzVMRunCommand -ResourceGroupName $dxcVM.ResourceGroupName -Name $dxcVM.VMName -CommandId 'RunShellScript' `
                                -ScriptPath (Join-Path (Get-Location).ProviderPath $dxcAgentRestartScript) -ErrorAction $ErrorActionPreference #-AsJob >$null
                        }
                        'Windows' {
                            $dxcAgentRestartScript = "mmagent-clean-restart.ps1"
                            $dxcAgentRestartResult = Invoke-AzVMRunCommand -ResourceGroupName $dxcVM.ResourceGroupName -Name $dxcVM.VMName -CommandId 'RunPowerShellScript' `
                                -ScriptPath (Join-Path (Get-Location).ProviderPath $dxcAgentRestartScript) -ErrorAction $ErrorActionPreference #-AsJob >$null
                        }
                    }
                } else { Write-Log Gray ("Log Analytics agent not found or in failed state.") 3 }

            # Capture agent service restart results     
            if ($error) { $dxcVM | Add-Member NoteProperty -Name "IsAgentRestarted" -Value $false
                $dxcVM | Add-Member NoteProperty -Name "IsAgentRestartedResults" -Value $error
            } elseif ((!($dxcAgentRestartResult)) -or ($dxcAgentRestartResult.Value[0].Message -like "*error*") -or ($dxcAgentRestartResult.Value[0].Message -like "*failed*")) { 
                $dxcVM | Add-Member NoteProperty -Name "IsAgentRestarted" -Value $false
                $dxcVM | Add-Member NoteProperty -Name "IsAgentRestartedResults" -Value ($dxcAgentRestartResult.Value[0].Message | Out-String) 
            } else { $dxcVM | Add-Member NoteProperty -Name "IsAgentRestarted" -Value $true 
                $dxcVM | Add-Member NoteProperty -Name "IsAgentRestartedResults" -Value ($dxcAgentRestartResult.Value[0].Message | Out-String)
            }
                
        } else { 
            Write-Log Gray "$dxcVMName is powered off. Unable to restart agent service." 3
            $dxcVM | Add-Member NoteProperty -Name "IsAgentRestarted" -Value $false
            $dxcVM | Add-Member NoteProperty -Name "IsAgentRestartedResults" -Value $false
        }   
        Write-Log White ("LogAnalytics Agent service restarted on " + $dxcVM.VMName + ": " + $dxcVM.IsAgentRestarted) 1
        $resultsAllAgentsRestart+=$dxcVM
        $error.clear()
    }
    
}

} catch {
Write-Log Red "Script executed with errors. $Error." 2

} finally {
if ($resultsAllAgentsRestart -ne $null) {
    $resultsAllAgentsRestart | Export-Excel -Path $reportFile -WorksheetName "AgentsRestarted" -Show
    Write-Log Green "Agent Restart report created, see $reportFile." 1
} else { Write-Log Red "Unable to create the AgentRestart report. $error" 2}

Disconnect-AzAccount | Out-Null
Write-Log Cyan "Disconnected from Resource Manager." 0
Write-Log Yellow "Script execution finished. Refer to log - $Global:LogFilePath." 1
}
