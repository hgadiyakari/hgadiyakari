﻿#Log Analytics Agent Restart

In order to support Agent Health remediation efforts, this story is to provide additional tools to report VMs without performance and perform a restart of the Log Analytics agent service. As observed in previous cases, collection of Performance data sometimes fail when the Log Analytics agent is upgraded. Hence, we need to restart the Log Analytics Agent service in order to recover missing data.

## Jira Epic
AZR-11972 - Remediation Guide enhancement to include - OMI services not restarting correctly after agent upgrade

## Deployment
For more information see 
https://confluence.dxc.com/display/CSA/AZR-11972+-+Remediation+Guide+enhancement+to+include+-+OMI+services+not+restarting+correctly+after+agent+upgrade

### Overview
To diagnose performance data collection issues, we need to ensure the following:

The Log Analytics Agent VM extension has been installed and in good state. 
- Heartbeat count is consistent (~60 per hour)
- Performance data collected within acceptable heartbeat count

If verified that perfomance data is not collecting, the Log Analytics Agent service needs to be restarted:

- For Linux VMs, the following needs to be performed:
  - Restart of OMI service 
  - Run PerformRequiredConfigurationChecks

- For Windows VMs, the following needs to be performed:
  - Restart of HealthService


### Solution approach
We need to collect and identify the VMs with failing performance data collection and initiate a restart of the Log Analytics Agent service to fix the issue. The automation scripts have been developed that covers -

- Reporting Performance Health issue (reportAgentHealth.ps1) - this script will report Agent Health for all VMs in a subscription with information on 
  - Virtual machine name, Resourcegroup, Location, OS type and version, Subscription, Location, Workspace
  - Heartbeat, Performance, Agent extension type (Monitoring, Diagnostics) and status
- Restarting the Log Analytics Agent (*restartLogAnalyticsAgent.ps1*) - this script will restart the Log Analytics Agent service on VMs identified from the Agent Health Report script (*reportAgentHealth.ps1*) and will include information on
  - Virtual machine name, Resourcegroup, Location, OS type and version, Subscription, Location, Workspace
  - Results of Log Analytics Agent restart action


### Prerequisites
- PowerShell version 5.0 or higher
- Az module verion 1.2. or higher
- ImportExcel module


### Script execution

1. Download or the copy the script package from GitHub.
2. Open a PowerShell conole (run as Administrator) and change to .\Operations\LogAnalyticsAgentRestart

- Reporting Performance Health issue (reportAgentHealth.ps1)

3. To run the agent reporting, execute either of the following commands -
   - Run on on all workspaces in a target subscription
   ```
   .\reportAgentHealth.ps1 -dxcSubscriptionId <mySubscriptionId>
   ```
   - Run on a target workspace in a subscription
   ```
   .\reportAgentHealth.ps1 -dxcSubscriptionId <mySubscriptionId> -dxcLogAnalyticsWorkspaceName <myWorkspaceName> 
   ```
   - Run on all workspaces in all subscriptions (default)
   ```
   .\reportAgentHealth.ps1
   ```
<em> Note: If you are keeping a list for supported VMs and want it flagged in the report, use the mandatory parameter and input the filename</em>
```
.\reportAgentHealth.ps1 -dxcSupportedVMList <SUPPORTEDVMsFILE>
```

4. Wait for script to finish. Upon completion, an Excel file will be displayed with the Agent Health report.
5. Take note of the file path where the report is created as it will be used for next script.

- Restarting the Log Analytics Agent (restartLogAnalyticsAgent.ps1)
6. On same console, run the command to perform agent restarts -
```
.\restartLogAnalyticsAgent.ps1 -dxcVMsforAgentRestartFile <AGENTHEALTHREPORTFILE>
```
7. Wait for the script to finish. Upon completion, an Excel file will be displayed to report results of the restart action.

## Authors
*  Caspellan, Jocelynne
