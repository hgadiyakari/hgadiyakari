/opt/microsoft/omsagent/bin/service_control stop
/opt/omi/bin/service_control stop
pkill -9 omicli
pkill -9 omiagent
pkill -9 omiengine
pkill -9 omiserver
pkill -9 omsagent
pkill -f /opt/microsoft/omsconfig/modules/nxOMSAutomationWorker/DSCResources/MSFT_nxOMSAutomationWorkerResource/automationworker/worker
/opt/omi/bin/service_control start
/opt/microsoft/omsagent/bin/service_control start
cd /opt/microsoft/omsconfig/Scripts/ && su omsagent -c ./PerformRequiredConfigurationChecks.py | grep -i "Operation PerformRequiredConfigurationChecks completed successfully." | head -1
