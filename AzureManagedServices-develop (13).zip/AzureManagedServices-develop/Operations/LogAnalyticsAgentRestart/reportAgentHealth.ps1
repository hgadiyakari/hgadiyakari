﻿#-----------------------------------------------------------[Comments]-------------------------------------------------------------
<#
.DOCUMENTATION LINK
https://confluence.dxc.com/display/CSA/AZR-11972+-+Remediation+Guide+enhancement+to+include+-+OMI+services+not+restarting+correctly+after+agent+upgrade

.SYNOPSIS
This PowerShell script collects data from log analytics to collect Microsoft Monitoring Agent data 
and report areas where health state can be assessed. The following information will be collected:
- Virtual machine name, Resourcegroup, Location, OS type and version, Subscription, Location, Workspace
- Heartbeat, Performance, Agent extension type (Monitoring, Diagnostics) and status
The script will create output files - the report in Excel format and a log file in text format.

This script also uses optional parameters to include a list of supported VMs to be indicated in the report and/or scope reporting 
- Run on all workspaces in all subscriptions (default).
- Run on on all workspaces in a target subscription
- Run on a target workspace in a subscription

.EXAMPLES
 .\reportAgentHealth.ps1 -dxcSubscriptionId <mySubscriptionId> -dxcLogAnalyticsWorkspaceName <myWorkspaceName> -dxcSupportedVMList <mySupportedVMs>
 .\reportAgentHealth.ps1 -dxcSubscriptionId <mySubscriptionId> -dxcLogAnalyticsWorkspaceName <myWorkspaceName>
 .\reportAgentHealth.ps1 -dxcSubscriptionId <mySubscriptionId> -dxcSupportedVMList <mySupportedVMs>
 .\reportAgentHealth.ps1 -dxcSupportedVMList <mySupportedVMs>

.REVISION HISTORY
    06-Feb-2020 - Initial script development
    17-Feb-2020 - Create scoping and function to validate Log Analytics workspaces in subscription
#>

#---------------------------------------------------------[Initializations]-------------------------------------------------------- 
[CmdletBinding(DefaultParameterSetName='allWorkspaces')]
Param(
    [Parameter(Mandatory=$false,ParameterSetName='allWorkspaces')]
    [Parameter(Mandatory=$true,ParameterSetName='singleWorkspace')]
    [Parameter(HelpMessage = "Please enter the Subscription Id.", Mandatory = $False, ValueFromPipeline = $True)]
    [ValidateNotNullOrEmpty()][string]$dxcSubscriptionId,

    [Parameter(HelpMessage = "Please enter the Log Analytics workspace name.", Mandatory = $False, ValueFromPipeline = $True)]
    [Parameter(ParameterSetName='singleWorkspace')]
    [ValidateNotNullOrEmpty()][string]$dxcLogAnalyticsWorkspaceName,

    [Parameter(Mandatory=$false,ParameterSetName='allWorkspaces')]
    [Parameter(Mandatory=$false,ParameterSetName='singleWorkspace')]
    [Parameter(HelpMessage = "Please enter file path for list of supported VMs.", Mandatory = $False, ValueFromPipeline = $True)]
    [ValidateNotNullOrEmpty()][string]$dxcSupportedVMList
)

#----------------------------------------------------------[Declarations]----------------------------------------------------------
$scriptName = "reportAgentHealth"
$ErrorActionPreference = 'SilentlyContinue'
$Global:LogFilePath = (Get-Item -Path .\ -Verbose).Fullname + '\' + $scriptName + '-{0:dd-MMM-yyyy_HHmm}' -f (Get-Date) + '.log'
$reportFile = (Get-Item -Path .\ -Verbose).Fullname + '\' + "AgentHealthReport" + '-{0:dd-MMM-yyyy_HHmm}' -f (Get-Date) + '.xlsx'
[PSObject[]]$resultsAllAgentHealth=@()
[PSObject[]]$Global:resultsAllWkspHBData=@()
[PSObject[]]$Global:resultsAllWkspPerfData=@()

#-----------------------------------------------------------[Functions]------------------------------------------------------------

function Write-Log { # This function writes script messages to active session and outputs to log file.
Param ([ValidateSet('Cyan','Gray','Green','Red','White','Yellow')][string]$logColor,
[string]$logText, [int]$logCode)

$logTimeStamp = Get-Date -Format MM-dd-yyyy-hh:mm:ss
switch ($logCode) {
    0 { Write-Output $logText | Tee-Object -FilePath $global:LogFilePath -Append | Out-Null;
        Write-Host -F $logColor $logText } # Use for general messages
    1 { Write-Output "$logTimeStamp INFO: $logText"| Tee-Object -FilePath $global:LogFilePath -Append | Out-Null;
        Write-Host -F $logColor "$logTimeStamp INFO: $logText" } # Use for Informational messages
    2 { Write-Output "$logTimeStamp ERROR: $logText"| Tee-Object -FilePath $global:LogFilePath -Append | Out-Null;
        Write-Host -F $logColor "$logTimeStamp ERROR: $logText" } # Use for Error messsages
    3 { Write-Output "$logTimeStamp WARN: $logText"| Tee-Object -FilePath $global:LogFilePath -Append | Out-Null;
        Write-Host -F $logColor "$logTimeStamp WARN: $logText" } # Use for Warning messages
}

}

function Run-PreChecks { # This function performs required prerequisite checks.

# Check for ImportExcel module
Write-Log White "Perform prerequisite checks." 1
$checkModule = Get-Module -Name ImportExcel -ListAvailable -ErrorAction $ErrorActionPreference
if ($checkModule -eq $null) {
    Install-Module ImportExcel -AllowClobber -Force -ErrorAction $ErrorActionPreference
    Write-Log White "Module ImportExcel installed successfully." 1
} else { Write-Log White "Module ImportExcel found." 1 } 

if ($error) { Write-Log Red "Installation of required module - ImportExcel failed. Try to install manually (refer to https://www.powershellgallery.com/packages/ImportExcel/5.4.2)." 2; exit}

# Check for valid input file for supported VMs
if (!($dxcSupportedVMList)) {
    Write-Log White "Supported VMs list not provided; will not check if supported by DXC." 3
} else { 
    if (Test-Path -Path $dxcSupportedVMList) {
        switch ($dxcSupportedVMList.Split(".")[-1]) {
            'csv' {$Global:dxcSupportedVMs = Import-CSV $dxcSupportedVMList -ErrorAction $ErrorActionPreference}
            'txt' {$Global:dxcSupportedVMs = Get-Content $dxcSupportedVMList -ErrorAction $ErrorActionPreference}
            'xls' {$Global:dxcSupportedVMs = Import-Excel $dxcSupportedVMList -ErrorAction $ErrorActionPreference}
            'xlsx' {$Global:dxcSupportedVMs = Import-Excel $dxcSupportedVMList -ErrorAction $ErrorActionPreference}
        }
        If ($error -or ($Global:dxcSupportedVMs -eq $null)) { Write-Log White "Failed to import VM list from the provided file path. Please ensure file contains valid input, path is correct and file type is either in .txt or .csv. Skipping DXC support check." 3
        } else { Write-Log White "Supported VMs list provided; will check if supported by DXC." 1 }
    } else { Write-Log White "Failed to import VM list from the provided file path. Please ensure file contains valid input, path is correct and file type is either in .txt or .csv. Skipping DXC support check." 3 }
}

if ($dxcSubscriptionId -and (!($dxcLogAnalyticsWorkspaceName))) {
    $Global:reportScope = 1; Write-Log Yellow ("Agent reporting will run on all workspaces in " + $dxcSubscriptionId) 1
} elseif ($dxcSubscriptionId -and $dxcLogAnalyticsWorkspaceName) {
    $Global:reportScope = 2; Write-Log Yellow ("Agent reporting will run on " + $dxcLogAnalyticsWorkspaceName + " in " + $dxcSubscriptionId) 1
} else {
    $Global:reportScope = 3; Write-Log Yellow "Agent reporting will run on all workspaces in all subscriptions you have access to." 1
}

Write-Log White "Prerequisite checks completed." 1
}

function Get-LogAnalyticsData {
Param ($dxcWorkspace)

[PSObject[]]$resultsAllHBData=@()

# Get current subscription
$currentAzSub = Get-AzContext

# Log Analytics query for Heartbeat and Performance
$queryHBData = @"
Heartbeat
| where TimeGenerated > ago(30m)
| summarize by Resource, Computer, Category, OSType, OSName, OSMajorVersion, OSMinorVersion, Version
"@

$queryPerfData = @"
let RecentPerf = Perf | where TimeGenerated > ago(30m) | summarize by Computer;
Heartbeat
| where TimeGenerated > ago(30m)
| where Computer in (RecentPerf)
| summarize by Resource, Computer, ResourceGroup, OSType, Version, OSName
"@

Write-Log Cyan ("Collecting Heartbeat and Performance data from " + $dxcWorkspace.Name + " in " + $currentAzSub.Subscription.Name + " ...") 1

    # Gather Log Analytics workspace information
    $dxcLogAnalyticsWorkspaceId = $dxcWorkspace.CustomerId
    $dxcLogAnalyticsWorkspaceKey = ($dxcWorkspace | Get-AzOperationalInsightsWorkspaceSharedKey -WarningAction Ignore).PrimarySharedKey
    if ($error) { Write-Log Gray ("Unable to fetch Log Analytics workspace. Skipping " + $currentAzSub.Subscription.Name) 3}

    # Query Heartbeat and Performance data from Log Analytics workspace
    $resultsHBData = (Invoke-AzOperationalInsightsQuery -Workspace $dxcWorkspace -Query $queryHBData).Results

        if ($error -or ($resultsHBData.Resource -eq $null)) { Write-Log Gray "No Heartbeat data collected. $error" 3; $error.clear() 
        } else {
            $resultsAllHBData = [System.Linq.Enumerable]::ToArray($resultsHBData)
            $resultsAllHBData | Add-Member -MemberType NoteProperty -Name "WorkspaceId" -Value $dxcLogAnalyticsWorkspaceId
            $resultsAllHBData | Add-Member -MemberType NoteProperty -Name "WorkspaceKey" -Value $dxcLogAnalyticsWorkspaceKey
            Write-Log White ("Heartbeat data collected from " + $dxcWorkspace.Name + "`n" + ($resultsAllHBData | Ft -AutoSize | Out-String)) 1
        }     
    $resultsPerfData = (Invoke-AzOperationalInsightsQuery -Workspace $dxcWorkspace -Query $queryPerfData).Results
        if ($error -or ($resultsPerfData.Resource -eq $null)) { Write-Log Gray "No Performance data collected. $error" 3; $error.clear() 
        } else {
            Write-Log White ("Performance data collected from " + $dxcWorkspace.Name + "`n" + ($resultsPerfData | Ft -AutoSize | Out-String)) 1
            $Global:resultsAllWkspPerfData+=$resultsPerfData
        }

    $Global:resultsAllWkspHBData+=$resultsAllHBData
}

#-----------------------------------------------------------[Execution]------------------------------------------------------------

try {
$error.Clear()

# Create the log file
New-Item $Global:LogFilePath -ItemType File | Out-Null

Write-Log Yellow "Script execution started." 1

# Run prerequisite checks
Run-PreChecks 
if ($error) { Write-Log Red $error 2; exit }

# Login to Azure
Write-Log Cyan "Please login to Azure Resource Manager." 0
Connect-AzAccount | Out-Null
if ($error) { Write-Log Red "Unable to connect to Azure. Check your internet connection and verify authentication details." 2; exit }
Write-Log Cyan "Connected to Azure with provided authentication." 0
Sleep 3

if (($Global:reportScope -eq 1) -or ($Global:reportScope -eq 2)) {
    $myAzSubscriptions = Get-AzSubscription | ? {$_.State -eq 'Enabled' -and $_.Id -like "$($dxcSubscriptionId)*"}
        if ($myAzSubscriptions -eq $null) { Write-Log Red "Unable to find the subscription provided." 2; exit } 
} else {
    $myAzSubscriptions = Get-AzSubscription | ? {$_.State -eq 'Enabled'}
}
    Write-Log White "List of target subscriptions:`n" 1
    Write-Log White ($myAzSubscriptions | Out-String) 0 

foreach ($azSubs in $myAzSubscriptions) {

$azCurrentSubs = Select-AzSubscription -Subscription $azSubs.Id

    # Gather Log Analytics workspace information
    if ($Global:reportScope -eq 2) {
        $dxcLogAnalyticsWorkspace = Get-AzOperationalInsightsWorkspace | ? {$_.Name -like "$($dxcLogAnalyticsWorkspaceName)*"}   
    } else {
        $dxcLogAnalyticsWorkspace = Get-AzOperationalInsightsWorkspace
    }
    
    # Validate all workspace resources in current subscription
    if (($dxcLogAnalyticsWorkspace.Count -eq $null) -or ($dxcLogAnalyticsWorkspace.Count -eq 0)) {
        Write-Log Red ("No Log Analytics workspace found in " + $azCurrentSubs.Name) 2; continue
    } elseif ($dxcLogAnalyticsWorkspace.Count -eq 1) {
        Write-Log Green ("Workspace found in subscription: " + $dxcLogAnalyticsWorkspace.Name) 1
        Get-LogAnalyticsData $dxcLogAnalyticsWorkspace
    } else {
        Write-Log Green ("Workspaces found in subscription: `n" + ($dxcLogAnalyticsWorkspace.Name | ft -a | Out-String)) 1
        foreach ($workspace in $dxcLogAnalyticsWorkspace) {
            Get-LogAnalyticsData $workspace
        }
    }

    # Gather all running/powered on VMs in subscription
    Write-Log Cyan ("Collecting VM data on all running VMs in " + $azCurrentSubs.Name) 1
    $allVMs += Get-AzVM -status | ? {$_.PowerState -match "running"}
        if ($allVMs -eq $null) { Write-Log Gray "No running VMs found in subscription." 3; continue }

    foreach ($vm in $allVMs) {
        # VM Details
        $vmDetailedInfo = Get-AzVM -ResourceGroupName $vm.ResourceGroupName -Name $vm.Name
        $vmExtensionInfo = Get-AzVMExtension -ResourceGroupName $vmDetailedInfo.ResourceGroupName -VMName $vmDetailedInfo.Name
        $vmOSVersion = $vmDetailedInfo.StorageProfile.ImageReference
        $vmIsSupported = if (($Global:dxcSupportedVMs -ne $null) -and ($Global:dxcSupportedVMs -like "$($vmDetailedInfo.Name)*")) { $true 
            } elseif ($Global:dxcSupportedVMs -eq $null) { $null } else { $false }
        $vmIsHB = if ($Global:resultsAllWkspHBData | ? {$_.Resource -like "$($vmDetailedInfo.Name)*"}) { $true
            $vmWorkspaceInfo = $Global:resultsAllWkspHBData | ? {$_.Resource -like "$($vmDetailedInfo.Name)*"} | select Resource, WorkspaceId, WorkspaceKey
        } else { $false }
        $vmIsPerf = if ($Global:resultsAllWkspPerfData | ? {$_.Resource -like "$($vmDetailedInfo.Name)*"}) { $true } else { $false }
        
        # Log Analytics and other agent extension information
        if (($vmExtensionInfo.ExtensionType -eq 'OmsAgentForLinux') -or ($vmExtensionInfo.ExtensionType -eq 'MicrosoftMonitoringAgent')) {
            $vmAgent = ($vmExtensionInfo | ? {($_.ExtensionType -eq 'OmsAgentForLinux') -or ($_.ExtensionType -eq 'MicrosoftMonitoringAgent')}).ExtensionType
            $vmAgentStatus = ($vmExtensionInfo | ? {($_.ExtensionType -eq 'OmsAgentForLinux') -or ($_.ExtensionType -eq 'MicrosoftMonitoringAgent')}).ProvisioningState
        } else { $vmAgent = $null; $vmAgentStatus = $null }
        if ($vmExtensionInfo.ExtensionType -eq 'DependencyAgentLinux' -or 'DependencyAgentWindows' -or 'LinuxDiagnostic') {
            $vmDA = ($vmExtensionInfo | ? {($_.ExtensionType -eq 'DependencyAgentLinux') -or ($_.ExtensionType -eq 'DependencyAgentWindows')}).ExtensionType
            $vmDAStatus = ($vmExtensionInfo | ? {($_.ExtensionType -eq 'DependencyAgentLinux') -or ($_.ExtensionType -eq 'DependencyAgentWindows')}).ProvisioningState
            $vmLAD = if ($vmExtensionInfo | ? {$_.ExtensionType -eq 'LinuxDiagnostic'}) { $true }
            $vmLADStatus = ($vmExtensionInfo | ? {$_.ExtensionType -eq 'LinuxDiagnostic'}).ProvisioningState
        } else { $vmDA = $null; $vmDAStatus = $null; $vmLAD = $null; $vmLADStatus }
        
        # Write result set for report output
        $resultsVMAgentHealth = New-Object -TypeName PSCUstomObject
        $resultsVMAgentHealth | Add-Member -MemberType NoteProperty -Name "VMName" -Value $vmDetailedInfo.Name
        $resultsVMAgentHealth | Add-Member -MemberType NoteProperty -Name "ResourceGroupName" -Value $vmDetailedInfo.ResourceGroupName
        $resultsVMAgentHealth | Add-Member -MemberType NoteProperty -Name "SubscriptionId" -Value $azSubs.Id
        $resultsVMAgentHealth | Add-Member -MemberType NoteProperty -Name "SubscriptionName" -Value $azSubs.Name
        $resultsVMAgentHealth | Add-Member -MemberType NoteProperty -Name "Location" -Value $vmDetailedInfo.Location
        $resultsVMAgentHealth | Add-Member -MemberType NoteProperty -Name "WorkspaceId" -Value $vmWorkspaceInfo.WorkspaceId
        $resultsVMAgentHealth | Add-Member -MemberType NoteProperty -Name "WorkspaceKey" -Value $vmWorkspaceInfo.WorkspaceKey
        $resultsVMAgentHealth | Add-Member -MemberType NoteProperty -Name "OSType" -Value $vmDetailedInfo.StorageProfile.OsDisk.OsType
        $resultsVMAgentHealth | Add-Member -MemberType NoteProperty -Name "OSVersion" -Value ($vmOSVersion.Publisher +" "+ $vmOSVersion.Offer +" "+ $vmOSVersion.Sku +" "+ $vmOSVersion.Version)
        $resultsVMAgentHealth | Add-Member -MemberType NoteProperty -Name "IsSupported" -Value $vmIsSupported
        $resultsVMAgentHealth | Add-Member -MemberType NoteProperty -Name "Heartbeat" -Value $vmIsHB
        $resultsVMAgentHealth | Add-Member -MemberType NoteProperty -Name "Performance" -Value $vmIsPerf
        $resultsVMAgentHealth | Add-Member -MemberType NoteProperty -Name "LogAnalyticsAgent" -Value $vmAgent
        $resultsVMAgentHealth | Add-Member -MemberType NoteProperty -Name "LogAnalyticsAgentProvisioningStatus" -Value $vmAgentStatus
        $resultsVMAgentHealth | Add-Member -MemberType NoteProperty -Name "DependencyAgent" -Value $vmDA
        $resultsVMAgentHealth | Add-Member -MemberType NoteProperty -Name "DependencyAgentProvisioningStatus" -Value $vmDAStatus
        $resultsVMAgentHealth | Add-Member -MemberType NoteProperty -Name "LinuxDiagnosticAgent" -Value $vmLAD
        $resultsVMAgentHealth | Add-Member -MemberType NoteProperty -Name "LinuxDiagnosticProvisioningStatus" -Value $vmLADStatus
        $resultsAllAgentHealth+=$resultsVMAgentHealth

}
    $allVMs = $null
    Write-Log Cyan ("Data collection completed for " + $azCurrentSubs.Name) 1
    $error.clear()
}

} catch {
Write-Log Red "Script executed with errors. $error." 2

} finally {
if ($resultsAllAgentHealth -ne $null) {
    $resultsAllAgentHealth | Export-Excel -WorksheetName "AgentHealth" -Path $reportFile -Append -Show
    Write-Log Green "Agent Health report created, see $reportFile." 1
} else { 
    if ($error) { Write-Log Red "Unable to create the AgentHealth report. $error" 2 
    } else { Write-Log Gray "No data collected, nothing to report." 3 }
} 

Disconnect-AzAccount | Out-Null
Write-Log Cyan "Disconnected from Resource Manager." 0
Write-Log Yellow "Script execution finished. Refer to log - $Global:LogFilePath." 1

}
