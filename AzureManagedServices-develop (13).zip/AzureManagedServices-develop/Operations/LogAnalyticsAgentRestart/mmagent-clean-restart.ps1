﻿
try {
$error.clear()
Get-Service -Name HealthService -ErrorAction SilentlyContinue | Out-Null
    if ($error) {
        Write-Output "MicrosoftMonitoringAgent is not installed."; exit
    } else {
        Stop-Service -Name HealthService -Force -Verbose
        if ($error) { Write-Output "Unable to terminate service - MicrosoftMonitoringAgent."; exit
        } else {
            # Write-Output "Successfully stopped service - MicrosoftMonitoringAgent. Initiating restart..."
            Start-Service -Name HealthService -Verbose
            Start-Sleep -Seconds 5
            $checkSvc = if ((Get-Service -Name HealthService).Status -eq 'Running') {
                Write-Output "MicrosoftMonitoringAgent restarted successfully."
            } else {
                Write-Output "Failed to restart MicrosoftMonitoringAgent. $error."
            }
        }
    }
return $checkSvc
} catch {
Write-Output "Failed to restart MicrosoftMonitoringAgent. $error."
} finally {

}