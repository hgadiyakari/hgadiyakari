
## Azure - Release deployment wrapper script

### Overview

This is a PowerShell script that is used as a wrapper for the following release deployment scripts:
- deployAlerts.ps1 (used for Onboarding/upgrade, located under ..\OnBoarding\Alerting\Alerts)
- deployHBAlertFunctions.ps1 (used for Onboarding/upgrade, located under ..\OnBoarding\Alerting\HeartbeatAlertDeployment)
- deployMetricAlertFunctions.ps1 (used for Onboarding/upgrade, located under ..\OnBoarding\Alerting\MetricAlertDeployment)
- deployFunctionAppAlerts.ps1 (used for Onboarding/upgrade, located under ..\OnBoarding\Alerting\FunctionAppAlertDeployment)
- deploySNOWConnectionMonitoringFunctionApp.ps1 (used for Onboarding/upgrade, located under ..\Alerting\SNOWConnectionMonitoringAlertDeployment)
- removeAlerts.ps1 (used for Onboarding/upgrade, located under ..\OnBoarding\Alerting\Cleanup)
- deploySelfHeal.ps1 (includes deployAlertRule.ps1; located under ..\Operations\Selfheal)

This script utilizes an input file in JSON format which contains the required parameters and controls execution of the deployment script/s on multiple targets (subscription).
It provides an option for selective execution of specific scripts via an interactive menu.  The script can also be executed in "automation" mode which allows for integration into a DevOps pipeline.  This mode will not present an interactive screen for users and will automaticlally run all included upgrade scripts.


#### Required files
- runWrapperScript.ps1 - PowerShell script that will execute as a wrapper for deployment scripts
- dxcCustomer_params.CSV - CSV file that contains all customer metadata and mandatory parameters that will be applied accordingly to deployment scripts. 

    | Field | Description |
    |:--- |:--- 
    | TenantId | Azure Tenant Id |
    | SubscriptionId | Azure subscription that is associated to the Tenant Id (supplied in the parameter) |
    | LogAnalyticsWorkspaceName | Name of the managed log analytics workspace |
    | AlertNotificationEmail | Email address required in deployAlerts.ps1 script |
    | AzureStack(Yes/No) | Use default values only: *Yes* or *No*, required in deployHBAlertFunctions.ps1 and deployMetricAlertFunctions.ps1 |
    | ServiceNowURL | ServiceNow Url required in deployAlerts.ps1 script |
    | UpgradeFunctionCodes(Auto/Yes) | Use default values only: *Auto* or *Yes*, required in deployHBAlertFunctions.ps1 and deployMetricAlertFunctions.ps1 scripts |
    | UpgradeEnvVariables(Auto/Yes) | Use default values only: *Auto* or *Yes*, required in deployHBAlertFunctions.ps1 and deployMetricAlertFunctions.ps1 scripts |
    | KeyVault | Key vault were ServiceNow credentials are stored, required in deployFunctionAppAlerts.ps1 script |
    | CustomTrace(Yes/No) | Use default values only: *Yes* or *No*, required in deployFunctionAppAlerts.ps1 script |


#### Syntax
This executes all the deployment scripts against the list of subscriptions provided in the JSON file.
    ```
    .\runWrapperScript.ps1
    ```

### Prerequisites
This section lists the requirements to prepare the environment for the script to run correctly.
1. Role-based access with Owner privileges to the subscription
2. PowerShell Core version 7
3. PowerShell Az module version 4.0 or higher
4. Latest version of Azure modules

### How to run the automation script
1. Modify the CSV file (dxcCustomer_params.csv) and enter the appropriate values to be used as parameters for the deployment script. 
2. Open PowerShell Core (run as Administrator) and switch to script directory ***AzureOffering_ServiceNow\Operations***.
3. Execute the command -
    ```
    .\runWrapperScript.ps1
    ```
    a. Once the script executes, you will prompted for logon and a selection of deployment scripts. Type in your choice following values as shown in the menu.   
    ```
        CONFIRM: Please select which deployment scripts you want to execute.
        Enter option [1] for deployAlerts.ps1
        Enter option [2] for deployHBAlertFunctions.ps1
        Enter option [3] for deployMetricAlertFunctions.ps1
        Enter option [4] for deploySNOWConnectionMonitoringFunctionApp.ps1
        Enter option [5] for deployFunctionAppAlerts.ps1
        Enter option [6] for removeAlerts.ps1
        Enter option [7] for deploySelfheal.ps1
        For multiple selections, type in the number/s separated by a comma (,).
        Type [all] to execute ALL scripts listed above or [quit] to exit deployment wrapper:
    ```
    Note: Only numeric values within the range listed in the menu will be valid when selecting scripts. If you type 'all', all the scripts will be deployed in sequence as listed. If you type in 'quit', script will be terminated.

    b. Press 'Enter' to proceed with your selection.
4. Wait until the script execution completes.
5. A log file will be created and saved to the script directory for review.

### Run in "automation" mode
1. Execute the command with automation switch -
    ```
    .\runWrapperScript.ps1 -automation
    ```
    All included upgrade functions will be executed just as if selecting the 'all' option above, but no interactive screen will be presented to the user.
