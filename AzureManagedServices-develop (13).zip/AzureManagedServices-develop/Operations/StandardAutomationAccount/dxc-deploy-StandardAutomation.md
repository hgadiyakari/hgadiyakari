## dxc-deploy-StandardAutomation.ps1 Description
Script to create automation account, service principal, connection and import runbooks with draft schedules.
#### Requirements
- Existing Resource Groups
- Module Az v2+, Az.Accounts Az.Automation Az.KeyVault Az.Resources Az.Storage
- Owner rights on subscription to add permission, script will check and ignore this step if user do not have rights.
Note: Rights maybe assigned specificaly for required resources only, all is up to enviroment security rules and what Automation Account supose to do.
#### Note:
- Resource names can be specified or if not specified new ones will be created in the same ResourceGroup.
- Names of resources will be generated as following:
    - Automation Account:  DXC-<CustomerCode>-<First 4 letters of Subscription>-StandardAutomationAccount
    - Application/Principal name the same as Automation Account
    - KeyVault: DXC-Maint-KV-<CustomerCode>-<First 4 letters of Subscription>
    - Storage Account(CAP lowered): dxc<customercode><first 4 letters of subscription>st4runbooks
    - Storage Account Container: container4automationrunbooks
- If script './dxc-deploy-StandardAutomation.ps1' encounters errors and does not exits, let it continue and later fix source of errors and rerun script. Important errors will exit script. Script skips existing resources. Script do not delete or overwrite any items. If you do not have rights to create Service Principal(Tenant App registration) then please ignore errors on 2a-f steps and do them manually.
#### Script Parameters
- Mandatory:
    - tenantId,                     #Tenant ID
    - subscriptionId,                        #Subscription ID
    - dxcAAResourceGroup,                  #Automation Account ResourceGroup, can be DXC-Maint or any other
    - dxcCustomerCompanyCode,       #Client Code the same as SNOW
- Optional:
    - AutomationAccountName,        #Automation Account and Application name if needed to use specific naming
    - Location,                     #if Location parameter not specified Location will be taken from Automation Account ResourceGroup
    - KeyVaultRG,                   #Keyvault ResourceGroup if KV is not in the same ResourceGroup
    - KeyVaultName,                 #Keyvault Name if KV is not in the same ResourceGroup
    - dxcStorageAccountName,        #Storage Account Name if needed to use some specific one
    - dxcStorageAccountRG           #Storage Account ResourceGroup if needed to use some specific one
    - dxcStorageAccountContainer    #Storage Container name if needed to use some specific one
#### Examples
- .\dxc-deploy-StandardAutomation.ps1 -tenantId ... -subID ... -DXCAARGName ... -dxcCustomerCompanyCode ...
- .\dxc-deploy-StandardAutomation.ps1 -tenantId ... -subID ... -DXCAARGName ... -dxcCustomerCompanyCode ... -KeyVaultRG ... -KeyVaultName ...
#### Deployment steps
    1. Create the Automation Account
    1a. Import required modules
    2a. Find the KeyVault or create a new one
    2b. Generate a new cert in the KeyVault and store it in the local temp folder
    2c. Create the SP for the Automation Account to "RunAs"
    2d. Add certificate to Automation Account
    2e. Create Connection "RunAs"
    2f. Add Contributor rights on Subscription for ServicePrincipal
    3a. Upload the RunBooks from Directory
    3b. Create schedules from Directory (schedule name: dxcRunbookName1-scheduleName1)
    3c. Associate the schedules with Runbooks
    4.  Create AutomationAccount Variables
    5a. Create Storage account for downloaded scripts to be stored and attached to VM if needed.
    5b. Create Storage account Container for download and for VM to access script 
#### Deployment steps diagram
<IMG SRC="dxc-deploy-StandardAutomation.png" width="800" >
