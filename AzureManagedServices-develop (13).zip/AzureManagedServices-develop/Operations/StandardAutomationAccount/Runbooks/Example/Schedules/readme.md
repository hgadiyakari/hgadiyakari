#### Folder meant to store Schedule deployment scripts for Invoke-VMCommand runbook.
  Create scripts as many Schedules needed. One Script per one Schedule.\
  Inside script you will find variables section:

    ####################################################################################
    #edit here(bellow) if need custom variables/values/parameters
    # Schedule specific configuration:
    $ShedulleName = $ShedulleName           # change if not happy with standard runbook-schedule name or need to follow with naming standards
    $StartTime = (Get-Date).AddMinutes(30)  # start in 30 min, or specify exact time starting tomorrow (Get-Date "00:00:00").AddDays(1)
    $IntervalName = "HourInterval"          # One of: HourInterval|DayInterval|WeekInterval|MonthInterval 
    $IntervalValue = "1"                    # On Interval options see 'New-AzAutomationSchedule' documentation
    $disableSchedule = "yes"                # "yes" to disable Schedule for now, or any other value is to skip this step.
    # Runbook specific configuration(add parameters how many you need):
    $RBS_params = @{                        # Parameters to use with Runbook, add values after Application is installed and enable schedule
        "Param1" = "HelloWorld"             # any type of string, like a ResourceGroup
        "Param2" = "FirstName LastName"     # strings devided by space, to use as array.
        "Param3" = "Name=First Sub=Last"    # strings pairs devided by space, to use as object.
    }                                       # Note: do not use ' or \', PowerShell Register-AzAutomationScheduledRunbook command do not accept those.
    ####################################################################################

This is the place where you customise your own values(see code above) and can add custom items under 6.3 step.

Remember to remove exit at line 15 to run this script and change disableSchedule to enable schedules.
