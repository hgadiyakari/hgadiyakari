# =======================================================
# - script to create automation account schedule and register with runbook, schedules are to be edited later on to add corect values when they are kown.
# - AUTHOR: Dalius Varkulevicius, draft-general-example, Nov 18-28, 2019
# =======================================================
[CmdletBinding(SupportsShouldProcess=$true)]
Param
    (
    [Parameter(Mandatory=$true)] [String]$RG,
    [Parameter(Mandatory=$true)] [String]$RunbookName,
    [Parameter(Mandatory=$true)] [String]$AutomationAccountName,
    [parameter(Mandatory=$false)] [object]$storageContext
    )
$?.Clear

####################################################################################
# Prepaire variables
# 6.1. Create Schedule
# 6.2. Register Schedule with runbook
# 6.3. Custom addon
####################################################################################

#create schedule name by combining runbook and schedule file names
$ShedulleName = $MyInvocation.MyCommand.Name
$ShedulleName= $ShedulleName -replace '\s',''
$ShedulleName= $ShedulleName -replace '\.ps1',''
$ShedulleName = "RunbookSchedule-" + $RunbookName + "-" + $ShedulleName

####################################################################################
    #edit here(bellow) if need custom variables/values/parameters
          # Schedule specific configuration:
    $ShedulleName = $ShedulleName           # change if not happy with standard runbook-schedule name or need to follow with naming standards
    $StartTime = (Get-Date).AddMinutes(30)  # start in 30 min, or specify exact time starting tomorrow (Get-Date "00:00:00").AddDays(1)
    $IntervalName = "HourInterval"          # One of: HourInterval|DayInterval|WeekInterval|MonthInterval 
    $IntervalValue = "1"                    # On Interval options see 'New-AzAutomationSchedule' documentation
    $disableSchedule = "yes"                 # "yes" to disable Schedule for now, or any other value is to skip this step.
          # Runbook specific configuration(add parameters how many you need):
    $RBS_params = @{                        # Parameters to use with Runbook, add values after Application is installed and enable schedule
        "Param1" = "HelloWorld"             # any type of string, like a ResourceGroup
        "Param2" = "FirstName LastName"     # strings devided by space, to use as array.
        "Param3" = "Name=First Sub=Last"    # strings pairs devided by space, to use as object.
    }                                       # Note: do not use ' or \', PowerShell Register-AzAutomationScheduledRunbook command do not accept those.
####################################################################################

Write-output "6.1 - Create Schedule $ShedulleName"
$result = Get-AzAutomationSchedule -AutomationAccountName $AutomationAccountName -Name $ShedulleName -ResourceGroupName $RG -erroraction 'silentlycontinue'
if ($result) { write-output "Schedule $ShedulleName exists, skipping." }
Else {
    if ($IntervalName -eq "HourInterval") { New-AzAutomationSchedule -AutomationAccountName $AutomationAccountName -Name $ShedulleName -ResourceGroupName $RG -StartTime $StartTime -HourInterval $IntervalValue }
    if ($IntervalName -eq "DayInterval") { New-AzAutomationSchedule -AutomationAccountName $AutomationAccountName -Name $ShedulleName -ResourceGroupName $RG -StartTime $StartTime -DayInterval $IntervalValue }
    if ($IntervalName -eq "WeekInterval") { New-AzAutomationSchedule -AutomationAccountName $AutomationAccountName -Name $ShedulleName -ResourceGroupName $RG -StartTime $StartTime -WeekInterval $IntervalValue }
    if ($IntervalName -eq "MonthInterval") { New-AzAutomationSchedule -AutomationAccountName $AutomationAccountName -Name $ShedulleName -ResourceGroupName $RG -StartTime $StartTime -MonthInterval $IntervalValue }
    #disable schedule
    if ($disableSchedule -eq "yes") { Set-AzAutomationSchedule -AutomationAccountName $AutomationAccountName -Name $ShedulleName -ResourceGroupName $RG -IsEnabled 0 }
}
####################################################################################
#register your runbook with schedule if parameters are not needed or you are installing with known $RBS_params parameters.
Write-output "6.2 - Register Schedule $ShedulleName with Runbook $RunbookName"
$result = Get-AzAutomationScheduledRunbook -AutomationAccountName $AutomationAccountName -ResourceGroupName $RG -RunbookName $RunbookName -ScheduleName $ShedulleName -erroraction 'silentlycontinue'
if ($result) { Write-output "Registration exists, skipping." }
else { 
    Register-AzAutomationScheduledRunbook -AutomationAccountName $AutomationAccountName -ResourceGroupName $RG -RunbookName $RunbookName -ScheduleName $ShedulleName -Parameters $RBS_params 
}
####################################################################################

#upload script to storage, example how you can add custom items to your automation.
#Write-output "6.3. Custom addon"
