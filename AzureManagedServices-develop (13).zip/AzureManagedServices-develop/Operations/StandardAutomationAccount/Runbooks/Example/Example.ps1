# =======================================================
# - Example runbook
# - AUTHOR: Dalius Varkulevicius, Dec 2, 2019
# =======================================================
Param
    (
        [parameter(Mandatory=$true)] [String]$Param1,   # any type of string, like a ResourceGroup
	[parameter(Mandatory=$false)] [string]$Param2,  # strings devided by space, to use as array.
        [parameter(Mandatory=$false)] [String]$Param3   # strings pairs devided by space, to use as object.
    )
    
#verbose stream output enablement in test output pane
#$VerbosePreference = "Continue"

try{

    #Param1 - simple string
    write-verbose "verbose $Param1"       #verbose will be visible only if you enable VerbosePreference.
    write-output "$Param1"
    
    #Param2 - array
    $Param2array = $Param2 -split ' '
    foreach($Par2 in $Param2array){
        write-verbose "verbose $Par2"
        write-output "$Par2"
    }
    
    #Param3 - object
    $Param3array = $Param3 -split ' '
    foreach($Par3 in $Param3array){
        $par3obj = $Par3 -split '='
        $par3first = $par3obj[0]
        $par3second = $par3obj[1]
        write-verbose "verbose $par3first and $par3second"
        write-output "$par3first and $par3second"
    }
    
    #variables
     $var = Get-AutomationVariable  –Name 'dxcResourceGroup'
     write-output "dxcResourceGroup $var"
     $var = Get-AutomationVariable  –Name 'dxcAutomationAccountName'
     write-output "dxcAutomationAccountName $var"
     $var = Get-AutomationVariable  –Name 'dxcStorageAccountRG'
     write-output "dxcStorageAccountRG $var"
     $var = Get-AutomationVariable  –Name 'dxcStorageAccountName'
     write-output "dxcStorageAccountName $var"
     $var = Get-AutomationVariable  –Name 'dxcStorageAccountContainer'
     write-output "dxcStorageAccountContainer $var"
     $var = Get-AutomationVariable  –Name 'dxcKeyVaultRG'
     write-output "dxcKeyVaultRG $var"
     $var = Get-AutomationVariable  –Name 'dxcKeyVaultName'
     write-output "dxcKeyVaultName $var"
    
    #Connection
    $connection = Get-AutomationConnection -Name AzureRunAsConnection
    write-output $connection

}#try
catch{
    $Error[0]
}
