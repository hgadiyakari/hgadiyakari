#### Schedules for Invoke-VMCommand Runbook
Folder contains scripts that will deploy Schedules, Schedules registration to Runbooks and aditional step to upload scripts to storage account.
- Schedule-BootUpSync-WinTest.ps1 will deploy Schedule and register with Runbook, also uplaods script Scripts/example-BootUpSync-timechecks.ps1 for Windows
- Schedule-BootUpSync-LinuxTest.ps1 will deploy Schedule and register with Runbook, also uplaods script Scripts/example-BootUpSync-timechecks.sh for Linux
