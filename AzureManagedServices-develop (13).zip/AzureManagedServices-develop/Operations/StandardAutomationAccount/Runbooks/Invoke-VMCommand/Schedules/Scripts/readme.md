## Script examples for Runbook Invoke-VMCommand.
2 scripts were created to demonstrate how to run scripts, how to use parameters and how to get output(job or events in system/syslog). Scripts developed as example, on how to integrate ouput with Log Analytics. Runbook-Schedule-Script-LAWorkspace-Alert-SNOW.
#### Scripts will check-test System Boot time, Uptime and Time synchronization offset.
- example-BootUpSync-timechecks.sh Linux Bash script
- example-BootUpSync-timechecks.ps1 Windows PS script
