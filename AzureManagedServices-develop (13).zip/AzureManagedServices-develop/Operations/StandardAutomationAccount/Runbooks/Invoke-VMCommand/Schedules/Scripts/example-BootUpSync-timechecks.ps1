#Powershell
############################################################################################################
# Script description: Windows Script is developed as example to get Boottime, Uptime, Synctime and send to System(or other) log
# Script date/version/author/change: 2019-Dec-13 / 0.1 / Dalius Varkulevicius / new
############################################################################################################
Param
    (
        [parameter(Mandatory=$false)] [String]$Eventidnr,
        [parameter(Mandatory=$false)] [string]$LogName,
        [parameter(Mandatory=$false)] [string]$logSource
    )
#functions
function Get-SystemUptime {
    $operatingSystem = Get-WmiObject Win32_OperatingSystem
    $uptime = $((Get-Date) - ([Management.ManagementDateTimeConverter]::ToDateTime($operatingSystem.LastBootUpTime)))
    $returnval = 'Uptime: ' + $uptime.days + ' days, ' + $uptime.hours + ' hours, ' + $uptime.minutes + ' minutes. '
    return $returnval
}
function Get-SystemBoottime {
    $operatingSystem = Get-WmiObject Win32_OperatingSystem
    $bttime = $([Management.ManagementDateTimeConverter]::ToDateTime($operatingSystem.LastBootUpTime))
    $returnval = 'Boot time: ' + $bttime + '. '
    return $returnval
}
function Get-SystemSynctime {
    $peer = w32tm /query /peers | findstr 'Peer: ' | select-object -first 1
    $peer = $peer -split ' '; $peer = $peer[1]; $peer = $peer -split ','; $peer = $peer[0]
    $offset = w32tm /monitor /computers:$peer | findstr 'NTP: ' | select-object -first 1
    $offset = $offset -split ':'
    $returnval = 'System time sync status:' + $offset[1] + '.'
    return $returnval
}

#if parameters not provided, use default
if (-not $Eventidnr ) { $Eventidnr = "11081" } #As example your AZR story ID, this will be your EventID, double check not to log event on actual Windows errors, see google
if (-not $LogName ) { $LogName = "System" } #log to System EventLog
if (-not $logSource ) { $logSource = "DXCAzureRunbook" } #Event Source name

#script, check if Log source exists, if not create
if (![System.Diagnostics.EventLog]::SourceExists($logSource)) {
        New-EventLog -LogName $LogName -Source $logSource
}

#main
#script, check if required Shared folders exists
$get1 = Get-SystemBoottime
$get2 = Get-SystemUptime
$get3 = Get-SystemSynctime
$msg = "$get1 $get2 $get3"
#$msg

#script, write log, if all is good informational, if not error type.
Write-Eventlog -LogName $LogName -Source $logSource -EntryType "Information" -EventID $Eventidnr -Message $msg
write-output $msg
