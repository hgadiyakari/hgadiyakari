#!/bin/bash
############################################################################################################
# Script description: Linux Script is developed as example to get Boottime, Uptime, Synctime and send to system(or o$
# Script date/version/author/change: 2019-Dec-13 / 0.1 / Dalius Varkulevicius / new
############################################################################################################
#reset variables
vrboottime=''; vruptime=''; d1=''; d2=''; dd=''; msg=''; Eventidnr=''; LogName=''; logSource=''
par2=''; par1=''; par3='';
for var in "$@"  #export parameters as variables and values pairs
do
   if [[ "$var" == *"="* ]]; then #check for pairs
      IFS='=' read -r -a array <<< "$var" 
      export "${array[0]}"="${array[1]}"
   fi
done
#if parameters not provided, use default
if [[ -z $Eventidnr ]]; then Eventidnr='11081'; fi
if [[ -z $LogName ]]; then LogName='Syslog'; fi #This one cannot be changed as logger only logs to syslog, create other solution, this is only example.
if [[ -z $logSource ]]; then logSource='DXCAzureRunbook'; fi
#get boot time
vrboottime=$(uptime -s)
#get uptime
vruptime=$(uptime -p)
#1 get remote server $d2, ntp time, convert to seconds, udp port 123
    d2=$(date '+%s' -d@$((0x`printf c%47s|nc -uw1 pool.ntp.org 123|xxd -s40 -l4 -p`-64#23GDW0)))
    #get local time $d1
    d1=$(date '+%s' -d "$(date +'%y-%m-%d %H:%M:%S')")
    #echo $d1 $d2
#2 get remote server $d2, nist time, convert to seconds, tcp port 13
if [[ -z $d2 ]]; then
    d2=$(date '+%s' -d "$(cat </dev/tcp/time.nist.gov/13 | grep UTC | cut -d' ' -f2-3)")
    d1=$(date '+%s' -d "$(date +'%y-%m-%d %H:%M:%S')")
    #echo $d1 $d2
fi
#3 get remote server $d2, nist time, convert to seconds, tcp port 13
if [[ -z $d2 ]]; then
    d2=$(date '+%s' -d "$(nc -w1 ut1-wwv.nist.gov 13 | grep UTC | cut -d' ' -f2-3)")
    d1=$(date '+%s' -d "$(date +'%y-%m-%d %H:%M:%S')")
    #echo $d1 $d2
fi
#compare local from remote
dd=$(expr $d1 - $d2)
#dispose of negative sign
#dd=${dd/#-/}
#create message
msg='EventID:'$Eventidnr'. Source:'$logSource'. Log Message - Boot time: '$vrboottime'. Uptime: '$vruptime'. System time sync status: '$dd's offset from local clock.'
logger --id=$Eventidnr $msg
echo $msg
#reset variables
vrboottime=''; vruptime=''; d1=''; d2=''; dd=''; msg=''; Eventidnr=''; LogName=''; logSource=''
IFS=' '
