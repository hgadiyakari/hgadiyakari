# =======================================================
# - Invoke-VMCommand runbook
# - AUTHOR: Aleksand Reznik, Nov 10, 2019 
# - Updates: Dalius Varkulevicius, Nov-Dec, 2019 (add storage url, convert to general one, add script variations)
# =======================================================
Param
    (
        [parameter(Mandatory=$true)] [String]$VMResourceGroupName,
        [parameter(Mandatory=$true)] [string]$VMnames,
        [parameter(Mandatory=$true)] 
        [ValidateSet('EnableRemotePS','IPConfig','RunPowerShellScript','RunShellScript','ifconfig','EnableAdminAccount','RDPSettings','SetRDPPort','ResetRDPCert','DisableNLA','RemoveRunCommandWindowsExtension','RemoveRunCommandLinuxExtension','EnableEMS','DisableWindowsUpdate','EnableWindowsUpdate')]
        [string]$CommandIdpar,
        [parameter(Mandatory=$false)] [String]$ScriptURL,
        [parameter(Mandatory=$false)] [string]$ScriptFileName,
        [parameter(Mandatory=$false)] [String]$ScriptParameters
    )
if ( $ScriptFileName -and $ScriptURL ) { Write-Output "Please give one of script parameters: Name or URL."; exit }
if ( $CommandIdpar -eq 'RunPowerShellScript' -or $CommandIdpar -eq 'RunShellScript' ) {
    if ( !$ScriptFileName -and !$ScriptURL ) { Write-Output "Please give one of script parameters: Name or URL."; exit }
}
#verbose stream output enablement in test output pane
#$VerbosePreference = "Continue"
try{
#get connection variables
    write-verbose "Connecting"
    $connection = Get-AutomationConnection -Name AzureRunAsConnection
    if ($connection) { write-verbose $connection } else { Write-Output 'Unable get connection variable';exit}
    $result = Connect-AzAccount -ServicePrincipal -Tenant $connection.TenantID -ApplicationID $connection.ApplicationID -CertificateThumbprint $connection.CertificateThumbprint
    if ($result) { write-verbose $result } else { write-verbose "Error, empty value returned." }   
    $result = Select-AzSubscription $connection.SubscriptionID
    if ($result) { write-verbose $result } else { write-verbose "Error, empty value returned." }   
    write-verbose "Setting variables"
#get storage variables
    $StorageResourceGroupName = Get-AutomationVariable  –Name 'dxcResourceGroup'
    if ($StorageResourceGroupName) { write-verbose $StorageResourceGroupName } else { Write-Output 'Unable get StorageResourceGroupName variable';exit}
    $StorageAccountName = Get-AutomationVariable  –Name 'dxcStorageAccountName'
    if ($StorageAccountName) { write-verbose $StorageAccountName} else { Write-Output 'Unable get StorageAccountName variable';exit}
    $StorageContainerName = Get-AutomationVariable  –Name 'dxcStorageAccountContainer'
    if ($StorageContainerName) { write-verbose $StorageContainerName} else { Write-Output 'Unable get StorageContainerName variable';exit}
#setting subscription context
    write-verbose "starting setazcontext:"
    $result = Get-AzSubscription -SubscriptionName $connection.SubscriptionName | Set-AzContext
    if ($result) { write-verbose $result } else { write-verbose "Error, empty value returned." }   
#setting storage context and uploading script
    if ($ScriptURL) {
    write-verbose "done, setting storage contex:"
    $AzStrKey = Get-AzStorageAccountKey -Name $StorageAccountName -ResourceGroupName $StorageResourceGroupName
    $AzStrCtx = New-AzureStorageContext $StorageAccountName -StorageAccountKey $AzStrKey[0].Value
        write-verbose "done, starting script download if URL is provided:"
        $scriptname = Split-Path -leaf -Path $scriptURL
        $scriptpath = $env:TEMP+"\"+$scriptname
        $result = Invoke-WebRequest -Uri $scriptURL -OutFile $scriptpath
        write-verbose "download complete, uploading file to local storage:"
        $result = Set-AzureStorageBlobContent -Context $AzStrCtx -Container $StorageContainerName -File $scriptpath -Blob $scriptname -Force
    }
    else {
        $scriptname = $ScriptFileName
    }
#constructin script parameters if any
    #Invoke-AzVMcommand syntax: -Parameter @{param1 = "var1"; param2 = "var2"}
    #Param3 - object from example
    if ($ScriptParameters) {
        write-verbose "done, creating parameters for script:" 
        $Script_params = @{} 
        $Param3array = $ScriptParameters -split ' '
        foreach($Par3 in $Param3array){
            $par3obj = $Par3 -split '='
            $par3name = $par3obj[0]
            $par3value = $par3obj[1]
            if ( $CommandIdpar -eq 'RunShellScript' ) {
                $Script_params = $Script_params + @{"$par3name" = "$par3name=$par3value"} #Remote Linux system shell gets only values, so we need to send name=value pair
            }
            else {
                $Script_params = $Script_params + @{"$par3name" = "$par3value"} #Remote Windows system gets normal PS object.
            }
        }
        if ($Script_params) {
            write-verbose $Script_params.Keys
            write-verbose $Script_params.Values
        }
    }
#constructing VMlist    
    write-verbose "done, parsing VMs:"
    $VMnames = $VMnames -replace '\"',''
    $VMnamez = $VMnames -split ' '
    foreach($VMName in $VMnamez){
        $vm = $null
        $vm = Get-AzVM -ResourceGroupName $VMResourceGroupName -Name $VMName -erroraction 'silentlycontinue' -status
        If ( $vm.name ) {
            $vms = $vm.statuses[1].Code
            $vmn = $vm.name
        #skip if not running
            If ( $vms -eq "PowerState/running") { #if VM is running
                if ($vm.OsName) { #if no OSname of VM, probably agent faulty
                    Write-Verbose "SCRIPT: VM name from runbook: $vmn and status: $vms" 
                    if ($vm.OsName.contains('Windows') -and ($CommandIdpar -eq 'RunShellScript' -or $CommandIdpar -eq 'ifconfig') ) { 
                        write-output "VM $VMName Widnows cannot run Linux shell scripts or commands, exiting."
                        Break  
                    }
                    if (!$vm.OsName.contains('Windows') -and ($CommandIdpar -eq 'RunPowerShellScript' -or $CommandIdpar -eq 'ipconfig') ) { 
                        write-output "VM $VMName Linux cannot run Windows PowerShell scripts or commands, exiting."
                        Break 
                    }
                    if ( $CommandIdpar -eq 'RunPowerShellScript' -or $CommandIdpar -eq 'RunShellScript' ) { #this portion only for PS/SH scripts
                    #connecting to storage
                        $StorageAccountKey = Get-AzStorageAccountKey -Name $StorageAccountName -ResourceGroupName $StorageResourceGroupName -erroraction 'silentlycontinue'
                        $Ctx = New-AzStorageContext -StorageAccountName $StorageAccountName -StorageAccountKey $StorageAccountKey.value[0] -erroraction 'silentlycontinue' #Primary
                        if ($Ctx) { 
                            write-verbose "SCRIPT: Ctx: $($Ctx)"
                            $tempFileName = Join-Path -Path $env:TEMP -ChildPath $scriptname
                            write-verbose  "SCRIPT: Write verbose '$tempFileName'"
                        #getting script from storage account
                            $result = Get-AzStorageBlob -Container $StorageContainerName -Context $Ctx -blob $scriptname | Get-AzStorageBlobContent -Destination $tempFileName -Force
                            if ($result) { 
                                write-verbose $result 
                                $text = Get-Content $tempFileName -Raw 
                                if ($text) { write-verbose $text } else { write-verbose "Error, 'Get-Content $tempFileName' empty value returned." }
                                if ($ScriptParameters) {
                                    $result = Invoke-AzVMRunCommand -ResourceGroupName $VMResourceGroupName -VMName $VMname -ScriptPath $tempFileName -CommandId $CommandIdpar -Parameter $Script_params 
                                }
                                else {
                                    $result = Invoke-AzVMRunCommand -ResourceGroupName $VMResourceGroupName -VMName $VMname -ScriptPath $tempFileName -CommandId $CommandIdpar
                                }
                                $msg=$result.value.Message
                                $msg = $msg -replace "`t|`n|`r",""
                            } else { write-verbose "Error, unable get StorageContainerName $StorageContainerName" }   
                        } else { write-output "Error, unable set storage $StorageAccountName context." }  
                    }#if CommandIdpar
                    else { #non shel script commands
                        $result = Invoke-AzVMRunCommand -ResourceGroupName $VMResourceGroupName -VMName $VMname -CommandId $CommandIdpar
                        $msg=$result.value.Message
                    }#if not CommandIdpar, then else portion
                    if ($result) { write-output "VM $vmn script execution was successful. Output: $msg" }
                    else { write-output "VM $vmn script execution was not-successful. Output: $msg" }
                    if ($result) { write-verbose $result } else { write-verbose "Error, empty value returned." }   
                }#if OsName
                else { write-output "VM $vmn is in 'running' state, unable to get OsName, agent faulty?, skipping execution of script for this VM." }
            }#if state
            else { write-output "VM $vmn is not in 'running' state, skipping execution of script for this VM." }
        }#end of novm
        else { write-output "VM $VMName is not found, skipping execution of script for this VM." }
    }#foreach
}#try
catch{
    $Error[0]
}
