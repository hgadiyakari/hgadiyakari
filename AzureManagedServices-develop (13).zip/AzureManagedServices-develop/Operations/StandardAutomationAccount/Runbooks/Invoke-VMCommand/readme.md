## Runbook: Invoke-command 
This runbook's purpose is to run scripts or commands inside VMs with Shedules capability that Runbooks provides.

#### Runbook data flow diagram
<IMG SRC="Invoke-VMCommand.png">

#### Invoke-command use-case solution diagram
<IMG SRC="full-solution-example.png" >
