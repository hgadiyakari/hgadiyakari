## Runbook Directory description
- Directory is for Runbooks, one subdir per one Runbook.
- Please do not create directories for other purposes.

#### For Runbooks, Automation Account Variables availabe:
    dxcResourceGroup            (RG for Automation Account)
    dxcAutomationAccountName    
    dxcStorageAccountRG         
    dxcStorageAccountName       
    dxcStorageAccountContainer  
    dxcKeyVaultRG               
    dxcKeyVaultName

#### From Automation Account Connection(inside runbook) you can get these variables:
    $connection = Get-AutomationConnection -Name AzureRunAsConnection
    write-output $connection
    ------------------------------------------------------------------------
    Name                           Value
    ----                           -----
    SubscriptionId                 X.......-....-....-....-...........Y
    TenantId                       X.......-....-....-....-...........Y
    ApplicationId                  X.......-....-....-....-...........Y
    CertificateThumbprint          X.........................................Y
