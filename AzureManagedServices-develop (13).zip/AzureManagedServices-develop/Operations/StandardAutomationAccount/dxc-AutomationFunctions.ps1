# =======================================================
# - Function Declarations
# - Extract of DeployShutdownAutomation.ps1
# - AUTHOR: Chris Neale, stable release, Oct 30, 2018 
# - Dalius Varkulevicius, extracted functions only to seperate file, changed keyVaultName creation, added 'dxc' to function names, Nov 12, 2019 
# - Dalius Varkulevicius, added import module function, Nov 14, 2019
# - Thomas Richards, fixed dxcGenerateCertFromKeyVault function (now runs on cloud shell), March 08, 2021
# =======================================================

#-----------------------------------
#-- Find Or Create Keyvault
#-----------------------------------
Function dxcFindOrCreateKeyvault ([string]$ResourceGroupName, [string]$UniqueID, [string]$subID, [string]$dxcCustomerCompanyCode, [string]$Location){
	##############################################################################################################
	#Searches RG supplied in DXCMaintRGName for a KeyVault to use
	#If it finds one it uses that, if not it creates a keyvault there using the AutomationAccountName
	##############################################################################################################
	#Write-Host "Checking for KeyVault presence, creating if not found"
	$GetKeyVault = Get-AzKeyVault -ResourceGroupName $ResourceGroupName | Select-Object -ExpandProperty VaultName -First 1
	if (!$GetKeyVault) {
		$keyVaultName = ("DXC-Maint-KV-" + $DXCRandomNo) #+ $dxcCustomerCompanyCode + "-" + $subID.ToString().Substring(0,4))
		Write-Host -Message "Key Vault not found. Creating the Key Vault $keyVaultName"
		$KeyVaultCreateResult = New-AzKeyVault -VaultName $keyVaultName -ResourceGroupName $ResourceGroupName -Location $Location
		if (!$KeyVaultCreateResult) {
			Write-Host -Message "Key Vault $keyVaultName creation failed. Please fix and continue"
			exit
		}
		Start-Sleep -s 15     
	}
	Else{
		$keyVaultName = $GetKeyVault
	}
	Return $keyVaultName
}

#-----------------------------------
#-- Generate Cert From KeyVault
#-----------------------------------
Function dxcGenerateCertFromKeyVault ([string]$CertName,[int]$LifetimeMonths,[string]$KVaultName, [Bool]$automate ){
	#Log Progress
	Write-Host "Generating the cert using Keyvault...$KVaultName"
	
	
	#Set variables
	$certSubjectName = "cn=" + $CertName
	$PfxCertPlainPasswordForRunAsAccount = [Guid]::NewGuid().ToString().Substring(0, 8) + "!" 
	$PfxCertPathForRunAsAccount = Join-Path ./ ($CertName + ".pfx")
	
	$Policy = New-AzKeyVaultCertificatePolicy -SecretContentType "application/x-pkcs12" -SubjectName $certSubjectName  -IssuerName "Self" -ValidityInMonths $LifetimeMonths -ReuseKeyOnRenewal
	if ($automate -eq $true)
	{
		#Allow certificate creation via Service Principal Account
		$dxcServicePrincipal = Get-AzADServicePrincipal -ApplicationId $currentAZContext.Account.Id
		if ($dxcServicePrincipal.count -eq 1)
		{
			Write-Output ("Setting Cert permissions in vault...") | Write-host -F Cyan
			Set-AzKeyVaultAccessPolicy -VaultName $KVaultName -ObjectId $dxcServicePrincipal.Id -PermissionsToCertificates Create,Get,Update	
		}
		else
		{
			Write-Output ("Automation flag detected, but the required Service Principal authentication was not found.  Use of the '-automation' flag requires authentication via Service Principal.") | Write-host -F Red
			Exit 5
		}	
	}
	$AddAzureKeyVaultCertificateStatus = Add-AzKeyVaultCertificate -VaultName $KVaultName -Name $CertName -CertificatePolicy $Policy 
	
	While ($AddAzureKeyVaultCertificateStatus.Status -eq "inProgress") {
		Start-Sleep -s 10
		$AddAzureKeyVaultCertificateStatus = Get-AzKeyVaultCertificateOperation -VaultName $KVaultName -Name $CertName
	}
	
	if ($AddAzureKeyVaultCertificateStatus.Status -ne "completed") {
		Write-Host -Message "Key vault cert creation is not sucessfull and its status is: $status.Status" 
	}

	$secretRetrieved = Get-AzKeyVaultSecret -VaultName $KVaultname -Name $CertName
    $secretValueText = '';
    $ssPtr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($secretRetrieved.SecretValue)
    try {
        $secretValueText = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($ssPtr)
        }finally {
        [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ssPtr)
        }
    $secretByte = [Convert]::FromBase64String($secretValueText)
    $certCollection = New-Object -TypeName System.Security.Cryptography.X509Certificates.X509Certificate2($secretByte, "", "Exportable,PersistKeySet")
    $type = [System.Security.Cryptography.X509Certificates.X509ContentType]::Pfx
    $pfxFileByte = $certCollection.Export($type, $PfxCertPlainPasswordForRunAsAccount)
	[System.IO.File]::WriteAllBytes($PfxCertPathForRunAsAccount, $pfxFileByte)

	$CertObject = "" | Select-Object -Property Path,PlainPass
	$CertObject.Path = $PfxCertPathForRunAsAccount
	$CertObject.PlainPass = $PfxCertPlainPasswordForRunAsAccount
	Return $CertObject
}

Function dxcCreateServicePrincipal([string]$PfxCertPath, [string]$PfxCertPlainPass, [string]$AppName, [string]$SubID, [Bool]$automate){
	########################################################
	# Create SP to run jobs as
	########################################################
	#Write-Host "Creating service principal..."

	$PfxCert = New-Object -TypeName System.Security.Cryptography.X509Certificates.X509Certificate2 -ArgumentList @($PfxCertPath, $PfxCertPlainPass)    
	$keyValue = [System.Convert]::ToBase64String($PfxCert.GetRawCertData())
	$KeyId = [Guid]::NewGuid() 
	$startDate = Get-Date
	$endDate = (Get-Date $PfxCert.GetExpirationDateString()).AddDays(-1)

	# Use Key credentials and create AAD Application
	if ($automate -eq $true)
	{
		$dxcServicePrincipal = Get-AzADServicePrincipal -ApplicationId $currentAZContext.Account.Id
		if ($dxcServicePrincipal.count -eq 1)
		{
			$Application = Get-AzADApplication -ApplicationId $currentAZContext.Account.Id
		}
		else
		{
			Write-Output ("Automation flag detected, but the required Service Principal authentication was not found.  Use of the '-automation' flag requires authentication via Service Principal.") | Write-host -F Red
			Exit 5
		}
	}
	else
	{
		$Application = New-AzADApplication -DisplayName $ApplicationDisplayName -HomePage ("http://" + $applicationDisplayName) -IdentifierUris ("http://" + $KeyId)
		$result = New-AzADAppCredential -ApplicationId $Application.ApplicationId -CertValue $keyValue -StartDate $startDate -EndDate $endDate 
		$result >>$null
		$result = New-AzADServicePrincipal -ApplicationId $Application.ApplicationId -SkipAssignment
	}
	return $PfxCert,$Application
}

Function dxcInstallModule ([string]$ModuleName, [string]$ResourceGroupName, [string]$AutomationAccountName, [string]$wait)
	{
		#if wait=false. If  it would not impact any other activity, then no point in waiting for completion. Use when down dependency is not needed.
		$uriModule = (Find-Module $ModuleName).RepositorySourceLocation + '/package/' + $ModuleName
		$msg = Get-AzAutomationModule -Name $ModuleName -ResourceGroupName $ResourceGroupName -AutomationAccountName $AutomationAccountName -ErrorAction SilentlyContinue
		if ($msg.ProvisioningState -ne "Succeeded") {
			if ($wait -eq 'true') {
				$msg = New-AzAutomationModule -Name $ModuleName -ContentLinkUri $uriModule -ResourceGroupName $ResourceGroupName -AutomationAccountName $AutomationAccountName
				$Retries = 0;
				While ($msg.ProvisioningState -ne " Succeeded" -and $Retries -le 30) {
					Start-Sleep -s 3
					$msg = Get-AzAutomationModule -Name $ModuleName -ResourceGroupName $ResourceGroupName -AutomationAccountName $AutomationAccountName -ErrorAction SilentlyContinue
					if ( $msg.ProvisioningState -eq " Failed" ) { return $msg; exit }
					$Retries++
				}
			}
			else{ $msg = New-AzAutomationModule -Name $ModuleName -ContentLinkUri $uriModule -ResourceGroupName $ResourceGroupName -AutomationAccountName $AutomationAccountName }
		}
		else { $msg = "$ModuleName exists, skipping. " }
		return $msg
	}
