# =======================================================
# - script to create automation account, service principal, connection and import runbooks with draft schedules
# - AUTHOR: Dalius Varkulevicius, draft, Nov 10, 2019
# - AUTHOR: Dalius Varkulevicius, final, Nov 28, 2019
# - Thomas Richards, fixed dxcGenerateCertFromKeyVault function (now runs on cloud shell), March 08, 2021
# =======================================================
# Required: Module Az v2+, Az.Accounts Az.Automation Az.KeyVault Az.Resources Az.Storage
# =======================================================
#	Steps
#	1. Create the Automation Account
#	1a. Import required modules
#	2a. Generate a new cert in the keyvault and store it in the local temp folder
#	2b. Create the SP for the Automation Account to "RunAs"
#	2c. Add certificate to Automation Account
#	2d. Create Connection "RunAs"
#	3. Create Storage account for downloaded scripts to be stored and attached to VM if needed.
#	4. Create AutomationAccount Variables
#	5. Create Storage account Container for download and for VM to access script 
#	60. Upload the RunBooks from Directory
#	   61. Create Schedules from Directory
#	   62. Associate the schedules Runbooks
#      63. Create-deploy aditional resources if needed
#   7. Add Contributor rights on Subscription for ServicePrincipal
# =======================================================
# examples
#.\dxc-deploy-StandardAutomation.ps1 -tenantId ... -subscriptionId ... -dxcAAResourceGroup ... -dxcCustomerCompanyCode ...
#.\dxc-deploy-StandardAutomation.ps1 -tenantId ... -subscriptionId ... -dxcAAResourceGroup ... -dxcCustomerCompanyCode ... -KeyVaultRG ... -KeyVaultName ...
# =======================================================
#-----------------------------------
#parameters
#-----------------------------------
[CmdletBinding(SupportsShouldProcess=$true)]
    Param
        (
        [Parameter(Mandatory=$true)]  [String]$tenantId,
        [Parameter(Mandatory=$true)]  [String]$subscriptionId,
        [Parameter(Mandatory=$true)]  [String]$dxcAAResourceGroup, #Automation Account ResourceGroup, can be DXC-Maint or any other
        [ValidateLength(2,6)][Parameter(Mandatory=$true)] [String]$dxcCustomerCompanyCode, #Client Code the same as SNOW
        [Parameter(Mandatory=$false)] [switch]$SkipAzureRunAsConnection, #any value will skip AzureRunAsConnection creation, incase do not have permisions on tenant leve, create manually
        [Parameter(Mandatory=$false)] [switch]$ShowErrors, #switch to show errors
        [Parameter(Mandatory=$false)] [String]$AutomationAccountName, #Automation Account and Application name if needed to use specific naming
        [Parameter(Mandatory=$true)]  [String]$KeyVaultRG, #Existing Keyvault ResourceGroup if KV is not in the same ResourceGroup
        [Parameter(Mandatory=$true)]  [String]$KeyVaultName, #Existing Keyvault Name if KV is not in the same ResourceGroup
        [Parameter(Mandatory=$false)] [String]$Location, #if no location specified take ResourceGroup location.
        [ValidatePattern("^[a-z0-9]*$")][Parameter(Mandatory=$false)] [String]$dxcStorageAccountName, #Existing Storage Account Name 
        [Parameter(Mandatory=$false)] [String]$dxcStorageAccountRG, #Existing Storage Account ResourceGroup 
        [ValidatePattern("^[a-z0-9]*$")][Parameter(Mandatory=$false)] [String]$dxcStorageAccountContainer, #Storage Container name if needed to use some specific one (if not pressent will be created)
		[Parameter(Mandatory=$false)] [Switch]$automation #Switch to determine if running full automation
        )
$?.Clear
$ErrorActionPreference = "Stop"
function cGreen{    process { Write-Host $_ -ForegroundColor Green }}
function cYellow{    process { Write-Host $_ -ForegroundColor Yellow }}
function cRed {    process { Write-Host $_ -ForegroundColor Red }}
Write-Output "`n0. - Connecting, checking and setting variables." | cGreen
if (-not (Get-InstalledModule -Name Az -AllVersions))
{
    Write-Output "Module Az does not exist, please install Az module, atleast version 2"
    exit
}

if($KeyVaultName -and !$KeyVaultRG) { Write-Output "Please give both KeyVaultName and KeyvaultRG" | cRed ; exit }
if(!$KeyVaultName -and $KeyVaultRG) { Write-Output "Please give both KeyVaultName and KeyvaultRG" | cRed ; exit }
if($dxcStorageAccountName -and !$dxcStorageAccountRG) { Write-Output "Please give both dxcStorageAccountName and dxcStorageAccountRG" | cRed ; exit }
if(!$dxcStorageAccountName -and $dxcStorageAccountRG) { Write-Output "Please give both dxcStorageAccountName and dxcStorageAccountRG" | cRed ; exit }

$automate = $false
#Determine if automation call
  if ($automation.IsPresent)
  {
	$automate = $true
  }

#-----------------------------------
#connection
#-----------------------------------

$currentAZContext = Get-AzContext
if ($currentAZContext.tenant.id -ne $tenantId){
    Connect-AzAccount -SubscriptionId $subscriptionId -tenant $tenantId
    $currentAZContext = Get-AzContext
    }
elseif ($currentAZContext.Subscription.id -ne $subscriptionId){
    Write-Output "$($currentAZContext.Subscription) not equal $($subscriptionId)"
    Get-AzSubscription -TenantId $tenantId -SubscriptionId $subscriptionId | Set-AzContext | out-null
    $currentAZContext = Get-AzContext
    }
if ($?) { Write-Output "Subscription connected." }
else { "Failed to connect to Azure." | cRed ; exit }

#-----------------------------------
#-- Check RG, KeyVault, StorageAccount
#-----------------------------------

#mandatory KV to exist
if($KeyVaultName) { 
    $result = Get-AzKeyVault -ResourceGroupName $KeyVaultRG -Name $KeyVaultName -erroraction 'silentlycontinue'
    if (-not $result) { Write-Output "KeyVault does not exists, please select correct KeyVault." | cRed; exit }
}
#Resource Group
$resultRG = Get-AzResourceGroup -name $dxcAAResourceGroup -erroraction 'silentlycontinue'
if (-not $resultRG) { Write-Output "ResourceGroup does not exists, please select correct ResourceGroup." | cRed; exit }

Write-Output "dxcAAResourceGroup, KeyVaultRG and KeyVaultName found."

# =======================================================
# - Import Function Declarations
# =======================================================

. .\dxc-AutomationFunctions.ps1
$checkFun = get-command "dxcGenerateCertFromKeyVault*"
if ($checkFun.Name) { Write-Output "Functions imported."  }
else { Write-Output "No Functions imported, please fix ensure you have file DXC-functions.ps1 in the same folder." | cRed; exit}

#-----------------------------------
#-- Setup Variables
#-----------------------------------
#if no location specified take ResourceGroup location.
if ( !$Location ) { $Location = $resultRG.Location }

#check Account and location support
$AzureLocation = $Location.ToLower().Replace(' ','')
$check = Get-AzLocation | Where-Object { $_.providers -contains 'Microsoft.Automation' -and $_.location -eq $AzureLocation }
if (!$check) { 
    Write-Output "Unsupported AutomationAccount Location: $AzureLocation. Use -Location parameter with one of:" | cRed; 
    Get-AzLocation | Where-Object { $_.providers -contains 'Microsoft.Automation' } | Select-Object Location,DisplayName
    exit 
}
Write-Output "Location:$AzureLocation supports AutomationAccount."

if(!$AutomationAccountName) { $AutomationAccountName = "DXC-" + $dxcCustomerCompanyCode + "-" + $subscriptionId.ToString().Substring(0,4) + "-StandardAutomationAccount" }
[String] $ApplicationDisplayName = "$AutomationAccountName"
$CertifcateAssetName = "AzureRunAsCertificate"
$CertificateName = $AutomationAccountName + $CertifcateAssetName
if (!$dxcStorageAccountName) {
    $dxcStorageAccountName = "dxc" + $dxcCustomerCompanyCode + $subscriptionId.ToString().Substring(0,4) + "st4runbooks"
    $dxcStorageAccountName = $dxcStorageAccountName.ToLower()
    $dxcStorageAccountRG = $dxcAAResourceGroup
}
if(!$dxcStorageAccountContainer) { $dxcStorageAccountContainer="container4automationrunbooks" }
if(!$KeyVaultRG) { $KeyVaultRG = $dxcAAResourceGroup }
$NameOfKeyVault = $KeyVaultName

##############################################################################################################
Write-Output "1. - Creating Automation Account"  | cGreen 
$check = Get-AzAutomationAccount -ResourceGroupName $dxcAAResourceGroup -Name $AutomationAccountName -erroraction 'silentlycontinue'
if (-not $check) {
    #dxcAAResourceGroup
    #$AutomationAccountName
    #$location
    $result = New-AzAutomationAccount -ResourceGroupName $dxcAAResourceGroup -Name $AutomationAccountName -Location $location
    if (!$?) { Write-Output "Error in creating AzAutomationAccount, hint: check Location of ResourceGroup Automation Account compatibility and limits." | cRed; exit }
    else { Write-Output "Automation Account $($result.AutomationAccountName) created" }
}
else { Write-Output "Automation Account $AutomationAccountName exists" }

##############################################################################################################
Write-Output "1a - Importing required modules to Automation Account"  | cGreen #minimum modules that are required for this AutomationAccount
try { 
    $result = dxcInstallModule -ModuleName Az.Accounts -ResourceGroupName $dxcAAResourceGroup -AutomationAccountName $AutomationAccountName -wait true #on this one others depend, so we need to wait for installation to finish.
    if ($? -and $result.Name) { Write-Output "$($result.Name) $($result.ProvisioningState) " } elseif ($? -and !$result.Name) { Write-Output "$result" }
    if ($result.ProvisioningState -eq "Creating" ) { 
        Write-Output "Error occurred while importing Az modules. This step is not mandatory. Continuing." | cYellow
        Write-Output "Import modules(Az.Accounts,Az.Automation,Az.Compute,Az.Storage) manualy or rerun script again." | cYellow
     }
    else {
        $result = dxcInstallModule -ModuleName Az.Automation -ResourceGroupName $dxcAAResourceGroup -AutomationAccountName $AutomationAccountName -wait false #no need to wait instalation will happen in background
        if ($? -and $result.Name) { Write-Output "$($result.Name) $($result.ProvisioningState) " } elseif ($? -and !$result.Name) { Write-Output "$result" }
        $result = dxcInstallModule -ModuleName Az.Compute -ResourceGroupName $dxcAAResourceGroup -AutomationAccountName $AutomationAccountName -wait false
        if ($? -and $result.Name) { Write-Output "$($result.Name) $($result.ProvisioningState) " } elseif ($? -and !$result.Name) { Write-Output "$result" }
        $result = dxcInstallModule -ModuleName Az.Storage -ResourceGroupName $dxcAAResourceGroup -AutomationAccountName $AutomationAccountName -wait false
        if ($? -and $result.Name) { Write-Output "$($result.Name) $($result.ProvisioningState) " } elseif ($? -and !$result.Name) { Write-Output "$result" }
    }
}
catch { 
    Write-Output "Error occurred while importing Az modules. This step is not mandatory. Continuing." | cYellow
    Write-Output "Import modules(Az.Accounts,Az.Automation,Az.Compute,Az.Storage) manualy or rerun script with switch -ShowErrors." | cYellow
    if($ShowErrors) { $_ }
}
##############################################################################################################
# check and AutomationConnection exists skip this portion.
Write-Output "2. - Create Automation AzureRunAsConnection"  | cGreen 
$check = Get-AzAutomationConnection -ResourceGroupName $dxcAAResourceGroup -automationAccountName $AutomationAccountName
if (-not $check -and !$SkipAzureRunAsConnection) {
    try { 
        ##############################################################################################################
        #Write-Output "2a - Finding or Creating Keyvault"  | cGreen 
        #if(!$KeyVaultName) {
        #    $NameOfKeyVault = dxcFindOrCreateKeyvault -ResourceGroupName $KeyVaultRG -UniqueID $AutomationAccountName -subID $subscriptionId -dxcCustomerCompanyCode $dxcCustomerCompanyCode -Location $Location
        #}
        #else { $NameOfKeyVault = $KeyVaultName }
        #write-output $NameOfKeyVault
        $NameOfKeyVault = $KeyVaultName 
        ##############################################################################################################
        $CertDetails = dxcGenerateCertFromKeyVault -CertName $CertificateName -LifetimeMonths 12 -KVaultName $NameOfKeyVault -automate $automate
        if (!$?) {
            Write-Output "Error occurred while creating Certificate. This step is not mandatory. Use switch -ShowErrors. Continuing." | cYellow
            if($ShowErrors) { $CertDetails } 
        }
        else { Write-Output "Created Certificate: $CertificateName" }
        ##############################################################################################################
        $spOutputs = dxcCreateServicePrincipal -PfxCertPath $CertDetails.Path -PfxCertPlainPass $CertDetails.PlainPass -AppName $ApplicationDisplayName -SubID $subscriptionId $automate
        if (!$?) {
            Write-Output "Error occurred while creating dxcCreateServicePrincipal. This step is not mandatory. Use switch -ShowErrors. Continuing." | cYellow
            if($ShowErrors) { $spOutputs } 
        }
        else { 
			if ($automate -eq $false)
			{
				Write-Output "Created Service Principal: $ApplicationDisplayName" 
			}
			else
			{
				Write-Output "Using existing Service Principal" 
			}
		}
        $spPfxCert = $spOutputs[0]
        $Application = $spOutputs[1]
        ##############################################################################################################
        # Create the automation certificate asset
        $CertPassword = ConvertTo-SecureString $CertDetails.PlainPass -AsPlainText -Force   
        $check = Get-AzAutomationCertificate -ResourceGroupName $dxcAAResourceGroup -automationAccountName $AutomationAccountName -erroraction 'silentlycontinue'
        if (-not $check) {
            $result = New-AzAutomationCertificate -ResourceGroupName $dxcAAResourceGroup -automationAccountName $AutomationAccountName -Path $CertDetails.Path -Name $CertifcateAssetName -Password $CertPassword -Exportable | write-verbose
            if (!$?) {
                Write-Output "Error occurred while adding Certificate in the Automation Account. This step is not mandatory. Use switch -ShowErrors. Continuing." | cYellow
                if($ShowErrors) { Write-Output "$result"  } 
            }
            else { Write-Output "Created Automation certificate asset." }
        }
        else { Write-Output "Automation certificate asset exists" }
        ##############################################################################################################
        # Populate the ConnectionFieldValues
        $ConnectionTypeName = "AzureServicePrincipal"
        $ConnectionAssetName = "AzureRunAsConnection"
        $ApplicationId = $Application.ApplicationId 
        $Thumbprint = $spPfxCert.Thumbprint
        $ConnectionFieldValues = @{"ApplicationId" = $ApplicationID; "TenantId" = $tenantId; "CertificateThumbprint" = $Thumbprint; "SubscriptionId" = $subscriptionId} 
        ############################################################################################################################################
        # Create a Automation connection asset named AzureRunAsConnection in the Automation account. This connection uses the service principal.   
        #$connectionFieldValues
        $check = Get-AzAutomationConnection -ResourceGroupName $dxcAAResourceGroup -automationAccountName $AutomationAccountName -erroraction 'silentlycontinue'
        if (-not $check) {
            $result = New-AzAutomationConnection -ResourceGroupName $dxcAAResourceGroup -automationAccountName $AutomationAccountName -Name $connectionAssetName -ConnectionTypeName $connectionTypeName -ConnectionFieldValues $connectionFieldValues -erroraction 'silentlycontinue'
            if (!$?) {
                Write-Output "Error occurred while creating AzAutomationConnection. This step is not mandatory. Use switch -ShowErrors. Continuing." | cYellow
                if($ShowErrors) { Write-Output "$result" } 
            }
            Else { Write-Output "Created AzAutomationConnection." }
        }
        else { Write-Output "AutomationConnection exists" }
    }
    catch { 
        Write-Output "Error occurred while creating AutomationConnection. This step is not mandatory. Continuing." | cYellow
        Write-Output "Create AutomationConnection manualy or rerun script with switch -ShowErrors." | cYellow
        if($ShowErrors) { $_ }
    }
}
else { Write-Output "AutomationConnection exists or not required, skipping 2 step." }

######################################
Write-Output "3. - Create Storage Account"  | cGreen 
$check = Get-AzStorageAccount -ResourceGroupName $dxcStorageAccountRG -Name $dxcStorageAccountName -erroraction 'silentlycontinue'
if (-not $check) { 
        $result = New-AzStorageAccount -ResourceGroupName $dxcStorageAccountRG -Name $dxcStorageAccountName -SkuName Standard_LRS -Location $Location -Kind Storage
        If ($result) { Write-Output "Storage Account $dxcStorageAccountName created." }
        else { Write-Output "Storage Account $dxcStorageAccountName creation failed. Use parameters dxcStorageAccountName and dxcStorageAccountRG." | cRed; exit }
        $strctx = $result.Context
    }
else { Write-Output "Storage Account $dxcStorageAccountName exists, skipping."; $strctx = $check.Context }

######################################
Write-Output "4. - Create AutomationAccount Variables"  | cGreen 
$check = Get-AzAutomationVariable -AutomationAccountName $AutomationAccountName -Name dxcResourceGroup -ResourceGroupName $dxcAAResourceGroup -erroraction 'silentlycontinue'
if (-not $check) {
    $result = New-AzAutomationVariable -AutomationAccountName $AutomationAccountName -Name dxcResourceGroup -Value $dxcAAResourceGroup -ResourceGroupName $dxcAAResourceGroup -Encrypted $false
    If ($result) { Write-Output "AutomationVariable dxcResourceGroup imported." }
}
else { Write-Output "AutomationVariable dxcResourceGroup exists, skipping." }
$check = Get-AzAutomationVariable -AutomationAccountName $AutomationAccountName -Name dxcAutomationAccountName -ResourceGroupName $dxcAAResourceGroup -erroraction 'silentlycontinue'
if (-not $check) {
    $result = New-AzAutomationVariable -AutomationAccountName $AutomationAccountName -Name dxcAutomationAccountName -Value $AutomationAccountName -ResourceGroupName $dxcAAResourceGroup -Encrypted $false
    If ($result) { Write-Output "AutomationVariable dxcAutomationAccountName imported." }
}
else { Write-Output "AutomationVariable dxcAutomationAccountName exists, skipping." }
$check = Get-AzAutomationVariable -AutomationAccountName $AutomationAccountName -Name dxcStorageAccountName -ResourceGroupName $dxcAAResourceGroup -erroraction 'silentlycontinue'
if (-not $check) {
    $result = New-AzAutomationVariable -AutomationAccountName $AutomationAccountName -Name dxcStorageAccountName -Value $dxcStorageAccountName -ResourceGroupName $dxcAAResourceGroup -Encrypted $false
    If ($result) { Write-Output "AutomationVariable dxcStorageAccountName imported." }
}
$check = Get-AzAutomationVariable -AutomationAccountName $AutomationAccountName -Name dxcStorageAccountRG -ResourceGroupName $dxcAAResourceGroup -erroraction 'silentlycontinue'
if (-not $check) {
    $result = New-AzAutomationVariable -AutomationAccountName $AutomationAccountName -Name dxcStorageAccountRG -Value $dxcStorageAccountRG -ResourceGroupName $dxcAAResourceGroup -Encrypted $false
    If ($result) { Write-Output "AutomationVariable dxcStorageAccountRG imported." }
}
else { Write-Output "AutomationVariable dxcStorageAccountName exists, skipping." }
$check = Get-AzAutomationVariable -AutomationAccountName $AutomationAccountName -Name dxcStorageAccountContainer -ResourceGroupName $dxcAAResourceGroup -erroraction 'silentlycontinue'
if (-not $check) {
    $result = New-AzAutomationVariable -AutomationAccountName $AutomationAccountName -Name dxcStorageAccountContainer -Value $dxcStorageAccountContainer -ResourceGroupName $dxcAAResourceGroup -Encrypted $false
    If ($result) { Write-Output "AutomationVariable dxcStorageAccountContainer imported." }
}
else { Write-Output "AutomationVariable dxcStorageAccountContainer exists, skipping." }
if ($NameOfKeyVault -eq $null) { $NameOfKeyVault = Get-AzKeyVault -resourcegroup $KeyVaultRG -erroraction 'silentlycontinue' | Select-Object -ExpandProperty VaultName -First 1 }
if ($NameOfKeyVault) {
    $check = Get-AzAutomationVariable -AutomationAccountName $AutomationAccountName -Name dxcKeyVaultName -ResourceGroupName $dxcAAResourceGroup -erroraction 'silentlycontinue'
    if (-not $check) {
        $result = New-AzAutomationVariable -AutomationAccountName $AutomationAccountName -Name dxcKeyVaultName -Value $NameOfKeyVault -ResourceGroupName $dxcAAResourceGroup -Encrypted $false
        If ($result) { Write-Output "AutomationVariable dxcKeyVaultName imported." }
    }
    else { Write-Output "AutomationVariable dxcKeyVaultName exists, skipping." }
    $check = Get-AzAutomationVariable -AutomationAccountName $AutomationAccountName -Name dxcKeyVaultRG -ResourceGroupName $dxcAAResourceGroup -erroraction 'silentlycontinue'
    if (-not $check) {
        $result = New-AzAutomationVariable -AutomationAccountName $AutomationAccountName -Name dxcKeyVaultRG -Value $KeyVaultRG -ResourceGroupName $dxcAAResourceGroup -Encrypted $false
        If ($result) { Write-Output "AutomationVariable dxcKeyVaultRG imported." }
    }
    else { Write-Output "AutomationVariable dxcKeyVaultRG exists, skipping." }
}

######################################
Write-Output "5. - Create Storage Account Container"  | cGreen 
#$AzStrKey = Get-AzStorageAccountKey -Name $dxcStorageAccountName -ResourceGroupName $dxcStorageAccountRG
#$AzStrCtx = New-AzStorageContext $dxcStorageAccountName -StorageAccountKey $AzStrKey[0].Value
$check = Get-AzStorageContainer -Name $dxcStorageAccountContainer -Context $strctx  -erroraction 'silentlycontinue'
if (-not $check) { 
    $result = New-AzStorageContainer -Name $dxcStorageAccountContainer -Permission Off -Context $strctx
    If ($result) { Write-Output "Storage Account $dxcStorageAccountContainer container created." }
    else { Write-Output "Storage Account $dxcStorageAccountContainer container creation failed." | cRed; Write-Output "$result"; exit }
}
else { Write-Output "Storage Account $dxcStorageAccountContainer exists, skipping." }

######################################
Write-Output "6. - Upload the RunBooks from Directory"  | cGreen 
$Runbooks = Get-ChildItem -Directory .\runbooks\ -ea silentlycontinue
for ($i=0; $i -lt $Runbooks.count; $i++) {
    $RBname = $runbooks[$i].name
    Write-Output "6.0a Importing AutomationRunbook $RBname. " | cGreen
    $link= ".\runbooks\" + $RBname + "\" + $RBname + ".ps1"
    if ( Get-ChildItem $link  -erroraction 'silentlycontinue' ) {
        $check = Get-AzAutomationRunbook -ResourceGroupName $dxcAAResourceGroup -automationAccountName $AutomationAccountName -Name "$RBname" -erroraction 'silentlycontinue'
        if (-not $check) {
            $result = Import-AzAutomationRunbook -Path "$link" -Name "$RBname" -Type PowerShell -ResourceGroupName $dxcAAResourceGroup -AutomationAccountName $AutomationAccountName -Published
            If ($result) { Write-Output "AutomationRunbook $RBname imported." }
            else { Write-Output "Nothing to import or unable to import $RBname Runbook." ; $result }
        }
        else { Write-Output "AutomationRunbook $RBname exists, skipping." }
        Write-Output "6.0b Importing AutomationRunbook $RBname Schedules. " | cGreen 
        $SchedulesDir = ".\runbooks\" + $runbooks[$i].name + "\Schedules\"
        $Schedules = Get-ChildItem -File $SchedulesDir*.ps1
        for ($e=0; $e -lt $Schedules.count; $e++) {
            $SSname = $Schedules[$e].name
            #Write-Output "Importing Schedule: $SSname"
            $SSpath = $SchedulesDir + $SSname
            $result = & .\$SSpath -RG $dxcAAResourceGroup -RunbookName $RBname -AutomationAccountName $AutomationAccountName -storageContext $strctx
            if ($result) { $result }  #select-string supreses output from script... remove if need more info
            else { Write-Output "Nothing to import or unable to import $SSname Schedule." } 
        }
    }
    else { Write-Output "AutomationRunbook $link file does not exists, skipping." }
}

############################################################################################################################################
# Add ApID contributor role to SUbscription, need to add some delay as sometimes ApplicationId is not discoverable after creation
# moved to the end of script as wait time is still not enought some times.
Write-Output "7. - Confirm or Add Contributor rights for AppName:$AutomationAccountName on Subscription level." | cGreen 
Start-Sleep -s 3
    $result = Get-AzRoleAssignment -scope ("/subscriptions/" + $subscriptionId) | Where-Object {$_.DisplayName -eq "$AutomationAccountName"}
    if (-not $result -and !$SkipAzureRunAsConnection ) {
        try {
            $RightsOnSub = Get-AzRoleAssignment -scope "/subscriptions/$subscriptionId" | Where-Object {$_.SignInName -eq $currentAZContext.account.id }
            if ( $RightsOnSub ) {
                Start-Sleep -s 3
                $Retries = 0
                $check = Get-AzADServicePrincipal -DisplayName $AutomationAccountName -erroraction 'silentlycontinue'
                While (-not $check -and $Retries -le 10) {
                    Start-Sleep -s 3
                    $check = Get-AzADServicePrincipal -DisplayName $AutomationAccountName -erroraction 'silentlycontinue'
                    $Retries++
                }
                if ($check) { Start-Sleep -s 3; New-AzRoleAssignment -RoleDefinitionName Contributor -scope ("/subscriptions/" + $subscriptionId) -ObjectId $check.Id }  
                else { Write-Output "Failed to Add Contributor rights. Ask other person with higher role to run script or add rights manually." | cYellow; $check }
            }
            else { Write-Output "User do not have rights to modify Subsciption level. Ask other person with higher role to run script or add rights manually." | cYellow }
        }
        catch { Write-Output "User do not have rights to modify Subsciption level. Ask other person with higher role to run script or add rights manually." | cYellow }
    }
    else { Write-Output "Good: Application principal already has rights or SkipAzureRunAsConnection switch used. " }
Write-Output "Script executed successfully.`n`n" | cGreen 
