## StandardAutomationAccount

### Description
Automation Account deployment system created to deliver Automation Account, Connection and Runbooks-Schedules that are used for any client or 
Ops needs, be it simple check 'if NSG are applied' or complex one with 'script on VM' and alerting. Any new runbook added will be deployed by 
running No6 step, existing resources will be skipped.

## Jira Epic
N/A - Before switch to AZR project in Jira

## Deployment
For more information please see:
* Section 3.3.9 of Onboarding Guide

#### How to deploy Automation Account, Runbooks and Schedules
1. Download branch, extract to local disk, open '/Operations/StandardAutomationAccount/' folder
2. Create folder inside runbooks folder. 
3. Name that folder as your runbook would look when deployed. (/Operations/StandardAutomationAccount/Runbooks/YourRunbook)
4. Create '.ps1' file inside your runbook folder with the same name. 
5. 'Schedule.ps1' PS-coded programs and added under the same folder subfolder 'Schedules'. 
6. Open(cd) main 'StandardAutomationAccount' folder and run './dxc-deploy-StandardAutomation.ps1' (see dxc-deploy-StandardAutomation.md for parameters)
* Script skips existing resources. Script do not delete or overwrite any items. If you need to change values do them manually of remove the item and rerun script.
* More information on rights, requirements and parameters see script documentation: dxc-deploy-StandardAutomation.md

#### Automated Deployment from DevOps Pipeline
1. Add "-automation" argument to script call:  .\dxc-deploy-StandardAutomation.ps1 -tenantId TENANT -subscriptionId SUBSCRIPTION -dxcAAResourceGroup RESOURCEGROUP -dxcCustomerCompanyCode CUSTOMERCOMPANYCODE -KeyVaultRG VAULTRESOURCEGROUP -KeyVaultName VAULTNAME -ShowErrors -automation
NOTE: When using the "-automation" argument, authentication via a Service Principal must be active prior to script execution.

### Structure Diagram
<IMG SRC="StandardAutomationAccount.png" width="685" height="784" >

## Authors
* Dalius Varkulevicius
