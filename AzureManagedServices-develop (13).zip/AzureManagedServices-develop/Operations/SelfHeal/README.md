# Self-heal Automation in Azure

This folder contains the following assets - ARM templates, automation scripts and documentation developed for the self-heal automation initiative.

## Confluence Page 
Refer to documentation on [Self-heal for Azure](https://confluence.dxc.com/display/ESCAT/Self-heal+for+Azure#Self-healforAzure-DeployingSelf-healautomation)

## Jira Epic
https://jira.dxc.com/browse/AZR-6957

### Context and problem
CloudOps Delivery is challenged to respond efficiently using available improvements and tools. However, there is still a number of areas which can be improved via automation. In the case of the standard alerts with known fixes, manual and segmented actions in multiple subscriptions/environment can impact flexibility and are error-prone.
One area of concern is the ability perform a retry operation as a common fix to most VM backup failures. Introducing an automated action or “self-heal” as response to failed alerts will improve productivity and reliability of monitoring.
Currently, the standard monitoring configuration is limited to send alerts directly to workflow tool and does not include a functionality to perform other alternate actions.

### Solution
The main objective is to enable a response mechanism, as enhancement, that will – detect, action on the error and log the action for operational insight. This simple approach will not only send events to ServiceNow but provide an alternate response based on identified Microsoft-recommended steps and known error fixes.

When a backup job fails, "self-heal" automation will attempt recovery by initiating a retry operation on the VM. Self-heal automation, as an enhancement to the alerting schema, will consist of the following Azure services:
-	Automation account – Service that enables, authorizes and manages runbook executions
-	Automation runbook – PowerShell scripts that run the automated tasks
-	Logic App – Service that orchestrates all automated actions
-	Custom log – Data source that will capture the automated recovery results
-	Alert rule – Log search query that monitors and categorizes the automated recovery results if successful or not

![](https://github.dxc.com/cloud/AzureOffering_ServiceNow/blob/AZR-11274_Upload_Self-Heal_assets/SelfHeal/images/self-heal.PNG)

The above diagram is the architecture of Self-Heal, showing how alerts flow and are processed within the automation framework using existing and additional resources.

### Automation workflow
The section describes how self-heal automation works as part of standard monitoring.
![](https://github.dxc.com/cloud/AzureOffering_ServiceNow/blob/AZR-11274_Upload_Self-Heal_assets/SelfHeal/images/self-heal_workflow.png)
#### Detecting the failure
Self-heal will capture events coming from standard alerting – DXC-Critical-Backup Failure and automated recovery will be triggered by a webhook process to start Logic App instance execution.
#### Recovering the failure
Within the Logic App instance, automation runbooks will be run in sequence to perform diagnostics, remediation and logging operations.
#### Alerting the recovery attempt and results
Self-heal will log all results to a custom log and categorize successful and failed attempts as Critical and Informational events respectively. New alert rules are created to represent the results –
- DXC-Critical-SelfHeal – this is the log query to be used to capture failed self-heal attempts on precursor alert (log entry from DXC-Critical-Backup Failure)
- DXC-Informational-SelfHeal – this is the log query to be used to capture successful self-heal attempts on precursor alert (log entry from DXC-Critical-Backup Failure)
Using the standard ITSM action group, these events will be forwarded to ServiceNow with the descriptions of the alert and recovery results.

### Deploying Self-heal for VM Backup failures

This page provides guidelines how self-heal is deployed and configured in the Azure subscription. The automated deployment includes ARM templates and scripts which covers the build and configuration of the following -

- Automation account
- Runbooks
- Logic Apps
- Custom log (Log Analytics)
- Alert rules (log search query and action group)

#### Prerequisites
This section lists the requirements to prepare the environment for self-heal automation to be deployed correctly.
1. Access to subscription and role-based access with Owner privileges
2. PowerShell version 7.0
3. PowerShell Az module version 1.0 or higher

The expected parameters are described below:
-	dxcSubscriptionId – the Customer subscription ID reference where self-heal will be deployed to.
-	dxcLogAnalyticsWorkspaceName – the standard Log Analytics workspace deployed in the DXC resource group.
-	dxcCustomerCompanyCode – 4 to 6 digit alphanumeric customer code
-	dxcKeyVaultName – Name of the keyvault in which to store certificates and secrets
-	A strong password for the RunAs account certificate asset

#### How to run the deployment scripts
There are two (2) automation scripts that need to be executed separately and in sequence to deploy the self-heal components.

- deploySelfheal.ps1 - this script creates an Automation account instance, imports the runbooks, creates a Logic app instance with the workflows and adds a custom log in the DXC Log analytics workspace.

- deployAlertRule.ps1 - this script creates alert rule with the log search query and action group.

1. Download the codebase from GitHub and save to your local machine.
2. Extract the contents to your preferred directory.
3. Open the PowerShell console (Run as Administrator) and switch to the directory where the codebase was saved (...\AzureOffering_ServiceNow-master\SelfHeal\arm-templates\)
4. Execute the scripts (one at a time)

```
.\deploySelfheal.ps1 -dxcSubscriptionID SUBSCRIPTION_ID  -dxcLogAnalyticsWorkspaceName LOGANALYTICS_WORKSPACE `
-dxcCustomerCompanyCode COMPANYCODE -dxcKeyVaultName KEY_VAULT_NAME
```
<em>Note: You will be prompted for a password for the self-signed certificate of the RunAs account, take note of the password. During script execution, you will again be prompted to authenticate to create the API connector; hence you need to select the account you used for logon earlier. 

Script duration is estimated at 10-15 minutes, don’t close the window until script finishes. Take note of the newly-created as it will be needed as input for next script.
</em>
```
.\deployAlertRule.ps1 -dxcSubscriptionID SUBSCRIPTION_ID -dxcLogAnalyticsWorkspaceName LOGANALYTICS_WORKSPACENAME `
-dxcAutomationAccountSH AUTOMATION_ACCOUNT -Verbose
```
<em>
Note:
-dxcAutomationAccountSH AUTOMATION_ACCOUNT is the newly-created Automation account for self-heal.
</em>

3. Each script will execute and capture messages in a log file on the script directory once completed.


#### Manual steps needed to complete deployment
1. Run the command below to quickly verify that required services were installed.
```
Get-AzResource -TagName "service" -TagValue "selfheal" | ft –a
```
<em>Note: This will list down all instances required for self-heal which includes an instance of Automation account, Logic app, 4 runbooks, 2 alert rules and 1 action group.</em>

2. Check if the components were created from the Portal.
  - Automation account - Tags, Runbooks (Published), Connections, Certificates, Run as accounts
  - Logic app - Tags, Logic app designer, API connections
  - Alert rule - Tags, Action rule


## Authors
* Azure Engineering


