#Requires -PSEdition Core
#Requires -Version 7.0
#Requires -RunAsAdministrator

#-----------------------------------------------------------[Comments]-------------------------------------------------------------
<#
.SYNOPSIS
This PowerShell script collects data from log analytics to validate if self-heal processing was successful or not. 
All backup failures from AzureDiagnostics (using the backup job id as reference) will be maapped for reference against the self-heal custom log 
to verify if alerts were successfully processed. Result set will capture 30 days of data as default.

The following are required as input -
    - Subscription Id
    - LogAnalytics workspace nam
.REVISION HISTORY
    12-Nov-2019 - Initial script development
    14-Nov-2019 - Added pre-checks, logging functions
    19-Mar-2020 - Added query for Hybrid Runbook Worker executions
    23-Jul-2020 - Include functions to check PowerShell Core execution
#>


#---------------------------------------------------------[Initializations]-------------------------------------------------------- 

[CmdletBinding()]
Param (
    [Parameter(HelpMessage = "Please enter your Subscription ID.", Position=1, Mandatory = $True, ValueFromPipeline = $True)]
    [ValidateNotNullOrEmpty()][string]$dxcSubscriptionId,
    [Parameter(HelpMessage = "Please enter your Log Analytics workspace name.", Position=2, Mandatory = $True, ValueFromPipeline = $True)]
    [ValidateNotNullOrEmpty()][string]$dxcLogAnalyticsWorkspaceName
)

#----------------------------------------------------------[Declarations]----------------------------------------------------------
$scriptName = "reportSelfHeal"
$scriptPath = (Get-Location).ProviderPath
$logFilePath = [System.IO.Path]::GetFullPath("$scriptPath\$($scriptName + '-{0:dd-MMM-yyyy_HHmm}' -f (Get-Date) + '.log')")
$reportFile = [System.IO.Path]::GetFullPath("$scriptPath\$($scriptName + '-{0:dd-MMM-yyyy_HHmm}' -f (Get-Date) + '.xlsx')")

$querySelfheal = '
    let SelfhealMetrics = AzureDiagnostics // SUCCESSFUL - all detected alerts captured and processed in self-heal
    | where TimeGenerated > ago(30d) and OperationName == "Job" and JobStatus_s == "Failed" 
    | where SchemaVersion_s == "V2"
    | project BackupItemUniqueId_s, JobUniqueId_g, JobFailureCode_s,TimeGenerated, _ResourceId 
    | join kind= inner (
    SelfHeal_CL
    | where TimeGenerated > ago(30d) 
    | extend ProcessedAlert = todynamic(ProcessedAlert_s) 
    | extend JobUniqueId_g = tostring(ProcessedAlert.JobUniqueId_g), BackupItemUniqueId_SH = tostring(ProcessedAlert.BackupItemUniqueId_s), BackupMgmtType = tostring(ProcessedAlert.BackupManagementType_s)
    | extend TimeGenerated_SH = TimeGenerated, SelfhealSeverity_SH = SelfhealSeverity_s, SelfhealResult_SH = SelfhealResult_s
    | project JobUniqueId_g , BackupItemUniqueId_SH, TimeGenerated_SH, SelfhealSeverity_s, SelfhealResult_s, BackupMgmtType 
    ) on JobUniqueId_g 
    | extend VMName = split(BackupItemUniqueId_SH, ";")[-1], BackupJobID = JobUniqueId_g, BackupJobFailureCode = JobFailureCode_s, TimeStampInAzureDiagnostics = TimeGenerated
    | extend TimeStampInSelfHeal = TimeGenerated_SH, SelfHeal_Severity = SelfhealSeverity_s, SelfHeal_Result = SelfhealResult_s
    | project VMName, BackupJobID, BackupJobFailureCode, _ResourceId, TimeStampInAzureDiagnostics, SelfHeal_Severity, SelfHeal_Result, TimeStampInSelfHeal, BackupMgmtType;
    SelfhealMetrics
', `
'
    let SelfhealDefects = AzureDiagnostics // FAILED = all detected alerts not captured and logged in self-heal
    | where TimeGenerated > ago(30d) and OperationName == "Job" and JobStatus_s == "Failed" 
    | where SchemaVersion_s == "V2"
    | project BackupItemUniqueId_s, JobUniqueId_g, JobFailureCode_s,TimeGenerated, _ResourceId, BackupManagementType_s 
    | join kind= leftanti (
    SelfHeal_CL
    | where TimeGenerated > ago(30d) 
    | extend ProcessedAlert = todynamic(ProcessedAlert_s) 
    | extend JobUniqueId_g = tostring(ProcessedAlert.JobUniqueId_g), BackupItemUniqueId_SH = tostring(ProcessedAlert.BackupItemUniqueId_s)
    | extend TimeGenerated_SH = TimeGenerated, SelfhealSeverity_SH = SelfhealSeverity_s, SelfhealResult_SH = SelfhealResult_s
    | project JobUniqueId_g , BackupItemUniqueId_SH, TimeGenerated_SH, SelfhealSeverity_s, SelfhealResult_s 
    ) on JobUniqueId_g 
    | extend VMName = split(BackupItemUniqueId_s,";")[-1], BackupJobID = JobUniqueId_g, BackupJobFailureCode = JobFailureCode_s, TimeStampInAzureDiagnostics = TimeGenerated
    | project VMName, BackupJobID, BackupJobFailureCode, _ResourceId, TimeStampInAzureDiagnostics, BackupManagementType_s;
    SelfhealDefects
', `
'
    let HRWExecutions = AzureDiagnostics // Hybrid Runbook Worker executions from Automation Account and registered in Event data
    | where ResourceProvider == "MICROSOFT.AUTOMATION" and TimeGenerated > ago(30d)
    | where RunOn_s == "selfheal-group" and OperationName == "Job" and ResultType == "Completed" 
    | extend JobId = toupper(JobId_g) 
    | project Type, RunbookName_s, JobId 
    | join kind= inner (
    Event
    | where Source == "Microsoft-SMA" and EventID == "3181"
    | extend parse_xml(EventData)
    | extend JobId = trim(@"[{}]",tostring(parse_json(tostring(parse_json(tostring(parse_json(tostring(EventData.DataItem)).EventData)).Data))[4].["#text"]))
    | extend Type_g = Type, eventData = EventData 
    | project Type_g,JobId, Computer , Source, EventData , RenderedDescription
    ) on JobId
    | project Type,RunbookName_s,JobId,Type_g,Computer,Source,EventData,RenderedDescription;
    HRWExecutions
'

#-----------------------------------------------------------[Functions]------------------------------------------------------------

filter timestamp {"$(Get-Date -Format MM-dd-yyyy-hh:mm:ss): $_"} # Capture the time information for logging purposes.

function Run-PreChecks # This function performs required prerequisite checks.
{
    Write-Output "INFO: Perform prerequisite checks." | timestamp 

    # Check for ImportExcel module
    $checkModule = Get-Module -Name ImportExcel -ListAvailable -EA 0 -WA 0
    if ($checkModule -eq $null) {
        Install-Module ImportExcel -AllowClobber -Force -EA 0
        if ($error) { 
            Write-Output "ERROR: Unable to install module, please install manually before retrying script." `
                | timestamp | Write-Host -F Red ; exit
        }
        Write-Output "INFO: Module ImportExcel installed successfully." | timestamp
    } else { Write-Output "Module ImportExcel found." | timestamp }

    
}

function Check-Login # Verify current connectivity to Azure and if login is required.
{
    [CmdletBinding(SupportsShouldProcess=$true)]
    Param ([string]$dxcSubscriptionId)

    Set-AzContext -Subscription $dxcSubscriptionID -EA 0 -WA 0 | Out-Null
    if ($error) {
        $error.Clear()
        Write-Output "INFO: Please login to Azure Resource Manager." | Write-Host -F Cyan
        Connect-AzAccount -EA 0 -WA 2 | Out-Null
        if ($error) {
            Write-Output "ERROR: Failed to connect to Azure Resource Manager. Check your internet connection and verify authentication details." | Write-Host -F Red ; exit
        } else {
            Set-AzContext -Subscription $dxcSubscriptionID -EA 0 -WA 0 | Out-Null
            Write-Output "INFO: Connected to Azure with provided authentication." | Write-Host -F Yellow
            Write-Host (Get-AzContext | Out-String)
        }
    }
}

function Validate-LogAnalyticsWorkspace # Get Log Analytics workspace details, enable AzureAutomation intelligence pack and Microsoft/SMA data source.
{
    [CmdletBinding(SupportsShouldProcess=$true)]
    Param ([string]$dxcLogAnalyticsWorkspaceName)
 
    $error.clear()

    $workspaceObj = Get-AzOperationalInsightsWorkspace | ? { $_.Name -eq $dxcLogAnalyticsWorkspaceName }
    if ($workspaceObj -eq $null) {
        Write-Output "ERROR: Loganalytics Workspace not found. Please enter a valid workspace in the subscription." `
            | timestamp | Write-Host -F Red ; break
    } else {
        Write-Output "INFO: Log Analytics workspace found in subscription: " | timestamp | Write-Host -F Yellow -NoNewline
        Write-Host $dxcLogAnalyticsWorkspaceName
        return $workspaceObj
    }
}

function Get-LogAnalyticsData # Query Heartbeat and Update data from Log Analytics workspace.
{
    [CmdletBinding(SupportsShouldProcess=$true)]
    Param ([object]$workspaceObj, [string]$workspaceQuery)
    
    $error.clear()

    $queryResults = (Invoke-AzOperationalInsightsQuery -Workspace $workspaceObj -Query $workspaceQuery -EA 0 -WA 0).Results
    if ($error) {
        $error.Clear()
        Write-Output "WARN: There are no results found for $($workspaceQuery.Split("`n")[-2].Trim()) in the workspace." | timestamp | Write-Host -F Gray
    } else {
        if (($queryResults.BackupJobID -eq $null) -and ($queryResults.JobID -eq $null)) {
            Write-Output "WARN: There are no results found for $($workspaceQuery.Split("`n")[-2].Trim()) in the workspace." | timestamp | Write-Host -F Gray
        }
    }
    
    return $queryResults
}

function Create-SavedSearch { # Create a saved search in Log Analytics workspace.
    [CmdletBinding(SupportsShouldProcess=$true)]
    Param ([object]$workspaceObj, [string]$workspaceQuery)
    
    $error.clear()

    $category = "SelfHeal"
    $id = $($workspaceQuery.Split("`n")[-2].Trim())
    
    try {
        $ifExists = Get-AzOperationalInsightsSavedSearch -ResourceGroupName $workspaceObj.ResourceGroupName -WorkspaceName $workspaceObj.Name -SavedSearchId $id -EA 0 -WA 0
        Write-Output "INFO: Saved search already exists in workspace - $id." | timestamp | Write-Host
    } catch {
        $error.clear()
        New-AzOperationalInsightsSavedSearch -ResourceGroupName $workspaceObj.ResourceGroupName -WorkspaceName $workspaceObj.Name `
            -DisplayName $id -Query $workspaceQuery -Category $category -SavedSearchId $id -Version 1 -Tag @{ service = 'selfheal' } -Force | Out-Null
        Write-Output "INFO: Saved search created in workspace - $id." | timestamp | Write-Host -F Green
            if ($error) {
                $error.clear()
                Write-Output "WARN: Unable to create saved search $id in workspace." | timestamp | Write-Host -F Gray
            }
    }
}

#-----------------------------------------------------------[Execution]------------------------------------------------------------
try {

    $error.Clear()
    $start = Get-Date

    # Create the log file
    New-Item $logFilePath -ItemType File -Force | Out-Null
    filter timestamp {"$(Get-Date -Format MM-dd-yyyy-hh:mm:ss): $_"}
    Start-Transcript -Path $logFilePath -Append -EA 0 | Out-Null
    Write-Output "Script execution started." | timestamp | Write-Host -F Yellow

    # Run prerequisite checks
    Run-PreChecks 
    if ($error) { throw }

    # Login to Azure
    Check-Login -dxcSubscriptionId $dxcSubscriptionID

    # Validate Log Analytics workspace
    $getWorkspaceObj = Validate-LogAnalyticsWorkspace -dxcLogAnalyticsWorkspaceName $dxcLogAnalyticsWorkspaceName

    # Process query and results
    foreach ($query in $querySelfheal) {
        Create-SavedSearch -workspaceObj $getWorkspaceObj -workspaceQuery $query
        $reportSet = Get-LogAnalyticsData -workspaceObj $getWorkspaceObj -workspaceQuery $query
        $reportSet | Export-Excel -WorksheetName $($query.Split("`n")[-2].Trim()) -Path $reportFile -Append
    }

} catch {

    Write-Output "ERROR: Script executed with errors." | timestamp | Write-Host -F Red ; $error

} finally {
    
    if ([string]::IsNullOrEmpty(($checkNullReport = Import-Excel -Path $reportFile -EA 0 -WA 0))) {
        Remove-Item -Path $reportFile -Force -EA 0 -WA 0
        Write-Output "WARN: No data collected, nothing to report." | Write-Host -F Gray
    } else {
        Write-Output "INFO: Report created - $reportFile." | timestamp | Write-Host -F Green
        Start $reportFile 
    }
    Write-Output "Script execution finished. Refer to log - $logFilePath." | timestamp | Write-Host -F Yellow
    Stop-Transcript -EA 0 | Out-Null
    $end = Get-Date ; Write-Host -F DarkGray "Script duration (mins):" ([math]::Round(($end - $start).TotalMinutes,2))
    Remove-Variable * -Force -EA 0; $error.Clear()

}
