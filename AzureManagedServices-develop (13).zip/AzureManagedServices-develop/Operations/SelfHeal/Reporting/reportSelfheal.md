## Reporting for Self-Heal 

#### Overview
This development aims to collect data from Log Analytics and provide a report to validate self-heal executions against detected backup failures. The report will show backup failures from AzureDiagnostics which maps to corresponding self-heal attempts made against the alert based on the custom log (self-heal) which will indicate the result of the attempt (either Success or Fail). It will also include a defect report to identify failed self-heal executions.

If Hybrid Runbook Worker is deployed, the report will show jobs completed from the Automation account and identify which VM worker the runbook was executed on.

#### Query and result set
The script will use both the Azure Diagnostics log and Self-heal custom log to  capture the metrics using the reference ID of the failed backup job.  To determine where self-heal was executed, this query will be used -

```
AzureDiagnostics 
| where TimeGenerated > ago(30d) and OperationName == "Job" and JobStatus_s == "Failed" 
| where SchemaVersion_s == "V2"
| project BackupItemUniqueId_s, JobUniqueId_g, JobFailureCode_s,TimeGenerated, _ResourceId 
| join kind= inner (
SelfHeal_CL
| where TimeGenerated > ago(30d) 
| extend ProcessedAlert = todynamic(ProcessedAlert_s) 
| extend JobUniqueId_g = tostring(ProcessedAlert.JobUniqueId_g), BackupItemUniqueId_SH = tostring(ProcessedAlert.BackupItemUniqueId_s), BackupMgmtType = tostring(ProcessedAlert.BackupManagementType_s)
| extend TimeGenerated_SH = TimeGenerated, SelfhealSeverity_SH = SelfhealSeverity_s, SelfhealResult_SH = SelfhealResult_s
| project JobUniqueId_g , BackupItemUniqueId_SH, TimeGenerated_SH, SelfhealSeverity_s, SelfhealResult_s, BackupMgmtType 
) on JobUniqueId_g 
| extend VMName = split(BackupItemUniqueId_SH, ";")[-1], BackupJobID = JobUniqueId_g, BackupJobFailureCode = JobFailureCode_s, TimeStampInAzureDiagnostics = TimeGenerated
| extend TimeStampInSelfHeal = TimeGenerated_SH, SelfHeal_Severity = SelfhealSeverity_s, SelfHeal_Result = SelfhealResult_s
| project VMName, BackupJobID, BackupJobFailureCode, _ResourceId, TimeStampInAzureDiagnostics, SelfHeal_Severity, SelfHeal_Result, TimeStampInSelfHeal, BackupMgmtType
```

Result set will include the following data:

|Item|Description|Source| 
|:--- |:---|:---
|VMName|Azure backup item|AzureDiagnostics
|BackupJobID|Unique identifier of the backup job reference|AzureDiagnostics
BackupJobFailureCode|Error code of the backup job failure|AzureDiagnostics
|_ResourceId|Recovery services vault identifier|AzureDiagnostics
|TimeStampInAzureDiagnostics|Time reference when logged in AzureDiagnostics|AzureDiagnostics
|SelfHealSeverity|Severity of the self-heal attempt	|SelfHeal_CL
|SelfHealResult|Result of the self-heal attempt|SelfHeal_CL
|TimeStampInSelfHeal|Time reference when logged in SelfHeal_CL|SelfHeal_CL
|BackupMgmtType|Type of workload being backed up|SelfHeal_CL


For defects, this query will determine where self-heal failed to run -
```
AzureDiagnostics 
| where TimeGenerated > ago(30d) and OperationName == "Job" and JobStatus_s == "Failed" 
| where SchemaVersion_s == "V2"
| project BackupItemUniqueId_s, JobUniqueId_g, JobFailureCode_s,TimeGenerated, _ResourceId, BackupManagementType_s 
| join kind= leftanti (
SelfHeal_CL
| where TimeGenerated > ago(30d) 
| extend ProcessedAlert = todynamic(ProcessedAlert_s) 
| extend JobUniqueId_g = tostring(ProcessedAlert.JobUniqueId_g), BackupItemUniqueId_SH = tostring(ProcessedAlert.BackupItemUniqueId_s)
| extend TimeGenerated_SH = TimeGenerated, SelfhealSeverity_SH = SelfhealSeverity_s, SelfhealResult_SH = SelfhealResult_s
| project JobUniqueId_g , BackupItemUniqueId_SH, TimeGenerated_SH, SelfhealSeverity_s, SelfhealResult_s 
) on JobUniqueId_g 
| extend VMName = split(BackupItemUniqueId_s,";")[-1], BackupJobID = JobUniqueId_g, BackupJobFailureCode = JobFailureCode_s, TimeStampInAzureDiagnostics = TimeGenerated
| project VMName, BackupJobID, BackupJobFailureCode, _ResourceId, TimeStampInAzureDiagnostics, BackupManagementType_s
```

Result set will include the following data:
|Item|Description|Source| 
|:--- |:---|:---
|VMName|Azure backup item|AzureDiagnostics
|BackupJobID|Unique identifier of the backup job reference|AzureDiagnostics
BackupJobFailureCode|Error code of the backup job failure|AzureDiagnostics
|_ResourceId|Recovery services vault identifier|AzureDiagnostics
|BackupMgmtType|Type of workload being backed up|SelfHeal_CL

If a hybrid runbook worker was deployed, this query will show all job executions from the Automation account which executed using the worker VM -
Result set will include the following data:
|Item|Description|Source| 
|:--- |:---|:---
|JobId|Unique identifier of the runbook execution reference| AzureDiagnostics (Automation account), Event (Hybrid Worker)
|RunbookName|Runbook published in Automation account|AzureDiagnostics
|Computer|Hybrid Runbook Worker|Event
|Source|Event source|Event
|EventData|Details for the logged event|Event
|RenderedDescription|Summary of event|Event

#### Prerequisites
- Access to subscription with Owner role privileges
- PowerShell version 7.0 or higher
- Az module version 2.5 or higher

#### Script execution
1. Download the script package from the GitHub repository ***AzureManagedServices*** to your preferred directory.
2. Open PowerShell console (run as Administrator) and switch to script directory ***.\AzureManagedServices\Operations\SelfHeal\Reporting*** .
3. Run the command:
   ```
   .\reportAgentHealth.ps1 -dxcSubscriptionId <mySubscriptionId> -dxcLogAnalyticsWorkspaceName <myWorkspaceName>
   ```
    Note: 
   - dxcSubscriptionId - Subscription ID where the Hybrid Runbook VM is to be created.
   - dxcLogAnalyticsWorkspaceName - Managed Log Analytics workspace name onboarded for the subscription.
1. Wait until script execution finishes.
2. Review the report saved in the script directory (Excel) and validate the saved search items: 
   - Go to Log Analytics workspace > Saved searches. 
   - Filter "self-heal" > 'Hybrid Runbook Worker executions', 'Self-heal metrics', 'Self-heal defects'
