<#
.SYNOPSIS
    This will perform rollback of the selfheal components in the subscription depending on the rollback mode selected.
    If Disable, it will switch the actiongroup in DXC-Critical-Backup-Job Failure to use DXC-AG-Critical (ITSM).
    If Remove, it will switch the actiongroup in DXC-Critical-Backup-Job Failure to use DXC-AG-Critical (ITSM) and remove all the selfheal components.

    To report a bug or an issue with Self-heal, log the case here:
    https://confluence.csc.com/pages/viewpage.action?pageId=162089166 

.PARAMETER
    dxcSubscriptionID
    dxcLogAnalyticsWorkspaceName 
    rollbackmode <Disable or Remove>
    
.REVISION HISTORY
    Creation Date:  
    28-Nov-2019 - Initial script development
#>

[CmdletBinding()]
Param (
    # Descrption of parameter and command bindings
    [Parameter(
        HelpMessage = "Please enter DXC Subscription ID.", Position=1,
        Mandatory = $True,
        ValueFromPipeline = $True)]
    [ValidateNotNullOrEmpty()]
    [string]$dxcSubscriptionID,
        [Parameter(
        HelpMessage = "Please enter DXC WorkSpace Name.", Position=2,
        Mandatory = $True,
        ValueFromPipeline = $True)]
    [ValidateNotNullOrEmpty()]
    [string]$dxcLogAnalyticsWorkspaceName,
        [Parameter(
        HelpMessage = "Please enter RollBack mode (Disable or Remove).", Position=3,
        Mandatory = $True,
        ValueFromPipeline = $True)]
    [ValidateNotNullOrEmpty()]
    [ValidateSet("Disable","Remove")]
    [string]$rollbackmode
)
#---------------------------------------------------------[Initializations]--------------------------------------------------------

$ActionGrp = "DXC-AG-Critical"
$ActionGrp_SH = "DXC-AG-SelfHeal"
$AlertRules_SH =@("DXC-Critical-SelfHeal","DXC-Informational-SelfHeal")
$selfheal_modules = "SelfHeal.psm1"

if (!$rollbackMode) {$rollbackMode = "Disable"}

#----------------------------------------------------------[Declarations]----------------------------------------------------------
#Script logging
$Global:LogFilePath = ""
$tmpname ="rollbackSelfHeal"
$Global:LogFilePath = (Get-Item -Path .\ -Verbose).Fullname + '\' + $tmpname + '-{0:dd-MMM-yyyy_HHmm}' -f (Get-Date) + '.log'
New-Item $Global:LogFilePath -ItemType file | Out-Null

#-----------------------------------------------------------[Functions]------------------------------------------------------------


#-----------------------------------------------------------[Execution]------------------------------------------------------------

#importing selfheal modules
$curworkingdir = (Get-Location).Path
$modulepath = (Get-ChildItem -Path ((Get-Item -Path .\ -Verbose).Fullname | Split-Path -Parent) -Include $selfheal_modules -Recurse).DirectoryName
if ((($modulepath | Measure-Object | Select Count).Count) -gt 1){$psmodpath = $modulepath[0]}else{$psmodpath = $modulepath}
$psmodpath = Join-Path -Path $modulepath -Childpath "\$selfheal_modules"

Import-Module $psmodpath
Write-toLog "Imported powershell modules..." 0 $Global:LogFilePath

# Connect to Azure
Write-toLog "Connecting to Azure..." 0 $Global:LogFilePath
Connect-AzAccount
Set-AzContext -Subscription $dxcSubscriptionID

$WorkspaceObj = Get-AzResource -Name $dxcLogAnalyticsWorkspaceName -ResourceType 'Microsoft.OperationalInsights/workspaces'

#Changes the Actiongroup in DXC-Critical-Backup-Job Failure alert rule
Write-toLog "Switch to $ActionGrp in DXC-Critical-Backup-Job Failure alert rule." 0 $Global:LogFilePath
Switch-ActionGroup $WorkspaceObj $ActionGrp $ActionGrp_SH $AlertRules_SH $true $Global:LogFilePath $curworkingdir

#Rollback mode
if($RollbackMode -eq 'Remove'){
 
  #Get all components with tags
  $tagName="service"
  $tagValue="selfheal"

  #Get the ResourceGroupName that contains the selfheal tags
  $RGList = (Get-AzResource -TagName $tagName -TagValue $tagvalue).ResourceGroupName | Get-Unique
  
  #Removes Selfheal components with selfHeal tags
  foreach($itm in $RGList){
     Write-host "WARNING:     This will REMOVE Selfheal components from resourcegroupname : $itm in $dxcSubscriptionID." -ForegroundColor yellow
     $tmp = [String]::Concat("WARNING:     This will REMOVE Selfheal components from resourcegroupname : ", $itm, " in ", $dxcSubscriptionID)
     Write-toLog $tmp 2 $Global:LogFilePath

     Search-LockedComponents $itm $false $AlertRules_SH $ActionGrp_SH $tagName $tagValue $Global:LogFilePath
  }
  
  #doublecheck if selfheal components were removed
  $NewList = (Get-AzResource -TagName $tagName -TagValue $tagvalue).ResourceType| Get-Unique
  $FoundList = New-Object PSCustomObject
  
  foreach($itmnew in $NewList){
     if($itmnew -eq "Microsoft.Automation/AutomationAccounts"){$FoundList| Add-Member -Name "AutomationAccount" -MemberType NoteProperty -Value 'Found'}
     if($itmnew -eq "Microsoft.Logic/workflows"){$FoundList | Add-Member -Name "LogicApp" -MemberType NoteProperty -Value 'Found'}
  }
   
  if( @($FoundList.psobject.Properties).Count -eq 0) {Write-toLog "Successfully Removed all SelfHeal components from Azure subscription..." 0 $Global:LogFilePath}
  else{Write-toLog "Failed to Remove SelfHeal components from Azure subscription..." 1 $Global:LogFilePath }
  
}

Write-toLog "`n####################### END OF SCRIPT EXECUTION ###################################" 0 $Global:LogFilePath
$tmp = [String]::Concat("SelfHeal Resources ", $rollbackMode, "d.")
Exit-Program $tmp 0 $Global:LogFilePath

