
## Rollback procedure for Self-Heal

We need to consider a rollback procedure to revert alerting in case of the following scenarios:
-	Failed deployment or upgrade
-	‘Self-heal’ automation exits prematurely or unable to send alerts

To determine if automation fails prematurely, runs incorrectly or unable to send the events to ServiceNow, refer to data from reporting; documentation available [here](https://confluence.csc.com/display/ESCAT/AZR-9977+DEVELOP+REPORTING+FOR+SELF-HEAL+METRICS).

Two modes of rollback will be available – full and partial –
-	Full – deletes all components of self-heal and reverts the DXC-Critical-Backup Job Failure alert rule to use the ITSM action group (DXC-AG-Critical).
-	Partial – reverts the DXC-Critical-Backup Job Failure alert rule to use the ITSM action group (DXC-AG-Critical) and disables the self-heal alerts (DXC-Critical-SelfHeal and DXC-Informational-SelfHeal).

How to run the rollback procedure:
1.	Download the script repository from GitHub.
2.	Open a PowerShell console (run as Administrator), go to the folder ...\AzureOffering_ServiceNow-master\SelfHeal\rollback\ and run EITHER of the following commands below:

Partial rollback command (DISABLE):
```
.\rollbackSelfHeal.ps1 -dxcSubscriptionId <Customer subscription ID> -dxcLogAnalyticsWorkspaceName <DXC Workspace name> - rollbackmode DISABLE
```
Full rollback command (REMOVE):
```
.\rollbackSelfHeal.ps1 -dxcSubscriptionId <Customer subscription ID> -dxcLogAnalyticsWorkspaceName <DXC Workspace name> -rollbackmode REMOVE
```
3.	To validate, check if the alert “DXC-Critical-Backup-Job Failure” uses the assigned ITSM action group (DXC-AG-Critical).search for ‘self-heal’ components/instance from the Portal using Tags –
 
  &nbsp;&nbsp;&nbsp; a.	Launch the Portal and go to Monitor > Alerts and click Manage alert rules.

   &nbsp;&nbsp;&nbsp; b.	Search for and click on the alert rule - DXC-Critical-Backup-Job Failure

   &nbsp;&nbsp;&nbsp; c.	Check Actions, and ensure the configured action group lists “DXC-AG-Critical”

   &nbsp;&nbsp;&nbsp; d.	If partial rollback was performed, go back and search for the following alert rules: DXC-Critical-SelfHeal and DXC-Informational-SelfHeal. Ensure both alert rules have their status set to Disabled.

   &nbsp;&nbsp;&nbsp; e.	If full rollback was performed, go to All resources

   &nbsp;&nbsp;&nbsp; f.	Click Add filter and under Tags, select service == selfheal

   &nbsp;&nbsp;&nbsp; <em>Note: Results should return an empty set as full rollback deletes identified services tagged with selfheal.</em>


<br>
Additional reference can be found in Confluence - https://confluence.csc.com/display/ESCAT/Rollback+Plan+for+Self-Heal.

