
This folder hosts image contents.
