<#
.SYNOPSIS
  This runbook automates the steps to fix "ExtensionFailedVssWriterInBadState - Snapshot operation failed because VSS writers were in a bad state"
  As described here: https://docs.microsoft.com/en-us/azure/backup/backup-azure-vms-troubleshoot#extensionfailedvsswriterinbadstate---snapshot-operation-failed-because-vss-writers-were-in-a-bad-state

  To report a bug or an issue with Self-heal, log the case here:
  https://confluence.csc.com/pages/viewpage.action?pageId=162089166 

.PARAMETER
  [PSCustomObject]$JsonInput

.REVISION HISTORY
    Creation Date:  05-Jul-2019
    05-Jul-2019 - v.01 - Initial script development
    02-Apr-2020 - update commands
#>

#---------------------------------------------------------[Initializations]-------------------------------------------------------- 

Param(
     [parameter (Mandatory = $true)]
     [PSCustomObject]$JsonInput
)

#----------------------------------------------------------[Declarations]----------------------------------------------------------
$connectionName = "AzureRunAsConnection"
$RunBookName = "buaas-fixVssWriterInBadState"
$TriggerBackup = $false

#-----------------------------------------------------------[Functions]------------------------------------------------------------

# Supporting functions in this section

function Get-AzCachedAccessToken(){
    $ErrorActionPreference = 'Stop'
    $currentAzureContext = Get-AzContext
    $azureRmProfile = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile
    $profileClient = New-Object Microsoft.Azure.Commands.ResourceManager.Common.RMProfileClient($azureRmProfile)
    $token=$profileClient.AcquireAccessToken($currentAzureContext.Subscription.TenantId)
    $token.AccessToken
}

function Get-AzBearerToken(){
    $ErrorActionPreference = 'Stop'
    ('Bearer {0}' -f (Get-AzCachedAccessToken))
}

#-----------------------------------------------------------[Execution]------------------------------------------------------------

try
{
    # Get the connection "AzureRunAsConnection "
    $servicePrincipalConnection = Get-AutomationConnection -Name $connectionName 

    #"Logging in to Azure..."
    Connect-AzAccount -Tenant $servicePrincipalConnection.TenantID `
                  -ApplicationId $servicePrincipalConnection.ApplicationID   `
                  -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint `
                  -ServicePrincipal | Out-Null
    $Context = Set-AzContext -SubscriptionId $servicePrincipalConnection.SubscriptionId -WarningAction Ignore

    $subsID = $servicePrincipalConnection.SubscriptionId
    #"Logged In."

}catch {
    if (!$servicePrincipalConnection)
    {
        $ErrorMessage = "Connection $connectionName not found."
        throw $ErrorMessage       
    } else{
        Write-Error -Message $_.Exception
        throw $_.Exception
    }
}

Try{
   # Enable AzureRm compatibility
   Enable-AzureRmAlias

   # Get access token
   $ArmToken = Get-AzBearerToken

# Get Automation Account credential asset
$credentialAsset = Get-AutomationPSCredential -Name $JsonInput.AutomationCredential 
$userName= $jsonInput.VMName+"\"+$credentialAsset.UserName
$securePassword = $credentialAsset.Password
$cred = New-Object System.Management.Automation.PSCredential ($userName,$securePassword)

## Getting VM Info ##
 $ifVmExists = Get-AzResource -ResourceType "Microsoft.Compute/virtualMachines" -ResourceGroupName $jsonInput.VMRG -Name $jsonInput.VMName
    if (($error) -or ($ifVmExists -eq $null)){ 
    Write-Output "Unable to find VM in subcription."; Exit
    }else{$vmObj = Get-AzVM -Name $ifVmExists.Name -ResourceGroupName $ifVmExists.ResourcegroupName}


 $error.Clear()
  
 # Script block to check service "Volume Shadow Copy"
  $scriptVSS = {

  $objResults =  New-Object PsCustomObject -Property @{
    resultsMsg = ""
    resultsCode = ""
  }

  $objVSS = Get-WmiObject -Class Win32_Service -ComputerName $env:COMPUTERNAME | ? {$_.Name -eq "VSS"} -WA 0 -EA 0 -EV errVSS
    if ($errVSS -or ($objVSS -eq $null)) {
        $objResults.resultsMsg = "VSSWriters not found. $errVSS"
        $objResults.resultsCode = 1
        break        
    } else {
        if ($objVSS.StartMode -eq "Disabled") {
            $objVSS.Change($null,$null,$null,$null,"Manual",$null,$null,$null,$null,$null,$null)
        } 
        [int]$count=0
        do {
            Restart-Service -Name $objVSS.Name -Force -WA 0 -EA 0 -EV errVSS
            $count+=1 ; sleep 3
        } until (($count -eq 10) -or ((Get-Service -Name $objVSS.Name).Status -eq "Running"))
    }

  if ((Get-Service -Name $objVSS.Name).Status -eq "Running") {
    $objResults.resultsMsg = "Volume Shadow Copy was restarted successfully."
    $objResults.resultsCode = 0
  }else{
    $objResults.resultsMsg = "Failed to restart Volume Shadow Copy. $errVSS"
    $objResults.resultsCode = 1    
  }

  return $objResults
 }


# Script block to check service "VSS Writers"
 $scriptWriters = {
  [PSCustomObject[]]$WriterColl=@()

  $objResults =  New-Object PsCustomObject -Property @{
    resultsMsg = ""
    resultsCode = ""
  }

 $objWriters = vssadmin list writers | Select-String -Context 0,4 'Writer name:' | ? {$_.Context.PostContext[2].Trim() -ne "State: [1] Stable"} |  Select Line |  % {$_.Line.tostring().Split("'")[1]} -WA 0 -EA 0 -EV errWriters
  
 if($errWriters -or ($objWriters -ne $null)){

  $ServiceNames = $objWriters | 
      ForEach-Object {
          switch ($_) {
              'Bits Writer' { $Result = 'BITS'}
              'ASR Writer' { $Result = 'BITS'}
              'VSS Metadata Store Writer' { $Result = 'VSS'}
              'COM+ REGDB Writer' { $Result = 'VSS'}
              'Registry Writer' { $Result = 'VSS'}
              'Shadow Copy Optimization Writer' { $Result = 'VSS'}           
              'System Writer' { $Result = 'CryptSvc'}
              'WMI Writer' { $Result = 'Winmgmt'}     
              }
          $result
      }
       
  $Writers = $ServiceNames | Select-Object -Unique  

  foreach($item in $Writers){

     $Writerresults = New-Object PsCustomObject -Property @{
        "WName" = ""
        "WresultMsg" = ""
        "WresultCode" = ""
     }

    [int]$count=0
        do {
            Restart-Service -Name $item -Force -WA 0 -EA 0 -EV errWriters
            $count+=1 ; sleep 3
        } until (($count -eq 3) -or ((Get-Service -Name $item).Status -eq "Running"))
        
          $Writerresults.WName = $item
        if ((Get-Service -Name $item).Status -eq "Running") {
          $Writerresults.WresultMsg = "$item was restarted successfully."
          $Writerresults.WresultCode = 0
        }else{
          $Writerresults.WresultMsg = "Failed to restart $item. $errWriters"
          $Writerresults.WresultCode = 1
        } 

        $WriterColl+=$Writerresults
   } #foreach
 } #if


 if($writerColl.Count -eq 0){
     $objResults.resultsMsg = "Services associated with VSS Writers are Stable."
     $objResults.resultsCode = 0
 }else{
    if($WriterColl.WresultCode -eq 1){
      $objResults.resultsMsg = "Failed to restart Services associated with VSS Writers."
      $objResults.resultsCode = 1
    }else{
      $objResults.resultsMsg = "Services associated with VSS Writers restarted Successfully."
      $objResults.resultsCode = 0
    }
 }
 
  return $objResults
 }

$soptions = New-PSSessionOption -SkipCACheck
$resultsVSS = Invoke-Command -ComputerName $vmObj.Name -UseSSL -ScriptBlock $scriptVSS -Credential $cred -SessionOption $soptions -WA 0 -EA 0

  if (($error) -or ($resultsVSS.resultsCode -eq 1)) {
     $resultsWriter = Invoke-Command -ComputerName $vmObj.Name -UseSSL -ScriptBlock $scriptWriters -Credential $cred -SessionOption $soptions -WA 0 -EA 0

        if (($error) -or ($resultsWriter.resultsCode -eq 1)) {
            $runbookStatus = "Failed"
            $runbookOutput =  $resultsVSS.resultsMsg + $resultsWriter.resultsMsg + $error
        } else {
            $runbookStatus = "Success"
            $runbookOutput = $resultsVSS.resultsMsg + $resultsWriter.resultsMsg
            $TriggerBackup = $true
        }
  }else{
    $runbookStatus = "Success"
    $runbookOutput = $resultsVSS.resultsMsg
    $TriggerBackup = $true
  }


}catch {
    $runbookStatus = "Failed"
    $runbookOutput = $_.Exception.Message
    $TriggerBackup = $false

} finally {

 # Write runbook results to JSON output
 $ScriptJobId = $PsPrivateMetaData.JobId.GUid
 $selfhealMsg=[PSCustomObject]@{
    JobId = $ScriptJobId
    RunbookName = $RunBookName
    Status = $runbookStatus
    Output = $runbookOutput
 }

 if ($jsonInput.psobject.Properties.name -contains "TriggerBackup") {
    $jsonInput.TriggerBackup = $TriggerBackup
 } else {
    $jsonInput | Add-Member -MemberType NoteProperty -Name TriggerBackup -Value $TriggerBackup
 }

 $JsonInput.SelfhealResult = $runbookStatus
 [psCustomObject[]]$jsonInput.SelfhealMessage+=$selfhealMsg

 $jsonInput | ConvertTo-Json

}