#!/bin/bash
# DESCRIPTION: This script is used for the AgentHealth self-heal automation.
# Author: CloudOps Automation
# Initial version: June 16, 2021
# See for more information: 
# To report a bug or an issue with Self-heal, log the case here:
# https://confluence.csc.com/pages/viewpage.action?pageId=162089166

ACTION=$(echo $1 | cut -f1 -d"_")
WORKSPACEID=$(echo $1 | cut -f2 -d"_")
WORKSPACEKEY=$(echo $1 | cut -f3 -d"_")
OSNAME=$(cat /etc/os-release | grep ^NAME | tr -d 'NAME="' | cut -f1 -d" ")

# Check if OMSAgent is running
function check_oms {
    OMSPROCESS=$(ps -ef | grep -i omi)
    if [[ $OMSPROCESS == *omiagent* && $OMSPROCESS == *omiserver* && $OMSPROCESS == *omiengine* ]]; then
        OMSAGENT="OMSAGENT: OMI processes are Running."
    else 
        OMSAGENT="OMSAGENT: OMI processes are Not Running or incomplete."
    fi
    echo $OMSAGENT
}

# Restart OMSAgent
function restart_oms {
    if [[ $(check_oms) == "*Not Running*" ]]; then
        sudo /opt/microsoft/omsagent/bin/service_control restart > /dev/null
        OMSAGENTRESTARTED="OMSAGENT_RESTARTED: true"
    else
        OMSAGENTRESTARTED="OMSAGENT_RESTARTED: false"
    fi
    echo $OMSAGENTRESTARTED
}

# Purge OMSAgent
function purge_oms {
    sudo /opt/microsoft/omsagent/bin/service_control stop > /dev/null
    wget https://raw.githubusercontent.com/Microsoft/OMS-Agent-for-Linux/master/installer/scripts/onboard_agent.sh
    sh onboard_agent.sh --purge > /dev/null
}

# Verify if heartbeat is logged
function verify_heartbeat {
    HEARTBEATLOG=$(grep Heartbeat /var/opt/microsoft/omsagent/log/omsagent.log | tail -1)
    if [[ $HEARTBEATLOG == *succeeded* ]]; then
        HEARTBEATLOGTIME=$(grep Heartbeat /var/opt/microsoft/omsagent/log/omsagent.log | tail -1 | cut -c 1-19)
        CURRENTTIME=$(date '+%Y-%m-%d %H:%M:%S')
        VARIANCE="HEARTBEAT: ${HEARTBEATLOGTIME} ${CURRENTTIME}"
    else
        VARIANCE="HEARTBEAT: NULL"
    fi
    echo $VARIANCE
}

# Verify if primary workspace is correct
function onboard_workspace {
    #/opt/microsoft/omsagent/bin/omsadmin.sh -l
    CHECK_WORKSPACE=$(/opt/microsoft/omsagent/bin/omsadmin.sh -l)
    PRIMARY_WORKSPACE=$(echo $ONBOARD | cut -f3 -d" ")
    if [ $PRIMARY_WORKSPACE == $WORKSPACEID ] || [[ $CHECK_WORKSPACE == "*Onboarded(OMSAgent Running)*" ]]; then
        OMSAGENTREONBOARDED="OMSAGENT_REONBOARDED: false"
    else
        sudo ./opt/microsoft/omsagent/bin/omsadmin.sh -X > /dev/null
        sudo ./opt/microsoft/omsagent/bin/omsadmin.sh -w $WORKSPACEID -s $WORKSPACEKEY > /dev/null
        OMSAGENTREONBOARDED="OMSAGENT_REONBOARDED: true"
    fi
    echo OMSAGENTONBOARDSTATUS
}

# Purge OMSAgent
function purge_oms {
    sudo /opt/microsoft/omsagent/bin/service_control stop > /dev/null
    wget https://raw.githubusercontent.com/Microsoft/OMS-Agent-for-Linux/master/installer/scripts/onboard_agent.sh
    sh onboard_agent.sh --purge > /dev/null
}

# Check VM agent 
function check_vmagent {
    if [[ "$OSNAME" == "Ubuntu" ]]; then
        VMAGENT=$(sudo service walinuxagent status | head -n 5)
    else
        VMAGENT=$(sudo service waagent status | head -n 5)
    fi
    case $VMAGENT in
        *running* ) VMAGENTSTATUS="VMAGENT_STATUS: waagent is Running.";;
        *stopped* ) VMAGENTSTATUS="VMAGENT_STATUS: waagent is Stopped.";;
        *inactive* ) VMAGENTSTATUS="VMAGENT_STATUS: waagent is Inactive.";;
        * ) VMAGENTSTATUS="VMAGENT_STATUS: waagent status is Unknown. Please check agent manually.";;
    esac
    echo $VMAGENTSTATUS
}

# Restart VM agent
function restart_vmagent {
    if [[ "$OSName" == "Ubuntu" ]]; then
	    sudo systemctl restart walinuxagent > /dev/null
        #sudo service walinuxagent status | head -n 5
    else
	    sudo service waagent status > /dev/null
        #sudo service waagent status | head -n 5
    fi 
    echo "VMAGENT_RESTARTED: true"
}

# EXECUTION
case $ACTION in
    omsagentheartbeat) 
        ISRESTARTED=$(restart_oms)
        ISRUNNING=$(check_oms)
        if [ $ISRESTARTED == *true* && $ISRUNNING == *Not Running* ]; then
            purge_oms
            OMSAGENTUNINSTALLED="OMSAGENT_UNINSTALLED: true"
            HEARTBEAT="N/A"
        else
            OMSAGENTUNINSTALLED="OMSAGENT_UNINSTALLED: false"
            HEARTBEAT=$(verify_heartbeat)
        fi
        echo $ISRESTARTED
        echo $ISRUNNING
        echo $OMSAGENTUNINSTALLED
        echo $HEARTBEAT
        ;;
    omsagentonboard)
        onboard_workspace
        ONBOARDSTATE=$(/opt/microsoft/omsagent/bin/omsadmin.sh -l)
        echo "OMSAGENT_ONBOARD_STATUS: $ONBOARDSTATE"
        HEARTBEAT=$(verify_heartbeat)
        ;;
    vmagentrestart)
        CHECKVMAGENT=$(check_vmagent)
        if [[ $CHECKVMAGENT == *Running* ]]; then 
            echo "VMAGENT_RESTARTED: false"
            echo $CHECKVMAGENT
        else
            restart_vmagent
            check_vmagent
        fi
        echo "WAAGENT_INSTALLED_VERSION: $(waagent --version | head -n 1 | cut -f2 -d"-" | cut -f1 -d" ")"
        UPGRADEVERSION=$(echo $(sudo yum check-update WALinuxAgent | grep -i WALinuxAgent) | cut -f2 -d" " | cut -f1 -d"-")
        echo "WAAGENT_LATEST_VERSION: $UPGRADEVERSION"
        ;;
    *)
        echo "ACTION: NONE"
        ;;
esac
