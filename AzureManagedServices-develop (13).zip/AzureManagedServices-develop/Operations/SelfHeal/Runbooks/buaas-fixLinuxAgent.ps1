﻿#region COMMENTS
<#
.SYNOPSIS
    This runbook will reinstall VM agent as it is Out of date (for Linux VMs)."
    As described here : https://docs.microsoft.com/en-us/azure/backup/backup-azure-troubleshoot-vm-backup-fails-snapshot-timeout#the-agent-installed-in-the-vm-is-out-of-date-for-linux-vms

    To report a bug or an issue with Self-heal, log the case here:
    https://confluence.csc.com/pages/viewpage.action?pageId=162089166 
    
    Supported OS:
    https://confluence.dxc.com/display/CSA/Supported+OS+Versions 

.PARAMETER
    [PSCustomObject]$JsonInput
    
.REVISION HISTORY
    Creation Date:  11-Jun-2019
    11-Jun-2019 - v.01 - Initial script development
    02-Apr-2020 - Update commands
    17-Jun-2021 - include try-catch and change uri
#>
#endregion

#region PARAMETERS
Param(
     [Parameter (Mandatory = $true)]
     [PSCustomObject]$JsonInput
 )
#endregion

#---------------------------------------------------------[Initializations]--------------------------------------------------------

$modname= 'Orchestrator.AssetManagement.Cmdlets'

#----------------------------------------------------------[Declarations]----------------------------------------------------------
$RunBookName="buaas-fixLinuxAgent"
$connectionName = "AzureRunAsConnection"
$urlbash = "https://dxcazuretools.blob.core.windows.net/selfheal/runbooks/"

$Global:CombinedProps=[PSCustomObject]@{
    AgentName ="WALinuxAgent"
    AgentVersion=""
    OSFlavor=""
    OSVersion=""
}
#-----------------------------------------------------------[Functions]------------------------------------------------------------

#region FUNCTIONS
# Supporting functions in this section

function Get-AzCachedAccessToken(){
    $ErrorActionPreference = 'Stop'
    $currentAzureContext = Get-AzContext
    $azureRmProfile = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile
    $profileClient = New-Object Microsoft.Azure.Commands.ResourceManager.Common.RMProfileClient($azureRmProfile)
    $token=$profileClient.AcquireAccessToken($currentAzureContext.Subscription.TenantId)
    $token.AccessToken
}

function Get-AzBearerToken(){
    $ErrorActionPreference = 'Stop'
    ('Bearer {0}' -f (Get-AzCachedAccessToken))
}

function Get-SSH_Session($vmObj, $targetVM, $cred, $OStype){

    if($OStype -eq "Linux"){
         $sshSession = New-SSHSession -ComputerName $targetVM -Credential $cred -AcceptKey:$true -ErrorAction SilentlyContinue       
       if ($sshSession.State -eq 'Opened' -or $sshSession.Connected -eq 'True') {
         $result = "Success"
         $msg = "VM connection: OK - $vmObj.Name is reachable from the Hybrid Worker VM. "
       } else {
         $result = "Fail"
         $msg = "VM connection: NOK - $vmObj.Name is unreachable from the Hybrid Worker VM. "
         Get-SSHTrustedHost | Remove-SSHTrustedHost
       }
    }else{
      $result = "Fail" 
      $msg = "$vmObj.Name is a $OStype machine."}


   return $sshSession, $result, $msg
}

function Get-OSversion($sshSession){

  $osflavor = Invoke-SSHCommand -SSHSession $sshSession `
                -Command {getOSVersion=$(cat /etc/os-release | grep ^NAME | tr -d 'NAME="'); echo $getOSVersion} -WA 0 -EA 0
  
   if(($osflavor.output).tolower() -match "centos"){
       $Global:CombinedProps.OSFlavor="centos"
   }elseif(($osflavor.output).tolower() -match "ubuntu"){
       $Global:CombinedProps.OSFlavor="ubuntu"
   }elseif(($osflavor.output).tolower() -match "sls"){
      $Global:CombinedProps.OSFlavor="sls"
   }elseif(($osflavor.output).tolower() -match "red hat"){
      $Global:CombinedProps.OSFlavor="rhel"
   }elseif(($osflavor.output).tolower() -match "oracle"){
      $Global:CombinedProps.OSFlavor="oracle"
   }else{
      $Global:CombinedProps.OSFlavor="Not supported"
   }
  
  $osverId = Invoke-SSHCommand -SSHSession $sshSession `
                -Command {osVerId="$(cat /etc/os-release | grep -i "VERSION_ID=" | head -1)"; echo "$osVerId" | tr -d '"' | tr -d "VERSION_ID="} -WA 0 -EA 0
  $Global:CombinedProps.OSVersion=$osverId.Output[0]
}


#endregion

#-----------------------------------------------------------[Execution]------------------------------------------------------------

#region MAIN
try
{

 #Import modules
 Import-Module $modname

 # Get the connection "AzureRunAsConnection "
 $servicePrincipalConnection = Get-AutomationConnection -Name $connectionName
 $subsID = $servicePrincipalConnection.SubscriptionId

 #"Logging in to Azure..."
 Add-AzAccount -Tenant $servicePrincipalConnection.TenantID `
             -ApplicationId $servicePrincipalConnection.ApplicationID `
             -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint `
             -ServicePrincipal | Out-Null
 $Context = Set-AzContext -SubscriptionId $servicePrincipalConnection.SubscriptionId -WarningAction Ignore
 #"Logged In."

}catch {
    if (!$servicePrincipalConnection)
    {
        $ErrorMessage = "Connection $connectionName not found."
        throw $ErrorMessage       
    } else{
        Write-Error -Message $_.Exception
        throw $_.Exception
    }
}
 
Try{
 # Authentication
 $ArmToken = Get-AzBearerToken

# GET PS CREDENTIAL, SAME LOCAL ACCOUNT ON TARGET HOST.
$myCredential = Get-AutomationPSCredential -Name $JsonInput.AutomationCredential
$userName= $myCredential.UserName
$securePassword = $myCredential.Password
$cred = New-Object System.Management.Automation.PSCredential ($userName,$securePassword)

 ## Getting VM Info ##
 $ifVmExists = Get-AzResource -ResourceType "Microsoft.Compute/virtualMachines" -ResourceGroupName $jsonInput.VMRG -Name $jsonInput.VMName
    if (($error) -or ($ifVmExists -eq $null)){ 
    Write-Output "Unable to find VM in subcription."; Exit
    }else{$vmObj = Get-AzVM -Name $ifVmExists.Name -ResourceGroupName $ifVmExists.ResourcegroupName}

 ## Getting targetVM ##
 if (Test-Connection -ComputerName $vmObj.Name -Count 3 -Quiet){ 
   $targetComputer = $vmObj.Name
 }else{
   $targetComputer = (Get-AzNetworkInterface -ResourceId $VM.NetworkProfile.NetworkInterfaces.Id).IpConfigurations.PrivateIpAddress
    if($error) { 
       Write-Output "Failed connection test for$vmObj.Name"
       throw
    }else{ $targetComputer = $vmPrivateIP  }
 }

 $error.Clear()
 ## Getting SSHSession ##
 $sshSession, $SessResult, $SelfHealMessage=Get-SSH_Session $vmObj $targetComputer $cred $JsonInput.OSType

 if($SessResult -eq "Success"){
   ## Geting the OS flavor and version... ##
   Get-OSversion $sshSession

   ## Checking Agent Version ##
   $GetAgentVersion = Invoke-SSHCommand -SSHSession $sshSession -Command {agentver="$(sudo waagent --version | grep -i WALinuxAgent | head -1)"; echo "$agentver"; sleep 2} -WA 0 -EA 0
   $agentver = ((($GetAgentVersion.Output[0]).split("-")| Select -Last 1).split("run") | Select -First 1).trim()
   $Global:CombinedProps.AgentVersion=$agentver

   ## Download bash script from storage account ##
   $bashscriptfile = ""

 Switch ($Global:CombinedProps.OSFlavor){
      "centos" {$bashscriptfile = "fixLinuxAgent_centos.sh"; $prevbashscriptfile = "fixLinuxAgentcentos.sh"  ; break}
      "rhel" {$bashscriptfile = "fixLinuxAgent_centos.sh" ; $prevbashscriptfile = "fixLinuxAgentcentos.sh"; break}
      "oracle" {$bashscriptfile = "fixLinuxAgent_centos.sh" ; $prevbashscriptfile = "fixLinuxAgentcentos.sh"; break}
      "ubuntu" {$bashscriptfile = "fixLinuxAgent_ubuntu.sh" ; $prevbashscriptfile = "fixLinuxAgentubuntu.sh"; break}
      "sls" {$bashscriptfile = "fixLinuxAgent_sls.sh" ; $prevbashscriptfile = "fixLinuxAgentsls.sh"; break}
    }
  
   ## Download file from storage account ##
   if ($bashscriptfile -ne ""){
      $urlbashscript = [String]::Concat($urlbash,$bashscriptfile)
   
      ## Creating the download script on target VM ##
$StringtoWrite=@"
   # This function will download bash script on the target VM
   date +"%Y-%m-%d_%H-%M-%S: Script execution started."
   if [ -f $bashscriptfile ]; then
   date +"%Y-%m-%d_%H-%M-%S: Deleting previous $prevbashscriptfile  File..."
   rm $prevbashscriptfile -f
   sleep 2
   fi
   date +"%Y-%m-%d_%H-%M-%S: Downloading File latest $bashscriptfile..."
   sudo wget $urlbashscript
   Sleep 5
   if [ -f $bashscriptfile ]; then
   date +"%Y-%m-%d_%H-%M-%S: $bashscriptfile exists."
   else
   date +"%Y-%m-%d_%H-%M-%S: $bashscriptfile do not exists."
   fi
"@

   ## Running to target VM ##
   $createShellScript = Invoke-SSHCommand -SSHSession $sshSession -Command "echo '$StringtoWrite' >> temp.sh; `
     sed 's/\r//g' temp.sh>wgetbashscript.sh; `
     chmod +x wgetbashscript.sh; rm -f temp.sh"

   $dwnbashfile = Invoke-SSHCommand -SSHSession $sshSession -Command {sleep 1; sudo ./wgetbashscript.sh; sleep 3; date +"%Y-%m-%d_%H-%M-%S: Script execution ended.".}

    ## Running the update bash script inside the target VM ###
    if(($dwnbashfile.Output).tolower() -notmatch "do not exists."){
     
     Switch ($Global:CombinedProps.OSFlavor){   #centos/rhel/oracle linux uses only 1 script fixLinuxAgent_centos.sh
       "centos" { 
                 $ModShellScript = Invoke-SSHCommand -SSHSession $sshSession -Command "sed 's/\r//g' fixLinuxAgent_centos.sh>fixLinuxAgentcentos.sh; `
                     chmod +x fixLinuxAgentcentos.sh; rm -f fixLinuxAgent_centos.sh"
                 $upgradebash = Invoke-SSHCommand -SSHSession $sshSession -Command {sleep 1; sudo ./fixLinuxAgentcentos.sh; date +"%Y-%m-%d_%H-%M-%S: Script execution ended."} 
                 break}

       "rhel" { 
                  $ModShellScript = Invoke-SSHCommand -SSHSession $sshSession -Command "sed 's/\r//g' fixLinuxAgent_centos.sh>fixLinuxAgentcentos.sh; `
                     chmod +x fixLinuxAgentcentos.sh; rm -f fixLinuxAgent_centos.sh"
                  $upgradebash = Invoke-SSHCommand -SSHSession $sshSession -Command {sleep 1; sudo ./fixLinuxAgentcentos.sh; date +"%Y-%m-%d_%H-%M-%S: Script execution ended."} 
                  break}

       "oracle" { 
                  $ModShellScript = Invoke-SSHCommand -SSHSession $sshSession -Command "sed 's/\r//g' fixLinuxAgent_centos.sh>fixLinuxAgentcentos.sh; `
                     chmod +x fixLinuxAgentcentos.sh; rm -f fixLinuxAgent_centos.sh"
                  $upgradebash = Invoke-SSHCommand -SSHSession $sshSession -Command {sleep 1; sudo ./fixLinuxAgentcentos.sh; date +"%Y-%m-%d_%H-%M-%S: Script execution ended."} 
                  break}

       "ubuntu" { 
                  $ModShellScript = Invoke-SSHCommand -SSHSession $sshSession -Command "sed 's/\r//g' fixLinuxAgent_ubuntu.sh>fixLinuxAgentubuntu.sh; `
                     chmod +x fixLinuxAgentubuntu.sh; rm -f fixLinuxAgent_ubuntu.sh"
                  $upgradebash = Invoke-SSHCommand -SSHSession $sshSession -Command {sleep 1; sudo ./fixLinuxAgentubuntu.sh; date +"%Y-%m-%d_%H-%M-%S: Script execution ended."}
                  break}
       
       "sls" { 
                  $ModShellScript = Invoke-SSHCommand -SSHSession $sshSession -Command "sed 's/\r//g' fixLinuxAgent_sls.sh>fixLinuxAgentsls.sh; `
                     chmod +x fixLinuxAgentsls.sh; rm -f fixLinuxAgent_sls.sh"
                  $upgradebash = Invoke-SSHCommand -SSHSession $sshSession -Command {sleep 1; sudo ./fixLinuxAgentsls.sh; date +"%Y-%m-%d_%H-%M-%S: Script execution ended."} 
                  break}
     }

     $cleanup = Invoke-SSHCommand -SSHSession $sshSession -Command {sleep 1; sudo rm -f wgetbashscript.sh; date +"%Y-%m-%d_%H-%M-%S: Script execution ended."} 

      if(($upgradebash.output).tolower() -match "waagent is running."){
        $SHResult= "Success"
        $SHMessage= "WALinuxAgent Re-Installation Success."
        $TriggerBackup = $true
      }else{
        $SHResult= "Fail"
        $SHMessage= "WALinuxAgent Re-Installation Fail."
        $TriggerBackup = $false
      }
    }else{
      $SHResult= "Fail"
      $SHMessage= "Error Downloading the BASH script for upgrade."
      $TriggerBackup = $false
    }
   }else{  #-- bashscript -ne "" --
      $SHResult= "Fail"
      $SHMessage= "Linux flavor NOT supported."
      $TriggerBackup = $false 
    }

   #Log-OUT
   $LogOutRemoteLinux = Remove-SSHSession -SSHSession $sshSession -Verbose
   Get-SSHTrustedHost | Remove-SSHTrustedHost

 }else{
    $SHResult= $SessResult
    $SHMessage= "Connection thru SSH Session Failed."
    $TriggerBackup = $false
 }


}catch{
    $SHResult = "Failed"
    $SHMessage = $_.Exception.Message
    $TriggerBackup = $false
}finally{
   # Write runbook results to JSON output
   $ScriptJobId = $PsPrivateMetaData.JobId.GUid 
   $selfhealMsg=[PSCustomObject]@{ 
      JobId = $ScriptJobId
      RunbookName = $RunBookName 
      Status = $SHResult
      Output = $SHMessage 
   } 

   if($jsonInput.psobject.Properties.name -contains "TriggerBackup") {
       $jsonInput.TriggerBackup = $TriggerBackup
    }else{
       $jsonInput | Add-Member -MemberType NoteProperty -Name TriggerBackup -Value $TriggerBackup
    }

    $JsonInput.SelfHealResult = $SHResult
    [PSCustomObject[]]$JsonInput.SelfhealMessage+=$selfhealMsg
    
    ### Output to JSON ###
    $JsonInput | ConvertTo-Json
}