﻿<# description: Crowdstrike
 Author: CloudOps Automation
 Initial version: June 3, 2021
 See for more information: 
 To report a bug or an issue with Self-heal, log the case here:
 https://confluence.csc.com/pages/viewpage.action?pageId=162089166
#>

$logFilePath = "C:\Temp\fixCSAgentlog" + '-{0:dd-MMM-yyyy}' -f (Get-Date) + '.log'


Try{
  $Error.clear()
  $start=Get-Date

  # Create the log file.
  New-Item $logFilePath -ItemType File -Force | Out-Null
  Start-Transcript -Path $logFilePath -Append -EA 0 | Out-Null
  
  # getting OS details
  $computerinfo = Get-ComputerInfo 
  Sleep 3

  # getting hostname
  $hostname=$computerinfo.csName
  
  # getting the Osversion
  $osversion = $computerinfo.OsName
   
  # checking crowdstrike agent
  $agtstatus=(Get-Service -Name csagent).Status
  if (!([string]::IsNullOrEmpty($agtstatus))){
     if($agtstatus -ne "Running"){
        Restart-Service -Name csagent
        Sleep 2
        $agentrestarted=$true
        $agtstatus=(Get-Service -Name csagent).Status
     }else{
        $agentrestarted=$false
     }

     #getting processID
     $processid = (Get-Process -Name CSFalconService).Id

  }else{
     $agtstatus="agent not found"
     $agentrestarted=$false
     $processid="processid not found"
  }

  # checking crowdstrike connection
  $chkconn=netstat -an | find '"443"' | find '"ESTABLISHED"'
  $connection=$chkconn
  Sleep 2

  # get the applicationfiles
  $arrfiles=@()
  if(Test-Path -Path 'C:\Program Files\CrowdStrike'){
     $cspath=Get-ChildItem -Path 'C:\Program Files\CrowdStrike' | % {$_.FullName} -WA 0 -EA 0
     $arrfiles=$cspath
  }

  if(Test-Path -Path 'C:\Program Files (x86)\CrowdStrike'){
     $cspath=Get-ChildItem -Path 'C:\Program Files (x86)\CrowdStrike' | % {$_.FullName} -WA 0 -EA 0
     $arrfiles+=$cspath
  }
  Sleep 2

  if (!([string]::IsNullOrEmpty($cspath))){
     $applicationfiles=$arrfiles
  }else{
     $applicationfiles="application files not found"
  }
  
  #get the proxy settings
  $proxytmp=netsh winhttp show proxy
  if (!([string]::IsNullOrEmpty($proxytmp))){
     $proxy=$proxytmp|where({$_ -ne ""})  #removing empty contents
  }else{
     $proxy="proxy command failed"
  }

  switch ($agtstatus){
    'Stopped' {$csstatus='Stopped'; break}     
    'StartPending' {$csstatus='StartPending'; break}
    'StopPending' {$csstatus='StopPending'; break}
    'Running' {$csstatus='Running'; break}
    'ContinuePending' {$csstatus='ContinuePending'; break}
    'PausePending' {$csstatus='PausePending'; break}
    'Paused' {$csstatus='Paused'; break}
    default {$csstatus='agent not found'} 
  }
  

  $objResults =  New-Object PsCustomObject -Property ([ordered] @{
      hostname=$computerinfo.csName
      osversion=$computerinfo.OsName
      agentstatus=$csstatus
      agentrestarted=$agentrestarted
      processid=$processid
      connection=$chkconn
      applicationfiles=$applicationfiles
      proxy=$proxy
      logfile=$logFilePath
  })
 
  Write-Output $objResults | Convertto-Json

}catch{
Write-Output ("ERROR: Script executed with errors.")
Write-Output ($_.Exception.Message)

}Finally{
Stop-Transcript -EA 0 | Out-Null 
}