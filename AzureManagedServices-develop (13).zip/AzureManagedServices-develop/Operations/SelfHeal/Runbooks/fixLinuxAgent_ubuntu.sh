#!/bin/bash
# description: Update Linux VM Agent
# Author: CloudOps Automation
# Initial version: March 30, 2020
# See for more information:  https://docs.microsoft.com/en-us/azure/virtual-machines/linux/update-agent
# To report a bug or an issue with Self-heal, log the case here:
# https://confluence.csc.com/pages/viewpage.action?pageId=162089166


#Create log file
TIMESTAMP=`date +"%Y-%m-%d"`
LOGFILE="/tmp/fixLinuxAgentlog-$TIMESTAMP.txt"

#Remove if there is existing log file
if [ -f "$LOGFILE" ];then
/bin/rm $LOGFILE
fi

#Function to check waagent status
function check_waagentstat {
        #Get  waagent service status
        if [ "$OSVERSION" -gt "14" ]; then
        GETAGENTSTAT=`sudo systemctl status walinuxagent.service`
        sleep 3
        else 
        GETAGENTSTAT=`sudo initctl status walinuxagent`
        sleep 3
        fi

        case $GETAGENTSTAT in
             *start* ) AGENTSTAT="waagent is running.";;
             *active* ) AGENTSTAT="waagent is running.";;
             *stop* ) AGENTSTAT="waagent is stopped.";;
             *inactive* ) AGENTSTAT="waagent is stopped.";;
             * ) AGENTSTAT="waagent status is unknown. Please check agent manually.";;
        esac
}

#Function to restart service waagent
function restart_waagent {
        echo "Restart waagent service" | tee -a $LOGFILE

        if [ "$OSVERSION" -gt "14" ]; then
        sudo systemctl restart walinuxagent.service > /dev/null
        sleep 3
        else
        sudo initctl restart walinuxagent > /dev/null
        sleep 3
        fi
}


#Function to install waagent
function install_waagent {
     sudo apt-get install walinuxagent -y
}

#Function to update configuration file
function update_config {
        echo "Enable AutoUpdate and Extensions in configuration file /etc/waagent.conf" | tee -a $LOGFILE
        sudo sed -i 's/\# AutoUpdate.Enabled=y/AutoUpdate.Enabled=y/g' /etc/waagent.conf
        sudo sed -i 's/\# Extensions.Enabled=y/Extensions.Enabled=y/g' /etc/waagent.conf
        grep -E "AutoUpdate.Enabled|Extensions.Enabled" /etc/waagent.conf
}

#Function to output summary
function display_sum {
        echo "VMName: $VMNAME"
        echo "OS version: $OS"
        echo "Linux VM Agent version: $NEWVER"
        echo "$AGENTSTAT"
        echo "Log file: $LOGFILE"
}



#Get VMName
VMNAME=`uname -n`
echo "VMName: $VMNAME" | tee -a $LOGFILE

#Get OS version
OS=`grep PRETTY  /etc/os-release | cut -d "=" -f2 | cut -d "\"" -f2`
echo "OS version: $OS" | tee -a $LOGFILE

#DispGetlay OS version
OSVERSION=`cat /etc/os-release | grep -i "VERSION_ID="| tr -d '"'| tr -d "VERSION_ID="|awk '{print substr ($0,0,2)}'`



#Check waagent
if [ -f "/usr/sbin/waagent" ];then
CURRENTVER=`/usr/sbin/waagent --version | grep WALinuxAgent | awk '{print $1}'` #Get current version of waagent
echo "Linux VM Agent version: $CURRENTVER" | tee -a $LOGFILE

#Check available updates
echo "Checking for available updates" | tee -a $LOGFILE
sudo apt-get -qq update # quiet

echo " "
#Install the latest package version
echo "Install if there is a latest package" | tee -a $LOGFILE
install_waagent >> $LOGFILE 2>&1

    if [ $? -ne "0" ]; then
        ERROR=`grep  "E:" $LOGFILE`
        restart_waagent #Start  waagent service after installation
        check_waagentstat #Get  waagent service status
        echo " "
        echo "#######################"
        display_sum  | tee -a $LOGFILE #Display summary of output
        echo $ERROR

    elif
       `/bin/grep -q "Nothing to do" $LOGFILE`;then
        echo "Nothing to do. Installed waagent is in latest version." | tee -a $LOGFILE
        restart_waagent #Restart waagent service
        echo " "
        update_config #Ensure auto update is enabled
        check_waagentstat #Get  waagent service status
        NEWVER=`/usr/sbin/waagent --version | grep WALinuxAgent | awk '{print $1}'` #Get version of waagent after attempting update
        echo " "
        echo "#######################"
        echo "waagent is in latest version and service was restarted"
        display_sum  | tee -a $LOGFILE #Display summary of output

    else
        echo "Latest package version installed."  | tee -a $LOGFILE
        restart_waagent #Restart waagent service
        echo " "
        update_config #Ensure auto update is enabled
        check_waagentstat #Get  waagent service status
        NEWVER=`/usr/sbin/waagent --version | grep WALinuxAgent | awk '{print $1}'` #Get version of waagent after attempting update
        echo " "
        echo "#######################"
        echo "waagent  latest version installed and service was restarted"
        display_sum  | tee -a $LOGFILE #Display summary of output
     fi

else

echo " "
#Install the  waagent package
echo "No waagent found. Installing latest WALinuxAgent package" | tee -a $LOGFILE
install_waagent >> $LOGFILE 2>&1

    if [ $? -ne "0" ]; then
        ERROR=`grep "E:" $LOGFILE`
        restart_waagent #Start  waagent service after installation
        check_waagentstat #Get  waagent service status
        echo " "
        echo "#######################"
        echo $ERROR
        display_sum  | tee -a $LOGFILE #Display summary of output
    else
        #Get version of waagent after installing WALinuxAgent package
        NEWVER=`/usr/sbin/waagent --version | grep WALinuxAgent | awk '{print $1}'`
        echo "$NEWVER installed." | tee -a $LOGFILE
        update_config #Ensure auto update is enabled
        restart_waagent #Start  waagent service after installation
        check_waagentstat #Get  waagent service status
        echo " "
        echo "#######################"
        display_sum  | tee -a $LOGFILE #Display summary of output
    fi

fi

if [[ -z "$ERROR" ]]; then
   exit 0
else
   exit 1
fi
