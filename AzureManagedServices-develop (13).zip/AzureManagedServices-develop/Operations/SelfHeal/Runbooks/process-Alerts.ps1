﻿#region COMMENTS
<#
.SYNOPSIS
    This runbook will be placed as an Action Group to process-alerts coming from LogAnalytics.
    It will trigger individual logic app self-heal.
    
    To report a bug or an issue with Self-heal, log the case here:
    https://confluence.csc.com/pages/viewpage.action?pageId=162089166 
    
.PARAMETER
    [PSCustomObject]$WebhookData
.REVISION HISTORY
    Creation Date:  20-Jun-2019
    20-Jun-2019 - v.01 - Initial script development
    05-Sep-2019 - added support for different RG
    29-Oct-2019 - added backupmanagementtype
    23-Jan-2020 - updated logicappname
    08-June-2020 - AZR-14542
    09-Sep-2020 - AZR-17176 and AZR-17364
    18-Nov-2020 - AZR 18701
    11-Jun-2021 - AZR-23696 include crowdstrike alerts
#>
#endregion

#region PARAMETERS
Param(
     [Parameter (Mandatory = $true)]
     [PSCustomObject]$WebHookData
 )
#endregion

#----------------------------------------------------------[Declarations]----------------------------------------------------------
$connectionName = "AzureRunAsConnection"
$RunbookName="process-Alerts"

#-----------------------------------------------------------[Functions]------------------------------------------------------------

function Get-AzCachedAccessToken(){
    $ErrorActionPreference = 'Stop'
    $currentAzureContext = Get-AzContext
    $azureRmProfile = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile
    $profileClient = New-Object Microsoft.Azure.Commands.ResourceManager.Common.RMProfileClient($azureRmProfile)
    $token=$profileClient.AcquireAccessToken($currentAzureContext.Subscription.TenantId)
    $token.AccessToken
}

function Get-AzBearerToken(){
    $ErrorActionPreference = 'Stop'
    ('Bearer {0}' -f (Get-AzCachedAccessToken))
}


function Call-LogicApp{
    [CmdletBinding()]
    Param(
       [Parameter(Mandatory)]
       [String]$subsID,
       [Parameter(Mandatory)]
       [PSCustomObject]$jsoninfo

    )
  Try{
    $ScriptJobId = $PsPrivateMetaData.JobId.GUid
    
    $selfhealMsg =  New-Object PsCustomObject -Property ([ordered] @{
        JobId= $ScriptJobId
        RunbookName= $RunbookName
        Status= ""
        Output= ""
    })      
  
    $ArmToken = Get-AzBearerToken
    $logicappName=Get-AutomationVariable -Name "logicappname"

     $laObj= Get-AzResource -ResourceType "Microsoft.Logic/workflows" -Name $logicappName -ErrorAction SilentlyContinue
    if (!([string]::IsNullOrEmpty($laObj))){
        #get the logic app to get the state
        $lash=Get-AzLogicApp -Name $laObj.Name -ResourceGroupName $laObj.ResourceGroupName -ErrorAction SilentlyContinue

        if($lash.State -eq "Disabled"){
           $errmsg="ERROR: Logic App is in Disabled State."
           throw $errmsg
        }else{
           $runbookStatus="Success" 
           $runbookOutput="Parsed alert activity completed."

           $jsoninfo.SelfhealResult=$runbookStatus
           $selfhealmsg.Status=$runbookStatus
           $selfhealmsg.Output=$runbookOutput

           $jsoninfo.SelfhealMessage=$selfhealMsg
           $body= $jsoninfo | ConvertTo-Json

           $urila="https://management.azure.com/subscriptions/$($subsID)/resourceGroups/$($laObj.ResourceGroupName)/providers/Microsoft.Logic/workflows/$($laObj.Name)/triggers/manual/run?api-version=2016-06-01"
             
           $Response = Invoke-WebRequest -Uri  `
              $urila `
              -Method POST `
              -ContentType "application/json;charset=UTF-8" `
              -Body $body  `
              -Headers @{Authorization ="$ArmToken"}`
              -UseBasicParsing

           $StatusCode = $Response.StatusCode
           if(!(($StatusCode -eq 200) -or ($StatusCode -eq 202))){
               $shmsg ="ERROR: Logic App triggered failed.. Response code is $StatusCode."
           }else{
               $shmsg = "Logic App triggered successfully. See Logic App run history."
           }
        }
    }else{
       $shmsg="ERROR: No Logic App found for Selfheal in the subscription."
      }
    
    return $shmsg, $jsoninfo

  }catch{
      Write-Error "Error in Call-LogicApp function. $($_.Exception.Message) + $($shmsg)"
  }
}
#-----------------------------------------------------------[Execution]------------------------------------------------------------

#region MAIN

# connecting to Azure
try
{
    # Get the connection "AzureRunAsConnection "
    $servicePrincipalConnection = Get-AutomationConnection -Name $connectionName 

    #"Logging in to Azure..."
    Add-AzAccount -Tenant $servicePrincipalConnection.TenantID `
                  -ApplicationId $servicePrincipalConnection.ApplicationID   `
                  -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint `
                  -ServicePrincipal | Out-Null
    $Context = Set-AzContext -SubscriptionId $servicePrincipalConnection.SubscriptionId -WarningAction Ignore

    $subsID = $servicePrincipalConnection.SubscriptionId
    #"Logged In."
}
catch {
    if (!$servicePrincipalConnection)
    {
        $ErrorMessage = "ERROR: Connection $connectionName not found."
        throw $ErrorMessage
    } else{
        Write-Error -Message $_.Exception
        throw $_.Exception
    }
}

try {
  $error.clear()

  if ($WebHookData){
    if ($WebHookData.RequestBody){
       $WebHookDataBody = (ConvertFrom-Json -InputObject $WebHookData.RequestBody)
 
       #To place into PSCustomObject
        $procalert =  New-Object PsCustomObject -Property ([ordered] @{
            alertRule= ""
            description= ""
            SearchQuery= ""
            ResourceId=""
            SearchIntervalStart=""
            SearchIntervalEnd=""
            SearchResults=""
        })
 
        $procalert.alertRule=$WebHookDataBody.AlertRuleName
        $procalert.description=$WebHookDataBody.Description
        $procalert.SearchQuery=$WebHookDataBody.SearchQuery
        $procalert.ResourceId=$WebHookDataBody.ResourceId
        $procalert.SearchIntervalStart=$WebHookDataBody.SearchIntervalStarttimeUtc
        $procalert.SearchIntervalEnd=$WebHookDataBody.SearchIntervalEndtimeUtc
  
        #categorize the alert
        Switch ($WebHookDataBody.AlertRuleName){
            {$_ -match "Backup"} { $alertcat='Backup';break}
            {$_ -match "CrowdStrike"} {$alertcat='CrowdStrike';break}
            {$_ -match "SecurityAgent"} {$alertcat='CrowdStrike';break}
            {$_ -match "CPU"} {$alertcat='CPU';break}
            {$_ -match "Disk"} {$alertcat='Disk';break}
        }
      
        $Severity = $WebHookDataBody.Severity
        #To capture correct Severity
        Switch($Severity){
           0 {$Severity='Critical'; break}
           1 {$Severity='Major'; break}
           2 {$Severity='Minor'; break}
           4 {$Severity='Informational'; break}
        }

        #construct the SearchResults      
        $SearchResult = $WebHookDataBody.SearchResult.tables."rows"
        $colsname = $WebHookDataBody.SearchResult.tables."columns"
        
        $resultcnt = $WebHookDataBody.ResultCount

        $cnt=0
        if($resultcnt -eq 1){
           $icol = 0
           $itemrow = New-Object PSCustomObject  
           foreach ($item in $SearchResult){
              $itemrow | Add-Member -Name $colsname[$icol].Name -MemberType NoteProperty -Value $item
              $icol+=1

           }#foreach
           
           $itemrow | Add-Member -Name 'Severity' -MemberType NoteProperty -Value $Severity 
           $procalert.SearchResults=$itemrow
            
           $jsoninfo =  New-Object PsCustomObject -Property ([ordered] @{
                SelfhealCategory= $alertcat
                SelfhealResult= ""
                SelfhealSeverity= $Severity
                SelfhealMessage= ""
                ProcessedAlert=$procalert
           })
                      
          #call logic app
           $error.clear()
           $resp, $jsoninfo=Call-LogicApp $subsID $jsoninfo -Verbose
           if($resp -match "ERROR"){
               $runbookStatus="Failed"
               $runbookOutput=$resp
           }else{
                $jsoninfo | ConvertTo-Json
           }

        }else{   #multiple incident
            foreach ($search in $SearchResult){
                Write-Verbose $cnt
                $icol = 0
                $itemrow = New-Object PSCustomObject  
                foreach ($item in $search){
                   $itemrow | Add-Member -Name $colsname[$icol].Name -MemberType NoteProperty -Value $item
                   $icol+=1
                }#foreach
                
                $itemrow | Add-Member -Name 'Severity' -MemberType NoteProperty -Value $Severity 
                $procalert.SearchResults=$itemrow
            
                $jsoninfo =  New-Object PsCustomObject -Property ([ordered] @{
                   SelfhealCategory= $alertcat
                   SelfhealResult= ""
                   SelfhealSeverity= $Severity 
                   SelfhealMessage=""
                   ProcessedAlert=$procalert
                })

                #call logic app
                $error.clear()
                $resp, $jsoninfo = Call-LogicApp $subsID $jsoninfo -Verbose
                if($resp -match "ERROR"){
                    $runbookStatus="Failed"
                    $runbookOutput=$resp
                }else{
                    $jsoninfo | ConvertTo-Json
                }
               $cnt+=1
            } #foreach search
            # $runbookOutput ="multiple output"
       }#resultcnt
    }#WebHookData.RequestBody


 }else{   #WebHookData is blank
 
    $jsoninfo =  New-Object PsCustomObject -Property ([ordered] @{
        SelfhealCategory= ""
        SelfhealResult= ""
        SelfhealSeverity= ""
        SelfhealMessage=""
        ProcessedAlert=""
    })

    $runbookOutput="ERROR:Incoming WebHookData is blank. Nothing to process."
    $runbookStatus="Failed"
    throw
 }
 
}catch{
    $runbookStatus = "Failed"
    $runbookOutput = $runbookOutput

    # Write runbook results to JSON output
    $JsonInfo.SelfhealResult=$runbookStatus    

    $selfhealMsg=[PSCustomObject]@{
       JobId = $ScriptJobId
       RunbookName = $RunBookName
       Status = $runbookStatus
       Output = $runbookOutput
    }

    [psCustomObject[]]$JsonInfo.SelfhealMessage+=$selfhealMsg
    $runRes = $JsonInfo | ConvertTo-Json
    
    # send to LogAnalytics #
    .\send-DatatoCL.ps1 -JsonInput $runRes
    
    $runRes
}