﻿#-----------------------------------------------------------[Comments]-------------------------------------------------------------
#region COMMENTS
<#
.SYNOPSIS
    This function deploys the custom log which will capture self-heal results.
    Reference: https://docs.microsoft.com/en-us/azure/azure-monitor/platform/data-collector-api
    
    To report a bug or an issue with Self-heal, log the case here:
    https://confluence.csc.com/pages/viewpage.action?pageId=162089166 
    
.PARAMETER
    [PSCustomObject]$JsonInput
.REVISION HISTORY
    Creation Date:  04-Jul-2019
    04-Jul-2019 - v.01 - Initial script development
    24-Jul-2019 - v.02 - added jobId in selfhealmessage object
    05-Sep-2019 - added support for different RG
    11-Jun-2021 - azr-23696 supports crowdstrike
    22-Jul-2021 - AZR-24230 Remove overwrite of results, severity

#>
#endregion

#----------------------------------------------------------[Declarations]----------------------------------------------------------
#region DECLARATIONS
Param(
     [Parameter (Mandatory = $true)]
     [PSCustomObject]$JsonInput
 )


# Specify the name of the record type that you'll be creating
$LogType = "SelfHeal_CL"
$connectionName = "AzureRunAsConnection"
#endregion

#-----------------------------------------------------------[Functions]------------------------------------------------------------
# Create two records with the same set of properties to create
#region FUNCTIONS

function Get-AzCachedAccessToken(){
    $ErrorActionPreference = 'Stop'
    $currentAzureContext = Get-AzContext
    $azureRmProfile = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile
    $profileClient = New-Object Microsoft.Azure.Commands.ResourceManager.Common.RMProfileClient($azureRmProfile)
    $token=$profileClient.AcquireAccessToken($currentAzureContext.Subscription.TenantId)
    $token.AccessToken
}

function Get-AzBearerToken(){
    $ErrorActionPreference = 'Stop'
    ('Bearer {0}' -f (Get-AzCachedAccessToken))
}


# Create the function to create the authorization signature
Function Build-Signature ($customerId, $sharedKey, $date, $contentLength, $method, $contentType, $resource)
{
    $xHeaders = "x-ms-date:" + $date
    $stringToHash = $method + "`n" + $contentLength + "`n" + $contentType + "`n" + $xHeaders + "`n" + $resource

    $bytesToHash = [Text.Encoding]::UTF8.GetBytes($stringToHash)
    $keyBytes = [Convert]::FromBase64String($sharedKey)

    $sha256 = New-Object System.Security.Cryptography.HMACSHA256
    $sha256.Key = $keyBytes
    $calculatedHash = $sha256.ComputeHash($bytesToHash)
    $encodedHash = [Convert]::ToBase64String($calculatedHash)
    $authorization = 'SharedKey {0}:{1}' -f $customerId,$encodedHash
    return $authorization
}


# Create the function to create and post the request
Function Post-LogAnalyticsData($customerId, $sharedKey, $body, $logType)
{
    $method = "POST"
    $contentType = "application/json"
    $resource = "/api/logs"
    $rfc1123date = [DateTime]::UtcNow.ToString("r")
    $contentLength = $body.Length
    $signature = Build-Signature `
        -customerId $customerId `
        -sharedKey $sharedKey `
        -date $rfc1123date `
        -contentLength $contentLength `
        -method $method `
        -contentType $contentType `
        -resource $resource
    $uri = "https://" + $customerId + ".ods.opinsights.azure.com" + $resource + "?api-version=2016-04-01"

    $headers = @{
        "Authorization" = $signature;
        "Log-Type" = $logType;
        "x-ms-date" = $rfc1123date;
       # "time-generated-field" = $TimeStampField;
    }

    $response = Invoke-WebRequest -Uri $uri -Method $method -ContentType $contentType -Headers $headers -Body $body -UseBasicParsing
    return $response.StatusCode

}
#endregion

#-----------------------------------------------------------[Execution]------------------------------------------------------------

#region MAIN
try
{
    # Get the connection "AzureRunAsConnection "
    $servicePrincipalConnection = Get-AutomationConnection -Name $connectionName

    #"Logging in to Azure..."
    Add-AzAccount -Tenant $servicePrincipalConnection.TenantID `
                  -ApplicationId $servicePrincipalConnection.ApplicationID   `
                  -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint `
                  -ServicePrincipal | Out-Null
    $Context = Set-AzContext -SubscriptionId $servicePrincipalConnection.SubscriptionId -WarningAction Ignore

    $subsID = $servicePrincipalConnection.SubscriptionId
    #"Logged In."
}
catch {
    if (!$servicePrincipalConnection)
    {
        $SelfHealResult = "Fail" 
        $SelfHealMessage = "Connection $connectionName not found."
    } else{
        $SelfHealResult = "Fail" 
        $SelfHealMessage = $_.Exception
    }
}

#Getting values of SelfHealMessage
[PSObject[]] $SelfHealMsg_Coll=@()

foreach($itm in $JsonInput.SelfhealMessage){
 $itemrow=New-Object PSCustomObject
 $itemrow | Add-Member -Name "JobId" -MemberType NoteProperty -Value $itm.JobId
 $itemrow | Add-Member -Name "RunbookName" -MemberType NoteProperty -Value $itm.RunbookName
 $itemrow | Add-Member -Name "Status" -MemberType NoteProperty -Value $itm.Status
 $itemrow | Add-Member -Name "Output" -MemberType NoteProperty -Value $itm.Output
 $SelfHealMsg_Coll+=$itemrow
}

$wrkspacename=($JsonInput.ProcessedAlert.ResourceId).Split('/') | Select -Last 1
$wrkspacerg = ($JsonInput.ProcessedAlert.ResourceId).Split('/') | Select -First 5 |Select -Last 1

# Get the customerID
$LogAnalytics = Get-AzOperationalInsightsWorkspace -Name $wrkspacename -ResourceGroupName $wrkspacerg -WarningAction Ignore
$CustomerId = $LogAnalytics.CustomerId."Guid"

# Get SharedKey
$tmpKey = Get-AzOperationalInsightsWorkspaceSharedKey -Name $wrkspacename -ResourceGroupName $wrkspacerg -WarningAction Ignore
$sharedKey = $tmpKey.SecondarySharedKey

$RunResult=[PSCustomObject] ([ordered]@{
    SelfhealCategory = $JsonInput.SelfhealCategory
    SelfhealResult = $JsonInput.SelfHealResult
    SelfhealSeverity = $JsonInput.SelfhealSeverity
    SelfhealMessage = $SelfHealMsg_Coll
    SubscriptionID = $JsonInput.ProcessedAlert.SearchResults.SubscriptionId
    Resource = $JsonInput.ProcessedAlert.SearchResults.Resource
    ResourceId = $JsonInput.ProcessedAlert.SearchResults.ResourceId
    ProcessedAlert = $JsonInput.ProcessedAlert | Select-Object -Property * -ExcludeProperty Resource, ResourceId, SubscriptionId | ConvertTo-Json -Depth 10
})

$RunResult= $RunResult | ConvertTo-Json -Depth 10
# Submit the data to the API endpoint
$PostResult = Post-LogAnalyticsData -customerId $CustomerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($RunResult)) -logType $logType
$PostResult
$RunResult
#endregion
