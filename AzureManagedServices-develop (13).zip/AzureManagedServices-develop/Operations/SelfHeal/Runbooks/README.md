#Self Heal Runbooks
This folder contains runbooks developed for Self-heal.

#### Within the Logic App instance, automation runbooks will be run in sequence to perform diagnostics, remediation and logging operations
|Runbook|What does it do?|
|-----|-----|
|process-Alerts.ps1|This runbook itemizes and parses the data captured by the “DXC-Critical-Backup Failure” alert rule and triggers the Logic App instance workflow. This is triggered by a webhook action group attached to “DXC-Critical-Backup Failure” alert rule.||
|validate-ErrorforSelfheal.ps1| This runbook determines the backup management type, items (vault and VM) and performs basic checks prior to retry operation.|
|buaas-triggerBackup.ps1|This runbook initiates the backup retry operation against the VM.|
|send-DatatoCL.ps1|This runbooks collects all data – from precursor alert and runbook results, and sends data to the self-heal custom log.|
