#region COMMENTS
<#
.SYNOPSIS
    This will Trigger Backup in Azure.
    To report a bug or an issue with Self-heal, log the case here:
    https://confluence.csc.com/pages/viewpage.action?pageId=162089166 
    
.PARAMETER
    [PSCustomObject]$JsonInput
.REVISION HISTORY
    Creation Date:  11-Jun-2019
    11-Jun-2019 - v.01 - Initial script development
    10-Jul-2019 - v1.01 - updated  the customlog output
    24-Jul-2019 - v1.02 - added jobId in selfhealmessage object
    05-Sep-2019 - added support for different RG
    04-Nov-2019 - fix deprecated cmd      
    14-Apr-2020 - fix bugs under AZR-13406
    18-Nov-2020 - AZR 18701
    14-Jun-2021 - AZR-23696 supports new schema
#>
#endregion

#region PARAMETERS
Param(
     [Parameter (Mandatory = $true)]
     [PSCustomObject]$JsonInput
 )
#endregion

#---------------------------------------------------------[Initializations]--------------------------------------------------------

#----------------------------------------------------------[Declarations]----------------------------------------------------------

$connectionName = "AzureRunAsConnection"
$RunBookName="buaas-triggerBackup"
[bool]$refire=$false

#-----------------------------------------------------------[Functions]------------------------------------------------------------

#region FUNCTIONS

function Get-AzCachedAccessToken(){
    $ErrorActionPreference = 'Stop'
    $currentAzureContext = Get-AzContext
    $azureRmProfile = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile
    $profileClient = New-Object Microsoft.Azure.Commands.ResourceManager.Common.RMProfileClient($azureRmProfile)
    $token=$profileClient.AcquireAccessToken($currentAzureContext.Subscription.TenantId)
    $token.AccessToken
}

function Get-AzBearerToken(){
    $ErrorActionPreference = 'Stop'
    ('Bearer {0}' -f (Get-AzCachedAccessToken))
}

function Get-BackupJob($job, $vaultid, $RunbookStartTime){
  
    $jobdate = $job.StartTime
    $jobRunID= $job.JobId
    $jobActId = $job.ActivityId
  
    # Check if hours is greater than 24 hours
    $curdate = (Get-Date).ToUniversalTime()
    $datediff = $curdate - $jobdate
    
    if ($datediff.Days -ge 1){ Stop-AzRecoveryServicesBackupJob -JobId $job.JobID -VaultId $vaultid | Out-Null }
      
    do{
        $job= Get-AzRecoveryServicesBackupJob -VaultId $vaultid -JobId $job.JobID -From $curdate.AddDays(-29)
        $jobRunStatus = $job.Status    
        $curdate = (Get-Date).ToUniversalTime()
        $lapsedmins = $curdate - $RunbookStartTime
        if($lapsedmins.TotalMinutes -ge 170){
           $jobRunStatus = "Runbook TimeOut"
          break
        }
        Sleep 5
    } while(($jobRunStatus -ne "Failed") -and ($jobRunStatus -ne "Cancelled") -and ($jobRunStatus -ne "Completed") -and ($jobRunStatus -ne "CompletedWithWarnings"))  

  return $jobRunID, $jobRunStatus, $jobActId
}

function Get-BackupJobCount($FailedBKJob,$vaultId,$JsonInput,$BKPolicy){
 
 $refire=$false
 $chkjobs=$true
 $SHM1 = ""
 $SHResult =""
 $VMjobs =$null
 $BKPolicyRunTimes = $BKPolicy.SchedulePolicy.ScheduleRunTimes

   #BaseDateTime from FailedBackupJob and Policy Time
   $FailedBKJobUTC = $FailedBKJob.StartTime
   $TodaysPolicyDate =(Get-date -Year ($FailedBKJobUTC.Year) -Month ($FailedBKJobUTC.Month) -Day ($FailedBKJobUTC.Day) -Hour ($BKPolicyRunTimes.Hour) -Minute ($BKPolicyRunTimes.Minute) -Second($BKPolicyRunTimes.Second)).ToUniversalTime()     

   #check if datetime is greater than backupjobtime
   $diffPolDate =  $FailedBKJobUTC - $TodaysPolicyDate
   
   if($BKPolicy.SchedulePolicy.ScheduleRunFrequency -eq "Daily"){
     if($diffPolDate.TotalMinutes -lt 0){$FromDate = $TodaysPolicyDate.Adddays(-1)}else{$FromDate = $TodaysPolicyDate}
   }else{
     if($diffPolDate.TotalMinutes -lt 0){$chkjobs=$false}else{$FromDate = $TodaysPolicyDate}
   }

 if($chkjobs -eq $true){
    $VMjobs= Get-AzRecoveryServicesBackupJob -VaultId $vaultItem.ID -From $FromDate | where {($_.WorkloadName -eq $JsonInput.VMName) -and ($_.Status -eq "Failed")} 
       
    if($VMjobs.Count -ge 2){
      $SHResult = "Failed"
      $SHM1 = [String]::Concat("FailedBackup JobId/ActivityId:", "(", $FailedBKJob.JobId, "/", $FailedBKJob.ActivityId, ")",". Self-heal has found multiple failed backup attempts from last scheduled run. The number of retry attempts has exceeded, no further actions will be done. Please check the issue manually before refiring another backup." )
    }else{
      $refire=$true
      $SHM1 = [String]::Concat("FailedBackup JobId/ActivityId:", "(", $FailedBKJob.JobId, "/", $FailedBKJob.ActivityId, ")",". Self-heal has determined no subsequent failures from last scheduled run and will attempt a retry operation." )
    }
 }else{
   $SHResult = "Failed"
   $SHM1 = [String]::Concat("FailedBackup JobId/ActivityId:", "(", $FailedBKJob.JobId, "/", $FailedBKJob.ActivityId, ")",". Self-heal has found multiple failed backup attempts from last scheduled run. The number of retry attempts has exceeded, no further actions will be done. Please check the issue manually before refiring another backup." )
 }
 
  return $refire, $SHResult, $SHM1
}

#endregion

#-----------------------------------------------------------[Execution]------------------------------------------------------------

#region MAIN

try
{

$RunbookStartTime = (Get-Date).ToUniversalTime()

# Get the connection "AzureRunAsConnection "
$servicePrincipalConnection = Get-AutomationConnection -Name $connectionName

Add-AzAccount -Tenant $servicePrincipalConnection.TenantID `
              -ApplicationId $servicePrincipalConnection.ApplicationID   `
              -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint `
              -ServicePrincipal | Out-Null
$Context = Set-AzContext -SubscriptionId $servicePrincipalConnection.SubscriptionId -WarningAction Ignore
$subsID = $servicePrincipalConnection.SubscriptionId

}catch {
    if (!$servicePrincipalConnection)
    {
        $ErrorMessage = "Connection $connectionName not found."
        throw $ErrorMessage       
    } else{
        Write-Error -Message $_.Exception
        throw $_.Exception
    }
}

Try{  
 # Authentication
 $ArmToken = Get-AzBearerToken

 # Register the Recovery Services provider #
 Register-AzResourceProvider -ProviderNamespace "Microsoft.RecoveryServices" | Out-Null

 $Error.Clear()
 #Get/Set Vault Properties#
 $vaultItem = Get-AzRecoveryServicesVault -ResourceGroupName $JsonInput.RGName -Name $JsonInput.VaultName
 $sContainer = Get-AzRecoveryServicesBackupContainer -ContainerType "AzureVM" -Status "Registered" -VaultId $vaultItem.Id -FriendlyName $JsonInput.VMName
 $BKProp = Get-AzRecoveryServicesBackupItem -Container $sContainer -WorkloadType "AzureVM" -VaultId $vaultItem.Id

 #Get Backup Policy for AzureVM#
 $BKPolicy = Get-AzRecoveryServicesBackupProtectionPolicy -Name $BKProp.ProtectionPolicyName -VaultId $vaultItem.Id
 $BKPolicySchedule = $BKPolicy.SchedulePolicy.ScheduleRunFrequency
 $BKPolicyRunTimes = $BKPolicy.SchedulePolicy.ScheduleRunTimes

 #Get Failed BackupJobId #
 $dateToday =(Get-Date).ToUniversalTime()

 # Get the needed backup category #
 $bucat=$JsonInput.ProcessedAlert.SearchResults.Category

 Switch ($bucat){
       "AddonAzureBackupJobs" { $jobUniqueId=$JsonInput.ProcessedAlert.SearchResults.JobUniqueId; break}
       "AzureBackupReport" { $jobUniqueId=$JsonInput.ProcessedAlert.SearchResults.JobUniqueId_g; break}
}
  
 $FailedBKJob = Get-AzRecoveryServicesBackupJob -VaultId $vaultItem.ID -JobId $jobUniqueId -From $dateToday.AddDays(-29)

 if (($FailedBKJob -eq $null) -or ($error)){
    $SHM1 = [String]::Concat("FailedBackupJobId :", $jobUniqueId, " cannot be queried from RecoveryServicesVault.", $error, " Nothing to Compare thus Triggering Backup for ", $JsonInput.VMName )
    $refire =$true
 }else{
    if($BKPolicySchedule -eq "Daily"){ #daily
       if ($FailedBKJob.Duration.Days -eq 0){ $refire, $SHResult, $SHM1=Get-BackupJobCount $FailedBKJob $vaultItem.ID $JsonInput $BKPolicy
       }else{
          $SHResult = "Failed"
          $SHM1 = [String]::Concat("FailedBackup JobId/ActivityId:", "(", $FailedBKJob.JobId, "/", $FailedBKJob.ActivityId, ")"," is long running backup job." )
       }
    }else{ #Weekly or Monthly  
       if($BKPolicy.SchedulePolicy.ScheduleRunDays -eq (((Get-Date).ToUniversalTime()).DayOfWeek)){ 
          $refire, $SHResult, $SHM1 = Get-BackupJobCount $FailedBKJob $vaultItem.ID $JsonInput $BKPolicy
       }else{
          $SHResult = "Failed"
          $SHM1 = [String]::Concat("Self-heal has found multiple failed backup attempts from last scheduled run. The number of retry attempts has exceeded, no further actions will be done. Please check the issue manually before refiring another backup."  )
       }
    } 
 }

 if($refire -eq $true){
    $backupJoblists =  Get-AzRecoveryServicesBackupJob -Status InProgress -VaultId $vaultItem.ID -From $dateToday.AddDays(-29) | where {$_.WorkloadName -eq $JsonInput.VMName}
    Sleep 5
    if ($backupJoblists -ne $null){
      if($backupJoblists.count -eq 1){ 
         $backupJob = $backupJoblists
      }else{ 
         $backupJob = $backupJoblists[$backupJoblists.count -1]
      }
     
     $jobRunID, $jobRunStatus, $jobActId = Get-BackupJob $backupJob $vaultItem.Id $RunbookStartTime

     Switch($jobRunStatus){
         "Completed" {
            $SHResult = "Success"
            $SHM2 = [String]::Concat(" Self-heal has found a backup job already in-progress (", $backupJob.JobId,"/",$backupJob.ActivityId,") which was successful. No action done.")
            break}
         "CompletedWithWarnings" {
            $SHResult = "Success"
            $SHM2 = [String]::Concat(" Self-heal has found a backup job already in-progress (",$backupJob.JobId, "/", $backupJob.ActivityId,") which was successful. No action done.")
            break}
         "Runbook TimeOut" {
            $SHResult = "Success"
            $SHM2 = [String]::Concat(" Self-heal has found a backup job already in-progress (",$backupJob.JobId,"/",$backupJob.ActivityId,")," ," pending results. No action done. Please check job status manually.")
            break}
         "Failed" {
            $SHResult = "Failed"
            $SHM2 = [String]::Concat(" Self-heal has found a backup job already in-progress (", $backupJob.JobId ,"/" ,$backupJob.ActivityId ,") which failed. No action done.")
            break}
       }      

    }else{
       #Refiring Backup
       $newjob = Backup-AzRecoveryServicesBackupItem -Item $BKProp -VaultId $vaultItem.Id
       $jobRunID, $jobRunStatus, $jobActId = Get-BackupJob $newjob $vaultItem.Id $RunbookStartTime
       
       Switch($jobRunStatus){
          "Completed"{
             $SHResult = "Success"
             $SHM3 =[String]::Concat(" Action: Self -heal has performed a retry attempt and was successfully completed (", $newjob.JobId,"/",$newjob.ActivityId, ")." )
             break}
          "CompletedWithWarnings"{
             $SHResult = "Success"
             $SHM3 =[String]::Concat(" Action: Self-heal has performed a retry attempt and was successfully completed (",$newjob.JobId,"/",$newjob.ActivityId,")." )
             break}
          "Runbook TimeOut" {
             $SHResult = "Success"
             $SHM3 =[String]::Concat(" Action: Self-heal has performed a retry attempt pending results (", $newjob.JobId,"/", $newjob.ActivityId,"). Please check job status manually.") 
             break}
          "Failed" {
             $SHResult = "Failed"
             $SHM3 =[String]::Concat(" Action: Self-heal has performed a retry attempt which failed (", $newjob.JobId ,"/" , $newjob.ActivityId ,"). Please investigate manually.")
             break}
       }
    }  #nothing InProgress
 }
 
 $SHMessage = $SHM1 + $SHM2 + $SHM3

 } catch {
    $SHResult = "Failed"
    $SHMessage =  $SHMessage + $error

 }finally{
 
    $ScriptJobId = $PsPrivateMetaData.JobId.GUid  
    $selfhealMsg=[PSCustomObject]@{ 
      JobId = $ScriptJobId
      RunbookName = $RunBookName 
      Status = $SHResult
      Output = $SHMessage 
    } 

   $JsonInput.SelfhealResult =$SHResult
   [PSCustomObject[]]$JsonInput.SelfhealMessage+=$selfhealMsg

   ### Output to JSON ###
   $JsonInput | ConvertTo-Json
}
#endregion