﻿#region COMMENTS
<#
.SYNOPSIS
    Validate if Error will pass thru Self-Heal Workflow.
    Output will include OSType and ErrorSupported.
    
    To report a bug or an issue with Self-heal, log the case here:
    https://confluence.csc.com/pages/viewpage.action?pageId=162089166 
    
.PARAMETER
    [PSCustomObject]$JsonInput

.REVISION HISTORY
    Creation Date:  11-Jun-2019
    11-Jun-2019 - v.01 - Initial script development
    10-Jul-2019 - v1.01 - updated  the customlog output
    25-Jul-2019 - v1.02 - added $AlertObjectType for cpu, memory and disk
    05-Sep-2019 - added support for different RG
    29-Oct-2019 - re-arranged validation
    23-Jan-2020 - removed logicappname
    16-Mar-2020 - combined workflow
    19-Mar-2020 - error-handling
    09-Sep-2020 - AZR-17176
    11-Jun-2021 - AZR-23696 supports crowdstrike
    22-Jul-2021 - AZR-24230 Update to include AgentHealth
#>
#endregion


Param(
     [Parameter (Mandatory = $true)]
     [PSCustomObject]$JsonInput
 )

#---------------------------------------------------------[Initializations]--------------------------------------------------------

$DefCredName = "DefaultAzureCredential"
$connectionName = "AzureRunAsConnection"
$RunBookName="validate-ErrorforSelfHeal"

$Global:ReferenceCodes=@{
   "UserErrorGuestAgentStatusUnavailable"="backup"
   "GuestAgentSnapshotTaskStatusError"="backup"
   "ExtensionOperationFailedForManagedDisks"="backup"
   "UserErrorBackupOperationInProgress"="backup"
   "BackUpOperationFailed"="backup"
   "BackUpOperationFailedV2"="backup"
   "ExtensionFailedVssWriterInBadState"="backup"
   "ExtensionSnapshotFailedCOM"="backup"
   "ExtensionInstallationFailedCOM"="backup"
   "ExtensionInstallationFailedMDTC"="backup"
   "DXC-Critical-Linux-CrowdStrike SVC Stopped"="crowdstrike"
   "DXC-Major-Crowdstrike SIEM-ConnectFail"="crowdstrike"
   "DXC-Critical-Windows-SecurityAgent SVC Didnt Start"="crowdstrike"
   "AgentHealth-Failed"="agenthealth"
}

$Global:vmObjStat=""
#-----------------------------------------------------------[Functions]------------------------------------------------------------

#region FUNCTIONS

function Get-AzCachedAccessToken(){
    $ErrorActionPreference = 'Stop'
    $currentAzureContext = Get-AzContext
    $azureRmProfile = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile
    $profileClient = New-Object Microsoft.Azure.Commands.ResourceManager.Common.RMProfileClient($azureRmProfile)
    $token=$profileClient.AcquireAccessToken($currentAzureContext.Subscription.TenantId)
    $token.AccessToken
}

function Get-AzBearerToken(){
    $ErrorActionPreference = 'Stop'
    ('Bearer {0}' -f (Get-AzCachedAccessToken))
}

function Get-AutomationInfo(){
   $AutomationResource = Get-AzResource -ResourceType Microsoft.Automation/AutomationAccounts

   foreach ($Automation in $AutomationResource)
   {
       $Job = Get-AzAutomationJob -ResourceGroupName $Automation.ResourceGroupName -AutomationAccountName $Automation.Name -Id $PSPrivateMetadata.JobId.Guid -ErrorAction SilentlyContinue
       if (!([string]::IsNullOrEmpty($Job)))
       {
           $AutomationInformation = @{}
           $AutomationInformation.Add("SubscriptionId",$Automation.SubscriptionId)
           $AutomationInformation.Add("Location",$Automation.Location)
           $AutomationInformation.Add("ResourceGroupName",$Job.ResourceGroupName)
           $AutomationInformation.Add("AutomationAccountName",$Job.AutomationAccountName)
           $AutomationInformation.Add("RunbookName",$Job.RunbookName)
           $AutomationInformation.Add("JobId",$Job.JobId.Guid)
           break;
       }
   }
   return $AutomationInformation
} 

# Check VM existence and powerstate.
function Check-VMState{
   Param ([string]$vmName, [string]$vmRG)
 
   #Write-Host -ForegroundColor Cyan "Checking the VM state in the subscription..."
   if ($vmObjStat.Name -eq $vmName) {# Check if the target VM exists or hosted within the Subscription.
      if ($vmObjStat.ResourceGroupName -eq $vmRG) {# Check if the VM is in the specified resource group.
          if ($vmObjStat.Statuses[1].DisplayStatus -eq 'VM running') {# Check if the VM state is started and running.
              $shMsg = "VM Status: OK - $vmName is in $vmRG and powered on. "
              $vmState = "Success"
          }else{
              $shMsg = "VM Status: NOK - $vmName is in $vmRG but powered off. Pre-checks failed. "
              $vmState = "Failed" }
      }else {
          $shMsg = "VM Status: NOK - $vmName not found in $vmRG. Pre-checks failed. "
          $vmState = "Failed" }
   }else{
      $shMsg = "VM Status: NOK - $vmName not found in the Subscription. Pre-checks failed. "
      $vmState = "Failed"
   }

   return $shMsg, $vmState 
}

function validate-BUcategory{
    [CmdletBinding()]
    Param($jError, $shmsg, $AAInfo, $jvault)

   Try{
       # validate errorcode #
       $arrtemp=$ReferenceCodes.GetEnumerator() | ? { $_.Value -eq "backup" }
       $errcode=$arrtemp.Key | Where-Object -FilterScript {$_ -in $jError} 
           
       if ($errcode){
          $errsupported=$true
          $shres ="Success"

          # validate automation credential #    
          $AutomationCreds = Get-AzAutomationCredential -Name $DefCredName -ResourceGroupName $AAInfo.ResourceGroupName -AutomationAccountName $AAInfo.AutomationAccountName -ErrorAction SilentlyContinue
          $AutomationCreds | Out-Null

          if ($AutomationCreds){
             $aacred = $DefCredName
          }else{
             $shmsg += " No Credential Found in Azure Automation."
          }

          # validate hybrid-worker machine #
          $AAhybridgrp = Get-AzAutomationHybridWorkerGroup -ResourceGroupName $AAInfo.ResourceGroupName -AutomationAccountName $AAInfo.AutomationAccountName -ErrorAction SilentlyContinue
          if ($AAhybridgrp){
             if((($AAhybridgrp.RunbookWorker).Name -eq $null) -or (($AAhybridgrp.RunbookWorker).IpAddress -eq $null)){
                $shmsg += " No hybridworker VM configured in Azure Automation."
             }else{ 
                $hg = ($AAhybridgrp.RunbookWorker).Name 
             }
          }else{
             $shmsg += " No hybridworkergroup configured in Azure Automation." 
          }

          # validate vault #
          $vObjs = Get-AzResource -Name $jvault -ResourceType "Microsoft.RecoveryServices/vaults" -ErrorAction SilentlyContinue
          
          Switch (($vObjs | Measure-Object).Count){
             0 { $shres ="Failed"
                 $shmsg += " ERROR: RecoveryServices vaultname Not found in subscription." 
                 break} 
             1 { $vaultObj = $vObjs 
                 $vn= $vaultObj.Name
                 $vrg= $vaultObj.ResourceGroupName
                 break} 
             default { $vmlocation = $vmObj.Location;
                       $vaultObj = $vObjs | Where-Object {$_.Location -eq $vmlocation}
                       if(($vaultObj | Measure-Object).Count -gt 1){$vaultObj=$vaultObj[0]}
                       $vn= $vaultObj.Name
                       $vrg= $vaultObj.ResourceGroupName
                       break}
          } #Switch
                 
        }else{
           $errsupported=$false
           $shres ="Failed"
           $shmsg = " Backup Error Not Supported." 
        }

    $retObjs=@{
        errsupp=$errsupported
        errcode=$errcode
        automationcred=$aacred
        hybridg=$hg
        vault=$vn
        vaultrg=$vrg
        res=$shres
        msg=$shmsg
    }
    return $retObjs

  }catch{
       Write-Error "Error in validate-BUcategory function. $($_.Exception.Message)"
  }
}

function validate-CScategory {
    [CmdletBinding()]
    Param($jError,$shmsg,$AAInfo)

    Try{
        # validate cs alert rule #
        $arrtemp=$ReferenceCodes.GetEnumerator() | ? { $_.Value -eq "crowdstrike" }
        $alertcode=$arrtemp.Key | Where-Object -FilterScript {$_ -in $jError} 

        if ($alertcode){
            $alertsupported=$true

            # validate keyvault #
            $keyvaultName=Get-AutomationVariable -Name "keyvault" -ErrorAction SilentlyContinue

            if($keyvaultName){
               $kvault = Get-AzKeyVault -VaultName $keyvaultName -ErrorAction SilentlyContinue

               if ($kvault){
                  # check permission of automation account #
                  $kvAccess=$kvault.AccessPolicies | Where-Object {$_.DisplayName -match $AAInfo.AutomationAccountName}

                  if ($kvAccess){
                     $secret_access = $kvAccess.PermissionsToSecrets

                     if($secret_access.Contains('Get')){
                        $clientidvalue = Get-AzKeyVaultSecret -VaultName $kvault.VaultName -Name "csClientId" -AsPlainText
                        $clientsecretvalue = Get-AzKeyVaultSecret -VaultName $kvault.VaultName -Name "csClientSecret" -AsPlainText
 
                        if (($clientidvalue) -and ($clientsecretvalue)){
                            $shres ="Success"
                            $shmsg +=" CrowdStrike Pre-checks success." 
                        }else{
                            $shres="Failed"
                            $shmsg += " ERROR: Missing values for csClientId/csClientSecret not Found in the keyvault Secret. Pre-checks failed."
                        }
                     }else{ 
                        $shres="Failed"
                        $shmsg += " ERROR: $($AAInfo.AutomationAccountName) has no access permission to the keyvault Secret. Pre-checks failed."
                     } #secret access
                  }else{
                    $shres="Failed"
                    $shmsg += " ERROR: $($AAInfo.AutomationAccountName) has no access permission to the keyvault. Pre-checks failed."
                  }
                }else{
                   $shres="Failed"
                   $shmsg += " ERROR: $($keyvaultname) not found in Subscription. Pre-checks failed."
                 }
            }else{
               $shres="Failed"
               $shmsg += " ERROR: keyvault variable not found in Automation Account. Pre-checks failed."
             }
        }else{
            $errsupported=$false
            $shres ="Failed"
            $shmsg += " CrowdStrike Alert Rule Not Supported." 
        }

    $retObjs=@{
        alertsupp=$alertsupported
        res=$shres
        msg=$shmsg
   }

   return  $retObjs

  }catch{
     Write-Error "Error in validate-CScategory function. $($_.Exception.Message) + $($shmsg)"
  }
}

#-----------------------------------------------------------[Execution]------------------------------------------------------------

Try
{
   $error.Clear()

   ### Get the connection "AzureRunAsConnection" ###
   $servicePrincipalConnection = Get-AutomationConnection -Name $connectionName 

   #"Logging in to Azure..."
   Add-AzAccount -Tenant $servicePrincipalConnection.TenantID `
                  -ApplicationId $servicePrincipalConnection.ApplicationID   `
                  -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint `
                  -ServicePrincipal | Out-Null
   $Context = Set-AzContext -SubscriptionId $servicePrincipalConnection.SubscriptionId -WarningAction Ignore

   $subsID = $servicePrincipalConnection.SubscriptionId
   #"Logged In."
   
}catch {
    if (!$servicePrincipalConnection)
    {
        $ErrorMessage = "Connection $connectionName not found."
        throw $ErrorMessage       
    } else{
        $ErrorMessage = "Script Executed with errors."
        Write-Error -Message $_.Exception
        throw $_.Exception
    }
}

Try{

   ### Get azure token ###
   $ArmToken = Get-AzBearerToken

   # Enable AzureRm compatibility
   Enable-AzureRMAlias

   # fields needed in logic app conditions  #
   $JsonInput | Add-Member -MemberType NoteProperty -Name "AlertRuleSupported" -Value $false
   $JsonInput | Add-Member -MemberType NoteProperty -Name "VMName" -Value ""     
   $JsonInput | Add-Member -MemberType NoteProperty -Name "VMRG" -Value ""   
   $JsonInput | Add-Member -MemberType NoteProperty -Name "OSType" -Value ""
   $JsonInput | Add-Member -MemberType NoteProperty -Name "Vaultname" -Value ""
   $JsonInput | Add-Member -MemberType NoteProperty -Name "RGName" -Value ""
   $JsonInput | Add-Member -MemberType NoteProperty -Name "ErrCode" -Value ""     #applicable for backup only
   $JsonInput | Add-Member -MemberType NoteProperty -Name "HybridGroup" -Value ""
   $JsonInput | Add-Member -MemberType NoteProperty -Name "AutomationCredential" -Value ""

   # 1st condition for alertrulesupported #
   $catsupp=$false
   Write-Verbose $JsonInput.SelfhealCategory
   
   Switch ($JsonInput.SelfhealCategory){
      "Backup" { $catesupp=$true ;break }
      "CrowdStrike" { $catesupp=$true;break }
      "AgentHealth" { $catesupp=$true;break }
   }

   # get automation account info #
   $AAInfo=Get-AutomationInfo

   # validate VM #
   $error.Clear()
   $vmresourceid=$jsonInput.ProcessedAlert.SearchResults.ResourceId
   $vmrg=$vmresourceid.split("/") | Select -First 5 | Select -Last 1
   $vmname=$vmresourceid.split("/") | Select -Last 1

   $ifVmExists = Get-AzResource -ResourceType "Microsoft.Compute/virtualMachines" -ResourceGroupName $vmrg -Name $vmname
   Write-Verbose $ifVmExists.Name

   if ($ifVmExists){
        $vmObj = Get-AzVM -Name $ifVmExists.Name -ResourceGroupName $ifVmExists.ResourcegroupName -ErrorAction SilentlyContinue
        $Global:vmObjStat = Get-AzVM -Name $ifVmExists.Name -ResourceGroupName $ifVmExists.ResourcegroupName -Status -ErrorAction SilentlyContinue
        Sleep 5

        $shmsg, $vmstatus = Check-VMState $vmname $vmrg

        if($vmstatus -eq "Success"){
           if(($vmObj.StorageProfile.OsDisk.OsType | Out-String).trim() -eq 'Linux') {
              $userName = "$user"
              $vmOS = 'Linux'
           }else{
              $userName = $Global:VM.Name + "\" + $user
              $vmOS = 'Windows'
           }
         
           $JsonInput.VMName = $ifVmExists.Name     
           $JsonInput.VMRG = $ifVmExists.ResourcegroupName    
           $JsonInput.OSType = $vmOS

           Switch ($JsonInput.SelfhealCategory){
               "Backup" { $jError=$JsonInput.ProcessedAlert.SearchResults.JobFailureCode
                          $jvn=$JsonInput.ProcessedAlert.SearchResults.VaultName
                          $robjs=validate-BUcategory $jError $shmsg $AAInfo $jvn -Verbose
                          $errorsupported=$robjs.errsupp
                          $JsonInput.ErrCode=$robjs.errcode
                          $JsonInput.AutomationCredential=$aacred
                          $JsonInput.HybridGroup=$robjs.hybridg
                          $JsonInput.VaultName=$robjs.vault
                          $JsonInput.RGName=$robjs.vaultrg
                          $SHResult=$robjs.res
                          $shmsg=$robjs.msg
                          break }
               "CrowdStrike" { $jalertrule=$JsonInput.ProcessedAlert.alertRule
                              $robjs=validate-CScategory $jalertrule $shmsg $AAInfo -Verbose
                              $errorsupported=$robjs.alertsupp
                              $SHResult=$robjs.res
                              $shmsg=$robjs.msg                  
                              break }
                'AgentHealth' {
                    $SHResult = $vmstatus
                    $shmsg = $shmsg
                    $errorsupported = $true
                    break
                }
           }
        }else{
            $SHResult = "Failed"
        }
        $runbookOutput=$shmsg
   }else{
        $SHResult = "Failed"
        $runbookOutput=" ERROR: VM Not Found in Subscription. Pre-checks failed."
   }
   
   $runbookStatus="Success"
   # Conditions for AlertRuleSupported #
     # selfhealresult = success -and category is supported + errorsupported
   if (($SHResult -eq "Success") -and ($catesupp -eq $true) -and ($errorsupported -eq $true)){
     $JsonInput.AlertRuleSupported = $true
   }

}catch{
    $SHResult = "Failed"
    $runbookStatus="Failed"
    $runbookOutput = $_.Exception.Message

}finally{
  $ScriptJobId = $PsPrivateMetaData.JobId.GUid
  # Write runbook results to JSON output
  $selfhealMsg=[PSCustomObject]@{
    JobId = $ScriptJobId
    RunbookName = $RunBookName
    Status = $runbookStatus
    Output = $runbookOutput
  }

  $JsonInput.SelfhealResult=$SHResult
  [psCustomObject[]]$JsonInput.SelfhealMessage+=$selfhealMsg
  $JsonInput | ConvertTo-Json
}