﻿#-----------------------------------------------------------[Comments]-------------------------------------------------------------
<#
.DOCUMENTATION LINK

.SYNOPSIS
This runbook automates the steps to fix the following crowdstrike issues
 - Stopped or Uninstalled CrowdStrike agent service on Windows/Linux VMs
 - Failed connection between SIEM server and CrowdStrike Falcon cloud
.REVISION HISTORY
    01-June-2021 - Initial script development
#>
#---------------------------------------------------------[Initializations]-------------------------------------------------------- 

Param(
    [parameter (Mandatory = $true)][PSCustomObject]$JsonInput
 )

#----------------------------------------------------------[Declarations]----------------------------------------------------------

$RunBookName = "crowdstrike-selfheal"
$connectionName = "AzureRunAsConnection"
$parent=[System.IO.Path]::GetTempPath()
$Global:BashSVCfilename  = [String]::Concat($parent,'\',"crowdstrike_svc.sh")
$Global:PSSVCfilename  = [String]::Concat($parent,'\',"crowdstrike_svc.ps1")
$Global:BashSIEMfileName = [String]::Concat($parent,'\',"crowdstrike_siem.sh")
$uriparent="https://dxcazuretoolsdev.blob.core.windows.net/selfheal/runbooks/"
#$uriparent="https://jcaspellanstorageaccount.blob.core.windows.net/crowdstrike/" #testuri

$psscripturi=-join($uriparent,"crowdstrike_svc.ps1")
$bscripturi=-join($uriparent,"crowdstrike_svc.sh")
$sscripturi=-join($uriparent,"crowdstrike_siem.sh")

$rbstart=Get-Date

#-----------------------------------------------------------[Functions]------------------------------------------------------------
# Supporting functions in this section

function Check_CrowdStrikePortal{
    [CmdletBinding()]
    Param(
       [Parameter(Mandatory)]
       [String]$VMName
   )

    $objResults =  New-Object PsCustomObject -Property @{
       cshostInfo = ""
       resultsMsg = ""
       resultsCode = ""
    }

    Try{
       # get the keyvaultname from automationvariable
       $keyvaultName=Get-AutomationVariable -Name "keyvault" -ErrorAction SilentlyContinue

       if ($keyvaultName){
          $kvault = Get-AzKeyVault -VaultName $keyvaultName -ErrorAction SilentlyContinue

          #get the clientID and secret from keyvault
          $clientidvalue = Get-AzKeyVaultSecret -VaultName $kvault.VaultName -Name "csClientId" -AsPlainText
          $clientsecretvalue = Get-AzKeyVaultSecret -VaultName  $kvault.VaultName -Name "csClientSecret" -AsPlainText

          #connect to the portal using PSFalcon module
          $cnt=0
          do{
             $resptoken=Test-FalconToken

             if($resptoken.Token -eq $false){
                Request-FalconToken -ClientId $clientidvalue -ClientSecret $clientsecretvalue
             }
             $cnt+=1
           }until (($resptoken.Token -eq $true) -or ($cnt -eq 2))

           if ($resptoken.Token -eq $true){
              #Retrieve specific host details
              $hn=[String]::Concat("hostname:'",$VMName,"'") 
              Write-Verbose $hn

              $datahosts=Get-FalconHost -Filter "$hn" -Detailed

              # get the last item in array result #
              if(($datahosts|Measure-Object).Count -gt 1){
                  $cnt=($datahosts|Measure-Object).Count
                  $datahost=$datahosts[$cnt-1]
              }else{
                  $datahost=$datahosts
              }

              if ($datahost){
                  #Write-Verbose $datahost
                  $objResults.cshostInfo=$datahost
                  $objResults.resultsMsg = "Success" 
                  $objResults.resultsCode = 0
               }else{
                  $objResults.resultsMsg = "Failure to capture Host details from Crowdstrike portal." 
                  $objResults.resultsCode = 1 
               }

           }else{
              $objResults.resultsMsg = "Failure to acquire token from Crowdstrike portal." 
              $objResults.resultsCode = 1 
           }
       }else{
              $objResults.resultsMsg = "KeyvaultName Not found in Subscription." 
              $objResults.resultsCode = 1 
       }
      
     return $objResults

  }catch{
        Write-Error "Error in Check_CrowdStrikePortal function. $($_.Exception.Message)"
  }
}

function Invoke_RunCMD{
   [CmdletBinding()]
   Param(
       [Parameter(Mandatory)]
       [String]$ResourceGroupName,
       [Parameter(Mandatory)]
       [String]$VMName,
       [Parameter(Mandatory)]
       [String]$osflag,
       [Parameter(Mandatory)]
       [String]$errt
   )

    $objResults =  New-Object PsCustomObject -Property @{
       result=""
       resultsMsg = ""
       resultsCode = ""
    }

   Try{
      #download the ps script
      Write-Verbose $osflag
      
      if(($osflag -eq 'win') -and ($errt -eq 'svc')){
        #download powershell script
        (New-Object System.Net.WebClient).DownloadFile($psscripturi, $PSSVCfilename)
        Write-Verbose $psscripturi
        Write-Verbose $PSSVCfilename

        #invoke cmd
        $Results=Invoke-AzVMRunCommand -ResourceGroupName $ResourceGroupName -Name $VMName -CommandId 'RunPowerShellScript' -ScriptPath $PSSVCfilename -Verbose -WA 0 -EA 0

      }elseif(($osflag -eq 'lin') -and ($errt -eq 'svc')){
        (New-Object System.Net.WebClient).DownloadFile($bscripturi, $BashSVCfilename)
        Write-Verbose $bscripturi
        Write-Verbose $BashSVCfilename
        
        #invoke cmd
        $Results=Invoke-AzVMRunCommand -ResourceGroupName $ResourceGroupName -Name $VMName -CommandId 'RunShellScript' -ScriptPath $BashSVCfilename -Verbose -WA 0 -EA 0
      } elseif(($osflag -eq 'lin') -and ($errt -eq 'siem')){
        (New-Object System.Net.WebClient).DownloadFile($sscripturi, $BashSIEMfileName)
        Write-Verbose $sscripturi
        Write-Verbose $BashSIEMfileName
        
        #invoke cmd
        $Results=Invoke-AzVMRunCommand -ResourceGroupName $ResourceGroupName -Name $VMName -CommandId 'RunShellScript' -ScriptPath $BashSIEMfileName -Verbose -WA 0 -EA 0
      }

      if ($Results){
         #parse the results
         if($osflag -eq 'win'){
            $data=$Results.Value[0].Message | Convertfrom-Json


         }else{
            $tmp=$Results.Value.Message
            $pos1=$tmp.IndexOf("[stdout]")
            $pos2=$tmp.IndexOf("[stderr]")
            $tmpdata=$tmp.substring(0,$pos2).substring($pos1+8)
            $data=$tmpdata | Convertfrom-Json
         }
         Write-Verbose $data

         $objResults.result=$data
         $objResults.resultsMsg=$Results.Status
      
         if($Results.Status -eq "Succeeded"){
            $objResults.resultsCode=0
         }else{
            $objResults.resultsCode=1
         }
      }else{
         $objResults.resultsMsg="Failed"
         $objResults.resultsCode=1
      }

      return $objResults

 }catch{
    Write-Error "Error in Invoke_RunCMD function. $($_.Exception.Message)"
 }
}

function Get_HeartBeatCount{
   [CmdletBinding()]
   Param($VMName,$wrkspaceObj,$runbookstart,$varDateTime)
     
    $diffTime = -join ((NEW-TIMESPAN -Start $varDateTime –End $runbookstart).TotalMinutes,'m')
    Write-verbose $diffTime

    $HeartbeatCountQuery = @"
Crowdstrike_SIEM_SVC_CL | where TimeGenerated > ago($diffTime) | where RawData has_any ("Received Heartbeat", "heartbeat failure") | order by TimeGenerated desc
"@
    
    $Error.Clear()
    $resultquery = Invoke-AzOperationalInsightsQuery -WorkspaceId $wrkspaceObj.customerId.Guid -Query $HeartbeatCountQuery
    return $resultquery
}

# Validate Log Analytics workspace
function Validate-LogAnalyticsWorkspace {
    [CmdletBinding()]
    Param ([string]$WorkspaceName)
 
    Try{
       $error.clear()

       $workspaceObj = Get-AzOperationalInsightsWorkspace | ? { $_.Name -eq $WorkspaceName }
       if ($workspaceObj -eq $null) {
           Write-Error "ERROR: Loganalytics Workspace not found. Please enter a valid workspace in the subscription." `
           throw
       } else {
           Write-Verbose "INFO: Log Analytics workspace found in subscription: " 
           return $workspaceObj
        }
    }catch{
       Write-Error "Error in Validate-LogAnalyticsWorkspace function. $($_.Exception.Message)"
    }
}

#-----------------------------------------------------------[Execution]------------------------------------------------------------
try
{
    # Get the connection "AzureRunAsConnection "
    $servicePrincipalConnection = Get-AutomationConnection -Name $connectionName 

    # Logon to Azure
    Connect-AzAccount -Tenant $servicePrincipalConnection.TenantID `
                  -ApplicationId $servicePrincipalConnection.ApplicationID   `
                  -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint `
                  -ServicePrincipal | Out-Null
    $Context = Set-AzContext -SubscriptionId $servicePrincipalConnection.SubscriptionId -WA 0 -EA 0
    $subsID = $servicePrincipalConnection.SubscriptionId
    #Write-Output $subsID
}
catch {
    if (!$servicePrincipalConnection)
    {
        $ErrorMessage = "Connection $connectionName not found."
        throw $ErrorMessage       
    } else{
        Write-Error -Message $_.Exception
        throw $_.Exception
    }
}

Try{
    $error.Clear()

    # importing PSFalcon
    Import-Module -Name PSFalcon
  
    # get the necessary fields #
    $resId=$JsonInput.ProcessedAlert.SearchResults.ResourceId
    $VMName = $resId.Split("/") | Select -Last 1
    $ResourceGroupName = $resId.Split("/") | Select -First 5 | Select -Last 1
    $wsResId=$JsonInput.ProcessedAlert.ResourceId
    $WorkspaceName=$wsResId.Split("/")| Select -Last 1
    $alertN=$JsonInput.ProcessedAlert.alertRule
    $eventT=$JsonInput.ProcessedAlert.SearchResults.TimeGenerated
    $varDateTime=[DateTime]$eventT

    if($alertN -match "SIEM"){
        $errType ='siem'
        #validate workspace
        $wrkspaceObj=Validate-LogAnalyticsWorkspace $WorkspaceName
    }else{
        $errType='svc'
    }

    #accessing crowdstrike IPs from automationaccount variable
    $csRemoteIPs=Get-AutomationVariable -Name "csRemoteIPs"
    $arrcsRem=$csRemoteIPs.split(",")

    # format runbookoutput #
    $rbout =  New-Object PsCustomObject -Property ([ordered] @{
        result=""
        details=""
    })

    # Get VM Info
    $error.Clear()
    $ifVmExists = Get-AzResource -ResourceType "Microsoft.Compute/virtualMachines" -ResourceGroupName $ResourceGroupName -Name $VMName
    
    if (($error) -or ($ifVmExists -eq $null)){ 
       $SHResult ="Failed"
       $runbookStatus="Success"
       $rbout.result="UNABLE TO FIND VM IN SUBSCRIPTION."
    }else{
        $vmObj = Get-AzVM -Name $ifVmExists.Name -ResourceGroupName $ifVmExists.ResourcegroupName
        $vmObjStat = Get-AzVM -Name $ifVmExists.Name -ResourceGroupName $ifVmExists.ResourcegroupName -Status
        Sleep 5

        if($vmObjStat.Statuses[1].DisplayStatus -eq "VM running"){
              $osver = $vmObj.StorageProfile.ImageReference.Offer + " $($vmObj.StorageProfile.ImageReference.Sku)"

            if($errType -eq "svc"){
              $objCSOutput =  New-Object PsCustomObject -Property ([ordered] @{
                 #result= ""
                 hostname = ""
                 osversion=""
                 agentstatus=""
                 connection=""
                 establishedip=""
                 agentrestarted=""
                 processid=""
                 modulelist=""
                 applicationfiles=""
                 proxy=""
                 logfile=""
                 portalstatus = ""
                 portallast_seen=""
                 portalcheck=""
              })
             
              #check crowdstrike portal
              $csPortal=Check_CrowdStrikePortal $ifVmExists.Name -Verbose
              $objCSOutput.portalcheck=$csPortal.resultsMsg
              
              if($csPortal.resultsCode -eq 0){
                 $objCSOutput.portallast_seen=$csPortal.cshostInfo.last_seen
                 $objCSOutput.portalstatus=$csPortal.cshostInfo.status
              }
                 
              $ip=@()
              $validcsip=@()
              $ipcompare=$true

              if($osver -match "Windows"){
                $chksvc=Invoke_RunCMD $ifVmExists.ResourceGroupName $ifVmExists.Name 'win' $errType -Verbose

                #parse the connection result to get the IP
                $objCSOutput.connection=$chksvc.result.connection

                $tmpconn=$chksvc.result.connection
                 if ($tmpconn){
                    foreach($itm in $tmpconn){
                       $tmp=$itm.split(" ")
                       $tmp=$tmp|where({$_ -ne ""})         #removing empty contents
                       $ip+=$tmp[2].split(":")[0]
                    }
                 }

              }else{  ### LINUX ###
                
                #verify crowdstrike falcon sensor service
                $chksvc=Invoke_RunCMD $ifVmExists.ResourceGroupName $ifVmExists.Name 'lin' $errType -Verbose

                #parse the connection result to get the IP
                $tmp=$chksvc.result.connection
                if ($tmp){
                   $arr = $tmp.split(" ")
                   $arr=$arr|where({$_ -ne ""})   #removing empty contents
                }
                foreach($itm in $arr){
                    if($itm -match ":443"){
                       $ip+=$itm.split(":")[0]
                    }
                }
                if(! $chksvc.result.connection -match "ESTABLISHED"){
                    $ipcompare=$false
                }
              } #osver under service

                if ($ipcompare -eq $true){
                   #validating connection to list of crowdstrike remoteIPs
                   $validcsip=$arrcsRem | Where-Object -FilterScript {$_ -in $ip}
                   $iplist=$validcsip -join ","

                   if(($validcsip|Measure-object).Count -ge 1){
                       $objCSOutput.connection="established"
                       $objCSOutput.establishedip=$iplist

                   }else{
                       $objCSOutput.connection="not established"
                   }
                }else{
                    $objCSOutput.connection="not established"
                }
               
                $objCSOutput.hostname=$chksvc.result.hostname
                $objCSOutput.osversion=$chksvc.result.osversion
                $objCSOutput.agentstatus=$chksvc.result.agentstatus
                $objCSOutput.agentrestarted=$chksvc.result.agentrestarted
                $objCSOutput.processid=$chksvc.result.processid
                $objCSOutput.modulelist=$chksvc.result.modulelist
                $objCSOutput.applicationfiles=$chksvc.result.applicationfiles
                $objCSOutput.proxy=$chksvc.result.proxy
                $objCSOutput.logfile=$chksvc.result.logfile
                               
                if ((($objCSOutput.agentstatus -match "loaded active running") -or ($objCSOutput.agentstatus -eq "Running")) -and ($objCSOutput.connection -eq "established") -and ($objCSOutput.agentrestarted -eq "true")){
                   #wait for 10mins to check portal again
                   Sleep -s 600
                   Write-Verbose "Sleeping for 10 mins..."
                   #check crowdstrike portal
                   $csPortal=Check_CrowdStrikePortal $ifVmExists.Name -Verbose  #try to include OSType in filter
                   $objCSOutput.portalcheck=$csPortal.resultsMsg
                   if($csPortal.resultsCode -eq 0){
                      $objCSOutput.portallast_seen=$csPortal.cshostInfo.last_seen
                      $objCSOutput.portalstatus=$csPortal.cshostInfo.status
                   }
                }
               
                #comparing startdate and lastseen
                $timeflag=$false
                if ($objCSOutput.portallast_seen){
                   $lst=Get-Date($objCSOutput.portallast_seen)
                   $difftime =New-TimeSpan -Start $varDateTime -End $lst
                   
                   if($difftime.TotalMinutes -lt -30) {
                      $objCSOutput.portalcheck="Time Difference between AlertEventTime to portallast_seen is $($diffTime.TotalMinutes) minutes."
                   }else{
                      $timeflag =$true
                   }
                }              

                #Conditions for SelfHeal
                $SHResult="Failed"
                if(([string]::IsNullOrEmpty($objCSOutput.agentstatus)) -and ([string]::IsNullOrEmpty($objCSOutput.hostname))){
                   $runbookStatus="Failed"
                   $rbout.result = "UNABLE TO CONNECT TO SERVER TO EXECUTE RUNCOMMANDS."
                }else{
                   $runbookStatus="Success"
                   if(($objCSOutput.agentstatus -eq "agent not found") -or ($objCSOutput.agentstatus -eq "not installed")){
                      $rbout.result = "FALCON SENSOR NOT INSTALLED. COORDINATE WITH POD SECURITY TO RE-DEPLOY."
                   }elseif ((($objCSOutput.agentstatus -match "loaded active running") -or ($objCSOutput.agentstatus -eq "Running")) -and ($objCSOutput.connection -eq "established") -and ($timeflag -eq $true)){
                      $SHResult="Success"
                      $rbout.result ="FALSE POSITIVE – SERVER IS REPORTING IN CROWDSTRIKE PORTAL AND THE AGENT/SERVICE IS RUNNING."
                   }elseif ((($objCSOutput.agentstatus -match "loaded active running") -or ($objCSOutput.agentstatus -eq "Running")) -and ($objCSOutput.connection -eq "established") -and ($timeflag -eq $false)){
                      if($csPortal.resultsCode -eq 0){
                         $rbout.result ="HOST NOT SEEN IN PORTAL FOR MORE THAN 30 MINUTES."
                      }else{
                         $rbout.result=($objCSOutput.portalcheck).toupper()
                      }
                   }else{
                      $rbout.result = "FALCON SENSOR CONNECTION NOT ESTABLISHED. CHECK WITH CLOUDOPS/NETWORK TEAM FOR THE NETWORK OR FIREWALL CONFIG."
                   }                
                }
                               
                 $rbout.details=$objCSOutput 

            }else{   ##### SIEM CHECKS  #####
                                
                if($osver -match "Windows"){
                    $runbookStatus="Success"
                    $SHResult="Failed"
                    $rbout.result="THE CROWDSTRIKE FALCON SIEM CONNECTOR RUNS AS A SERVICE ON A LOCAL LINUX SERVER. PLEASE PROVIDE A DIFFERENT VMNAME." 
                    
                }else{
                  $siemflag=$true
                  $HBRes=Get_HeartBeatCount $ifVmExists.Name $wrkspaceObj $rbstart $varDateTime
                  $datcnt=($HBRes.Results|Measure-Object).Count   #total count
                  if($datcnt -eq 0){
                     $logQresult='No "heartbeat received" found in log query.'
                  }else{
                     $datfailureHB=$HBRes.Results.RawData | where { $_ -match "heartbeat failure"} | Sort
                     $datreceivedHB=$HBRes.Results.RawData | where { $_ -match "received heartbeat"} | Sort

                     if (($datfailureHB.count -eq 0)  -and ($datreceivedHB.count -ne 0)){     #no heartbeafailure
                        $runbookStatus="Success"
                        $SHResult="Success"
                        $rbout.result="FALSE POSITIVE - CROWDSTRIKE SIEM CONNECTION IS ACTIVE."
                        $siemflag=$false
                     }elseif(($datfailureHB.count -ne 0)  -and ($datreceivedHB.count -eq 0)){ #no heartbeat received
                        $logQresult='No "heartbeat received" found in log query.'
                     }else{                                                                   #with heartbeatreceived and heartbeatfailure 
                        #get the last datetime of failure
                        $datfitem=$datfailureHB[$datfailureHB.Count -1]
                        $ftline=$daftitem.split("streamer.go")[0]
                        $ftime=[datetime]$ftline

                        #get the last datetime of receivedHB
                        $datritem=$datreceivedHB[$datreceivedHB.Count -1] 
                        $rtline=$datritem.split("streamer.go")[0]
                        $rtime=[datetime]$rtline

                        #compare which is latest bet 2 dates
                        $tmpf=New-TimeSpan -Start $ftime -End $rbstart
                        $tmpr=New-TimeSpan -Start $rtime -End $rbstart

                        if($tmpf.TotalMinutes -gt $tmpr.TotalMinutes){ 
                           #compare time diff
                           $timediff=New-TimeSpan -Start $ftime -End $rtime
                         
                           if($timediff.TotalMinutes -ge 10){     #10minutes
                              $runbookStatus="Success"
                              $SHResult="Success"
                              $rbout.result="CROWDSTRIKE SIEM CONNECTION IS ACTIVE NOW."
                              $siemflag=$false
                           }else{ 
                               $logQresult='No "heartbeat received" found in the last 10 minutes'
                           }
                        }else{
                           $logQresult="heartbeat failure is the last item found in log query."
                        } 
                     }
                  }#datcnt

                  if($siemflag -eq $true){
                     $objCSOutput =  New-Object PsCustomObject -Property ([ordered] @{
                        result =""
                        hostname = ""
                        osversion=""
                        agentstatus=""
                        agentrestarted=""
                        processid=""
                        siem_errlog=""
                        logqueryresult=$logQresult
                     })
                        
                     #verify siem connector
                     $chksvc=Invoke_RunCMD $ifVmExists.ResourceGroupName $ifVmExists.Name 'lin' $errType -Verbose

                     $objCSOutput.hostname=$chksvc.result.hostname
                     $objCSOutput.osversion=$chksvc.result.osversion
                     $objCSOutput.agentstatus=$chksvc.result.agentstatus
                     $objCSOutput.agentrestarted=$chksvc.result.agentrestarted
                     $objCSOutput.processid=$chksvc.result.processid
                     $objCSOutput.siem_errlog=$chksvc.result.siem_error
                                       
                      if(([string]::IsNullOrEmpty($objCSOutput.agentstatus)) -and ([string]::IsNullOrEmpty($objCSOutput.hostname))){
                        $SHResult="Failed"
                        $runbookStatus="Failed"
                        $rbout.result="UNABLE TO CONNECT TO SERVER TO EXECUTE RUNCOMMANDS."
                     }else{
                        if (($objCSOutput.agentstatus -match "loaded active running") -and ($objCSOutput.agentrestarted -eq $false)) {
                           $runbookStatus="Success"
                           $SHResult="Success"
                           $rbout.result="CROWDSTRIKE SIEM CONNECTOR IS RUNNING."
                        }elseif (($objCSOutput.agentstatus -match "loaded active running") -and ($objCSOutput.agentrestarted -eq $true)){
                           $runbookStatus="Success"
                           $SHResult="Success"
                           $rbout.result="CROWDSTRIKE SIEM CONNECTOR RESTARTED AND RUNNING."
                        }else{
                           $SHResult="Failed"
                           $runbookStatus="Success"
                           if ($chksvc.result.siem_error){
                              $objCSOutput.siem_errlog=$chksvc.result.siem_error

                              if($objCSOutput.siem_errlog -match "refer to logfile"){
                                  $rbout.result="SIEM CONNECTOR NOT RUNNING. ERRORS FOUND IN /VAR/LOG/CROWDSTRIKE/FALCONHOSECLIENT. EXPORT LOG FILE AND SEND TO POD SECURITY ENGINEER OR PUBLIC CLOUD SECURITY."
                              }
                           }else{
                              $rbout.result="SIEM CONNECTOR NOT RUNNING. EXPORT LOG FILE AND SEND TO POD SECURITY ENGINEER OR PUBLIC CLOUD SECURITY."
                           } #siem_errlog
                        }
                     }

                     $rbout.details=$objCSOutput
                  }
                } ##osver inside LINUX if-else
             } #errType
        }else{
            $runbookStatus="Success"
            $SHResult ="Failed"
            $rbout.result="VM MACHINE NOT RUNNING." 
        } #if VM running
    } #$ifVMExists


} catch {
    $runbookStatus = "Failed"
    $rbout.result = $_.Exception.Message
    $SHResult ="Failed"

}finally {
    # Write runbook results to JSON output
    $ScriptJobId = $PsPrivateMetaData.JobId.GUid

    $selfhealMsg=[PSCustomObject]@{
       JobId = $ScriptJobId
       RunbookName = $RunBookName
       Status = $runbookStatus
       Output = $rbout
    }

   $JsonInput.SelfhealResult = $SHResult
   [psCustomObject[]]$JsonInput.SelfhealMessage+=$selfhealMsg
   $JsonInput | ConvertTo-Json -Depth 10
}
