<#
.SYNOPSIS
This script is used for the AgentHealth self-heal automation.
.REVISION HISTORY
    16-Jul-2021 - Initial script development
#>

[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true,Position=1)][string]$arg1
)

$runAction = $arg1.Split("_")[0]
$logAnalyticsWorkspaceID = $arg1.Split("_")[1]
$logAnalyticsWorkspaceKey = $arg1.Split("_")[2]

function verify_heartbeat {
    $mmaDir =  "C:\WindowsAzure\Logs\Plugins\Microsoft.EnterpriseCloud.Monitoring.MicrosoftMonitoringAgent\"
    $mmaCurrentVersion = (Get-ChildItem $mmaDir | Sort-Object LastWriteTime -Descending)[0].Name
    $heartbeatLogDir = [string]::Concat($mmaDir, $mmaCurrentVersion,"\")
    $latestHeartbeatLog = (Get-ChildItem $heartbeatLogDir | ? {$_.Name -like "MMAExtensionHeartbeat*"} | Sort-Object LastWriteTime -Descending)[0].Name
    $heartbeatLogFile = [string]::Concat($heartbeatLogDir, $latestHeartbeatLog)
    $heartbeatLog = Get-Content -Path $heartbeatLogFile -Tail 1
    $lastHeartbeatLog = [string]::Concat($heartbeatLog.Split(" ")[0], " ", $heartbeatLog.Split(" ")[1])
    $heartbeatLogTime = $lastHeartbeatLog | Get-Date -F "yyyy-MM-dd hh:mm:ss"
    $currentTime = Get-Date -F "yyyy-MM-dd hh:mm:ss"
    $heartbeatVariance = (New-Timespan -Start $($heartbeatLogTime) -End $($currentTime)).TotalMinutes
    #if ((New-Timespan –Start $heartbeatLogTime –End $currentTime).TotalMinutes -gt 5) {
    if ($heartbeatVariance -gt 5) {
        return "SKIPPING"
    } else {
        return "SENDING"
    }
}

function omsagentheartbeat {
    $checkOMSAgent = Get-Service -Name "healthservice" -EA 0
    if ($checkOMSAgent.Status -eq "Running") {
        $restarted = $false
        $state = $checkOMSAgent.Status
    } else {
        [int]$count=0
        do {
            Restart-Service -Name "healthservice" -WA 0 -EA 0
            $isRunning = Get-Service -Name "healthservice"
            $count+=1
        } until (($isRunning.Status -eq "Running") -or ($count -eq 3))
        $restarted = $true
        $state = $isRunning.Status
    }
    Start-Sleep -s 30
    $checkOMSExtService = try { Get-Service -Name "MMAExtensionHeartbeatService" -EA 1 } catch { $error.clear(); return $null }
    if ($checkOMSExtService) {
        Restart-Service -Name "MMAExtensionHeartbeatService" -EA 0
        [int]$count=0
        do {
            Restart-Service -Name "MMAExtensionHeartbeatService" -WA 0 -EA 0
            $isRunning = Get-Service -Name "MMAExtensionHeartbeatService"
            $count+=1
        } until (($isRunning.Status -eq "Running") -or ($count -eq 3))
        $state = $isRunning.Status
    }

    $checkHeartbeat = verify_heartbeat
    return "OMSAGENT_RESTARTED: $restarted", "OMSAGENT: $state", "HEARTBEAT: $checkHeartbeat"
}

function omsagentonboard {
    $agentConfigManager = New-Object -ComObject 'AgentConfigManager.MgmtSvcCfg'
    $agentConfigManager.AddCloudWorkspace($logAnalyticsWorkspaceID, $logAnalyticsWorkspaceKey)
    $agentConfigManager.ReloadConfiguration()
    $omsOnboardState = $agentConfigManager.GetCloudWorkspace($logAnalyticsWorkspaceID).ConnectionStatusText
    
    $omsCheck = omsagentheartbeat
    
    return "OMSAGENT_REONBOARDED: $true", "OMSAGENT_ONBOARD_STATUS: $omsOnboardState", $omsCheck[0], $omsCheck[1], $omsCheck[2]
}
function vmagentheartbeat {
    $checkVMAgent = Get-Service -Name "WindowsAzureGuestAgent" -EA 0
    if ($checkVMAgent.Status -eq "Running") {
        $restarted = $false
        $state = $checkVMAgent.Status
    } else {
        [int]$count=0
        do {
            Restart-Service -Name "WindowsAzureGuestAgent" -WA 0 -EA 0
            $isRunning = Get-Service -Name "WindowsAzureGuestAgent"
            $count+=1
        } until (($isRunning.Status -eq "Running") -or ($count -eq 3))
        $restarted = $true
        $state = $isRunning.Status
    }
    $checkHeartbeat = verify_heartbeat
    return "VMAGENT_RESTARTED: $restarted", "VMAGENT_STATUS: $state", "HEARTBEAT: $checkHeartbeat"
}

switch ($runAction) {
    'omsagentheartbeat' {
        omsagentheartbeat
    }
    'omsagentonboard' {
        omsagentonboard
    }
    'vmagentrestart' {
        vmagentheartbeat
    }
    default {
        return "NO ACTION"
    }
}  
