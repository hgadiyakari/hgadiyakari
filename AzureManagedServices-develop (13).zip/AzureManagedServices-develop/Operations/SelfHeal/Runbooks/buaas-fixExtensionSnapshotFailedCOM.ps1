#-----------------------------------------------------------[Comments]-------------------------------------------------------------
<#
.DOCUMENTATION LINK
https://docs.microsoft.com/en-us/azure/backup/backup-azure-vms-troubleshoot#extensionsnapshotfailedcom--extensioninstallationfailedcom--extensioninstallationfailedmdtc---extension-installationoperation-failed-due-to-a-com-error
.SYNOPSIS
This runbook automates the steps to fix the following backup failure errors (restart of COM+ System and MSDTC)-
    - ExtensionSnapshotFailedCOM
    - ExtensionInstallationFailedCOM 
    - ExtensionInstallationFailedMDTC - Extension installation/operation failed due to a COM+ error
As described here: https://docs.microsoft.com/en-us/azure/backup/backup-azure-vms-troubleshoot#extensionsnapshotfailedcom--extensioninstallationfailedcom--extensioninstallationfailedmdtc---extension-installationoperation-failed-due-to-a-com-error
.REVISION HISTORY
    05-Sep-2019 - Initial script development
    25-Mar-2020 - Updated commands
#>

#---------------------------------------------------------[Initializations]-------------------------------------------------------- 

Param(
     [parameter (Mandatory = $true)][PSCustomObject]$jsonInput
 )

#----------------------------------------------------------[Declarations]----------------------------------------------------------

$RunBookName = "buaas-fixExtensionSnapshotFailedCOM"
$connectionName = "AzureRunAsConnection"
$TriggerBackup = $false

#-----------------------------------------------------------[Functions]------------------------------------------------------------

# Supporting functions in this section
function Get-AzCachedAccessToken(){
    $ErrorActionPreference = 'Stop'
    $currentAzureContext = Get-AzContext
    $azureRmProfile = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile
    $profileClient = New-Object Microsoft.Azure.Commands.ResourceManager.Common.RMProfileClient($azureRmProfile)
    $token=$profileClient.AcquireAccessToken($currentAzureContext.Subscription.TenantId)
    $token.AccessToken
}

function Get-AzBearerToken(){
    $ErrorActionPreference = 'Stop'
    ('Bearer {0}' -f (Get-AzCachedAccessToken))
}

function Check-HWConnection { # Check Hybrid Worker connectivity to VM and establish an active remote session

# Get Automation Account credential asset
$credentialAsset = Get-AutomationPSCredential -Name $JsonInput.AutomationCredential 
$userName= $credentialAsset.UserName
$securePassword = $credentialAsset.Password
$password = $credentialAsset.GetNetworkCredential().Password
$securepassword_s = ConvertTo-SecureString "$password" -AsPlainText -Force
    if ($userName.Contains("\") -eq $false) {  $userName = $vmObj.Name + "\" + $userName }
$credential = New-Object System.Management.Automation.PSCredential ($userName,$securepassword_s)

# Validate VM target
$vmObj = Get-AzVm -Name $jsonInput.VMName -Status

Write-Host -ForegroundColor Cyan "Checking the VM connection to the Hybrid Worker VM..."
switch (($vmObj.StorageProfile.OsDisk.OsType | Out-String).trim()) {
    'Linux' {
        $global:hrwSession = New-SSHSession -ComputerName $vmObj.Name -Credential $credential -AcceptKey:$true -ErrorAction SilentlyContinue -ErrorVariable ConnErr
    }
    'Windows' {
        $winOption = New-PSSessionOption -SkipCACheck
        $global:hrwSession = New-PSSession -ComputerName $vmObj.Name  -Port 5986 -Credential $credential -SessionOption $winOption -UseSSL `
            -ErrorAction SilentlyContinue -ErrorVariable ConnErr
    }
}
    
if ($ConnErr) { throw }

if ($global:hrwSession.State -eq 'Opened' -or $global:hrwSession.Connected -eq 'True') {
    $shMsg = Write-Output "VM connection: OK - $vmName is reachable from the Hybrid Worker VM." ; $shRes = "OK"
} else {
    $shMsg = Write-Output "VM connection: NOK - $vmName is unreachable from the Hybrid Worker VM." ; $shRes = "NOK"
}
$global:hrwCheck=[PSCustomObject]@{
    status=$shRes
    output=$shMsg
}
return $global:hrwCheck
}

#-----------------------------------------------------------[Execution]------------------------------------------------------------

try
{
    # Get the connection "AzureRunAsConnection "
    $servicePrincipalConnection = Get-AutomationConnection -Name $connectionName 

    # Logon to Azure
    Connect-AzAccount -Tenant $servicePrincipalConnection.TenantID `
                  -ApplicationId $servicePrincipalConnection.ApplicationID   `
                  -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint `
                  -ServicePrincipal | Out-Null
    $Context = Set-AzContext -SubscriptionId $servicePrincipalConnection.SubscriptionId -WA 0 -EA 0
    $subsID = $servicePrincipalConnection.SubscriptionId
}
catch {
    if (!$servicePrincipalConnection)
    {
        $ErrorMessage = "Connection $connectionName not found."
        throw $ErrorMessage       
    } else{
        Write-Error -Message $_.Exception
        throw $_.Exception
    }
}

try {
    # Enable AzureRm compatibility
    Enable-AzureRmAlias

    # Get access token
    $ArmToken = Get-AzBearerToken

    # Get the Hybrid Runbook Worker VM connection
    Check-HWConnection

    #region Script blocks for execution
    # Script block to check service "COMSysApp"
    $scriptComSysApp = {

    $objResults =  New-Object PsCustomObject -Property @{
    resultsMsg = ""
    resultsCode = ""
    }

    $objCOMSysApp = Get-WmiObject -Class Win32_Service -ComputerName $env:COMPUTERNAME | ? {$_.Name -eq "COMSysApp"} -WA 0 -EA 0 -EV errCOMSysApp
        if ($errCOMSysApp -or ($objCOMSysApp -eq $null)) {
            $objResults.resultsMsg = "COM+ System Application not found. $errCOMSysApp"
            $objResults.resultsCode = 1
            break        
        } else {
            if ($objCOMSysApp.StartMode -eq "Disabled") {
                $objCOMSysApp.Change($null,$null,$null,$null,"Automatic",$null,$null,$null,$null,$null,$null)
            } 
            [int]$count=0
            do {
                Restart-Service -Name $objCOMSysApp.Name -Force -WA 0 -EA 0 -EV errCOMSysApp
                $count+=1 ; sleep 3
            } until (($count -eq 10) -or ((Get-Service -Name $objCOMSysApp.Name).Status -eq "Running"))
        }

    if ((Get-Service -Name $objCOMSysApp.Name).Status -eq "Running") {
        $objResults.resultsMsg = "COM+ System Application was restarted successfully."
        $objResults.resultsCode = 0
    } else {
        $objResults.resultsMsg = "Failed to restart COM+ System Application. $errCOMSysApp"
        $objResults.resultsCode = 1    
    }
    return $objResults
    }

    # Script block to check service "MSDTC"
    $scriptMSDTC = {
    $objResults =  New-Object PsCustomObject -Property @{
    resultsMsg = ""
    resultsCode = ""
    }

    $objMSDTC = Get-WmiObject -Class Win32_Service | ? {$_.Name -eq "MSDTC"} -WA 0 -EA 0 -EV errMSDTC
        if ($errMSDTC -or ($objMSDTC -eq $null)) {
            $objResults.resultsMsg = "MSDTC Application not found. $errMSDTC"
            $objResults.resultsCode = 1
            break
        } else {
            if ($objMSDTC.StartName -ne "NT AUTHORITY\NetworkService") {
                $objMSDTC.Change($null,$null,$null,$null,"Automatic",$null,"NT AUTHORITY\NetworkService","",$null,$null,$null)
            }
            Restart-Service -Name $objMSDTC.Name -Force -WA 0 -EA 0 -EV errMSDTC
        }

    if ((Get-Service -Name $objMSDTC.Name).Status -ne "Running") {
        [int]$count=0
        do {
            msdtc -uninstall ; sleep 5
            msdtc -install ; sleep 5
            Restart-Service -Name $objMSDTC.Name -Force -WA 0 -EA 0 -EV errMSDTC
            $count+=1
        } until (($count -eq 10) -or ((Get-Service -Name $objMSDTC.Name).Status -eq "Running"))
        if ((Get-Service -Name $objMSDTC.Name).Status -ne "Running") {
            $objResults.resultsMsg = "Failed to restart MSDTC Application. $errMSDTC"
            $objResults.resultsCode = 1
        } 
    } else {
        $objResults.resultsMsg = "MSDTC Application is started and running."
        $objResults.resultsCode = 0
    }
    return $objResults
    }
    #endregion

    $resultsComSysApp = Invoke-Command -Session $global:hrwSession -ScriptBlock $scriptComSysApp -WA 0 -EA 0
    if (($error) -or ($resultsComSysApp.resultsCode -eq 1)) {
        $runbookStatus = $resultsComSysApp.resultsMsg + $error
        $runbookOutput = "Failed"
        $TriggerBackup = $false
    } else {
        $resultsMSDTC = Invoke-Command -Session $global:hrwSession -ScriptBlock $scriptMSDTC -WA 0 -EA 0
            if (($error) -or ($resultsMSDTC.resultsCode -eq 1)) {
                $runbookStatus = "Failed"
                $runbookOutput = $resultsComSysApp.resultsMsg + $resultsMSDTC.resultsMsg + $error
                $TriggerBackup = $false
            } else {
                $runbookStatus = "Success"
                $runbookOutput = $resultsComSysApp.resultsMsg + $resultsMSDTC.resultsMsg
                $TriggerBackup = $true
            }
    }
} catch {
    $runbookStatus = "Failed"
    $runbookOutput = $_.Exception.Message
    $TriggerBackup = $false
} finally {
    # Write runbook results to JSON output
    $ScriptJobId = $PsPrivateMetaData.JobId.GUid
    $selfhealMsg=[PSCustomObject]@{
    JobId = $ScriptJobId
    RunbookName = $RunBookName
    Status = $runbookStatus
    Output = $runbookOutput
    }
    if ($jsonInput.psobject.Properties.name -contains "TriggerBackup") {
        $jsonInput.TriggerBackup = $TriggerBackup
    } else {
        $jsonInput | Add-Member -MemberType NoteProperty -Name TriggerBackup -Value $TriggerBackup
    }

    $jsonInput.SelfhealResult=$runbookStatus
    [psCustomObject[]]$jsonInput.SelfhealMessage+=$selfhealMsg
    $jsonInput | ConvertTo-Json
}
