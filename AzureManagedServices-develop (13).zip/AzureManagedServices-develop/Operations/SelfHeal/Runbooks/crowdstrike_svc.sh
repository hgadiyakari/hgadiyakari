#!/bin/bash
# description: Crowdstrike
# Author: CloudOps Automation
# Initial version: May 28, 2021
# See for more information: 
# To report a bug or an issue with Self-heal, log the case here:
# https://confluence.csc.com/pages/viewpage.action?pageId=162089166

#Create log file
TIMESTAMP=`date +"%Y-%m-%d"`
LOGFILE="/tmp/fixCSAgentlog-$TIMESTAMP.txt"

#Remove if there is existing log file
if [ -f "$LOGFILE" ];then
/bin/rm $LOGFILE
fi

#Function to check falcon-sensor status
function check_falconstat {
        #Get  falcon sensor service status
        GETFSSTAT=`sudo systemctl status falcon-sensor` 
        sleep 3
    
        case $GETFSSTAT in
             *running* ) AGENTSTAT="falcon-sensor is running.";;
             *stopped* ) AGENTSTAT="falcon-sensor is stopped.";;
             *inactive* )  AGENTSTAT="falcon-sensor is stopped.";;
             * ) AGENTSTAT="falcon-sensor status is unknown. Please check agent manually.";;
        esac
}

#Function to check falcon-sensor processes
function proc_sensor {
         echo "Checking falcon sensor processid" >> $LOGFILE
         GETPROC=`ps -e | grep -e falcon-sensor`
         sleep 3

         if [[ -n "$GETPROC" ]]; then
         PROCID="$GETPROC"
         else
         PROCID="no running process for falcon-sensor"
         fi
}

#Function to restart service falcon-sensor
function restart_sensor {
        echo "Restart falcon sensor service" >> $LOGFILE
        sudo systemctl restart falcon-sensor.service > /dev/null
        sleep 3
        RESETSVC="true"
}

#Function to check falcon-sensor modules
function module_sensor {
        #List all falcon modules
        echo "List falcon sensor modules" >> $LOGFILE
        SAVEIFS=$IFS   # Save current IFS
        IFS=$'\n'      # Change IFS to new line
        GETMODLST=`sudo lsmod | grep falcon`
        GETMODARR=($GETMODLST) # split to array $names
        IFS=$SAVEIFS   # Restore IFS
        sleep 3

        if [[ -n "$GETMODLST" ]]; then
           for (( i = 0 ; i < (${#GETMODARR[@]}-1) ; i++ )) 
              do  GETMODARR[$i]=\"${GETMODARR[$i]}\"",";
           done
        GETMODARR[${#GETMODARR[@]}-1]=\"${GETMODARR[${#GETMODARR[@]}-1]}\";                      
        echo "${GETMODARR[@]}" >> $LOGFILE
        MODLST="true"
        else
        MODLST="false"
        fi
}

#Function to check Application files
function app_sensor {
        #List all falcon application files
        echo "List falcon sensor application files" >> $LOGFILE
        sudo ls -al /opt/CrowdStrike /opt/CrowdStrike/falcon-sensor >> $LOGFILE 2>&1
        APPSENSOR_RES=`cat $LOGFILE | grep "No such file or directory"`

        if [[ -n "$APPSENSOR_RES" ]]; then
        APPFILES="falcon-sensor application files not found."
        else
        APPFILES="falcon-sensor application files found. refer to logfile."
        fi
}

#Function to check netstat
function netstat_sensor {
         echo "Checking netstat result" >> $LOGFILE
         GETNET=`sudo netstat -tapn | grep falcon`
         sleep 3

         if [[ -n "$GETNET" ]]; then
         NETSTATRES="$GETNET"
         else
         NETSTATRES="not established"
         fi
}

#Function to check proxy
function proxy_sensor {
         echo "Checking proxy settings" >> $LOGFILE
         GETPRO1=`echo $http_proxy`
         sleep 2
         GETPRO2=`echo $https_proxy`
         sleep 2

         if [[ -n "$GETPRO1" ]]; then
         PROXYRES="$GETPRO1"
         else
         PROXYRES="no proxy settings found for http_proxy."
         fi

         if [[ -n "$GETPRO2" ]]; then
         PROXYRES+="$GETPRO2"
         else
         PROXYRES+="no proxy settings found for https_proxy."
         fi
}


#Function to output summary
function display_sum {
       printf '{\n'
       printf '\t"hostname": "%s", \n\t"osversion":"%s",\n\t"agentstatus":"%s", \n\t"connection":"%s",\n\t"agentrestarted":"%s", \n\t"processid":"%s",\n' "$VMNAME" "$OS" "$FSVC" "$NETSTATRES" "$RESETSVC" "$PROCID"
      
       case $MODLST in 
           *true* ) 
           printf '\t"modulelist":[\n'
           printf '\t\t\t\t\t%s\n' "${GETMODARR[@]}"
           printf '\t],'
           ;;
           *false* ) 
           printf '\t"modulelist": "falcon-sensor modules not found.",'
           ;;
       esac
           printf '\n\t"applicationfiles": "%s", \n\t"proxy":"%s", \n\t"logFile":"%s"\n' "$APPFILES" "$PROXYRES" "$LOGFILE"
           printf '}'
}

#### Start of script ###
RESETSVC="false" 

#Get VMName
VMNAME=`uname -n`
echo "hostname: $VMNAME" >> $LOGFILE

#Get OS version
OS=`cat /etc/system-release`

if [[ -n "$OS" ]]; then
echo "osversion: $OS" >> $LOGFILE
OSVERSION=`grep -o 'release [^ ]*' /etc/system-release | cut -d ' ' -f2 | cut -d '.' -f1`
else
OS=`grep PRETTY  /etc/os-release | cut -d "=" -f2 | cut -d "\"" -f2`
OSVERSION=`cat /etc/os-release | grep -i "VERSION_ID="| tr -d '"'| tr -d "VERSION_ID="|awk '{print substr ($0,0,2)}'`
fi

#initial check of falcon sensor if installed by looking at the folder
app_sensor

if [[ "$APPFILES" == *"refer to log"* ]]; then
FSVC=`sudo systemctl --type=service | grep falcon-sensor`
check_falconstat      #check if service is running

case $GETFSSTAT in
   *running* )
    echo "falcon service is running..." >> $LOGFILE
    ;;
   *stopped* )
    restart_sensor   #restart sensor
    check_falconstat  #check falcon sensor
    FSVC=`sudo systemctl --type=service | grep falcon-sensor`
    ;;
   *inactive* )
    restart_sensor   #restart sensor
    check_falconstat  #check falcon sensor
    FSVC=`sudo systemctl --type=service | grep falcon-sensor`
   ;;
   * )
    echo "Check application files..." >> $LOGFILE
   ;;
esac

else
FSVC="not installed"
echo "not installed" >> $LOGFILE
fi

#additional checks
proc_sensor     #check processId
module_sensor   #check modules
app_sensor      #check application files
netstat_sensor  #check netstat
proxy_sensor    #check proxy settings

display_sum  | tee -a $LOGFILE #Display summary of output

if [[ -z "$ERROR" ]]; then
   exit 0
else
   exit 1
fi