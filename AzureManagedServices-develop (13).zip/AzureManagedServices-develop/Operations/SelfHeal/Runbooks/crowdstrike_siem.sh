#!/bin/bash
# description: Crowdstrike
# Author: CloudOps Automation
# Initial version: June 01, 2021
# See for more information: 
# To report a bug or an issue with Self-heal, log the case here:
# https://confluence.csc.com/pages/viewpage.action?pageId=162089166

#Create log file
TIMESTAMP=`date +"%Y-%m-%d"`
LOGFILE="/tmp/fixSiemAgentlog-$TIMESTAMP.txt"

#Remove if there is existing log file
if [ -f "$LOGFILE" ];then
/bin/rm $LOGFILE
fi

#Function to check SIEM connector status
function check_siemstat {
        #Get  falcon sensor service status
        GETFSSTAT=`sudo systemctl status cs.falconhoseclientd` 
        sleep 3
    
        case $GETFSSTAT in
             *running* ) AGENTSTAT="falconhoseclientd is running.";;
             *stopped* ) AGENTSTAT="falconhoseclientd is stopped.";;
             *inactive* )  AGENTSTAT="falconhoseclientd is stopped.";;
             * ) AGENTSTAT="falconhoseclientd status is unknown. Please check agent manually.";;
        esac
}

#Function to check falcon-sensor processes
function proc_siem {
         echo "Checking falconhoseclientd processid" >> $LOGFILE
         GETPROC=`sudo ps -ef | grep cs.falconhoseclientd`
         sleep 3

         if [[ -n "$GETPROC" ]]; then
         PROCID="$GETPROC"         
         else
         PROCID="No running process for SIEM connector."
         check_siemlog   #check siem log for ERROR
         fi
}

#Function to restart service falcon-sensor
function restart_siem {
        echo "Restart SIEM connector service" >> $LOGFILE
        #sudo service cs.falconhoseclientd start> /dev/null
        sudo systemctl restart cs.falconhoseclientd.service > /dev/null
        sleep 3
        RESETSVC="true"
}

#Function to check ERROR in SIEM log
function check_siemlog {
        echo "check for any ERROR in SIEM log" >> $LOGFILE
        cat /var/log/crowdstrike/falconhoseclient/cs.falconhoseclient.log | grep "ERROR" >> $LOGFILE 2>&1   #check for any errors
        SAVEIFS=$IFS   # Save current IFS
        IFS=$'\n'      # Change IFS to new line
        ERRLOG=`cat /var/log/crowdstrike/falconhoseclient/cs.falconhoseclient.log | grep "ERROR"`
        ARRERR=($ERRLOG)
        IFS=$SAVEIFS   # Restore IFS
        PREVDATE=$(date -d "yesterday 13:00" +"%Y/%m/%d")
        MYDATE=$(date +"%Y/%m/%d")

        #find ERROR from yesterday and today's dates
        for (( i = 0 ; i < ${#ARRERR[@]} ; i++ ))
         do
           case ${ARRERR[$i]} in
           *"$MYDATE"*)
              array+=${ARRERR[$i]}
           ;;
           *"$PREVDATE"*)
              array+=${ARRERR[$i]}
           ;;
           esac
         done

        #echo "${#array[@]}"                #array count
        echo "${array[@]}" >> $LOGFILE      #printing array
        if [ -z "$array" ]; then    #array is empty
        ERRLINES="NO error found with $PREVDATE - $MYDATE in cs.falconhoseclient.log."
        else
        ERRLINES="ERROR found in cs.falconhoseclient.log. refer to logfile."
        fi
}

#Function to output summary
function display_sum {
       printf '{\n'
       case $PROCID in
          *"No running process"*)
          printf '\t"hostname": "%s", \n\t"osversion":"%s",\n\t"agentstatus":"%s", \n\t"agentrestarted":"%s",\n\t"processid":"%s",\n\t"siem_error":"%s"\n' "$VMNAME" "$OS" "$FSVC" "$RESETSVC" "$PROCID" "$ERRLINES"      
           ;;
          *)
          printf '\t"hostname": "%s", \n\t"osversion":"%s",\n\t"agentstatus":"%s", \n\t"agentrestarted":"%s",\n\t"processid":"%s"\n' "$VMNAME" "$OS" "$FSVC" "$RESETSVC" "$PROCID"
          ;;
       esac
       printf '}'
}

#### Start of script ###
RESETSVC="false" 

#Get VMName
VMNAME=`uname -n`
echo "VMName: $VMNAME" >> $LOGFILE

#Get OS version
OS=`cat /etc/system-release`

if [[ -n "$OS" ]]; then
echo "OS version: $OS" >> $LOGFILE
OSVERSION=`grep -o 'release [^ ]*' /etc/system-release | cut -d ' ' -f2 | cut -d '.' -f1`
else
OS=`grep PRETTY  /etc/os-release | cut -d "=" -f2 | cut -d "\"" -f2`
OSVERSION=`cat /etc/os-release | grep -i "VERSION_ID="| tr -d '"'| tr -d "VERSION_ID="|awk '{print substr ($0,0,2)}'`
fi

#initial check of SIEM connector if installed
CHK_SVC=`sudo systemctl --type=service | grep cs.falconhoseclientd`
sleep 3
echo "$CHK_SVC" >> $LOGFILE

if [[ -n "$CHK_SVC" ]]; then
FSVC="$CHK_SVC"
check_siemstat         #check if service is running
else
FSVC="SIEM Connector Service Not Found"
fi

case $GETFSSTAT in
   *running* )
     echo "cs.falconhoseclientd service is running..." >> $LOGFILE
    ;;
   *stopped* )
    restart_siem   #start siem
    check_siemstat  #check SIEM connector
    FSVC="$CHK_SVC"
    ;;
   *inactive* )
    restart_siem   #start siem
    check_siemstat   #check SIEM connector
    FSVC="$CHK_SVC"
   ;;
   * )
    echo "Check Log for ANY errors" >> $LOGFILE
    
   ;;
esac

#addtl checks
proc_siem     #check processId

display_sum  | tee -a $LOGFILE #Display summary of output


if [[ -z "$ERROR" ]]; then
   exit 0
else
   exit 1
fi