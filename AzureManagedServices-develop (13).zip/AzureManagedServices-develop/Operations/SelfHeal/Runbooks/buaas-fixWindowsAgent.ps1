#-----------------------------------------------------------[Comments]-------------------------------------------------------------
<#
.DOCUMENTATION LINK
https://docs.microsoft.com/en-us/azure/backup/backup-azure-troubleshoot-vm-backup-fails-snapshot-timeout#the-agent-installed-in-the-vm-but-unresponsive-for-windows-vms
.SYNOPSIS
This runbook automates the steps to fix the following backup failure caused by the Windows Azure Guest Agent service
As described here: https://docs.microsoft.com/en-us/azure/backup/backup-azure-troubleshoot-vm-backup-fails-snapshot-timeout#the-agent-installed-in-the-vm-but-unresponsive-for-windows-vms
.REVISION HISTORY
    28-Aug-2019 - Initial script development
    13-Apr-2020 - Updated commands
#>

#---------------------------------------------------------[Initializations]-------------------------------------------------------- 

Param(
     [parameter (Mandatory = $true)][PSCustomObject]$jsonInput
 )

#----------------------------------------------------------[Declarations]----------------------------------------------------------

$RunBookName = "buaas-fixWindowsAgent"
$connectionName = "AzureRunAsConnection"
$TriggerBackup = $false

#-----------------------------------------------------------[Functions]------------------------------------------------------------

# Supporting functions in this section
function Get-AzCachedAccessToken(){
    $ErrorActionPreference = 'Stop'
    $currentAzureContext = Get-AzContext
    $azureRmProfile = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile
    $profileClient = New-Object Microsoft.Azure.Commands.ResourceManager.Common.RMProfileClient($azureRmProfile)
    $token=$profileClient.AcquireAccessToken($currentAzureContext.Subscription.TenantId)
    $token.AccessToken
}

function Get-AzBearerToken(){
    $ErrorActionPreference = 'Stop'
    ('Bearer {0}' -f (Get-AzCachedAccessToken))
}

function Check-HWConnection { # Check Hybrid Worker connectivity to VM and establish an active remote session

# Get Automation Account credential asset
$credentialAsset = Get-AutomationPSCredential -Name $JsonInput.AutomationCredential 
$userName= $credentialAsset.UserName
$securePassword = $credentialAsset.Password
$password = $credentialAsset.GetNetworkCredential().Password
$securepassword_s = ConvertTo-SecureString "$password" -AsPlainText -Force
    if ($userName.Contains("\") -eq $false) {  $userName = $vmObj.Name + "\" + $userName }
$credential = New-Object System.Management.Automation.PSCredential ($userName,$securepassword_s)

# Validate VM target
$vmObj = Get-AzVm -Name $jsonInput.VMName -Status

Write-Host -ForegroundColor Cyan "Checking the VM connection to the Hybrid Worker VM..."
switch (($vmObj.StorageProfile.OsDisk.OsType | Out-String).trim()) {
    'Linux' {
        $global:hrwSession = New-SSHSession -ComputerName $vmObj.Name -Credential $credential -AcceptKey:$true -ErrorAction SilentlyContinue -ErrorVariable ConnErr
    }
    'Windows' {
        $winOption = New-PSSessionOption -SkipCACheck
        $global:hrwSession = New-PSSession -ComputerName $vmObj.Name  -Port 5986 -Credential $credential -SessionOption $winOption -UseSSL `
            -ErrorAction SilentlyContinue -ErrorVariable ConnErr
    }
}
    
if ($ConnErr) { throw }

if ($global:hrwSession.State -eq 'Opened' -or $global:hrwSession.Connected -eq 'True') {
    $shMsg = Write-Output "VM connection: OK - $vmName is reachable from the Hybrid Worker VM." ; $shRes = "OK"
} else {
    $shMsg = Write-Output "VM connection: NOK - $vmName is unreachable from the Hybrid Worker VM." ; $shRes = "NOK"
}
$global:hrwCheck=[PSCustomObject]@{
    status=$shRes
    output=$shMsg
}
return $global:hrwCheck
}

#-----------------------------------------------------------[Execution]------------------------------------------------------------

try
{
    # Get the connection "AzureRunAsConnection "
    $servicePrincipalConnection = Get-AutomationConnection -Name $connectionName 

    # Logon to Azure
    Connect-AzAccount -Tenant $servicePrincipalConnection.TenantID `
                  -ApplicationId $servicePrincipalConnection.ApplicationID   `
                  -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint `
                  -ServicePrincipal | Out-Null
    $Context = Set-AzContext -SubscriptionId $servicePrincipalConnection.SubscriptionId -WA 0 -EA 0
    $subsID = $servicePrincipalConnection.SubscriptionId
}
catch {
    if (!$servicePrincipalConnection)
    {
        $ErrorMessage = "Connection $connectionName not found."
        throw $ErrorMessage       
    } else{
        Write-Error -Message $_.Exception
        throw $_.Exception
    }
}

try {
    # Enable AzureRm compatibility
    Enable-AzureRmAlias

    # Get access token
    $ArmToken = Get-AzBearerToken

    # Get the Hybrid Runbook Worker VM connection
    Check-HWConnection

    #region Script block to check service "WindowsAzureGuestAgent"
    $scriptWinAgentInstall = {
    $objResults =  New-Object PsCustomObject -Property @{
    resultsMsg = ""
    resultsCode = ""
    }
    $objWinAgent = Get-WmiObject -Class Win32_Service | ? {$_.Name -eq "WindowsAzureGuestAgent"} -WA 0 -EA 0 -EV errWinAgentInstall
        if ($errWinAgent -or ($objWinAgent -eq $null)) {
            $downloadUri = "http://aka.ms/vmagentwin"
            $downloadPath = Join-Path (Get-Item -Path .\ -Verbose).Fullname "WindowsAzureVmAgent.msi"
            $logFile = Join-Path (Get-Item -Path .\ -Verbose).Fullname "scriptWinAgentInstall.log"
            (New-Object System.Net.WebClient).DownloadFile($downloadUri, $downloadPath)
            if ((Test-Path -Path $downloadPath) -eq $true) {
                $msiArguments = @("/i " +$downloadPath + " /quiet /L*v $logFile")
                [int]$count=0
                do {
                    Start-Process "msiexec.exe" -ArgumentList $msiArguments -Wait -NoNewWindow -WA 0 -EA 0 -EV errWinAgentInstall
                    $checkWinAgent = Get-Service -Name "WindowsAzureGuestAgent" -WA 0 -EA 0 -EV errWinAgentInstall
                    $count+=1
                } until ($checkWinAgent -or ($count -eq 10))
            } else {
                $objResults.resultsCode = 1
                $objResults.resultsMsg = "Unable to download WindowsAzureGuestAgent installer. $errWinAgentInstall"
            }
            if ($checkWinAgent) { 
                $objResults.resultsCode = 0
                $objResults.resultsMsg = "Successfully downloaded and installed WindowsAzureGuestAgent. "
            } else {
                $objResults.resultsCode = 1
                $objResults.resultsMsg = "Failed to install WindowsAzureGuestAgent. $errWinAgentInstall"
            }
        } else {
                $objResults.resultsCode = 0
                $objResults.resultsMsg = "WindowsAzureGuestAgent is currently installed. "
        }
    $objResults
    }

    $scriptWinAgentRestart = {
    $objResults =  New-Object PsCustomObject -Property @{
    resultsMsg = ""
    resultsCode = ""
    }
    $objWinAgent = Get-WmiObject -Class Win32_Service | ? {$_.Name -eq "WindowsAzureGuestAgent"} -WA 0 -EA 0 -EV errWinAgentRestart
        if ($objWinAgent.State -ne "Running") {
            $objWinAgent.Change($null,$null,$null,$null,"Automatic",$null,$null,$null,$null,$null,$null)
        }
        [int]$count=0
        do {
            Restart-Service -Name "WindowsAzureGuestAgent" -WA 0 -EA 0
            $checkWinAgentStatus = Get-Service -Name "WindowsAzureGuestAgent" -WA 0 -EA 0 -EV errWinAgentRestart
            $count+=1
        } until (($checkWinAgentStatus.Status -eq "Running") -or ($count -eq 10))

        if ($checkWinAgentStatus.Status -eq "Running") {
            $objResults.resultsCode = 0
            $objResults.resultsMsg = "WindowsAzureGuestAgent service was restarted successfully. "
        } else {
            $objResults.resultsCode = 1
            $objResults.resultsMsg = "Failed to restart WindowsAzureGuestAgent service. $errWinAgentRestart"
        }
    $objResults
    }
    #endregion

    # Execute scripts to fix WindowsAzureGuestAgent
    $resultsWinAgentInstall = Invoke-Command -Session $global:hrwSession -ScriptBlock $scriptWinAgentInstall -WA 0 -EA 0
    if (($error) -or ($resultsWinAgentInstall.resultsCode -eq 1)) {
        $runbookStatus = "Failed"
        $runbookOutput = $resultsWinAgentInstall.resultsMsg + $error
        $TriggerBackup = $false
    } else {
        $resultsWinAgentRestart = Invoke-Command -Session $global:hrwSession -ScriptBlock $scriptWinAgentRestart -WA 0 -EA 0
        if (($error) -or ($resultsWinAgentRestart.resultsCode -eq 1)) {
            $runbookStatus = "Failed"
            $runbookOutput = $resultsWinAgentInstall.resultsMsg + $resultsWinAgentRestart.resultsMsg + $error
            $TriggerBackup = $false
        } else {
            $runbookStatus = "Success"
            $runbookOutput = $resultsWinAgentInstall.resultsMsg + $resultsWinAgentRestart.resultsMsg
            $TriggerBackup = $true    
        }
    }

} catch {
    $runbookStatus = "Failed"
    $runbookOutput = $_.Exception.Message
    $TriggerBackup = $false
} finally {
    # Write runbook results to JSON output
    $ScriptJobId = $PsPrivateMetaData.JobId.GUid
    $selfhealMsg=[PSCustomObject]@{
    JobId = $ScriptJobId
    RunbookName = $RunBookName
    Status = $runbookStatus
    Output = $runbookOutput
    }

    if ($jsonInput.psobject.Properties.name -contains "TriggerBackup") {
        $jsonInput.TriggerBackup = $TriggerBackup
    } else {
        $jsonInput | Add-Member -MemberType NoteProperty -Name TriggerBackup -Value $TriggerBackup
    }

    $jsonInput.SelfhealResult = $runbookStatus 
    [psCustomObject[]]$jsonInput.SelfhealMessage+=$selfhealMsg
    $jsonInput | ConvertTo-Json
}
