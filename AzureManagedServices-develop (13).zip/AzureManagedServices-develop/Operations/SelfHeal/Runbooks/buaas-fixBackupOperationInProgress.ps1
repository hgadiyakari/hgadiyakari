#region COMMENTS
<#
.SYNOPSIS
    This will Trigger Backup in Azure
.PARAMETER
    [PSCustomObject]$JsonInput
.REVISION HISTORY
    Creation Date:  24-Jul-2019
    24-Jul-2019 - v.01 - Initial script development
    05-Sep-2019 - added support for different RG
    04-Nov-2019 - fix deprecated cmd
    17-Jun-2021 - corrected Check-RunningBackupJob function
#>
#endregion

#region PARAMETERS
Param(
     [Parameter (Mandatory = $true)]
     [PSCustomObject]$JsonInput
 )
#endregion

#---------------------------------------------------------[Initializations]--------------------------------------------------------


#----------------------------------------------------------[Declarations]----------------------------------------------------------

$connectionName = "AzureRunAsConnection"
$RunBookName="buaas-fixBackupOperationInProgress"
#-----------------------------------------------------------[Functions]------------------------------------------------------------

#region FUNCTIONS

function Get-AzCachedAccessToken(){
    $ErrorActionPreference = 'Stop'
    $currentAzureContext = Get-AzContext
    $azureRmProfile = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile
    $profileClient = New-Object Microsoft.Azure.Commands.ResourceManager.Common.RMProfileClient($azureRmProfile)
    $token=$profileClient.AcquireAccessToken($currentAzureContext.Subscription.TenantId)
    $token.AccessToken
}

function Get-AzBearerToken(){
    $ErrorActionPreference = 'Stop'
    ('Bearer {0}' -f (Get-AzCachedAccessToken))
}

function Check-RunningBackupJob($JsonInput,$RunbookStartTime){

 Try{
 $error.Clear()
 $dateToday =(Get-Date).ToUniversalTime()

 #Getting values of SelfHealMessage
 [PSObject[]] $JobsCancelled_Coll=@()

 #Check if target VM has a valid vault location
 $vaultlist=Get-AzRecoveryServicesVault -ResourceGroupName $JasonInput.RGName

 foreach($vault in $vaultlist){
   $vaultItem = Get-AzRecoveryServicesVault -ResourceGroupName $JasonInput.RGName -Name $JsonInput.VaultName
   $fnames = Get-AzRecoveryServicesBackupContainer -ContainerType "AzureVM" -Status "Registered" -VaultId $vaultItem.ID | select -ExpandProperty friendlyname
   
   if($fnames.contains($JsonInput.VMName)){
      $validvault = $vault.Name

      # check for running backup #
      $joblist = Get-AzRecoveryServicesBackupJob -Status InProgress -VaultId $vaultItem.ID -From $dateToday.AddDays(-29) -EA 0 | where {$_.WorkloadName -eq $JsonInput.VMName}

      if($joblist -eq $null){
         $SHM1 = ("No running jobs for " +  $JsonInput.VMName + " in current vault :" + $JsonInput.VaultName)
      }else{
         if($joblist.count -eq 1){ 
              $job = $joblist
          }else{ 
              $job = $joblist[$joblist.count -1]
          }

          $SHM1 = ("InProgress job for " +  $JsonInput.VMName + " found in vault :" + $JsonInput.VaultName +". JobId/ActivityId : " + $job.JobId + "/ " + $job.ActivityId)
      }

   }else{  
     #check if there is running job with the VMName under old vault --and STOP it.
     #old vault pertains to where the backup item was setup before moving to the current vault
     $joblist = Get-AzRecoveryServicesBackupJob -Status InProgress -VaultId $vaultItem.ID -From $dateToday.AddDays(-29)
     
     $curdate = (Get-Date).ToUniversalTime()

     foreach($job in $joblist){
        if($job.WorkloadName -eq $JsonInput.VMName){

            #list all jobs that are cancelled in a custom object = old vault - jobid - cancelled
            $itemrow=New-Object PSCustomObject
            $itemrow | Add-Member -Name "VaultName" -MemberType NoteProperty -Value $vault.Name
            $itemrow | Add-Member -Name "JobId" -MemberType NoteProperty -Value $job.JobId

            Stop-AzRecoveryServicesBackupJob -JobID $job.JobID -VaultId $vaultItem.ID | Out-Null

            do{
               $job= Get-AzRecoveryServicesBackupJob -VaultId $vaultItem.ID -JobId $job.JobID -From $curdate.AddDays(-29)
               $jobRunStatus = $job.Status    
               $curdate = (Get-Date).ToUniversalTime()
               $lapsedmins = $curdate - $RunbookStartTime
               if($lapsedmins.TotalMinutes -ge 170){
                  $jobRunStatus = "Runbook TimeOut"
                  $SHM1 = "Rubook TimeOut while waiting for Job cancellation."
                  break
               }
               Sleep 5
            } while(($jobRunStatus -ne "Failed") -and ($jobRunStatus -ne "Cancelled") -and ($jobRunStatus -ne "Completed") -and ($jobRunStatus -ne "CompletedWithWarnings"))  

            $itemrow | Add-Member -Name "Status" -MemberType NoteProperty -Value $jobRunStatus
            $JobsCancelled_Coll+=$itemrow
        }
     }
   }
 } #foreach vault

 return $validvault, $JobsCancelled_Coll, $JobRunStatus, $SHM1

 }catch{
  Write-Error ("Script executed with errors in Check-RunningBackupJob function." + $Error)
 }
}
#endregion

#-----------------------------------------------------------[Execution]------------------------------------------------------------

#region MAIN

try
{
   
  $RunbookStartTime = (Get-Date).ToUniversalTime()
    
  # Get the connection "AzureRunAsConnection "
  $servicePrincipalConnection = Get-AutomationConnection -Name $connectionName

  Add-AzAccount -Tenant $servicePrincipalConnection.TenantID `
                -ApplicationId $servicePrincipalConnection.ApplicationID   `
                -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint `
                -ServicePrincipal | Out-Null
  $Context = Set-AzContext -SubscriptionId $servicePrincipalConnection.SubscriptionId -WarningAction Ignore
  $subsID = $servicePrincipalConnection.SubscriptionId
}catch {
    if (!$servicePrincipalConnection)
    {
        $ErrorMessage = "Connection $connectionName not found."
        throw $ErrorMessage       
    } else{
        Write-Error -Message $_.Exception
        throw $_.Exception
    }
}

 Try{        
  # Authentication
  $ArmToken = Get-AzBearerToken

  # Register the Recovery Services provider #
  Register-AzResourceProvider -ProviderNamespace "Microsoft.RecoveryServices" | Out-Null

  $TriggerBackup =$false
  $validvault, $CancelledJobs, $JobRunStatus, $SHM1 = Check-RunningBackupJob $JsonInput $RunbookStartTime
    
  if($JobRunStatus -ne "Runbook TimeOut"){
     if($CancelledJobs.Count -ge 1){
        $TriggerBackup =$true
        $SHResult = "Success"
        $SHM2 = "Successfully Cancelled running backup Jobs."
     }else{
        $TriggerBackup =$true
        $SHResult = "Success"
        $SHM2 = (". No running jobs for " +  $JsonInput.VMName + " in other vaults.")
     }
  }else{
     $SHResult = "Failed"
     $TriggerBackup =$false
  }

  $SHMessage = $SHM1 + " " + $SHM2

} catch {
    $SHResult = "Failed"
    $SHMessage = $_.Exception.Message
    $TriggerBackup = $false

}finally{
    # Write runbook results to JSON output
    $ScriptJobId = $PsPrivateMetaData.JobId.GUid
    $selfhealMsg=[PSCustomObject]@{ 
       JobId = $ScriptJobId
       RunbookName = $RunBookName 
       Status = $SHResult
       Output = $SHMessage 
    } 
    if ($jsonInput.psobject.Properties.name -contains "TriggerBackup") {
        $jsonInput.TriggerBackup = $TriggerBackup
    } else {
        $jsonInput | Add-Member -MemberType NoteProperty -Name TriggerBackup -Value $TriggerBackup
    }

    $jsonInput.SelfhealResult=$SHResult

    [PSCustomObject[]]$JsonInput.SelfhealMessage+=$selfhealMsg
    $jsonInput | ConvertTo-Json

}
#endregion
