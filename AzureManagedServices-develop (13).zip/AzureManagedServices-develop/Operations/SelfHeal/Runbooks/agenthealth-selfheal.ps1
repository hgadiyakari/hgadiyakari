#-----------------------------------------------------------[Comments]-------------------------------------------------------------
<#
.DOCUMENTATION LINK
.SYNOPSIS
This runbook automates the steps to fix the following issues as displayed in AgentHealthDashboard
 - Incorrect workspace
 - Monitoring agent extension failed, unavailable
 - Monitoring agent skipping or no heartbeat
 - VM agent not ready
.REVISION HISTORY
    16-Jul-2021 - Initial script development
#>
#---------------------------------------------------------[Initializations]-------------------------------------------------------- 

Param(
    [parameter (Mandatory = $true)][PSCustomObject]$JsonInput
 )

#----------------------------------------------------------[Declarations]----------------------------------------------------------

$runbookName = "agenthealth-selfheal"
$connectionName = "AzureRunAsConnection"
$runScriptUri = "https://dxcazuretoolsdev.blob.core.windows.net/selfheal/runbooks/"
# Self-heal runbook output
$runbookDetails = [PSCustomObject]@{
    JobId = $PsPrivateMetaData.JobId.Guid
    RunbookName = $runbookName
    Status = "Successful"
    Output = $null
}
$workspaceId = $JsonInput.ProcessedAlert.SearchResults.RequiredWorkspaceId
$dateNow = Get-Date -F 'yyyy-MM-dd'
$targetResourceId = $JsonInput.ProcessedAlert.SearchResults.ResourceId
# Self-heal query
$selfhealQuery = @"
SelfHeal_CL
| where TimeGenerated between (datetime($dateNow) .. now())
| where SelfhealCategory_s == 'AgentHealth' and ResourceId == '$targetResourceId'
"@

#-----------------------------------------------------------[Functions]------------------------------------------------------------
#region SUPPORTING FUNCTIONS
function Get-AzCachedAccessToken(){
    $ErrorActionPreference = 'Stop'
    $currentAzureContext = Get-AzContext
    $azureRmProfile = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile
    $profileClient = New-Object Microsoft.Azure.Commands.ResourceManager.Common.RMProfileClient($azureRmProfile)
    $token=$profileClient.AcquireAccessToken($currentAzureContext.Subscription.TenantId)
    $token.AccessToken
}

function Get-AzBearerToken(){
    $ErrorActionPreference = 'Stop'
    ('Bearer {0}' -f (Get-AzCachedAccessToken))
}

function Reinstall-OMS {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$true,Position=1)][object]$vmObj,
        [Parameter(Mandatory=$true,Position=2)][string]$logAnalyticsWorkspaceID,
        [Parameter(Mandatory=$true,Position=3)][string]$logAnalyticsWorkspaceKey
    )

    # Install the Log Analytics agent as VM extension
    $publicSettings = @{"workspaceId" = $logAnalyticsWorkspaceID }
    $protectedSettings = @{"workspaceKey" = $logAnalyticsWorkspaceKey }
    if ($vmObj.StorageProfile.OsDisk.OsType -eq "Linux") {
        $vmExtensionType = "OmsAgentForLinux"
    } else {
        $vmExtensionType = "MicrosoftMonitoringAgent"
    }
    $vmExtensionName = ($vmObj.Extensions.Id | Select-String "OMSAgent", "OmsAgentForLinux", "MicrosoftMonitoringAgent" | Out-String).Split("/")[-1].Trim()
    if (![string]::IsNullorEmpty($vmExtensionName)) {
        Remove-AzVMExtension -ResourceGroupName $vmObj.ResourceGroupName -Name $vmExtensionName -VMName $vmObj.Name -Force -EA 0
        Start-Sleep -Seconds 5
    }

    Set-AzVMExtension -ExtensionName $vmExtensionType -ResourceGroupName $vmObj.ResourceGroupName -VMName $vmObj.Name -Location $vmObj.Location `
        -Publisher "Microsoft.EnterpriseCloud.Monitoring" -ExtensionType $vmExtensionType `
        -TypeHandlerVersion 1.7 -Settings $publicSettings -ProtectedSettings $protectedSettings -EA 0 | Out-Null

    Start-Sleep -Seconds 60
    $checkVMExtension = Get-AzVMExtension -ResourceGroupName $vmObj.ResourceGroupName -VMName $vmObj.Name -Name $vmExtensionType 
    if ($null -eq $checkVMExtension) {
        $result =  $null
    } else {
        $result = $($checkVMExtension.ProvisioningState)
    }

    return $result
}

function Execute-RunCMD {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$true,Position=1)][object]$vmObj,
        [Parameter(Mandatory=$true,Position=2)][string]$logAnalyticsWorkspaceID,
        [Parameter(Mandatory=$true,Position=3)][string]$logAnalyticsWorkspaceKey,
        [Parameter(Mandatory=$true,Position=4)][string]$runCMDId,
        [Parameter(Mandatory=$true,Position=5)][string]$runCMDScriptPath,
        [Parameter(Mandatory=$true,Position=6)][string]$runCMDArg
    )
    $runCmdResults = Invoke-AzVMRunCommand -ResourceGroupName $vmObj.ResourceGroupName `
        -VMName $vmObj.Name -CommandId $runCMDId -ScriptPath $runCMDScriptPath `
        -Parameter @{arg1 = "$runCMDArg"} -EA 0 -Verbose
    return $runCmdResults.Value.Message
}
#endregion

#-----------------------------------------------------------[Execution]------------------------------------------------------------

try
{
    # Get the connection "AzureRunAsConnection "
    $servicePrincipalConnection = Get-AutomationConnection -Name $connectionName 

    # Logon to Azure
    Connect-AzAccount -Tenant $servicePrincipalConnection.TenantID `
                  -ApplicationId $servicePrincipalConnection.ApplicationID   `
                  -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint `
                  -ServicePrincipal | Out-Null
    Set-AzContext -SubscriptionId $servicePrincipalConnection.SubscriptionId -WA 0 -EA 0 | Out-Null
}
catch {
    if (!$servicePrincipalConnection)
    {
        $ErrorMessage = "Connection $connectionName not found."
        throw $ErrorMessage       
    } else{
        Write-Error -Message $_.Exception
        throw $_.Exception
    }
}

try {
    # Bypass TLS error
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

    # Validate the log analytics workspace
    $workspaceObj = Get-AzOperationalInsightsWorkspace | ? { $_.CustomerId -eq $workspaceId }
    if ($null -eq $workspaceObj) {
        Write-Error "Unable to find workspace ID $workspaceID in subscription."
        throw
    } else {
        $workspaceKey = (Get-AzOperationalInsightsWorkspaceSharedKey -ResourceGroupName $workspaceObj.ResourceGroupName `
            -Name $workspaceObj.Name -WA Ignore).PrimarySharedKey
        $JsonInput.ProcessedAlert.ResourceId =  $workspaceObj.ResourceId
    }

    # Determine if Self-heal will be invoked
    $selfhealResults = (Invoke-AzOperationalInsightsQuery -WorkspaceId $workspaceId -Query $selfhealQuery -EA 0).results
    if (!([string]::IsNullOrEmpty($selfhealResults))) {
        $runbookDetails.Output = "Self-heal was already attempted. Please check manually."
        $selfhealResult = "Not applicable"
        $selfhealSeverity = "Critical"
        exit
    }

    # Download run script
    if ($JsonInput.OSType -eq "Linux") {
        $runScript = "agenthealth_linux.sh"
        $runCommandId = "RunShellScript"
    } else {
        $runScript = "agenthealth_windows.ps1"
        $runCommandId = "RunPowerShellScript"
    }
    $downloadUri = [string]::Concat($runScriptUri,$runScript)
    $downloadPath = [string]::Concat([System.IO.Path]::GetTempPath(),$runScript)
    (New-Object System.Net.WebClient).DownloadFile($downloadUri, $downloadPath)

    if (!(Test-Path -Path $downloadPath)) {
        throw "ERROR: Unable to download run scripts for AgentHealth."
    }

    # Get VM info
    $vmInfo = Get-AzVM -Name $JsonInput.ProcessedAlert.SearchResults.Computer `
        -ResourceGroupName $JsonInput.ProcessedAlert.SearchResults.ResourceGroup

    if ($JsonInput.ProcessedAlert.SearchResults.VmAgentStatus -ne "ProvisioningState/succeeded") { # VMAgent not ready
        $JsonInput.ProcessedAlert.SearchQuery = "VMAgent not ready"
        $runAction = "vmagentrestart"
    } else {
        if ($JsonInput.ProcessedAlert.SearchResults.MicrosoftMonitoringAgentExtensionStatus -ne "Provisioning succeeded") { # OMSAgent extension failed
            $JsonInput.ProcessedAlert.SearchQuery = "OMSAgent extension failed status"
            $runAction = "omsextensionreinstall"
        } else {
            if ($JsonInput.ProcessedAlert.SearchResults.RequiredWorkspaceId -ne $JsonInput.ProcessedAlert.SearchResults.ConfiguredWorkspaceId) { # Incorrect workspace
                $JsonInput.ProcessedAlert.SearchQuery = "Incorrect workspace"
                $runAction = "omsagentonboard"
            } else { 
                if ((([int]$JsonInput.ProcessedAlert.SearchResults.HeartbeatVariance -gt 10) -and ($JsonInput.ProcessedAlert.SearchResults.VMUptime -gt 24)) -or ($JsonInput.ProcessedAlert.SearchResults.Heartbeat -eq $false)) { # Heartbeat skipping or missing
                    $JsonInput.ProcessedAlert.SearchQuery = "Heartbeat skipping or missing"
                    $runAction = "omsagentheartbeat"
                } else {
                    $runbookDetails.Output = "No actions required based on data collected for VMAgent, MicrosoftMonitoringAgent and Heartbeat."
                    $selfhealResult = "Not applicable"
                    $selfhealSeverity = "Informational"
                    exit
                }
                
            }
        }
    } 

    $runArgs = [string]::Concat($runAction, "_", $workspaceID, "_", $workspaceKey)
    if ($runAction -eq "omsextensionreinstall") {
        $runCmdOutput = Reinstall-OMS -vmObj $vmInfo `
            -logAnalyticsWorkspaceID $workspaceID `
            -logAnalyticsWorkspaceKey $workspaceKey
    } else {
        $runCmdOutput = Execute-RunCMD -vmObj $vmInfo -logAnalyticsWorkspaceID $workspaceId `
            -logAnalyticsWorkspaceKey $workspaceKey -runCMDId $runCommandId `
            -runCMDScriptPath $downloadPath -runCMDArg $runArgs   
    }

    if ([string]::IsNullOrEmpty($runCmdOutput)) {
        $runbookDetails.Output = "ERROR: Failed to execute run script on virtual machine. Please check manually."
        $selfhealResult = "Failed"
        $selfhealSeverity = "Critical"
        exit
    } else {
        if ($runAction -eq "omsextensionreinstall") {
            $runbookDetails.Output = [PSCustomObject]@{
                OMSEXTENSION_REINSTALLED = $true
                OMSEXTENSION_STATUS = $runCmdOutput
            }
            if ($runCmdOutput -ne "Succeeded") {
                $selfhealResult = "Failed"
                $selfhealSeverity = "Critical"
            } else {
                $selfhealResult = "Successful"
                $selfhealSeverity = "Informational"
            }
        } else {
             # Format output
             if ($runCmdOutput.Contains("[stdout]")) {
                $stdOut=$runCmdOutput.IndexOf("[stdout]")
                $stdErr=$runCmdOutput.IndexOf("[stderr]")
                $stdResults = $runCmdOutput.substring(0,$stdErr).substring($stdOut+8).Trim()
             } else {
                $stdResults = $runCmdOutput.Trim()
             }
            $resultsObj = New-Object PsCustomObject
            foreach ($line in $stdResults -split '\n') {
                if ($($line.split(":")[0])) {                
                    $resultsObj | Add-Member -MemberType NoteProperty -Name $($line.split(":")[0]) -Value $($line.split(":")[-1].Trim())
                }
            }

            # Compute for heartbeat variance
            if ($resultsObj.PsObject.Properties.Name -eq "HEARTBEAT") {
                if ($resultsObj.HEARTBEAT -notin ("NULL", "SENDING", "SKIPPING")) {
                    $heartbeatLogTime = [string]::Concat(($stdResults -split '\n')[-1].REPLACE("HEARTBEAT: ","").split(" ")[2]," ",`
                        ($stdResults -split '\n')[-1].REPLACE("HEARTBEAT: ","").split(" ")[3]) | Get-Date -F "yyyy-MM-dd hh:mm:ss"
                    $currentTime = [string]::Concat(($stdResults -split '\n')[-1].REPLACE("HEARTBEAT: ","").split(" ")[2]," ",`
                        ($stdResults -split '\n')[-1].REPLACE("HEARTBEAT: ","").split(" ")[3]) | Get-Date -F "yyyy-MM-dd hh:mm:ss"
                    if ((New-Timespan –Start $heartbeatLogTime –End $currentTime).TotalMinutes -gt 5) {
                        $resultsObj.HEARTBEAT = "SKIPPING"
                    } else {
                        $resultsObj.HEARTBEAT = "SENDING"
                    }
                }
            }
            # Reinstall OMS if condition is met
            if ($resultsObj.OMSAGENT_UNINSTALLED -eq "true") {
                 $omsExtStatus = Reinstall-OMS -vmObj $vmInfo `
                    -logAnalyticsWorkspaceID $workspaceObj.CustomerId.Guid `
                    -logAnalyticsWorkspaceKey $workspaceKey
                $omsReinstall = $true
            } else {
                $omsReinstall = $false
                $omsExtension = ($vmInfo.Extensions.Id | Select-String "OMSAgent", "OMSAgentForLinux", "MicrosoftMonitoringAgent" | Out-String).Split("/")[-1].Trim()
                $omsExtStatus = (Get-AzVMExtension -ResourceGroupName $vmInfo.ResourceGroupName -VMName $vmInfo.Name -Name $omsExtension).ProvisioningState
            }
            $resultsObj | Add-Member -MemberType NoteProperty -Name OMSEXTENSION_REINSTALLED -Value $omsReinstall
            $resultsObj | Add-Member -MemberType NoteProperty -Name OMSEXTENSION_STATUS -Value $omsExtStatus

            # Summarize results for self-heal
            if (($resultsObj.OMSAGENT -like "*Not Running*") -or `
                ($resultsObj.OMSAGENT -like "*Stop*") -or `
                ($resultsObj.HEARTBEAT -eq "SKIPPING") -or `
                ($resultsObj.HEARTBEAT -eq "NULL") -or `
                ($resultsObj.OMSEXTENSION_STATUS -ne "Succeeded") -or `
                ($resultsObj.OMSAGENT_ONBOARD_STATUS -notcontains "*Onboarded(OMSAgent Running)*") -or `
                ($resultsObj.OMSAGENT_ONBOARD_STATUS -notcontains "*successfully connected*") `
            ) {
                $selfhealResult = "Failed"
                $selfhealSeverity = "Critical"
            } else {
                $selfhealResult = "Successful"
                $selfhealSeverity = "Informational"
            }
            $runbookDetails.Output = $resultsObj
        }
    }
} catch {
    $runbookDetails.Output = $error.Exception.Message
    $runbookDetails.Status = "Failed"
    $selfhealResult = "Failed"
    $selfhealSeverity = "Critical"
} finally {
    # Construct the Self-heal alert payload in JSON
    $JsonInput.SelfhealResult = $selfhealResult
    $JsonInput.SelfhealSeverity = $selfhealSeverity
    [object[]]$JsonInput.SelfhealMessage+=$runbookDetails
    $JsonInput | ConvertTo-Json -Depth 15
}