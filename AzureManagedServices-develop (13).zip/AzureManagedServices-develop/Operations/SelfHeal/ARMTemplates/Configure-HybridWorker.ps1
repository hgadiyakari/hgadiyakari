
# This script installs the required packages, modules and settings required to function as a Hybrid Runbook Worker.
Param ([string]$groupName, [string]$url, [string]$key)

$storageAccountUrl = "https://azurehybridworker.blob.core.windows.net/module/"
$required_files_list = "nuget.zip", "Az.5.4.0.33905-x64.msi", "AzureRm.6.13.1.24243-x64.msi", "Posh-SSH.zip"
$checkList =  New-Object PsCustomObject

# Bypass TLS error
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

# Install required package
$randomGuid = [System.Guid]::NewGuid()
$downloadDir = New-Item -ItemType Directory -Force `
    -Path ([System.IO.Path]::Combine([System.IO.Path]::GetTempPath(),$randomGuid))
foreach ($required_file in $required_files_list) {
    $modulesUrl = [String]::Concat($storageAccountUrl, $($required_file))
    $downloadPath = [System.IO.Path]::Combine($downloadDir,$modulesUrl.Split('/')[-1])
    (New-Object System.Net.WebClient).DownloadFile($modulesUrl, $downloadPath)

    switch ($required_file.Split(".")[-1]) {
        'msi' {
            $timestamp = get-date -Format yyyyMMddTHHmmss
            $logFile = '{0}-{1}.log' -f $required_file.Split(".")[0], $timestamp
            $MSIArguments = @(
                "/i"
                ('"{0}"' -f $downloadPath)
                "/qn"
                "/norestart"
                "/L*v"
                $logFile
            )
            $installer = Start-Process "msiexec.exe" -ArgumentList $MSIArguments -Wait -PassThru
            [int]$ctr=0
            do {
                $checkProcess = Get-Process -Name "msiexec*" 
                Start-Sleep -s 15; $ctr+=1
            } until (($null -eq $checkProcess) -or ($ctr -eq 100))
            if ($installer.ExitCode -eq 0) {
                $isInstalled = $true
            } else {
                $isInstalled = $false
            }
        }
        'zip' {
            switch ($required_file.Split(".")[0]) {
                'nuget' {
                    $destinationPathList = "C:\Program Files\PackageManagement\ProviderAssemblies\"
                    $installerCmd = "Get-PackageProvider -Name $($required_file.Split(".")[0]) -WA 0 -EA 0"
                }
                default {
                    $destinationPathList = $env:PSModulePath.Split(";")
                    $installerCmd = "Get-Module -Name $($required_file.Split(".")[0]) -ListAvailable -EA 0 -WA 0"
                }
            }
            foreach ($destinationPath in $destinationPathList) {
                Expand-Archive -Path $downloadPath -DestinationPath $destinationPath -EA 0 -Force
            }
            $installer = Invoke-Expression -Command $installerCmd -EA 0
            if ($null -ne $installer) {
                $isInstalled = $true
            } else {
                $isInstalled = $false
            }
        }
    }
    $checkList | Add-Member -MemberType NoteProperty `
        -Name $($required_file.Split(".")[0]) -Value $isInstalled
    $error.clear(); $isInstalled = ""
}

# Configure WinRM
Invoke-Command -ScriptBlock { winrm quickconfig -Force; winrm set winrm/config/client '@{TrustedHosts="*"}'} -EA 0 | Out-Null
if ($error) { $isInstalled = $false } else { $isInstalled = $true }
$checkList | Add-Member -MemberType NoteProperty -Name WinRM -Value $isInstalled
$error.clear()

# Register the host as Hybrid Worker
cd "$env:ProgramFiles\Microsoft Monitoring Agent\Agent\AzureAutomation"
if ($error) { # Write-Output "Unable to find Log Analytics installation directory."
    $isInstalled = $false
	$checkList | Add-Member -MemberType NoteProperty -Name RegisterHost -Value $isInstalled
	return $checkList, $error
} else {
    $version = (ls | Sort-Object LastWriteTime -Descending | Select -First 1).Name
    cd "$version\HybridRegistration"
    Import-Module (Resolve-Path('HybridRegistration.psd1')) -EA 0
        if ($error) { # Write-Output "Failed to import HybridRegistration. Perform manual import instead."
            $isInstalled = $false
			$checkList | Add-Member -MemberType NoteProperty -Name RegisterHost -Value $isInstalled
			return $checkList, $error
		}
    Add-HybridRunbookWorker -GroupName $groupName -Url $url -Key $key -EA 0
        if ($error) { # Write-Output "Failed to add $env:COMPUTERNAME. Perform manual registration instead."
            Remove-Item -Path "HKLM:\Software\Microsoft\HybridRunbookWorker" -Recurse -Force -EA 0
			Remove-ItemProperty -Path "HKLM:\Software\Microsoft" -Name "HybridRunbookWorker" -Force -EA 0
            Sleep -S 10        
            $error.clear()
            Add-HybridRunbookWorker -GroupName $groupName -Url $url -Key $key
                if ($error) { $isInstalled = $false } else { $isInstalled = $true }
				$checkList | Add-Member -MemberType NoteProperty -Name RegisterHost -Value $isInstalled
				return $checkList, $error
        } else { # Write-Output "Host $env:COMPUTERNAME is successfully registered as Hybrid Runbook Worker."
            $isInstalled = $true 
			$checkList | Add-Member -MemberType NoteProperty -Name RegisterHost -Value $isInstalled
            $error.clear()
			return $checkList
		}
}