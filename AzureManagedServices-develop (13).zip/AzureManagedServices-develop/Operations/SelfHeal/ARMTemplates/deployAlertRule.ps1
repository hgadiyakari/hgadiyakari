<#
.SYNOPSIS
- Script that deploys Self-heal alert rules (log query + action group), where actions include : 
    - create the self-heal action group (runbook webhook) - DXC-AG-SelfHeal
    - assign the self-heal action group (DXC-AG-SelfHeal) to the backup alert (DXC-Major-Backup-Job Failure)
    - create/deploy the self-heal alerts - DXC-Major-SelfHeal, DXC-Informational-SelfHeal
    - assign the ITSM action groups (DXC-AG-Major, DXC-AG-Informational) to the self-heal alerts (DXC-Major-SelfHeal, DXC-Informational-SelfHeal)   

To report a bug or an issue with Self-heal, log the case here: https://confluence.csc.com/pages/viewpage.action?pageId=162089166        
.PARAMETER
    dxcSubscriptionID
    dxcLogAnalyticsWorkspaceName
    dxcAutomationAccountSH

.REVISION HISTORY
    Creation Date:  
    27-Aug-2019 - Initial script development
    08-dec -2019 - Added switching of action group in DXC-Critical-Backup-Job Failure
    06-May-2020 - supports upgrade
    06-Jul-2020 - AZR-14676: Refactored for PowerShell Core execution and align to alert severity (alert rule ARM template)
    22-Jun-2021 - AZR-23698 to support crowdstrike alerts
#>

#---------------------------------------------------------[Initializations]--------------------------------------------------------
[CmdletBinding()]
Param (
    [Parameter(
        HelpMessage = "Please enter DXC Subscription ID.", Position=1,
        Mandatory = $True,
        ValueFromPipeline = $True)]
    [ValidateNotNullOrEmpty()]
    [string]$dxcSubscriptionID,
    [Parameter(
        HelpMessage = "Please enter DXC Log Analytics Workspace Name.", Position=2,
        Mandatory = $True,
        ValueFromPipeline = $True)]
    [ValidateNotNullOrEmpty()]
    [string]$dxcLogAnalyticsWorkspaceName,
    [Parameter(
        HelpMessage = "Please enter DXC Self-heal AutomationAccount.", Position=3,
        Mandatory = $True,
        ValueFromPipeline = $True)]
    [ValidateNotNullOrEmpty()]
    [string]$dxcAutomationAccountSH
)

#----------------------------------------------------------[Declarations]----------------------------------------------------------
$scriptName = "deployAlertRule"
$scriptPath = (Get-Item -Path .\).FullName
$logFileName = ($scriptName + '-{0:dd-MMM-yyyy_HHmm}' -f (Get-Date) + '.log')
$logFilePath = [System.IO.Path]::GetFullPath("$scriptPath\$logFileName")

$dxcAlertScript = [System.IO.Path]::GetFullPath("$scriptPath\..\..\..\OnBoarding\Alerting\Alerts\deployAlerts.ps1")
$dxcAlertsPath = [System.IO.Path]::GetFullPath("$scriptPath\..\..\..\OnBoarding\Alerting\Alerts\")
$dxcAlerts = @(
    [PSCustomObject]@{ AlertName = "DXC-Major-Backup-Job Failure"; AlertTemplate = "alerts-backup.json" }
    [PSCustomObject]@{ AlertName = "DXC-Critical-Linux-CrowdStrike SVC Stopped"; AlertTemplate = "alerts-crowdstrike.json" }
    [PSCustomObject]@{ AlertName = "DXC-Critical-Windows-SecurityAgent SVC Didnt Start"; AlertTemplate = "alerts-security.json" }
    [PSCustomObject]@{ AlertName = "DXC-Major-Crowdstrike SIEM-ConnectFail"; AlertTemplate = "alerts-dxctools.json" }

)
$dxcAlertRules = New-Object System.Collections.ArrayList

$defaultAlertTemplate = [System.IO.Path]::GetFullPath("$scriptPath\alerts-default.json")
$selfHealAlertRule = [System.IO.Path]::GetFullPath("$scriptPath\alerts-selfheal.json")
$selfhealActionGroup = [System.IO.Path]::GetFullPath("$scriptPath\actiongroup-selfheal.json")
$selfhealActionGroupName = "DXC-AG-SelfHeal"
$selfhealActionGroupShortName = "dxcSelfHeal"

#$dxcResourceGroupName = "dxc-maint-rg"
$webhookName = "process-Alerts"

#-----------------------------------------------------------[Functions]------------------------------------------------------------

#region Supporting functions
function Get-AzCachedAccessToken()
{
    $ErrorActionPreference = 'Stop'
  
    if(-not (Get-Module Az.Accounts)) {
        Import-Module Az.Accounts
    }
    $azProfile = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile
    if(-not $azProfile.Accounts.Count) {
        Write-Error "Ensure you have logged in before calling this function."    
    }
  
    $currentAzureContext = Get-AzContext
    $profileClient = New-Object Microsoft.Azure.Commands.ResourceManager.Common.RMProfileClient($azProfile)
    Write-Debug ("Getting access token for tenant" + $currentAzureContext.Tenant.TenantId)
    $token = $profileClient.AcquireAccessToken($currentAzureContext.Tenant.TenantId)
    $token.AccessToken
}

function Get-AzBearerToken()
{
    $ErrorActionPreference = 'Stop'
    ('Bearer {0}' -f (Get-AzCachedAccessToken))
}

# Verify current connectivity to Azure and if login is required.
function Check-Login {
    [CmdletBinding(SupportsShouldProcess=$true)]
    Param ([string]$dxcSubscriptionId)

    Set-AzContext -Subscription $dxcSubscriptionID -EA 0 -WA 0 >$null
    if ($error) {
        $error.Clear()
        Write-Output "INFO: Please login to Azure Resource Manager." | timestamp | Write-Host -F Cyan
        Connect-AzAccount -Subscription $dxcSubscriptionID -EA 0 -WA 2 | Out-Null
        if ($error) {
            Write-Output "ERROR: Failed to connect to Azure Resource Manager. Check your internet connection and verify authentication details." `
                | timestamp | Write-Host -F Red ; exit
        } else {
            Write-Output "INFO: Connected to Azure with provided authentication." | timestamp | Write-Host -F Yellow
            Write-Host (Get-AzContext | Out-String)
        }
    }
}

# Validate Log Analytics workspace
function Validate-LogAnalyticsWorkspace # Get Log Analytics workspace details, enable AzureAutomation intelligence pack and Microsoft/SMA data source
{
    [CmdletBinding(SupportsShouldProcess=$true)]
    Param ([string]$dxcLogAnalyticsWorkspaceName)
 
    $error.clear()

    $workspaceObj = Get-AzOperationalInsightsWorkspace | ? { $_.Name -eq $dxcLogAnalyticsWorkspaceName }
    if ($workspaceObj -eq $null) {
        Write-Output "ERROR: Loganalytics Workspace not found. Please enter a valid workspace in the subscription." `
            | timestamp | Write-Host -F Red ; break
    } else {
        Write-Output "INFO: Log Analytics workspace found in subscription: " | timestamp | Write-Host -F Yellow -NoNewline
        Write-Host $dxcLogAnalyticsWorkspaceName
        return $workspaceObj
    }
}

# Validate Automation Account
function Validate-AutomationAccount # Get the Automation Account details
{
    [CmdletBinding(SupportsShouldProcess=$true)]
    Param ([string]$dxcAutomationAccountSH)
     
    $error.clear()

    $automationAccountObj = Get-AzAutomationAccount | ? { ($_.AutomationAccountName -eq $dxcAutomationAccountSH) -and ($_.Tags.Values -eq "selfheal") }
    if ($automationAccountObj -eq $null) {
        Write-Output "ERROR: Automation Account not found. Please enter the Automation Account used for Self-heal in the subscription." `
            | timestamp | Write-Host -F Red ; break
    } else {
        Write-Output "INFO: Self-heal Automation Account found in subscription: " | timestamp | Write-Host -F Yellow -NoNewline
        Write-Host $dxcAutomationAccountSH
        return $automationAccountObj
    }
}
#endregion

function Create-Webhook {
    [CmdletBinding(SupportsShouldProcess=$true)]
    Param ([string]$dxcSubscriptionID, [string]$dxcResourceGroupName, [string]$dxcAutomationAccountSH, [string]$webhookName)
    
    $error.clear()
    
    Write-Output "INFO: Start creation of Self-heal automation webhook." | timestamp | Write-Host
    $armToken = Get-AzBearerToken
    $requestHeaders = @{'Authorization'=$armToken ;'Accept'='application/json'; 'Content-Type'='application/json'}

    # Generate a webhook URI
    $createWebhookUriRequestUri = "https://management.azure.com/subscriptions/$dxcSubscriptionID/resourceGroups/$dxcResourceGroupName/providers/Microsoft.Automation/automationAccounts/$dxcAutomationAccountSH/webhooks/generateUri?api-version=2015-10-31"
    $createWebhookUriResponse = Invoke-WebRequest -UseBasicParsing -Uri $createWebhookUriRequestUri `
        -Method POST -Headers $requestHeaders -EA 0 -WA 0 -Verbose
    if ($error) { 
        Write-Output "ERROR: Failed to create a webhook Uri." | timestamp | Write-Host -F Red ; break
    } else {
        $webhookUri = $createWebhookUriResponse.Content.Trim('"')
    }

    # Create the automation runbook webhook
    $webhookExpiryDate = ([Datetime]::UtcNow).AddYears(5)
    $webhookRequestUri = "https://management.azure.com/subscriptions/$dxcSubscriptionID/resourceGroups/$dxcResourceGroupName/providers/Microsoft.Automation/automationAccounts/$dxcAutomationAccountSH/webhooks/$webhookName`?api-version=2015-10-31"
    $webhookRequestBody = @{
        name = $webhookName
        properties = @{
            isEnabled = $true
            Uri = $webhookUri
            expiryTime = $webhookExpiryDate
            runbook = @{
                name = $webhookName
            }
            runOn = ""
        }
    }
    $webhookRequestJson = $webhookRequestBody | ConvertTo-Json
    try {
        $webhookResponse = Invoke-WebRequest -Uri $webhookRequestUri -UseBasicParsing `
            -Method PUT -Headers $requestHeaders -Body $webhookRequestJson -EA 0 -WA 0 -Verbose
        if (($webhookResponse.StatusCode -ge 200) -and ($webhookResponse.StatusCode -le 299)) {
            Write-Output "INFO: Automation Webhook creation successful - " | timestamp | Write-Host -F Green -NoNewline ; Write-Host "$webhookUri.`n"
            return $webhookUri
        } else {
            throw
        }    
    } catch {
        Write-Output "ERROR: Automation Webhook creation failed. " | timestamp | Write-Host -F Red  -NoNewline 
        Write-Host -F Red "Please check if a webhook of the same name `"$($webhookName.ToUpper())`" already exists and attached to the runbook.`n" 
        break
    }
}

function Deploy-ActionGroup {
    [CmdletBinding(SupportsShouldProcess=$true)]
    Param ([string]$dxcResourceGroupName, [string]$selfhealWebhookUri)

    $error.clear()

    Write-Output "INFO: Start deployment of Self-heal action group." | timestamp
    New-AzResourceGroupDeployment -Name $($selfhealActionGroup.Split("\").Split(".")[-2]) -ResourceGroupName $dxcResourceGroupName `
        -TemplateFile $selfhealActionGroup -actionGroupName $selfhealActionGroupName -actionGroupShortName $selfhealActionGroupShortName `
        -serviceUri $selfhealWebhookUri -EA 0 -WA 0 -Verbose
        if ($error) {
            Write-Output "ERROR: Action group deployment failed. Please check deployment error from Azure Portal. $error`n" | timestamp | Write-Host -F Red
        } else {
            Write-Output "INFO: Action Group deployment successful.`n" | timestamp | Write-Host -F Green
        }
}

function Deploy-AlertRule {
    [CmdletBinding(SupportsShouldProcess=$true)]
    Param ([string]$dxcSubscriptionID, [object]$dxcLogAnalyticsObject, [string]$dxcTemplateFile)

    $error.clear()

    # Get alert version and event processing schema from deployAlerts.ps1
    $dxcAlertVersion = (Select-String "dxcAlertVersion" $dxcAlertScript | select line)[0].Line.Split("`"")[1]
    $dxcEventProcessingSchema = (Select-String "dxcEventProcessingSchema" $dxcAlertScript | select line)[0].Line.Split("`"")[1]
   
    # Deploy the alert template
    try {
        New-AzResourceGroupDeployment -Name $($dxcTemplateFile.Split("\").Split(".")[-2]) `
            -ResourceGroupName $($dxcLogAnalyticsObject.ResourceGroupName) `
            -TemplateFile $dxcTemplateFile -omsWorkspaceName $($dxcLogAnalyticsObject.Name) `
            -omsWorkspaceLocation $($dxcLogAnalyticsObject.Location) `
            -eventProcessingSchema $($dxcEventProcessingSchema) `
            -alertVersion $($dxcAlertVersion) -EA 0 -WA 0 -Verbose
        Write-Output "INFO: Alert deployment successful." | timestamp | Write-Host -F Green
    } catch {
        Write-Output "ERROR: Alert deployment failed. Please check deployment error from Azure Portal. $error`n" | timestamp | Write-Host -F Red
    }

}
#-----------------------------------------------------------[Execution]------------------------------------------------------------

try {
    
    $error.clear() ; $start = Get-Date
    
    # Capture the time information for logging purposes.
    filter timestamp {"$(Get-Date -Format MM-dd-yyyy-hh:mm:ss): $_"}
    
    # Create the log file.
    New-Item $logFilePath -ItemType File -Force | Out-Null   
    Start-Transcript -Path $logFilePath -Append -EA 0 | Out-Null
    Write-Output "INFO: Script execution started." | timestamp | Write-Host -F Yellow

    # Login to Azure
    Check-Login -dxcSubscriptionId $dxcSubscriptionID

    # Run subscription check
    $logAnalyticsWorkspaceObj = Validate-LogAnalyticsWorkspace -dxcLogAnalyticsWorkspaceName $dxcLogAnalyticsWorkspaceName
    $automationAccountObj = Validate-AutomationAccount -dxcAutomationAccountSH $dxcAutomationAccountSH
    
    # Condition statement for action group creation.
    $ifActionGroupExists = Get-AzActionGroup -ResourceGroupName $($logAnalyticsWorkspaceObj.ResourceGroupName) -Name $selfhealActionGroupName -EA 0 -WA 0
    $ifWebhookExists = Get-AzAutomationWebhook -ResourceGroupName $($automationAccountObj.ResourceGroupName) -AutomationAccountName $dxcAutomationAccountSH -Name $webhookName -EA 0 -WA 0 -Verbose

    if (($ifActionGroupExists) -and ($ifWebhookExists)) { 
        Write-Output "INFO: Self-heal Action group (webhook) already exists - " | timestamp | Write-Host -F Yellow -NoNewline
        Write-Host ($ifActionGroupExists | Out-String) -NoNewline
    } else {
        if ($ifWebhookExists) {
            Remove-AzAutomationWebhook -ResourceGroupName $($automationAccountObj.ResourceGroupName) `
                -AutomationAccountName $dxcAutomationAccountSH -Name $webhookName -EA 0 -WA 0 | Out-Null
        }
        # Generate and create the webhook
        $selfhealWebhookUri = Create-Webhook -dxcSubscriptionID $dxcSubscriptionID -dxcResourceGroupName $($automationAccountObj.ResourceGroupName) `
            -dxcAutomationAccountSH $dxcAutomationAccountSH -webhookName $webhookName -EA 0 -WA 0
        # Create the action group
        Deploy-ActionGroup -dxcResourceGroupName $($logAnalyticsWorkspaceObj.ResourceGroupName) -selfhealWebhookUri $($selfhealWebhookUri)
    } 
    if ($logAnalyticsWorkspaceObj) { 
        # Update the alerts-default.json template with default alert rules
        foreach ($dxcAlert in $dxcAlerts) {
            $alertPath = [System.IO.Path]::Combine($dxcAlertsPath, $($dxcAlert.AlertTemplate))
            $alertContent = Get-Content -Path $alertPath | ConvertFrom-Json
            foreach ($alertItem in $alertContent.variables.alertArray) {
                if ($alertItem.alertName -eq $dxcAlert.AlertName) {
                    if ($alertItem.alertName -eq "DXC-Major-Crowdstrike SIEM-ConnectFail") {
                        $alertItem.query = "Crowdstrike_SIEM_SVC_CL | where TimeGenerated between (ago(60m) .. ago(30m)) | where RawData contains 'Received Heartbeat' and _ResourceId !in ((Crowdstrike_SIEM_SVC_CL | where TimeGenerated > ago(28m) | where RawData contains 'Received Heartbeat' | summarize AggregatedValue = count() by _ResourceId)) and _ResourceId in ((Heartbeat | where  TimeGenerated > ago(20m) | summarize AggregatedValue = count() by _ResourceId))"
                    }
                    $alertItem.actionGroupName = $selfhealActionGroupName
                    $dxcAlertRules+=$alertItem
                }
            }
        }
        $defaultAlerts = Get-Content -Path $defaultAlertTemplate | ConvertFrom-Json
        [object[]]$defaultAlerts.variables.alertArray=$dxcAlertRules
        $defaultAlerts | ConvertTo-Json -Depth 25 | % { [System.Text.RegularExpressions.Regex]::Unescape($_) } `
            | Out-File -FilePath $defaultAlertTemplate -Force -EA 0
        
            # Deploy default alerts with self-heal action group
        Write-Output "INFO: Start redeploying default alerts with Self-heal action group ($selfhealActionGroupName)." | timestamp | Write-Host
        Deploy-AlertRule -dxcSubscriptionID $dxcSubscriptionID -dxcLogAnalyticsObject $logAnalyticsWorkspaceObj `
            -dxcTemplateFile $defaultAlertTemplate -EA 0 -WA 0

        # Deploy custom alerts for self-heal
        Write-Output "INFO: Start deployment of Self-heal alert rules." | timestamp | Write-Host
        Deploy-AlertRule -dxcSubscriptionID $dxcSubscriptionID -dxcLogAnalyticsObject $logAnalyticsWorkspaceObj `
            -dxcTemplateFile $selfHealAlertRule -EA 0 -WA 0

        # Verify, summarize the deployed alerts
        $deployedAlerts = Get-AzScheduledQueryRule -ResourceGroupName dxc-maint-rg -WA 0 `
            | ? { ($_.Name -in $dxcAlerts.AlertName) -or ($_.Tags.Values -eq "selfheal") }
        foreach ($deployedAlert in $deployedAlerts) {
            $deployedAlert | Add-Member -MemberType NoteProperty -Name ActionGroup `
                -Value $deployedAlert.Action.AznsAction.ActionGroup.Split("/")[-1]
        }
        $deployedAlerts | Select Name, ActionGroup, Description | ft -AutoSize
    }
    Write-Output "INFO: Self-heal alert and action group deployment successful." | timestamp | Write-Host -F Green
} 
catch {
    Write-Output "ERROR: Self-heal alert and action group deployment failed. Error details - $error" | timestamp | Write-Host -F Red
} 
finally {
    Write-Output "INFO: Script execution finished. Refer to log - $logFilePath" | timestamp | Write-Host -F Yellow
    Stop-Transcript -EA 0 | Out-Null ;  $end = Get-Date
    Write-Host -F DarkGray "Script duration (mins):" ([math]::Round(($end - $start).TotalMinutes,2))
    Remove-Variable * -Force -EA 0 ; $error.Clear()
}