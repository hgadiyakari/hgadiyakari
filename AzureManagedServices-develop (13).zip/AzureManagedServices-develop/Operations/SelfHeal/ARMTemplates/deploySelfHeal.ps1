<#
#Requires -PSEdition Core
#Requires -Version 7.0
#Requires -Module @{ ModuleName = 'Az.KeyVault'           ; ModuleVersion = "3.3.1" }


-----------------------------------------------------------------------------------------------------------------------------------
.SYNOPSIS
    This script will perform the following items :
      - Deploy Automation Account for SelfHeal
      - Import Az modules in the Automation Account
      - Upload the runbooks to be used for Selfheal workflow
      - Deploy Logic app component for SelfHeal
      - Deploy SelfHeal_CL (CustomLog) in dxcLogAnalyticsWorkspaceName
    To report a bug or an issue with Self-heal, log the case here: https://confluence.csc.com/pages/viewpage.action?pageId=162089166 

.PARAMETER
    deploySelfheal
       -dxcSubscriptionID
       -dxcLogAnalyticsWorkspaceName
       -dxcKeyVaultName
       -dxcCustomerCompanyCode (optional)

-----------------------------------------------------------------------------------------------------------------------------------
#>

#---------------------------------------------------------[Initializations]--------------------------------------------------------
[CmdletBinding()]
Param(
    [Parameter(
        HelpMessage = "Please enter DXC Subscription ID.", Position=1,
        Mandatory = $True,
        ValueFromPipeline = $True)]
    [ValidateNotNullOrEmpty()]
    [String]$dxcSubscriptionId,
    [Parameter(
        HelpMessage = "Please enter DXC Log Analytics Workspace Name.", Position=2,
        Mandatory = $True,
        ValueFromPipeline = $True)]
    [ValidateNotNullOrEmpty()]
    [String]$dxcLogAnalyticsWorkspaceName,
    [Parameter(
        HelpMessage = "Please enter DXC KeyVault Name.", Position=3,
        Mandatory = $True,
        ValueFromPipeline = $True)]
    [ValidateNotNullOrEmpty()]
    [String]$dxcKeyVaultName,
    [Parameter(
        HelpMessage = "Please enter DXC Customer Company Code.", Position=4,
        Mandatory = $False,
        ValueFromPipeline = $True)]
    [ValidateLength(1,6)]
    [ValidatePattern('^[a-zA-Z0-9]+$')]
    [String]$dxcCustomerCompanyCode
)
#----------------------------------------------------------[Declarations]----------------------------------------------------------

$Global:AutomationAccountName=""
$Global:LogicAppName=""

$selfheal_modules = "SelfHeal.psm1"
$logType = "SelfHeal_CL"
$dxcResourceGroupName = "DXC-Maint-RG"
$HybridGrpName = "selfheal-group"

$selfHealTags=@{
 service="selfheal"
 dxcManaged=$true
 dxcMonitored=$true
 dxcAdditionalSupport="cloudopsautomationteam@dxc.com"
 dxcResourceRole="Selfheal"
 dxcConfigurationCheck=[DateTime]::UtcNow.ToString('yyyyMMddTHHmmssZ')
}

[int]$SelfSignedCertNoOfMonthsUntilExpired = 12
$JSONtemplates=@("automationaccount-selfheal.json","logicapps-selfheal.json")

$curworkingdir = (Get-Location).Path
$logFilePath = (Get-Item -Path .\ -Verbose).Fullname + '\' + "deploySelfheal" + '-{0:dd-MMM-yyyy_HHmm}' -f (Get-Date) + '.log'
$SHmodulepath = [System.IO.Path]::GetFullPath("$curworkingdir\PowershellModules\$selfheal_modules")

$RunbookList=@('process-Alerts', `
               'validate-ErrorforSelfHeal', `
               'buaas-triggerBackup', `
               'send-DatatoCL', `
               'buaas-fixWindowsAgent', `
               'buaas-fixVssWriterInBadState', `
               'buaas-fixExtensionSnapshotFailedCOM', `
               'buaas-fixBackupOperationInProgress', `
               'buaas-fixLinuxAgent', `
               'crowdstrike-selfheal', `
               'agenthealth-selfheal'
               )

$localazModules=@('Az.Accounts', `
                  'Az.KeyVault', `
                  'Az.Resources', `
                  'Az.Automation', `
                  'Az.OperationalInsights'
)

#-----------------------------------------------------------[Functions]------------------------------------------------------------

function Check-Login {
   [CmdletBinding(SupportsShouldProcess=$true)]
   Param ([string]$dxcSubscriptionID)

   Set-AzContext -Subscription $dxcSubscriptionID -EA 0 -WA 0 >$null
   if ($error) {
      $error.Clear()
      Write-Output "INFO: Please login to Azure Resource Manager." | timestamp | Write-Host -F Cyan
      Connect-AzAccount -Subscription $dxcSubscriptionID -EA 0 -WA 2 | Out-Null
      if ($error) {
         Write-Output "ERROR: Failed to connect to Azure Resource Manager. Check your internet connection and verify authentication details." `
            | timestamp | Write-Host -F Red ; exit
      }else{
         Write-Output "INFO: Connected to Azure with provided authentication." | timestamp | Write-Host -F Yellow
         Write-Host (Get-AzContext | Out-String)
      }
    }
}

function Publish-AutomationAccount{
   [CmdletBinding(SupportsShouldProcess=$true)]
   param ([String]$dxcSubscriptionID,
          [String]$dxcResourceGroupName,
          [HashTable]$WorkspaceHashTable,
          [String]$curWorkingDir,
          [String[]]$JSONtemplates,
          [HashTable]$KeyVaultHashtable
         )

   $diagnosticName = "diagSelfHeal"

   Try{

      #Delete all runbooks before deployment to get the latest one
      $GetRunbooks=Get-AzAutomationRunbook -AutomationAccountName $AutomationAccountName -ResourceGroupName $dxcResourceGroupName -ErrorAction SilentlyContinue
      if($GetRunbooks -ne $null){
          foreach($runbookName in $Runbooklist){
             if ($GetRunbooks.Name -eq $runbookName){
                Remove-AzAutomationRunbook -AutomationAccountName $AutomationAccountName -ResourceGroupName $dxcResourceGroupName -Name $runbookName -Force
             }
          }
      }
      Sleep 2

      $Error.Clear()
      $rgLocation=Select-ResourceLocation $dxcSubscriptionID $dxcResourceGroupName 'automationaccount'
      $jsonfile = Join-Path -Path $curWorkingDir -ChildPath $JSONtemplates[0]

      $thisdeploymentname = ($jsonfile.split('\') | select -Last 1).split('.') | select -First 1
      New-AzResourceGroupDeployment -Name $thisdeploymentname `
                 -TemplateFile $jsonfile `
                 -ResourceGroupName $dxcResourceGroupName `
                 -automationaccountName $AutomationAccountName `
                 -automationAccountLocation $rgLocation `
                 -workspaceRG $($WorkspaceHashTable.ResourceGroupName) `
                 -workspaceName $($WorkspaceHashTable.Name) `
                 -workspaceLocation $($WorkspaceHashTable.WorkspaceLocation) `
                 -diagsettingName $diagnosticName `
                 -keyVaultName $($KeyVaultHashtable.dxcKeyVaultName) `
                 -logicAppName $LogicAppName `
                 -EA SilentlyContinue
 

   }Catch{
      
      Write-Output ("ERROR: Script executed with errors in Publish-AutomationAccount. $($_.Exception.Message)") | timestamp | Write-host -F Red ; throw
   }
}

function Publish-SHLogicApp{
   [CmdletBinding(SupportsShouldProcess=$true)]
   param([String]$dxcSubscriptionID,
         [String]$dxcResourceGroupName,
         [String]$LogicAppLocation,
         [String]$HybridGrpName,
         [String]$curWorkingDir,
         [String[]]$JSONtemplates,
         [HashTable]$WorkspaceHashTable,
         $RunAsConnection,
         [String]$PlainPasswordForSecret
        )

   Try{
      $Error.clear()
      $diagnosticName = "diagnostics-logicApp"

      #--- Deploying the logic app ---#
      Write-Output "INFO: Deploying SelfHeal LogicApp using ARM template ..." | timestamp | Write-host -F White
      $jsonfile = Join-Path -Path $curWorkingDir -ChildPath $JSONtemplates[1]
      $thisdeploymentname = ($jsonfile.split('\') | select -Last 1).split('.') | select -First 1
      
      $secretpasswd = ConvertTo-SecureString $PlainPasswordForSecret -AsPlainText -Force

      New-AzResourceGroupDeployment -Name $thisdeploymentname `
            -TemplateFile $jsonfile `
            -ResourceGroupName $dxcResourceGroupName `
            -logicAppName $LogicAppName `
            -logicapplocation $LogicAppLocation `
            -HybridGrpName $HybridGrpName `
            -automationaccountRG $dxcResourceGroupName `
            -automationaccountName $AutomationAccountName `
            -diagnosticSettings_name $diagnosticName `
            -workspaceRG $($WorkspaceHashTable.ResourceGroupName) `
            -workspaceName $($WorkspaceHashTable.Name) `
            -workspaceLocation $($WorkspaceHashTable.WorkspaceLocation) `
            -tenantId $(($RunAsConnection.FieldDefinitionValues).TenantId) `
            -clientId $(($RunAsConnection.FieldDefinitionValues).ApplicationId) `
            -clientSecret $($secretpasswd) `
            -EA SilentlyContinue
   

      #--- Setting the Logic App Management Solution in LogAnalytics ---#
      Write-Output ("INFO: Setting LogicappsManagement Solution..." ) | timestamp | Write-host -F White
      Set-AzOperationalInsightsIntelligencePack -ResourceGroupName $($WorkspaceHashTable.ResourceGroupName) -WorkspaceName $($WorkspaceHashTable.Name) -IntelligencePackName LogicAppsManagement -Enabled $True -ErrorAction SilentlyContinue


   } catch {
      Write-Output ("ERROR: Script executed with errors in Publish-SHLogicApp.$($_.Exception.Message)") | timestamp | Write-host -F Red ; throw
   }
}

function Publish-CustomLog {
   [CmdletBinding(SupportsShouldProcess=$true)]
   param([hashtable]$workspaceHashtable,[String]$logType,[String]$dxcLogAnalyticsWorkspaceName)

   # Preset properties for the custom log.
$json = @"
[{
"SelfhealResult": "",
"SelfhealSeverity": "",
"SelfhealMessage": "",
"SubscriptionId": "",
"ResourceId": "",
"Resource": "",
"ProcessedAlert": ""
}]
"@

# Submit the data to the API endpoint.
$Error.clear()
$results = Post-LogAnalyticsData -customerId $($workspaceHashtable.wsCustomerId) -sharedKey $($workspaceHashtable.workspaceKey) -body ([System.Text.Encoding]::UTF8.GetBytes($json)) -logType $logType
    if (($error) -or ($results -ne 200)) { Write-Output "ERROR: Unable to find the Log Analytics workspace Id and/or key. Please check manually." | timestamp | Write-Host -F Red ; throw
    } else { Write-Output "INFO: SelfHeal_CL custom log in $dxcLogAnalyticsWorkspaceName was deployed successfully." | timestamp | Write-Host -F Green }
}

function Initialize-Checks{
   [CmdletBinding(SupportsShouldProcess=$true)]
   param([String]$curworkingdir,[String[]]$JSONtemplates,[String]$dxcSubscriptionID,[String]$dxcLogAnalyticsWorkspaceName,[String]$dxcResourceGroupName,[String]$dxcCustomerCompanyCode,[HashTable]$selfHealTags)

  Try{
     # validating automationaccount and logicapp resources # 
     Write-Output ("INFO: Searching for resources with selfheal tag...") | timestamp | Write-host -F White
     $selfhealres=Get-AzResource -ResourceGroupName $dxcResourceGroupName -TagValue $selfHealTags.service

     $aaFound = $selfhealres | where {$_.ResourceType -eq 'Microsoft.Automation/automationAccounts'}
     $laFound = $selfhealres | where {$_.ResourceType -eq 'Microsoft.Logic/workflows'}

     $ratiores=-join(($aaFound |Measure-Object).Count,'-',($laFound |Measure-Object).Count)

     $partialid = $dxcSubscriptionID.Substring(0,4)
        if($dxcCustomerCompanyCode){
           $CompanyCode=$dxcCustomerCompanyCode.ToUpper()
           $tmpAA = "DXC-$CompanyCode-$partialid-AutomationAccount-SH"
           $tmpLA = "DXC-$CompanyCode-$partialid-LA-SelfHeal"
        }else{
           $tmpAA = "DXC-$partialid-AutomationAccount-SH"
           $tmpLA = "DXC-$partialid-LA-SelfHeal"
        }

     # compare the resource name from the captured selfheal tag #
     $diffres =  New-Object PsCustomObject -Property ([ordered] @{
        AAName=""
        LAName=""
     })


     Switch ($ratiores){
       '1-1' { if($aaFound.Name -eq $tmpAA){$Global:AutomationAccountName = $aaFound.Name
               }else{$diffres.AAName=$aaFound.Name}

               if($laFound.Name -eq $tmpLA){$Global:LogicAppName= $laFound.Name
               }else{$diffres.LAName=$laFound.Name}

               if(($diffres.AAName -eq "") -or ($diffres.LAName -eq "")){
                  Write-Output ("INFO: Validated AutomationAccountName and LogicAppName provided.") | timestamp | Write-host -F White
               }else{
                  Write-Output ("ERROR: Please remove the selfheal resources deployed in this resourcegroup: $($dxcResourceGroupName) before running deployselfheal.") | timestamp | Write-host -F Red
                  throw
               }
             }
       '0-1' { #create the automationaccount
               $Global:AutomationAccountName=$tmpAA

               if($laFound.Name -eq $tmpLA){$Global:LogicAppName= $laFound.Name
               }else{$diffres.LAName=$laFound.Name
                  Write-Output ("ERROR: Please remove $($diffres.LAName) before running deployselfheal.")  | timestamp | Write-host -F Red
                  throw
               }
               break
             }
       '1-0' { $Global:LogicAppName=$tmpLA

               if($aaFound.Name -eq $tmpAA){$Global:AutomationAccountName= $aaFound.Name
               }else{$diffres.AAName=$aaFound.Name
                  Write-Output ("ERROR: Please remove $($diffres.AAName) before running deployselfheal.")  | timestamp | Write-host -F Red
                  throw
               }
               break
             }
       '0-0' { $Global:AutomationAccountName=$tmpAA
               $Global:LogicAppName=$tmpLA
               break 
             }
        default { Write-Output ("ERROR: Multiple AutomationAccount and LogicApp resources for SelfHeal found in subscription. Please remove selfheal components before running deployselfheal.")  | timestamp | Write-host -F Red 
                  throw
                 }
      }#switch

      # validating workspace resource and JSON templates #
      $workspaceHashtable = Validate-Checks $curworkingdir $JSONtemplates $dxcLogAnalyticsWorkspaceName -EA Stop

      return $workspaceHashtable, $ratiores
  
  }catch{
     Write-Output ("ERROR: Script executed with errors in Initialize-Checks function. $($_.Exception.Message)" ) | timestamp | Write-host -F Red ; throw
  }

}

#-----------------------------------------------------------[Execution]------------------------------------------------------------

Try{
   $Error.Clear()
   $start = Get-Date

   # Capture the time information for logging purposes.
   filter timestamp {"$(Get-Date -Format MM-dd-yyyy-hh:mm:ss): $_"}

   # Create the log file.
   New-Item $logFilePath -ItemType File -Force | Out-Null   
   Start-Transcript -Path $logFilePath -Append -EA 0 | Out-Null
   Write-Output "INFO: Script execution started." | timestamp | Write-Host -F Yellow

#################################################################################################
### STEP 1 - PRE-requisites
#################################################################################################

   ### ----- Running as Administrator ----- ###
    $PwshCurrent = Get-ItemProperty HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\* |
       Where-Object { $_.DisplayName -match "PowerShell [0-9]-x" } |
       Select-Object DisplayName, DisplayVersion

   if(([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator) -eq $True){
       if(($PSVersionTable.PSEdition -eq 'Core') -and ($PWshCurrent.DisplayName -match 'Powershell 7')){
          Write-Output ("INFO: Window is running on Powershell Core version $($PwshCurrent.DisplayName) with RunAsAdmin privilege.") | timestamp | Write-host -F Green
       }else{
          Write-Output ("ERROR: Window is NOT running on Powershell Core 7.") | timestamp | Write-host -F Red ; throw
       }
    }else{
       Write-Output ("ERROR: Window is NOT running as Administrator. Please open a new powershell console with RunAsAdmin permission.") | timestamp | Write-host -F Red ; throw
    }

    ### ----- Connecting to Azure ----- ###
    Check-Login -dxcSubscriptionId $dxcSubscriptionID -EA Stop


    ### ----- Check Required Modules locally ----- ###
    $missmod=@()
    foreach($azmod in $localazModules){
       $aztmp = Get-InstalledModule -Name $azmod -Allversions | Select Name, Version
       if($aztmp){
          if($aztmp.Name -eq "Az.Keyvault"){
              if($aztmp.Version -lt 3.3.1){
                 Write-Output ("ERROR: Az.Keyvault version is $($aztmp.Version). It should have => 3.3.1.") | timestamp | Write-host -F Red ; throw
              }
          }
       }else{
          $missmod.Add($azmod)
       }
    }

     if($missmod.Count -ne 0){
        $tmp= -join($missmod,",")
        Write-Output ("ERROR: Install the missing Az modules ($tmp) locally.") | timestamp | Write-host -F Red ; throw
     }
    
    ### ----- Importing SelfHeal Modules ----- ###
    Import-Module $SHmodulepath -DisableNameChecking -EA Stop
    Write-Output ("INFO: Powershell modules for Selfheal imported successfully.") | timestamp | Write-host -F Green
    

    ### ----- Register Microsoft.Web ----- ###
    $webreg = Get-AzResourceProvider -ProviderNamespace Microsoft.Web
    if($webreg.RegistrationState -ne "Registered"){ Register-AzResourceProvider -ProviderNamespace Microsoft.Web}


#################################################################################################
#  STEP 2 - Initialize-Checks
#################################################################################################

    #---- Getting the allowed location for the logic app ----#
    $logicAppLocation = Select-ResourceLocation $dxcSubscriptionID $dxcResourceGroupName 'logicapp' -EA Stop

    #---- Validate if Selfheal is already installed ----#
    $workspaceHashtable, $ratiores=Initialize-Checks $curworkingdir $JSONtemplates $dxcSubscriptionID $dxcLogAnalyticsWorkspaceName $dxcResourceGroupName $dxcCustomerCompanyCode $selfHealTags
    
    #---- Validate keyvault ----#
    $KeyVaultHashtable=@{}
    $KeyVaultHashtable=Find-KeyVault $dxcKeyVaultName $dxcResourceGroupName $dxcSubscriptionID $SelfSignedCertNoOfMonthsUntilExpired -EA Stop
    Write-Output (" ")          
    Write-Output ("##################################################################################") | Write-host -F White
    Write-Output ("#                       SUMMARY OF INPUT VALUES                                  #") | Write-host -F White
    Write-Output ("##################################################################################") | Write-host -F White

    Write-Output ("dxcResourceGroupName = $dxcResourceGroupName") | Write-host -F White
    Write-Output ("AutomationAccountName = $AutomationAccountName") | Write-host -F White
    Write-Output ("LogicAppName = $LogicAppName") | Write-host -F White
    Write-Output ("dxcKeyVaultName = $($KeyVaultHashtable.dxcKeyVaultName)") | Write-host -F White
    Write-Output ("dxcKeyVaultRG = $($KeyVaultHashtable.dxcKeyVaultRG)" )| Write-host -F White
    Write-Output ("##################################################################################") | Write-host -F White
    Write-Output (" ")

#################################################################################################
#  STEP 3 - Publish Automation Account
#################################################################################################
   Switch ($ratiores) {
      '1-1' { Write-Output ("INFO: Updating AutomationAccount, Az Modules and Runbooks using ARM template.") | timestamp | Write-host -F White
              break}
      '1-0' { Write-Output ("INFO: Updating AutomationAccount, Az Modules and Runbooks using ARM template.") | timestamp | Write-host -F White
              break}
      default { Write-Output ("INFO: Creating AutomationAccount, Importing Az Modules and Uploading Runbooks using ARM template.") | timestamp | Write-host -F White
                break}
   }     
    
    Write-Output ("INFO: Azure Module Updates may take a while (usually 10-15mins)...") | timestamp | Write-host -F White
    Publish-AutomationAccount $dxcSubscriptionID $dxcResourceGroupName $WorkspaceHashTable $curWorkingDir $JSONtemplates $KeyVaultHashtable -EA Stop -Verbose
    Start-Sleep -Seconds 10

    #---- validate if runasaccount is present ----#
    $partialid = $dxcSubscriptionID.Substring(0,4)
    $clientsecretname = $partialId + "clientsecretpswd"
    $AutomationAccountObj=Get-AzAutomationAccount -Name $AutomationAccountName -ResourceGroupName $dxcResourceGroupName
    if($AutomationAccountObj){
       $RunAsConnection = $AutomationAccountObj | Get-AzAutomationConnection -Name 'AzureRunAsConnection' -ErrorAction SilentlyContinue
       if($RunAsConnection){
          New-SecretInServicePrincipal $KeyVaultHashtable $RunAsConnection $clientsecretname -EA Stop -Verbose
       }else{
          New-RunsAsAccount $KeyVaultHashtable $AutomationAccountName $dxcResourceGroupName $dxcSubscriptionID -EA Stop -Verbose
          Sleep 5
          $RunAsConnection = $AutomationAccountObj | Get-AzAutomationConnection -Name 'AzureRunAsConnection' -ErrorAction SilentlyContinue
          New-SecretInServicePrincipal $KeyVaultHashtable $RunAsConnection $clientsecretname -EA Stop -Verbose      
       }
    }

    # append service principal to vault #
    $error.clear()
    Write-Output ("INFO: Setting Service Principal Access to KeyVault.") | timestamp | Write-host -F White
    $appobjId=(Get-AzADApplication -ApplicationId $(($RunAsConnection.FieldDefinitionValues).ApplicationId)).ObjectID
    $spobjId=(Get-AzADApplication -ObjectId $appobjId | Get-AzADServicePrincipal).Id
    Set-AzKeyVaultAccessPolicy -VaultName $KeyVaultHashtable.dxcKeyVaultName -ObjectId $spobjId -PermissionsToSecrets Get,Set
    if($error){
       Write-Output ("ERROR: Setting Service Principal Access to KeyVault. Failed.") | timestamp | Write-host -F Red ; throw
    }     

#################################################################################################
#  STEP 4 - Publish LogicApp
#################################################################################################
    $secretvalue = Get-AzKeyVaultSecret -VaultName $KeyVaultHashtable.dxcKeyVaultName -Name $clientsecretname
    $PlainPasswordForSecret = ([System.Net.NetworkCredential]::new("", $secretvalue.SecretValue).Password)

    Switch ($ratiores) {
      '1-1' { Write-Output ("INFO: Updating LogicApp resource using ARM template.") | timestamp | Write-host -F White
              break}
      '0-1' { Write-Output ("INFO: Updating LogicApp resource using ARM template.") | timestamp | Write-host -F White
              break}
      default { Write-Output ("INFO: Creating LogicApp resource using ARM template.") | timestamp | Write-host -F White
                break}
    }

    Start-Sleep -s 60       
    Publish-SHLogicApp $dxcSubscriptionID $dxcResourceGroupName $LogicAppLocation $HybridGrpName $curWorkingDir $JSONtemplates $workspaceHashtable $RunAsConnection $PlainPasswordForSecret -EA Stop -Verbose

   # Assign permissions to Logic App
   $error.clear()
   Write-Output "INFO: Assigning permissions for AgentHealth Function App to Self-heal." | timestamp | Write-host
   $selfhealLogicApp = Get-AzResource -ResourceType Microsoft.Logic/workflows -ResourceGroupName $dxcResourceGroupName -TagName 'service' -TagValue 'selfheal' -EA 0
   $agentHealthFA = Get-AzFunctionApp -ResourceGroupName 'dxc-automation-rg' | ? { $_.Name -like "dxc-AgentHealth-*" }
   if (($null -ne $agentHealthFA) -and ($null -ne $selfhealLogicApp)) {
      $isRoleAssigned = Get-AzRoleAssignment -ObjectId $agentHealthFA.IdentityPrincipalId -RoleDefinitionName 'Logic App Contributor' -EA 0
      if ($isRoleAssigned) {
         Write-Output "'Logic App Contributor' already assigned to Agent Health Function App." | timestamp | Write-host
      } else {
         New-AzRoleAssignment -ObjectId $agentHealthFA.IdentityPrincipalId -RoleDefinitionName 'Logic App Contributor' `
               -Scope $selfhealLogicApp.ResourceId -EA 0
         if ($error) {
               Write-Warning "Failed to assign 'Logic App Contributor' permissions to $($selfhealLogicApp.Name). Please perform manually."
         }
      }
   }

#################################################################################################
#  STEP 5 - Publish CustomLog 
#################################################################################################
     Publish-CustomLog $workspaceHashtable $logType $dxcLogAnalyticsWorkspaceName -EA Stop -Verbose

#################################################################################################
#  STEP 6 - Listing of Selfheal components
#################################################################################################
      Write-Output ("INFO: Listing resources with selfheal tags...") | timestamp | Write-host -F White
      Write-Output (Get-AzResource -TagValue $selfHealTags.service | Select Name, Type  | Ft -AutoSize | Out-String) | write-host -F White


}Catch{
   Write-Output ("ERROR: Script executed with errors. $($_.Exception.Message)") | timestamp | Write-host -F Red

}Finally{
   Write-Output ("INFO: Script execution finished. Refer to log - $logFilePath") | timestamp | Write-Host -F Yellow
   Stop-Transcript -EA 0 | Out-Null ;  $end = Get-Date
   Write-Host -F DarkGray "Script duration (mins):" ([math]::Round(($end - $start).TotalMinutes,2))

   $selfheal_modules = "SelfHeal.psm1"

   ### Clearing of Variables ###
   if((Get-Module).Name -eq (($selfheal_modules).split(".") | Select -First 1 )) {
      Remove-Module -Name (($selfheal_modules).split(".") | Select -First 1) -ErrorAction SilentlyContinue
   }

   Remove-Variable (Get-Variable -Scope 0).Name -ErrorAction SilentlyContinue
}

