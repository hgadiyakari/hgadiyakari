﻿#-----------------------------------------------------------[Comments]-------------------------------------------------------------
<#
.DOCUMENTATION LINK
https://confluence.dxc.com/display/ESCAT/Deployment+of+the+Hybrid+Runbook+Worker
.SYNOPSIS
This automation script deploys the Hybrid Worker VM using an ARM template. The following procedures are included:
    - Checks for validity of required parameters (from an input file)
    - Creates the ARM parameter template file based on the input file
    - Deploys a Windows VM from an ARM template
    - Installs the Microsoft Monitoring Agent
    - Installs custom script extensions for Hybrid Runbook Worker configurations
The following are required as input -
    - deployHybridWorker_config.txt - This is the input file which contains VM build specifications such as VMName, Windows OS version, Resourcegroup, VNet info, etc...
    - SubscriptionID
    - LogAnalytics workspace
    - Automation Account
    - Administrator username and password for Hybrid Runbook Worker VM
.REVISION HISTORY
    03-Oct-2019 - Initial script development
    10-Mar-2020 - Modified to accommodate ARM template changes
    11-Mar-2020 - Modified to include option for key vault
    12-Mar-2020 - Modified to support option "addRole" 
    16-Mar-2020 - Modified to enable diagnostics by adding datasource
    17-Mar-2020 - Include function to register service account as credential asset to Automation Account
    31-Mar-2020 - Include CrowdStrike/Symantec security agent in 'deploy' option (ARM template)
    04-May-2021 - Include Recoveryvault, Backup policyname and patchGroup for the hybridworker VM
#>

#---------------------------------------------------------[Initializations]-------------------------------------------------------- 

[CmdletBinding()]
Param (
    [Parameter(HelpMessage = "Please enter your Subscription ID.", Position=1, Mandatory = $True, ValueFromPipeline = $True)]
    [ValidateNotNullOrEmpty()][string]$subscriptionId,
    [Parameter(HelpMessage = "Please enter your amnaged Log Analytics workspace name.", Position=2, Mandatory = $True, ValueFromPipeline = $True)]
    [ValidateNotNullOrEmpty()][string]$logAnalyticsWorkspaceName,
    [Parameter(HelpMessage = "Please enter the Automation Account used in Self-heal.", Position=3, Mandatory = $True, ValueFromPipeline = $True)]
    [ValidateNotNullOrEmpty()][string]$automationAccountName,
    [Parameter(HelpMessage = "Please enter the Key Vault used in your subscription.", Position=4, Mandatory = $True, ValueFromPipeline = $True)]
    [ValidateNotNullOrEmpty()][string]$keyvaultName
)

#----------------------------------------------------------[Declarations]----------------------------------------------------------

$ErrorActionPreference = "SilentlyContinue"
$scriptName = "deployHybridRunbookWorker"
$Global:LogFilePath = (Get-Item -Path .\ -Verbose).Fullname + '\' + $scriptName + '-{0:dd-MMM-yyyy_HHmm}' -f (Get-Date) + '.log'
$templateFile = "deployHybridRunbookWorker.json"
$configfile = 'deployHybridRunbookWorker_config.txt' # Default file name for input parameters
$hybridWorkerGroupName = "selfheal-group"
$global:paramsObject = New-Object PSCustomObject
$global:workspaceObj = $null
$global:automationAccountObj = $null
$allowedChar = '^[a-zA-Z0-9-_]+$'
$runbookScript = Join-Path (Get-Item -Path .\ -Verbose).Fullname "Export-RunAsCertificateToHybridWorker.ps1"
$runCommandScript = Join-Path (Get-Item -Path .\ -Verbose).Fullname "Configure-HybridWorker.ps1"

#-----------------------------------------------------------[Functions]------------------------------------------------------------
function Write-Log # This function writes script messages to active session and outputs to log file.
{ 
Param ([ValidateSet('Cyan','Gray','Green','Red','White','Yellow')][string]$logColor,
[string]$logText, [int]$logCode)

$logTimeStamp = Get-Date -Format MM-dd-yyyy-hh:mm:ss
switch ($logCode) {
    0 { Write-Host -F $logColor $logText } # Use for general messages
    1 { Write-Host -F $logColor "$logTimeStamp INFO: $logText" } # Use for Informational messages
    2 { Write-Host -F $logColor "$logTimeStamp ERROR: $logText" } # Use for Error messsages
    3 { Write-Host -F $logColor "$logTimeStamp WARN: $logText" } # Use for Warning messages
}

}

function Get-AzCachedAccessToken { 
    if(-not (Get-Module Az.Accounts)) {
        Import-Module Az.Accounts
    }
    $azProfile = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile
    if(-not $azProfile.Accounts.Count) {
        Write-Error "Ensure you have logged in before calling this function."    
    }
  
    $currentAzureContext = Get-AzContext
    $profileClient = New-Object Microsoft.Azure.Commands.ResourceManager.Common.RMProfileClient($azProfile)
    Write-Debug ("Getting access token for tenant" + $currentAzureContext.Tenant.TenantId)
    $token = $profileClient.AcquireAccessToken($currentAzureContext.Tenant.TenantId)
    $token.AccessToken
}

function Get-AzBearerToken {
    ('Bearer {0}' -f (Get-AzCachedAccessToken))
}

function Import-ConfigFile ([string]$configfile) # This function imports the config file to accept as parameters for the ARM template
{
$paramsFile = Get-Content (Join-Path (Get-Location).Path $configfile)
foreach ($i in $paramsFile) {
    if ($i.indexOf('vmName=') -ne -1) {$global:paramsObject | Add-Member -Name 'vmName' -MemberType NoteProperty -Value ($i.Split('=').Trim())[1]}
    if ($i.indexOf('vmLocation=') -ne -1) {$global:paramsObject | Add-Member -Name 'vmLocation' -MemberType NoteProperty -Value ($i.Split('=').Trim())[1]}
    if ($i.indexOf('vmResourceGroup=') -ne -1) {$global:paramsObject | Add-Member -Name 'vmResourceGroup' -MemberType NoteProperty -Value ($i.Split('=').Trim())[1]}
    if ($i.indexOf('existingvNetResourceGroup=') -ne -1) {$global:paramsObject | Add-Member -Name 'vNetResourceGroup' -MemberType NoteProperty -Value ($i.Split('=').Trim())[1]}
    if ($i.indexOf('existingvNet=') -ne -1) {$global:paramsObject | Add-Member -Name 'vNet' -MemberType NoteProperty -Value ($i.Split('=').Trim())[1]}
    if ($i.indexOf('existingvNetSubnet=') -ne -1) {$global:paramsObject | Add-Member -Name 'vNetSubnet' -MemberType NoteProperty -Value ($i.Split('=').Trim())[1]}
    if ($i.indexOf('publicIPRequired=') -ne -1) {$global:paramsObject | Add-Member -Name 'publicIPRequired' -MemberType NoteProperty -Value ($i.Split('=').Trim())[1]}
    if ($i.indexOf('existingDiagnosticsStorageResourceGroup=') -ne -1) {$global:paramsObject | Add-Member -Name 'diagStorageResourceGroup' -MemberType NoteProperty -Value ($i.Split('=').Trim())[1]}
    if ($i.indexOf('existingDiagnosticsStorageAccountName=') -ne -1) {$global:paramsObject | Add-Member -Name 'diagStorageName' -MemberType NoteProperty -Value ($i.Split('=').Trim())[1]}
    if ($i.indexOf('securityAgent=') -ne -1) {$global:paramsObject | Add-Member -Name 'securityAgent' -MemberType NoteProperty -Value ($i.Split('=').Trim())[1]}
    if ($i.indexOf('existingRecoveryServicesVaultRG=') -ne -1) {$global:paramsObject | Add-Member -Name 'recoveryvaultResourceGroup' -MemberType NoteProperty -Value ($i.Split('=').Trim())[1]}
    if ($i.indexOf('existingRecoveryServicesVault=') -ne -1) {$global:paramsObject | Add-Member -Name 'recoveryvaultName' -MemberType NoteProperty -Value ($i.Split('=').Trim())[1]}
    if ($i.indexOf('existingBackupPolicy=') -ne -1) {$global:paramsObject | Add-Member -Name 'backupPolicy' -MemberType NoteProperty -Value ($i.Split('=').Trim())[1]}
    if ($i.indexOf('patchGroup=') -ne -1) {$global:paramsObject | Add-Member -Name 'patchGroup' -MemberType NoteProperty -Value ($i.Split('=').Trim())[1]}

}
$requiredParams = 'vmName','vmLocation','vmResourceGroup','vNetResourceGroup','vNet','vNetSubnet','publicIPRequired','diagStorageResourceGroup','diagStorageName','securityAgent','recoveryvaultResourceGroup','recoveryvaultName','backupPolicy', 'patchGroup'
$checkRequiredParams = $global:paramsObject.psObject.Properties.Name | ? { $_ -notin $requiredParams}
if ($checkRequiredParams -ne $null) {
    Write-Log Red "Failed to import due to missing parameter in config file: $checkRequiredParams. Please ensure you entered the required parameter." 2;
    Write-Error "Failed to import due to missing parameter in config file: $checkRequiredParams. Please ensure you entered the required parameter." -EV errInput -EA 0 | Out-Null
} else {
    foreach ($param in $global:paramsObject.psObject.Properties) {
        if ([string]::IsNullOrWhiteSpace($param.Value)) {
            Write-Log Red ("Failed to import due to missing input in config file: " + $param.Name + ". Please ensure you entered a valid input.") 2
            Write-Error ("Failed to import due to missing input in config file: " + $param.Name + ". Please ensure you entered a valid input.") -EV errInput -EA 0
        }
    }
}
if ($errInput) { Write-Log Red "Failed to import config file due to invalid/missing parameters. $errInput" 2; $errInput.Clear(); exit }
}

function Validate-InputParameters ([psCustomObject]$inputObj) # This function validates input parameters and values
{
[psCustomObject[]]$validParamObject=@()
foreach ($input in $inputObj.psObject.Properties) {
$error.Clear()
    switch ($input.Name) {
        'vmResourceGroup' {
            Get-AzResourceGroup -Name $inputObj.vmResourceGroup -EA 0 | Out-Null
                if ($error) { 
                    Write-Log Red ("Unable to find resourcegroup named: "+ $inputObj.vmResourceGroup +" in subscription.") 2; $isValid = $false } else { $isValid = $true }
        }
        'vmName' { 
            $checkVM = Get-AzResource -ResourceType "Microsoft.Compute/virtualMachines" -Name $global:paramsObject.vmName -EA 0
                switch ($global:mode) {
                    'deploy' { if ($checkVM -eq $null) { $isValid = $true } else { 
                        $isValid = $false; Write-Log Red ("Found virtual machine named: "+ $inputObj.vmName +" in subscription.") 2} 
                    }
                    'addrole' { if ($checkVM -eq $null) { $isValid = $false
                        Write-Log Red ("Unable to find virtual machine named: "+ $inputObj.vmName +" in subscription.") } else { $isValid = $true } 
                    }
                }
        }
        'vmLocation' { 
            $computeLocations = Get-AzLocation | where Providers -like "Microsoft.Compute*"
            if ($computeLocations.location -eq $inputObj.vmLocation) { $isValid = $true } else { 
                Write-Log Red ("Invalid location name: "+ $inputObj.vmLocation +".") 2; $isValid = $false }
        }
        'vNet' {
            $checkVNet = Get-AzVirtualNetwork -Name $inputObj.vNet -ResourceGroupName $inputObj.vNetResourceGroup -EA 0
                if ($error) { 
                    Write-Log Red ("Unable to find virtual network named: "+ $inputObj.vNet +".") 2; $isValid = $false } else { $isValid = $true } 
        }
        'vNetSubnet' {
            if ($checkVNet -eq $null) { $isValid = $false; continue }
            $checkSubnet = Get-AzVirtualNetworkSubnetConfig -VirtualNetwork $checkVNet -Name $inputObj.vNetSubnet -EA 0
                if ($error -or ($checkSubnet -eq $null)) { 
                    Write-Log Red ("Unable to find virtual network subnet named: "+ $inputObj.vNetSubnet +".") 2; $isValid = $false } else { $isValid = $true }
        }
        'vNetResourceGroup' {
            Get-AzResourceGroup -Name $inputObj.vNetResourceGroup -EA 0 | Out-Null
                if ($error) { 
                Write-Log Red ("Unable to find virtual network resourcegroup named: "+ $inputObj.vNetResourceGroup +" in subscription.") 2; $isValid = $false } else { $isValid = $true }
        }
        'publicIPRequired' { 
            if (($inputObj.publicIPRequired -eq "yes") -or ($inputObj.publicIPRequired -eq "no")) {
                $isValid = $true } else { Write-Log Gray "Yes/no input only allowed." 2; $isValid = $false } 
        }
        'diagStorageResourceGroup' {
            Get-AzResourceGroup -Name $inputObj.diagStorageResourceGroup -EA 0 | Out-Null
                if ($error) { 
                Write-Log Red ("Unable to find virtual network resourcegroup named: "+ $inputObj.diagStorageResourceGroup +" in subscription.") 2; $isValid = $false } else { $isValid = $true }
        }
        'diagStorageName' {
            $global:storageAccountObj = Get-AzResource -ResourceType Microsoft.Storage/storageAccounts `
                -Name $inputObj.diagStorageName -ResourceGroupName $inputObj.diagStorageResourceGroup
                if ($error) { Write-Log Red "Unable to find storage account named $inputObj.diagStorageName." 2 ; $isValid = $false } else { $isValid = $true }
        }
        'securityAgent' {
            if (($inputObj.securityAgent -eq "crowdstrike") -or ($inputObj.securityAgent -eq "symantec")) { 
                $isValid = $true
            } else {
                Write-Log Red ("Invalid input. Please enter either 'crowdstrike' or 'symantec' only.") 2; $isValid = $false 
            }
        }
        'recoveryvaultResourceGroup' {
            Get-AzResourceGroup -Name $inputObj.recoveryvaultResourceGroup -EA 0 | Out-Null
                if ($error) { 
                Write-Log Red ("Unable to find recovery vault resourcegroup named: "+ $inputObj.recoveryvaultResourceGroup +" in subscription.") 2; $isValid = $false } else { $isValid = $true }
        }
        'recoveryvaultName' {
            $global:recoveryvaultName = Get-AzResource -ResourceType Microsoft.RecoveryServices/vaults `
                -Name $inputObj.recoveryvaultName -ResourceGroupName $inputObj.recoveryvaultResourceGroup
                if ($error) { Write-Log Red "Unable to find recovery vault named $inputObj.recoveryvaultName." 2 ; $isValid = $false } else { $isValid = $true }
        }
        'backupPolicy' {
            $allowedVal=@("defaultpolicy", "dxc30day", "dxc60day", "dxc90day")
            if($allowedVal.Contains(($inputObj.backupPolicy).tolower())){
               $global:backupPolicy = Get-AzRecoveryServicesBackupProtectionPolicy -Name $inputObj.backupPolicy -vaultid $global:recoveryvaultName.Id
               if ($error) { Write-Log Red "Unable to find backuppolicy named $inputObj.backupPolicy." 2 ; $isValid = $false } else { $isValid = $true }
            }else{
                Write-Log Red ("Invalid input. Please enter any of the values : 'DefaultPolicy','DXC30day, 'DXC60day','DXC90day' only.") 2; $isValid = $false 
            }

        }
    }
    $addParam = New-Object PsCustomObject -Property @{Parameter=($input.Name).ToString(); Value=($input.Value).ToString(); IsValid=$isValid}
    $validParamObject+=$addParam
    Clear-Variable addParam, isValid
} 

Write-Log Yellow ("Validation results:") 1
Write-Log White ($validParamObject | select Parameter,Value,IsValid | ft -a | Out-String) 0
if ($validParamObject.IsValid -contains $false) {
    Write-Log Red "Failed validation of input parameters. Please ensure input entered is valid." 2 ; throw } else { 
    Write-Log Green "Import and validation of input parameters successfully completed." 1 }

}

function Validate-LogAnalyticsWorkspace # Get Log Analytics workspace details, enable AzureAutomation intelligence pack and Microsoft/SMA data source
 {
 $error.clear()
$global:workspaceObj = Get-AzResource -ResourceType Microsoft.OperationalInsights/workspaces -Name $logAnalyticsWorkspaceName -EA 0
    if ($global:workspaceObj -eq $null) {
        Write-Log Red "Unable to find Log Analytics workspace named $logAnalyticsWorkspaceName in subscription." 2; exit
    } else {
        Write-Log Yellow "Found Log Analytics workspace in subscription:" 1
        Write-Log White ($global:workspaceObj | Out-String) 0
        $global:workspaceId = (Get-AzOperationalInsightsWorkspace -ResourceGroupName $global:workspaceObj.ResourceGroupName -Name $logAnalyticsWorkspaceName).CustomerId.Guid
        $global:workspaceKey = (Get-AzOperationalInsightsWorkspaceSharedKey -ResourceGroupName $global:workspaceObj.ResourceGroupName -Name $logAnalyticsWorkspaceName -WA Ignore).PrimarySharedKey
        
        # Enables AzureAutomation package to register VM to Hybrid Worker group 
        Set-AzOperationalInsightsIntelligencePack -ResourceGroupName $global:workspaceObj.ResourceGroupName `
            -WorkspaceName $global:workspaceObj.Name -IntelligencePackName "AzureAutomation" -Enabled $true -EA 0 | Out-Null
            if ($error) { Write-Log Gray "Failed to enable AzureAutomation on $logAnalyticsWorkspaceName" 0; $error.Clear() } 
        
        # Enables Microsoft-SMA datasource in Log Analytics
        $hrwDataSource = New-Object PsCustomObject -Property @{
            name="Microsoft-SMA"
            type="datasources"
            kind="WindowsEvent"
            properties=@{
            eventLogName="Microsoft-SMA/Operational"
            eventTypes=@(
                @{eventType="Error"}
                @{eventType="Warning"}
                @{eventType="Information"}
                )
            }
        }
        $wkspName = $global:workspaceObj.Name
        $rgName = $global:workspaceObj.ResourceGroupName
        $dataSrc = "Microsoft-SMA"
        $requestUpdateUri = "https://management.azure.com/subscriptions/$subscriptionId/resourcegroups/$rgName/providers/Microsoft.OperationalInsights/workspaces/$wkspName/dataSources/$dataSrc`?api-version=2015-11-01-preview"
        $body = $hrwDataSource | ConvertTo-Json -Depth 5
        $armToken = Get-AzBearerToken
        $apiResponse = Invoke-WebRequest -Uri $requestUpdateUri `
            -Method PUT -ContentType "application/json" -Body $body -Headers @{ Authorization ="$armToken"} –UseBasicParsing -WA 0 -EA 0
    }
}

function Validate-AutomationAccount # Get Automation Account (self-heal) details
{
$error.clear()
$global:automationAccountObj = Get-AzResource -ResourceType Microsoft.Automation/automationAccounts -Name $automationAccountName -EA 0
    if ($global:automationAccountObj -eq $null) {
        Write-Log Red "Unable to find Automation Account named $automationAccountName in subscription." 2; exit
    } else {
        Write-Log Yellow "Found Automation Account in subscription:" 1
        Write-Log White ($global:automationAccountObj[0] | Out-String) 0
            $global:autoAcctEndpoint = (Get-AzAutomationRegistrationInfo -ResourceGroupName $global:automationAccountObj[0].ResourceGroupName -AutomationAccountName $global:automationAccountObj[0].Name).Endpoint
            $global:autoAcctKey = (Get-AzAutomationRegistrationInfo -ResourceGroupName $global:automationAccountObj[0].ResourceGroupName -AutomationAccountName $global:automationAccountObj[0].Name).PrimaryKey
    }
}

function Validate-Secret ([psCustomObject]$secretObj) # Validate the secret and/or register credentials to key vault
{
$error.clear()
if (!($keyVaultName) -or ($global:keyVaultObj -eq $null)) {
    Write-Host -F Yellow "No key vault provided. Please manually secure your credentials for safekeeping."
    do { 
        $secretName = Read-Host ("Enter the secret name for " + $secretObj.Item) 
        $secretPassword = Read-Host ("Enter a strong password for " + $secretObj.Item) -AsSecureString
    } until (($secretName -match $allowedChar) -and ($secretPassword.Length -ne 0))
} else {
    Write-Host -F Cyan "The secret provided will be automatically detected in the key vault if it exists. Otherwise, it will create a new one."
    do { $secretName = Read-Host ("Enter the secret name for " + $secretObj.Item) } until ( $secretName )
    $keyVaultSecret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $secretName -EA 0
        if ($keyVaultSecret -eq $null) { 
            Write-Log Gray "Secret name $secretName not found in key vault. will proceed to create a new one." 3
            do {$secretPassword = Read-Host ("Enter a strong password for " + $secretObj.Item) -AsSecureString} until ($secretPassword.Length -ne 0)
            $setSecret = Set-AzKeyVaultSecret -VaultName $keyVaultName -Name $secretName -SecretValue $secretPassword `
                -Expires ((Get-Date).AddYears(1).ToUniversalTime()) -ContentType $secretObj.Desc -EA 0
                if ($error) { Write-Log Gray ("Failed to create new secret in key vault. Check your permissions in the key vault." + $error ) 3 } else {
                    Write-Log Green ("Successfully added the new secret for " + $secretObj.Item) 1
                    $secretPassword = $setSecret.SecretValue
                }
        } else { 
            Write-Log Yellow "Found secret name in key vault, will use existing secret value for password." 1
            $secretPassword = $keyVaultSecret.SecretValue
        }
}
return $secretName, $secretPassword
}

function Register-CredentialAsset ([string]$credUserName, [secureString]$credPassword)# This function registers a secret (service account) as Automation Account credential asset.
{
# Add the service account as credential asset to the Automation Account
$svcAccount = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $credUserName, $credPassword
$credAsset = New-AzAutomationCredential -AutomationAccountName $global:automationAccountObj.Name `
    -ResourceGroupName $global:automationAccountObj.ResourceGroupName `
    -Name DefaultAzureCredential -Value $svcAccount -WA 0 -EA 0
        if ($error) { Write-Log Gray ("Failed to add  the service account as credential asset to the Automation Account." + $error ) 3 } else {
            Write-Log White ($credAsset | Out-String) 0
            Write-Log White "Added the service account as credential asset successfully." 1
        }
}

function Create-HybridRunbookWorkerVM # Deploy Hybrid Worker VM if validations passed successfully.
{
$error.clear()
Write-Host "`n"; Write-Log White "`Start deployment of the Hybrid Runbook Worker VM..." 1
switch ($global:paramsObject.securityAgent) {
    'crowdstrike' {
        $csCID = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto([System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($csCID))
        New-AzResourceGroupDeployment -Name $scriptName -TemplateFile (Join-Path (Get-Location).Path $templateFile) `
            -ResourceGroupName $global:paramsObject.vmResourceGroup `
            -adminUserName $global:hrwUserName -adminPassword $global:hrwPassword `
            -vmName $global:paramsObject.vmName -vmLocation $global:paramsObject.vmLocation `
            -existingvNetResourceGroup $global:paramsObject.vNetResourceGroup `
            -existingvNetName $global:paramsObject.vNet `
            -subnetName $global:paramsObject.vNetSubnet `
            -publicIPRequired $global:paramsObject.publicIPRequired `
            -workspaceId $global:workspaceId -workspaceKey $global:workspaceKey `
            -existingDiagnosticsStorageResourceGroup $global:paramsObject.diagStorageResourceGroup `
            -existingDiagnosticsStorageAccountName $global:paramsObject.diagStorageName `
            -securityAgent $global:paramsObject.securityAgent `
            -csCID $csCID -csUninstallPW $global:csUninstallPWSecretPassword `
            -existingRecoveryServicesVaultRG $global:paramsObject.recoveryvaultResourceGroup `
            -existingRecoveryServicesVault $global:paramsObject.recoveryvaultName `
            -existingBackupPolicy $global:paramsObject.backupPolicy `
            -patchGroup $global:paramsObject.patchGroup `
            -WA 0 -EA 0 -Verbose
    }
    'symantec' {
        $SymantecCustomerId = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto([System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($SymantecCustomerId))
        $SymantecDomainId = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto([System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($SymantecDomainId))
        $SymantecClientId = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto([System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($SymantecClientId))
        New-AzResourceGroupDeployment -Name $scriptName -TemplateFile (Join-Path (Get-Location).Path $templateFile) `
            -ResourceGroupName $global:paramsObject.vmResourceGroup `
            -adminUserName $global:hrwUserName -adminPassword $global:hrwPassword `
            -vmName $global:paramsObject.vmName -vmLocation $global:paramsObject.vmLocation `
            -existingvNetResourceGroup $global:paramsObject.vNetResourceGroup `
            -existingvNetName $global:paramsObject.vNet `
            -subnetName $global:paramsObject.vNetSubnet `
            -publicIPRequired $global:paramsObject.publicIPRequired `
            -workspaceId $global:workspaceId -workspaceKey $global:workspaceKey `
            -existingDiagnosticsStorageResourceGroup $global:paramsObject.diagStorageResourceGroup `
            -existingDiagnosticsStorageAccountName $global:paramsObject.diagStorageName `
            -securityAgent $global:paramsObject.securityAgent `
            -SymantecCustomerId $SymantecCustomerId `
            -SymantecDomainId $SymantecDomainId `
            -SymantecClientId $SymantecClientId `
            -SymantecCustomerSecretKey $SymantecCustomerSecretKey `
            -SymantecClientSecretKey $SymantecClientSecretKey `
            -existingRecoveryServicesVaultRG $global:paramsObject.recoveryvaultResourceGroup `
            -existingRecoveryServicesVault $global:paramsObject.recoveryvaultName `
            -existingBackupPolicy $global:paramsObject.backupPolicy `
            -patchGroup $global:paramsObject.patchGroup `
            -WA 0 -EA 0 -Verbose
    }
}
    if ($error) { throw } else { Write-Log Green "Hybrid Runbook Worker VM deployed successfully." 1 }
}

function Execute-Runbook ([string]$runbookObj) 
{
$error.clear()
Write-Log White ("Start execution of runbook " + $runbookObj + "...") 1
$executeRunbook = Start-AzAutomationRunbook -Name $runbookObj `
    -ResourceGroupName $global:automationAccountObj.ResourceGroupName `
    -AutomationAccountName $global:automationAccountObj.Name -RunOn $hybridWorkerGroupName -WA 0 -EA 0
    if ($error) { Write-Log Red ("Failed to execute runbook " + $runbookObj + $error) 2 } else { 
        do { $isJobCompleted = Get-AzAutomationJob -Id $executeRunbook.JobId `
                -ResourceGroupName $global:automationAccountObj.ResourceGroupName `
                -AutomationAccountName $global:automationAccountObj.Name -WA 0 -EA 0
            Sleep -s 3; [int]$count +=1
        } until (($isJobCompleted.Status -eq "Completed") -or ($count -eq 25))
        if ($isJobCompleted.Status -ne "Completed") { Write-Log Red "Failed runbook execution due job timeout." 2
        } else { Write-Log White ($isJobCompleted | Out-String) 0
            Remove-AzAutomationRunbook -Name $runbookObj `
                -ResourceGroupName $global:automationAccountObj.ResourceGroupName `
                -AutomationAccountName $global:automationAccountObj.Name -Force -WA 0 -EA 0
            Write-Log Green ("Runbook "+ $runbookObj +" executed and completed successfully.") 1 } 
        }
}

function Execute-RunCMDScript ([string]$runCmdScriptObj) 
{
$error.clear()
Write-Log White ("Start installation and configuration of required modules and settings on " + $global:paramsObject.vmName + "...") 1
$argParams = @{groupName=$hybridWorkerGroupName; url=$global:autoAcctEndpoint;key=$global:autoAcctKey}
$runCmdResults = Invoke-AzVMRunCommand -ResourceGroupName $global:paramsObject.vmResourceGroup -VMName $global:paramsObject.vmName `
    -CommandId 'RunPowerShellScript' -ScriptPath $runCmdScriptObj -Parameter $argParams -Verbose -WA 0 -EA 0
    if ($error) {
        Write-Log Red "Failed to install and configure required modules and settings." 2
        $error
    } else {
        Write-Log White ($runCmdResults.Value[0].Message | Out-String) 0
        Write-Log Green "Successfully installed and configured required modules and settings" 1
    }
}

#-----------------------------------------------------------[Execution]------------------------------------------------------------

try {
$error.clear()
$start = Get-Date

# Create the log file
New-Item $Global:LogFilePath -ItemType File | Out-Null
Start-Transcript -Path $Global:LogFilePath -Append -EA 0 | Out-Null
Write-Log Yellow "Script execution started." 1

# Confirm the deployment type of the Hybrid Runbook Worker resource
Write-Log Cyan "CONFIRM: Please select and confirm deployment mode for the Hybrid Runbook Worker resource:" 0
Write-Host "Type " -NoNewline; Write-Host -F Yellow "'deploy'" -NoNewline
Write-Host " to create a new VM resource and set up the Hybrid Runbook Worker role."
Write-Host "Type " -NoNewline; Write-Host -F Yellow "'addRole'" -NoNewline
Write-Host " to set up an existing Windows VM with the Hybrid Runbook Worker role only."
Write-Host "Type " -NoNewline; Write-Host -F Gray "'quit'" -NoNewline; Write-Host " to exit."

do {
$global:mode = Read-Host "CONFIRM: Which mode do you wish to proceed with? (deploy/addRole/quit)"

    if ($global:mode -eq "deploy") { 
        Write-Host "You have chosen " -NoNewline; Write-Host -F Green "DEPLOY" -NoNewline
        Write-Host " mode. A new VM resource will be created and setup as a Hybrid Runbook Worker." 
            # Check if ARM template file exists in script directory
        if (!(Test-Path -Path .\$templateFile) -or !(Test-Path -Path .\$configfile)) { 
            Write-Log Red "Unable to find the required ARM template file - $templateFile. Please ensure file exists in script directory." 2 ; exit }
        Import-ConfigFile $configfile
    } elseif ($global:mode -eq "addRole") { 
        Write-Host "You have chosen " -NoNewline; Write-Host -F Green "ADDROLE" -NoNewline
        Write-Host " mode. Your nominated Windows VM resource will be configured as a Hybrid Runbook Worker."
        do { $vmName = Read-Host "Enter an existing Windows VM to configure the Hybrid Runbook Worker role on" } until ($vmName -match $allowedChar)
        do { $vmResourceGroup = Read-Host "Enter the resourcegroup of $vmName" } until ($vmResourceGroup -match $allowedChar)
        $global:paramsObject | Add-Member -Name 'vmName' -MemberType NoteProperty -Value $vmName
        $global:paramsObject | Add-Member -Name 'vmResourceGroup' -MemberType NoteProperty -Value $vmResourceGroup
    } else { 
        if ($global:mode -eq "quit") { exit } else { 
            Write-Log Red "Input entered invalid, please enter either 'deploy' or addRole' for deployment modes OR 'quit' to exit." 2; pause }
    } 
} until (($global:mode -eq "deploy") -or ($global:mode -eq "addRole") -or ($global:mode -eq "quit"))
  

# Login to Azure
Write-Log Cyan "Please login to Azure Resource Manager.`n" 0
Connect-AzAccount -Subscription $subscriptionId | Out-Null
if ($error) { Write-Log Red "Unable to connect to Azure. Check your internet connection and verify authentication details." 2; exit }
Sleep 3
Write-Log Yellow "Connected to Azure with provided authentication." 1
Write-Log White (Get-AzContext | Out-String) 0


Validate-LogAnalyticsWorkspace
Validate-AutomationAccount
# Import runbook Export-RunAsCertificateToHybridWorker.ps1 to Automation Account
    $runbookName = ($runbookScript.Split("\")[-1])
    $importRunbook = { 
        param ($resourceGroupName,$automationAccountName,$runbookScript,$runbookName)
        Import-AzAutomationRunbook -ResourceGroupName $resourceGroupName `
        -AutomationAccountName $automationAccountName `
        -Path $runbookScript -Name $runbookName -Type PowerShell `
        -Tags @{"service"="selfheal"} -Published -Force -Verbose -EA 0 | Out-Null }
    Start-Job -ScriptBlock $importRunbook `
        -ArgumentList @($global:automationAccountObj.ResourceGroupName,$global:automationAccountObj.Name,$runbookScript,$runbookName) > $null

Write-Log White "Start validation of input parameters..." 1
Validate-InputParameters $global:paramsObject

# Validate the Key vault in subscription for secrets
if ($keyVaultName -ne "") {
    $global:keyVaultObj = Get-AzResource -ResourceType Microsoft.KeyVault/vaults -Name $keyVaultName
    if ($global:keyVaultObj -eq $null) { 
        Write-Log Gray "No Key Vault found in subscription." 3
    } else {
        Write-Log Yellow "Found Key Vault in subscription:" 1
        Write-Log White ($global:keyVaultObj | Out-String) 0

        if ($global:mode -eq "deploy") {
            # Validate credentials for Hybrid Runbook Worker
            Write-Host -F Cyan "`nCONFIRM: Provide the credentials for the Hybrid Runbook Worker. " -NoNewline
            Write-Host -F Cyan "This will be used as the " -NoNewLine; 
            Write-Host -F Yellow "local administrator account of the Hybrid Runbook Worker. " -NoNewLine
            Write-Host -F Cyan "If you have entered a key vault, you may choose to create or use an existing secret."
            $hrwSecret = [psCustomObject]@{item="Hybrid Runbook Worker"; desc="Local administrator account for Hybrid Runbook Worker."}
            $global:hrwUserName, $global:hrwPassword = Validate-Secret $hrwSecret

            # Validate secrets for security agent (CrowdStrike/Symantec)
            $secretsSecurityAgent = 'csCID','SymantecCustomerId','SymantecDomainId','SymantecClientId','SymantecCustomerSecretKey','SymantecClientSecretKey'
            foreach ($secret in $secretsSecurityAgent) {
                $keyVaultSecret = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $secret -EA 0
                Set-Variable -Name $secret -Value $keyVaultSecret.SecretValue
            }
            # Validate credentials for CrowdStrike
            if ($global:paramsObject.securityAgent -eq "crowdstrike") {
                Write-Host -F Cyan "`nCONFIRM: Provide a " -NoNewLine ; Write-Host -F Yellow "CrowdStrike uninstall password" -NoNewline
                Write-Host -F Cyan ". This the password to prevent uninstall of CrowdStrike." 
                Write-Host -F Cyan "If you have entered a key vault, you may choose to create or use an existing secret."
                $csUninstallPWSecret = [psCustomObject]@{item="Password to prevent CrowdStrike uninstall"; desc="Uninstall password for CrowdStrike."}
                $csUninstallPWSecretName, $global:csUninstallPWSecretPassword = Validate-Secret $csUninstallPWSecret
            }
        }
    }
} 

# Validate credentials for Automation Account credential asset
Write-Host -F Cyan "`nCONFIRM: Provide the credential asset for the Automation Account. " -NoNewLine
Write-Host -F Cyan "This will be used as a " -NoNewLine; Write-Host -F Yellow "service account by the Hybrid Runbook Worker " -NoNewLine
Write-Host -F Cyan "to authenticate against VM resources. Please enter a valid service account, otherwise you need to create this first before proceeding further."
$credAssetSecret = [psCustomObject]@{item="Automation Account Credential Asset"; desc="Service account for Hybrid Runbook Worker and used as Credential Asset in Automation Account."}
$credAssetUserName, $credAssetPassword = Validate-Secret $credAssetSecret
Register-CredentialAsset $credAssetUserName $credAssetPassword

if ($global:mode -eq "deploy") { Create-HybridRunbookWorkerVM }

Execute-RunCMDScript $runCommandScript
Execute-Runbook $runbookName

} catch {
Write-Log Red "Script executed with errors. $Error." 2

} finally {
Disconnect-AzAccount | Out-Null
Write-Log Cyan "`nDisconnected from Resource Manager." 0
Stop-Transcript -EA 0 | Out-Null
Write-Log Yellow "Script execution finished. Refer to log - $Global:LogFilePath." 1; $end = Get-Date
Write-Host -F DarkGray "Script duration (mins):" ([math]::Round(($end - $start).TotalMinutes,2))
Remove-Variable * -Force -EA 0; $error.Clear()
}
