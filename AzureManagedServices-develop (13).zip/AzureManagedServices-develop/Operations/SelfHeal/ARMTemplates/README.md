# Self Heal ARM Templates

This folder contains deployment scripts and ARM templates used for self-heal.

|Deployment script|What does it do?|Required Parameter|
|-----|-----|-----|
|deploySelfHeal.ps1|this script creates an Automation account instance, imports the runbooks, creates a Logic app instance with the workflows and adds a custom log in the DXC Log analytics workspace.|<li>dxcSubscriptionID</li><li>dxcLogAnalyticsWorkspaceName</li><li>dxcCustomerCompanyCode</li><li>dxcKeyVaultName</li>|
|deployAlertRule.ps1|this script creates alert rule with the log search query and action group.|<li>dxcSubscriptionID</li><li>dxcLogAnalyticsWorkspaceName</li><li>dxcAutomationAccountSH</li>|

|ARM template|What does it contain?|
|-----|-----|
|automationaccount-selfheal.json|This template creates the automation account instance and defines all modules, runbooks that enables self-heal. This is deployed by the deploySelfHeal.ps1 script.|
|logicapps-selfheal-lite.json|This template defines the automation workflow for self-heal. This is deployed by the deploySelfHeal.ps1 script.|
|alerts-selfheal.json|This template defines the alert rules for both Critical and Informational events for self-heal. This is deployed by the deployAlertRule.ps1 script.|
|actiongroup-selfheal.json|This template defines the action group used that will be used by "DXC-Critical-Backup Failure" alert rule. This is deployed by the deployAlertRule.ps1 script.|
