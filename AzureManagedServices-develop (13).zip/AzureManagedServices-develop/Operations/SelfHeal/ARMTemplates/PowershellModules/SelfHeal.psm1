<#
.SYNOPSIS
    This module contains functions used by SelfHeal deployment.
.PARAMETER
    
.REVISION HISTORY
    Creation Date:
    2-Jul-2020 - initial script development
    15-Mar-2021 - Update to Get- Certificate and Secret commands
    21-Jun-2021 - azr-23698 - include service principal
    21-Jul-2021 - AZR-24312 - Fix permissions check on Find-KeyVault function.
    21-Jul-2021 - AZR-24269 - Fix UPN checking on Find-KeyVault function.
#>

#---------------------------------------------------------[Initializations]--------------------------------------------------------
# Capture the time information for logging purposes.
filter timestamp {"$(Get-Date -Format MM-dd-yyyy-hh:mm:ss): $_"}

#-----------------------------------------------------------[Functions]------------------------------------------------------------

#region functions used by AUTOMATION ACCOUNT deployment

function Find-KeyVault{  # this should be in module
  [CmdletBinding(SupportsShouldProcess=$True)]
  param ([String]$dxcKeyVaultName,[String]$dxcResourceGroupName,[String]$dxcSubscriptionID,[int]$SelfSignedCertNoOfMonthsUntilExpired)
 
  $KeyVaultHash=@{'SelfSignedCertNoOfMonthsUntilExpired' = $SelfSignedCertNoOfMonthsUntilExpired}
  $partialid = $dxcSubscriptionID.Substring(0,4)

  Try{
    
    $Error.Clear()
    $KeyVaults=Get-AzResource -ResourceType Microsoft.KeyVault/vaults -Name $dxcKeyVaultName -EA SilentlyContinue
    
    if(($KeyVaults -eq $null) -or ($error)) {
         Write-Output ("No KeyVault Name : "+  $dxcKeyVaultName + " found in ResourceGroup: $dxcResourceGroupName. Please specify a valid keyvault.") | timestamp | Write-host -F Cyan

       $kvflag=$false
       $tries = 0
        do{
            $KeyVaultName = Read-Host "Enter valid KeyVault Name..."
            if($KeyVaultName.Length -ne 0){
                Write-Output ("INFO: Validating Key Vault Name $($KeyVaultName) provided...") | timestamp | Write-host -F White
                $KeyVaults=$null
                $KeyVaults = Get-AzResource -ResourceType Microsoft.KeyVault/vaults -Name $KeyVaultName -EA SilentlyContinue

                if($KeyVaults -ne $null){ 
                   Write-Output ("INFO: Creating secret key for runasaccount in keyvault...") | timestamp | Write-host -F White
                   $kvflag = $true
                   Write-Output ("INFO: KeyVaultName: $($KeyVaults.Name) found in subscription.") | Write-host -F White
                   #Write-Output ($KeyVaults | Out-String) | Write-host -F White

                   $KeyVaultHash.Add('dxcKeyVaultName', $KeyVaults.Name)
                   $KeyVaultHash.Add('dxcKeyVaultRG',$KeyVaults.ResourceGroupName)
                   break
                }else{
                   Write-Output ("ERROR: KeyVaultName $($KeyVaults.Name) NOT Found in subscription.") | Write-host -F Cyan
                   $kvflag = $false}
            }
            $tries++
        } until (($kvflag -eq $true) -or ($tries -ge 3) )
        
        if($kvflag -eq $false){ Write-Output ("ERROR: The maximum allowable retries has exceeded.") | timestamp | Write-host -F Red; throw}
  
    }else{
       Write-Output ("INFO: KeyVault found in subscription: $($KeyVaults.Name)") | timestamp | Write-host -F Yellow
       $KeyVaultHash.Add('dxcKeyVaultName', $KeyVaults.Name)
       $KeyVaultHash.Add('dxcKeyVaultRG',$KeyVaults.ResourceGroupName)
    }

    ### ----- Checking KeyVault Permissions --- ###
    $reqpermcert=@('Get','Create','Update')
    $reqpermsecret=@('Get','Set')

    $acctId = (Get-AzContext).Account.Id
    $kVault = Get-AzKeyVault -VaultName $KeyVaultHash.dxcKeyVaultName
    $kVaccess=$kVault.AccessPolicies | Where-Object { ($_.DisplayName -match $acctId) -or ($_.DisplayName -match ($acctId).replace('@','_'))}
    if ($null -eq $kVaccess) {
        throw "ERROR: Unable to find user's access to key vault policy."
    }

    $cert_access = $kVaccess.PermissionsToCertificates
    $secret_access = $kVaccess.PermissionsToSecrets

    foreach($reqp in $reqpermcert){
        if ($reqp -notin $cert_access){
            $missing_access_cert+=$reqp
        }
    }

    foreach($reqp in $reqpermsecret){
        if ($reqp -notin $secret_access){
            $missing_access_secret+=$reqp
        }
    }

    if($missing_access_cert){$str_acc_cert=$missing_access_cert -join ","}
    if($missing_access_secret){$str_acc_sec=$missing_access_secret -join ","}

    if(($missing_access_cert) -and ($missing_access_secret)){
       Write-Output ("ERROR: Missing $str_acc_cert permissions in Certificates and $str_acc_sec permissions in Secrets in keyvault.") | timestamp | Write-host -F Red
       throw
    }elseif($missing_access_cert){
       Write-Output ("ERROR: Missing $str_acc_cert permissions in Certificates in keyvault.") | timestamp | Write-host -F Red
       throw
    }elseif($missing_access_secret){
       Write-Output ("ERROR: Missing $str_acc_sec permissions in Secrets in keyvault.") | timestamp | Write-host -F Red
       throw
    }
     
    # check if $partialId + "runasaccountpswd" is present in keyvault #
    $sname = $partialId + "runasaccountpswd"
    $KeyVaultHash.Add('sname',$sname)
    $snameval = Get-AzKeyVaultSecret -VaultName $KeyVaultHash.dxcKeyVaultName -Name $sname

    if(!($snameval)){
       ### ----- Writing to Key Vault ----- ###
       $PfxCertPlainPasswordForRunAsAccount = [Guid]::NewGuid().ToString().Substring(0, 8) + "!"
       $credAssetSecret = [psCustomObject]@{name=$sname;item="RunAsAccount Asset"; desc="RunAsAccount Asset in Automation Account."}
       $secretpswd = ConvertTo-SecureString $PfxCertPlainPasswordForRunAsAccount -AsPlainText -Force
       $setSecret = Set-AzKeyVaultSecret -VaultName $KeyVaultHash.dxcKeyVaultName -Name $credAssetSecret.name -SecretValue $secretpswd `
             -Expires ((Get-Date).AddYears(1).ToUniversalTime()) -ContentType $credAssetSecret.Desc -EA Stop

       Sleep 3
    }
    
  return $KeyVaultHash

  }Catch{
     Write-Output ("ERROR: Script executed with errors in Find-KeyVault function. $Error") | timestamp | Write-host -F Red ; throw
  }
}
  
function Validate-Checks{
  [CmdletBinding(SupportsShouldProcess=$True)]
  param ([String]$curWorkingDir,[String[]]$JSONtemplates,[String]$dxcLogAnalyticsWorkspaceName)

  Try{
       #################################################################################################
       #  STEP1 - Validating JSON Templates
       #################################################################################################
       $incval = New-Object System.Collections.ArrayList
       $filen = New-Object System.Collections.ArrayList

       foreach($itm in $JSONtemplates){
          $findfile = Test-Path (Join-Path -Path $curWorkingDir -ChildPath "\$itm")
          if($findfile -eq $False){
             $incval.Add($True)
             $filen.Add($itm)
          }
       }#foreach
                     
       if($incval.Contains($True)){
           $filesn = $filen -join ","
           Write-Output ("ERROR: $filesn NOT found in local directory. Please download from GitHub location.") | timestamp | Write-host -F Red ; throw
       }

       #################################################################################################
       #  STEP2 - Validating LogAnalytics Workspace
       ################################################################################################# 
       $workspaceHashtable=@{}

       $Error.clear()
       $workspaceObj = Get-AzOperationalInsightsWorkspace | ? { $_.Name -eq $dxcLogAnalyticsWorkspaceName }

       if ($workspaceObj -eq $null) {
         Write-Output ("ERROR: Loganalytics Workspace Not found. Please enter a valid workspace in the subscription.") `
         | timestamp | Write-Host -F Red ; throw
        }else{
         Write-Output ("INFO: Log Analytics Workspace found in subscription: $($workspaceObj.Name)")  | timestamp | Write-Host -F Yellow

           $workspaceHashtable.Add("Name",$workspaceObj.Name)
           $workspaceHashtable.Add("ResourceGroupName",$workspaceObj.ResourceGroupName)
           $workspaceHashtable.Add("WorkspaceId",$workspaceObj.ResourceId)
           $workspaceHashtable.Add("WorkspaceLocation",$workspaceObj.Location)

           # Fetch the customer Id and shared key.
           $wsCustomerId = (Get-AzOperationalInsightsWorkspace -ResourceGroupName $workspaceObj.ResourceGroupName -Name $workspaceObj.Name).CustomerId.Guid
           $workspaceKey = (Get-AzOperationalInsightsWorkspaceSharedKey -ResourceGroupName $workspaceObj.ResourceGroupName -Name $workspaceObj.Name -WA Ignore).PrimarySharedKey

           $workspaceHashtable.Add("wsCustomerId",$wsCustomerId)
           $workspaceHashtable.Add("workspaceKey",$workspaceKey)

        }

   return $workspaceHashtable

  }Catch{
    Write-Output ("ERROR: Script executed with errors in Validate-Checks function. $($_.Exception.Message)" ) | timestamp | Write-host -F Red ; throw
  }

}

function New-RunsAsAccount{  # this should be in module
  [CmdletBinding(SupportsShouldProcess=$True)]
  param([hashTable]$KeyVaultHashtable,[String]$AutomationAccountName,[String]$dxcResourceGroupName,[String]$dxcSubscriptionID)

  Try{
   $error.Clear()

   Write-Output ("Creating RunAsAccount creation Started...") | timestamp | Write-host -F White

   $runAsAccountHash = @{
      CertifcateAssetName ="AzureRunAsCertificate"
      secretAssetName=$KeyVaultHashtable.sname
   }

   $CertName = $AutomationAccountName + $runAsAccountHash.CertifcateAssetName
   $runAsAccountHash.Add("CertName",$CertName)

   $PfxCertPathForRunAsAccount = Join-Path $env:TEMP ($CertName + ".pfx")
   $runAsAccountHash.Add("PfxCertPathForRunAsAccount",$PfxCertPathForRunAsAccount)

   # get password from keyvault #
   $secretvalue = Get-AzKeyVaultSecret -VaultName $KeyVaultHashtable.dxcKeyVaultName -Name $runAsAccountHash.secretAssetName
   $PfxCertPlainPasswordForRunAsAccount = ([System.Net.NetworkCredential]::new("", $secretvalue.SecretValue).Password).ToLower()
   $runAsAccountHash.Add("PfxCertPlainPasswordForRunAsAccount",$PfxCertPlainPasswordForRunAsAccount)

   # creating certificate using keyvault #
   New-SignedCertificate $KeyVaultHashtable $runAsAccountHash -EA Stop -Verbose
   Write-Output ("INFO: Certificate in Keyvault generated successfully.") | timestamp | Write-host -F Green 

   # creating service principal #
   $runAsAccountHash = New-ServicePrincipal $KeyVaultHashtable $runAsAccountHash $AutomationAccountName -EA Stop -Verbose
   Write-Output ("INFO: Service Principal for RunAsAccount created successfully.") | timestamp | Write-host -F Green 

   # creating automation certificate #  
   New-AutomationCertificateAsset $KeyVaultHashtable $runAsAccountHash $dxcResourceGroupName $AutomationAccountName -EA Stop -Verbose
   Write-Output ("INFO: Certificate for RunAsAccount created successfully.") | timestamp | Write-host -F Green 
  
   #creating automation connection asset #
   New-AutomationConnectionAsset $KeyVaultHashtable $runAsAccountHash $dxcSubscriptionID $dxcResourceGroupName $AutomationAccountName -EA Stop -Verbose
   Write-Output ("INFO: Connection for RunAsAccount created successfully.") | timestamp | Write-host -F Green 
   
   Write-Output ("INFO: RunAsAccount created successfully.") | timestamp | Write-host -F Green

 }Catch{
    Write-Output ("ERROR: Creating RunAsAccount Failed. $($_.Exception.Message)") | timestamp | Write-host -F Red
    Write-Output ("ERROR: Script executed with errors in New-RunsAsAccount function. $($_.Exception.Message)" ) | timestamp | Write-host -F Red ; throw
 }
}

function New-SignedCertificate{
  [CmdletBinding(SupportsShouldProcess=$True)]
  param ([hashtable]$KeyVaultHashtable,[hashtable]$runAsAccountHash)
  
  Try{
    $error.Clear()
    Write-Output ("INFO: Generating the certificate using Keyvault...") | timestamp | Write-host -F White
    $certSubjectName = "cn=" + $runAsAccountHash.CertName

    $Policy = New-AzKeyVaultCertificatePolicy -SecretContentType "application/x-pkcs12" -SubjectName $certSubjectName  -IssuerName "Self" -ValidityInMonths $KeyVaultHashtable.SelfSignedCertNoOfMonthsUntilExpired -ReuseKeyOnRenewal
    $AddAzureKeyVaultCertificateStatus = Add-AzKeyVaultCertificate -VaultName $KeyVaultHashtable.dxcKeyVaultName -Name $runAsAccountHash.CertName -CertificatePolicy $Policy 
    
    While ($AddAzureKeyVaultCertificateStatus.Status -eq "inProgress") {
      Start-Sleep -s 10
      $AddAzureKeyVaultCertificateStatus = Get-AzKeyVaultCertificateOperation -VaultName $KeyVaultHashtable.dxcKeyVaultName -Name $runAsAccountHash.CertName -EA Stop
    }
 
    if ($AddAzureKeyVaultCertificateStatus.Status -ne "completed") {
       Write-Output ("ERROR: Generating certificate in keyvault failed. Status is: $($AddAzureKeyVaultCertificateStatus.Status)") | timestamp | Write-host -F Red ; throw
    }

    $cert = Get-AzKeyVaultCertificate -VaultName $KeyVaultHashtable.dxcKeyVaultName -Name $runAsAccountHash.CertName
    $secret = Get-AzKeyVaultSecret -VaultName $KeyVaultHashtable.dxcKeyVaultName -Name $cert.Name -AsPlainText
    $secretByte = [Convert]::FromBase64String($secret)
    $x509Cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($secretByte, "", "Exportable,PersistKeySet")
    $type = [System.Security.Cryptography.X509Certificates.X509ContentType]::Pfx
    $pfxFileByte = $x509Cert.Export($type, $runAsAccountHash.PfxCertPlainPasswordForRunAsAccount)

    # Write to a file
    [System.IO.File]::WriteAllBytes($runAsAccountHash.PfxCertPathForRunAsAccount, $pfxFileByte)

  }Catch{
     Write-Output ("ERROR: Script executed with errors in New-SignedCertificate function. $($_.Exception.Message)" ) | timestamp | Write-host -F Red ; throw
  }
}

function New-ServicePrincipal{
  [CmdletBinding(SupportsShouldProcess=$True)]
  param ([hashtable]$KeyVaultHashtable,[hashtable]$runAsAccountHash,[String]$AutomationAccountName)

  Try{
  $error.Clear()
  Write-Output ("INFO: Creating the Service Principal for the RunAsAccount...") | timestamp | Write-host -F White 

  # Create Service Principal
  $PfxCert = New-Object -TypeName System.Security.Cryptography.X509Certificates.X509Certificate2 -ArgumentList @($runAsAccountHash.PfxCertPathForRunAsAccount, $runAsAccountHash.PfxCertPlainPasswordForRunAsAccount)
  $runAsAccountHash.Add("PfxCert",$PfxCert)

  $keyValue = [System.Convert]::ToBase64String($PfxCert.GetRawCertData())
  $KeyId = [Guid]::NewGuid()

  # Create an Azure AD application, AD App Credential, AD ServicePrincipal

  # Requires Application Developer Role, but works with Application administrator or GLOBAL ADMIN
  $Application = New-AzADApplication -DisplayName $AutomationAccountName -HomePage ("http://" + $AutomationAccountName) -IdentifierUris ("http://" + $keyId) 
  Sleep -s 5
  $runAsAccountHash.Add("ApplicationId",$Application.ApplicationId)

  # Requires Application administrator or GLOBAL ADMIN
  $ApplicationCredential = New-AzADAppCredential -ApplicationId $Application.ApplicationId -CertValue $keyValue -StartDate $PfxCert.NotBefore -EndDate $PfxCert.NotAfter
  # Requires Application administrator or GLOBAL ADMIN
  $ServicePrincipal = New-AzADServicePrincipal -ApplicationId $Application.ApplicationId

  #Sleep here for a few seconds to allow the service principal application to become active (ordinarily takes a few seconds)
  Sleep -s 15
  $NewRole = New-AzRoleAssignment -RoleDefinitionName Contributor -ApplicationId $Application.ApplicationId -EA SilentlyContinue 
  Sleep -s 5

  # Requires User Access Administrator or Owner.
  $Retries = 0;
  While ($NewRole -eq $null -and $Retries -le 6) {
     Sleep -s 10
     New-AzRoleAssignment -RoleDefinitionName Contributor -ApplicationId $Application.ApplicationId -EA SilentlyContinue
     $NewRole = Get-AzRoleAssignment -ServicePrincipalName $Application.ApplicationId -EA SilentlyContinue
     $Retries++;
  }

  if ($NewRole -eq $null){ 
     Write-Output ("ERROR: Creating the Service Principal for the RunAsAccount Failed. You need to have an Azure AD permission of either Global Admin or Application Administrator OR Azure AD User setting with App registration enabled. Kindly contact your Azure Subscription Admin.") | timestamp | Write-host -F Red
     throw
  }

 return $runAsAccountHash

 }Catch{
    Write-Output ("ERROR: Script executed with errors in New-ServicePrincipal function. $($_.Exception.Message)" ) | timestamp | Write-host -F Red ; throw
 }
}

function New-AutomationCertificateAsset{  # this should be in module
  [CmdletBinding(SupportsShouldProcess=$True)]
  param ([hashtable]$KeyVaultHashtable,[hashtable]$runAsAccountHash,[String]$dxcResourceGroupName,[String]$AutomationAccountName)

  Try{
  
    $error.Clear()
    Write-Output ("INFO: Creating Certificate for the RunAsAccount...") | timestamp | Write-host -F White
  
    # Create the automation certificate asset
    $CertPassword = ConvertTo-SecureString $runAsAccountHash.PfxCertPlainPasswordForRunAsAccount -AsPlainText -Force

    Remove-AzAutomationCertificate -ResourceGroupName $dxcResourceGroupName -AutomationAccountName $AutomationAccountName -Name $runAsAccountHash.certifcateAssetName -EA SilentlyContinue
    New-AzAutomationCertificate -ResourceGroupName $dxcResourceGroupName -AutomationAccountName $AutomationAccountName -Path $runAsAccountHash.PfxCertPathForRunAsAccount -Name $runAsAccountHash.certifcateAssetName -Password $CertPassword -Exportable:$Exportable -EA Stop
    Sleep -s 10


   }Catch{
      Write-Output ("ERROR: Creating Certificate for the RunAsAccount Failed. $($_.Exception.Message)") | timestamp | Write-host -F Red
      Write-Output ("ERROR: Script executed with errors in New-AutomationCertificateAsset function. $($_.Exception.Message)" ) | timestamp | Write-host -F Red ; throw
   }
}

function New-AutomationConnectionAsset{  # this should be in module
  [CmdletBinding(SupportsShouldProcess=$True)]
  param ([hashtable]$KeyVaultHashtable,[hashtable]$runAsAccountHash,[String]$dxcSubscriptionID,[String]$dxcResourceGroupName,[String]$AutomationAccountName)

  Try{
   $error.Clear()
   Write-Output ("INFO: Creating Connection for the RunAsAccount...") | timestamp | Write-host -F White

   # Populate the ConnectionFieldValues
   $ConnectionTypeName = "AzureServicePrincipal"
   $ConnectionAssetName = "AzureRunAsConnection"
  
   $SubscriptionInfo = Get-AzSubscription -SubscriptionId $dxcSubscriptionID
   $TenantID = $SubscriptionInfo | Select TenantId -First 1
   $Thumbprint = $runAsAccountHash.PfxCert.Thumbprint

   $ConnectionFieldValues = @{"ApplicationId" = $runAsAccountHash.ApplicationId; "TenantId" = $TenantID.TenantId; "CertificateThumbprint" = $Thumbprint; "SubscriptionId" = $dxcSubscriptionID}

   # Create a Automation connection asset named AzureRunAsConnection in the Automation account. This connection uses the service principal.
   Remove-AzAutomationConnection -ResourceGroupName $dxcResourceGroupName -AutomationAccountName $AutomationAccountName -Name $ConnectionAssetName -Force -EA SilentlyContinue
   New-AzAutomationConnection -ResourceGroupName $dxcResourceGroupName -AutomationAccountName $AutomationAccountName -Name $ConnectionAssetName -ConnectionTypeName $ConnectionTypeName -ConnectionFieldValues $ConnectionFieldValues -EA Stop
   Sleep -s 10


  }Catch{
      Write-Output ("ERROR: Creating Connection for the RunAsAccount Failed.") | timestamp | Write-host -F Red
      Write-Output ("ERROR: Script executed with errors in New-AutomationCertificateAsset function. $($_.Exception.Message)" ) | timestamp | Write-host -F Red ; throw
  }
}

function New-SecretInServicePrincipal{
  [CmdletBinding(SupportsShouldProcess=$True)]
   param ([HashTable]$KeyVaultHashtable,$RunAsConnection, $clientsecretname)

   Try{ 
      $error.clear()
      Write-Output ("INFO: Setting Service Principal Secret for the RunAsAccount...") | timestamp | Write-host -F White

      $clientID = ($RunAsConnection.FieldDefinitionValues).ApplicationId
      $tenantid = ($RunAsConnection.FieldDefinitionValues).TenantId
      $objId=(Get-AzADApplication -ApplicationId $clientID).ObjectID

      $AppCreds=Get-AzADAppCredential -ObjectId $objId | where {$_.Type -eq 'Password'}

      # remove existing secret #
      if($AppCreds){
         if(($AppCreds|Measure-Object).Count -eq 1){
            Remove-AzADAppCredential -ObjectId $objId -KeyId $appCreds.KeyId -Force
         }else{
            foreach($itm in $AppCreds){
               Remove-AzADAppCredential -ObjectId $objId -KeyId $itm.KeyId -Force
            }
         }
      }

      # create a new secret #
      $SecretPlainPassword = [Guid]::NewGuid().ToString().Substring(0, 34) + "!"
      $secretpasswd = ConvertTo-SecureString $SecretPlainPassword -AsPlainText -Force

      $credClientSecret = [psCustomObject]@{name=$clientsecretname;item="Client Secret Asset"; desc="Client Secret of RunAsAccount ServicePrincipal"}
      $setSecret = Set-AzKeyVaultSecret -VaultName $KeyVaultHashtable.dxcKeyVaultName -Name $credClientSecret.name -SecretValue $secretpasswd `
        -Expires ((Get-Date).AddYears(1).ToUniversalTime()) -ContentType $credClientSecret.Desc -EA Stop
   
      #$newAppsecret=New-AzADAppCredential -ObjectId $objId -CustomKeyIdentifier "SelfhealSecret" -Password $secretpasswd -StartDate (Get-Date) -EndDate (Get-Date).AddYears(1)
      New-AzADAppCredential -ObjectId $objId -Password $secretpasswd -StartDate (Get-Date) -EndDate (Get-Date).AddYears(1) | Out-Null
      Start-Sleep -s 20

   }Catch{
      Write-Output ("ERROR: Setting Service Principal Secret for the RunAsAccount Failed.") | timestamp | Write-host -F Red
      Write-Output ("ERROR: Script executed with errors in New-SecretInServicePrincipal function. $($_.Exception.Message)" ) | timestamp | Write-host -F Red ; throw
  }

}

#endregion

#region Functions used by AUTOMATION ACCOUNT and LOGIC APP deployment

function Get-AzCachedAccessToken(){
    $ErrorActionPreference = 'Stop'
  
    if(-not (Get-Module Az.Accounts)) {
        Import-Module Az.Accounts
    }
    $azProfile = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile
    if(-not $azProfile.Accounts.Count) {
        Write-Error ("ERROR: Ensure you have logged in before calling this function.") | timestamp | Write-host -F Red ; throw   
    }
  
    $currentAzureContext = Get-AzContext
    $profileClient = New-Object Microsoft.Azure.Commands.ResourceManager.Common.RMProfileClient($azProfile)
    Write-Debug ("Getting access token for tenant" + $currentAzureContext.Tenant.TenantId)
    $token = $profileClient.AcquireAccessToken($currentAzureContext.Tenant.TenantId)
    
    return $token.AccessToken
}

function Get-AvailableResourceLocation {
    [CmdletBinding(SupportsShouldProcess=$True)]
    param(
        [string]$subscriptionID, 
        [ValidateSet('automationaccount', 'logicapp')]
        [string]$azResourceType
    )

    switch($azResourceType){
        'automationaccount' {$azResourceProvider = 'Microsoft.Automation'}
        'logicapp' {$azResourceProvider = 'Microsoft.Logic'}
    }
    #Get Token
    $token = Get-AzCachedAccessToken
    #Invoke Azure REST
    $header = @{'Authorization'= "Bearer $token" }
    $URI = "https://management.azure.com/subscriptions/$($subscriptionID)/providers/$($azResourceProvider)?api-version=2019-10-01"
    $result = (Invoke-WebRequest -Method Get -Uri $URI -Headers $header -UseBasicParsing -ContentType 'application/json').Content | ConvertFrom-Json

    #Get the available location
    if($azResourceType -eq 'automationaccount'){
        $availableLocation = ($result.resourceTypes | ? {$_.resourceType -eq 'automationAccounts'}).locations
    } elseif ($azResourceType -eq 'logicapp'){
        $availableLocation = ($result.resourceTypes | ? {$_.resourceType -eq 'workflows'}).locations
    }
    
    return $availableLocation
}

function Select-ResourceLocation {
    [CmdletBinding(SupportsShouldProcess=$True)]
    param(
       [String]$dxcSubscriptionID,
       [String]$dxcResourceGroupName,
       [ValidateSet('automationaccount', 'logicapp')]
       [string]$azResourceType
    )
    begin{
        $regions = @("africa","asia","australia","brazil","canada","china","europe","france","germany","india","japan","korea","norway","switzerland","uae","uk")
    }
    process{
        try{
            #Getting the location of resource group
            $rgObj = Get-AzResourceGroup -Name $dxcResourceGroupName -ErrorAction Stop

            switch($azResourceType){
                "automationaccount"{
                    #Getting the available location for automation account
                    $AAsupportedlocations = Get-AvailableResourceLocation -subscriptionID $dxcSubscriptionID -azResourceType automationaccount | ForEach-Object { $_.replace(' ','') }

                    if($AAsupportedlocations -contains ($rgObj.Location)){
                        $azlocation = $rgObj.Location
                    }else{
                        #Available locations does not contain RG loc
                        foreach($region in $regions){
                            if(($rgobj.Location).Contains($region)){
                                $keyregion = $region
                            }
                        }
                        switch($keyregion){
                            "africa" {$azlocation = "southafricanorth"; break}
                            "australia" {$azlocation = "australiacentral"; break}
                            "canada" {$azlocation = "canadacentral"; break}
                            "china" {$azlocation = "chinaeast2"; break}
                            "france" {$azlocation = "francecentral"; break}
                            "germany" {$azlocation = "westeurope"; break}
                            "india" {$azlocation = "centralindia"; break}
                            "japan" {$azlocation = "japaneast"; break}
                            "korea" {$azlocation = "koreacentral"; break}
                            "norway" {$azlocation = "uksouth"; break}
                            "switzerland" {$azlocation = "francecentral"; break}
                            "uae" {$azlocation = "centralindia"; break}
                            "uk" {$azlocation = "uksouth"; break}
                            }
                    }
                }
                "logicapp"{
                    #Getting the available location for logic app
                    $LAsupportedlocations = Get-AvailableResourceLocation -subscriptionID $dxcSubscriptionID -azResourceType logicapp | ForEach-Object { $_.replace(' ','') }

                    if($LAsupportedlocations -contains ($rgObj.Location)){
                        $azlocation = $rgObj.Location
                    }else{
                        #Available locations does not contain RG loc
                        foreach($region in $regions){
                            if(($rgobj.Location).Contains($region)){
                                $keyregion = $region
                            }
                        }
                        switch($keyregion){
                            "australia" {$azlocation = "australiaeast"; break}
                            "canada" {$azlocation = "canadacentral"; break}
                            "china" {if(($rgObj.Location).Contains("east")){$azlocation = "chinaeast"
                                    }else{$azlocation = "chinanorth"}; break}
                            "germany" {$azlocation = "westeurope"; break}
                            "norway" {$azlocation = "uksouth"; break}
                            "switzerland" {$azlocation = "francecentral"; break}
                            "uae" {$azlocation = "centralindia"; break}
                        }
                    }
                }
            }#switch

        } catch {
            Write-Output ("ERROR: Select-ResourceLocation function encountered an error $($_.Exception.Message)") | timestamp | Write-host -F Red ; throw
        }
    }
    end{
        if($azlocation -ne $null){
            return $azlocation
        } else {
            Write-Output ("ERROR: Unable to find available location for $azResourceType resource.") | timestamp | Write-host -F Red ; throw
        }
    }
}

#endregion

#region function used by LOGIC APP Deployment

#--to be removed --
function Connect-APIConnector {
    [CmdletBinding(SupportsShouldProcess=$True)]
    param([String]$dxcResourceGroupName,
          [String]$apiName,
          [String]$dxcSubscriptionID,
          [String]$LogicAppLocation,
          [hashtable]$selfHealTags)

    process{
        try {
            #Checking if there is already an existing API connector.
            $connection = Get-AzResource -ResourceType "Microsoft.Web/connections" -ResourceGroupName $dxcResourceGroupName -ResourceName $apiName -EA Stop
             Write-Output ("INFO: Found API connector: $apiName") | timestamp  | Write-host -F Yellow

             if($connection.Properties.Statuses[0].status -ne 'Connected'){
                Write-Output ("INFO:  Initializing API authorization...") | timestamp | Write-host -F Cyan
                Initialize-ApiAuthorization -ResourceId $connection.ResourceId
                $connection = Get-AzResource -ResourceId $connection.ResourceId -ErrorAction Stop
             }
             
             $tmp=Update-AzTag -ResourceId $connection.ResourceId -Tag $selfHealTags -Operation Merge
             

        } catch {
             if($_.Exception.Message -match "The Resource 'Microsoft.Web/connections/azureautomation'"){
                Write-Output ("Cannot find an existing API connector, creating a new one ...Please WAIT for Login Authentication Window.") | Write-host -F Cyan
                try {
                  #Creating API connection resource
                  $parameters = @{
                    "Properties" = @{"api" = @{"id" = "subscriptions/" + $dxcSubscriptionID + "/providers/Microsoft.Web/locations/" + $LogicAppLocation + "/managedApis/" + $apiName}; "displayName" = $apiName; }
                    "ResourceName" = $apiName
                    "ResourceType" = "Microsoft.Web/connections"
                    "ResourceGroupName" = $dxcResourceGroupName
                    "Location" = $LogicAppLocation
                    "Tag" = $selfHealTags
                    "Force" = $true
                  }
                    $newConnection = New-AzResource  @parameters -ErrorAction Stop
                
                    #Authorize API Connector
                    Write-Output ("INFO: Initializing API authorization...") | timestamp | Write-host -F Cyan
                    Initialize-ApiAuthorization -ResourceId $newConnection.ResourceId
                    $connection = Get-AzResource -ResourceType "Microsoft.Web/connections" -ResourceGroupName $dxcResourceGroupName -ResourceName $apiName -ErrorAction Stop
        
                } catch {
                    Write-Output ("ERROR: Validating API Connector Failed.") | timestamp | Write-host -F Red ; throw
                }

            } else {
                Write-Output ("ERROR: Validating API Connector Failed.") | timestamp | Write-host -F Red ; throw
            }

        }
    }
    end{
        return $connection.Properties.Statuses[0].status
    }
}

#--to be removed --
function Show-OAuthWindow {
    Add-Type -AssemblyName System.Windows.Forms
 
    $form = New-Object -TypeName System.Windows.Forms.Form -Property @{Width=600;Height=800}
    $web  = New-Object -TypeName System.Windows.Forms.WebBrowser -Property @{Width=580;Height=780;Url=($url -f ($Scope -join "%20")) }
    $DocComp  = {
            $Global:uri = $web.Url.AbsoluteUri
            if ($Global:Uri -match "error=[^&]*|code=[^&]*") {$form.Close() }
    }
    $web.ScriptErrorsSuppressed = $true
    $web.Add_DocumentCompleted($DocComp)
    $form.Controls.Add($web)
    $form.Add_Shown({$form.Activate()})
    $form.ShowDialog() | Out-Null
}

#--to be removed --
function Initialize-ApiAuthorization {
    [CmdletBinding(SupportsShouldProcess=$True)]
    param([string]$ResourceId)

    #Getting the links needed for consent
    $parameters = @{
        "parameters" = ,@{
            "parameterName"= "token";
            "redirectUrl"= "https://ema1.exp.azure.com/ema/default/authredirect"
        }
    }
    $consentResponse = Invoke-AzResourceAction -Action "listConsentLinks" -ResourceId $ResourceId -Parameters $parameters -Force
    $url = $consentResponse.Value.Link
    Show-OAuthWindow -URL $url

    $code  = ($Global:uri | Select-string -pattern '(code=)(.*)$').Matches[0].Groups[2].Value
    if (-Not [string]::IsNullOrEmpty($code)) {
        $parameters = @{ "code" = $code  }
        #Confirming the consent code
        Invoke-AzResourceAction -Action "confirmConsentCode" -ResourceId $ResourceId -Parameters $parameters -Force -ErrorAction Ignore 
    }

}

#--to be removed --
function New-SHLogicAppParameter{
    [CmdletBinding(SupportsShouldProcess=$True)]
    param([String]$dxcSubscriptionID,
          [String]$dxcResourceGroupName,
          [String]$apiName,
          [String]$LogicAppLocation,
          [String]$AutomationAccountName,
          [String]$LogicAppName,
          [String]$HybridGrpName,
          [HashTable]$WorkspaceHashTable
    )
    
    #Creating the parameter object
    $conn_externalid=-Join('/subscriptions/',$dxcSubscriptionID, '/resourceGroups/', $dxcResourceGroupName,'/providers/Microsoft.Web/connections/',$apiName)
    $connection_id=-Join('/subscriptions/',$dxcSubscriptionID, '/providers/Microsoft.Web/locations/', $LogicAppLocation ,'/managedApis/',$apiName)
    $RGpath=-Join('/subscriptions/', '@{encodeURIComponent(',"'$dxcSubscriptionID'",')}/resourceGroups/@{encodeURIComponent(',"'$dxcResourceGroupName'",')}/providers/Microsoft.Automation/automationAccounts/@{encodeURIComponent(',"'$AutomationAccountName'",')}/jobs')
    $azParams = @{
        LogicAppName = $LogicAppName
        LogicAppLocation = $LogicAppLocation
        HybridGrpName = $HybridGrpName
        connections_azureautomation_externalid = $conn_externalid 
        connection_id = $connection_id 
        connection_name = $apiName
        resourcegroupname= $dxcResourceGroupName
        automationaccountName= $AutomationAccountName
        diagnosticSettings_name="diagnostics-logicApp"
        workspaceId=$($WorkspaceHashTable.WorkspaceId)
        workspacelocation=$($WorkspaceHashTable.WorkspaceLocation)
        RGpath= $RGpath 
        FailedCOM_MDTC= -Join($RGpath,'/@{encodeURIComponent(body(',"'FailedCOM_MDTC'",')?[',"'properties'",']?[',"'jobId'",'])}/output')
        FailedCOM_MDTC_TriggerBackup= -Join($RGpath,'/@{encodeURIComponent(body(',"'FailedCOM_MDTC-TriggerBackup'",')?[',"'properties'",']?[',"'jobId'",'])}/output')
        FailedVssWriter= -Join($RGpath,'/@{encodeURIComponent(body(',"'FailedVssWriter'",')?[',"'properties'",']?[',"'jobId'",'])}/output')
        FailedVssWriter_TriggerBackup= -Join($RGpath,'/@{encodeURIComponent(body(',"'FailedVssWriter-TriggerBackup'",')?[',"'properties'",']?[',"'jobId'",'])}/output')
        BackupInProgress= -Join($RGpath,'/@{encodeURIComponent(body(',"'BackupInProgress'",')?[',"'properties'",']?[',"'jobId'",'])}/output')
        BackupInProgress_TriggerBackup= -Join($RGpath,'/@{encodeURIComponent(body(',"'BackupInProgress-TriggerBackup'",')?[',"'properties'",']?[',"'jobId'",'])}/output')
        fixWindowsAgent= -Join($RGpath,'/@{encodeURIComponent(body(',"'fixWindowsAgent'",')?[',"'properties'",']?[',"'jobId'",'])}/output')
        fixWindowsAgent_TriggerBackup= -Join($RGpath,'/@{encodeURIComponent(body(',"'fixWindowsAgent-TriggerBackup'",')?[',"'properties'",']?[',"'jobId'",'])}/output')
        fixLinuxAgent= -Join($RGpath,'/@{encodeURIComponent(body(',"'fixLinuxAgent'",')?[',"'properties'",']?[',"'jobId'",'])}/output')
        fixLinuxAgent_TriggerBackup= -Join($RGpath,'/@{encodeURIComponent(body(',"'fixLinuxAgent-TriggerBackup'",')?[',"'properties'",']?[',"'jobId'",'])}/output')
        BackupInProgress_Lite= -Join($RGpath,'/@{encodeURIComponent(body(',"'BackupInProgress-Lite'",')?[',"'properties'",']?[',"'jobId'",'])}/output')
        BackupInProgress_Lite_TriggerBackup= -Join($RGpath,'/@{encodeURIComponent(body(',"'BackupInProgress-Lite-TriggerBackup'",')?[',"'properties'",']?[',"'jobId'",'])}/output')
        OtherErrCode_Lite_TriggerBackup= -Join($RGpath,'/@{encodeURIComponent(body(',"'OtherErrCode-Lite-TriggerBackup'",')?[',"'properties'",']?[',"'jobId'",'])}/output')
        Validate_ErrorforSelfHeal= -Join($RGpath,'/@{encodeURIComponent(body(',"'Validate-ErrorforSelfHeal'",')?[',"'properties'",']?[',"'jobId'",'])}/output')
    }

    return $azParams
}

#endregion

#region function used by Custom LOG deployment...

# Create the authorization signature. Note: This function is adopted from: https://docs.microsoft.com/en-us/azure/azure-monitor/platform/data-collector-api
Function Build-Signature ($customerId, $sharedKey, $date, $contentLength, $method, $contentType, $resource)
{
    $xHeaders = "x-ms-date:" + $date
    $stringToHash = $method + "`n" + $contentLength + "`n" + $contentType + "`n" + $xHeaders + "`n" + $resource

    $bytesToHash = [Text.Encoding]::UTF8.GetBytes($stringToHash)
    $keyBytes = [Convert]::FromBase64String($sharedKey)

    $sha256 = New-Object System.Security.Cryptography.HMACSHA256
    $sha256.Key = $keyBytes
    $calculatedHash = $sha256.ComputeHash($bytesToHash)
    $encodedHash = [Convert]::ToBase64String($calculatedHash)
    $authorization = 'SharedKey {0}:{1}' -f $customerId,$encodedHash
    return $authorization
}

# Create and post the request. Note: This function is adopted from: https://docs.microsoft.com/en-us/azure/azure-monitor/platform/data-collector-api
Function Post-LogAnalyticsData ($customerId, $sharedKey, $body, $logType)
{

    $method = "POST"
    $contentType = "application/json"
    $resource = "/api/logs"
    $rfc1123date = [DateTime]::UtcNow.ToString("r")
    $contentLength = $body.Length
    $signature = Build-Signature `
        -customerId $customerId `
        -sharedKey $sharedKey `
        -date $rfc1123date `
        -contentLength $contentLength `
        -method $method `
        -contentType $contentType `
        -resource $resource
    $uri = "https://" + $customerId + ".ods.opinsights.azure.com" + $resource + "?api-version=2016-04-01"

    $headers = @{
        "Authorization" = $signature;
        "Log-Type" = $logType;
        "x-ms-date" = $rfc1123date;
    }


    
    $response = Invoke-WebRequest -Uri $uri -Method $method -ContentType $contentType -Headers $headers -Body $body -UseBasicParsing
    return $response.StatusCode
}
#endregion

Export-ModuleMember -Function Validate-Checks, Find-KeyVault, New-RunsAsAccount, Select-ResourceLocation, Connect-APIConnector, `
Post-LogAnalyticsData, New-SecretInServicePrincipal
