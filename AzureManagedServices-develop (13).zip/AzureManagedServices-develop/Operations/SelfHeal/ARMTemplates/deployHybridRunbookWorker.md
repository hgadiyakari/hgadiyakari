## Deploy the Hybrid Runbook Worker

#### Overview
The Hybrid Runbook Worker is a feature in Azure Automation that enables remote local execution of runbooks on targets hosts from Azure. For Self-heal automation, this service will extend "in-VM" troubleshooting and fixes.

While existing features such as *RunCommand*, also provides this ability, it is dependent on Azure VM Agent service. As with cases of backup failures relating to Azure Agent services ([see article](https://docs.microsoft.com/en-us/azure/backup/backup-azure-vms-troubleshoot)), if this service is down or in hung state (WindowsAzureGuestAgent/walinuxagent), Self-heal automation may not apply and fail immediately using said feature because of this dependency.

Hybrid Runbook Worker on the other hand, has the functionality to address this limitation since it can execute runbooks locally against target resources you want to manage in your environment using user-provided credentials.

To summarize, the Hybrid Runbook Worker can be described with the following -
- report to an Automation Account
- run and manage runbooks directly on a target computer
- for authentication, use [*RunAs certificate*]() to Azure resources and a [*credential asset*](https://docs.microsoft.com/en-us/azure/automation/shared-resources/credentials) to local resource (a target computer)
- depend on the Log Analytics agent - Microsoft Monitoring Agent (Windows) or OMS Agent for Linux (Linux) 

The Hybrid Runbook Worker VM resource should meet the minimum system and network requirements to operate correctly as outlined [here](https://docs.microsoft.com/en-us/azure/automation/automation-windows-hrw-install).

#### Solution approach

An automation script and ARM template were created to deploy and configure the Hybrid Runbook Worker VM in the subscription. 

- deployHybridRunbookWorker.ps1 - script that deploys the ARM template, configures required settings for the Hybrid Runbook Worker. Includes validation of parameters.
  - allows two options for deployment:
    - a) deploy - automates VM creation from an ARM template and runs post-configuration settings.
    - b) addRole - automates configuration of Hybrid Runbook role on an existing VM resource.
  - allows the following parameters:

    | Parameter | Type |Mandatory| Description |
    |:--- |:--- |:---|:---
    |subscriptionId|string|Yes|Id of the Azure subscription|
    |logAnalyticsWorkspaceName|string|Yes|Name of the managed workspace|
    |automationAccountName|string|Yes|Automation account name used in Self-heal (-SH)
    |keyvaultName|string|No|Name of the key vault resource

  - uses an input file (*deployHybridRunbookWorker_config.txt*) which is manually filled out to capture ARM template parameters (for deploy option)
  - adds a service account as credential asset to the Automation Account
- deployHybridRunbookWorker.json - ARM template that contains Azure resources required for the Hybrid Runbook Worker role. Includes VM extensions - Microsoft Monitoring Agent (MMA) and custom script (HybridRunbookWorker)
  - uses Marketplace images of Windows OS versions - 2016-Datacenter (default), 2019-Datacenter
  - uses the following standard VM sizes per [minimum requirement](https://docs.microsoft.com/en-us/azure/automation/automation-windows-hrw-install#minimum-requirements-for-windows-hybrid-runbook-worker) (2vCpus, 8Gb) - Standard_B2ms (default), Standard_D2_v3
  
    | Parameter | Type | Details | Input method |
    |:--- |:--- |:---|:---
    |adminUsername|string|Administrator username for the Hybrid Runbook Worker VM.|Input from script|
    |adminPassword|secureString|Password for the Hybrid Runbook Worker VM. Should contain any 3 of: 1 Lower Case, 1 Upper Case, 1 Number and 1 Special character.|Input from script|
    |windowsOSVersion|string|The Windows version for the Virtual Machine. This will pick a fully patched image of this given Windows version. Allowed values: 2016-Datacenter, 2019-Datacenter.|Default value set to "2016-Datacenter"|
    |vmName|string|The virtual machine name to identify the Hybrid Runbook Worker resource in alphanumeric value with maximum limit of 15 characters.|Input from config file|
    |vmSize|string|The VM size of the Hybrid Runbook Worker resource. Allowed values: Standard_A2_v2, Standard_B2s, Standard_B2ms, Standard_D2_v3.|Default value set to "Standard_B2s"|
    |vmLocation|string|Location or datacenter where the VM will be placed.|Input from config file|
    |existingVnetResourceGroup|string|Resource group of the existing Virtual Network.|Input from config file|
    |existingVnetName|string|Existing Virtual Network to connect to Network Interface to. It should be in the same location as the Virtual Machine.|Input from config file.|
    |subnetName|string|The subnet from virtual network for the Virtual Machine.|Input from config file|
    |publicIPRequired|string|Does this VM needs a public IP? Allowed values: yes, no.|Input from config file|
    |existingdiagnosticsStorageResourceGroup|string|Resource group of the existing storage account used for diagnostics data.|Input from config file|
    |existingdiagnosticsStorageAccountName|string|Existing storage account used for diagnostics data.|Input from config file|
    |securityAgent|string|What security agent will be deployed? (crowdstrike/symantec)|Input from config file|
    |csCID|string|Client ID with checksum for Falcon CrowdStrike|Input from config file|
    |csUninstallPW|string|Password to prevent uninstall of Crowdstrike|Input from script|
    |SymantecCustomerId|string| The CustomerId of Symantec CWP extension|Input from script|
    |SymantecDomainId|string| The domainId of Symantec CWP extension|Input from script|
    |SymantecClientId|string| The clientId of Symantec CWP extension|Input from script|
    |SymantecCustomerSecretKey|string| The customerSecretKey of Symantec CWP extension|Input from script|
    |SymantecClientSecretKey|string| The clientSecretKey of Symantec CWP extension|Input from script|
    |existingRecoveryServicesVaultRG|string| Resource group of the existing Recovery Vault.|Input from config file|
    |existingRecoveryServicesVault|string| Existing Recovery Vault where the VM backup will be stored.|Input from config file|
    |existingBackupPolicy|string| Existing Backup Policy where the VM will be attached to. Allowed values: DefaultPolicy/DXC30day/DXC60day/DXC90day |Input from config file|
    |patchGroup|string| Specify the group (update deployment schedule) for system updates/patches (ie. Windows2016). This is for tagging purposes only.|Input from config file|

Supporting automation scripts will also be executed to enable the Hybrid Runbook Worker role -
- Configure-HybridWorker.ps1 - This run command script will install the required packages, modules and settings required to function as a Hybrid Runbook Worker. 
- Export-RunAsCertificateToHybridWorker.ps1 - This runbook exports the Run As certificate from an Azure Automation account to a Hybrid Runbook Worker. 


#### Prerequisites
 
Ensure all the pre-requisites are prepared and met –
- Access to subscription with Owner role privileges
- PowerShell version 5.0 or higher
- Az module version 2.5 or higher

  
The following port and URLs are required for the Hybrid Runbook Worker role to communicate with Automation:
- Port: Only TCP 443 is required for outbound internet access.
- Global URL: *.azure-automation.net
- Global URL of US Gov Virginia: *.azure-automation.us
- Agent service: https://<LogAnalyticsWorkspaceId>.agentsvc.azure-automation.net

The following configurations are required for Hybrid Runbook Worker runbook executions (on clients/targets):
- Allow inbound rules for WinRM (port 5986) in security rules
- Enable PowerShell remoting (Enable-PSRemoting) on Windows OS-type VMs
- Service account with admin/sudo privileges on VMs
  
Collect the following details for the required input parameters –
- Automation account (existing automation account created and used by self-heal, name uses a suffix *-SH*)
- Log Analytics workspace onboarded for the subscription
- Local administrator credentials (choose a username and password to use for the Hybrid Runbook Worker VM)
- Service account (an account local to VMs in environment for remote script execution)
- Resourcegroup (choose an existing resource group to deploy the Hybrid Runbook Worker VM)
- Virtual machine name (choose a preferred name to identify the Hybrid Runbook Worker VM or nominate an existing VM resource for the role; should meet system and network requirements below.)
- Virtual machine location (choose a supported location for the Hybrid Runbook Worker VM)
- Virtual network (choose an existing virtual network in the subscription, should be on same location as Virtual machine location)
- Virtual network resourcegroup (the resourcegroup of the chosen virtual network)
- Virtual network subnet (select a subnet from the virtual network chosen)
- Storage account (select an existing storage account used for diagnostics data)
- Storage account resourcegroup (the resourcegroup of the chosen storage account)
- CrowdStrike registration details (CrowdStrike client ID, security password)
- Symantec registration details (Customer Id, Domain Id, Client Id, Customer secret key, Client secret key)
- Recovery Vault Resourcegroup (choose an existing recovery vault resource group where the Hybrid Runbook Worker VM backup will be stored)
- Recovery Vault (choose an existing recovery vault where the Hybrid Runbook Worker VM backup will be stored)
- Backup Policy (choose an existing backup policy for the Hybrid Runbook Worker VM to be attached to)
- Patch Group (specify the group (update deployment schedule) for system updates/patches (ie. Windows2016). This is for tagging purposes only.)
#### Script execution

   IMPORTANT: There are 2 modes of deployment available for the Hybrid Runbook Worker resource. Determine which would be more appropriate in your environment. Please ensure the system and network requirements are considered and met prior to deployment.

##### __MODE 1: Deploy - Create a VM resource and set up the Hybrid Runbook Worker role__
This option creates a new Windows VM resource and setup the instance with the required configuration. An ARM template is provided in the script directory and will be used for deployment which contains the resources and required extensions to function as runbook worker with Automation Account.

1. Download the script package from the GitHub repository ***AzureOffering_ServiceNow*** to your preferred directory.

2. Open Windows Explorer, browse to ***.\AzureOffering_ServiceNow\SelfHeal\arm-templates*** and modify the input file *deployHybridRunbookWorker_config.txt* with the required VM specifications:
  - vmResourceGroup - Resource group where the Hybrid Runbook Worker virtual machine will be hosted.
  - vmName - The virtual machine resource name of the Hybrid Runbook Worker, must not exceed 15 characters. Can't use \/""[]:|<>+=;,?*@&.
  - vmLocation - Location or region where the Hybrid Runbook Worker virtual machine will be placed. Use supported locations in Azure.
  - existingvNetResourceGroup - Resource group of an existing virtual network where the Hybrid Runbook Worker VM will be connected to.
  - existingvNet - Existing virtual network where the Hybrid Runbook Worker VM will be connected to. Should be same as with *vmLocation*.
  - existingvNetSubnet - Existing subnet from the virtual network where the Hybrid Runbook Worker VM will be connected to.
  - publicIPRequired - Does this VM needs a public IP? (yes/no). Default value is set as *no*.
  - existingDiagStorageResourceGroup - Storage account resource group name where boot diagnostics will be stored.
  - existingDiagStorageName - Storage account name where boot diagnostics will be stored. Should be co-located with VM.
  - securityAgent - What security agent will be deployed? (crowdstrike/symantec)
  - csCID - Client ID with checksum for Falcon CrowdStrike (not required if Symantec is selected)
  - SymantecCustomerId - The CustomerId of Symantec CWP extension (not required if CrowdStrike is selected)
  - SymantecDomainId - The domainId of Symantec CWP extension (not required if CrowdStrike is selected)
  - SymantecClientId - The clientId of Symantec CWP extension (not required if CrowdStrike is selected)
  - existingRecoveryServicesVaultRG - Recovery vault resource group name where VM backup will be stored.
  - existingRecoveryServicesVault - Recovery vault name where VM backup will be stored.
  - existingBackupPolicy - Backup policy where VM will be attached to.
  - patchGroup - Specify the group (update deployment schedule) for system updates/patches (ie. Windows2016). This is for tagging purposes only.
  
3. Open PowerShell console (run as Administrator) and switch to script directory ***.\AzureOffering_ServiceNow\SelfHeal\arm-templates*** .

4. Execute the following command -
    ```
    .\deployHybridRunbookWorker.ps1 -subscriptionId <SUBSCRIPTION_ID> -logAnalyticsWorkspaceName <WORKSPACE_NAME> `
        -automationAccountName <AUTOMATION_ACCOUNT> -keyVaultName <KEYVAULT_NAME>
    ```
    Note: 
    - subscriptionId - Subscription ID where the Hybrid Runbook VM is to be created.
    - logAnalyticsWorkspaceName - Managed Log Analytics workspace name onboarded for the subscription.
    - automationAccountName - Automation account name used by Self-heal automation (-SH).
    - keyVaultName - Key vault name for credentials (optional)
  
    4.1 Once script executes, you will be prompted to select a deployment option. You need to type in your choice to proceed.
    ```
    CONFIRM: Please select and confirm deployment mode for the Hybrid Runbook Worker resource:
    Type 'deploy' to create a new VM resource and set up the Hybrid Runbook Worker role.
    Type 'addRole' to set up an existing Windows VM with the Hybrid Runbook Worker role only.
    Type 'quit' to exit.
    ```   
    4.2 Type in ```deploy``` to continue and script will start to validate all input from the config file and parameters provided.
    ```
    You have chosen DEPLOY mode. A new VM resource will be created and setup as a Hybrid Runbook Worker.
    ```
    4.3 After validation of script parameters, you will be prompted for credentials. You will need to provide sets of credentials - a) Local administrator for the Hybrid Runbook Worker and b) a service account for the Automation Account credential asset c) security agent installation - CrowdStrike (uninstall password); Symantec details will be obtained automatically from the key vault.
    ```    
    CONFIRM: Provide the credentials for the Hybrid Runbook Worker.
    This will be used as the
    local administrator account of the Hybrid Runbook Worker.
    If you have entered a key vault, you may choose to create or use an existing secret.
    The secret provided will be automatically detected in the key vault if it exists. Otherwise, it will create a new one. 
    Enter the secret name for for the Hybrid Runbook Worker: dxc-admin
    
    CONFIRM: Provide the uninstall password for CrowdStrike.
    If you have entered a key vault, you may choose to create or use an existing secret.
    The secret provided will be automatically detected in the key vault if it exists. Otherwise, it will create a new one.
    Enter the secret name for Password to prevent CrowdStrike uninstall: csUninstallPW

    CONFIRM: Provide the credential asset for the Automation Account.
    This will be used as a
    service account by the Hybrid Runbook Worker
    to authenticate against VM resources. Please enter a valid service account, otherwise you need to create this first before proceeding further.
    The secret provided will be automatically detected in the key vault if it exists. Otherwise, it will create a new one.
    Enter the secret name for for the Automation Account Credential Asset: serviceaccount
    ```
    If you have supplied a key vault in the script parameter and a matching secret is found, the secret value will automatically be obtained. Otherwise, you will be prompted for a password for registration.
    
    4.4 Once credentials are secured, script will continue with the validation and proceed to resource deployment without additional user prompts.

 1. Wait until script execution completes.

 2. Validate the deployment from the Portal and check the following:
 - Virtual machine instance and extensions (status should be 'Provisioning succeeded').
   - Microsoft Monitoring Agent (Microsoft.EnterpriseCloud.Monitoring.MicrosoftMonitoringAgent)
   - HybridRunbookWorker (Microsoft.Compute.CustomScriptExtension)
 - Automation account > Hybrid Worker groups
   - Check if group name *selfheal-group* is created.
   - Click on the group and select *Hybrid Workers*, check the VM created under Worker name.
 - Automation account > Process Automation > Jobs. Check if runbook "Export-RunAsCertificateToHybridWorker" completed.

##### __MODE 2: Add Role - Set up an existing Windows VM resource as a Hybrid Runbook Worker__
If you choose to create your VM resource using your ARM template or use an existing VM resource. Please ensure the system requirements match for Hybrid Runbook Worker role. This option will install a VM extension that will run required configuration  scripts to function  properly with the Automation Account. 

1. Download the script package from the GitHub repository ***AzureOffering_ServiceNow*** to your preferred directory.
   
2. Open PowerShell console (run as Administrator) and switch to script directory ***.\AzureOffering_ServiceNow\SelfHeal\arm-templates*** .
3. Execute the following command -
    ```
    .\deployHybridRunbookWorker.ps1 -subscriptionId <SUBSCRIPTION_ID> -logAnalyticsWorkspaceName <WORKSPACE_NAME> `
        -automationAccountName <AUTOMATION_ACCOUNT> -keyVaultName <KEYVAULT_NAME>
    ```
    Note: 
    - subscriptionId - Subscription ID where the Hybrid Runbook VM is to be created.
    - logAnalyticsWorkspaceName - Managed Log Analytics workspace name onboarded for the subscription.
    - automationAccountName - Automation account name used by Self-heal automation (-SH).
    - keyVaultName - Key vault name for credentials (optional)

   3.1 Once script executes, you will be prompted to select a deployment option. You need to type in your choice to proceed.
    ```
    CONFIRM: Please select and confirm deployment mode for the Hybrid Runbook Worker resource:
    Type 'deploy' to create a new VM resource and set up the Hybrid Runbook Worker role.
    Type 'addRole' to set up an existing Windows VM with the Hybrid Runbook Worker role only.
    Type 'quit' to exit.
    ```   
    3.2 Type in ```addRole``` to continue and you will be prompted to provide the virtual machine name and its resourcegroup.
    ```
    You have chosen ADDROLE mode. Your nominated Windows VM resource will be configured as a Hybrid Runbook Worker.
    Enter an existing Windows VM to configure the Hybrid Runbook Worker role on: dxc-vm
    Enter the resourcegroup of hybridworkerA: dxc-resourcegroup
    ```
    3.3 After validation of script parameters, you will be prompted for credentials. You will need to provide two sets of credentials - a) Local administrator for the Hybrid Runbook Worker and b) a service account for the Automation Account credential asset.  
    ``` 
    CONFIRM: Provide the credential asset for the Automation Account.
    This will be used as a
    service account by the Hybrid Runbook Worker
    to authenticate against VM resources. Please enter a valid service account, otherwise you need to create this first before proceeding further.
    The secret provided will be automatically detected in the key vault if it exists. Otherwise, it will create a new one.
    Enter the secret name for for the Automation Account Credential Asset: serviceaccount
    ```
    If you have supplied a key vault in the script parameter and a matching secret is found, the secret value will automatically be obtained. Otherwise, you will be prompted for a password for registration.

    3.4 The script will continue to configure the Windows VM resource with required modules and settings to register as Hybrid Runbook Worker.

4. Wait until script execution completes.

5. Validate the deployment from the Portal and check the following:
 - Automation account > Hybrid Worker groups
   - Check if group name *selfheal-group* is created.
   - Click on the group and select *Hybrid Workers*, check the VM created under Worker name.
 - Automation account > Process Automation > Jobs. Check if runbook "Export-RunAsCertificateToHybridWorker" completed.


##### References:
- [Automation of Hybrid Runbook Worker](https://docs.microsoft.com/en-us/azure/automation/automation-hybrid-runbook-worker)
- [Automation Security Overview](https://docs.microsoft.com/en-us/azure/automation/automation-security-overview)
- [Shared resources credentials](https://docs.microsoft.com/en-us/azure/automation/shared-resources/credentials)
- [Run runbooks in Hybrid Runbook Worker](https://docs.microsoft.com/en-us/azure/automation/automation-hrw-run-runbooks)
- [Automation Credentials for Hybrid Worker](https://confluence.dxc.com/display/ESCAT/AZR-9976%3A+REVIEW+AUTOMATION+CREDENTIALS+FOR+HYBRID+WORKER)
- [Credential assets management for Hybrid Worker](https://confluence.dxc.com/display/ESCAT/Credential+assets+management+for+Hybrid+Worker)
