﻿# Recycle OMS service on Linux VMs

This folder contains files that are used to Restart a Linux OMS Agent

The Log Analytics agent collects monitoring data from the guest operating system and workloads of virtual machines in Azure, other cloud providers, 
and on-premises. It collects data into a Log Analytics workspace. The Log Analytics agent for Windows is often referred to as 
Microsoft Management Agent (MMA).

## Jira Epic
https://jira.dxc.com/browse/AZR-12116

## Deployment
For more information please see:
https://confluence.dxc.com/display/ESCAT/Recycle+OMS+service+on+Linux+VMs

This script was developed to perform a clean restart of the OMS agent services on Linux VMs that includes -
 - Stopping and restarting OMS agent service
 - Stopping and restarting OMS agent processes
 - Running <em>PerformRequiredConfigurationChecks.py</em>

#### Prerequisites:
- PowerShell 5.1 or higher
- Az module 2.0 or higher

#### Script execution:
1. Download and extract the script package.
2. Edit the file, ***serverlist.txt*** and input target hosts (VM names) for remediation.
3. Open PowerShell console (run as Administrator) and execute from downloaded directory -
```
.\restartLinuxOMSAgent.ps1 -dxcSubscriptionId <SUBSCRIPTIONID>
```
4. Wait until script execution finishes and review results from the log file output.

## Authors
* Aquino Angelica M,
