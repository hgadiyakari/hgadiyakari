
#-----------------------------------------------------------[Comments]-------------------------------------------------------------
<#
.SYNOPSIS
This automation script runs omsagent-clean-restart.sh to target Linux Azure VM.
omsagent-clean-restart.sh , stops omsagent (including omi server) , kills running processes related to omsagent, and then start omsagent (including omi server).

The following are required as input -
    - Subscription ID
    - Text File that contains the list of VMs. Make sure that it is in your current directory.

.REVISION HISTORY
   23-Jan-2020 - Initial script development 
#>

#---------------------------------------------------------[Initializations]-------------------------------------------------------- 

[CmdletBinding()]
Param (
    [Parameter(HelpMessage = "Please enter your Subscription ID.", Position=1, Mandatory=$True, ValueFromPipeline=$True)]
    [ValidateNotNullOrEmpty()][string]$dxcSubscriptionID
)

#----------------------------------------------------------[Declarations]----------------------------------------------------------
$Global:vm = ""
$functionName = "Linux-OMSAgentRestart"
$Global:LogFilePath = (Get-Item -Path .\ -Verbose).FullName + '\' +$functionName + '-{0:dd-MMM-yyyy_HHmm}' -f (Get-Date) + '.log'
$ErrorActionPreference = 'SilentlyContinue'
$TxtFile= "serverlist.txt"

$dxcScriptFileUri = "https://dxcazuretoolsdev.blob.core.windows.net/forautomation/AgentFix/"
$dxcScript = "omsagent-clean-restart.sh"
$Error.Clear()

#-----------------------------------------------------------[Functions]------------------------------------------------------------

function Write-Log([string]$Text,[int]$Flag){ #This function writes script messages to log file.
$timeStamp = Get-Date -Format MM-dd-yyyy-hh:mm:ss
Switch($Flag){
    0 {Write-Output "$timeStamp INFO: $Text"| Tee-Object -FilePath $Global:LogFilePath -Append | Out-Null; # INFORMATION
        Write-Host -F White "$timeStamp INFO: $Text"}
    1 {Write-Output "$timeStamp ERROR: $Text"| Tee-Object -FilePath $Global:LogFilePath -Append | Out-Null; # ERROR
        Write-Host -F Red "$timeStamp ERROR: $Text"}
    2 {Write-Output "$timeStamp WARN: $Text"| Tee-Object -FilePath $Global:LogFilePath -Append | Out-Null; # WARNING
        Write-Host -F Yellow "$timeStamp WARN: $Text"}
    3 {Write-Output "$timeStamp : $Text"| Tee-Object -FilePath $Global:LogFilePath -Append | Out-Null; # Use for prompts
        Write-Host -F Cyan "$timeStamp : $Text"}
    4 {Write-Output "$timeStamp : $Text"| Tee-Object -FilePath $Global:LogFilePath -Append | Out-Null; # OK
        Write-Host -F Green "$timeStamp : $Text"}
    5 {Write-Output "$timeStamp : $Text"| Tee-Object -FilePath $Global:LogFilePath -Append | Out-Null; # OK
        Write-Host -F White "$timeStamp : $Text"}
}
}



############################################################################
#                             MAIN Program                                 #
############################################################################

try {

Write-Host -F Yellow (Get-Date -Format MM-dd-yyyy-hh:mm:ss) ": Script execution STARTED."

# # # # # LOG FILE CREATION # # # # #
New-Item $Global:LogFilePath -ItemType File | Out-Null


# # # # # Download Log Analytics Agent Restart Script # # # # #

$dxcfileURLforDownload = $dxcScriptFileUri + $dxcScript
$dxcScriptFilePath = Join-Path (Get-Location).ProviderPath $dxcScript
(New-Object System.Net.WebClient).DownloadFile($dxcfileURLforDownload, $dxcScriptFilePath)

if ($Error) { Write-Log "Unable to download AgentRestart script. Try downloading manually from here: $dxcfileURLforDownload " 2; exit} 
else { Write-Log "Script downloaded at $dxcScriptFilePath " 0}


# # # # # LOGIN SECTION # # # # #
Write-Log "Please login to Azure Resource Manager." 3

Connect-AzAccount -Subscription $dxcsubscriptionID | Out-Null

If ($Error) {Write-Log "Unable to connect to Azure. Check your internet connection and verify authentication details." 1;exit}
Write-Log "Connected to Azure with provided authentication." 0

Start-Sleep 3

# # # # # Validate VMs and VM List File # # # # #

if ($TxtFile -ne '') {
   $CheckFile = Test-Path $TxtFile
       if (  $CheckFile -eq "True" ) { 
        $GetVMList = Get-Content $TxtFile
       $VMCheckResult=@()
       $VMlist = @($GetVMList)
          if ((Get-Content $($TxtFile)) -eq $null ) {
              Write-Log "$($TxtFile) is empty. No VM to check. `n" 2;Start-Sleep 1;exit}                       
       } else { Write-Log "$($TxtFile) file does not exist. Text File that contains the list of VMs. `n" 2
                  Write-Log "Make sure that it is in you current directory. " 2 ;Start-Sleep 1;exit}
}


# # # # # # Start of loop

$VMCheckResult = foreach($vmitem in $VMlist) {   #Start of foreach

# # # Run valdation on VM

Write-Log "Running VM validation on $($vmitem)" 0

$Global:vm = Get-AzResource -ResourceType Microsoft.Compute/virtualMachines -Name $vmitem #Check if VM exists in the subscription

if ($Global:vm -eq $null) {       
        $VMCheck = "NO"
        $OSProfile = "==="
        $VMState = "===" 
        $LogAnalyticsAgent = "==="
        $CheckFlag = "NOK"
        $VMResult = "NOT APPLIED"
        $VMResultMessage = "No message"
} else {    
    $VMCheck = "YES"
    $GetOS = Get-AzVM -ResourceGroupName $Global:vm.ResourceGroupName -Name $Global:vm.Name -ErrorAction SilentlyContinue  #Check OS type of VM 
    $vmCheckState = (Get-AzVM -ResourceGroupName $Global:vm.ResourceGroupName -Name $Global:vm.Name -Status).Statuses[1].DisplayStatus   #Check if VM is running or not
         
       if ( $GetOS.OSProfile.LinuxConfiguration.ProvisionVMAgent -eq $true) {
            $OSProfile="Linux" 
       } elseif  ( $GetOS.OSProfile.LinuxConfiguration.ProvisionVMAgent -ne $true) {
            $OSProfile="Windows" 
       }else { $OSProfile="===" }
                    
       if ($vmCheckState -eq 'VM running' ) {
            $VMState="Running"
       }elseif ( $vmCheckState -eq 'VM deallocated') {
            $VMState="Deallocated"
        } else { $VMState ="NotRunning"} 
    
    $LogAnalyticsAgent = ((Get-AzVMExtension -ResourceGroupName $Global:vm.ResourceGroupName -VMName $Global:vm.Name) | ? {($_.ExtensionType -eq 'OmsAgentForLinux') -or ($_.ExtensionType -eq 'MicrosoftMonitoringAgent')}).ProvisioningState
    if ($LogAnalyticsAgent  -eq $null) {
        $LogAnalyticsAgent = "==="}
 

} #end of validation


Write-Log "$($vmitem) - Found in subscription: $($VMCheck), OStype: $($OSProfile), State: $($VMState), LogAnalyticsAgent: $LogAnalyticsAgent " 0


If (( ($OSProfile -eq "Linux") -and ($vmCheckState -eq 'VM running') ) -and ($Global:vm.Name -eq $vmitem) -and ($LogAnalyticsAgent -eq "Succeeded")) {

$dxcAgentRestartResult = Invoke-AzVMRunCommand -ResourceGroupName $Global:vm.ResourceGroupName -Name $Global:vm.Name -CommandId 'RunShellScript' `
                        -ScriptPath (Join-Path (Get-Location).ProviderPath $dxcScript) -ErrorAction $ErrorActionPreference

if ($dxcAgentRestartResult.Value[0].Message.Contains("No Workspace") -Or $dxcAgentRestartResult.Value[0].Message.Contains("NOT running") -Or `
           $dxcAgentRestartResult.Value[0].Message.Contains("PerformRequiredConfigurationChecks NOT Found") `
            -Or $dxcAgentRestartResult.Value[0].Message.Contains("ERROR")) {
           
               Write-Log "Restarting OMS agent on $($Global:vm.Name) UNSUCCESSFUL." 1
               Write-Log "Error Message is : $($dxcAgentRestartResult.Value[0].Message)" 1
               $VMResultMessage = $dxcAgentRestartResult.Value[0].Message
               $VMResult = "$($Global:vm.Name) UNSUCCESSFUL"
               Start-Sleep 3
        
           }else {             
               Write-Log "Restarting OMS agent on $($Global:vm.Name) SUCCESSFUL." 4
               Write-Log "$($dxcAgentRestartResult.Value[0].Message)" 4
               $VMResultMessage = $dxcAgentRestartResult.Value[0].Message
               $VMResult = "$($Global:vm.Name) SUCCESSFUL"
               Start-Sleep 3
               }

} else {
$VMResult = "NOT APPLIED"
$VMResultMessage = "No message"
}


[pscustomobject]@{
    VMName =  $vmitem
    VMExistsInSubscription = $VMCheck
    OSType  = $OSProfile
    LogAnalyticsAgent = $LogAnalyticsAgent
    VMState = $VMState
    StatusMessage = $VMResultMessage
    Output =  $VMResult
    }


} #End of for loop

Write-Output $VMCheckResult
$VMCheckResult >> $Global:LogFilePath

} catch {
Write-Log "Unable to restart OMS agent. $Error." 1
   
} finally {
Disconnect-AzAccount | Out-Null
Write-Log "Disconnected from Resource Manager." 0
Write-Log "Script execution finished. Refer to log - $Global:LogFilePath." 3
Write-Host -F Yellow (Get-Date -Format MM-dd-yyyy-hh:mm:ss) ": Script execution ENDED."
}
