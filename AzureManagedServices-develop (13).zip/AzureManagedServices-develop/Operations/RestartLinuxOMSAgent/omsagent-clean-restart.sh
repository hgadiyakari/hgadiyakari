#!/bin/bash

# Stop omsagent and omi server , kill processes related to omsagent then start omsagent (including omi server)
# omid.service is under /opt/omi/bin/service_control
VM=`hostname`
OMIPIDFILE=/var/opt/omi/run/omiserver.pid
OMSCONFIGFILE=/etc/opt/microsoft/omsagent/conf/omsadmin.conf

if [ ! -f $OMSCONFIGFILE ]; then
    echo "ERROR: Cannot restart. Missing configuration file - $OMSCONFIGFILE. Check if OMS agent is installed.";sleep 3;exit
else
    echo "$OMSCONFIGFILE - OMS agent configuration file FOUND. Continue with restart."

fi

echo ""

## Stop omsagent service control
echo "Stopping OMS agent..."
/opt/microsoft/omsagent/bin/service_control stop >/dev/null


# Check if omsagent is running or not
#  Returns 1 if  omsagent  is running
/opt/microsoft/omsagent/bin/service_control is-running

if [ $? -eq 1 ];
then
    echo "omsagent : still running."
else
    echo "omsagent: stopped."
fi

echo ""

## Stop omi server (omid.service)
echo "Stopping omi server"

/opt/omi/bin/service_control stop

echo ""

## Kill other processes related to oms

echo "Kill other processes related to OMS - omicli omiagent omiengine omiserver omsagent."

for i in omicli omiagent omiengine omiserver omsagent; do pkill -9 $i; done

pkill -f /opt/microsoft/omsconfig/modules/nxOMSAutomationWorker/DSCResources/MSFT_nxOMSAutomationWorkerResource/automationworker/worker
echo ""

## Start omi server (omid.service)
echo "Starting OMI server"
/opt/omi/bin/service_control start >/dev/null

## Check if omi server is running or not
## Returns 1 if 'omi' server is running

if [ -f $OMIPIDFILE ]; then
    ps -p `cat $OMIPIDFILE` | grep -q omiserver
    omiserver_status="running"
        echo "omi server: $omiserver_status"
else
    omiserver_status="NOT running"
    echo "ERROR omi server: $omiserver_status"
fi

echo ""

## Start omsagent service control
echo "Starting oms agent"
/opt/microsoft/omsagent/bin/service_control start

# Check if omsagent is running or not
#  Returns 1 if  amosagent  is running
/opt/microsoft/omsagent/bin/service_control is-running


if [ $? -eq 1 ];
then
    omsagent_status="running"
        echo "omsagent: $omsagent_status"
else
    omsagent_status="NOT running"
        echo "ERROR omsagent:  $omsagent_status"
fi

echo ""

## Force the omsconfig agent to talk to Azure Monitor and retrieve the latest configuration
if [ -f /opt/microsoft/omsconfig/Scripts/PerformRequiredConfigurationChecks.py ]; then
    su omsagent -c /opt/microsoft/omsconfig/Scripts/PerformRequiredConfigurationChecks.py >/dev/null
    PerformRequiredConfigurationChecks="PerformRequiredConfigurationChecks executed"
else
    PerformRequiredConfigurationChecks="PerformRequiredConfigurationChecks NOT Found"

fi

sleep 30

if [ -f "/opt/microsoft/omsagent/bin/omsadmin.sh" ]; then
  checkomsagent=`/opt/microsoft/omsagent/bin/omsadmin.sh -l`
else
  checkomsagent="Onboarding file omsadmin.sh not found."
fi

## Check status of omsagent
echo "SUMMARY for server $VM:"
echo "OMSAGENT is $omsagent_status"
echo "OMI SERVER is $omiserver_status"
echo $PerformRequiredConfigurationChecks
echo $checkomsagent
