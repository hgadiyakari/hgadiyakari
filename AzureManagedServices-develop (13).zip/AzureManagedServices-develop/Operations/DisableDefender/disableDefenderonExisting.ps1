<#=================================================================================================================
Required - Powershell Version 7.0, Azure CLI Version 2.1.0
===================================================================================================================
===================================================================================================================
AUTHOR: Iain Babeu
DATE:    19/04/2021
Version: 1.0
==================================================================================================================#>


#Will run to completion and exit with success if one of the following set of conditions is true.
# 1) OS is Windows 2016 and 2019, CrowdStrike is installed, Windows Defender RealTimeMonitorting is already disabled.
# 2) OS is Windows 2016 and 2019, CrowdStrike is installed, Windows Defender RealTimeMonitorting was disabled by script.
# 3) OS is not Windows 2016 or 2019. In that case this script does not apply and script exits.
# 4) OS is Windows 2016 or 2019 but Crowdstrike is not installed. Script assumed machine was targeted in error, exits clean.
# Script will fail with error code if:
# 1) Script was unable to set Windows Defender Policy.
# 2) Any other error within the script.

#Collect required parameters
[CmdletBinding(SupportsShouldProcess=$true)]
Param
(

)

#Disable Defender as recommended for CrowdStrike. AZR-17662
#Check for Windows 2019 or 2016. Defender is not enabled by default on earlier systems.
#Get OS Version
$osversion = (Get-CIMInstance -ClassName Win32_OperatingSystem).version


#Check status of Crowdstrike install.
$csService = Get-Service CSFalconService -ErrorAction SilentlyContinue
if ($? -eq $False)
    {$csServiceStatus = "No CrowdStrike Service Detected"}
else 
    {$csServiceStatus = $csService.Status}

#Test that OS and Crowdstrike are as expected and exit script if not.
#Exit will be clean, this is expected behavior as prerequisites are not met.

#If the OS is not 2016 or 2019 then exit the script and return status. Clean Exit.
if (-Not (($osversion -like '*17763') -or ($osversion -like '*14393')))
    {
    Write-Host "VMName: ($env:COMPUTERNAME),OS: $osversion,DisableRealtimeMonitoring: NA,CrowdStrike: ($csServiceStatus)"
    EXIT $LASTEXITCODE
    } else {}

#If CrowdStrike is not installed then exit the script and return status. Clean exit.
if ($csServiceStatus -eq "No CrowdStrike Service Detected")
    {
    Write-Host "VMName: ($env:COMPUTERNAME),OS: $osversion,DisableRealtimeMonitoring: NA,CrowdStrike: ($csServiceStatus)"
    EXIT $LASTEXITCODE
    } else {}

#OS and CrowdStrike status are known and good.
#Determine and check Windows Defender Status
$disableRTMsettingValue = (Get-MpPreference | Select-Object DisableRealtimeMonitoring).disablerealtimemonitoring

#If Windows Defender RealTime monitoring is disabled do nothing, report status, exit clean.
#If Windows Defender RealTime monitoring is enabled update it, check it, report status, error if needed, exit clean.

if ($disableRTMsettingValue -eq $True) #If Windows Defender realtime monitoring is already disabled then take no action. Exit normally.
    { 
    Write-Host "VMName: ($env:COMPUTERNAME),OS: $osversion,DisableRealtimeMonitoring: $disableRTMsettingValue,CrowdStrike: ($csServiceStatus)"
    EXIT $LASTEXITCODE
    } else {
        Set-MpPreference -DisableRealtimeMonitoring $true
        sleep 3
        $disableRTMsettingValue = (Get-MpPreference | Select-Object DisableRealtimeMonitoring).disablerealtimemonitoring
        if ($disableRTMsettingValue -eq $True) 
            {
            Write-Host "VMName: ($env:COMPUTERNAME),OS: $osversion,DisableRealtimeMonitoring: $disableRTMsettingValue,CrowdStrike: ($csServiceStatus)"
            EXIT $LASTEXITCODE
            }
        else 
            {
            Write-Host "VMName: ($env:COMPUTERNAME),OS: $osversion,Failed to disable Windows Defender Realtime Monitoring)"
            }
        }

Exit $LASTEXITCODE