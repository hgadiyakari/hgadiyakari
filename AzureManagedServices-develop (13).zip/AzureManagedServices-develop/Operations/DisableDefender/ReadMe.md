disableDefenderonExisting.ps1

This script takes no parameters. 

When executed on Windows it will check the operating system version, if the CrowdStrike Falcon service is installed, and the state of Windows Defender Realtime Monitoring.

If the operating system is Windows 2016 or Windows 2019 AND CrowdStrike Falcon is installed it will attempt to disable Windows Defender Realtime Montoring. If the disable fails the script will exit with an error. If the operating system is not Windows 2016 or Windows 2019 the script will exit without error. If the Crowdstrike Falcon service is not installed the script will exit without error and not change any Windows Defender settings.

To automate deployment of this script use:
  * automatedisableDefenderonExisting.ps1


----------------------------
automatedisableDefenderonExisting.ps1

This script will attempt to deploy disableDefenderonExisting.ps1 to the specified targets. The script can be targeted at an entire subscription, a specific resource group, or an individual virtual machine. The script will be deployed in parallel to the targeted virtual machines.

*The target subscription or resource group will be filtered to only attempt execution on RUNNING Windows machines with the CrowdStrike extension present.

The script uses Invoke-AZVmCommand and Powershells Jobs to execute disableDefenderonExisting.ps1 on target virtual machines in parallel. Jobs will timeout after 10 minutes.

Parameters:
  * -subscriptionId REQUIRED. The user must specify which subscription is being targeted.
  * -resourceGroupName OPTIONAL. A specific resource group in the subscription may be targeted by name. This parameter is also required if targeting a single virtual machine.
  * -VMName OPTIONAL. A single virtual machine may be targeted by using this option.
  * -tenantID REQUIRED. For use with spKey and ClientID. Provides an option to use identities and keys for authentication and authorization.
  * -spKey OPTIONAL. For use with tenantID.
  * -clientID OPTIONAL. For use with tenantID.
  
Examples:
 Example 1)
  .\automatedisableDefenderonExisting.ps1 -subscriptionId "mySubscriptionID" -TenantId "myTenantId"
    In this example the entire subscription would be processed by the automation script. It would find running virtual machines identified as Windows machines with the CrowdStrike extension and execute the script.
  Example 2)
  .\automatedisableDefenderonExisting.ps1 -subscriptionId "mySubscriptionID" -TenantId "myTenantId" -resourceGroupName myResourceGroup
    In this example the resource group named "myResourceGroup" would be processed by the automation script. It would find running virtual machines identified as Windows machines with the CrowdStrike extension and execute the script.
  Example 3)
  .\automatedisableDefenderonExisting.ps1 -subscriptionId "mySubscriptionID" -TenantId "myTenantId" -resourceGroupName myResourceGroup -VMName myVM
    In this example the script will attempt to deploy the script on the targeted VM. *This does not check operating system or if the CrowdStrike extension is installed. However, the disableDefenderonExisting.ps1 script will still make that check
