﻿<#=================================================================================================================
Required - Powershell Version 7.0, Azure CLI Version 2.1.0
===================================================================================================================
===================================================================================================================
AUTHOR:  Iain Babeu
DATE:    19/04/2021
Version: 1.0
==================================================================================================================#>

#Requires -Version 7
#Requires -PSEdition Core

#Collect required parameters
[CmdletBinding(SupportsShouldProcess=$true)]
Param
    (
    [Parameter(Mandatory=$true)] [String]$subscriptionId,    
    [Parameter(Mandatory=$false)] [String]$resourceGroupName,
    [Parameter(Mandatory=$false)] [String]$VMName,
    [Parameter(Mandatory=$true)] [String]$tenantId,
    [Parameter(Mandatory=$false)] [String]$spKey,
    [Parameter(Mandatory=$false)] [String]$clientID
    )

$WarningPreference = "SilentlyContinue"

#Check environemnt for required modules
$dxcModuleList = "DXCEnvCheckV2.psm1","DXCUtilityFunctions.psm1"
foreach ($dxcModule in $dxcModuleList)
    {
    [String]$dxcModuleURL = "https://dxcazuretoolsdev.blob.core.windows.net/installers/DXCPowershellModules/" + $dxcModule
    [String]$dxcLocalModule = $PSScriptRoot + "\" + $dxcModule
    (New-Object System.Net.WebClient).DownloadFile($dxcModuleURL, $dxcLocalModule)
    Import-Module $dxcLocalModule -WA 0
    Remove-Item -Path $dxcLocalModule
    }


$dxcAZCli = Check-AzureCLI -Version 2.1.0 
if (!$dxcAZCli)
    {
    Read-Host "`Press 'ENTER' to exit the script........"
    exit
    }

#Connect to Azure & Subscription
Write-Host "Connecting to Azure and subscription"
Start-Sleep -S 3
if ($SpKey) {
	Utility-LoginAZSpn -TenantId $tenantId -SpnKey $spKey -ClientId $clientID -SubscriptionId $subscriptionId
	}
else {
	Utility-LoginAZTenant -SubscriptionId $subscriptionId -TenantId $tenantId
	}

#Get list of VMs
$targetList = @()

#Check if subscriptionID, RGName and VMname are all specified. If they are, target one VM.
if (($VMName) -and ($resourceGroupName) -and ($subscriptionId))
    {
    $target = get-azvm -ResourceGroupName $resourceGroupName -Name $VMName
    $targetList += $target
    }
elseif (($resourceGroupName) -and ($subscriptionId)) #If RGName only is set, loop through and select only Windows if CrowdStrike extension is installed.
    {
    get-azvm -status -ResourceGroupName $resourceGroupName | `
             Where-Object {(($_.StorageProfile.OsDisk.OsType -eq "Windows") -and ($_.extensions.id -match "CrowdStrike") -and ($_.PowerState -eq "VM Running"))}| % {
                $targetList += $_
            }
    }
elseif ((!$VMName) -and (!$resourceGroupName) -and ($subscriptionId)) #Runs against whole subscription
    {
    get-azvm -status | Where-Object {(($_.StorageProfile.OsDisk.OsType -eq "Windows") -and ($_.extensions.id -match "CrowdStrike") -and ($_.PowerState -eq "VM Running"))}| % {
                $targetList += $_
            }

    }
else {
    write-host "Check parameters entered. -subscriptionId and -TenantID are always required. If using -VMName then -resourceGroupName is also required."
    EXIT
    }

$Jobs = @()
foreach ($target in $targetList) {
    $jobs += Invoke-AzVMRunCommand -VM $target -ScriptPath .\disableDefenderonExisting.ps1 -CommandId 'RunPowerShellScript' -AsJob | Get-Job
    write-host "Started background job on $($target.Name)"
}

$Jobs | Wait-Job -Timeout 600 | Out-Null
$results = $Jobs | Receive-Job
$Jobs | Remove-Job
$results.value.message