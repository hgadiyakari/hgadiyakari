#Requires -PSEdition Core
#Requires -Version 7.0
#Requires -Module Az
#
#
#
#
#
#
#
#
Write-Host "`nThis script has been deprecated. To install diagnostic extensions on Azure Virtual Machines, please use MakeManagedAuto.ps1 instead. This is located at \ResourceDeployment\IaaS\MakeManaged\makeManagedSymantec\makeManagedAuto.ps1.`n`nExiting...`n" -ForegroundColor Red
exit
#
#
#
#
#
#
#
#
#
<#
=========================================================================================================================
Required - Powershell Version 7.0, Powershell Azure module 5.0.0
=========================================================================================================================
AUTHOR:  Miroslav Dimitrov
DATE:    21/05/2019
Version: 1.0
Documentation: https://confluence.csc.com/pages/viewpage.action?pageId=162088558 
=========================================================================================================================
AUTHOR:  Thomas Richards
DATE:    24/06/2021
Version: 2.0
Changes: Deprecated script as part of AZR-23760
Documentation: https://confluence.dxc.com/display/CSA/SPIKE%3A+Update+automateDiagnosticExtension.ps1+to+work+with+new+tagging+schema 
=========================================================================================================================
.SYNOPSIS
Installs the diagnostic extension needed for the CloudChkrRightSize Report on Windows and Linux VMs in a given subscription.
Updates expired certificate on RHEL VMs in order to prevent a known issue: https://confluence.csc.com/display/CSA/CSA-9474+RHEL+7.2+Linix+Diagnostic+Extension+provisioning+failed+status%2C+mdsd+dependency+error
Takes all the running Windows VMs, checks if they have the Diagnostic Extension installed, if yes- skipp them, if no- doing the installation
Takes the Linux VMs reporting Hearbeat to the workspace in the dxc-maint-rg in the last 15 mins and which have OMS agent 1.9 or higher and installs the Linux Diagnostic Extension only on the up to date machines, in order to prevent a coexistence issue between an older OMS and LAD
Gives a list of the Linux VMs with OMS agent version lower than 1.9 in order to upgrade the OMS agent version, before installing the Diagnostic Extension on them
#>
#=========================================================================================================================
#Param
    #(
    #[Parameter(Mandatory=$true)]  [String]$CustomerSubscriptionID
    #)
#==========================================================================================================================
#Login Section
#==========================================================================================================================
$error.Clear()
Write-Host "INFORMATION: Please login to Azure Resource Manager." -ForegroundColor Green
    Login-AzAccount
 
    if ($error) 
        { 
        Write-Host "WARNING:     Unable to connect to Azure. Check your internet connection and verify authentication details." -ForegroundColor Yellow
        
        exit
        }
        Else {
    Write-Host "INFORMATION: Connected to Azure with provided authentication." -ForegroundColor Green }

    Set-AzContext -Subscription $CustomerSubscriptionID

    if ($error) 
        { 
        Write-Host "WARNING:     Invalid Subscription ID. Please make sure you have proper access to this Azure Subscription." -ForegroundColor Yellow 
        Write-Host "             Run the Powershell Command: " -ForegroundColor Yellow -NoNewLine 
        Write-Host "Login-AzAccount -Subscription $dxcSubscriptionID " -NoNewLine
        Write-Host "and login with your authentication details." -ForegroundColor Yellow
        Write-Host "             If you get error, you have access issues with the subscription." -ForegroundColor Yellow

        exit 
        }
        else {
    Write-Host "INFORMATION: Connected to Azure Subscription " -NoNewline -ForegroundColor Green
    Write-Host $dxcSubscriptionID -NoNewline
    Write-Host " with provided authentication." -ForegroundColor Green 
    }
#========================================================================================================================
# Creating the variables
#========================================================================================================================
#Taking all the VMs in the subscription
$vms = get-azvm -Status
#Taking all the Windows VMs in the subscription
$vmlistWindows = $vms | Where-Object {$_.storageprofile.osdisk.ostype -like 'Windows'} | select name, resourcegroupname , powerstate, Location | Where-Object {$_.powerstate -eq 'VM running'} | Sort-Object Name 
#Taking all the RHEL VMs to update their rhui certificate
$vmlistRHEL = $vms | Where-Object {$_.Storageprofile.ImageReference.Offer -like 'RHEL'} | select name, resourcegroupname , powerstate, Location | Where-Object {$_.powerstate -eq 'VM running'} | Sort-Object Name 
#Taking the Log Analytics workspace from the dxc-maint-rg
$oms = (Get-AzOperationalInsightsWorkspace -ResourceGroupName dxc-maint-rg)[0]
#Take the VMs with OMS agent version higher than 1.9 via Log Analytics workspace query
$LinuxVMsNewOMSquery = 'Heartbeat | where OSType contains "Linux" | where Version contains "1.10" or Version contains "1.9" | project Computer, Version, ResourceGroup | distinct Computer, Version, ResourceGroup'
#Take the VMs with OMS agent version lower than 1.9 via Log Analytics workspace query
$LinuxVMsOlderOMSquery = 'Heartbeat | where OSType contains "Linux" | where Version !contains "1.10" and Version !contains "1.9" | project Computer, Version, ResourceGroup | distinct Computer, Version, ResourceGroup'
$timespan = New-TimeSpan -Hours 0 -Minutes 15
#Taking all the Linux VMs with a newer OMS agent to install LAD on them
$LinuxVMsNewOMSList = (Invoke-AzOperationalInsightsQuery -Workspace $oms -Timespan $timespan -Query $LinuxVMsNewOMSquery).Results
#Taking Linux VMs with an older OMS agent which need to be updated, before installing LAD on them
$LinuxVMsOlderOMSList = (Invoke-AzOperationalInsightsQuery -Workspace $oms -Timespan $timespan -Query $LinuxVMsOlderOMSquery).Results
#Setting the deployment directory
$deployExtensionLogDir = split-path -parent $MyInvocation.MyCommand.Definition
#=================================================================================================================================================
# Creating functions to enable the Diagnostic Extension, one with the settings for Windows VMs, another with the settings for Linux VMs
#=================================================================================================================================================
# Creating function to enable the Windows Diagnostic Extension

function Enable-WindowsDiagnosticsExtension($rsgName, $rsgLocation, $vmId, $vmName) {
    $WindowsExtensionName = "IaaSDiagnostics"
    $extensionType = "IaaSDiagnostics"
    $vmLocation = $vm.Location
    $WindowsExtensionTemplate = '{
    "$schema": "http://schema.management.azure.com/schemas/2015-01-01/deploymentTemplate.json#",
    "contentVersion": "1.0.0.0",
    "parameters": {},
    "variables": {},
    "resources": [
        {
            "type": "Microsoft.Compute/virtualMachines/extensions",
            "name": "' + $vm.Name + '/' + $WindowsExtensionName + '",
            "apiVersion": "2018-10-01",
            "location": "' + $vmLocation + '",
            "properties": {
                "publisher": "Microsoft.Azure.Diagnostics",
                "type": "IaaSDiagnostics",
                "typeHandlerVersion": "1.5",
                "autoUpgradeMinorVersion": true,
                "protectedSettings": {
                    "storageAccountName": "' + $Storageaccount + '",
                    "storageAccountKey": "' + $storageKey + '",
                    "storageAccountEndPoint": "https://core.windows.net"
                },
                "settings": {
                    "StorageAccount": "' + $Storageaccount + '",
                    "WadCfg": {
                        "DiagnosticMonitorConfiguration": {
                            "overallQuotaInMB": 5120,
                            "Metrics": {
                                "resourceId": "' + $vmId + '",
                                "MetricAggregation": [
                                    {
                                        "scheduledTransferPeriod": "PT1H"
                                    },
                                    {
                                        "scheduledTransferPeriod": "PT1M"
                                    }
                                ]
                            },
                            "DiagnosticInfrastructureLogs": {
                                "scheduledTransferLogLevelFilter": "Error",
                                "scheduledTransferPeriod": "PT1M"
                            },
                            "PerformanceCounters": {
                                "scheduledTransferPeriod": "PT1M",
                                "PerformanceCounterConfiguration": [
                                   
                                    {
                                        "counterSpecifier": "\\Memory\\Available Bytes",
                                        "sampleRate": "PT60S"
                                    },
                                    {
                                        "counterSpecifier": "\\Memory\\Committed Bytes",
                                        "sampleRate": "PT60S"
                                    },
                                    {
                                        "counterSpecifier": "\\Memory\\Cache Bytes",
                                        "sampleRate": "PT60S"
                                    },
                                    {
                                        "counterSpecifier": "\\Memory\\Pool Paged Bytes",
                                        "sampleRate": "PT60S"
                                    },
                                    {
                                        "counterSpecifier": "\\Memory\\Pool Nonpaged Bytes",
                                        "sampleRate": "PT60S"
                                    },
                                    {
                                        "counterSpecifier": "\\Memory\\Pages/sec",
                                        "sampleRate": "PT60S"
                                    },
                                    {
                                        "counterSpecifier": "\\Memory\\Page Faults/sec",
                                        "sampleRate": "PT60S"
                                    }
                                    
                                ]
                            },
                            "WindowsEventLog": {
                                "scheduledTransferPeriod": "PT1M",
                                "DataSource": [
                                    {
                                        "name": "Application!*[Application[(Level=1 or Level=2 or Level=3)]]"
                                    },
                                    {
                                        "name": "System!*[System[(Level=1 or Level=2 or Level=3)]]"
                                    },
                                    {
                                        "name": "Security!*[System[(band(Keywords,4503599627370496))]]"
                                    }
                                ]
                            },
                            "Directories": {
                                "scheduledTransferPeriod": "PT1M"
                            }
                        }
                    }
                }
            }
        }
    ]
}'
    $extensionTemplatePath = Join-Path $deployExtensionLogDir "extensionTemplateForWindows.json";
    Out-File -FilePath $extensionTemplatePath -Force -Encoding utf8 -InputObject $WindowsExtensionTemplate
    New-AzResourceGroupDeployment -ResourceGroupName $vm.ResourceGroupName -TemplateFile $extensionTemplatePath
       
}

# Creating function to enable the Linux Diagnostic Extension

function Enable-LinuxDiagnosticsExtension($rsgName, $rsgLocation, $vmId, $vmName) {
    $LinuxextensionName = "LinuxDiagnostic"
    $LinuxextensionType = "LinuxDiagnostic"
    $vmLocation = $vm.Location

    $LinuxExtensionTemplate = '{
    "$schema": "http://schema.management.azure.com/schemas/2015-01-01/deploymentTemplate.json#",
    "contentVersion": "1.0.0.0",
    "parameters": {},
    "variables": {},
    "resources": [
        {
            "type": "Microsoft.Compute/virtualMachines/extensions",
            "name": "' + $vm.Name + '/' + $LinuxExtensionName + '",
            "apiVersion": "2018-10-01",
            "location": "' + $vm.Location + '",
            "properties": {
                "publisher": "Microsoft.Azure.Diagnostics",
                "type": "LinuxDiagnostic",
                "typeHandlerVersion": "3.0",
                "autoUpgradeMinorVersion": true,
                "protectedSettings": {
                    "storageAccountName": "' + $Storageaccount + '",
                    "storageAccountSasToken": "' + $SasToken + '",
                    "storageAccountEndPoint": "https://core.windows.net"
                },
                "settings": {
                    "StorageAccount": "' + $Storageaccount + '",
                    "ladCfg": {
                        "diagnosticMonitorConfiguration": {
                            "eventVolume": "Medium",
                            "metrics": {
                                "metricAggregation": [
                                    {
                                        "scheduledTransferPeriod": "PT1H"
                                    },
                                    {
                                        "scheduledTransferPeriod": "PT1M"
                                    }
                                ],
                                "resourceId": "' + $vmId + '"
                            },
                            "performanceCounters": {
                                "performanceCounterConfiguration": [    
                                    {
                                        "annotation": [
                                            {
                                                "displayName": "Memory available",
                                                "locale": "en-us"
                                            }
                                        ],
                                        "class": "memory",
                                        "counter": "availablememory",
                                        "counterSpecifier": "/builtin/memory/availablememory",
                                        "type": "builtin",
                                        "unit": "Bytes"
                                    },
                                    {
                                        "annotation": [
                                            {
                                                "displayName": "Swap percent used",
                                                "locale": "en-us"
                                            }
                                        ],
                                        "class": "memory",
                                        "counter": "percentusedswap",
                                        "counterSpecifier": "/builtin/memory/percentusedswap",
                                        "type": "builtin",
                                        "unit": "Percent"
                                    },
                                    {
                                        "annotation": [
                                            {
                                                "displayName": "Memory used",
                                                "locale": "en-us"
                                            }
                                        ],
                                        "class": "memory",
                                        "counter": "usedmemory",
                                        "counterSpecifier": "/builtin/memory/usedmemory",
                                        "type": "builtin",
                                        "unit": "Bytes"
                                    },
                                    {
                                        "annotation": [
                                            {
                                                "displayName": "Page reads",
                                                "locale": "en-us"
                                            }
                                        ],
                                        "class": "memory",
                                        "counter": "pagesreadpersec",
                                        "counterSpecifier": "/builtin/memory/pagesreadpersec",
                                        "type": "builtin",
                                        "unit": "CountPerSecond"
                                    },
                                    {
                                        "annotation": [
                                            {
                                                "displayName": "Swap available",
                                                "locale": "en-us"
                                            }
                                        ],
                                        "class": "memory",
                                        "counter": "availableswap",
                                        "counterSpecifier": "/builtin/memory/availableswap",
                                        "type": "builtin",
                                        "unit": "Bytes"
                                    },
                                    {
                                        "annotation": [
                                            {
                                                "displayName": "Swap percent available",
                                                "locale": "en-us"
                                            }
                                        ],
                                        "class": "memory",
                                        "counter": "percentavailableswap",
                                        "counterSpecifier": "/builtin/memory/percentavailableswap",
                                        "type": "builtin",
                                        "unit": "Percent"
                                    },
                                    {
                                        "annotation": [
                                            {
                                                "displayName": "Mem. percent available",
                                                "locale": "en-us"
                                            }
                                        ],
                                        "class": "memory",
                                        "counter": "percentavailablememory",
                                        "counterSpecifier": "/builtin/memory/percentavailablememory",
                                        "type": "builtin",
                                        "unit": "Percent"
                                    },
                                    {
                                        "annotation": [
                                            {
                                                "displayName": "Pages",
                                                "locale": "en-us"
                                            }
                                        ],
                                        "class": "memory",
                                        "counter": "pagespersec",
                                        "counterSpecifier": "/builtin/memory/pagespersec",
                                        "type": "builtin",
                                        "unit": "CountPerSecond"
                                    },
                                    {
                                        "annotation": [
                                            {
                                                "displayName": "Swap used",
                                                "locale": "en-us"
                                            }
                                        ],
                                        "class": "memory",
                                        "counter": "usedswap",
                                        "counterSpecifier": "/builtin/memory/usedswap",
                                        "type": "builtin",
                                        "unit": "Bytes"
                                    },
                                    {
                                        "annotation": [
                                            {
                                                "displayName": "Memory percentage",
                                                "locale": "en-us"
                                            }
                                        ],
                                        "class": "memory",
                                        "counter": "percentusedmemory",
                                        "counterSpecifier": "/builtin/memory/percentusedmemory",
                                        "type": "builtin",
                                        "unit": "Percent"
                                    },
                                    {
                                        "annotation": [
                                            {
                                                "displayName": "Page writes",
                                                "locale": "en-us"
                                            }
                                        ],
                                        "class": "memory",
                                        "counter": "pageswrittenpersec",
                                        "counterSpecifier": "/builtin/memory/pageswrittenpersec",
                                        "type": "builtin",
                                        "unit": "CountPerSecond"
                                    }
                                ]
                            },
                            "syslogEvents": {
                                "syslogEventConfiguration": {
                                    "LOG_AUTH": "LOG_DEBUG",
                                    "LOG_AUTHPRIV": "LOG_DEBUG",
                                    "LOG_CRON": "LOG_DEBUG",
                                    "LOG_DAEMON": "LOG_DEBUG",
                                    "LOG_FTP": "LOG_DEBUG",
                                    "LOG_KERN": "LOG_DEBUG",
                                    "LOG_LOCAL0": "LOG_DEBUG",
                                    "LOG_LOCAL1": "LOG_DEBUG",
                                    "LOG_LOCAL2": "LOG_DEBUG",
                                    "LOG_LOCAL3": "LOG_DEBUG",
                                    "LOG_LOCAL4": "LOG_DEBUG",
                                    "LOG_LOCAL5": "LOG_DEBUG",
                                    "LOG_LOCAL6": "LOG_DEBUG",
                                    "LOG_LOCAL7": "LOG_DEBUG",
                                    "LOG_LPR": "LOG_DEBUG",
                                    "LOG_MAIL": "LOG_DEBUG",
                                    "LOG_NEWS": "LOG_DEBUG",
                                    "LOG_SYSLOG": "LOG_DEBUG",
                                    "LOG_USER": "LOG_DEBUG",
                                    "LOG_UUCP": "LOG_DEBUG"
                                }
                            }
                        },
                        "sampleRateInSeconds": 15
                    }
                }
            }
        }
    ]
}'
    $LinuxextensionTemplatePath = Join-Path $deployExtensionLogDir "extensionTemplateForLinux.json";
    Out-File -FilePath $LinuxextensionTemplatePath -Force -Encoding utf8 -InputObject $LinuxExtensionTemplate
    New-AzResourceGroupDeployment -ResourceGroupName $vm.ResourceGroupName -TemplateFile $LinuxextensionTemplatePath
}
#========================================================================================================================
#Updating the possible expired client certificate on the RHEL VMs in order to prevent a known issue, documented here:
#https://confluence.csc.com/display/CSA/CSA-9474+RHEL+7.2+Linix+Diagnostic+Extension+provisioning+failed+status%2C+mdsd+dependency+error
#========================================================================================================================
#Looping all RHEL VMs to update their client certificate
Write-Host "INFORMATION: Updating client certificate on RHEL VMs" -ForegroundColor Green
foreach($vm in $vmlistRHEL)
	{
		#update the client certificate on the VM and output result
		Write-host 'Update client certificate on VM named ' $vm.name
		$result =(invoke-azvmruncommand -ResourceGroupName $vm.resourcegroupname -Name $vm.name -CommandId 'RunShellScript' -ScriptPath .\redhatcertupdate.sh)
		$r2 = $result.value.message
		#$r2 = $r2 -replace "\n", ""
		$r2 = $r2 -replace "\[stdout\]",""
		$r2 = $r2 -replace "\[stderr\]","" 
		Write-host $r2
        
	}

# Looping all the Windows VMs, checking if the Diagnostic extension is installed, if yes - skip them, if no- installing it
Write-Host "INFORMATION: Start checking Windows VMs" -ForegroundColor Green
foreach ($vm in $vmlistWindows) {
    Write-host "Checking for Diagnostic Extension on VM named" $vm.name
    $diagnosticext = Get-AzVM -ResourceGroupName $vm.ResourceGroupName -Name $vm.Name | Where-Object {$_.Extensions.VirtualMachineExtensionType -like "IaaSDiagnostics"} | select-object -ExpandProperty Name      
    $vmName = $vm.name
    $vmId = (Get-AzResource -Name $vm.name).ResourceId
    IF ($diagnosticext) {
        $extname = $diagnosticext.Extensions | Where-Object {$_.VirtualMachineExtensionType -like "IaaSDiagnostics"} | select-object -ExpandProperty Name
        write-host "Existing Diagnostic Extension found on $vmName. No further action required."
   
    }
    Else {
        write-host "There is no Diagnostic Extension found on this machine. Proceed taking the boot diagnostic storage account details needed for installing it"
        $vm = Get-AzVM -ResourceGroupName $vm.ResourceGroupName -Name $vm.Name
        # Taking the boot diagnostic storage account
        $Storageaccount = [regex]::match($vm.DiagnosticsProfile.bootDiagnostics.storageUri, '^http[s]?://(.+?)\.').groups[1].value
        Write-Host "diagnostic account is" $Storageaccount
        $StorageaccountResourcegroup = $rgName = Get-AzStorageAccount | where {$_.StorageAccountName -eq $Storageaccount} | Select-Object -ExpandProperty ResourceGroupName 
        Write-Host "Resource Group of the storage account is " $StorageaccountResourcegroup
        # Taking the Storage key
        $storageKeys = Get-AzStorageAccountKey -ResourceGroupName $StorageaccountResourcegroup -Name $Storageaccount;
        $storageKey = $storageKeys[0].Value;
        Write-Host "Proceeding with Installing the Diagnostic Extension on" $vm.Name
        Enable-WindowsDiagnosticsExtension -rsgName $vm.ResourceGroupName -rsgLocation $vm.Location -vmId $vmId -vmName $vm.Name
        Write-Host "Installation finished"
    }
}

# Looping all the Linux VMs, checking if the Diagnostic extension is installed, if yes - skip them, if no- installing it
Write-Host "INFORMATION: Start checking Linux VMs" -ForegroundColor Green
foreach ($vm in $LinuxVMsNewOMSList) {
    Write-host "Checking for Linux Diagnostic Extension on VM named" $vm.Computer
    $diagnosticext = Get-AzVM -ResourceGroupName $vm.ResourceGroup -Name $vm.Computer | Where-Object {$_.Extensions.VirtualMachineExtensionType -like "LinuxDiagnostic"} | select-object -ExpandProperty Name
    $vmName = $vm.Computer
    $vmId = (Get-AzResource -Name $vm.Computer).ResourceId

    IF ($diagnosticext) {
        $extname = $diagnosticext.Extensions | Where-Object {$_.VirtualMachineExtensionType -like "LinuxDiagnostic"} | select-object -ExpandProperty Name
        write-host "Existing Diagnostic Extension found on VM $vmName. No further action required"
        }
        
    Else {
        write-host "There is no Diagnostic Extension found on this machine. Proceed taking the boot diagnostic storage account details needed for installing it"
        $vm = Get-AzVM -ResourceGroupName $vm.ResourceGroup -Name $vm.Computer
        # Taking the boot diagnostic storage account
        $Storageaccount = [regex]::match($vm.DiagnosticsProfile.bootDiagnostics.storageUri, '^http[s]?://(.+?)\.').groups[1].value
        Write-Host "diagnostic account is" $Storageaccount
        $StorageaccountResourcegroup = $rgName = Get-AzStorageAccount | where {$_.StorageAccountName -eq $Storageaccount} | Select-Object -ExpandProperty ResourceGroupName 
        Write-Host "Resource Group of the storage account is " $StorageaccountResourcegroup
        # Creating the SAS token
        $SasContext = (Get-AzStorageAccount -ResourceGroupName $StorageaccountResourcegroup -Name $Storageaccount).context
        $SasToken = (New-AzStorageAccountSASToken -Service Blob, Table -ResourceType Container, Object -Permission "wlacu" -ExpiryTime "2029-12-31T23:59Z" -Context $SasContext).Trim("?")
        Write-Host "Proceeding with installing the Diagnostic Extension on" $vm.Name
        Enable-LinuxDiagnosticsExtension -rsgName $vm.ResourceGroupName -rsgLocation $vm.Location -vmId $vmId -vmName $vm.Name
        write-host "Installation finished"
    }
}
# Giving the list of the VMs with older than 1.9 Version of the OMS agent, which need to be upgraded
Write-Host 'WARNING: The following machines have an older OMS Agent version than 1.9 and need to be upgraded manually before installing LAD on them' -ForegroundColor Yellow
$LinuxVMsOlderOMSList | Format-Table
