#!/bin/bash
sudo yum update -y --disablerepo='*' --enablerepo='*microsoft*' 2>/dev/null

