# Input bindings are passed in via param block.
param($Timer)

# Get the current universal time in the default string format.
$currentUTCtime = (Get-Date).ToUniversalTime()

# The 'IsPastDue' property is 'true' when the current function invocation is later than scheduled.
if ($Timer.IsPastDue) {
    Write-Host "PowerShell timer is running late!"
}

#--------------------------------------------------------------------------------------------------------------------#

Import-Module DXC-Azure-PSUtils

# Get environment variables
$WorkspaceKey = $env:AZURE_WORKSPACE_KEY
$WorkspaceId = $env:AZURE_WORKSPACE_ID

# Decxlarations

$Sub = (Get-AzSubscription -SubscriptionId (Get-AzContext).Subscription).name
$NetAppFilesList = @()
$NetAppLogs = @{}
$ResourceGroupList = Get-AzResourceGroup | Sort-Object ResourceGroupName
foreach ($ResourceGroup in $ResourceGroupList.ResourceGroupName) {
    Write-Information "Searching for NetApp Files in ResourceGroup - $ResourceGroup"
    $NetAppAccountList = Get-AzNetAppFilesAccount -ResourceGroupName $ResourceGroup
    If($NetAppAccountList) {
        $NetAppAccountList | ForEach-Object {
            $NetAppAccount = $_.Name
            $NetAppLocation = $_.Location
            $SubID = ($_.Id -split '/')[2]
            $NetAppPoolsList = Get-AzNetAppFilesPool -ResourceGroupName $ResourceGroup -AccountName $NetAppAccount
            If($NetAppPoolsList) {
                $NetAppPoolsList | ForEach-Object {
                    $PoolName = $($_.Name -split '/')[1]
                    $ServiceLevel = $_.ServiceLevel
                    $QosType = $_.QosType
                    $PoolSize = $($_.Size / 1099511627776)
                    $TotalThroughputMibps = $_.TotalThroughputMibps
                    $UtilizedThroughputMibps = $_.UtilizedThroughputMibps

                    $NetAppVolumesList = Get-AzNetAppFilesVolume -ResourceGroupName $ResourceGroup -AccountName $NetAppAccount -PoolName $PoolName
                    Write-Information "Found $($NetAppVolumesList.count) volume(s) in pool $($_.Name) in NetApp Account $NetAppAccount"
                    If($NetAppVolumesList) {
                        $NetAppVolumesList | ForEach-Object {
                            $Object = @{
                                SubscriptionId = $SubID 
                                SubscriptionName = $Sub 
                                NetAppAccount = $NetAppAccount
                                ResourceGroup = $ResourceGroup
                                Location = $NetAppLocation
                                PoolName = $PoolName
                                ServiceLevel = $ServiceLevel
                                QosType = $QosType
                                PoolSizeinTiB = $PoolSize
                                TotalThroughputMibps = $TotalThroughputMibps
                                UtilizedThroughputMibps = $UtilizedThroughputMibps
                                VolumeName = $($_.Name -split '/')[-1]
                                QuotainGiB = $($_.UsageThreshold / 1073741824)
                                ThroughputinMiBps = $_.ThroughputMibps
                                Protocol = $_.ProtocolTypes[0]
                                MountPath = "$($_.MountTargets.IpAddress):/$($($_.Name -split '/')[-1])"
                                VolumeServiceLevel = $_.ServiceLevel
                                SecurityStyle = $_.SecurityStyle
                                Subnet = $($_.SubnetId -split '/')[-1]
                            }
                            $NetAppFilesList += $Object
                        }
                    }
                    Else {
                        $Object = @{
                            SubscriptionId = $SubID 
                            SubscriptionName = $Sub 
                            NetAppAccount = $NetAppAccount
                            ResourceGroup = $ResourceGroup
                            Location = $NetAppLocation
                            PoolName = $PoolName
                            ServiceLevel = $ServiceLevel
                            QosType = $QosType
                            PoolSizeinTiB = $PoolSize
                            TotalThroughputMibps = $TotalThroughputMibps
                            UtilizedThroughputMibps = $UtilizedThroughputMibps
                            VolumeName = $null
                            QuotainGiB = $null
                            ThroughputinMiBps = $null
                            Protocol = $null
                            MountPath = $null
                            VolumeServiceLevel = $null
                            SecurityStyle = $null
                            Subnet = $null
                        }
                        $NetAppFilesList += $Object
                    }
                }
            }
        }
    }
}

$NetAppLogs = $NetAppFilesList | ConvertTo-Json
$LogType = "NetAppFiles"

Write-Information "Pushing logs count - $($NetAppFilesList.count) into Log Analytics Workspace - $WorkspaceId."
Send-LogAnalyticsData -customerId $WorkspaceId -sharedKey $WorkspaceKey -body $NetAppLogs -logType $logType

#--------------------------------------------------------------------------------------------------------------------#

# Write an information log with the current time.
Write-Host "PowerShell timer trigger function ran! TIME: $currentUTCtime"

#---------------------------------------------------------END--------------------------------------------------------#