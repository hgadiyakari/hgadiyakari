﻿# Azure NetApp Files

This folder contains the json and powershell files that are used to create logs in Log analytics workpsace for Azure NetApp Files.

## Jira Epic

<https://jira.dxc.com/browse/AZR-20753>

## Deployment

For more information on how to create Azure NetApp Files and deployment of Azure funtion, please see:

* <https://confluence.dxc.com/pages/viewpage.action?pageId=226520287>
* <https://confluence.dxc.com/display/CSA/I%3A+Power+Bi+Template+for+Azure+NetApp+Files>

## Members of this directory are

* **_changeFunctionIdentityPermission.ps1_** - Apply security enhancements to existing Azure NetApp Files function app
* **_deployNetAppFilesLogs.ps1_** - Main script for deploying AZure NetApp Files Function App

## Authors

* Vaishali S
