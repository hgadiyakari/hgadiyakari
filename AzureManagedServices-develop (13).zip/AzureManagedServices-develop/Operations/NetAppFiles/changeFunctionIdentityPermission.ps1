#=====================================================================================================================
# DOCUMENTATION LINK
# https://confluence.dxc.com/display/CSA/AZR-12266+Apply+security+enhancements+to+existing+agent+health+dashboard+function+app
#=====================================================================================================================

[CmdletBinding(SupportsShouldProcess=$true)]
Param
    (
    [Parameter(Mandatory=$true)] [String]$SubscriptionId,
    [Parameter(Mandatory=$true)]  [String]$LogAnalyticsWorkspaceName
    )

#=====================================================================================================================
# CHECK ENVIRONMENT FOR NECESSERY MODULES
#=====================================================================================================================
$dxcModuleURL = "https://dxcazuretools.blob.core.windows.net/installers/DXCPowershellModules/DXCEnvCheck.psm1"
$dxcLocalModule = $PSScriptRoot + "\DXCEnvCheck.psm1"
(New-Object System.Net.WebClient).DownloadFile($dxcModuleURL, $dxcLocalModule)
Import-Module $dxcLocalModule -WA 0
Remove-Item -Path $dxcLocalModule

Check-PSVersion -dxcPSVersion 5.1
Check-AzModuleVersion -dxcAzModuleVersion 2.5.0

#=====================================================================================================================
# VARIABLE SECTION
#=====================================================================================================================
$ErrorActionPreference = "SilentlyContinue"
$WarningPreference = "SilentlyContinue"

$dxcSubscriptionID = $SubscriptionID.Trim()
$dxcLogAnalyticsWorkspaceName = $LogAnalyticsWorkspaceName.Trim()
$dxcSubscriptionScope = "/subscriptions/" + $dxcSubscriptionID

#=====================================================================================================================
# LOGIN SECTION
#=====================================================================================================================
$error.Clear()
Set-AzContext -Subscription $dxcSubscriptionID -EA 0 -WA 0 >$null

if ($error) 
    { 
    $error.Clear()
    Write-Host "`nINFORMATION: Please login to Azure Resource Manager." -ForegroundColor Green
    Connect-AzAccount -WarningAction:Continue >$null
 
    if ($error) 
        { 
        Write-Host "WARNING:     Unable to connect to Azure. Check your Internet connection and verify authentication details." -ForegroundColor Yellow
       
        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        Read-Host "`nPress 'ENTER'to exit the script........"
        exit
        }
    Write-Host "INFORMATION: Connected to Azure with provided authentication." -ForegroundColor Green 

    Set-AzContext -Subscription $dxcSubscriptionID -EA 0 -WA 0 >$null

    if ($error) 
        { 
        Write-Host "WARNING:     Invalid Subscription ID. Please make sure you have proper access to this Azure Subscription." -ForegroundColor Yellow 
        Write-Host "             Run the Powershell Command: " -ForegroundColor Yellow -NoNewLine 
        Write-Host "Login-AzAccount -Subscription $dxcSubscriptionID " -NoNewLine
        Write-Host "and login with your authentication details." -ForegroundColor Yellow
        Write-Host "             If you get error, you have access issues with the subscription." -ForegroundColor Yellow

        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        Read-Host "`nPress 'ENTER'to exit the script........"
        exit 
        }
    }
Write-Host "INFORMATION: Connected to Azure Subscription " -NoNewline -ForegroundColor Green
Write-Host $dxcSubscriptionID -NoNewline
Write-Host " with provided authentication." -ForegroundColor Green 
	
#========================================================================================================================
# MAIN BODY OF THE SCRIPT
#========================================================================================================================

# Collect Maintenance ResourceGroup and OMS Workspace Details.
$dxcObjWorkspace = Get-AzOperationalInsightsWorkspace | ? { $_.Name -Match $dxcLogAnalyticsWorkspaceName }

If ($dxcObjWorkspace)
    {
    $dxcLogAnalyticsWorkspaceName = $dxcObjWorkspace.Name
    $dxcResourceGroup = $dxcObjWorkspace.ResourceGroupName
    $dxcWorkspaceResourceId = $dxcObjWorkspace.ResourceId

    Write-Host "INFORMATION: Loganalytics Workspace named " -NoNewline -ForegroundColor Green
    Write-Host $dxcLogAnalyticsWorkspaceName -NoNewline
    Write-Host " located under ResourceGroup " -NoNewline -ForegroundColor Green 
    Write-Host $dxcResourceGroup
    }
else
    {
    Write-Host "WARNING:     Loganalytics Workspace not found. Please enter correct workspace name while running the script." -ForegroundColor Yellow

    Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
    Read-Host "`nPress 'ENTER'to exit the script........"
    exit
    } 

# Locate FunctionApp
$dxcFunctionAppName = (Get-AZWebApp -ResourceGroupName $dxcResourceGroup | ? {($_.Kind -Match "functionapp") -and ($_.Name -Match "dxc-") -and ($_.Name -notmatch "dxc-Metric")}).Name

If ($dxcFunctionAppName)
    {
    Write-Host "INFORMATION: FunctionApp named " -NoNewline -ForegroundColor Green
    Write-Host $dxcFunctionAppName -NoNewline
    Write-Host " located under ResourceGroup " -NoNewline -ForegroundColor Green 
    Write-Host $dxcResourceGroup
    }
else
    {
    Write-Host "WARNING:     Dashboard management FunctionApp not found under Resource Group " -NoNewline -ForegroundColor Yellow
    Write-Host $dxcResourceGroup
    Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
    Read-Host "`nPress 'ENTER'to exit the script........"
    exit
    } 

# Locate FunctionApp Identity
$dxcFunctionIdentityObjId = (Get-AzADServicePrincipal -DisplayName $dxcFunctionAppName).Id

If (-not($dxcFunctionIdentityObjId))
    {
    Write-Host "WARNING:     FunctionApp Identity not found" -ForegroundColor Yellow
    Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
    Read-Host "`nPress 'ENTER'to exit the script........"
    exit
    }

#Alter Assigned Roles
$error.Clear()
Remove-AzRoleAssignment -ObjectId $dxcFunctionIdentityObjId -RoleDefinitionName Contributor -Scope $dxcSubscriptionScope >$null
New-AzRoleAssignment -ObjectId $dxcFunctionIdentityObjId -RoleDefinitionName Reader -Scope $dxcSubscriptionScope >$null
New-AzRoleAssignment -ObjectId $dxcFunctionIdentityObjId -RoleDefinitionName "log analytics contributor" -Scope $dxcWorkspaceResourceId >$null

if($error) { Write-Host "WARNING:     Unable to change role assignment, make sure you have Owner rights to the subscription. Script will exit now." -ForegroundColor Yellow }
Else { Write-Host "INFORMATION: Role assignment changed successfully." -ForegroundColor Green }
Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0

Write-Host "`n*****************End OF SCRIPT EXECUTION*****************"