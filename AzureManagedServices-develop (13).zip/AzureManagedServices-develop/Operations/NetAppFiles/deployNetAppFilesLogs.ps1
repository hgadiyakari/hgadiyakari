#=====================================================================================================================
# DOCUMENTATION LINK
# https://confluence.csc.com/display/CSA/AZR-10107+and+AZR-10720+Automate+Agent+Health+Report+Generation+and+Dashboard+View
#=====================================================================================================================

[CmdletBinding(SupportsShouldProcess=$true)]
Param
    (
    [Parameter(Mandatory=$true)]  [String]$SubscriptionId,
    [Parameter(Mandatory=$true)]  [String]$TenantId,
    [Parameter(Mandatory=$true)]  [String]$LogAnalyticsWorkspaceName,
    [Parameter(Mandatory=$true)] [ValidateSet("Auto","Yes")] [String]$UpgradeFunctionCodes,
    [Parameter(Mandatory=$true)] [ValidateSet("Auto","Yes")] [String]$UpgradeEnvVariables
    )

#=====================================================================================================================
# CHECK ENVIRONMENT FOR NECESSERY MODULES
#=====================================================================================================================
$dxcModuleList = "DXCEnvCheckV2.psm1", "DXCUtilityFunctions.psm1", "DXCDeploymentFunctions.psm1"
foreach ($dxcModule in $dxcModuleList)
    {
    [String]$dxcModuleURL = "https://dxcazuretools.blob.core.windows.net/installers/DXCPowershellModules/" + $dxcModule
    [String]$dxcLocalModule = Join-path -path $PSScriptRoot -ChildPath $dxcModule
    (New-Object System.Net.WebClient).DownloadFile($dxcModuleURL, $dxcLocalModule)
    Import-Module $dxcLocalModule -WA 0
    Remove-Item -Path $dxcLocalModule
    }

$dxcPSCore = Check-PSCore -Version 7.0.0
if ($dxcPSCore) { $dxcAZ = Check-AzModule -Version 2.5.0 }
if ($dxcAZ) { $dxcAZCli = Check-AzureCLI -Version 2.1.0 }
if ($dxcAZCli) { $dxcAZStorage = Check-PSModule -Name "Az.Storage" -Version 1.5.1 }
if ($dxcAZStorage) { $dxcAZMonitor = Check-PSModule -Name "Az.Monitor" -Version 1.5.0 }
if ($dxcAZMonitor) { $dxcAZOperationalInsights = Check-PSModule -Name "Az.OperationalInsights" -Version 1.3.2 }
if ($dxcAZOperationalInsights) { $dxcAZApplicationInsights = Check-PSModule -Name "Az.ApplicationInsights" -Version 1.0.1 }
if ($dxcAZApplicationInsights){$dxcAZResource = Check-PSModule -Name "Az.Resources" -Version 3.2.0 }
if (!$dxcAZResource)
    {
    Read-Host "`nPress 'ENTER'to exit the script........"
    exit
    }

#=====================================================================================================================
# LOGIN SECTION
#=====================================================================================================================
$error.Clear()
Utility-LoginAZTenant -TenantId $TenantId -SubscriptionId $SubscriptionId
Utility-LoginAureCliTenant -TenantId $TenantId -SubscriptionId $SubscriptionId

#=====================================================================================================================
# VARIABLE SECTION
#=====================================================================================================================#
#$ErrorActionPreference = "SilentlyContinue"
$WarningPreference = "SilentlyContinue"
	
#========================================================================================================================
# MAIN BODY OF THE SCRIPT
#========================================================================================================================

#Sanitise/Clean the Subscription name so it only contains alphanumeric and hyphens, and is less than 63 chars
$subname= (Get-AzSubscription -SubscriptionId (Get-AzContext).Subscription).name
$subnamearray=$subname.tochararray()
$cleanSubName =''
foreach($char in $subNameArray) { if($char -match "[a-zA-Z0-9\-]") { $cleanSubName+=$char }}

# Collect Maintenance ResourceGroup and OMS Workspace Details.
$dxcObjWorkspaces = Get-AzOperationalInsightsWorkspace

ForEach ($dxcObjWorkspace in $dxcObjWorkspaces)
    {
    if ($dxcObjWorkspace.Name -eq $LogAnalyticsWorkspaceName)
        {
        $LogAnalyticsWorkspaceName = $dxcObjWorkspace.Name
        $dxcObjResourceGroup = Get-AzResourceGroup -Name $dxcObjWorkspace.ResourceGroupName
        $dxcResourceGroup = $dxcObjResourceGroup.ResourceGroupName
        $dxcWorkspaceRegion = (($dxcObjWorkspace.location).ToLower()) -replace '\s',''
        $dxcWorkspaceId = $dxcObjWorkspace.CustomerId.Guid
        $dxcWorkspaceResourceId = $dxcObjWorkspace.ResourceId
        $dxcPrimaryKey = (Get-AzOperationalInsightsWorkspaceSharedKeys -ResourceGroupName $dxcResourceGroup -Name $LogAnalyticsWorkspaceName).PrimarySharedKey
        break
        }
    }

If ($dxcResourceGroup -and $dxcWorkspaceRegion -and $dxcWorkspaceId -and $dxcPrimaryKey)
    { Utility-DisplayInfo -dxcstr1 "INFORMATION: Loganalytics Workspace named" -dxcstr2 $LogAnalyticsWorkspaceName -dxcstr3 "located under ResourceGroup" -dxcstr4 $dxcResourceGroup }
else
    {
    Write-Host "WARNING:     Loganalytics Workspace not found. Please enter correct workspace name while running the script." -ForegroundColor Yellow

    Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
    Read-Host "`nPress 'ENTER'to exit the script........"
    exit
    } 
	
Write-Host "`n############################################################"
Write-Host "STAGE1: RESOURCE GROUP DEPLOYMENT SECTION"
Write-Host "############################################################"

[String]$dxcFunctionAppRGName = "dxc-automation-rg"
$dxcRGExtsts, $dxcobjRG = Deploy-ResourceGroup -Name $dxcFunctionAppRGName -Location $dxcWorkspaceRegion

if (!$dxcobjRG)
    {
    Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
    Read-Host "`nPress 'ENTER'to exit the script........"
    exit
    }

if (!$dxcRGExtsts) 
    { 
    $error.Clear()
    New-AzResourceLock -ResourceGroupName $dxcFunctionAppRGName -LockName "DXC-Automation-RG-Lock" -LockNotes "Cannot Delete Lock applied on this Resource Group to avoid accidental deletion of all resources from automation resource group" -LockLevel "CanNotDelete" -Force >$null

    if ($error) { Utility-DisplayWarning -dxcstr1 "WARNING:     Unable to lock the ResourceGroup" -dxcstr2 $dxcFunctionAppRGName -dxcstr " . You need to Manually Lock it against deletion, post deployment." }
    Else { Utility-DisplayInfo -dxcstr1 "INFORMATION: Deletion Lock applied to the ResourceGroup" -dxcstr2 $dxcFunctionAppRGName }
	}
[String]$dxcRandom = Utility-GeneratingUniqueID -dxcResourceGroupName $dxcFunctionAppRGName
[String]$dxcStorageAccountName = 'dxcagt' + $dxcRandom + 'sa'
[String]$dxcAppServicePlan = 'dxc-FuncAppB1-' + $dxcRandom + '-ASP'
[String]$dxcFunctionAppName = 'dxc-NetAppFiles-' + $dxcRandom + '-FA'
[String]$dxcAppInsight = 'dxc-FuncApp-' + $dxcRandom + '-AI'
[String]$dxcFunctionAppIdentityScope = '/subscriptions/' + $SubscriptionId
 
[String]$dxcFunctionFolderZipPath = Join-Path -Path $PSScriptRoot -ChildPath 'Report-NetAppFiles.zip'
[String]$DeploymentZipfile = $dxcFunctionAppName + '.zip'
[String]$dxcZippedFunctionPath = Join-Path -Path $PSScriptRoot -ChildPath $DeploymentZipfile 
[String]$dxcDashboardDeploymentJSONPath = Join-Path -Path $PSScriptRoot -ChildPath 'deployNetAppFilesLogs.json'

Write-Host "`n##########################################################"
Write-Host "STAGE2: STORAGE ACCOUNT DEPLOYMENT SECTION"
Write-Host "############################################################"

$error.Clear()
$dxcStorageExists, $dxcObjStorage = Deploy-StorageAccount -Location $dxcWorkspaceRegion -ResourceGroupName $dxcFunctionAppRGName -Name $dxcStorageAccountName -Container "None" -Table "None" -Queue "ext-health-queue" -Blobfiles "None"

if (!$dxcObjStorage)
    {
    Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
    Read-Host "`nPress 'ENTER'to exit the script........"
    exit
    }

Write-Host "`n##########################################################"
Write-Host "STAGE3: FUNCTIONAPP DEPLOYMENT AND CONFIGURATION SECTION"
Write-Host "##########################################################`n"

#Upgrade FunctionApp if exists and its version number is less than 3
$dxcObjFunctionApp = Get-AzResource -Name $dxcFunctionAppName -ResourceGroupName $dxcFunctionAppRGName -ResourceType "Microsoft.Web/sites" -EA 0

if ($dxcObjFunctionApp) 
    { 
    $function_extension_version = az functionapp config appsettings list --name $dxcFunctionAppName --resource-group $dxcFunctionAppRGName --query "[?name=='FUNCTIONS_EXTENSION_VERSION'].value" | ConvertFrom-Json
    if ($function_extension_version -ne "~3") 
        {
            $AzFunctionAppStorageAccountKey = Get-AzStorageAccountKey -ResourceGroupName $dxcFunctionAppRGName -AccountName $dxcStorageAccountName | Where-Object { $_.KeyName -eq "Key1" } | Select-Object Value
            $AzFunctionAppStorageAccountConnectionString = "DefaultEndpointsProtocol=https;AccountName=$dxcStorageAccountName;AccountKey=$($AzFunctionAppStorageAccountKey.Value);EndpointSuffix=core.windows.net"
            az functionapp config appsettings set --name $dxcFunctionAppName --resource-group $dxcFunctionAppRGName --settings "AzureWebJobsStorage=$AzFunctionAppStorageAccountConnectionString"
            az functionapp config appsettings set --name $dxcFunctionAppName --resource-group $dxcFunctionAppRGName --settings "FUNCTIONS_EXTENSION_VERSION=~3"  
            az functionapp config appsettings set --name $dxcFunctionAppName --resource-group $dxcFunctionAppRGName --settings "FUNCTIONS_WORKER_RUNTIME=powershell"  
            # Enable the ApplicationInsights -- Get the ApplicationInsights InstrumentationKey and then enable.
            $instrumentationKey = (Get-AzApplicationInsights -ResourceGroupName $dxcFunctionAppRGName -Name $dxcAppInsight).InstrumentationKey
            az functionapp config appsettings set --name $dxcFunctionAppName --resource-group $dxcFunctionAppRGName --settings "APPINSIGHTS_INSTRUMENTATIONKEY = $instrumentationKey"
		    Set-AzResource -ResourceId "/subscriptions/$SubscriptionId/resourceGroups/$dxcFunctionAppRGName/providers/Microsoft.Web/sites/$dxcFunctionAppName/config/web" -UsePatchSemantics -Properties @{ powerShellVersion = '~7' } -Force
        }
    $function_extension_version = az functionapp config appsettings list --name $dxcFunctionAppName --resource-group $dxcFunctionAppRGName --query "[?name=='FUNCTIONS_EXTENSION_VERSION'].value" | ConvertFrom-Json
    if ($function_extension_version -ne "~3") 
        {
        Utility-DisplayWarning -dxcstr1 "WARNING    : FunctionApp upgradation to" -dxcstr2 "Version 3" -dxcstr3 "failed. Script cannot proceed further."
        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        Read-Host "`nPress 'ENTER'to exit the script........"
        exit
        }
    }
else
    {
    #Deploy FunctionApp if doesn't exit
    $dxcFunctionAppExists = $dxcObjFunctionApp = Deploy-FunctionApp -SubscriptionId $SubscriptionId  -Location $dxcWorkspaceRegion -ResourceGroupName $dxcFunctionAppRGName -Name $dxcFunctionAppName -StorageAccountName $dxcStorageAccountName -AppServicePlanName $dxcAppServicePlan -Sku "B1" -AppInsights $dxcAppInsight -OSType "Windows" -Runtime "powershell" -FunctionVersion 3
    $dxcObjFunctionApp = Get-AzFunctionApp -ResourceGroupName $dxcFunctionAppRGName -Name $dxcFunctionAppName
    If($dxcObjFunctionApp)
        {
        [bool]$FunctionAppExists = $true
        $error.clear()
        Set-AzResource -ResourceId "/subscriptions/$SubscriptionId/resourceGroups/$dxcFunctionAppRGName/providers/Microsoft.Web/sites/$dxcFunctionAppName/config/web" -UsePatchSemantics -Properties @{ powerShellVersion = '~7' } -Force >$null
        if ($error) 
            {
            Utility-DisplayWarning -dxcstr1 "WARNING    : Failed to enforce Powershell 7 environment, the script cannot proceed further."
            Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
            Read-Host "`nPress 'ENTER'to exit the script........"
            exit
            }
        }
    else
        {
        [bool]$FunctionAppExists = $false
        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        Read-Host "`nPress 'ENTER'to exit the script........"
        exit
        }
   }
Write-Host "`n###############################################################"
Write-Host "STAGE4: FUNCTIONAPP IDENTITY AND ENVIRONMENT SETTINGS SECTION"
Write-Host "###############################################################`n"

$error.Clear()
$dxcOutput =  az functionapp identity assign -g $dxcFunctionAppRGName -n $dxcFunctionAppName --role reader --scope $dxcFunctionAppIdentityScope  | ConvertFrom-Json
if($dxcOutput)
    {
    $dxcOutput = $null
    $dxcOutput =  az functionapp identity assign -g $dxcFunctionAppRGName -n $dxcFunctionAppName --role "log analytics contributor" --scope $dxcWorkspaceResourceId  | ConvertFrom-Json
    }

if (!$dxcOutput) 
    {    
    Write-Host "WARNING:     Unable to provide necessery access to FunctionApp. You may not have 'Owner' rights to the subscription." -ForegroundColor Yellow
    Write-Host "             The script will continue to deploy but for proper functioning, some one with owner rights have to assign it the necessery permissions." -ForegroundColor Yellow
    Write-Host "             Please follow the direction in its wiki link to assign permission to this functionapp after deployment." -ForegroundColor Yellow
    }
else
    {
    Write-Host 'INFORMATION: FunctionApp ' -NoNewline -ForegroundColor Green
    Write-Host $dxcFunctionAppName -NoNewline
    Write-Host ' has been provided "Reader" access to the Subscription and "LogAnalytics Contributor" access to the workspace.' -ForegroundColor Green 
    }
    $dxcObjFunctionApp = Get-AzFunctionApp -ResourceGroupName $dxcFunctionAppRGName -Name $dxcFunctionAppName
    If($dxcObjFunctionApp)
        {
            $FunctionAppExists = $true
        }
    else
    {
        $FunctionAppExists = $false
	}
#Set Environtment Variables to FunctionApp
if ($FunctionAppExists -or ($UpgradeEnvVariables -eq "Yes" ))
    {
    $function_extension_version = az functionapp config appsettings list --name $dxcFunctionAppName --resource-group $dxcFunctionAppRGName --query "[?name=='FUNCTIONS_EXTENSION_VERSION'].value" | ConvertFrom-Json
    if ($function_extension_version -ne "~3") 
        {
            Utility-DisplayInfo -dxcstr1 "INFORMATION: FunctionApp named" -dxcstr2 $dxcFunctionAppName -dxcstr3 "being updated to powershell 7"
            $AzFunctionAppStorageAccountKey = Get-AzStorageAccountKey -ResourceGroupName $dxcFunctionAppRGName -AccountName $dxcStorageAccountName | Where-Object { $_.KeyName -eq "Key1" } | Select-Object Value
            $AzFunctionAppStorageAccountConnectionString = "DefaultEndpointsProtocol=https;AccountName=$dxcStorageAccountName;AccountKey=$($AzFunctionAppStorageAccountKey.Value);EndpointSuffix=core.windows.net"
            az functionapp config appsettings set --name $dxcFunctionAppName --resource-group $dxcFunctionAppRGName --settings "AzureWebJobsStorage=$AzFunctionAppStorageAccountConnectionString"
            az functionapp config appsettings set --name $dxcFunctionAppName --resource-group $dxcFunctionAppRGName --settings "FUNCTIONS_EXTENSION_VERSION=~3"  
            az functionapp config appsettings set --name $dxcFunctionAppName --resource-group $dxcFunctionAppRGName --settings "FUNCTIONS_WORKER_RUNTIME=powershell"  
            # Enable the ApplicationInsights -- Get the ApplicationInsights InstrumentationKey and then enable.
            $instrumentationKey = (Get-AzApplicationInsights -ResourceGroupName $dxcFunctionAppRGName -Name $dxcAppInsight).InstrumentationKey
            az functionapp config appsettings set --name $dxcFunctionAppName --resource-group $dxcFunctionAppRGName --settings "APPINSIGHTS_INSTRUMENTATIONKEY = $instrumentationKey"
            Set-AzResource -ResourceId "/subscriptions/$SubscriptionId/resourceGroups/$dxcFunctionAppRGName/providers/Microsoft.Web/sites/$dxcFunctionAppName/config/web" -UsePatchSemantics -Properties @{ powerShellVersion = '~7' } -Force
        }
     $function_extension_version = az functionapp config appsettings list --name $dxcFunctionAppName --resource-group $dxcFunctionAppRGName --query "[?name=='FUNCTIONS_EXTENSION_VERSION'].value" | ConvertFrom-Json
     if ($function_extension_version -ne "~3") 
        {
        Utility-DisplayWarning -dxcstr1 "WARNING    : FunctionApp upgradation to" -dxcstr2 "Version 3" -dxcstr3 "failed. Script cannot proceed further."
        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        Read-Host "`nPress 'ENTER'to exit the script........"
        exit
        }

    Write-Host "INFORMATION: Settting up environment variable for the powershell function...." -ForegroundColor Green
    $dxcOutput = az functionapp config appsettings set --name $dxcFunctionAppName --resource-group $dxcFunctionAppRGName `
        --settings "AZURE_WORKSPACE_NAME=$LogAnalyticsWorkspaceName" "AZURE_WORKSPACE_RG=$dxcResourceGroup" "AZURE_WORKSPACE_ID=$dxcWorkspaceId" "AZURE_WORKSPACE_KEY=$dxcPrimaryKey" "ApplicationInsightsAgent_EXTENSION_VERSION=true" | ConvertFrom-Json

        if (!$dxcOutput) 
        { 
        Write-Host "WARNING:     Unable to set environment variables to FunctionApp. Script will exit now." -ForegroundColor Yellow

        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        Read-Host "`nPress 'ENTER'to exit the script........"
        exit
        }
    Write-Host "INFORMATION: Environment variable setup completed successfully." -ForegroundColor Green
    }

#Apply Security Settings
deploy-FunctionAppSecurity -FunctionAppName $dxcFunctionAppName -ResourceGroupName $dxcFunctionAppRGName -Location $dxcWorkspaceRegion -AppServiceAuthOn -HTTPSOnly -HTTP20Enabled -FTPDisabled
Start-Sleep -s 65

Write-Host "`n##########################################################"
Write-Host "STAGE5: FUNCTION DEPLOYMENT SECTION"
Write-Host "##########################################################`n"

if ($dxcFunctionAppExists -or ($UpgradeFunctionCodes -eq "Yes" ))
    {
    
    # AZR-19421: Change section to deploy source code via temporary zip file
    # Copy-Item $dxcFunctionFolderZipPath $dxcZippedFunctionPath  # TODO: Replace this section

    # First clear any old version of the zipped source

    if (Test-Path -Path $dxcZippedFunctionPath){
        Remove-Item -Path $dxcZippedFunctionPath
    }
    # Copy function app source to temporary zip file for deployment

    Compress-Archive -Path 'Functions/*' -DestinationPath $dxcZippedFunctionPath -force #path separator works on Mac OSx as well as windows, but this is not elegant


    $error.Clear()
    $dxcOutput = az functionapp deployment source config-zip -g $dxcFunctionAppRGName -n $dxcFunctionAppName --src $dxcZippedFunctionPath | ConvertFrom-Json
    Remove-Item -Path $dxcZippedFunctionPath -Force >$null

    if (!$dxcOutput) 
        { 
        Utility-DisplayWarning -dxcstr1 "WARNING:     Unable to deploy" -dxcstr2 $dxcZippedFunctionPath -dxcstr3 " . Script will exit now."
        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        Read-Host "`nPress 'ENTER'to exit the script........"
        exit
        }
    Utility-DisplayInfo -dxcstr1 "INFORMATION: Function from zip file" -dxcstr2 $dxcZippedFunctionPath -dxcstr3 "has been deployed successfully."
    }

Write-Host "`n##########################################################"
Write-Host "STAGE6: FUNCTIONAPP ALERT DEPLOYMENT SECTION"
Write-Host "##########################################################`n"

Utility-DisplayInfo -dxcstr1 "INFORMATION: Run the below command in powershell 7.x console, from" -dxcstr2 "...\OnBoarding\Alerting\FunctionAppAlertDeployment\" -dxcstr3 "folder to deploy alerts for this FunctionApp"
Write-Host ".\deployFunctionAppAlerts.ps1 -functionAppName $dxcFunctionAppName -appInsightsName $dxcAppInsight -logAnalyticsWorkspaceName $LogAnalyticsWorkspaceName -subscriptionId $SubscriptionId -applicationName 'dxc-NetAppFiles'"
Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0   

Write-Host "`n*****************End OF SCRIPT EXECUTION*****************"
