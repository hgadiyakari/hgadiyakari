﻿      #Parameter for Maintenance Token      
      Param
        (
         [Parameter(Mandatory=$true)]  [String]$MaintenanceToken
         )

        #Validation of Crowdstrike version
        $csversion = (Get-WmiObject -Class win32_product | Where-Object {$_.name -EQ "CrowdStrike Sensor Platform"}).version
        if ($csversion -ge "5.10.9106")
        {

        #Storing CSuninstall.exe tool in blob
        $Toolurl = "https://dxcazuretoolsdev.blob.core.windows.net/installers/CsUninstallTool.exe"
       
       #Location to store the downloaded tool
        $ToolLocation = "C:\Windows\Temp\CsUninstallTool.exe"

       #Command to download tool from storage blob
       (New-Object System.Net.WebClient).DownloadFile($Toolurl, $ToolLocation)

       #Commmand to uninstall Crowdstrike 

       $Installer = Start-Process -FilePath $ToolLocation -argumentlist "Maintenance_Token=$MaintenanceToken /quiet" -Wait -PassThru 
       }
       else
       {
       Write-Host "Unsupported crowdstrike Version"
       }