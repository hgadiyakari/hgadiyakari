<#
=====================================================================================================================
NOTE:  If this script is not run in the Azure Portal Cloud Shell (Powershell), then the user must have the Powershell
Az (NOT AzureRM) modules installed and working
=====================================================================================================================
AUTHOR:  Tim Vrazo 
DATE:    26 June 2019
UPDATE:  20 August 2019 - Cosmetic cleanup, remove debug code
UPDATE:  27 August 2019 - Consolidated code down from 3 "remove" functions, to 1 unified function, added -force to the remove-resource cmdlet
UPDATE:  05 September 2019 - Removed the "1 unified function", and made the whole script "functionless" (with the exception of the "bail" (or exit) function
UPDATE:  21 October 2019 - added functionality to the DISK switch (around line 100) that filters out any ASR volumes that may be idle, but should not be deleted because they are part of an ASR set
UPDATE:  30 October 2019 - added subscriptionCheck() function
UPDATE:  3 August 2020 - AZR-13536 Fixed error on deletion of single remaining ophaned resource
UPDATE:  4 August 2020 - AZR-15057 Add Removal of Boot Diagnostics to Orphaned Resources Script

Version: 1.0
Documentation: https://confluence.csc.com/pages/viewpage.action?pageId=170853309
======================================================================================================================
.SYNOPSIS
    Tool for removing vNIC, Public IP and Disk resources that are not associated with any VM
.DESCRIPTION
    .PARAMETER  <there are none - this is a placeholder only>
		There are no parameters for this script.
.EXAMPLE
.\removeOrphanedResources.ps1
#>
#The following Parameter placeholder is here so that the "-WhatIf" commandline (script) parameter will be in effect for all the cmdlets in this script that use it
[CmdletBinding(SupportsShouldProcess=$true)]
Param(
	[Parameter(Mandatory=$false)] [String]$placeholder
)
function subscriptionCheck()
{
	Clear-Host
	""
	""
	"*****************************************************************"
	"* VM REMOVAL SCRIPT - REMOVE VM AND ASSOCIATED RESOURCES *"
	"*****************************************************************"
	""
	""
	"Your Azure Context (Subscription) is currently set to:"
	""
	try {
		$azContext=Get-AzContext
		if ($azContext -eq $null) {
			"Please log in to Azure using Connect-AzAccount -SubscriptionName <Name of Subscription> and re-run this script."
			""
			bail "noop"
		}
		else {
			$azContext
			""
			$subOk=$null
			while ($subOK -ne "Y") {
				$subOk=read-host 'Is this the subscription you wish to proceed with? (Y/y to proceed, or N/n to quit)'
				if ($subOk -eq "Y" -or $subOk -eq "N") {
					if ($subOk -eq "Y") {
						""
						"OK - proceeding with the provided subscription."
						""
						pause
					}
					else {
						""
						"Please set your powershell session to desired subscription using Set-AzContext -Subscription <Name of Subscription> and re-run this script"
						""
						bail "noop"
					}
				}
				else {
					"ERROR: Invalid entry.  Please enter Y/y or N/n to proceed or quit."
					pause
				}			
			}
		}
	}
	catch
	{
		""
		'There was an error running the Get-AzContext cmdlet. This may be because the Azure (Az) modules - which are required to run this script - are not installed. Please install them using "Install-Module Az".  If you already have AzureRM modules installed, they may have to be uninstalled first.  Please refer to https://azure.microsoft.com/en-us/blog/how-to-migrate-from-azurerm-to-az-in-azure-powershell/ for more detail on how to do this.'
		""
		bail "error"

	}
}
function bail($action) {
	switch ($action) {
		'normal' {
			""
			"Exiting from the script.  Goodbye."
			""
			$exitCode=0
		}
		'error' {
			""
			"Exiting due to error.  "
			""
			$exitCode=1
		}
	}
	"end"
	get-date -format o
	try {
		Stop-Transcript
	}
	catch {
		"unable to stop transcript at "+(get-date -format o)|Out-File $log -Append -Encoding ascii
	}
	exit $exitCode
}
#
#MAIN
#
$log=".\removeOrphanedResources.log"
try {
	Start-Transcript $log -Append
}
catch {
	"unable to start transcript at "+(get-date -format o)|Out-File $log -Append -Encoding ascii
}
#
subscriptionCheck
$thisIsFirstPass=$true
while($true) {
	if($thisIsFirstPass) {
		while($thisIsFirstPass) {
			clear-host
			"*************************************************************************"
			"* ORPHANED RESOURCES SCRIPT - REMOVE RESOURCES NOT ASSOCIATED WITH A VM *"
			"*************************************************************************"
			""
			#Ask user which resource type to delete on the first pass
			$firstPassResponse = read-host "Enter the type of resource you wish to delete wish to delete (n=vNIC, i=PublicIP, d=Disk, b=BootDiagnostics, q=quit)" 
			if ($firstPassResponse -eq "n" -or $firstPassResponse -eq "i" -or $firstPassResponse -eq "d" -or $firstPassResponse -eq "b" -or $firstPassResponse -eq "q") {
				$thisIsFirstPass=$false
			}
			else {
				"ERROR: Invalid entry.  Please enter i/n/d/b/q to navigate or quit."
				pause
			}
		}
		switch($firstPassResponse){
			'n' {$resourceType = "vNIC"}
			'i' {$resourceType = "publicIP"}
			'd' {$resourceType = "DISK"}
			'b' {$resourceType = "BootDiagnostics"}
			'q' {bail "normal"}
		}
	}
	clear-host
			"*************************************************************************"
			"* ORPHANED RESOURCES SCRIPT - REMOVE RESOURCES NOT ASSOCIATED WITH A VM *"
			"*************************************************************************"
	""
	#Load up the $unassociatedResourceList array with a list of resources that are candidates for deletion
	write-host "Generating list of " -f yellow -nonewline; write-host "** ${resourceType}(S) **" -f green -nonewline; write-host " not associated with any VM.  Please wait..." -f yellow
	try {
		
		switch ($resourceType) {
			'vNIC' {[array]$unassociatedResourceList=(Get-AzNetworkInterface | ?{$_.VirtualMachine -eq $null}).Id}
			'publicIP' {[array]$unassociatedResourceList=(Get-AzPublicIpAddress | ?{$_.IpConfiguration -eq $null}).Id}
			'DISK' {[array]$unassociatedResourceList=(Get-AzDisk | %{if (($_.tags.keys | select -index 0) -match 	"ASR-"){"noop" | out-null}else{if ($_.ManagedBy -eq $null) {$_.Id}}})}
			'BootDiagnostics' {
						[array]$unassociatedResourceList = @()
						$storageAccounts = Get-AzStorageAccount | select StorageAccountName, ResourceGroupName
						#Get all VMs. We have to check each on each time since there is no way to search by vmId
						$vmsToCheck = Get-azvm
						foreach($storageAccount in $storageAccounts)
						{
							Write-Host "." -nonewline
							$storageKey = (Get-AzStorageAccountKey -ResourceGroupName $storageAccount.ResourceGroupName -Name $storageAccount.StorageAccountName)[0].Value
							$context = New-AzStorageContext -StorageAccountName $storageAccount.StorageAccountName -StorageAccountKey $storageKey
							try{
								$containers = Get-AzStorageContainer -Context $context -Name bootdiagnostics-* -ErrorAction Stop
							}
							catch
							{
								Write-Host
								Write-host "Error accessing storage account=" $storageAccount.StorageAccountName "Resource Group=" $storageAccount.ResourceGroupName -f red
								Write-Host "You may need to add the IP address of the machine where this script is executed from to the Storage Accounts Firewall and Virtual Networks page" -f red
								Write-Host
							}
							#Only gather boot diagnostics that are no longer associated with a VM
							foreach($container in $containers)
							{
								$vmIdToCheckFor = $container.Name.Substring($container.Name.IndexOf("-",$container.Name.IndexOf("-") + 1)+1)
								$vmMatchFound=$false
								foreach($vmToCheck in $vmsToCheck)
								{
									if ($vmToCheck.VmId -eq $vmIdToCheckFor)
									{
										$vmMatchFound=$true
									}
								}

								#No VM exists for bootdiagnostics container, add it to potential list to remove
								if ($vmMatchFound -eq $false)
								{
									$unassociatedResourceList += ,($container.Name+","+$storageAccount.ResourceGroupName+","+$storageAccount.StorageAccountName)
								}
							}
						}
				   }
		}
	}
	catch {
		"Error generating list of Orphaned ${resourceType}(S).  See  $log for detail."
		bail "error"
	}
	""
	"Done."
	""
	pause
	""

	if($resourceType -eq 'BootDiagnostics')
	{
		#We already have a parsed out list for unassociated boot diagnostics, consisting only of the Resource, RG Name an Storage Account from those records. Just assign it to the display array
		[array]$unassociatedResourceListParsed=$unassociatedResourceList
	}
	else
	{
		#Create a comma delimited list, parsed out from the list of unassociated resource id's, consisting only of the Resource and RG Name from those records
		[array]$unassociatedResourceListParsed=($unassociatedResourceList | foreach-object {
			#parse each record and keep only the fields we need, specifically, Resource and RG Name
			(($_ -split "/")[8] -replace '",')+","+(($_ -split "/")[4] -replace '",')})
	}

	$continue=$true
	#
	#keep looping until user enters a valid response
	while ($continue) {
		clear-host
			"*************************************************************************"
			"* ORPHANED RESOURCES SCRIPT - REMOVE RESOURCES NOT ASSOCIATED WITH A VM *"
			"*************************************************************************"
		""
		write-host "List of " -f yellow -nonewline; write-host "** ${resourceType}(S) *" -f green -nonewline; write-host " not associated with any VM:" -f yellow
		""
		$i=0
		
		#Format the headers of the list
		"{0,-4} {1,-20} {2,-70}" -f "NO.","RESOURCE GROUP","RESOURCE"
		"{0,-4} {1,-20} {2,-70}" -f "---","--------------","---------"
		#
		#Display the list (using the -f format operator) as a fixed-width formatted table of resources
		$unassociatedResourceListParsed | foreach-object {
			$i++
				if($resourceType -eq 'BootDiagnostics')
				{
					"{0,-4} {1,-20} {2,-70}" -f "$i.",$_.split(",")[1],($_.split(",")[2]+"/"+$_.split(",")[0])
				}
				else
				{
					"{0,-4} {1,-20} {2,-70}" -f "$i.",$_.split(",")[1],$_.split(",")[0]
				}
			}
		

		#Sorry, the following line is rather convoluted - but it simply converts DISK to Disk.  Cosmetic.  Don't ask :P
		if ($resourceType -eq "DISK") {
			$resourceType = (Get-Culture).TextInfo.ToTitleCase($resourceType.tolower())
			
		}
		""
		$response = read-host "Enter the number of the"$resourceType" resource to delete or a=Delete All(or jump to another menu: n=vNIC, i=PublicIP, d=Disk, b=BootDiagnostics, q=Quit)" 
		#
		#If $response is not a number corresponding to a resource in the list, but instead is a "jump to" response - rerun this function from the top based on the resourceType returned by responseRouting()
		if ($response -eq "n" -or $response -eq "i" -or $response -eq "d" -or $response -eq "b" -or $response -eq "q") {
			$continue=$false
		    switch($response){
			    'n' {$resourceType = "vNIC"}
			    'i' {$resourceType = "publicIP"}
			    'd' {$resourceType = "DISK"}
				'b' {$resourceType = "BootDiagnostics"}
			    'q' {bail "normal"}
		    }

		}
		else {
			#
			#if $response was not a "jump to" response, then make sure $response, which is a string at this point, ONLY contains numerics, and also isn't a blank.  
			#otherwise the divide-by trick (below) to convert it to numeric won't work.  Also ensure it's within
			#the range of numbers in the resource list
			if($response -match "^[0-9]*$")	{
				#change the response from string to int so it can be decremented
				$response=[int]$response
				#
				#now decrement $response, since the row's number in the list is actually one higher than the array index
				$response--
				#
							   				 
				#is the response within the row number values displayed to the user?
				if($response  -ge 0 -and $response -lt $unassociatedResourceListParsed.length) {
					#response is a valid value, so deletion may proceed
					$continue=$false
					$selectedListEntry=$unassociatedResourceListParsed[$response]
					$selectedResource=$selectedListEntry.split(",")[0]
					$selectedRG=$selectedListEntry.split(",")[1]
					$selectedBootDiagStorageAccount=$selectedListEntry.split(",")[2]
					""
					write-host Removing selected Resource' "'$selectedResource'" 'from Resource Group' "'$selectedRG'" '...please wait... -foregroundcolor yellow
					""
					try {
						if($resourceType -eq 'BootDiagnostics')
						{
							Get-AzStorageAccount -ResourceGroupName $selectedRG -Name $selectedBootDiagStorageAccount | Get-AzStorageContainer | where { $_.Name -eq $selectedResource } | Remove-AzStorageContainer -Force #-whatif
						}
						else
						{
							Remove-AzResource -ResourceId $unassociatedResourceList[$response] -Force #-whatif
						}
					}
					catch {
						"Error removing resource $unassociatedResourceList[$response] .  See  $log for detail."
						bail "error"
					}
					""
					"Done."
					""
					pause
				}
				else {
					#response is not within the valid range - stay in loop and prompt user for valid response
					""
					"ERROR: Invalid entry.  Please enter a number from the list (above), or i/n/d/q to navigate or quit."
					pause
				}
			
			}
			#If user enters a then loop and delete all
			elseif($response -eq "a")
			{
				$continue=$false
				$listCounter=0
				foreach($selectedListEntry in $unassociatedResourceListParsed)
				{
					$selectedResource=$selectedListEntry.split(",")[0]
					$selectedRG=$selectedListEntry.split(",")[1]
					$selectedBootDiagStorageAccount=$selectedListEntry.split(",")[2]

					write-host Removing selected Resource' "'$selectedResource'" 'from Resource Group' "'$selectedRG'" '... -foregroundcolor yellow
					""

					try {
						if($resourceType -eq 'BootDiagnostics')
						{
							Get-AzStorageAccount -ResourceGroupName $selectedRG -Name $selectedBootDiagStorageAccount | Get-AzStorageContainer | where { $_.Name -eq $selectedResource } | Remove-AzStorageContainer -Force #-whatif
						}
						else
						{
							Remove-AzResource -ResourceId $unassociatedResourceList[$listCounter] -Force #-whatif
						}
					}
					catch {
						"Error removing resource $unassociatedResourceList[$listCounter] .  See  $log for detail."
						bail "error"
					}
					$listCounter++
				}
				""
				"Done."
				""
				pause
			}
			else {
				#response is not numeric - stay in loop and prompt user for valid response
				"ERROR: Invalid entry.  Please enter a number from the list (above), or i/n/d/q to navigate or quit."
				pause
			}
		}
	}
 }
