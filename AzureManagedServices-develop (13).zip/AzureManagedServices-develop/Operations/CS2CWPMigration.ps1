#Requires -PSEdition Core
#Requires -Version 7.0
#Requires -Modules @{ ModuleName="Az"; ModuleVersion="3.1.0" }


<#
.SYNOPSIS
Run CS2CWPMigration to install Symantec CWP protection on VMs and replace CrowdStrike protection if present.

.DESCRIPTION
This powershell will pick up all VMs in a resource group pointed to by the resource group parameter.  It will
then determine if the VM is capable of running Symantec CWP and if so, it will install CWP.  If the VM also
has CrowdStrike install, it will remove it only on successful installation of CWP.


.SWITCH log
(Optional) Switch used to indicate that a log file is created for the run. 

.PARAMETER logName
(Optional) This is used to define a name for the log when the above 'log' parameter is used.  The default is 'log4ps.log'
and it is placed in the same directory that this script is run from.

.PARAMETER resourcegroup
(Required) The name of the resource group that contains the VMs to be upgraded.

.PARAMETER clientid
(Optional) The userid from a service principal on the subscription.

.PARAMETER clientkey
(Optional) The password of the service principal.

.PARAMETER tenantid
(Optional) The tenantid of the service principal.

.PARAMETER keyvault
(Optional) The name of a keyvault that contains the additional information required
to run the migration script. If this parameter is not supplied, the script will attempt
to get the keyvault name from the 'DXC-Maint-RG' resource group.  If not found, then
the script will exit.

.SWITCH trace
(Internal Support) Switch used to trace script flow and variables. 

.SWITCH detail
(Internal Support) Switch used to show the return values from Linux VMs.

.SWITCH prototype
(Internal Support) Switch used to exercise the script, but not update any VMs

.PARAMETER limit
(Required) The parameter is used to limit the number of VMs that will be processed concurrently.
This is being used to help reduce the amount of resources being consumed during script processing.


Author:  Kevin Bilderback
Date:    15/04/2020
Version: 1.0
Documentation: https://confluence.dxc.com/display/CSA/AZR-11440%3A+CS2CWPMigration+script+runtime+improvements

        - CStoCWPMigration script - Run CWP installs against multiple VM's at once (AZR-11730)
        - CStoCWPMigration script - Validate all VM's are CWP compatible prior to installation (AZR-11729)
        - CStoCWP Migration Script - Use the key vault for parameters (AZR-11727)
        - CStoCWPMigration Script - Check powershell version (AZR-11728)
        - CStoCWPMigration script - Give user option to specify run log (AZR-11731)


#>
param(
        [Parameter(Mandatory = $false)][switch]$log = $false,
        [Parameter(Mandatory = $false)][string]$logName = "log4ps.log",
        [Parameter(Mandatory = $true)][string]$resourceGroup,
        [Parameter(Mandatory = $true)][string]$clientid,
        [Parameter(Mandatory = $true)][string]$clientkey,
        [Parameter(Mandatory = $true)][string]$tenantid,
        [Parameter(Mandatory = $true)][string]$subscription,
        [Parameter(Mandatory = $false)][String]$keyvault = "",
        [Parameter(Mandatory = $false)][switch]$trace = $false,
        [Parameter(Mandatory = $false)][switch]$detail = $false,
        [Parameter(Mandatory = $false)][switch]$prototype = $false,
        [Parameter(Mandatory = $true)][int]$limit
)

#################################################################
# When making updates to this script, increment the scriptVersion
#################################################################
$scriptVersion = '1.0.0'
#################################################################

#################################################################
# logger variables
#################################################################
$executionPath = $null
$logRequired = $false
$logger = $null

#################################################################
# logger functions
#################################################################
Function initializeLogger() {

        $log4Console = '<LOG4PS level="debug"> 
        <APPENDER type="ConsoleAppender" name="ConsoleAppender" >             
        <LAYOUT type="PatternLayout" pattern="[%lvl]: %log_data"/>         
        </APPENDER>             
        </LOG4PS> '

        $log4PS = '<LOG4PS level="debug">
        <APPENDER type="ConsoleAppender" name="ConsoleAppender" >
        <LAYOUT type="PatternLayout" pattern="[%lvl]: %log_data"/>
        </APPENDER>
        <APPENDER type="RollingFileAppender" name="log.log" maxFileSize="10240" maxBackupFiles="5">
        <LAYOUT type="PatternLayout" pattern="%d %t [%lvl]: %log_data"/>
        </APPENDER>
        </LOG4PS> '


        $parent = [System.IO.Path]::GetTempPath()
        [string] $name = [System.Guid]::NewGuid()
        $tmpDir = New-Item -ItemType Directory -Path (Join-Path $parent $name.replace('-', ''))    
        New-Item -Path $tmpDir -Name "release" -ItemType "directory" | Out-Null   
        New-Item -Path $tmpDir -Name "config" -ItemType "directory" | Out-Null   
        $configDir = "{0}/{1}" -f $tmpDir.ToString().Trim(), 'config' 
        New-Item -Path $configDir -Name "log4ps.xml" -ItemType "file" | Out-Null   
        $configFile = "{0}/{1}" -f $configDir, 'log4ps.xml'
        $configFile = $configFile.replace('/', '\')
        Set-Alias -Scope GLOBAL -Name Logger -Value Logger

        Try {
                if ($log -eq $false) {
                        $log4Console | Out-File $configFile  
                }
                else {
                        $log4PS | Out-File $configFile
                        $logRequired = $true    
                }
        }
        Catch {
                Write-Host "ERROR: Failure to set Config file.  Processing terminated." -ForegroundColor Red
                Remove-Item -LiteralPath $tmpDir -Force -Recurse 1>$null 2>$null 3>$null
                [System.IO.File]::Delete($configFile)
        }

        # Finish up logger initialization
        $executionPath = Split-Path $script:MyInvocation.MyCommand.Path
        $global:logger = global:Logger;
        $global:logger.load($configFile, $logName, $logRequired, $executionPath);
        [System.IO.File]::Delete($configFile)
}
Function destroyLogger() {
        $logger.Destroy();
        Remove-Variable -Name logger -Scope Global -Force
}

<#
#>
function global:ConsoleAppender {
        $obj = New-Object PSObject -Property @{        

                logFileName        = $null;
                logFileChildFolder = $null;
                logFileFolder      = $null;
                backupFolder       = $null;
                logFileFullPath    = $null;
                maxFileSize        = 10000;
                maxBackupFiles     = 0;
                layout             = $null;
                currentCount       = 0;
                currentFileName    = $null;
                currentFileSize    = 0;


        };
    
        $obj | Add-Member -MemberType ScriptMethod -Name load -Value {
    
                <#
            $dateString = Get-Date -format dd\_MM\_yyyy\_HH\_mm\_ss;
        #>        
        
        };       
    
        $obj | Add-Member -MemberType ScriptMethod -Name log -Value {
    
                param($data, $levelType);
        
                $dataToLog = $this.layout.FormatData($data, $levelType);       
                switch ($levelType) {
                        'FATAL' { 
                                Write-Host $dataToLog -ForegroundColor DarkRed
                        }
                        'ERROR' {
                                Write-Host $dataToLog -ForegroundColor RED
                        }
                        'WARN' {
                                Write-Host $dataToLog -ForegroundColor YELLOW
                        }
                        'INFO' {
                                Write-Host $dataToLog -ForegroundColor GREEN
                        }
                        'DEBUG' {
                                Write-Host $dataToLog -ForegroundColor CYAN
                        }
                        'TRACE' {
                                Write-Host $dataToLog -ForegroundColor MAGENTA
                        }
                        default {
                                Write-Host $dataToLog -ForegroundColor WHITE
                        }
                }
        };
    
        <#
        Function: Destroy
        Purpose: Destructor for the class
            
        Params: none
        Returns: none
    #>
        $obj | Add-Member -MemberType ScriptMethod -Name Destroy -Value {

                $this.logFileName = $null;
                $this.logFileChildFolder = $null;
                $this.logFileFolder = $null;
                $this.backupFolder = $null;
                $this.logFileFullPath = $null;
                $this.layout = $null;
                $this.currentFileName = $null; 

        };
        
        <#
        Return object closure
    #>
        return $obj;
}
<#
    Modeled after log4j logger.
#>
function global:Logger {
        $obj = New-Object PSObject -Property @{
    
                className    = $MyInvocation.MyCommand.Name;
                appenders    = @();
                mainLogLevel = 0;
                level        = @{DEBUG = 0; INFO = 1; WARN = 2; ERROR = 3; FATAL = 4 };
        
        };
    
        $obj | Add-Member -MemberType ScriptMethod -Name CallAppenders -Value {
    
                param($data, [int]$levelHeight, $levelType);
        
                if ($levelHeight -ge $this.mainLogLevel) {
                        foreach ($appender in $this.appenders) {
                                $appender.log($data, $levelType);
                        }    
                }
    
        };
    
        $obj | Add-Member -MemberType ScriptMethod -Name debug -Value {
    
                param([string]$data);
        
                $this.CallAppenders($data, $this.level.DEBUG, "DEBUG");
        };

        $obj | Add-Member -MemberType ScriptMethod -Name trace -Value {
    
                param([string]$data);
        
                $this.CallAppenders($data, $this.level.TRACE, "TRACE");
        };
    
        $obj | Add-Member -MemberType ScriptMethod -Name info -Value {
    
                param([string]$data);
        
                $this.CallAppenders($data, $this.level.INFO, "INFO");
        };
    
        $obj | Add-Member -MemberType ScriptMethod -Name warn -Value {
    
                param([string]$data);
        
                $this.CallAppenders($data, $this.level.WARN, "WARN");
        };
    
        $obj | Add-Member -MemberType ScriptMethod -Name error -Value {
    
                param([string]$data);
        
                $this.CallAppenders($data, $this.level.ERROR, "ERROR");
        
        };
    
        $obj | Add-Member -MemberType ScriptMethod -Name fatal -Value {
    
                param([string]$data);
        
                $this.CallAppenders($data, $this.level.FATAL, "FATAL");

        };
    
        $obj | Add-Member -MemberType ScriptMethod -Name load -Value {
    
                param($logFileConfigPath, $logFileName, $logRequired, $executionPath);

                [xml]$config = Get-Content $logFileConfigPath;
                $log4psNode = $config.LOG4PS;
                $defaultLevel = $log4psNode.getAttribute("level");
                $defaultLevel = $defaultLevel.ToUpper();
        
                switch ($defaultLevel) {
                        "DEBUG" { $this.mainLogLevel = $this.level.DEBUG; };
                        "TRACE" { $this.mainLogLevel = $this.level.TRACE; };
                        "INFO" { $this.mainLogLevel = $this.level.INFO; };
                        "WARN" { $this.mainLogLevel = $this.level.WARN; };
                        "ERROR" { $this.mainLogLevel = $this.level.ERROR; };
                        "FATAL" { $this.mainLogLevel = $this.level.FATAL; };            
                };
        
                $appenders = $log4psNode.selectNodes("APPENDER");
                foreach ($appender in $appenders) {
                        $type = $appender.getAttribute("type");
                        $name = $appender.getAttribute("name");
                        $maxFileSize = $appender.getAttribute("maxFileSize");
                        $maxBackupFiles = $appender.getAttribute("maxBackupFiles");
                        $appenderInstance = & (Get-Item function:$type);
                        $logFilePath = $logFileConfigPath.replace("\config\log4ps.xml", "");

                        if ($logRequired -eq $true) {
                                $logFilePath = $executionPath + "\logs\";
                        }
                        else {
                                $logFilePath = $logFilePath + "\logs\";
                        }

                        $appenderInstance.logFileFolder = $logFilePath;            
                        if (!$logFileName) {
                                $appenderInstance.logFileName = $name;
                        }
                        else {
                                $appenderInstance.logFileName = $logFileName;
                        }
                        
                        $appenderInstance.maxFileSize = $maxFileSize;
                        $appenderInstance.maxBackupFiles = $maxBackupFiles;
            
                        $layout = $appender.selectSingleNode("LAYOUT");
                        $type = $layout.getAttribute("type");
                        $pattern = $layout.getAttribute("pattern");
            
                        $layoutInstance = & (Get-Item function:$type);
                        $layoutInstance.pattern = $pattern;
            
                        $appenderInstance.layout = $layoutInstance;
            
                        $appenderInstance.load();
            
                        $this.appenders += $appenderInstance;          
                }
        
        };
    
        $obj | Add-Member -MemberType ScriptMethod -Name SendEmail -Value {
    
                param([string]$emailFrom, [string]$emailTo, [string]$smtpServer, [string]$subject, [string]$body);
     
                $smtp = new-object Net.Mail.SmtpClient($smtpServer);
                $smtp.Send($emailFrom, $emailTo, $subject, $body);

        };

        <#
        Function: Destroy
        Purpose: Destructor for the class
            
        Params: none
        Returns: none
    #>
        $obj | Add-Member -MemberType ScriptMethod -Name Destroy -Value {
        
                $this.appenders = $null;

        };
        
        <#
        Return object closure
    #>
        return $obj;
}
<#
#>
function global:PatternLayout {
        $obj = New-Object PSObject -Property @{
    
                pattern = $null;
        
        };
    
        $obj | Add-Member -MemberType ScriptMethod -Name FormatData -Value {
    
                param($data, $levelType);
        
                $dateString = Get-Date -format dd/MM/yyyy;
                $timeString = Get-Date -format HH:mm:ss;
                $ret = $this.pattern.replace("%d", $dateString);
                $ret = $ret.replace("%t", $timeString);
                $ret = $ret.replace("%lvl", $levelType);
                $ret = $ret.replace("%log_data", $data);
        
                return $ret;
        
        };

        <#
        Function: Destroy
        Purpose: Destructor for the class
            
        Params: none
        Returns: none
    #>
        $obj | Add-Member -MemberType ScriptMethod -Name Destroy -Value {
        
                $this.pattern = $null;
        
        };
        
        <#
        Return object closure
    #>
        return $obj;
}
<#
#>
function global:RollingFileAppender {
        $obj = New-Object PSObject -Property @{
    
                logFileName        = $null;
                logFileChildFolder = $null;
                logFileFolder      = $null;
                backupFolder       = $null;
                logFileFullPath    = $null;
                maxFileSize        = 10000;
                maxBackupFiles     = 0;
                layout             = $null;
                currentCount       = 0;
                currentFileName    = $null;
                currentFileSize    = 0;
        
        };
    
        $obj | Add-Member -MemberType ScriptMethod -Name load -Value {
    
                <#
            $dateString = Get-Date -format dd\_MM\_yyyy\_HH\_mm\_ss;
        #>
        
                if (!$this.logFileChildFolder) {
                        $this.logFileFullPath = $this.logFileFolder + $this.logFileName;
                }
                else {
                        $this.logFileFullPath = $this.logFileFolder + $this.logFileChildFolder + "\" + $this.logFileName;
                }
        
                if (!(Test-Path -path $this.logFileFolder)) {
                        New-Item -path $this.logFileFolder -type directory 1>$null 2>$null 3>$null
                }
        
                if ($this.logFileChildFolder) {
                        $p = $this.logFileFolder + "\" + $this.logFileChildFolder;
                        if (!(Test-Path -path $p)) {
                                New-Item -path $p -type directory 1>$null 2>$null 3>$null
                        }
                }
        
                $this.backupFolder = $this.logFileFolder + "backup";
                if (!(Test-Path -path $this.backupFolder)) {
                        New-Item -path $this.backupFolder -type directory 1>$null 2>$null 3>$null
                }
        
                if (!(Test-Path -path $this.logFileFullPath)) {
                        New-Item $this.logFileFullPath -type file 1>$null 2>$null 3>$null
                }
                else {
                        $this.currentFileSize = (Get-ChildItem -path $this.logFileFullPath | Select-Object Length).Length;
                }
        
                $this.currentCount = $this.DetermineCurrentLogCount();
        
        };
    
        $obj | Add-Member -MemberType ScriptMethod -Name DetermineCurrentLogCount -Value {
    
                $currentLogCount = 1;
        
        
                if ((Test-Path $this.backupFolder)) {
                        $fileCount = (Get-ChildItem $this.backupFolder | Measure-Object).Count;
                        if ($fileCount -lt $this.maxBackupFiles) {
                                $currentLogCount = $fileCount + 1;
                        }
                }
        
                return $currentLogCount;
    
        };
    
        $obj | Add-Member -MemberType ScriptMethod -Name WeCanLog -Value {
    
                param([int]$dataToLogSize);
        
                $ret = $false;
                $this.currentFileSize = $this.currentFileSize + $dataToLogSize;
        
                if ([int]$this.currentFileSize -lt ([int]$this.maxFileSize * 1024)) {
                        $ret = $true;
                }
        
                return $ret;
        
        };
    
        $obj | Add-Member -MemberType ScriptMethod -Name RollLogFile -Value {
            
                if ($this.currentCount -le $this.maxBackupFiles) {      
                        $ext = "_" + $this.currentCount + ".log";
                        $dest = $this.backupFolder + "\" + $this.logFileName.replace(".log", $ext);
                        Move-Item $this.logFileFullPath $dest -force 1>$null 2>$null 3>$null
            
                        $this.currentCount++;
                }
                else {
                        $ext = "_1" + ".log";
                        $dest = $this.backupFolder + "\" + $this.logFileName.replace(".log", $ext);
                        Move-Item $this.logFileFullPath $dest -force 1>$null 2>$null 3>$null
                        $this.currentCount = 2;
                }
        
                $this.currentFileSize = 0;
    
        };
    
        $obj | Add-Member -MemberType ScriptMethod -Name log -Value {
    
                param($data, $levelType);
        
                $dataToLog = $this.layout.FormatData($data, $levelType);
        
                if (!$this.WeCanLog(($dataToLog.length + 2))) {
                        $this.RollLogFile();
                }
        
                Add-Content -path $this.logFileFullPath -value $dataToLog;
    
        };
    
        <#
        Function: Destroy
        Purpose: Destructor for the class
            
        Params: none
        Returns: none
    #>
        $obj | Add-Member -MemberType ScriptMethod -Name Destroy -Value {
        
                $this.logFileName = $null;
                $this.logFileChildFolder = $null;
                $this.logFileFolder = $null;
                $this.backupFolder = $null;
                $this.logFileFullPath = $null;
                $this.layout = $null;
                $this.currentFileName = $null;
        
        };
        
        <#
        Return object closure
    #>
        return $obj;
}

#################################################################
# end logger functions
#################################################################

Function getCredentials {

        param(
                [Parameter(Mandatory = $true)][string]$clientid,
                [Parameter(Mandatory = $true)][string]$clientkey,
                [Parameter(Mandatory = $true)][string]$tenantid,
                [Parameter(Mandatory = $true)][string]$subscription
        )

        # Connect with service principal credentials supplied
        if ($trace -eq $true) {
                $logger.trace("Attempting to connect with submitted credentials:") 
                $logger.trace("    clientid: $clientid") 
                $logger.trace("    clientkey: $clientkey") 
                $logger.trace("    tenantid: $tenantid") 
        }

        $error.Clear()

        $passwd = ConvertTo-SecureString $clientkey -AsPlainText -Force
        $pscredential = New-Object System.Management.Automation.PSCredential($clientid, $passwd)
        Connect-AzAccount -ServicePrincipal -Credential $pscredential -TenantId $tenantid   1>$null 2>$null 3>$null
       
        if ($error) {
                $logger.error("Unable to connect to Azure. Check your Service Principal variables to ensure they are correct and valid.")
                exit
        }
 
        $error.Clear()
        Select-AzSubscription -Subscription $subscription 
        if ($error) {
                $logger.error("Unable to set subscription in Azure. Check your Service Principal and Subscription are correct and valid.")
                exit
        }
        $logger.info("Connected to Azure with submitted Service Principal and Subscription.")
        return $true

}
Function WindowsCSUninstallScript() {
        $script = 'Param `
        ( `
               [Parameter(Mandatory=$true)]  [String]$MaintenanceToken `
        )  `
        $csversion = (Get-WmiObject -Class win32_product | Where-Object {$_.name -EQ "CrowdStrike Sensor Platform"}).version   `
        if ($csversion -ge "5.10.9106") {  `
             $Toolurl = "https://dxcazuretoolsdev.blob.core.windows.net/installers/CsUninstallTool.exe"  `
             $ToolLocation = "C:\Windows\Temp\CsUninstallTool.exe"  `
             (New-Object System.Net.WebClient).DownloadFile($Toolurl, $ToolLocation)  `
             $Installer = Start-Process -FilePath $ToolLocation -argumentlist "Maintenance_Token=$MaintenanceToken /quiet" -Wait -PassThru  `
        }  `
        else {  `
           Write-Host "Unsupported crowdstrike Version"  `
        }'
        return $script
}
Function getVMStatus($vmname) {
        $running = 'no'
        $dc = Get-AzVM -ResourceGroupName $resourceGroup  -Name $vmname  -Status
        foreach ($status in $dc.Statuses.DisplayStatus) {
                if ($status -eq "VM running") {
                        $running = 'yes'
                }
        }
        return $running
}
Function getOSType($resourceGroup) {       
        $VMs = Get-AzVM -ResourceGroupName $resourcegroup | Select-Object Name, @{Name = "OSType"; Expression = { $_.StorageProfile.OSDisk.OSType } } | ForEach-Object { $_.Name + ";" + $_.OSType }
        #Write-Output $VMs
        foreach ($vm in $VMs) {
                $Name, $Type = $vm -split ";"
                if ($Name -eq $vmname) {
                        return $Type
                }
        }
        return $null
}

Function getPowershellVersion($resourceGroup, $vmname, $powershellVersion) {
        try {
                $job = Invoke-AzVMRunCommand -ResourceGroupName $resourceGroup -Name $vmname -CommandId 'RunPowerShellScript' -ScriptPath $powershellVersion -AsJob  
        }
        catch {
                $job = $null
        }
        return $job
}
Function getVMValues($resourceGroup, $vmname, $LinuxCmdFile) {
        try {
                $job = Invoke-AzVMRunCommand -ResourceGroupName $resourceGroup -Name $vmname -CommandId 'RunShellScript' -ScriptPath $LinuxCmdFile -AsJob  
        }
        catch {
                $job = $null
        }
        return $job
}

Function installLinuxCWP($resourceGroup, $vmname, $SymantecDomainId, $SymantecCustomerId, $SymantecCustomerSecretKey, $vmlocation) {
        $job = $null
        $settings = @{"domainId" = "$SymantecDomainId"; "customerId" = "$SymantecCustomerId"; "forceReboot" = "yes" }
        $protectedSettings = @{"customerSecretKey" = "$SymantecCustomerSecretKey" }
        $job = Set-AzVMExtension -VMName $vmname -ResourceGroupName $resourceGroup -Location $vmlocation -Publisher Symantec.CloudWorkloadProtection -ExtensionName SCWPAgentForLinux -ExtensionType SCWPAgentForLinux -Version 2.5 -Settings $settings -ProtectedSettings $protectedSettings -AsJob
        return $job
}

Function installWindowsCWP($resourceGroup, $vmname, $SymantecDomainId, $SymantecCustomerId, $SymantecClientId, $SymantecCustomerSecretKey, $SymantecClientSecretKey, $vmlocation) {
        $job = $null
        $settings = @{"domainId" = "$SymantecDomainId"; "customerId" = "$SymantecCustomerId"; "clientId" = "$SymantecClientId"; "forceReboot" = "yes" }
        $protectedSettings = @{"customerSecretKey" = "$SymantecCustomerSecretKey"; "clientSecretKey" = "$SymantecClientSecretKey" }
        $job = Set-AzVMExtension -VMName $vmname -ResourceGroupName $resourceGroup -Location $vmlocation -Publisher Symantec.CloudWorkloadProtection -ExtensionName SCWPAgentForWindows -ExtensionType SCWPAgentForWindows -Version 2.2 -Settings $settings -ProtectedSettings $protectedSettings -AsJob
        return $job
}


Function removeLinuxCS($resourceGroup, $vmname, $LinuxCSRemoveFile, $clientid, $clientkey, $tenantid, $subscription) {
        # Requiring reconnection because MS poorly plugged a security flaw.  Could use import 
        # context, but it is showing up as expired, so their recommendation is also flawed
        $passwd = ConvertTo-SecureString $clientkey -AsPlainText -Force
        $pscredential = New-Object System.Management.Automation.PSCredential($clientid, $passwd)
        Connect-AzAccount -ServicePrincipal -Credential $pscredential -TenantId $tenantid   1>$null 2>$null 3>$null
        Select-AzSubscription -Subscription $subscription  1>$null 2>$null 3>$null

        $extension = Get-AzVMExtension -ResourceGroupName $resourceGroup -VMName $vmname | Where-Object { $_.Name | Select-String -Pattern 'CrowdStrikeSensor|CrowdStrikeAgent' } | select name 
        Remove-AzVMExtension -ResourceGroupName $resourceGroup -VMName $vmname -ExtensionName $extension.name -Force | Out-Null
        Invoke-AzVMRunCommand -ResourceGroupName $resourceGroup -Name $vmname -CommandId 'RunShellScript' -ScriptPath $LinuxCSRemoveFile   1>$null  2>$null 3>$null
}

Function removeWindowsCS($resourceGroup, $vmname, $WindowsCSRemoveFile, $CSuninstall, $clientid, $clientkey, $tenantid, $subscription) {
        # Requiring reconnection because MS poorly plugged a security flaw.  Could use import 
        # context, but it is showing up as expired, so their recommendation is also flawed
        $passwd = ConvertTo-SecureString $clientkey -AsPlainText -Force
        $pscredential = New-Object System.Management.Automation.PSCredential($clientid, $passwd)
        Connect-AzAccount -ServicePrincipal -Credential $pscredential -TenantId $tenantid   1>$null 2>$null 3>$null
        Select-AzSubscription -Subscription $subscription  1>$null 2>$null 3>$null

        $extension = Get-AzVMExtension -ResourceGroupName $resourceGroup -VMName $vmname | Where-Object { $_.Name | Select-String -Pattern 'CrowdStrikeSensor|CrowdStrikeAgent' } | select name
        Remove-AzVMExtension -ResourceGroupName $resourceGroup -VMName $vmname -ExtensionName $extension.name -Force | Out-Null
        Invoke-AzVMRunCommand -ResourceGroupName $resourceGroup -Name $vmname -CommandId 'RunPowerShellScript' -ScriptPath $WindowsCSRemoveFile -Parameter @{MaintenanceToken = $CSuninstall }   1>$null  2>$null 3>$null
}

Function processRunCmd ($vmname, $runCmd) {
        $outArray = $runCmd.Split([Environment]::NewLine)
        
        foreach ($line in $outArray) {
                if ($detail -eq $true) {
                        $logger.debug("$vmname  line: $line")
                }
                if ($line.startsWith("NAME=")) {
                        $osname = $line.Substring(6, $line.Length - 7)
                }	
                else {
                        if ($line.startsWith("KERNEL=")) {
                                $kernel = $line.Substring(8, $line.Length - 9)
                        }
                }
        }
        $logger.info("    VM: $vmname  OS: $osname  Kernel: $kernel")
        @{"osname" = $($osname); "kernel" = $($kernel) }
}

Function getCWPType([string]$osname, [string]$sku, [string]$offer) {
        if ($osname -match "RED HAT" -or $osname -match "RHEL") {
                if ($sku.StartsWith("cis", 'CurrentCultureIgnoreCase')) {
                        $s = $offer -split ('-')
                        $v = $s[2]
                }
                else {
                        $v = $sku.Substring(0, 1)
                }
                return "rhel$v"
        }
        ElseIf ($osname -match "SLES") {
                $v = $sku.Substring(0, 2)
                return "sles$v"
        }
        ElseIf ($osname -match "UBUNTU") {
                if ($sku.StartsWith("cis", 'CurrentCultureIgnoreCase')) {
                        $s = $offer -split ('-')
                        if ($offer -match '1604') {
                                $v = '16'
                        }
                        elseif (if $offer -match '1804') {
                                $v = '18'
                        }
                }
                else {
                        $v = $sku.Substring(0, 2)
                }
                return "ubuntu$v"
        }
        ElseIf ($osname -match "CENTOS") {
                if ($offer.StartsWith("cis", 'CurrentCultureIgnoreCase')) {
                        $s = $offer -split ('-')
                        $v = $s[2]
                }
                else {
                        $v = $sku.Substring(0, 1)
                }
                return "centos$v"
        }
        ElseIf ($osname -match "ORACLE") {
                if ($sku.StartsWith("cis", 'CurrentCultureIgnoreCase')) {
                        $s = $offer -split ('-')
                        $v = $s[3]
                }
                else {
                        $v = $sku.Substring(0, 1)
                }
                return "oel$v" 
        }
        ElseIf ($osname -match "DEBIAN") {
                $v = $sku.Substring(0, 1)
                return "debian$v"
        }
        ElseIf ($osname -match "WINDOWS") {
                if ($sku.StartsWith("cis", 'CurrentCultureIgnoreCase')) {
                        $s = $offer -split ('-')
                        if ($s[3] -eq '2008' -And $s[4] -eq 'r2') {
                                return("2008r2")  
                        }
                        ElseIf ($s[3] -eq '2012' -And $s[4] -eq 'r2') {
                                return("2012r2")  
                        }
                        ElseIf ($s[3] -eq '2012') {
                                return("2012")  
                        }
                        ElseIf ($s[3] -eq '2016') {
                                return("2016")  
                        }
                        ElseIf ($s[3] -eq '2019') {
                                return("2019")  
                        }
                        else {
                                return($null)
                        }
                }
                if ($sku -match "2008-r2") {
                        return("2008r2")
                }
                ElseIf ($sku -match "2012-r2") {
                        return("2012r2")
                }
                ElseIf ($sku -match "2012") {
                        return("2012")
                }
                ElseIf ($sku -match "2016") {
                        return("2016")
                }
                ElseIf ($sku -match "2019") {
                        return("2019")
                }
                else {
                        return($null)
                }
        }
        Else {
                return $null
        }
}

Function symantecToken($SymantecCustomerId, $symantecDomainId, $SymantecClientId, $symantecClientSecretKey) {
        [int] $MaxRetries = 3
        [int] $WaitBetweenRetries = 1

        $URI = "https://scwp.securitycloud.symantec.com/dcs-service/dcscloud/v1/oauth/tokens"

        $header = @{
                "Accept"             = "application/json"
                "x-epmp-customer-id" = $SymantecCustomerId
                "x-epmp-domain-id"   = $SymantecDomainId
                "Content-Type"       = "application/json"
        }

        $body = @{
                "client_id"     = $SymantecClientId
                "client_secret" = $SymantecClientSecretKey
        } | ConvertTo-Json 

        if ($trace -eq $true) {
                $logger.trace("symantecToken header: $header")
                $logger.trace("symantecToken body: $body")
        }
        $Success = $false
        $RetriesLeft = $MaxRetries

        do {
                try {
                        $Response = Invoke-WebRequest -Uri $URI -Method POST -Body $body -Headers $header
                        $StatusCode = $Response.StatusDescription
                        $StatusCodeInt = $Response.StatusCode
                        $ExceptionOccurred = $false
                        if ($trace -eq $true) {
                                $logger.trace("symantecToken Retry: $RetriesLeft")
                                $logger.trace("symantecToken statusCode: $StatusCode")
                                $logger.trace("symantecToken statusCodeInt: $StatusCodeInt")
                        }
                }
                catch {
                        if ($_.Exception.Response.StatusCode) {
                                $StatusCode = $_.Exception.Response.StatusCode
                                $StatusCodeInt = $StatusCode.value__
                                $StatusText = "Invoke-WebRequest get token returned $StatusCode ($StatusCodeInt)"
                                if ($trace -eq $true) {
                                        $logger.trace("symantecToken Retry: $RetriesLeft")
                                        $logger.trace("symantecToken statusText: $StatusText")
                                }
                        }
                        else {
                                $StatusText = $_.Exception.Message
                                if ($trace -eq $true) {
                                        $logger.trace("symantecToken Retry: $RetriesLeft")
                                        $logger.trace("symantecToken statusText: $StatusText")
                                }
                        }
                        $ExceptionOccurred = $true
                }

                $Success = (($StatusCodeInt -eq 200) -and -not($ExceptionOccurred))
                $RetriesLeft--
                Start-Sleep $WaitBetweenRetries
        }
        while (($Success -eq $false) -and ($RetriesLeft -ge 0))

        if ($Success -eq $false) {
                $logger.error("Unable to obtain a Symantec token.  Processing stopped")
                Exit
        } 
        $token = $Response.Content | ConvertFrom-Json
        return $token.access_token
} 	

Function symantecCheckKernelSupport() {
        param (
                [Parameter(Mandatory = $true)][String]$SymantecCustomerId,
                [Parameter(Mandatory = $true)][String]$SymantecDomainId,
                [Parameter(Mandatory = $true)][String]$token,
                [Parameter(Mandatory = $true)][String]$osname,
                [Parameter(Mandatory = $true)][String]$kernel,
                [Parameter(Mandatory = $true)][String]$vmname,
                [Parameter(Mandatory = $true)][String]$clientid,
                [Parameter(Mandatory = $true)][String]$clientkey,
                [Parameter(Mandatory = $true)][String]$tenantid,
                [Parameter(Mandatory = $true)][String]$subscription


        )

        # Requiring reconnection because MS poorly plugged a security flaw.  Could use import 
        # context, but it is showing up as expired, so their recommendation is also flawed
        $passwd = ConvertTo-SecureString $clientkey -AsPlainText -Force
        $pscredential = New-Object System.Management.Automation.PSCredential($clientid, $passwd)
        Connect-AzAccount -ServicePrincipal -Credential $pscredential -TenantId $tenantid   1>$null 2>$null 3>$null
        Select-AzSubscription -Subscription $subscription  1>$null 2>$null 3>$null

        [int] $MaxRetries = 3
        [int] $WaitBetweenRetries = 1

        $URI = "http://scwp.securitycloud.symantec.com/dcs-service/dcscloud/v1/agents/packages/supported-platforms"

        $header = @{
                "Accept"             = "application/json"
                "x-epmp-customer-id" = $SymantecCustomerId
                "x-epmp-domain-id"   = $SymantecDomainId
                "Content-Type"       = "application/json"
                "Authorization"      = "Bearer " + $token
        }

        $body = @{
                "osDistribution" = $osname
                "kernelVersion"  = $kernel
        } | ConvertTo-Json

        if ($trace -eq $true) {
                $logger.trace("symantecCheckKernelSupport header: $header")
                $logger.trace("symantecCheckKernelSupport body: $body")
        }



        $Success = $false
        $RetriesLeft = $MaxRetries

        do {
                try {
                        $Response = Invoke-WebRequest -Uri $URI -Method PUT -Body $body -Headers $header
                        $StatusCode = $Response.StatusDescription
                        $StatusCodeInt = $Response.StatusCode
                        $ExceptionOccurred = $false
                        if ($trace -eq $true) {
                                $logger.trace("symantecCheckKernelSupport Retry: $RetriesLeft")
                                $logger.trace("symantecCheckKernelSupport statusCode: $StatusCode")
                                $logger.trace("symantecCheckKernelSupport statusCodeInt: $StatusCodeInt")
                        }
                }
                catch {
                        if ($_.Exception.Response.StatusCode) {
                                $StatusCode = $_.Exception.Response.StatusCode
                                $StatusCodeInt = $StatusCode.value__
                                $StatusText = "Invoke-WebRequest check kernel support returned $StatusCode ($StatusCodeInt)"
                                if ($trace -eq $true) {
                                        $logger.trace("symantecCheckKernelSupport Retry: $RetriesLeft")
                                        $logger.trace("symantecCheckKernelSupport statusText: $StatusText")
                                }
                        }
                        else {
                                $StatusText = $_.Exception.Message
                                if ($trace -eq $true) {
                                        $logger.trace("symantecCheckKernelSupport Retry: $RetriesLeft")
                                        $logger.trace("symantecCheckKernelSupport statusText: $StatusText")
                                }
                        }
                        $ExceptionOccurred = $true
                }
                
                $Success = (($StatusCodeInt -eq 200) -and -not($ExceptionOccurred))
                $RetriesLeft--
                Start-Sleep $WaitBetweenRetries
        }
        while (($Success -eq $false) -and ($RetriesLeft -ge 0))

        if ($Success -eq $false) {
                Write-Host "ERROR: Unable to obtain Symantec kernel information for VM: $vmname" -ForegroundColor Red
        }
        $content = $Response.Content | ConvertFrom-Json
        return $content
}

Function findNonNullJobId($hashTable) {
        $JobIds = New-Object System.Collections.Generic.List[System.Object]
        foreach ($key in $hashTable.Keys) {
                if ($null -ne $hashTable[$key].JobId) {
                        $JobIds.add($key)
                }
        }
        return $JobIds.ToArray()
}

Function getKeyVault {
        $rg = Get-AzResourceGroup -Name "DXC-Maint-RG"
        If ($rg.ProvisioningState -eq "Succeeded") {
                $kv = Get-AzKeyVault -ResourceGroupName "DXC-Maint-RG"
                If ($kv) {
                        return $kv.VaultName
                }
        }
        return $null
}



##########################################################
#                           MAIN                         #
##########################################################

initializeLogger
$logger = $global:logger

$hashArray = @{ }
$historyArray = @{ }
$startVM = 1
$iteration = 1

$startTime = (Get-Date)

if ($prototype -eq $true) {
        $logger.info("############################################")
        $logger.info("#        Running in Prototype Mode         #")	
        $logger.info("############################################")
}

# Write out verson of script running
$logger.info("CS2CWPMigration Version: $scriptVersion") 

$currentLogin = getCredentials  $clientid $clientkey $tenantid $subscription

# If keyvault parameter is not input, attempt to get it from the 'DXC-Maint-RG' resource group.
if ($keyvault -eq "" -or $null -eq $keyvault) {
        $keyvault = getKeyVault
        if ($null -eq $keyvault) {
                $logger.error("Keyvault not input and unable to get it from 'DXC-Maint-RG'.")
                exit   
        }
}
# Get Symantec secrets
$SymantecCustomerId = (Get-AzKeyVaultSecret -vaultName $keyvault -name "SymantecCustomerId").SecretValueText
$SymantecDomainId = (Get-AzKeyVaultSecret -vaultName $keyvault -name "SymantecDomainId").SecretValueText
$SymantecClientId = (Get-AzKeyVaultSecret -vaultName $keyvault -name "SymantecClientId").SecretValueText
$SymantecClientSecretKey = (Get-AzKeyVaultSecret -vaultName $keyvault -name "SymantecClientSecretKey").SecretValueText
$SymantecCustomerSecretKey = (Get-AzKeyVaultSecret -vaultName $keyvault -name "SymantecCustomerSecretKey").SecretValueText
$CSuninstall = (Get-AzKeyVaultSecret -vaultName $keyvault -name "CSuninstall").SecretValueText


# Get temporary files to write out commands to be run on VMs
$LinuxCmdFile = New-TemporaryFile
'if [ -f "/etc/system-release" ] || [ -h "/etc/system-release" ]; then echo NAME=\"$(cat /etc/system-release)\"; else cat /etc/os-release; fi' | out-file -filepath $LinuxCmdFile -append
'echo KERNEL=\"$(uname -r)\"' | out-file -filepath $LinuxCmdFile -Append
$LinuxCSRemoveFile = New-TemporaryFile
'sudo yum remove -y falcon-sensor' | out-file -FilePath $LinuxCSRemoveFile
$WindowsCSRemoveFile = New-TemporaryFile
WindowsCSUninstallScript | out-file -FilePath $WindowsCSRemoveFile
$powershellVersion = New-TemporaryFile
'$PSVersionTable.PSVersion' | out-file -filepath $powershellVersion -Append

$logger.info("Loading run queue with data from VM's");
$VMs = Get-AzVM -ResourceGroupName $resourceGroup
if ($trace -eq $true) {
        $total = $VMs.Count
        $logger.trace("Total number of VMs:$total")
}
# Check that limit is at least 1
if ($limit -lt 1) {
        $limit = 1
}
# Set the limit count to max number of VMs if set greater
if ($limit -gt $VMs.Count) {
        $limit = $VMs.Count
}
$endVM = $limit

do {
        $powershellCheck = $false
        if ($trace -eq $true) {
                $logger.trace("startVM:$startVM")
                $logger.trace("endVM:$endVM")
        }
        $logger.info("Iteration number: $iteration")
        $startVM..$endVM | ForEach-Object {
                $i = $_ -as [int]
                $vm = $VMs[$i - 1]
                $vmname = $vm.Name
                $vmEntry = Get-AzVM -ResourceGroupName $resourceGroup -Name $vmname
                $vmlocation = $vmEntry.Location
                # Get to where the information is about sku and offer
                $storageProfile = $vmEntry.StorageProfile
                $imageReference = $storageProfile.ImageReference
                $publisher = $imageReference.Publisher
                $offer = $imageReference.Offer
                $sku = $imageReference.Sku
                $ostype = getOSType $resourceGroup
                $logger.info("    Found $ostype VM: $vmname")
                # Initialize parameters
                $stopped = $false
                $cwpinstalled = ""
                $csinstalled = ""
                $jobId = $null
                $skipped = $false
                # Verify that the VM is in a running state
                $running = getVMStatus $vmname
                if ($running -ne 'yes') {
                        $logger.warn("    VM: $vmname does not appear to be running. Further processing for this VM will be skipped.")
                        $stopped = $true
                        $skipped = $true
                }
                else {
                        $ListofExtension = Get-AzVMExtension -ResourceGroupName $resourceGroup -VMName $vmname | Select-Object Name
                        if ($ListofExtension.Name -match "SCWPAgent") {
                                $logger.warn("    VM: $vmname already has the CWP agent installed.  Further processing for this VM will be skipped.")
                                $cwpinstalled = "installed"
                                $skipped = $true
                        }
                        if (($ListofExtension.Name -match "CrowdStrikeSensor" -or $ListofExtension.Name -match "CrowdStrikeAgent")) {
                                $csinstalled = "installed"
                        }
                }
                
                if ($running -eq 'yes') {
                        if ($ostype -match "windows") {
                                if ($sku -like "2008*") {
                                        $jobId = getPowershellVersion $resourceGroup $vmname $powershellVersion 
                                        $powershellCheck = $true
                                }
                        } 
                }

                $hashElement = @{     
                        "resourcegroup"     = "$resourceGroup"
                        "offer"             = $offer
                        "sku"               = $sku
                        "publisher"         = $publisher
                        "ostype"            = $ostype
                        "jobId"             = $jobId
                        "osname"            = $null
                        "kernel"            = $null
                        "vmlocation"        = $vmlocation
                        "csinstalled"       = $csinstalled
                        "cwpinstalled"      = $cwpinstalled
                        "supported"         = $false
                        "stopped"           = $stopped
                        "powershellVersion" = $null
                        "skipped"           = $skipped
                }
                $hashArray.Add( $vmname, $hashElement )
        }

        # Check if there are any Windows 2008-R2 machines in the current hashArray.
        # If so, then we need to verify that the powershell version is at least at
        # v4 or flag the VM as not processed.
        if ($powershellCheck -eq $true) {
                $logger.info("Wait for Windows 2008 powershell version jobs to complete.")
                foreach ($key in $hashArray.Keys) {
                        if ($null -ne $hashArray[$key].jobId) {
                                if ($trace -eq $true) {
                                        $jobId = $hashArray[$key].jobId.Id
                                        $logger.trace("Processing powershellVersion job on VM: $key with jobId: $jobId")
                                }
                                Wait-Job -Job $hashArray[$key].jobId -Timeout 300 | Out-Null
                                $jobid = [System.Int32]$hashArray[$key].jobId.Id
                                $jobStatus = Get-Job -Id $jobid
                                $state = $jobStatus.State
                                if ($state -ne "Completed") { 
                                        $logger.warn("    VM: $key failed powershell check with status: $state. Further processing for this VM will be skipped.")
                                        $hashArray[$key].skipped = $true
                                }
                                else {
                                        $runCmd = Receive-Job -Job $hashArray[$key].jobId
                                        $j = ConvertTo-Json -InputObject $runCmd | ConvertFrom-Json
                                        $v = $j.Value[0].Message
                                        if ($null -eq $v -Or $v -eq "") {
                                                $i = 1
                                        }
                                        else {
                                                $s = $v -split '\n'
                                                $e = $s | Where-Object { $_ }
                                                $i = [int]$e[2].Substring(0, 3)
                                        }
                                        $hashArray[$key].powershellVersion = $i
                                        if ($i -lt 4) {
                                                $logger.warn("    VM: $key does not have high enough powershell version ($i). Further processing for this VM will be skipped.")
                                                $hashArray[$key].skipped = $true
                                        }
                                        Remove-Job -Job $hashArray[$key].jobId
                                }
                                $hashArray[$key].jobId = $null
                        }
                }
        }

        #  Need to check if there is anything to do in the current hashArray
        #  since the limit count could be set in such a way that all the VMs
        #  selected are either stopped, or already have CWP installed.  In that
        #  case there is nothing to do, so skip the processing
        $required = $false
        foreach ($key in $hashArray.Keys) {
                if ($hashArray[$key].skipped -eq $true) {
                        continue
                }
                $required = $true
        }

        if ($required -eq $false) {
                $logger.info("Nothing to do in this iteration.")
        }
        else {
                $logger.info("Submitting jobs to get Linux kernel values")
                foreach ($key in $hashArray.Keys) {
                        if ($hashArray[$key].ostype -eq 'Linux') {
                                if ($hashArray[$key].skipped -eq $true) {
                                        continue
                                }
                                if ($hashArray[$key].cwpinstalled -ne "installed") { 
                                        $hashArray[$key].jobId = getVMValues $hashArray[$key].resourceGroup $key $LinuxCmdFile
                                        if ($trace -eq $true) {
                                                $jobId = $hashArray[$key].jobId.Id
                                                $logger.trace("Submitting job to get Linux kernel values on VM: $key with jobId: $jobId")
                                        }
                                }
                        }
                }

                $logger.info("Wait for Linux kernel jobs to complete.")
                foreach ($key in $hashArray.Keys) {
                        if ($hashArray[$key].ostype -eq 'Linux') {
                                if ($null -ne $hashArray[$key].jobId) {
                                        if ($trace -eq $true) {
                                                $jobId = $hashArray[$key].jobId.Id
                                                $logger.trace("Processing kernel value job on VM: $key with jobId: $jobId")
                                        }
                                        Wait-Job -Job $hashArray[$key].jobId -Timeout 180 | Out-Null
                                        $jobid = [System.Int32]$hashArray[$key].jobId.Id
                                        $jobStatus = Get-Job -Id $jobid
                                        $state = $jobStatus.State
                                        if ($state -ne "Completed") {
                                                $logger.warn("    VM: $key failed Linux kernel job with status: $state. Further processing for this VM will be skipped.")
                                                $hashArray[$key].skipped = $true
                                        }
                                        else {
                                                $runCmd = Receive-Job -Job $hashArray[$key].jobId | Out-String
                                                $vmvalues = processRunCmd $key $runCmd
                                                $hashArray[$key].osname = getCWPType $vmvalues.osname $hashArray[$key].sku $hashArray[$key].offer | Out-String
                                                $hashArray[$key].osname = $hashArray[$key].osname.Trim()
                                                $hashArray[$key].kernel = $vmvalues.kernel | Out-String
                                                $hashArray[$key].kernel = $hashArray[$key].kernel.Trim()
                                                $osname = $hashArray[$key].osname
                                                $kernel = $hashArray[$key].kernel
                                                if ($trace -eq $true) {
                                                        $logger.trace("os Distribution name: $osname")
                                                        $logger.trace("os Kernel version: $kernel")
                                                }
                                                
                                        }
                                        if ($state -ne "Running") {
                                                Remove-Job -Job $hashArray[$key].jobId
                                        }
                                        $hashArray[$key].jobId = $null
                                }
                        }
                        else {
                                $hashArray[$key].osname = "Windows"
                                $OS = getCWPType $hashArray[$key].osname $hashArray[$key].sku $hashArray[$key].offer | Out-String
                                $hashArray[$key].osname = "windows$OS".Trim()
                                $hashArray[$key].kernel = " "
                                $osname = $hashArray[$key].osname
                                $kernel = $hashArray[$key].kernel
                                if ($trace -eq $true) {
                                        $logger.trace("os Distribution name: $osname")
                                        $logger.trace("os Kernel version: $kernel")
                                }
                        }
                }

                $token = symantecToken $SymantecCustomerId $symantecDomainId $SymantecClientId $symantecClientSecretKey
                $logger.info("Checking VMs against CWP for support.")
                foreach ($key in $hashArray.Keys) {
                        if ($hashArray[$key].skipped -eq $true) {
                                continue
                        }
                        if ($hashArray[$key].cwpinstalled -ne "installed") { 
                                $osname = $hashArray[$key].osname
                                $kernel = $hashArray[$key].kernel
                                $hashArray[$key].jobId = Start-Job -Name $key -ScriptBlock ${function:symantecCheckKernelSupport} -ArgumentList $SymantecCustomerId, $SymantecDomainId, $token, $osname, $kernel, $key, $clientid, $clientkey, $tenantid, $subscription
                                if ($trace -eq $true) {
                                        $jobId = $hashArray[$key].jobId.Id
                                        $logger.trace("Submitting job to check CWP on VM: $key with jobId: $jobId")
                                }
                        }
                }

                $logger.info("Wait for checkCWP jobs to complete.")
                foreach ($key in $hashArray.Keys) {
                        if ($null -ne $hashArray[$key].jobId) {
                                if ($trace -eq $true) {
                                        $jobId = $hashArray[$key].jobId.Id
                                        $logger.trace("Processing CWP check job on VM: $key with jobId: $jobId")
                                }
                                Wait-Job -Job $hashArray[$key].jobId -Timeout 300 | Out-Null
                                $jobid = [System.Int32]$hashArray[$key].jobId.Id
                                $jobStatus = Get-Job -Id $jobid
                                $state = $jobStatus.State
                                if ($state -ne "Completed") { 
                                        $logger.warn("    VM: $key failed checkCWP job with status: $state. Further processing for this VM will be skipped.")
                                        $hashArray[$key].skipped = $true
                                }
                                else { 
                                        $runCheck = Receive-Job -Job $hashArray[$key].jobId
                                        if ($runCheck.supported -eq 'True') {
                                                $hashArray[$key].supported = $true
                                        }
                                        $osname = $hashArray[$key].osname
                                        $kernel = $hashArray[$key].kernel
                                        if ($osname -match "windows") {
                                                $kernel = "n/a"
                                        }
                                        if ($runCheck.supported -ne $true) {
                                                $logger.warn("    VM: $key of type $osname and kernel version of $kernel is not supported by CWP.  Further processing for this VM will be skipped.")
                                                $hashArray[$key].skipped = $true
                                        }
                                        else {
                                                $logger.info("    VM: $key of type $osname and kernel version of $kernel is supported by CWP.")
                                        }
                                        Remove-Job -Job $hashArray[$key].jobId
                                }
                                $hashArray[$key].jobId = $null
                        }
                } 



                if ($prototype -eq $true) {
                        $logger.info("Install CWP agent. Running prototype, no changes will be made to the VMs")
                        foreach ($key in $hashArray.Keys) {
                                if ($hashArray[$key].skipped -eq $true) {
                                        continue
                                }
                                if ($hashArray[$key].supported -eq $true) {
                                        $logger.warn("    VM: $key CWP would have installed.")
                                        $hashArray[$key].cwpinstalled = "installed"
                                }
                        }
                }
                else {

                        $logger.info("Submit install CWP agent.  Please note this section could take up to 10 minutes.")
                        foreach ($key in $hashArray.Keys) {
                                if ($hashArray[$key].skipped -eq $true) {
                                        continue
                                }
                                if ($hashArray[$key].cwpinstalled -ne "installed") { 
                                        if ($hashArray[$key].supported -eq $true) {
                                                if ($hashArray[$key].ostype -eq 'Linux') {
                                                        $hashArray[$key].jobId = installLinuxCWP $hashArray[$key].resourceGroup $key $SymantecDomainId $SymantecCustomerId $SymantecCustomerSecretKey $hashArray[$key].vmlocation 
                                                }
                                                if ($hashArray[$key].ostype -eq 'Windows') {
                                                        $hashArray[$key].jobId = installWindowsCWP $hashArray[$key].resourceGroup $key $SymantecDomainId $SymantecCustomerId $SymantecClientId $SymantecCustomerSecretKey $SymantecClientSecretKey $hashArray[$key].vmlocation 
                                                }
                                                if ($trace -eq $true) {
                                                        $jobId = $hashArray[$key].jobId.Id
                                                        $logger.trace("Submitting job to install CWP on VM: $key with jobId: $jobId")
                                                }
                                        }
                                }
                        }

                        $logger.info("Wait for CWP install jobs to complete.")
                        $jobArray = findNonNullJobId($hashArray)
                        foreach ($key in $jobArray) {
                                if ($null -ne $hashArray[$key].jobId) {
                                        if ($trace -eq $true) {
                                                $jobId = $hashArray[$key].jobId.Id
                                                $logger.trace("Processing CWP install job on VM: $key with jobId: $jobId")
                                        }
                                        Wait-Job -Job $hashArray[$key].jobId -Timeout 900 | Out-Null
                                        $jobid = [System.Int32]$hashArray[$key].jobId.Id
                                        $jobStatus = Get-Job -Id $jobid
                                        $state = $jobStatus.State
                                        if ($state -ne "Completed") { 
                                                $logger.warn("    VM: $key failed CWP install job with status: $state. Further processing for this VM will be skipped.")
                                                $hashArray[$key].skipped = $true
                                        }
                                        else { 
                                                $runInstall = Receive-Job -Job $hashArray[$key].jobId
                                                if ($runInstall.IsSuccessStatusCode -eq 'True') {
                                                        $hashArray[$key].cwpinstalled = "installed" 
                                                        $logger.info("    VM: $key successfully installed CWP ")
                                                }
                                                else {
                                                        $hashArray[$key].cwpinstalled = "failed"
                                                        $logger.warn("    VM: $key CWP installation was not successful")
                                                }
                                                Remove-Job -Job $hashArray[$key].jobId
                                        }
                                        $hashArray[$key].jobId = $null
                                }   
                        } 
                }

                if ($prototype -eq $true) {
                        $logger.info("Remove Crowdstrike agent. Running prototype, no changes will be made to the VMs")
                        foreach ($key in $hashArray.Keys) {
                                if ($hashArray[$key].skipped -eq $true) {
                                        continue
                                }
                                if ($hashArray[$key].csinstalled -eq "installed") {
                                        $logger.warn("    VM: $key CrowdStrike would have been removed.")
                                        $hashArray[$key].csinstalled = "removed" 
                                }
                        }
                }
                else {
 
                        $logger.info("Stage jobs to remove CrowdStrike on VMs that have both CrowdStrike and CWP installed.")
                        foreach ($key in $hashArray.Keys) {
                                if ($hashArray[$key].skipped -eq $true) {
                                        continue
                                }
                                if ($hashArray[$key].cwpinstalled -eq "installed") {
                                        if ($hashArray[$key].csinstalled -eq "installed") {
                                                if ($hashArray[$key].ostype -eq 'Linux') {
                                                        $hashArray[$key].jobId = Start-Job -Name $key -ScriptBlock ${function:removeLinuxCS} -ArgumentList $hashArray[$key].resourceGroup, $key, $LinuxCSRemoveFile, $clientid, $clientkey, $tenantid, $subscription
                                                }
                                                else {
                                                        $hashArray[$key].jobId = Start-Job -Name $key -ScriptBlock ${function:removeWindowsCS} -ArgumentList $hashArray[$key].resourceGroup, $key, $WindowsCSRemoveFile, $CSuninstall, $clientid, $clientkey, $tenantid, $subscription
                                                }
                                                if ($trace -eq $true) {
                                                        $jobId = $hashArray[$key].jobId.Id
                                                        $logger.trace("Submitting job to remove CrowdStrike from VM: $key with jobId: $jobId")
                                                }
                                        }
                                }
                        }
                        
                        $logger.info("Wait for CrowdStrike uninstall jobs to complete.")
                        foreach ($key in $hashArray.Keys) {
                                if ($null -ne $hashArray[$key].jobId) {
                                        if ($trace -eq $true) {
                                                $jobId = $hashArray[$key].jobId.Id
                                                $logger.trace("Processing CrowdStrike uninstall job on VM: $key with jobId: $jobId")
                                        }
                                        Wait-Job -Job $hashArray[$key].jobId -Timeout 900 | Out-Null
                                        $jobid = [System.Int32]$hashArray[$key].jobId.Id
                                        $jobStatus = Get-Job -Id $jobid
                                        $state = $jobStatus.State
                                        if ($state -ne "Completed") { 
                                                $logger.warn("    VM: $key failed CrowdStrike uninstall job with status: $state. Further processing for this VM will be skipped.")
                                                $hashArray[$key].skipped = $true
                                        }
                                        else {
                                                Receive-Job -Job $hashArray[$key].jobId | Out-null
                                                $ListofExtension = Get-AzVMExtension -ResourceGroupName $hashArray[$key].resourceGroup -VMName $key | Select-Object Name
                                                if (($ListofExtension.Name -match "CrowdStrikeSensor" -or $ListofExtension.Name -match "CrowdStrikeAgent")) {
                                                        if ($hashArray[$key].ostype -eq 'Linux') {
                                                                $logger.error("    VM: $key CrowdStrike appears to still be installed.")
                                                        }
                                                        else {
                                                                $logger.error("     VM: $key CrowdStrike appears to still be installed.  Check for unsupported crowdstrike version")  
                                                        }
                                                }
                                                else {
                                                        $logger.info("    VM: $key successfully remove CrowdStrike")
                                                        $hashArray[$key].csinstalled = "removed"
                                                }
                                                Remove-Job -Job $hashArray[$key].jobId
                                        }
                                        $hashArray[$key].jobId = $null 
                                }  
                        } 
                }
        }

        # copy hashArray to the historyArray for reporting purposes
        foreach ($key in $hashArray.Keys) {
                $historyArray.Add($key, $hashArray[$key])
        }
        # Clear out hash table for next iteration
        $hashArray.Clear() 

        $startVM = $startVM + $limit
        $endVM = $endVM + $limit
        if ($endVM -gt $VMs.Count) {
                $endVM = $VMs.Count
        }
        $iteration = $iteration + 1
} while ($startVM -le $VMs.Count)

# Get time it took to run this migration
$endTime = (Get-Date)
$ElapsedTime = (($endTime - $startTime).TotalMinutes)

# Final report of what was (or might have been) done for the run
$logger.info(" ")
if ($prototype -eq $true) {
        $logger.info("#################################################################################################################################")
        $logger.info("#                                                  Prototype results from run                                                   #")	
        $logger.info("#################################################################################################################################")
}
else {
        $logger.info("#################################################################################################################################")
        $logger.info("#                                                     Summary results of run                                                    #")	
        $logger.info("#################################################################################################################################")     
}
$label1 = "VM: "
$label2 = "csinstalled: "
$label3 = "cwpinstalled: "
$label4 = "stopped:"
$label5 = "skipped:"
foreach ($key in $historyArray.Keys) {
        $line = $historyArray[$key].ostype + (" " * (8 - $historyArray[$key].ostype.Length))
        $line = $line + $label1
        $computerName = $key
        if ($computerName.Length -gt 25) {
                $computerName = $computerName.Substring(0, 25) + '...'             
        }
        $line = $line + $computerName + (" " * (33 - $computerName.Length))
        $line = $line + $label2
        $line = $line + $historyArray[$key].csinstalled + (" " * (13 - $historyArray[$key].csinstalled.Length))  
        $line = $line + $label3
        $line = $line + $historyArray[$key].cwpinstalled + (" " * (13 - $historyArray[$key].cwpinstalled.Length)) 
        $line = $line + $label4
        $reportStopped = ""
        if ($historyArray[$key].stopped -eq $true) {
                $reportStopped = " yes"
        }
        $line = $line + $reportStopped + (" " * (10 - $reportStopped.Length)) 
        $line = $line + $label5
        $reportSkipped = ""
        if ($historyArray[$key].skipped -eq $true) {
                $reportSkipped = " yes"
        }
        $line = $line + $reportSkipped + (" " * (10 - $reportSkipped.Length)) 
        $logger.info($line)
}
$logger.info(" ")
$rounded = [math]::Round($ElapsedTime, 2)
$logger.Info("Migration ran in $rounded minutes")
$logger.info(" ")

# Check to see if we need to disconnect the session
if ($currentLogin -eq $true) {
        if ($trace -eq $true) {
                $logger.trace("Disconnecting from AzAccount")
        }
        Disconnect-AzAccount 1>$null 2>$null 3>$null
}
# Remove logger global variable and data from run
destroyLogger
# Remove temporary files
Remove-Item -Path $LinuxCmdFile
Remove-Item -Path $LinuxCSRemoveFile
Remove-Item -Path $WindowsCSRemoveFile
Remove-Item -Path $powershellVersion
