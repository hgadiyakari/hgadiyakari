# Azure Automation Variables - Reporting and Encryption

### Overview

This solution provides automated approach in reporting and resetting automation variables in an Azure subscription.

A PowerShell script is used to perform dual mode of operations - to report and reset variables:
- REPORT - collect all automation variables from automation accounts in active subscription and produce an inventory file.
- RESET - recreate and encrypt select variables from an input file/list and produce a result file.

The script will generate an output report (Excel file) that captures the action. If script is executed with Report action - the output will contain the list of collected variables from the specified target. If the script is executed wth Reset action - the output will contain the result if variable was recreated or not.

Note: Automation variables can only be encrypted at creation time and you need to set the Encrypted parameter as per Microsoft documentation [here](https://docs.microsoft.com/en-us/powershell/module/az.automation/set-azautomationvariable?view=azps-4.8.0#description).

- Parameter

    | Parameter | Type |Mandatory| Description |
    |:--- |:--- |:---|:---
    | action | string | Yes | Use default values only: Report or Reset |
    | subscription | string array | No | Optional parameter to be used with REPORT (-action parameter). Accepts valid input of one or more subscription Id/s or name/s. |
    | inputFile | string | Yes | Mandatory parameter to be used with RESET (-action parameter). Accepts valid input of the absolute path of the Excel (.xlsx) file (where variable list is contained). |
    | customerName | string | Yes | The name of the customer or account. |
- Syntax

    Use Report action parameter:

    .\automationVariables.ps1 -action Report -customerName <customer_name>

    .\automationVariables.ps1 -action Report -subscription <subscriptionId_1> -customerName <customer_name>

    .\automationVariables.ps1 -action Report -subscription <"subscriptionName_2"> -customerName <customer_name>

    .\automationVariables.ps1 -action Report -subscription <subscriptionId_1, subscriptionId_2> -customerName <customer_name>

    .\automationVariables.ps1 -action Report -subscription <subscriptionId_1, "subscriptionName_2"> -customerName <customer_name>

    Use Reset action parameter:

    .\automationVariables.ps1 -action Reset -inputFile .\ReportFile.xlsx -customerName <customer_name>

### Prerequisites
This section lists the requirements to prepare the environment for the script to run correctly.
1. Role-based access with Owner privileges to the subscription
2. PowerShell Core version 7
3. PowerShell Az module version 4.0 or higher
4. Latest version of Azure modules
 - Az.Resources
 - Az.Automation
5. ImportExcel module (https://www.powershellgallery.com/packages/ImportExcel/7.1.0)

### How to run the automation script

Download and extract the script package from the GitHub repository ***cloudops\azure*** to your preferred directory in local drive.

__NOTE: The script executes in dual mode. You need to specify which action to take using the ***-action*** parameter.__


##### REPORT
1. Open PowerShell Core (run as Administrator) and switch to script directory ***cloudops\azure\azure_automationvariable_report***.

2. Execute the following command -

    ```
    .\automationVariables.ps1 -action Report -customerName <customer_name>
    - This executes the report action which targets ALL subscriptions you have access to.

    .\automationVariables.ps1 -action Report -subscription <subscriptionId1, subscriptionId2> `
        -customerName <customer_name>
    - This executes the report action which targets SPECIFIC subscription/s you have access to.
    ```

3. Wait until script execution completes.

4. An Excel file will be created and saved to the script directory where the list of automation variables will be stored.

##### RESET
*Note: The Reset action utilizes the report file generated from the Report action as input file. Only variables found without encryption will be actioned. Please perform the following before proceeding.*

1. Open the Excel file created from the Report action and review which variables will be recreated. The column ***Encrypted*** indicates the current encryption state of the variable - TRUE means variable is encrypted, while FALSE means variable is not encrypted.

    In the column **EnableEncryption(Yes/No)**, tag the entry with ***Yes*** to recreate and encrypt. Otherwise, tag with ***No*** or leave as blank. 

    In the column **Description**, you may also specify an appropriate comment on the variable you want to reset/recreate. This modification will only be applied if the *Encrypted* status is *False* and you have set the *EnableEncryption(Yes/No)* to *Yes*.

2. Save and close the Excel file.

3. Open PowerShell Core (run as Administrator) and switch to script directory ***cloudops\azure\azure_automationvariable_report***.

3. Execute the following commands -

    ```
    .\automationVariables.ps1 -action Reset -inputFile <REPORT.xlsx> -customerName <customer_name>
    - This executes the reset action against the provided input file.
    ```

4. Wait until script execution completes.

5. An Excel file will be created and saved to the script directory where the list of resultant action will be stored (refer to column **ResetVariable**).
