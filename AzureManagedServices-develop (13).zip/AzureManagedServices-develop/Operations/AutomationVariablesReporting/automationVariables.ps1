#-----------------------------------------------------------[Comments]-------------------------------------------------------------
<#
.SYNOPSIS
This PowerShell script collects automation variables and resets encryption.

.EXAMPLE
.\AutomationVariables.ps1 -action Report -subscription <subscriptionId_1, subscriptionId_2> -customerName <customer_name>
.\AutomationVariables.ps1 -action Reset -inputFile .\ReportFile.xlsx -customerName <customer_name>

.NOTES
    Revision history:
    22-Oct-2020 - Initial script development
.LINK
https://confluence.dxc.com/display/ESCAT/Azure+Automation+Variables+-+Reporting+and+Encryption
#>

#---------------------------------------------------------[Initializations]-------------------------------------------------------- 

[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true,Position=1, HelpMessage="Select script action:")]
    [ValidateSet("Report","Reset")]
    [string]$action="Report",
    [Parameter(Mandatory=$true,Position=3, HelpMessage="Enter the customer name:")]
    [string]$customerName
)

DynamicParam {
    if ($action -eq "Report") {
        $paramName_FN = 'subscription'
        $attributeCollection = New-Object System.Collections.ObjectModel.Collection[System.Attribute]
        $ParameterAttribute = New-Object System.Management.Automation.ParameterAttribute
        $ParameterAttribute.HelpMessage = "Please enter target subscription/s:"
        $ParameterAttribute.Mandatory = $false
        $ParameterAttribute.Position = 2
        $AttributeCollection.Add($ParameterAttribute) 
        $RuntimeParameterDictionary = New-Object System.Management.Automation.RuntimeDefinedParameterDictionary
        $RuntimeParameter = New-Object System.Management.Automation.RuntimeDefinedParameter($paramName_FN, [string[]], $AttributeCollection)
        $RuntimeParameterDictionary.Add($paramName_FN, $RuntimeParameter)
        return $RuntimeParameterDictionary   
    }
        if ($action -eq "Reset") {
        $paramName_FN = 'inputFile'
        $attributeCollection = New-Object System.Collections.ObjectModel.Collection[System.Attribute]
        $ParameterAttribute = New-Object System.Management.Automation.ParameterAttribute
        $ParameterAttribute.HelpMessage = "Please enter path and name of the Excel input file:"
        $ParameterAttribute.Mandatory = $true
        $ParameterAttribute.Position = 2
        $AttributeCollection.Add($ParameterAttribute) 
        $RuntimeParameterDictionary = New-Object System.Management.Automation.RuntimeDefinedParameterDictionary
        $RuntimeParameter = New-Object System.Management.Automation.RuntimeDefinedParameter($paramName_FN, [string], $AttributeCollection)
        $RuntimeParameterDictionary.Add($paramName_FN, $RuntimeParameter)
        return $RuntimeParameterDictionary   
    }
}

Begin 
{
#----------------------------------------------------------[Declarations]----------------------------------------------------------

    $scriptName = "AutomationVariables"
    $scriptPath = (Get-Location).ProviderPath
    $logFileName = ($scriptName + '-{0:dd-MMM-yyyy_HHmm}' -f (Get-Date) + '.log')
    $logFilePath = [System.IO.Path]::GetFullPath("$scriptPath\$logFileName")
    $reportFilePath = [System.IO.Path]::GetFullPath("$scriptPath\$($scriptName + '_' + $customerName + '-{0:dd-MMM-yyyy_HHmm}' -f (Get-Date) + '-Report.xlsx')")
    $resetFilePath = [System.IO.Path]::GetFullPath("$scriptPath\$($scriptName + '_' + $customerName + '-{0:dd-MMM-yyyy_HHmm}' -f (Get-Date) + '-Reset.xlsx')")
    $variableCollection = New-Object System.Collections.ArrayList
    $encryptedVariableCollection = New-Object System.Collections.ArrayList

#-----------------------------------------------------------[Functions]------------------------------------------------------------

    # Capture the time information for logging purposes.
    filter timestamp {"$(Get-Date -Format MM-dd-yyyy-hh:mm:ss): $_"}

    function Check-Login # Verify current connectivity to Azure and if login is required.
    { 
        if (!(Get-AzContext)) {
            Write-Output "INFO: Please login to Azure Resource Manager." | timestamp | Write-Host -F Cyan
            Connect-AzAccount -WA 2
            if ($error) {
                Write-Output "ERROR: Failed to connect to Azure Resource Manager. Check your internet connection and verify authentication details." `
                    | timestamp | Write-Host -F Red ; exit
            } 
        } else {
            Write-Output "INFO: Connected to Azure with provided authentication." | timestamp | Write-Host -F Yellow    
        }
    }

    $PSBoundParameters.Keys | ? { !(Get-Variable -name $_ -Scope 0 -EA 0) } | ForEach { New-Variable -Name $_ -Value $PSBoundParameters[$_] }
}

Process 
{
#-----------------------------------------------------------[Execution]------------------------------------------------------------
    try {

        $error.clear() ; $start = Get-Date

        # Create the log file.
        New-Item $logFilePath -ItemType File -Force | Out-Null   
        Start-Transcript -Path $logFilePath -Append -EA 0 | Out-Null
        Write-Output "INFO: Script execution started." | timestamp | Write-Host -F Yellow

        # Login to Azure
        Check-Login
        Get-AzContext -EA 1 | fl

        if ($action -eq "Report") {
            if ($subscription) {
                $subscriptionsList = $subscription
            } else {
                $subscriptionsList = (Get-AzSubscription).Id
            }
            foreach ($sub in $subscriptionsList) {
                Set-AzContext -Subscription $sub -EA 1 | Out-Null
                
                # Fetch all automation account resources in subscription
                Write-Output "INFO: Start collection on all automation variables in " | timestamp | Write-Host -F Yellow -NoNewline
                Write-Host -F Cyan $sub
                $automationAcountsList = Get-AzResource -ResourceType 'Microsoft.Automation/AutomationAccounts' -EA 0
                if ($null -ne $automationAcountsList) {
                    foreach ($automationAccount in $automationAcountsList) {
                    Write-Host "Checking variables in $($automationAccount.Name)... " -NoNewline
                        # Fetch all variables in the automation account
                        $automationVariablesList = Get-AzAutomationVariable `
                            -ResourceGroupName $automationAccount.ResourceGroupName `
                            -AutomationAccountName $automationAccount.Name
                        if ($null -ne $automationVariablesList) {
                            $automationVariablesList | Add-Member -MemberType NoteProperty -Name SubscriptionId -Value $automationAccount.ResourceId.Split("/")[2]
                            $automationVariablesList | Add-Member -MemberType NoteProperty -Name SubscriptionName `
                                -Value (Get-AzSubscription -SubscriptionId $automationAccount.ResourceId.Split("/")[2]).Name
                            $variableCollection+=($automationVariablesList | Select-Object SubscriptionId, SubscriptionName, AutomationAccountName, `
                                ResourceGroupName, Name, Description, Encrypted, CreationTime, LastModifiedTime, EnableEncryption`(Yes/No`))
                        }
                        Write-Host "done."
                    }
                } 
            }

        }

        if ($action -eq "Reset") {
            Write-Output "INFO: Start validation of the input file." | timestamp | Write-Host -F Yellow
            Write-Host "Importing the input file... " -NoNewLine
            $requiredHeaders = @("SubscriptionId", "SubscriptionName", "AutomationAccountName","ResourceGroupName","Name","Description","Encrypted","CreationTime","LastModifiedTime","EnableEncryption(Yes/No)")
            if (Test-Path -Path $inputFile) {
                $inputFileContent = Import-Excel -Path $inputFile -EA 1
                if ($inputFileContent[0].psObject.Properties.Name | ? -FilterScript { $_ -notin $requiredHeaders }) {
                    Write-Host -F Red "Failed to import the input file due to missing headers - $requiredHeaders `nPlease ensure file contains valid input."; exit
                }
                $enableEncryptionList = $inputFileContent | ? { $_.'EnableEncryption(Yes/No)' -like "yes*" }
                if ($null -eq $enableEncryptionList) {
                    Write-Host -F DarkMagenta "No variables were tagged for encryption. Please check input file and ensure the column EnableEncryption has valid entries of Yes/No."; exit
                } else {
                    Write-Host -F Green "File imported successfully."
                }
            } else {
                Write-Host -F Red "Failed to import the input file from the provided path. Please ensure file path is correct."; exit
            }
            Write-Output "INFO: Start validation of all automation variables for encryption." | timestamp | Write-Host -F Yellow
            foreach ($variableItem in $enableEncryptionList) {
                Set-AzContext -Subscription $variableItem.SubscriptionId -EA 0 | Out-Null
                if ($error) { $error.clear() ; continue }
                $variableObj = Get-AzAutomationVariable -ResourceGroupName $variableItem.ResourceGroupName `
                    -AutomationAccountName $variableItem.AutomationAccountName -Name $variableItem.Name -EA 0
                if ($variableObj) {
                    Write-Host "Recreating and setting encryption on variable - " -NoNewline; 
                    Write-Host -F Cyan $($variableItem.Name) -NoNewline; Write-Host " in $($variableItem.AutomationAccountName)... " -NoNewline
                    if ($variableObj.Encrypted -eq $false) {   
                        Remove-AzAutomationVariable -ResourceGroupName $variableObj.ResourceGroupName `
                            -AutomationAccountName $variableObj.AutomationAccountName -Name $variableObj.Name -EA 0
                        $error.clear()
                        try {
                            if ($null -eq $variableItem.Description) {
                                $encryptVariable = New-AzAutomationVariable -ResourceGroupName $variableObj.ResourceGroupName `
                                    -AutomationAccountName $variableObj.AutomationAccountName -Name $variableObj.Name `
                                    -Value $variableObj.Value -Encrypted $true -EA 0
                        
                            } else {
                                $encryptVariable = New-AzAutomationVariable -ResourceGroupName $variableObj.ResourceGroupName `
                                    -AutomationAccountName $variableObj.AutomationAccountName -Name $variableObj.Name `
                                    -Description $variableItem.Description -Value $variableObj.Value -Encrypted $true -EA 0
                            }
                            Write-Host -F Green "successful." ; $resetVariable = $true
                        } catch {
                                Write-Host -F Red "failed." ; $resetVariable = $false
                                $error.clear() ; continue
                        }
                    } else {
                        Write-Host "already encrypted, skipped." ; $resetVariable = $false
                    }
                    $encryptedVariableObj = Get-AzAutomationVariable -ResourceGroupName $variableItem.ResourceGroupName `
                        -AutomationAccountName $variableItem.AutomationAccountName -Name $variableItem.Name
                    $encryptedVariableObj | Add-Member -MemberType NoteProperty -Name SubscriptionId -Value $variableItem.SubscriptionId
                    $encryptedVariableObj | Add-Member -MemberType NoteProperty -Name SubscriptionName `
                        -Value (Get-AzSubscription -SubscriptionId $variableItem.SubscriptionId).Name
                    $encryptedVariableObj | Add-Member -MemberType NoteProperty -Name EnableEncryption`(Yes/No`) -Value $variableItem.'EnableEncryption(Yes/No)'
                    $encryptedVariableObj | Add-Member -MemberType NoteProperty -Name ResetVariable -Value $resetVariable
                    $encryptedVariableCollection+=($encryptedVariableObj | Select-Object SubscriptionId, SubscriptionName, AutomationAccountName, `
                        ResourceGroupName, Name, Description, Encrypted, CreationTime, LastModifiedTime, EnableEncryption`(Yes/No`), ResetVariable)
                } else {
                    Write-Host -F Gray "Unable to find variable named $($variableItem.Name) in $($variableItem.AutomationAccountName)." ; $resetVariable = $false
                    $variableItem | Add-Member -MemberType NoteProperty -Name ResetVariable -Value $resetVariable
                    $encryptedVariableCollection+=($variableItem | Select-Object SubscriptionId, SubscriptionName, AutomationAccountName, `
                        ResourceGroupName, Name, Description, Encrypted, CreationTime, LastModifiedTime, EnableEncryption`(Yes/No`), ResetVariable)
                }
            }

        }

    } 
    catch {

        Write-Output "ERROR: Script executed with errors. $error" | timestamp | Write-Host -F Red

    } 
    finally {

        if (!$error) {         
            if ($action -eq "Report") {
                # Generate the inventory report
                $variableCollection | Export-Excel -WorksheetName $customerName -Path $reportFilePath -Append -Show
                $reportFile = $reportFilePath
            }
            if ($action -eq "Reset") {
                # Generate reset output report
                $encryptedVariableCollection | Export-Excel -WorksheetName $customerName -Path $resetFilePath -Append -Show
                $reportFile = $resetFilePath
            }
            Write-Output "INFO: Report is created successfully - $reportFile." | timestamp | Write-Host -F Green -NoNewline
        }
        
        Write-Output "INFO: Script execution finished. Refer to log - $logFilePath" | timestamp | Write-Host -F Yellow
        Stop-Transcript -EA 0 | Out-Null ;  $end = Get-Date
        Write-Host -F DarkGray "Script duration (mins):" ([math]::Round(($end - $start).TotalMinutes,2))
        Remove-Variable * -Force -EA 0 ; $error.Clear()

    }
}