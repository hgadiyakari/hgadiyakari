<#=================================================================================================================
Required - Powershell Version 7.0, Azure CLI Version 2.1.0
===================================================================================================================
===================================================================================================================
AUTHOR:  David Warren
DATE:    05/05/2021
Version: 0.1
Confluence Doc: https://confluence.dxc.com/display/CSA/AZR-22444+Create+Upgrade+Powershell+script+for+Tagging+Schema

 (c) Copyright DXC Technology, 2021. All rights reserved
==================================================================================================================
.SYNOPSIS
Apply Tagging schema changes to Resources DXC Manages in an Azure Subscription
.DESCRIPTION
This script will retrieve the list of resources that DXC has monitoring or management capabilities for and place
them in a CSV file, that can then be updated with appropriate values.  This script also allows the Operator to 
upload a csv file to tag the listed resources.  Finally, it provides an option to remove the DXC_AutoDeploy tag
from all resources in a subscription.
.PARAMETER subscriptionId
(Required for all operations) The subscription id to be updated 
.PARAMETER tenantId
(Required for all Operations) The tenant id of the scription to be updated
.PARAMETER mode
(Required for all Operations) The mode in which the script should run, valid values are "GetResources",
"UpdateResources", and "RemoveAutoDeployTag"
.PARAMETER workspaceName
(Required for some Operations) The workspaceName that dxcMonitored resources in a subscription should 
report to
.PARAMETER resourceGroup
(Optional) if set, then only the specified resourceGroup within a subscription will be queried or updated
.PARAMETER resourceCSV
(Optional) Specifies the name of the csv file containing the list of the resources to be updated when using
"UpdateResources" mode
.PARAMETER spKey
(Optional) Service Principal key to use when running in unattended operations
.PARAMETER clientID
(Optional) Client Identifier for use when performing Service Principal based authentication
#>

#Requires -PSEdition Core
#Requires -Version 7.0
#Requires -Modules @{ ModuleName="Az.Resources"; ModuleVersion="3.5.0" }
#Requires -Modules @{ ModuleName="Az.OperationalInsights"; ModuleVersion="1.3.3" }
#Requires -Modules @{ ModuleName="Az.Monitor"; ModuleVersion="2.0.1" }

#Collect required parameters
[CmdletBinding(SupportsShouldProcess=$true)]
Param
    (
    [Parameter(Mandatory=$true)] [String]$subscriptionId,
    [Parameter(Mandatory=$true)] [String]$tenantId,
    [Parameter(Mandatory=$true)] [ValidateSet("GetResources","UpdateResources","RemoveAutoDeployTag")] [String]$mode,
    [Parameter(Mandatory=$false)] [String]$workspaceName,
    [Parameter(Mandatory=$false)] [String]$resourceGroup,
    [Parameter(Mandatory=$false)] [String]$resourceCsv,
    [Parameter(Mandatory=$false)] [String]$spKey,
    [Parameter(Mandatory=$false)] [String]$clientID
    )

$WarningPreference = "SilentlyContinue"
##############################################
# Functions
##############################################
Function isValidBoolean($inputTagValue) {
    $validTagValues = @(
        "TRUE",
        "FALSE"
    )
    if ($inputTagValue.ToUpper().Trim() -in $validTagValues) {
        return $true
    } else {
        return $false
    }
}

Function isPositiveTagValue($inputTagValue) {
    $positiveTagValues = @(
        "TRUE"
    )

    if ($inputTagValue.ToUpper().Trim() -in $positiveTagValues) {
        return $true
    } else {
        return $false
    }
}

Function validateBackupPolicy($resourceId, $backupVaultName, $backupPolicy) {
    
    $backupStatus = Get-AzRecoveryServicesBackupStatus -ResourceId $resourceId 
    if ($backupStatus.BackedUp) {
        $actualBVName = Get-AzResource -ResourceId $backupStatus.VaultId | Select-Object -ExpandProperty Name
        $resource = Get-AzResource -ResourceId $resourceId 
        $backupContainer = Get-AzRecoveryServicesBackupContainer -VaultId $backupStatus.VaultId -ContainerType "AzureVM" -FriendlyName $resource.Name -ResourceGroupName $resource.ResourceGroupName
        $backupItem = Get-AzRecoveryServicesBackupItem -Container $backupContainer -WorkloadType "AzureVM" -VaultId $backupStatus.VaultId

        if (($actualBVName -eq $backupVaultName) -and ($backupPolicy -eq $backupItem.ProtectionPolicyName)) {
            return $true
        } else {
            return $false
        }

    } else {
        return $false   
    }
    return $false
}

Function getMonitoredState($resource, $wsName, $vmExtensions) {
    $extensionNameList = @(
        "MicrosoftMonitoringAgent",
        "OmsAgentForLinux",
        "OMSAgent"
    )

    $monitoredState="False"
    $laWs = Get-AzOperationalInsightsWorkspace | Where-Object {$_.Name -eq $wsName }
    $laGuid =  $laWs | Select-Object -ExpandProperty CustomerId
    $laWsId = $laGuid.ToString()

    if ($resource.ResourceType -eq "Microsoft.Compute/virtualMachines") {
        
        foreach ($extension in $vmExtensions) {
            if ($extension.Name -in $extensionNameList) {
                $assignedWorkspaceId = $extension.PublicSettings | ConvertFrom-json | Select-Object -ExpandProperty workspaceId
                $provState = $extension.ProvisioningState
                if (($provState -eq "Succeeded") -and ($assignedWorkspaceId -eq $laWsId)) {
                    $monitoredState = "True"
                }
            }
        }
    } else {
        $diagSetting = Get-AzDiagnosticSetting -ResourceId $resource.ResourceId
        if ($diagSetting.WorkspaceId -eq $laWs.ResourceId) {
            $monitoredState = "True"
        }
        $metricAlerts = Get-AzMetricAlertRuleV2 -ResourceGroupName $resource.ResourceGroupName | Where-Object {$_.TargetResourceId -eq $resource.ResourceId}
        if ($metricAlerts.Count -gt 0) {
            $monitoredState = "True"
        }
        $scheduledQueryRules = Get-AzScheduledQueryRule | Where-Object {$_.Name -match $resource.Name}
        if ($scheduledQueryRules.Count -gt 0) {
            $monitoredState = "True"
        }
    }

    return $monitoredState
}

Function validateMonitoredState($resource, $wsName, $vmExtensions) {
    $extensionNameList = @(
        "MicrosoftMonitoringAgent",
        "OmsAgentForLinux",
        "OMSAgent"
    )

    $laWs = Get-AzOperationalInsightsWorkspace | Where-Object {$_.Name -eq $wsName }
    $laGuid =  $laWs | Select-Object -ExpandProperty CustomerId
    $laWsId = $laGuid.ToString()

    $monitoredState = $false

    if ($resource.ResourceType -eq "Microsoft.Compute/virtualMachines") {
        
        foreach ($extension in $vmExtensions) {
            if ($extension.Name -in $extensionNameList) {
                $assignedWorkspaceId = $extension.PublicSettings | ConvertFrom-json | Select-Object -ExpandProperty workspaceId
                $provState = $extension.ProvisioningState
                if (($provState -eq "Succeeded") -and ($assignedWorkspaceId -eq $laWsId)) {
                    $monitoredState = $true
                }
            }
        }
    } else {
        $diagSetting = Get-AzDiagnosticSetting -ResourceId $resource.ResourceId
        if ($diagSetting.WorkspaceId -eq $laWs.ResourceId) {
            $monitoredState = $true
        }
        $metricAlerts = Get-AzMetricAlertRuleV2 -ResourceGroupName $resource.ResourceGroupName | Where-Object {$_.TargetResourceId -eq $resource.ResourceId}
        if ($metricAlerts.Count -gt 0) {
            $monitoredState = $true
        }
        $scheduledQueryRules = Get-AzScheduledQueryRule | Where-Object {$_.Name -match $resource.Name}
        if ($scheduledQueryRules.Count -gt 0) {
            $monitoredState = $true
        }
    }

    return $monitoredState
}

Function getEPAgent($vmExtensions) {
    $symantecExtensionNames = @(
        "SCWPAgentForLinux",
        "SCWPAgentForWindows"
    )
    $crowdstrikeExtensionNames = @(
        "CrowdStrikeSensor",
        "CrowdStrikeAgent"   
    )
    
    $agentName = "False"
    
    foreach ($extension in $vmExtensions) {
        if ( ($extension.Name -in $symantecExtensionNames) -and ($extension.ProvisioningState -eq "Succeeded")) {
            $agentName = "symantec"
        } elseif (($extension.Name -in $crowdstrikeExtensionNames) -and ($extension.ProvisioningState -eq "Succeeded")) {
            $agentName = "crowdstrike"
        }
    }

    return $agentName
}

Function validateEPAgent($vmExtensions, $expectedAgent) {
    $symantecExtensionNames = @(
        "SCWPAgentForLinux",
        "SCWPAgentForWindows"
    )
    $crowdstrikeExtensionNames = @(
        "CrowdStrikeSensor",
        "CrowdStrikeAgent"   
    )  
    $unvalidatableAgents = @(
        "Defender",
        "False"
    )

    $agentToValidate = ""
    
    if ($expectedAgent -eq "Symantec") {
        $agentToValidate = $symantecExtensionNames
    } elseif ($expectedAgent -eq "Crowdstrike") {
        $agentToValidate = $crowdstrikeExtensionNames
    } elseif ($expectedAgent -in $unvalidatableAgents) {
        return $true
    } else {
        return $false
    }

    foreach ($ext in $vmExtensions) {
        if ($ext.Name -in $agentToValidate) {
            if ($ext.ProvisioningState -eq "Succeeded") {
                return $true
            } else {
                return $false
            }
        }
    }

    return $false
}

Function getBackupPolicy($resourceId) {
    $backupStatus = Get-AzRecoveryServicesBackupStatus -ResourceId $resourceId 
    $backupData = @{}
    if ($backupStatus.BackedUp) {
        $backupData.Add("Required", "True")
        $BVName = Get-AzResource -ResourceId $backupStatus.VaultId | Select-Object -ExpandProperty Name
        $resource = Get-AzResource -ResourceId $resourceId 
        $backupContainer = Get-AzRecoveryServicesBackupContainer -VaultId $backupStatus.VaultId -ContainerType "AzureVM" -FriendlyName $resource.Name -ResourceGroupName $resource.ResourceGroupName
        $backupItem = Get-AzRecoveryServicesBackupItem -Container $backupContainer -WorkloadType "AzureVM" -VaultId $backupStatus.VaultId

        $backupData.Add("RecoveryVault", $BVName)
        $backupData.Add("BackupPolicy", $backupItem.ProtectionPolicyName)

    } else {
        $backupData.Add("Required","False")
    }
    return $backupData
}

Function checkRequiredTagValues($incomingTags, $resource, $wsName) {
    #Once we get into this function, we've already validated that the tagValues are not empty, so we won't check for that in here
    #This function is going to remove entries from the Required lists as they're checked and will return the contents of the arrays
    #which represent the tag values that failed validation
   
    $validEPValues = @(
        "CROWDSTRIKE",
        "SYMANTEC",
        "DEFENDER",
        "FALSE"
    )

    [System.Collections.ArrayList] $allResourcesRequiredTags = @(
        "dxcManaged"
        "dxcMonitored"
    )
    [System.Collections.ArrayList] $vmResourceRequiredTags = @(
        "dxcBackup",
        "dxcEPAgent",
        "dxcPatchGroup"
    )
    
    $vmExts = ""

    if ($resource.ResourceType -match "Microsoft.compute/virtualMachines") {
        $vmExts = Get-AzVMExtension -VMName $resource.Name -ResourceGroupName $resource.ResourceGroupName
        foreach ($tag in $incomingTags.GetEnumerator()) {
            if (($tag.Name -eq "dxcEPAgent") -and ($tag.Value.Trim().ToUpper() -in $validEPValues) ) {
                if ((validateEPAgent $vmExts $tag.Value.Trim())) {
                    $vmResourceRequiredTags.Remove($tag.Name)
                    #Intentionally leaving out the else so the tag is left behind in the array
                }
            } elseif ( $tag.Name -in $vmResourceRequiredTags ) {
                if ( $tag.Name -eq "dxcBackup") {
                    $backupValue = $tag.Value.Trim() | ConvertFrom-Json
                    if ($backupValue.Required) {
                        if ($backupValue.Required.Trim() -eq "true") {
                            if (($backupValue.BackupPolicy) -and ($backupValue.RecoveryVault)) {
                                if ($(validateBackupPolicy $resource.ResourceId $backupValue.RecoveryVault $backupValue.BackupPolicy )) {
                                    $vmResourceRequiredTags.Remove($tag.Name) 
                                    #Intentionally leaving out the else so the tag is left behind in the array
                                }                               
                            } 
                        } elseif ($backupValue.Required.Trim() -eq "false") {
                            $vmResourceRequiredTags.Remove($tag.Name)
                        }
                    }
                }
                if ($tag.Name -eq "dxcPatchGroup") {
                    $patchValue = $tag.Value.Trim() | ConvertFrom-Json
                    if ($patchValue.Required) {
                        if ($patchValue.Required.Trim() -eq "true") {
                            if ($patchValue.PatchGroupName) {
                                $vmResourceRequiredTags.Remove($tag.Name)
                            }
                        } elseif ($patchValue.Required.Trim() -eq "false") {
                            $vmResourceRequiredTags.Remove($tag.Name)
                        }
                     }
                }
            }
        }       
    }

    foreach($entry in $incomingTags.GetEnumerator()) {
        if ($entry.Name -in $allResourcesRequiredTags) {
            if (($entry.Name -eq "dxcManaged") -or ($entry.Name -eq "dxcMonitored") ) {          
                if ($(isValidBoolean $entry.Value)) {
                    if (($entry.Name -eq "dxcMonitored") -and (isPositiveTagValue $entry.Value)) {
                        if ((validateMonitoredState $resource $wsName $vmExts)) {
                            $allResourcesRequiredTags.Remove($entry.Name)
                        }
                    } else {
                        $allResourcesRequiredTags.Remove($entry.Name)
                    }
                }          
            } 
        }   
    }
    
    if ($allResourcesRequiredTags.Count -ne 0) {
        return $allResourcesRequiredTags
    } else {
        if ( ($resource.ResourceType -eq "Microsoft.Compute/virtualMachines") -and ($vmResourceRequiredTags.Count -ne 0)) {
            return $vmResourceRequiredTags
        } 
    }

    return $allResourcesRequiredTags
}

##############################################
# Main
##############################################
#Check environemnt for required modules
$dxcModuleList = "DXCUtilityFunctions.psm1"
foreach ($dxcModule in $dxcModuleList)
    {
    [String]$dxcModuleURL = "https://dxcazuretoolsdev.blob.core.windows.net/installers/DXCPowershellModules/" + $dxcModule
    [String]$dxcLocalModule = $PSScriptRoot + "\" + $dxcModule
    (New-Object System.Net.WebClient).DownloadFile($dxcModuleURL, $dxcLocalModule)
    Import-Module $dxcLocalModule -WA 0
    Remove-Item -Path $dxcLocalModule
    }

if ($spKey) {
    Utility-LoginAZSpn -TenantId $tenantId -SpnKey $spKey -ClientId $clientID -SubscriptionId $subscriptionId 
} else {
    Utility-LoginAZTenant -TenantId $tenantId -SubscriptionId $subscriptionId
}

$supportedResourceTypes = @(
    "Microsoft.Compute/virtualMachines",
    "Microsoft.Storage/storageAccounts",
    "Microsoft.Sql/servers/databases",
    "Microsoft.Sql/servers",
    "Microsoft.Network/expressRouteCircuits",
    "Microsoft.ContainerRegistry/registries",
    "Microsoft.KeyVault/vaults",
    "Microsoft.Network/applicationGateways",
    "microsoft.insights/webtests",
    "Microsoft.Web/serverfarms",
    "Microsoft.Network/virtualNetworks",
    "Microsoft.DocumentDB/databaseAccounts",
    "Microsoft.ServiceBus/namespaces",
    "Microsoft.Network/bastionHosts",
    "Microsoft.Network/virtualNetworks/subnets",
    "Microsoft.EventHub/Namespaces",
    "Microsoft.EventGrid/Domain",
    "Microsoft.EventGrid/Topic",
    "Microsoft.RecoveryServices/vaults",
    "Microsoft.Cache/Redis",
    "Microsoft.Network/trafficmanagerprofiles",
    "Microsoft.Network/loadBalancers",
    "Microsoft.Network/azureFirewalls",
    "Microsoft.Logic/workflows",
    "Microsoft.DBforMySQL/servers",
    "Microsoft.DBforPostgreSQL/servers",
    "Microsoft.Sql/managedInstances/databases",
    "Microsoft.Web/sites",
    "Microsoft.OperationalInsights/workspaces",
    "Microsoft.Automation/automationAccounts",
    "Microsoft.Portal/dashboards"
)

if ($mode -eq "GetResources") {

    if (-not $workspaceName) {
        Write-Host "-workspaceName parameter is required for this mode"
        Exit
    }

    $resources = @()
    $outputCsvName = $subscriptionId + ".csv"
    
    foreach ($resourceType in $supportedResourceTypes) {
        if ($resourceGroup) {
            $resources += Get-AzResource -ResourceType $resourceType -ResourceGroupName $resourceGroup
        } else {
            $resources += Get-AzResource -ResourceType $resourceType          
        }
    }

    foreach ($resource in $resources) {
    
        #First checking whether the contents of Tags is null to prevent errors during execution
        if ($resource.Tags.count -gt 0) {   
            #If DXC_AutoDeploy tag exists and is set to true on the Resource, then prepopulate dxcManaged with True otherwise set it to false        
            if ($resource.Tags["DXC_AutoDeploy"] -eq "true") {
                
                $vmx = ""
               
                if ($resource.ResourceType -eq "Microsoft.Compute/virtualMachines") {
                    $vmx = Get-AzVMExtension -VMName $resource.Name -ResourceGroupName $resource.ResourceGroupName
                    $patchGroup = @{"Required"="";"PatchGroupName"=""} | ConvertTo-Json -Compress
                    $backupPolicy = getBackupPolicy $resource.ResourceId | ConvertTo-Json -Compress
                    $resource | Add-Member -NotePropertyName "dxcBackup" -NotePropertyValue $backupPolicy
                    $resource | Add-Member -NotePropertyName "dxcEPAgent" -NotePropertyValue (getEPAgent $vmx)
                    $resource | Add-Member -NotePropertyName "dxcPatchGroup" -NotePropertyValue $patchGroup
                }

                #Moved for consistency, and because we need to wait for vmx to be populated if this is a virtual machine type
                $resource | Add-Member -NotePropertyName "dxcManaged" -NotePropertyValue "true"
                $resource | Add-Member -NotePropertyName "dxcMonitored" -NotePropertyValue (getMonitoredState $resource $workspaceName $vmx)

            } elseif (($resource.Tags["dxcManaged"] -in ("true", "false"))) {
                $resource | Add-Member -NotePropertyName "dxcManaged" -NotePropertyValue $resource.Tags["dxcManaged"]
                
                if ($resource.Tags["dxcMonitored"] -eq "true") {
                    $resource | Add-Member -NotePropertyName "dxcMonitored" -NotePropertyValue "true"
                } else {
                    $resource | Add-Member -NotePropertyName "dxcMonitored" -NotePropertyValue "false"
                }

                if ($resource.ResourceType -eq "Microsoft.Compute/virtualMachines") {
                    
                    if ($resource.Tags["dxcBackup"]) {
                        $resource | Add-Member -NotePropertyName "dxcBackup" -NotePropertyValue $resource.Tags["dxcBackup"]
                    }

                    if ($resource.Tags["dxcPatchGroup"]) {
                        $resource | Add-Member -NotePropertyName "dxcPatchGroup" -NotePropertyValue $resource.Tags["dxcPatchGroup"]
                    }

                    if ($resource.Tags["dxcEPAgent"]) {
                        $resource | Add-Member -NotePropertyName "dxcEPAgent" -NotePropertyValue $resource.Tags["dxcEPAgent"]
                    }
                }

            } else {
                $resource | Add-Member -NotePropertyName "dxcManaged" -NotePropertyValue "false"
            }
        } else {
            $resource | Add-Member -NotePropertyName "dxcManaged" -NotePropertyValue "false"
        }
        
    }

    Write-Host "outputting resources list to file named " $outputCsvName
     $resources | Select-Object -Property Name, ResourceGroupName, ResourceId, ResourceType, dxcManaged, dxcMonitored, dxcBackup, dxcPatchGroup, dxcEPAgent, dxcPrimarySupport, dxcAdditionalSupport, dxcResourceRole, dxcAutoShutdownSchedule, dxcCustomerContact
    | export-csv $outputCsvName

    
} elseif ($mode -eq "UpdateResources") {
    
    if (-not $workspaceName) {
        Write-Host "-workspaceName parameter is required for this mode"
        Exit
    }

    $tagNames = @(
        "dxcManaged",
        "dxcMonitored",
        "dxcBackup",
        "dxcPatchGroup",
        "dxcEPAgent",
        "dxcPrimarySupport",
        "dxcAdditionalSupport", 
        "dxcResourceRole", 
        "dxcAutoShutdownSchedule", 
        "dxcCustomerContact"
    )

    if ( $resourceCsv ) {
        $unupdatedResources = @{}
        $resourcesForUpdate = Import-Csv $resourceCsv
        foreach ($entry in $resourcesForUpdate) {
            $resourceTags = @{}
            $isDxcManaged = $false
            
            foreach ($tag in $tagNames) {
                $tagValue = $entry | Select-Object -ExpandProperty $tag
                if ($tagValue -ne "" ) {
                    if (($tag -eq "dxcManaged") -and ($(isValidBoolean $tagValue)) -and ($(isPositiveTagValue $tagValue)) ) {
                        $isDxcManaged = $true
                    }
                    
                    $resourceTags[$tag] = $tagValue
                }
            }
            
            $requiredValues = checkRequiredTagValues $resourceTags $entry $workspaceName
            # checkRequiredTagValues returns an array with any tags that have failed validation, therefore
            # if it has any contents then the resource failed validation check
            
            if (($isDxcManaged) -and ($requiredValues.Count -eq 0)) {
                
                $resourceTags.Add("dxcConfigurationCheck", (Get-Date).ToUniversalTime().ToString("yyyyMMddTHHmmssZ"))
                $result = Update-AzTag -ResourceId $entry.ResourceId -Operation Merge -Tag $resourceTags
            } elseif (-not $isDxcManaged) {
                $result = Update-AzTag -ResourceId $entry.ResourceId -Operation Merge -Tag $resourceTags
            } else {
                $unupdatedResources.Add($entry.ResourceId, $requiredValues)
            } 
            
        }

        if ($unupdatedResources.Count -ne 0) {
            Write-Host "The following resources did not have tags applied because the required tags listed with each resource "
            Write-Host "were not set, or had incorrect values"
            foreach ($instance in $unupdatedResources.Keys) {
                Write-Host $instance $unupdatedResources[$instance]
            }
            Write-Host "dxcManaged is required for all resources."
            Write-Host "dxcMonitored is required when dxcManaged is true"
            Write-Host "dxcBackup, dxcEPAgent, and dxcPatchGroup are required for virtualMachines when dxcManaged is true"
        }
        
    } else {
        Write-Host "resourceCsv must be provided for UpdateResources Execution"
        Exit
    }
    
} elseif ($mode -eq "RemoveAutoDeployTag") {
    #allowing ResourceGroup as an option for testing purposes
    if ($resourceGroup) {
        $resourceList = Get-AzResource -ResourceGroupName $resourceGroup
    } else {
        $resourceList = Get-AzResource
    }

    foreach ($resource in $resourceList) {
        if ($resource.Tags.count -gt 0) {   
            #If DXC_AutoDeploy tag exists and is set to true on the Resource, then prepopulate dxcManaged with True otherwise set it to false        
            if ($resource.Tags["DXC_AutoDeploy"]) {
                #Putting output into a variable to suppress output to screen during execution
                $result = Update-AzTag -ResourceId $resource.Id -Tag @{"DXC_AutoDeploy"=$resource["DXC_AutoDeploy"]} -Operation Delete
            } 
        } 
    }

} else {
    Write-Host "Invalid mode of operation"
}


