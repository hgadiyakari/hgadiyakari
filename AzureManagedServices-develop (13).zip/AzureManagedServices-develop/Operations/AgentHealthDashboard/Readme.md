﻿# Agent Health Dashboard

This folder contains the json and powershell files that are used to create shared dashboard per subscription, detailing the number of VMs 
that are non-compliant (any of the data is in a state of "false")

## Jira Epic
https://jira.dxc.com/browse/AZR-10731

## Deployment
For more information on how to Agent Health Dashboard, please see:
 * https://confluence.csc.com/display/CSA/AZR-10107+and+AZR-10720+Automate+Agent+Health+Report+Generation+and+Dashboard+View
 * https://confluence.dxc.com/display/CSA/AZR-12266+Apply+security+enhancements+to+existing+agent+health+dashboard+function+app

## Members of this directory are:
* changeFunctionIdentityPermission.ps1	Apply security enhancements to existing agent health dashboard function app
* deployAgentHealthDashboard.json		ARM template called by main script
* deployAgentHealthDashboard.ps1		Main script for deploying Agent Health Dashboard
* Report-ExtensionHealth.zip			Artifacts utilized by main script

## Authors
* Santanu Sengupta
