
function Test-CASSchemaPresent {
    <#
    .SYNOPSIS
        Tests a powershell object to see if it conforms to the Common Alert Schema
    .DESCRIPTION
        Common Alert Schema is an Azure Monitor ALert format to convey alert data
        in a standardised way. This function tests if the SchemaId member is set
    .EXAMPLE
        PS:/> Test-CASSchemaPresent -Body $BodyObject
        Determines if the PSObject $BodyObject has SchemaId set to "azureMonitorCommonAlertSchema"
    .INPUTS
        $Body object derived from a JSON Azure Monitor Alert payload
    .OUTPUTS
        $true if the object has a SchemaId corresponding to the CAS
    .NOTES
        A superficial check to confirm the SchemaId is present and correct
        (C) DXC Technology 2020
    #>
    [CmdletBinding()]
    [OutputType([boolean])]
    param (
        [parameter(Mandatory = $true)]
        [Object]
        $Body
    )
    process {
        Write-Debug "## Test-CASSchemaPresent ##"
        Write-Debug "Testing SchemaId"
        if (($Body.SchemaId) -and ($Body.SchemaId -eq "azureMonitorCommonAlertSchema")){
            $SchemaOK = $true
        } else {
            $SchemaOK = $false
        }
        Write-Debug "CAS Schema present: $($SchemaOK)"
        $SchemaOK
    }
}

function Get-CASVersions {
    [CmdletBinding()]
    [OutputType([psobject])]
    param (
        [parameter(Mandatory = $true)]
        [psobject]
        $Body
    )
    process {
        Write-Debug "## Get-CASVersions ##"
        $Versions =@{
            EssentialsVersion = $Body.data.essentials.essentialsVersion
            AlertContextVersion = $Body.data.essentials.alertContextVersion
        }
        New-Object -Property $Versions -TypeName psobject
    }
}
function Get-CASLogQuerySearchResults {
    [CmdletBinding()]
    [OutputType([psobject])]
    param (
        [parameter(Mandatory = $true)]
        $AlertData
    )
    process {
        Write-Debug "## Get-CASLogQuerySearchResults ##"
        foreach ($table in $AlertData.alertContext.SearchResults.tables){
            $AlertResults = @()
            if ($table.name -eq "PrimaryResult"){
                foreach ($row in $table.rows){
                    $ResultObject = New-Object -Typename psobject
                    $RowIndex = 0
                    foreach ($value in $row){
                        Write-Debug "$($table.columns[$RowIndex].name): $($value)"
                        $ResultObject | Add-Member -MemberType NoteProperty -Name $table.columns[$RowIndex].name $value
                        $RowIndex++
                    }
                    $AlertResults += $ResultObject
                }
            } else {
                Write-Warning "Unexpected table name: $($table.name) found in Log Query Search Results"
            }
        }
        $AlertResults
    }
}
function Test-VMAlert {
    param (
        $Alert
    )
    $AlertVMReport = Get-VMStatus -ResourceId $Alert.ResourceId
    switch ( $AlertVMReport ) {
        # Resource Group or VM Deleted
        ({
            ($PSItem.StatusCode -eq "VM_DELETED" `
            -or $PSItem.StatusCode -eq "RG_DELETED")
        })
        {
            Write-Information "VM or ResourceGroup deleted"
            $AlertVMReport["Summary"] = "Virtual machine has been deleted from ARM"
            $AlertVMReport["AlertState"] = $false
            break
        }
        # VM Healthy
        ({
            ($PSItem.VMPowerState -eq "PowerState/running")`
            -and ($PSItem.AgentState -eq "ProvisioningState/succeeded")`
            -and $PSItem.AgentStateCurrent -eq $true
        })
        {
            Write-Information "VM Healthy"
            $AlertVMReport["Summary"] = "Virtual machine is healthy"
            $AlertVMReport["AlertState"] = $false
            break
        }
        # VM Crashed or in hung state
        ({
            ($PSItem.VMPowerState -eq "PowerState/running"`
            -and $PSItem.AgentState -eq "ProvisioningState/succeeded"`
            -and $PSItem.AgentStateCurrent -eq $false)`
            -or ($PSItem.VMPowerState -eq "PowerState/running"`
            -and $PSItem.AgentState -eq "ProvisioningState/Unavailable")
        })
        {
            Write-Information "VM Unresponsive - crashed or hung"
            $AlertVMReport["Summary"] = "Virtual machine is down or in hung-state"
            $AlertVMReport["AlertState"] = $true
            break
        }
        # VM Starting - need to test this state further - can you distinguish
        # portal restart vs. in-guest reboot
        ({
            $PSItem.VMPowerState -match '^PowerState\/starting'
        })
        {
            Write-Information "VM restarting"
            $AlertVMReport["Summary"] = "Virtual machine is being restarted - ARM or OS?"
            $AlertVMReport["AlertState"] = $true
            break 
        }
        # VM deallocated from portal
        ({
            $PSItem.VMPowerState -match '^PowerState\/deallocat[ed|ing]'
        })
        {
            Write-Information "VM Deallocated from ARM"
            $AlertVMReport["Summary"] = "Virtual machine has been deallocated by ARM"
            $AlertVMReport["AlertState"] = $false
            break
        }
        # VM stopped in guest - i.e. shutdown at OS level
        ({
            $PSItem.VMPowerState -match '^PowerState\/stopp[ed|ing]'
        })
        {
            Write-Information "VM shutdown in guest"
            $AlertVMReport["Summary"] = "Virtual machine has been stopped in OS"
            $AlertVMReport["AlertState"] = $true
            break
        }
        default
        {
            Write-Information "VM State: $($PSItem.VMPowerState)"
            Write-Information "Agent State: $($PSItem.AgentState)"
            Write-Information "Agent State current: $($PSItem.AgentStateCurrent)"
            $AlertVMReport["Summary"] = "Virtual machine status unknown"
            $AlertVMReport["AlertState"] = $true
        }
    }
    if ($AlertVMReport.Status -match 'Error:') {
        $AlertVMReport["Summary"] = "Error assessing Virtual Machine"
        $AlertVMReport["AlertState"] = $true
    }
    $AlertVMReport["FloodWarning"] = $FloodWarning
    $AlertVMReport["IngestionDelay"] = $IngestionDelay
    $AlertVMReport
}
function Get-VMStatus {
    param (
        $ResourceId
    )
    # Cutoff threshold to determine if agent is updating (seconds)
    $MaxDeltaSeconds = 60
    Write-Information "## Get-VMStatus ##"
    $Regex = "^\/subscriptions\/(?<Subscription>.+)\/resourcegroups\/(?<ResourceGroup>.+)\/providers\/Microsoft.Compute\/virtualMachines\/(?<Resource>.+)$"
    $Report = @{
        VMResource =$null
        VMResourceGroup = $null
        VMSubscription = $null
        VMResourceId = $ResourceId
        StatusCode = $null
        Status = $null
        VMPowerState = $null
        AgentState = $null
        AgentStateCurrent =$null
    }
    # $VM.ResourceId -match $Regex
    
    if ($ResourceId -match $Regex) {

        $Report.VMResource = $Matches.Resource
        $Report.VMResourceGroup = $Matches.ResourceGroup
        $Report.Subscription = $Matches.Subscription

        try {
            Set-AzContext -SubscriptionId $Matches.Subscription -ErrorAction Stop | Out-Null
        }
        catch {
            Write-Error $_.Exception.Message
            Write-Error "Unable to set context to subscription $($Matches.Subscription)"
            $Report["StatusCode"] = "INVALID_SUB"
            $Report["Status"] = "Error: Unable to set context to subscription $($Matches.Subscription)"
            break
        }
        try {
            Get-AzResourceGroup -Name $Matches.ResourceGroup -ErrorAction Stop | Out-Null
        }
        catch {
            Write-Error $_.Exception.Message
            Write-Error "Resource Group $($Matches.ResourceGroup) not found. It has been deleted"
            $Report["StatusCode"] = "RG_DELETED"
            $Report["Status"] = "OK: Resource Group $($Matches.ResourceGroup) not found. It has been deleted"
            break
        }
        try {
            $Attempts = 0
            do {
                $Attempts++
                if ($Attempts -gt 5){
                    Write-Warning "Too many attempts retrieve VM Status and Agent data"
                    break
                }
                $EvalTime = Get-Date
                Write-Information "Calling Get-AzVM attempt $($Attempts)"
                $VMDetails = Get-AzVM -ResourceGroupName $Matches.ResourceGroup -Name $Matches.Resource -Status -ErrorAction Stop 
            } while ($null -eq $VMDetails.VMAgent.Statuses)
            $Report["StatusCode"] = "VM_TESTED"
            $Report["Status"] = "OK: VM tested"
        }
        catch {
            Write-Error $_.Exception.Message
            Write-Error "VM $($Matches.Resource) not found. It has been deleted"
            $Report["StatusCode"] = "VM_DELETED"
            $Report["Status"] = "OK: VM $($Matches.Resource) not found. It has been deleted"
            break
        }
    } else {
        $Report["StatusCode"] = "INVALID_RESOURCEID"
        $Report["Status"] = "Error: Cannot parse Resource Id"
    }
    $Report["VMStatusJSON"] = ($VMDetails.Statuses | ConvertTo-JSON)
    foreach ($v in $VMDetails.Statuses) {
        if ($v.Code -match "PowerState") {
            $Report["VMPowerState"] = $v.Code
        }
    }
    $Report["AgentStatusJSON"] = ($VMDetails.VMAgent.Statuses | ConvertTo-JSON)
    foreach($a in $VMDetails.VMAgent.Statuses) {
        if ($a.Code -match "ProvisioningState") {
            $Report["AgentState"] = $a.Code
            $Delta = New-TimeSpan -Start $a.Time -End $EvalTime
            Write-Debug "Delta: $($Delta.TotalSeconds)"
            if ($Delta.TotalSeconds -gt $MaxDeltaSeconds) {
                $Report["AgentStateCurrent"] = $false
            } else {
                $Report["AgentStateCurrent"] = $true
            }
            
        }
    }
    #foreach($key in $Report.keys){Write-Warning "$($key): $($Report[$key])"}
    return $Report
}
function Get-IngestionStatus {
    param (
        $WorkspaceId
        
    )
    $RateQuery = @"
// Estimate of expected delay for signal ingestion to LA - should be conservative, but not excessive
// say ~95th percentile in normal operations
let ingestionDelay = time(2m);
// define the query "reference" time
let refTime = now();
// Select a "lookback" period to get a baseline for expected heartbeat signal arrival rate
let avgPeriod = time(10m);
// define evalutaion period to assess current heartbeat rate - ingestion problems will slow or stop HB signals available in Log Analytics
let evalDuration = time(5m);
// define evaluation period
let evalEndTime = refTime - ingestionDelay;
let evalStartTime = evalEndTime - evalDuration;
// define immediate prior period for active heartbeat detection
let detectionEndTime = evalStartTime;
let detectionStartTime = detectionEndTime - evalDuration;
// The threshold for triggering "flood protection" expressed as a ratio of current HB rate to average HB rate
let HBRateThreshold = 0.75;
// Calculate average HB signal rate for this workspace in total HB/minute over the period avgPeriod
let avgHBRateTemp = Heartbeat
| where TimeGenerated > ago(avgPeriod)
| summarize count() by bin(TimeGenerated, 1m)
| summarize avg(count_);
// Convert to integer scalar
let avgHBRate = toint(toscalar(avgHBRateTemp));
// Calculate current average HB signal rate
let curHBRateTemp = Heartbeat
| where TimeGenerated between( evalStartTime .. evalEndTime )
| summarize count()/(evalDuration/1m);
// Convert to integer scalar
let curHBRate = toint(toscalar(curHBRateTemp));
// Find all systems which have sent heartbeats in the period immediately before the evaluation period
// Not strictly necessary?
let activeHB = Heartbeat
| summarize countif(TimeGenerated between( detectionStartTime .. detectionEndTime) ) by Resource;
Heartbeat
| where Resource in ( activeHB )
| where TimeGenerated > detectionStartTime
| extend floodWarning = iff(curHBRate < (HBRateThreshold * avgHBRate), true, false)
| extend CurrentHB = curHBRate, AverageHB = avgHBRate
| take 1
"@
    Write-Information "## Get-IngestionStatus ##"
    $RateQueryResults = Invoke-AzOperationalInsightsQuery -WorkspaceId $WorkspaceId  -Query $RateQuery
    Write-Information "Current Heartbeat ingestion rate (5 min period): $($RateQueryResults.Results.CurrentHB)"
    Write-Information "Average Heartbeat ingestion rate: $($RateQueryResults.Results.AverageHB)"
    Write-Information "Ratio: $($RateQueryResults.Results.CurrentHB/$RateQueryResults.Results.AverageHB)"

    if ($RateQueryResults.Results.floodWarning -eq "false"){
        return $false
    } else {
        return $true
    }
}
function Get-IngestionDelay {
    param (
        $WorkspaceId
    )
    process {
        $DelayQuery = @"
Heartbeat
| where TimeGenerated > ago(5m)
| extend ingestionTime = ingestion_time()
| extend delta = (ingestionTime - TimeGenerated)/time(1s)
| summarize avg(delta)
"@
        Write-Information "## Get-Get-IngestionDelay ##"
        $DelayQueryResults = Invoke-AzOperationalInsightsQuery -WorkspaceId $WorkspaceId  -Query $DelayQuery
        Write-Information "Current Ingestion delay (5m period) $($DelayQueryResults.Results.avg_delta)"
        return $DelayQueryResults.Results.avg_delta
    }
}

function Get-ResourceHealthAlerts {
    param (
        $ResourceId
    )
    process {
        Write-Information "## Get-ResourceHealthAlerts ##"
        # Get list of relevant resource health alerts
        Write-Information "Getting Resource Health Alerts for $($ResourceId)"
        $Alerts = Get-AzAlert -MonitorService "Resource Health" -TargetResourceId $ResourceId -TimeRange "1h"
        #Write-Information "Number of alerts in last hour: $($Alerts.Length)"
        foreach($Alert in $Alerts){
            Get-AzAlert -AlertId $Alert.Id
        }
    }
    
}

function Get-LastHeartbeat {
    param ( 
        $VMResource
    )
    process {
        $LastHBQuery = @"
Heartbeat
| where Resource == $($VMResource)
| where TimeGenerated > ago(30d)
| summarize arg_max(TimeGenerated, *)
"@
    }
}

# Function to create the authorization signature
Function Build-Signature
{
    param($customerId, $sharedKey, $date, $contentLength, $method, $contentType, $resource)
    $xHeaders = "x-ms-date:" + $date
    $stringToHash = $method + "`n" + $contentLength + "`n" + $contentType + "`n" + $xHeaders + "`n" + $resource

    $bytesToHash = [Text.Encoding]::UTF8.GetBytes($stringToHash)
    $keyBytes = [Convert]::FromBase64String($sharedKey)

    $sha256 = New-Object System.Security.Cryptography.HMACSHA256
    $sha256.Key = $keyBytes
    $calculatedHash = $sha256.ComputeHash($bytesToHash)
    $encodedHash = [Convert]::ToBase64String($calculatedHash)
    $authorization = 'SharedKey {0}:{1}' -f $customerId,$encodedHash
    return $authorization
}


# Function to post data to custom log table in Log Analytics workspace
Function Send-LogAnalyticsData
{
    param($customerId, $sharedKey, $body, $logType)
    $method = "POST"
    $contentType = "application/json"
    $resource = "/api/logs"
    $rfc1123date = [DateTime]::UtcNow.ToString("r")
    $contentLength = $body.Length
    $signature = Build-Signature `
        -customerId $customerId `
        -sharedKey $sharedKey `
        -date $rfc1123date `
        -contentLength $contentLength `
        -method $method `
        -contentType $contentType `
        -resource $resource
    $uri = "https://" + $customerId + ".ods.opinsights.azure.com" + $resource + "?api-version=2016-04-01"

    # Do not pass in time field via headers - accept the default applied by Log Analytics
    $headers = @{
        "Authorization" = $signature;
        "Log-Type" = $logType;
        "x-ms-date" = $rfc1123date;
    }

    $response = Invoke-WebRequest -Uri $uri -Method $method -ContentType $contentType -Headers $headers -Body $body -UseBasicParsing
    return $response.StatusCode

}
function Send-TeamsNotification {
    param (
        $ChannelURL,
        $MessageBody
    )
    # Send Data to Teams

    Write-Information "## Get-Send-TeamsNotification ##"      
    # call Teams webhook
    try {
        write-Information '## Invoke-RestMethod ##'
        #Write-Information "Calling Uri: $($ChannelURL)"
        #Write-Information "With Message Body:"
        #$MessageBody | Write-Information
        Invoke-RestMethod -Method "Post" -Uri $ChannelURL -Body $MessageBody | Write-output
    }
    catch {
        $ErrorMessage = $_.Exception.message
        write-error ('Error with invoke-restmethod ' + $ErrorMessage)
        Break
    }
}
function Send-SNOWEvent {
    param (
        $EventDescription,
        $SubscriptionId,
        $EventResource,
        $EventType,
        $EventFormat,
        $EventSeverity,
        $ResourceId,
        $Resource
    )
    $MessageKey = "OMS_$($SubscriptionId)_$($ResourceId)_$($EventType)_$($EventResource)"
    $EventBody =@{
        source = "OMS"
        severity = $EventSeverity
        type = $EventType
        resource = $EventResource
        event_class = $EventFormat
        node = $Resource
        description = $EventDescription
        message_key = $MessageKey
    }
    $CredentialPair = "$($ENV:ServiceNowUser):$($ENV:ServiceNowPassword)"
    $EncodedCredential = [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes($CredentialPair))
    $Headers = @{
        'Authorization' = "Basic $($EncodedCredential)"
        'Content-Type' = "application/json"
        'Accept' = "application/json"
    }
    $SnowAPIUri = $ENV:ServiceNowUrl + "api/now/table/em_event"
    $JSONBody = $EventBody | ConvertTo-Json
    $Response = try {
        Write-Information $SnowAPIUri
        Write-Information $Headers
        Write-Information $JSONBody
        (Invoke-Webrequest -Uri $SnowAPIUri -Header $Headers -Method POST -Body $JSONBody -ErrorAction Stop).BaseResponse
    } catch [System.Net.WebException] { 
        Write-Error $JSONBody
        Write-Verbose "An exception was caught: $($_.Exception.Message)"
        $_.Exception.Response 
    } 
    
    #then convert the status code enum to int by doing this
    $statusCodeInt = [int]$Response.BaseResponse.StatusCode
    #or this
    #$statusCodeInt = $response.BaseResponse.StatusCode.Value__
    Write-Information "Status Code returned from Service Now: $($statusCodeInt)"
}
function Send-SNOWHBEvent {
    param (
        $AlertData,
        $AlertReport
    )
    <#
        <-- Log Entry -->
        TimeGenerated : 2/29/2020 1:34:08 PM
        SubscriptionId : b47b134f-d1e7-4f79-8a4c-043a355acf6d
        Resource : monvmlx001
        ResourceId : /subscriptions/b47b134f-d1e7-4f79-8a4c-043a355acf6d/resourcegroups/rg-rn-monitortests/providers/microsoft.compute/virtualmachines/monvmlx001
        AggregatedValue : 0
        eventType : Availability
        eventResource : Virtual Machine
        eventFormat : HeartbeatLogMetric
        <-- Log Entry -->
    #>
    $TargetURL = "https://portal.azure.com/#resource" + $AlertReport.VMResourceId + "/overview" 
    $EventDescription = @"
Alert : DXC-Critical-Beta-Heartbeat Availability Alert
Description : Heartbeat Alert Processed by triage function
Result : $($AlertReport.Summary)
VM Status : $($AlertReport.VMStatusJSON)
Agent Status : $($AlertReport.AgentStatusJSON)
SubscriptionId : $($AlertData.SubscriptionId)
Resource : $($AlertData.Resource)
ResourceId : $($AlertData.ResourceId)
eventType : $($AlertData.eventType)
eventResource : $($AlertData.eventResource)
eventFormat : $($AlertData.eventFormat)

Click [code]<a href="$($TargetURL)">here</a>[/code] to go to the Virtual Machine

"@

    Write-Information "SubscriptionId: $($AlertData.SubscriptionId)"
    Write-Information "Resource: $($AlertData.Resource)"
    Send-SNOWEvent  -SubscriptionId $AlertData.SubscriptionId `
                    -ResourceId $AlertData.ResourceId `
                    -Resource $AlertData.Resource `
                    -EventResource $AlertData.eventResource `
                    -EventType $AlertData.eventType `
                    -EventFormat $AlertData.eventFormat `
                    -EventSeverity 1 `
                    -EventDescription $EventDescription
}
function Send-TeamsHBAlertNotification {
    param(
        $AlertReport,
        $ChannelURL
    )
    process {
        # Send Data to Teams
        # Build the message body
        $image = ""
        $TargetURL = "https://portal.azure.com/#resource" + $AlertReport.VMResourceId + "/overview"   
        try {    
            $TeamsNotificationBody = ConvertTo-Json -ErrorAction Stop -Depth 4 @{
                title           = 'Azure VM Availability Notification' 
                text            = 'A new Azure Heartbeat Availability Alert has been processed'
                sections        = @(
                    @{
                        activityTitle    = "Alert received from: $($AlertReport.VMResource)"
                        activitySubtitle = $AlertReport.Summary
                        activityText     = $AlertReport.Status
                        activityImage    = $image
                        facts = @(
                            @{
                                name = "Virtual Machine"
                                value = $AlertReport.VMResource
                            }
                            @{
                                name = "Resource Group"
                                value = $AlertReport.VMResourceGroup
                            }
                            @{
                                name = "Subscription"
                                value = $AlertReport.VMSubscription
                            }
                            @{
                                name = "Assessment Summary"
                                value = $AlertReport.Summary
                            }
                            @{
                                name = "Alert State"
                                value = $AlertReport.AlertState
                            }
                            @{
                                name = "VM ARM Status"
                                value = $AlertReport.VMStatusJSON
                            }
                            @{
                                name = "VM Agent Status"
                                value = $AlertReport.AgentStatusJSON
                            }
                            @{
                                name = "Power State"
                                value = $AlertReport.VMPowerState
                            }
                            @{
                                name = "Agent State"
                                value = $AlertReport.AgentState
                            }
                            @{
                                name = "Agent State is Current"
                                value = $AlertReport.AgentStateCurrent
                            }
                        )
                    }
                )
                potentialAction = @(@{
                        '@context' = 'http://schema.org'
                        '@type'    = 'ViewAction'
                        name       = 'Click here to go to the Virtual Machine in the portal'
                        target     = @($TargetURL)
                    })
            }
        }
        catch {
            $ErrorMessage = $_.Exception.message
            write-error ('Error converting body to JSON ' + $ErrorMessage)
            Break
        }
        Send-TeamsNotification -ChannelURL $ChannelURL -MessageBody $TeamsNotificationBody

    }
}