# Input bindings are passed in via param block.
param([string] $QueueItem, $TriggerMetadata)

# Get environment variables
$LAWorkspaceName = $env:AZURE_WORKSPACE_NAME
$LAWorkspaceId = $env:AZURE_WORKSPACE_ID

# Write out the queue message and insertion time to the information log.
Write-Information "PowerShell queue trigger function processed work item: $QueueItem"
Write-Information "Queue item insertion time: $($TriggerMetadata.InsertionTime)"

# Extract VM information from queued payload

$VMName = $TriggerMetadata.QueueTrigger.Name
$VMResourceGroupName = $TriggerMetadata.QueueTrigger.ResourceGroupName
$VMResourceId = $TriggerMetadata.QueueTrigger.ResourceId
$VMHeartbeatData = $TriggerMetadata.QueueTrigger.HeartbeatData 
$VMPerformanceData = $TriggerMetadata.QueueTrigger.PerformanceData 
$VMFrequencyData = $TriggerMetadata.QueueTrigger.FrequencyData 
$VMLatencyData = $TriggerMetadata.QueueTrigger.LatencyData 
$VMOSImageVersion = $TriggerMetadata.QueueTrigger.OSImageVersion

Write-Information "Processing virtual machine: $($VMName)"
Write-Information "Image version: $($VMOSImageVersion)"

Import-Module DXC-Azure-PSUtils

$Regex = "^\/subscriptions\/(?<Subscription>.+)\/resourcegroups\/(?<ResourceGroup>.+)\/providers\/Microsoft.Compute\/virtualMachines\/(?<Resource>.+)$"

try {
    Write-Information "Getting VM Instance details for $($VMName)"
    $VMDetail = Get-AzVM -Name $VMName -ResourceGroupName $VMResourceGroupName -Status -ErrorAction Stop
    Write-Information "Getting VM Model details for $($VMName)"
    $VMModel = Get-AzVM -Name $VMName -ResourceGroupName $VMResourceGroupName -ErrorAction Stop
} catch {
    Write-Error "Error getting VM details for $($VMName)"
    exit
}

#Getting SubscriptionName
$VMSubName = (Get-AzSubscription -SubscriptionId (Get-AzContext).Subscription).name
# $JSONDetail = $VMDetail | ConvertTo-Json

# Write-Information $JSONDetail

if ($VMResourceId -match $Regex){
    $VMSubscription = $Matches.Subscription
} else {
    Write-Error "Unable to extract subscription from $($VMResourceId)"
    exit
}

try {
    Write-Information "Getting extension data for $($VMName)"
    $VMWSId = (get-AZVMExtension -ResourceGroupName $VMResourceGroupName -VmName $VMName | Where-Object {($_.ExtensionType -eq "MicrosoftMonitoringAgent") -or ($_.ExtensionType -eq "OmsAgentForLinux")}).PublicSettings -replace '\s+', ''
    $VMWSId = $VMWSId -replace '{"workspaceId":"', ''
    $VMWSId = $VMWSId -replace '"', ''
    $VMWSId = $VMWSId -replace '}', ''
    if ($VMWSId){
        $ArrayVMWSId = $VMWSId.Split(",")
        if ($ArrayVMWSId.Length -gt 1){
            $VMWSConfig = $ArrayVMWSId[-1] 
            $VMWSId = $ArrayVMWSId[0]
        } else {
            $VMWSConfig = "None"
        }
    }
} catch {
    Write-Warning "Error getting extension data for $($VMName)"
}
$LogData = @{
    Computer = $VMDetail.Name
    Tags = ($VMModel.Tags | ConvertTo-Json) 
    _ResourceId = $VMResourceId
    Subscription = $VMSubscription
    SubscriptionName = $VMSubName
    ResourceGroup = $VMResourceGroupName
    OSVersion = $VMOSImageVersion
    RequiredWorkspaceId = $LAWorkspaceId
    ConfiguredWorkspaceId = $VMWSId
    AdditionalWorkspaceConfig = $VMWSConfig
    VmAgentVersion = "VM Deallocated"
    VmAgentStatus = "VM Deallocated"
    VMUptime = 0
    MicrosoftMonitoringAgentTypeHandlerVersionSeenByVmAgent = "Not Available"
    MicrosoftMonitoringAgentStatusSeenByVmAgent = "Not Available"
    MicrosoftMonitoringAgentExtensionTypeHandlerVersion = "Not Available"
    MicrosoftMonitoringAgentExtensionStatus = "Not Available"
    Heartbeat = $false
    Monitoring_Agent_Version = "Not Available"
    Performance = $false
    HeartbeatVariance = 0
    End2EndLatency_50 = 0
    End2EndLatency_95 = 0
    AgentLatency_50 = 0
    AgentLatency_95 = 0
}
Write-Information "Heartbeat data: $($VMHeartbeatData | ConvertTo-Json)"
if ($VMHeartbeatData.Count -ne 0){
    $LogData.Heartbeat = $true
    $LogData.Monitoring_Agent_Version = $VMHeartbeatData.Version
}
Write-Information "Performance data:  $($VMPerformanceData | ConvertTo-Json)"
if ($VMPerformanceData.Count -ne 0){
    $LogData.Performance = $true
}
Write-Information "Frequency data:  $($VMFrequencyData | ConvertTo-Json)"

if ($VMFrequencyData.Count -ne 0){
    $LogData.HeartbeatVariance = $VMFrequencyData.HBVar
}
Write-Information "Latency data:  $($VMLatencyData | ConvertTo-Json)"
if ($VMLatencyData.Count -ne 0){
    $LogData.End2EndLatency_50 = $VMLatencyData.percentile_E2EIngestionLatency_50
    $LogData.End2EndLatency_95 = $VMLatencyData.percentile_E2EIngestionLatency_95
    $LogData.AgentLatency_50 = $VMLatencyData.percentile_AgentLatency_50
    $LogData.AgentLatency_95 = $VMLatencyData.percentile_AgentLatency_95
}

if ($VMDetail.Statuses[1].Code -ne "PowerState/deallocated") {
    if ($VMDetail.VmAgent.VmAgentVersion) {
        $LogData.VmAgentVersion = $VMDetail.VmAgent.VmAgentVersion
    }
    try {
        $LogData.VmAgentStatus = $VMDetail.VmAgent.Statuses[0].Code
    } catch {
        Write-Warning "Cannot get Agent status for $($VMName)"
    }
    try {
        [DateTime]$BootTime = $VMDetail.Statuses[0].Time
        $LogData.VMUptime = (New-TimeSpan -Start $BootTime -End (Get-Date)).TotalHours
    } catch {
        Write-Warning "Unable to retrieve uptime data for $($VMName)"
    }
}

# Extension and Extension handler details for monitoring agent

if ($null -ne $VMDetail.VmAgent) {
    for ($ExtNo=0; $ExtNo -le ($VMDetail.VmAgent.ExtensionHandlers).Count; $ExtNo++) {
        try {
            if (($VMDetail.VmAgent.ExtensionHandlers[$ExtNo].Type -contains 'Microsoft.EnterpriseCloud.Monitoring.MicrosoftMonitoringAgent') -or ($VMDetail.VmAgent.ExtensionHandlers[$ExtNo].Type -contains 'Microsoft.EnterpriseCloud.Monitoring.OmsAgentForLinux')){
                $LogData.MicrosoftMonitoringAgentTypeHandlerVersionSeenByVmAgent = $VMDetail.VmAgent.ExtensionHandlers[$ExtNo].TypeHandlerVersion
    	        $LogData.MicrosoftMonitoringAgentStatusSeenByVmAgent = $VMDetail.VmAgent.ExtensionHandlers[$ExtNo].Status.DisplayStatus
            }
        } catch {
            Write-Warning "Unable to extract extension handler data for $($VMName)"
            Write-Warning ($VMDetail.VmAgent | ConvertTo-Json)
        }
    }
    for ($ExtNo=0; $ExtNo -le ($VMDetail.Extensions).Count; $ExtNo++) {
        try {
            if (($VMDetail.Extensions[$ExtNo].Type -contains 'Microsoft.EnterpriseCloud.Monitoring.MicrosoftMonitoringAgent') -or ($VMDetail.Extensions[$ExtNo].Type -contains 'Microsoft.EnterpriseCloud.Monitoring.OmsAgentForLinux')){
                $LogData.MicrosoftMonitoringAgentExtensionTypeHandlerVersion = $VMDetail.Extensions[$ExtNo].TypeHandlerVersion
    	        $LogData.MicrosoftMonitoringAgentExtensionStatus = $VMDetail.Extensions[$ExtNo].Statuses.DisplayStatus
            }
        } catch {
            Write-Warning "Unable to extract extension data for $($VMName)"
            Write-Warning ($VMDetail.VmAgent | ConvertTo-Json)
        }
    }
}
$LogType = "ExtensionHealth"
$JSONBody = $LogData | ConvertTo-Json
Write-Information "Sending health data to log analytics"
Send-LogAnalyticsData -customerId $LAWorkspaceId -sharedKey $env:AZURE_WORKSPACE_KEY -body ([System.Text.Encoding]::UTF8.GetBytes($jsonBody)) -logType $logType

#region Self-heal automation for Agent Health issues
$workspaceId = $LogData.RequiredWorkspaceId
$targetResourceId = $LogData._ResourceId
# Self-heal query
$selfhealQuery = @"
SelfHeal_CL
| where TimeGenerated > ago(24h)
| where SelfhealCategory_s == 'AgentHealth' and ResourceId == '$targetResourceId'
"@

# Determine if Self-heal will be invoked
$selfhealResults = (Invoke-AzOperationalInsightsQuery -WorkspaceId $workspaceId -Query $selfhealQuery -EA 0).results
if (!([string]::IsNullOrEmpty($selfhealResults))) {
    Write-Output "Self-heal was already attempted in the last 24 hours. Skipping execution."
    exit
}

# Self-heal alert schema
$SelfhealAlertSchema = New-Object PsCustomObject
$SelfhealAlertSchema | Add-Member -MemberType NoteProperty -Name SelfhealCategory -Value "AgentHealth"
$SelfhealAlertSchema | Add-Member -MemberType NoteProperty -Name SelfhealResult -Value $null
$SelfhealAlertSchema | Add-Member -MemberType NoteProperty -Name SelfhealSeverity -Value "Critical"
$SelfhealAlertSchema | Add-Member -MemberType NoteProperty -Name SelfhealMessage -Value $null
$SelfhealAlertSchema | Add-Member -MemberType NoteProperty -Name ProcessedAlert -Value $null

# Self-heal processed alert
$ProcessedAlert = [PSCustomObject]@{
    alertRule = "AgentHealth-Failed"
    description = "VM resources reported with failed agent health from Agent Health dashboard."
    SearchQuery = $null
    ResourceId = $LAWorkspaceName
    SearchResults = $null
}

function Get-AzCachedAccessToken(){
    $ErrorActionPreference = 'Stop'
    $currentAzureContext = Get-AzContext
    $azureRmProfile = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile
    $profileClient = New-Object Microsoft.Azure.Commands.ResourceManager.Common.RMProfileClient($azureRmProfile)
    $token=$profileClient.AcquireAccessToken($currentAzureContext.Subscription.TenantId)
    $token.AccessToken
}

function Get-AzBearerToken(){
    $ErrorActionPreference = 'Stop'
    ('Bearer {0}' -f (Get-AzCachedAccessToken))
}

# Filter bad results for self-heal
if ($VMDetail.Statuses[1].Code -eq "PowerState/running") {
    if (($LogData.RequiredWorkspaceId -ne $LogData.ConfiguredWorkspaceId) -or `
        ($LogData.VmAgentStatus -ne "ProvisioningState/succeeded") -or `
        ($LogData.MicrosoftMonitoringAgentExtensionStatus -ne "Provisioning succeeded") -or `
        (([int]$LogData.HeartbeatVariance -gt 10) -and ($LogData.VMUptime -gt 24)) -or `
        ($LogData.Heartbeat -eq $false)) {
        
        # Invoke the Logic App endpoint URL
        $LogData.Add("Resource", $($VMDetail.Name))
        $LogData.Add("ResourceId", $VMResourceId)
        $LogData.Add("SubscriptionId", $VMSubscription)
        $LogData.Add("Severity", "Critical")
        $ProcessedAlert.SearchResults = $LogData
        $SelfhealAlertSchema.ProcessedAlert = $processedAlert
        $SelfhealAlertSchemaJSON = $SelfhealAlertSchema | ConvertTo-Json -Depth 5
        $ARMToken = Get-AzBearerToken
        $SelfhealLogicApp = Get-AzResource -ResourceType Microsoft.Logic/workflows `
            -TagName "service" -TagValue "selfheal"
        if ($SelfhealLogicApp) {
            $SelfhealLogicAppUrl = [string]::Concat("https://management.azure.com", $SelfhealLogicApp.ResourceId, `
                "/triggers/manual/run?api-version=2016-06-01")
            $SendToSelfheal = Invoke-WebRequest -Uri $SelfhealLogicAppUrl `
                -Method POST -ContentType "application/json;charset=UTF-8" `
                -Headers @{Authorization ="$ARMToken"} `
                -Body $SelfhealAlertSchemaJSON -UseBasicParsing
            if ($null -eq $SendToSelfheal) {
                Write-Error "Unable to send alert to Logic App for processing."
            } else {
                if ($SendToSelfheal.StatusCode -eq "202") {
                    Write-Output "Self-heal started on $($SelfhealAlertSchema.ProcessedAlert.SearchResults.Computer)."
                } else {
                    Write-Warning "Failed to start self-heal on $($SelfhealAlertSchema.ProcessedAlert.SearchResults.Computer)."
                }
            }
        }
    } else {
        Write-Output "Self-heal not required."
    }
} else {
    Write-Output "Self-heal not required."
}
#endregion