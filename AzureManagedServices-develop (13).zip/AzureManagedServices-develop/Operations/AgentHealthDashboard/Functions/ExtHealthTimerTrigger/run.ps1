# Input bindings are passed in via param block.
param($Timer)

# Configuration parameters
[int]$QueryPeriodInMin = 360
[string]$QueryPeriod = ($QueryPeriodInMin / 60).ToString() + "h"

# Get environment variables
$LAWorkspaceName = $env:AZURE_WORKSPACE_NAME
$LAWorkspaceId = $env:AZURE_WORKSPACE_ID

# Log Analytics queries
$HeartbeatQuery = @"
Heartbeat
| where TimeGenerated > ago($($QueryPeriod))
| summarize by Resource, Category, OSType, OSName, OSMajorVersion, OSMinorVersion, Version 
"@

$PerformanceQuery = @"
let RecentPerf = Perf | where TimeGenerated > ago($($QueryPeriod)) | summarize by Computer;
Heartbeat
| where TimeGenerated > ago($($QueryPeriod))
| where Computer in (RecentPerf)
| summarize by Resource, ResourceGroup, OSType, Version, OSName
"@

$FrequencyQuery = @"
Heartbeat
| where TimeGenerated > ago($($QueryPeriod))
| summarize HBCount = count() by Resource
| extend HBVar = abs(HBCount - $($QueryPeriodInMin))
"@

$LatencyQuery =@"
Heartbeat
| where TimeGenerated > ago($QueryPeriod) 
| extend E2EIngestionLatency = ingestion_time() - TimeGenerated 
| extend AgentLatency = _TimeReceived - TimeGenerated 
| summarize percentiles(E2EIngestionLatency,50,95), percentiles(AgentLatency,50,95) by Resource
"@

$HeartbeatResults = (Invoke-AzOperationalInsightsQuery -WorkspaceId $LAWorkspaceId -Query $HeartbeatQuery).results
$PerformanceResults = (Invoke-AzOperationalInsightsQuery -WorkspaceId $LAWorkspaceId -Query $PerformanceQuery).results
$FrequencyResults = (Invoke-AzOperationalInsightsQuery -WorkspaceId $LAWorkspaceId -Query $FrequencyQuery).results
$LatencyResults = (Invoke-AzOperationalInsightsQuery -WorkspaceId $LAWorkspaceId -Query $LatencyQuery).results

# Get the current universal time in the default string format
$currentUTCtime = (Get-Date).ToUniversalTime()

# The 'IsPastDue' property is 'true' when the current function invocation is later than scheduled.
if ($Timer.IsPastDue) {
    Write-Host "PowerShell timer is running late!"
}

# Write an information log with the current time.
Write-Host "PowerShell timer trigger function ran! TIME: $currentUTCtime"
Get-AzContext | Out-String | Write-Information
$VMList = Get-AzVM | ? { $_.Tags["dxcMonitored"] -eq $true } # Add filter to tagged VMs only.

foreach($VM in $VMList) {
    $VMHBData = $HeartbeatResults | Where-Object {$_.Resource -like "$($VM.name)*"}
    $VMPerfData = $PerformanceResults | Where-Object {$_.Resource -like "$($VM.name)*"}
    $VMFreqData = $FrequencyResults | Where-Object {$_.Resource -like "$($VM.name)*"}
    $VMLatData = $LatencyResults | Where-Object {$_.Resource -like "$($VM.name)*"}
    $VMDetails = @{
        Name = $VM.Name
        ResourceGroupName = $VM.ResourceGroupName
        ResourceId = $VM.Id
        OSImageVersion = $VM.StorageProfile.ImageReference.offer + " " + $VM.StorageProfile.ImageReference.sku
        HeartbeatData = $VMHBData
        PerformanceData = $VMPerfData
        FrequencyData = $VMFreqData
        LatencyData = $VMLatData
    }
    Write-Information "Pushing $($VM.Name) details to queue"
    $VMDetails | ConvertTo-Json | Push-Outputbinding -Name VMoutputQueueItem
}
