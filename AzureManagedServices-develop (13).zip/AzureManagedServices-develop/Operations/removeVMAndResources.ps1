<#
=====================================================================================================================
	� Copyright DXC Technology, 2020. All rights reserved
	� DXC Technology, 2019, 2020. All rights reserved

NOTE:  If this script is not run in the Azure Portal Cloud Shell (Powershell), then the user must have the Powershell
Az (NOT AzureRM) modules installed and working
NOTE:  The "-whatif" option is commented out for the "destructive" (deletion) commands (below).  They may be uncommented 
for troubleshooting purposes, if desired.
=====================================================================================================================
AUTHOR:  Tim Vrazo 
DATE:    9 July 2019 - Initial dev
UPDATE: 13 Aug 2019 - added logging, multi-disk, multi-nic capabilities
UPDATE: 19 Aug 2019 - added error handling; all az cli commands converted to az powershell
UPDATE: 05 Sep 2019 - added initial verification of the entries made as command-line parameters to the script ie -vmName and -vmRg
UPDATE: 30 Oct 2019 - added subscriptionCheck()
Version: 1.0

AUTHOR: Bang Bui
Version 1.1
UPDATE: Removed separation of OS and data disks to avoid specific search for a name. Delete all disks in one loop regardless of OS or data.

AUTHOR: Anthony Borucki
Version 1.2
UPDATE: Added Boot Diagnostics Blob Deletion to VM Deletion Script

Documentation: https://dxcconfluence.atlassian.net/wiki/spaces/CSA/pages/XXXXXX
======================================================================================================================
.SYNOPSIS
    Tool for removing a VM and its associated Public IP, vNIC and Disk resources
.DESCRIPTION
    .PARAMETER  vmName
		The name of the VM being removed.  This would be the name found under the "Name" column in the Virtual Machines blade
    .PARAMETER  vmRg
		The Resource Group of the VM being removed.  This can be found found under the "Resource Group" column in the Virtual Machines blade
.EXAMPLE
	.\removeVMAndResources.ps1 -vmName <Name-of-VM> -vmRg <Resource-group-of-VM>
#>
[CmdletBinding(SupportsShouldProcess=$true)]
Param(
	[Parameter(Mandatory=$true)] [String]$vmName,
	[Parameter(Mandatory=$true)] [String]$vmRg
)
$log=".\removeVMAndResources.log"
try {
	Start-Transcript $log -Append
}
catch {
	"unable to start transcript at "+(get-date -format o)|Out-File $log -Append -Encoding ascii
}
function subscriptionCheck()
{
	Clear-Host
	""
	""
	"*****************************************************************"
	"* VM REMOVAL SCRIPT - REMOVE VM AND ASSOCIATED RESOURCES *"
	"*****************************************************************"
	""
	""
	"Your Azure Context (Subscription) is currently set to:"
	""
	try {
		$azContext=Get-AzContext
		if ($azContext -eq $null) {
			"Please log in to Azure using Connect-AzAccount -SubscriptionName <Name of Subscription> and re-run this script."
			""
			bail "noop"
		}
		else {
			$azContext
			""
			$subOk=$null
			while ($subOK -ne "Y") {
				$subOk=read-host 'Is this the subscription you wish to proceed with? (Y/y to proceed, or N/n to quit)'
				if ($subOk -eq "Y" -or $subOk -eq "N") {
					if ($subOk -eq "Y") {
						""
						"OK - proceeding with the provided subscription."
						""
						pause
					}
					else {
						""
						"Please set your powershell session to desired subscription using Set-AzContext -Subscription <Name of Subscription> and re-run this script"
						""
						bail "noop"
					}
				}
				else {
					"ERROR: Invalid entry.  Please enter Y/y or N/n to proceed or quit."
					pause
				}			
			}
		}
	}
	catch
	{
		""
		'There was an error running the Get-AzContext cmdlet. This may be because the Azure (Az) modules - which are required to run this script - are not installed. Please install them using "Install-Module Az".  If you already have AzureRM modules installed, they may have to be uninstalled first.  Please refer to https://azure.microsoft.com/en-us/blog/how-to-migrate-from-azurerm-to-az-in-azure-powershell/ for more detail on how to do this.'
		""
		bail "error"

	}
}
function bail($action) {
	switch ($action) {
		'normal' {
			$exitCode=0
		}
		'noop' {
			""
			"Exiting without taking any action."
			""
			$exitCode=1
		}
		'error' {
			""
			"Exiting"
			"NOTE:  if some, but not all of the resources were deleted, the script '.\removeOrphanedResources' may be run to selectively remove the remaining resources one-by-one."
			""
			$exitCode=1
		}
	}
	try {
		Stop-Transcript
	}
	catch {
		"unable to stop transcript at "+(get-date -format o)|Out-File $log -Append -Encoding ascii
	}
	exit $exitCode
}

#
# MAIN
#
#
subscriptionCheck
clear-host
""
""
"*****************************************************************"
"* VM REMOVAL SCRIPT - REMOVE VM AND ASSOCIATED RESOURCES *"
"*****************************************************************"
""
"Validating resource entries..."
""
if((get-azresource -name $vmName) -eq $null){
	"ERROR:		VM $vmName DOES NOT exist"
	""
	bail "noop"
} 
else {
	"VALIDATED:	VM $vmName exists"
	""
}

if(get-azresourcegroup -name $vmRg -erroraction SilentlyContinue){
	"VALIDATED:	Resource Group $vmRg exists"
	""
}
else {
	"ERROR:		Resource Group $vmRg DOES NOT exist"
	""
	bail "noop"
}

if((get-azresource -name $vmName -ResourceGroupName $vmRg) -eq $null){
	"ERROR:		VM $vmName DOES NOT exist in Resource Group $vmRg"
	""
	bail "noop"
} 
else {
	"VALIDATED:	VM $vmName exists in Resource Group $vmRg"
	""
	pause
}
clear-host
""
""
"*****************************************************************"
"* VM REMOVAL SCRIPT - REMOVE VM AND ASSOCIATED RESOURCES *"
"*****************************************************************"
""
#
#Get the Resource ID of the to-be-deleted-VM
#
try {
	$vmResourceId=(get-azresource -name $vmName -resourcegroupname $vmRg | ?{$_.name -eq $vmName}).Id
}
catch {
	"Error retrieving resource id for the VM.  See  $log for detail."
	bail "noop"
}
#
#Get the vNIC(s) associated with the to-be-deleted-VM
#
write-host "Retrieving the " -f yellow -nonewline; write-host "Virtual Network Adapter(s)" -f green -nonewline; write-host "..." -f yellow
try {
	$associatedNicName=@((Get-AzNetworkInterface | ?{$_.VirtualMachine.Id -eq $vmResourceId}).Name)
	$associatedNicResourceId=@((Get-AzNetworkInterface | ?{$_.VirtualMachine.Id -eq $vmResourceId}).Id)
}
catch {
	"Error retrieving resource info for the vNIC.  See  $log for detail."
	bail "noop"
}
#
#Get the Public IP(s) associated with the to-be-deleted-VM (actually, with the NIC(s), that are assoc w the to-be-deleted VM)
#
write-host "Retrieving the " -f yellow -nonewline; write-host "Public IP Address(es)" -f green -nonewline; write-host "..." -f yellow
try {
	$associatedPublicIpAddress=@(
		for ($i = 0; $i -lt $associatedNicResourceId.count; $i++) {
			(Get-AzPublicIpAddress|?{$_.IpConfiguration.Id -match $associatedNicResourceId[$i]}).IpAddress
		}
	)
	$associatedPublicIpResourceId=@(
		for ($i = 0; $i -lt $associatedNicResourceId.count; $i++) {
			(Get-AzPublicIpAddress|?{$_.IpConfiguration.Id -match $associatedNicResourceId[$i]}).Id
		}
	)
}
catch {
	"Error retrieving resource info for the Public IP Address.  See  $log for detail."
	bail "noop"
}
#
#Get ALL Disk resources associated with the to-be-deleted-VM
#
write-host "Retrieving the " -f yellow -nonewline; write-host "All Disks" -f green -nonewline; write-host "..." -f yellow
try {
	$associatedDiskName=(get-azdisk |?{$_.ManagedBy -eq $vmResourceId}).Name
	$associatedDiskResourceId=(get-azdisk |?{$_.ManagedBy -eq $vmResourceId}).Id
}
catch {
	"Error retrieving resource info for all Disks.  See  $log for detail."
	bail "noop"
}
#
#Get boot diagnostics blob associated with the to-be-deleted-VM
#
write-host "Retrieving the " -f yellow -nonewline; write-host "Diagnostics Blob" -f green -nonewline; write-host "..." -f yellow
try {
		$vm = Get-AzVm -ResourceGroupName $vmRg -Name $vmName
		if ($vm.DiagnosticsProfile.bootDiagnostics) {
				$diagSa = [regex]::match($vm.DiagnosticsProfile.bootDiagnostics.storageUri, '^http[s]?://(.+?)\.').groups[1].value

				if ($vm.Name.Length -gt 9) {
					$i = 9
				} else {
					$i = $vm.Name.Length
				}

				$vmId = $vm.VmId
				$vmnameNoSpecialCharacters = $vm.name -replace '[^\p{L}\p{Nd}]', ''
				$diagContainerName = ('bootdiagnostics-{0}-{1}' -f $vmnameNoSpecialCharacters.ToLower().Substring(0, $i), $vmId)
				$diagSaRg = (Get-AzStorageAccount | where { $_.StorageAccountName -eq $diagSa }).ResourceGroupName
		}
}
catch {
	"Error retrieving resource info for boot diagnostics blob.  See  $log for detail."
	bail "noop"
}

$continue=$true
while ($continue) {
	""
	write-host "Please confirm that you want to remove the following VM and its associated resources:" -f yellow
	""
	write-host "VM: " -f yellow -nonewline; write-host $VMName
	write-host "vNIC(s): " -f yellow -nonewline; write-host $associatedNicName
	write-host "Public IP(s): " -f yellow -nonewline; write-host $associatedPublicIpAddress
	write-host "Disk(s): " -f yellow -nonewline; write-host $associatedDiskName
	write-host "Boot Diagnostic Container: " -f yellow -nonewline; write-host $diagContainerName
	""
	$response=read-host "Confirm ==> PERMANENT DELETION <== of VM $vmName and its associated resources (Y/N - Y to proceed, N to quit)"
	if ($response -eq "Y") {
		try {
			""
			write-host "You chose to proceed with deletion."
			""
			#
			#Delete the VM
			#
			write-host "Deleting " -f yellow -nonewline; write-host "Virtual Machine $vmName" -f green -nonewline; write-host "..." -f yellow
			Remove-AzVm -Id $vmResourceId -force #-whatif
			"***Deleted the vm "+$vmResourceId
			#
			#Delete the vNIC(s) associated with deleted VM
			#
			write-host "Deleting the " -f yellow -nonewline; write-host "Virtual Network Adapter(s) $associatedNicName" -f green -nonewline; write-host "..." -f yellow
			#
			#Delete the Public IP Address(es) associated with the deleted NIC
			#
			for ($i = 0; $i -lt ($associatedNicResourceId.count); $i++) {
				Remove-AzResource -ResourceId $associatedNicResourceId[$i] -force #-whatif 
				"***Deleted vNIC "+$associatedNicResourceId[$i]
			}
			write-host "Deleting the " -f yellow -nonewline; write-host "Public IP Address(es) $associatedPublicIpAddress" -f green -nonewline; write-host "..." -f yellow
			for ($i = 0; $i -lt ($associatedPublicIpResourceId.count); $i++) {
				if ($associatedPublicIpResourceId[$i] -ne $null) {
					Remove-AzResource -ResourceId $associatedPublicIpResourceId[$i] -force #-whatif
				"***Deleted public ip"+$associatedPublicIpResourceId[$i]
				}
			}	
			#
			#Delete all disk(s) associated with the deleted VM
			#
			write-host "Deleting the " -f yellow -nonewline; write-host "Disk(s) $associatedDiskName" -f green -nonewline; write-host "..." -f yellow
			foreach($disk in $associatedDiskResourceId)
			{
				Remove-AzResource -ResourceId $disk -force #-whatif
				"***Deleted disk(s)"+$disk
			}
			#
			#Delete Boot Diagnostic Container associated with the deleted VM
			#
			write-host "Deleting the " -f yellow -nonewline; write-host "Boot Diagnostic Container $diagContainerName" -f green -nonewline; write-host "..." -f yellow
			Get-AzStorageAccount -ResourceGroupName $diagSaRg -Name $diagSa | Get-AzStorageContainer | where { $_.Name -eq $diagContainerName } | Remove-AzStorageContainer -Force #-whatif
			"***Deleted Boot Diagnostic Container "+$diagContainerName
			""
			write-host "The VM and associated resources have been deleted.  Please confirm by checking in the Azure Portal.  Exiting"
		}
		catch {
			"Error deleting resources!  See  $log for detail."
			bail "error"
		}
		""
		$continue=$false
	}
	else {
		if ($response -eq "N") {
			""
			bail "noop"
			""
		}
		else {
			""
			"                 !!!!!! ERROR !!!!!: Invalid entry.  Please enter Y or N."
		}
	}
}
bail "normal"
