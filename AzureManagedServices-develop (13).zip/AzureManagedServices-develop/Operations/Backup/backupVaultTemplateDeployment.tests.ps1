param(

  [Parameter(Mandatory)]
  [ValidateNotNullOrEmpty()]
  [string]$LogAnalyticsResourceGroup,

  [Parameter (Mandatory)]
  [ValidateNotNullOrEmpty()]
  [string]$logAnalyticsWorkspaceName
  )

$global:TemplatePath = "./backup-vault-with-daily-backup-policy.json"
$global:vaultName =  "VaultTest-Pester-BV"
$global:LogAnalyticsResourceGroup = $LogAnalyticsResourceGroup
$global:logAnalyticsWorkspaceName = $logAnalyticsWorkspaceName

Describe 'ARM Template Validation' {
	Context 'Deployment Validation' {
		It 'Should deploy without errors' {
			$deployment = New-AzResourceGroupDeployment  -Name "BackupVaultPesterTest" -TemplateFile $global:TemplatePath -ResourceGroupName $global:LogAnalyticsResourceGroup -vaultName $global:vaultName -logAnalyticsWorkspaceName $global:logAnalyticsWorkspaceName -LogAnalyticsResourceGroup $global:LogAnalyticsResourceGroup
            $deployment.provisioningState | Should -Be 'Succeeded'
        }
        It 'Should deploy a backup vault with the correct name' {
            $global:testvault = (Get-AzRecoveryServicesVault -Name $global:vaultName -ResourceGroupName $global:LogAnalyticsResourceGroup)
            ($global:testvault | Measure-Object).Count | Should -Be 1
        }  
        It 'Should create a diagnostics setting on the vault linked to the correct Log Analytics workspace' {
            ( (Get-AzDiagnosticSetting -ResourceId $global:testvault.ID -wa 0).Logs | ?{$_.Category -eq 'AzureBackupReport'}).enabled | Should -Be $true 
        }
        AfterAll{
            Write-host "Cleaning up"
            Remove-AzRecoveryServicesVault -Vault $global:testvault
        }
    }
}