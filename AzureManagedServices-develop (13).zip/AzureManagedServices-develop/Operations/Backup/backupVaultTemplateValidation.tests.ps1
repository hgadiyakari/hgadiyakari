$global:TemplatePath = "./backup-vault-with-daily-backup-policy.json"
$global:templateARM = Get-Content $TemplatePath -Raw 
$global:template = ConvertFrom-Json -InputObject $templateARM 
$global:templateElements = $template.psobject.Properties.name.tolower()

Describe 'ARM Template Validation' {
	Context 'File Validation' {
		It 'Template ARM File Exists' {
			Test-Path $global:TemplatePath -Include '*.json' | Should -Be $true
		}

		It 'Is a valid JSON file' {
			$global:templateARM | ConvertFrom-Json -ErrorAction SilentlyContinue | Should -Not -Be $Null
	  }
  }
    Context 'Template Content Validation' {
      It "Contains all required elements" {
          $Elements = '$schema',
                      'contentVersion',
                      'outputs',
                      'parameters',
                      'resources',
		      'variables'                                
            $templateProperties = $global:template | Get-Member -MemberType NoteProperty | ForEach-Object Name
            $templateProperties | Should -Be $Elements
        }
        It "Creates the expected resources" {
            $Elements = @('Microsoft.RecoveryServices/vaults', 'Microsoft.RecoveryServices/vaults/backupPolicies', 'Microsoft.RecoveryServices/vaults/backupPolicies', 'Microsoft.RecoveryServices/vaults/backupPolicies', 'Microsoft.RecoveryServices/vaults/providers/diagnosticSettings')
            $templateResources = $global:template.Resources.type
            $templateResources | Should -Be $Elements
        }
  
    }
}