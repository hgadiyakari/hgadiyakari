**Resources**

This folder contains the resources for deploying a standard backup vault and reporting to a customer following onboarding  
* backup-vault-with-daily-backup-policy.json - this is the arm template to deploy the vault and diagnostics settings
* enable-backup-reports.ps1 - this enables diagnostic setting "BackupReports" across all vaults in a resource group

**Testing**

The folder also contains Pester tests to validate the ARM template and to confirm it deploys successfully.  These should not be run in customer environments
* backupVaultTemplateValidation.tests.ps1 - checks the filename, existence and JSON structure of the template
* backupVaultTemplateDeployment.tests.ps1 - checks the template deploys a valid vault and that BackupReport diagnostics are configured (and removes the vault afterwards)

*Running the tests*  
1. You need to have Powershell Core 7 and the Pester Module 5.0 or greater installed.
2. Ensure you are logged in to azure and have set the context to your test subscription, and that there is an existing Log Analytics Workspace in that subscription.  
3. Collect the following information
LogAnalyticsResourceGroup
LogAnalyticsWorkspaceName 
Then, from the Backup folder where these files reside, run:
```
 Invoke-Pester -Output Detailed

```
When prompted enter the values collected and hit enter after each. Here is an example run
```
PS C:\Users\cneale3\Documents\repos\AzureManagedServices\Operations\Backup> invoke-pester -Output Detailed

Starting discovery in 2 files.
Discovering in C:\Users\cneale3\Documents\repos\AzureManagedServices\Operations\Backup\backupVaultTemplateDeployment.tests.ps1.

cmdlet backupVaultTemplateDeployment.tests.ps1 at command pipeline position 1
Supply values for the following parameters:
LogAnalyticsResourceGroup: DXC-MAINT-RG
logAnalyticsWorkspaceName: DXC-EA1C-41de-loganalyticsWorkspace
Found 3 tests. 3.21s
Discovering in C:\Users\cneale3\Documents\repos\AzureManagedServices\Operations\Backup\backupVaultTemplateValidation.tests.ps1.
Found 4 tests. 95ms
Discovery finished in 3.32s.

Running tests from 'C:\Users\cneale3\Documents\repos\AzureManagedServices\Operations\Backup\backupVaultTemplateDeployment.tests.ps1'
Describing ARM Template Validation
 Context Deployment Validation
   [+] Should deploy without errors 11.77s (11.77s|2ms)
   [+] Should deploy a backup vault with the correct name 755ms (753ms|2ms)
   [+] Should create a diagnostics setting on the vault linked to the correct Log Analytics workspace 1.21s (1.21s|2ms)
Cleaning up

Running tests from 'C:\Users\cneale3\Documents\repos\AzureManagedServices\Operations\Backup\backupVaultTemplateValidation.tests.ps1'
Describing ARM Template Validation
 Context File Validation
   [+] Template ARM File Exists 23ms (21ms|2ms)
   [+] Is a valid JSON file 6ms (4ms|2ms)
 Context Template Content Validation
   [+] Contains all required elements 9ms (7ms|2ms)
   [+] Creates the expected resources 17ms (15ms|2ms)
Tests completed in 25.65s
Tests Passed: 7, Failed: 0, Skipped: 0 NotRun: 0
```
You will see the passing tests in green with plus (+) signs next to them