<#
====================================================================================================================================================
Contributors:  Dudley Miller
DATE:    07/22/2019
Version: 1.0
====================================================================================================================================================
.SYNOPSIS
    enable-backup-reports.ps1

.DESCRIPTION
    The script will create a diagnostic setting and enable it for all backup vaults in a resource group. This is setting needed to send 
    Azure backup reports to Log Analytics in order to enable additional queries on the backup jobs to detect backup failures.

    Syntax: 
     ./enable-backup-reports.ps1 -SubscriptionId <subscription id> -VaultNames <vault name list>  -LogAnalyticsWorkspaceName <LA WorkspaceName> -LogAnalyticsResourceGroup <LA RG>

    Parameters:
      SubscriptionId :  Subscription ID 
      VaultNames : Comma Separated list of Backup Vault names
      LogAnalyticsWorkspaceName :  Log Anaylytics Workspace name
      LogAnalyticsResourceGroup :  Resource Group that contains the LA workspace

    Notes:

        This script was developed and tested using the Azure PS cloud shell to avoid any issues with required PowerShell versions.
        It should also run without issue on Powershell Core v6.x and later
        To run this script from cloud shell:
            1) Launch an Azure PS cloud shell using the portal
            2) Use Get-CloudDrive to retrieve the Azure file share information currently mounted 
            3) Select the storage account and then the file share associated with your id
            4) Updload this script
            5) cd ~/clouddrive
            6) run the script at which point you will be prompted for a login
   
.EXAMPLE
     ~\clouddrive\enable-backup-reports.ps1 -SubscriptionId '41de9402-bdbf-4272-83b5-c47919900bd6' -VaultNames 'BackupVault1','BackupVault2' -LogAnalyticsWorkspaceName 'DXC-EA1C-41de-loganalyticsWorkspace' -LogAnalyticsResourceGroup 'DXC-Maint-RG'

================================================================================================================================================================================================================================================
#>

#
########### Parameters section ###########
#
[CmdletBinding(SupportsShouldProcess=$true)]
Param
    (
    [Parameter(Mandatory=$true)] [String]$SubscriptionId,
    [Parameter(Mandatory=$true)] [Array]$VaultNames,
    [Parameter(Mandatory=$true)] [String]$LogAnalyticsWorkspaceName,
    [Parameter(Mandatory=$true)] [String]$LogAnalyticsResourceGroup
    )

########### Variable section ###########

$SettingName = "AzureBackupReport_LogAnalytics"
$LogsToEnable = @(
    "CoreAzureBackup","AddonAzureBackupJobs","AddonAzureBackupAlerts","AddonAzureBackupPolicy","AddonAzureBackupStorage","AddonAzureBackupProtectedInstance"
)

# 
#  Login Section with Logic to determine is already logged into account with access to SubscriptionId
# 
$needLogin = $true
Try 
{
    $context = Get-AzContext
    if ($context) 
    {
        $needLogin = ([string]::IsNullOrEmpty($context.Account))
    } 
    if (-not $needLogin) {
        $AccessToSubscription = Get-AzSubscription | where-object {$_.Id -match $SubscriptionId}            
        if ($AccessToSubscription) {
            $needLogin = ([string]::IsNullOrEmpty($AccessToSubscription))   
        }
    }
} 
Catch 
{
    if ($_ -like "*Connect-AzAccount to login*") 
    {           
        $needLogin = $true
    } 
    else 
    {
        throw
    }
}

if ($needLogin)
{
    $error.Clear()
    Write-Host "`nINFORMATION: Please login to Azure." -ForegroundColor Green
    Connect-AzAccount -ErrorAction SilentlyContinue >$null
    if ($error) 
        { 
        Write-Host "WARNING:     Unable to connect to Azure. Check your internet connection and verify authentication details." -ForegroundColor Yellow
        exit 
        }
    Write-Host "INFORMATION: Logged into Azure with provided authentication." -ForegroundColor Green 
} else {
    Write-Host "`nLogin session still valid.  Skipping Connect-AzAccount`n" -ForegroundColor Green
}

#
#  Set Subscription ID
#
$error.Clear()
Set-AzContext -SubscriptionID $SubscriptionId -ErrorAction SilentlyContinue   
if ($error) 
    { 
    Write-Host "WARNING:     Invalid Subscription ID. Please make sure you have proper access to this Azure Subscription." -ForegroundColor Yellow 
    Write-Host "             Run the Powershell Command: " -ForegroundColor Yellow -NoNewLine 
    Write-Host "Set-AzContext -Subscription $SubscriptionID " -NoNewLine
    Write-Host "and login with your authentication details." -ForegroundColor Yellow
    Write-Host "             If you need to reset your session run can run the PowerShell command: " -ForegroundColor Yellow -noNewLine
    Write-Host "Disconnect-AzAccount" 
    exit 
    }

Write-Host "`r`nINFORMATION: Connected to Azure Subscription " -NoNewline -ForegroundColor Green
Write-Host $SubscriptionID -NoNewline
Write-Host " with provided authentication." -ForegroundColor Green 

#
# Get full resource ID of Log Analytics Workspace
#
$LogAnalyticsResourceID = (Get-AzOperationalInsightsWorkspace -Name $LogAnalyticsWorkspaceName -ResourceGroup $LogAnalyticsResourceGroup).ResourceId
if ($error) 
    { 
    Write-Host "Error:    Unable to determine ResourceID of the Log Analytics workspace." -ForegroundColor Yellow 
    Write-Host "          Please check the input values for the parameters LogAnalyticsWorkspaceName and LogAnalyticsResourceGroup" -ForegroundColor Yellow
    exit 
    }

#
#  Main loop to add Diagnostic Setting to each vault found in the specified RG
#
try {
    foreach($name in $VaultNames) {
        $vaults = Get-AzRecoveryServicesVault -Name $name
        foreach ($vault in $vaults) {
        Write-Host "Adding diagnostic setting for vault name: "  $vault.name in ResourceGroup: $vault.ResourceGroupName -ForegroundColor Green
        Set-AzDiagnosticSetting -ResourceId $vault.ID -Enabled $true -WorkspaceId $LogAnalyticsResourceID -Category $LogsToEnable -Name $SettingName -ExportToResourceSpecific -ErrorAction Stop -WarningAction SilentlyContinue | Out-Null
        }
    }
} catch {
    Write-Host "Error: $_"
}
