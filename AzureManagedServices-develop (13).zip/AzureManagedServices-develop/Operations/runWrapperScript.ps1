
<#
.SYNOPSIS
    This is a wrapper script that controls execution of release deployment scripts to multiple subscriptions using an input file.
    Scripts in scope are the following:
    - deployAlerts.ps1
    - deployHBAlertFunctions.ps1
    - deployMetricAlertFunctions.ps1
    - deployFunctionAppAlerts.ps1
    - deploySNOWConnectionMonitoringFunctionApp
    - removeAlerts.ps1
    - deploySelfheal.ps1 (includes deployAlertRule.ps1)
    Report a bug or an issue with this script here: https://confluence.csc.com/pages/viewpage.action?pageId=162089166        
.EXAMPLE
    .\runWrapperScript.ps1
.REVISION HISTORY
    14-Dec-2020 - 1.0 Initial version
.DOCUMENTATION LINK
https://confluence.dxc.com/display/CSA/AZR-19814+-+Azure+X+-+Release+deployment+automation+-+script+for+generic+upgrade+steps
#>
#---------------------------------------------------------[Initializations]--------------------------------------------------------

<#[CmdletBinding()]
Param (
    [Parameter(HelpMessage = "Please enter tenant Id.", Position=1, Mandatory = $true, ValueFromPipeline = $True)]
    [ValidateNotNullOrEmpty()][string]$tenantId
)#>
[CmdletBinding()]
Param
        (
		[Parameter(Mandatory=$false)] [Switch]$automation, #Switch to determine if running full automation from Pipeline
		[Parameter(Mandatory=$false)] [String]$custSpKey  #Service Principal Key
        )
		
#----------------------------------------------------------[Declarations]----------------------------------------------------------
$cust_client_id = $Env:cust_client_id
$scriptName = "runWrapperScript"
$scriptPath = (Get-Location).ProviderPath
$logFileName = ($scriptName + '-{0:dd-MMM-yyyy_HHmm}' -f (Get-Date) + '.log')
$logFilePath = [System.IO.Path]::GetFullPath("$scriptPath\$logFileName")
# Scripts to be included in deployment wrapper
$deployScriptsObj = @(
    [PSCustomObject]@{ Name = "deployAlerts.ps1"; Path = [System.IO.Path]::GetFullPath("$scriptPath\..\OnBoarding\Alerting\Alerts\deployAlerts.ps1"); Index = 1;  }
    [PSCustomObject]@{ Name = "deploySNOWConnectionMonitoringFunctionApp.ps1"; Path = [System.IO.Path]::GetFullPath("$scriptPath\..\OnBoarding\Alerting\SNOWConnectionMonitoringAlertDeployment\deploySNOWConnectionMonitoringFunctionApp.ps1"); Index = 2 }
    [PSCustomObject]@{ Name = "deployHBAlertFunctions.ps1"; Path = [System.IO.Path]::GetFullPath("$scriptPath\..\OnBoarding\Alerting\HeartbeatAlertDeployment\deployHBAlertFunctions.ps1"); Index = 3 }
    [PSCustomObject]@{ Name = "deployMetricAlertFunctions.ps1"; Path = [System.IO.Path]::GetFullPath("$scriptPath\..\OnBoarding\Alerting\MetricAlertDeployment\deployMetricAlertFunctions.ps1"); Index = 4 }
    [PSCustomObject]@{ Name = "deployFunctionAppAlerts.ps1"; Path = [System.IO.Path]::GetFullPath("$scriptPath\..\OnBoarding\Alerting\FunctionAppAlertDeployment\deployFunctionAppAlerts.ps1"); Index = 5 }
    [PSCustomObject]@{ Name = "removeAlerts.ps1"; Path = [System.IO.Path]::GetFullPath("$scriptPath\..\OnBoarding\Alerting\Cleanup\removeAlerts.ps1"); Index = 6 }
    [PSCustomObject]@{ Name = "deploySelfheal.ps1"; Path = [System.IO.Path]::GetFullPath("$scriptPath\SelfHeal\ARMTemplates\deploySelfHeal.ps1"); Index = 7 }
)
$dxcModuleList = "DXCEnvCheckV2.psm1"
$runResultsSummary = New-Object System.Collections.ArrayList
$runScriptsObj = New-Object System.Collections.ArrayList
# Customer data
$customerDataCsvFile = [System.IO.Path]::GetFullPath("$scriptPath\dxcCustomer_params.csv") 
$requiredHeaders = @(
'TenantId','SubscriptionId','LogAnalyticsWorkspaceName','AlertNotificationEmail','AzureStack(Yes/No)', `
'ServiceNowURL','UpgradeFunctionCodes(Auto/Yes)','UpgradeEnvVariables(Auto/Yes)','KeyVault','CustomTrace(Yes/No)'
)

#-----------------------------------------------------------[Functions]------------------------------------------------------------
#region SUPPORTING FUNCTIONS

filter timestamp # Capture the time information for logging purposes.
{"$(Get-Date -Format MM-dd-yyyy-hh:mm:ss): $_"}

function LoginTo-Azure # Login to ARM, AzCLI
{
    [CmdletBinding(SupportsShouldProcess=$true)]
    Param ([Parameter(Mandatory=$false)][string]$tenant,
		   [Parameter(Mandatory=$false)][string]$subId,
		   [Parameter(Mandatory=$false)][Bool]$automate,
		   [Parameter(Mandatory=$false)][String]$custSpKey)
												 
    $error.clear()
	if ($automate) {
		$SecurePassword = $custSpKey | ConvertTo-SecureString -AsPlainText -Force
		$dxcAzureEnv = Get-AzEnvironment 'AzureCloud'	
		$cred = new-object -typename System.Management.Automation.PSCredential -argumentlist "$cust_client_id", $SecurePassword	
		Login-AzAccount -Environment $dxcAzureEnv -Credential $cred -Tenant $tenant -Subscription $subId -ServicePrincipal	
		$azureLogin = "Connect-AzAccount -Tenant $tenant -EA 1 -WA 2"
	}			 								
    elseif ($tenant) {	  
        $azureLogin = "Connect-AzAccount -Tenant $tenant -EA 1 -WA 2"
        $azCLILogin = "az login --tenant $tenant --use-device-code | ConvertFrom-Json"
    } else {
        $azureLogin = "Connect-AzAccount -EA 1 -WA 2"
        $azCLILogin = "az login --use-device-code | ConvertFrom-Json"
    }
    # Login to Azure Resource Manager
    Set-AzContext -Tenant $tenant -EA 0 -WA 2 | Out-Null
    if ($error) {
        $error.clear()
        Write-Output "INFO: Please login to Azure Resource Manager." | timestamp | Write-Host -F Cyan
        $azureLoginOutput = Invoke-Expression -Command $azureLogin
        if (!$azureLoginOutput) {
            Write-Output "ERROR: Failed to connect to Azure Resource Manager. Check your internet connection and verify authentication details." `
                | timestamp | Write-Host -F Red ; exit
        }
    }
     
    # Sign in with Azure CLI
    Write-Output "INFO: Please sign in with Azure CLI." | timestamp | Write-Host -F Cyan  
	if ($automate) {
		$azCLILoginOutput = az login --service-principal -u $cred.UserName -p $cred.GetNetworkCredential().Password --tenant $tenant | ConvertFrom-Json
	}
	else {				   
		$azCLILoginOutput = Invoke-Expression -Command $azCLILogin
    }
    if (!$azCLILoginOutput) { 
        Write-Output "ERROR: Failed to connect to Azure Resource Manager. Check your internet connection and verify authentication details." `
            | timestamp | Write-Host -F Red ; exit
    }
    [System.Console]::ResetColor()
}

function Check-NullorEmpty # Validate input object for null or empty value
{ 
    [CmdletBinding(SupportsShouldProcess=$true)]
    Param ([Parameter(Mandatory=$true)][object]$ifNullorEmptyObj)

    $error.clear()

    $checkNullorEmpty = $ifNullorEmptyObj.PsObject.Properties | % {
        if([string]::IsNullOrEmpty($_.Value)) { $true } else { $false }
    }
    if ($checkNullorEmpty -eq $true) {
        Write-Output "WARN: Please review and provide valid input items." | timestamp | Write-Host -F DarkYellow
        $ifNullorEmptyObj | Out-String | Write-Host -F DarkYellow
        return $true
    } else {
        return $false
    }
}

function Run-Wrapper # Execute a deployment script
{ 
    [CmdletBinding(SupportsShouldProcess=$true)]
    Param (
        [Parameter(Mandatory=$true)][object]$paramObj,
        [Parameter(Mandatory=$true)][string]$scriptFile
    )

    $error.clear(); [System.Console]::ResetColor()

    # Create a copy of the script file and comment out sections requiring user prompts.
    $runScriptName = "run_$($scriptFile.Split("\")[-1])"
    $dxcScriptFile = Get-Content -Path $scriptFile
    $dxcScriptFile = $dxcScriptFile | % { $_ -replace "Read-Host" , "#Read-Host" } 
    $dxcScriptFile = $dxcScriptFile | % { $_ -replace "Get-Variable" , "#Get-Variable" } 
    $dxcScriptFile = $dxcScriptFile | % { $_ -replace "Utility-LoginAZ" , "#Utility-LoginAZ" }
    $dxcScriptFile = $dxcScriptFile | % { $_ -replace "Utility-LoginAZSpn" , "#Utility-LoginAZSpn" }
    $dxcScriptFile = $dxcScriptFile | % { $_ -replace "Utility-LoginAureCliTenant" , "#Utility-LoginAureCliTenant" }
    $dxcScriptFile = $dxcScriptFile | % { $_ -replace "Utility-LoginAzureCliTenant" , "#Utility-LoginAzureCliTenant" }
    $dxcScriptFile = $dxcScriptFile | % { $_ -replace "Connect-AzAccount" , "#Connect-AzAccount" }
    $dxcScriptFile = $dxcScriptFile | % { $_ -replace "Remove-Variable" , "#Remove-Variable" } 
    Set-Location (Split-Path -Path $scriptFile) -EA 0
    # Get key vault secret
    $snUserSecret = (Get-AzKeyVaultSecret -vaultname $($paramObj.keyVault.Trim()) -name "ITSMIntegrationUser").SecretValue
    if ($null -eq $snUserSecret) {
        $ServiceNowUser = $null
    } else {
        $snUserSecretBSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($snUserSecret)
        $ServiceNowUser = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($snUserSecretBSTR)
    }

    $snUserPwdSecret = (Get-AzKeyVaultSecret -vaultName $($paramObj.keyVault.Trim()) -name "ITSMIntegrationPass").SecretValue
    if ($null -eq $snUserPwdSecret) {
        $ServiceNowUserPwd = $null
    } else {
        $snUserPwdSecretBSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($snUserPwdSecret)
        $ServiceNowUserPwd = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($snUserPwdSecretBSTR)
    }
    # Execute the deployment script
    Write-Host "`n"
    Write-Output "Execution started on $($paramObj.subscriptionId) - " | timestamp | Write-Host -NoNewline -F Yellow
    Write-Host "$($scriptFile.Split("\")[-1]) `n" -F Cyan
    try {
        switch ($($scriptFile.Split("\")[-1])) {
            'deployAlerts.ps1' { 
                $dxcScriptFile | Set-Content .\$runScriptName -Force -EA 0
                switch ($($paramObj.'azureStack(Yes/No)'.ToLower())) {
                    'yes' {
                        . .\$runScriptName -dxcSubscriptionID $($paramObj.SubscriptionId) `
                            -dxcLogAnalyticsWorkspaceName $($paramObj.LogAnalyticsWorkspaceName.Trim()) `
                            -dxcalertNotificationEmail $($paramObj.AlertNotificationEmail.Trim()) `
                            -AzureStack -EA 0
                    }
                    default {
                        . .\$runScriptName -dxcSubscriptionID $($paramObj.SubscriptionId) `
                            -dxcLogAnalyticsWorkspaceName $($paramObj.LogAnalyticsWorkspaceName.Trim()) `
                            -dxcalertNotificationEmail $($paramObj.AlertNotificationEmail.Trim()) -EA 0
                    }
                }
            }
            'deployHBAlertFunctions.ps1' {
                $dxcScriptFile = $dxcScriptFile | % { $_ -replace "dxcHBFunctionZip" , "dxcZippedFunctionPath" }
                $dxcScriptFile | Set-Content .\$runScriptName -Force -EA 0
                . .\$runScriptName -SubscriptionId $($paramObj.SubscriptionId.Trim()) -TenantId $($paramObj.tenantId.Trim()) `
                    -LogAnalyticsWorkspaceName $($paramObj.LogAnalyticsWorkspaceName.Trim()) `
                    -ServiceNowURL $($paramObj.ServiceNowURL.Trim()) `
                    -ServiceNowUser $ServiceNowUser -ServiceNowUserPwd $ServiceNowUserPwd `
                    -UpgradeFunctionCodes $($paramObj.'UpgradeFunctionCodes(Auto/Yes)'.Trim()) `
                    -UpgradeEnvVariables $($paramObj.'UpgradeEnvVariables(Auto/Yes)'.Trim()) -EA 0
     
            }
            'deployMetricAlertFunctions.ps1' {
                $dxcScriptFile = $dxcScriptFile | % { $_ -replace "-dxcstr " , "-dxcstr3 " }
                $dxcScriptFile | Set-Content .\$runScriptName -Force -EA 0
                . .\$runScriptName -SubscriptionId $($paramObj.SubscriptionId.Trim()) -TenantId $($paramObj.TenantId.Trim()) `
                    -LogAnalyticsWorkspaceName $($paramObj.LogAnalyticsWorkspaceName.Trim()) `
                    -ServiceNowURL $($paramObj.ServiceNowURL.Trim()) `
                    -keyVault $($paramObj.keyVault.Trim()) `
                    -UpgradeFunctionCodes $($paramObj.'UpgradeFunctionCodes(Auto/Yes)'.Trim()) `
                    -UpgradeEnvVariables $($paramObj.'UpgradeEnvVariables(Auto/Yes)'.Trim()) -EA 0
            }
            'deployFunctionAppAlerts.ps1' {
                $dxcScriptFile | Set-Content .\$runScriptName -Force -EA 0
                $dxcFunctionApps = Get-AzResource -ResourceType 'Microsoft.Web/sites' `
                    | ? { ($_.Name -like "dxc-*") -and ($_.ResourceGroupName -eq 'dxc-automation-rg')}
                if ($null -eq $dxcFunctionApps) { 
                    Write-Error "No DXC function app resources found." ; throw
                }
                foreach ($funcApp in $dxcFunctionApps) {
                    Write-Host "Run deployFunctionAppAlerts.ps1 - $($funcApp.Name)" -F DarkBlue
                    switch ($($paramObj.'CustomTrace(Yes/No)'.ToLower().Trim())) {
                        'yes' {
                            . .\$runScriptName -functionAppName $funcApp.Name `
                                -appInsightsName $('dxc-FuncApp-' + $funcApp.Name.Split("-")[2] + '-AI') `
                                -logAnalyticsWorkspaceName $($paramObj.LogAnalyticsWorkspaceName.Trim()) `
                                -subscriptionId $($paramObj.SubscriptionId.Trim()) `
                                -applicationName $($funcApp.Name.Split("-")[0..1] -join "-") `
                                -CustomTrace -EA 0
                        }
                        default {
                            . .\$runScriptName -functionAppName $funcApp.Name `
                                -appInsightsName $('dxc-FuncApp-' + $funcApp.Name.Split("-")[2] + '-AI') `
                                -logAnalyticsWorkspaceName $($paramObj.LogAnalyticsWorkspaceName.Trim()) `
                                -subscriptionId $($paramObj.SubscriptionId.Trim()) `
                                -applicationName $($funcApp.Name.Split("-")[0..1] -join "-") -EA 0
                        }
                    }
                    if ($error) { continue }                    
                }
            }
            'removeAlerts.ps1' {
                $dxcScriptFile | Set-Content .\$runScriptName -Force -EA 0
                . .\$runScriptName -dxcSubscriptionIDs $($paramObj.SubscriptionId.Trim())
            }
            'deploySNOWConnectionMonitoringFunctionApp.ps1' {
                $dxcScriptFile | Set-Content .\$runScriptName -Force -EA 0
                . .\$runScriptName -SubscriptionId $($paramObj.SubscriptionId.Trim()) -TenantId $($paramObj.TenantId.Trim()) `
                    -LogAnalyticsWorkspaceName $($paramObj.LogAnalyticsWorkspaceName.Trim()) `
                    -ServiceNowURL $($paramObj.ServiceNowURL.Trim()) `
                    -KeyVaultName $($paramObj.keyVault.Trim()) -EA 0
                if (!($Error.InvocationInfo.MyCommand.name -match "New-Az")) { $error.clear() }
            }
            'deploySelfHeal.ps1' {
                $dxcScriptFile = $dxcScriptFile | % { $_ -replace "#Get-Variable" , "Get-Variable" }
                $dxcScriptFile | Set-Content .\$runScriptName -Force -EA 0
                <#switch ($($paramObj.selfhealDeployMode.ToLower().Trim())) {
                    'install' {
                        . .\$runScriptName -deploymode "install" `
                            -dxcSubscriptionID $($paramObj.SubscriptionId.Trim()) `
                            -dxcLogAnalyticsWorkspaceName $($paramObj.LogAnalyticsWorkspaceName.Trim()) `
                            -dxcKeyVaultName $($paramObj.keyVault.Trim()) `
                            -dxcCustomerCompanyCode $($paramObj.LogAnalyticsWorkspaceName.Split("-")[2].Trim()) -EA 0
                    } #>
                    #'update' {
                        . .\$runScriptName -deploymode "update" `
                            -dxcSubscriptionID $($paramObj.SubscriptionId.Trim()) `
                            -dxcLogAnalyticsWorkspaceName $($paramObj.LogAnalyticsWorkspaceName.Trim()) -EA 0
                    #}
                #}
                # Proceed to execute deployAlertRule.ps1 (self-heal alert rules)
                Write-Host "Run deployAlertRule.ps1 (for self-heal alerts)" -F DarkBlue
                $selfhealAutomationAccount = Get-AzResource -ResourceType 'Microsoft.Automation/automationAccounts' -TagValue "selfheal" -EA 0
                if (($null -eq $selfhealAutomationAccount) -or ($selfhealAutomationAccount.Count -gt 1)) {
                    Write-Error "Selfheal automation account resource not found." ; throw
                }
                $deployAlertRule = Get-Content -Path .\deployAlertRule.ps1
                $deployAlertRule = $deployAlertRule | % { $_ -replace "Remove-Variable" , "#Remove-Variable" }
                $deployAlertRule | Set-Content .\run_deployAlertRule.ps1 -Force -EA 0
                . .\run_deployAlertRule.ps1 -dxcSubscriptionID $($paramObj.SubscriptionId.Trim()) `
                    -dxcLogAnalyticsWorkspaceName $($paramObj.LogAnalyticsWorkspaceName.Trim()) `
                    -dxcAutomationAccountSH $($selfhealAutomationAccount.Name.Trim()) -EA 0
            }
        }
    } catch {
        Write-Host "ERROR: Script encountered error/s and exited prematurely. Error details as follows." -F Red
        $error
    } finally {
        [System.Console]::ResetColor()
        Write-Output "Execution finished on $($paramObj.SubscriptionId) - " | timestamp | Write-Host -NoNewline -F Yellow
        Remove-Item -Path .\$runScriptName -Force -EA 0
        Write-Host "$($scriptFile.Split("\")[-1])`n" -F Yellow
    }
}
#endregion

#-----------------------------------------------------------[Execution]------------------------------------------------------------

try {

    $error.clear() ; $start = Get-Date

    # Create the log file.
    New-Item $logFilePath -ItemType File -Force | Out-Null   
    Start-Transcript -Path $logFilePath -Append -EA 0 | Out-Null
    Write-Output "INFO: Script execution started." | timestamp | Write-Host -F Yellow
	$automate = $false
	#Determine if automation call
	if ($automation.IsPresent)
	{
		$automate = $true
	}			   

    # Import modules (derived from majority of deployment scripts)
    foreach ($dxcModule in $dxcModuleList)
        {
        [String]$dxcModuleURL = "https://dxcazuretoolsdev.blob.core.windows.net/installers/DXCPowershellModules/" + $dxcModule
        [String]$dxcLocalModule = $PSScriptRoot + "\" + $dxcModule
        (New-Object System.Net.WebClient).DownloadFile($dxcModuleURL, $dxcLocalModule)
        Import-Module $dxcLocalModule -WA 0
        #Remove-Item -Path $dxcLocalModule
        }
    $dxcPSCore = Check-PSCore -Version 7.0.0
    if ($dxcPSCore) { $dxcAZ = Check-AzModule -Version 2.5.0 }
    if ($dxcAZ) { $dxcAZCli = Check-AzureCLI -Version 2.1.0 }

    # Validate file path
    if (Test-Path -Path $customerDataCsvFile) {
        $customerData = Import-Csv -Path $customerDataCsvFile -EA 0
        if ($error) {
            Write-Output "ERROR: Unable to import CSV parameter file. Please review and check for errors. Script will now exit." `
                | timestamp | Write-Host -F Red
            throw
        } else {
            $inputHeaders = $customerData[0].PSObject.Properties.Name
            if (($inputHeaders | ? -FilterScript { $_ -in $requiredHeaders}).Count -eq $inputHeaders.Count) {
                $managedScopes = $customerData.subscriptionId
                Write-Host "`nScope of deployment:" -F Yellow; $managedScopes | Out-Host
            } else {
                Write-Output "ERROR: Failed to import due to incomplete headers in input file." `
                    | timestamp | Write-Host -F Red ; exit
            }
        }
    } else {
        Write-Output "ERROR: Invalid file path for CSV parameter file. Script will now exit." | timestamp | Write-Host -F Red
        exit
    } 

    # Login to Azure
    LoginTo-Azure -tenant $customerData[0].tenantId $customerData[0].SubscriptionId $automate $custSpKey

    # Determine script/s to execute from user selection
    do {
		if ($automate -eq $true)
		{
			$runScriptsObj = $deployScriptsObj
		}
		else
		{				  
			Write-Host "`nCONFIRM: Please select which deployment scripts you want to execute. " -F Cyan
			foreach ($deployScript in $deployScriptsObj) {
				Write-Host "Enter option " -NoNewline; Write-Host "[$($deployScript.Index)]" -F Green -NoNewline; 
				Write-Host " for " -NoNewline; Write-Host $($deployScript.Name) -F Green
			}
			Write-Host "For multiple selections, type in the number/s separated by a comma (,). `nType " -NoNewline
			Write-Host "[all] " -F Green -NoNewline; Write-Host "to execute ALL scripts listed above or " -NoNewline 
			Write-Host "[quit] " -F DarkYellow -NoNewline; Write-Host "to exit deployment wrapper:" 
			$get_answer = (Read-Host).Trim()
			switch ($get_answer) {
				'all' {
					$runScriptsObj = $deployScriptsObj
				}
				'quit' { 
					Write-Host "`nScript will now exit." -F DarkYellow ;exit
				}
				default {
					$get_answer = $get_answer.split(",").Trim() | select -Unique | sort
					foreach ($answer in $get_answer) {
						$getIndex = [array]::IndexOf($deployScriptsObj.Index,[int]$answer)
						if ($getIndex -notin (0..$deployScriptsObj.count)) { continue }
						$runScriptsObj+=$deployScriptsObj[$getIndex]
					}
				}
			}
		}
    } until($runScriptsObj) 
    Write-Host "`nThe following deployment scripts were selected:" -F Yellow
    $runScriptsObj.Name | Out-Host
    $runScriptsList = $runScriptsObj.Path 

    # Process input and script execution
    foreach ($paramSet in $customerData) {
        $error.clear()
        Write-Host "`n--------------------------------------------------------------------------------------" -F Magenta
        Write-Output "INFO: Start execution of deployment scripts" | timestamp | Write-Host -F Yellow
        Write-Host "Subscription: " -NoNewline; Write-Host $($paramSet.subscriptionId) -F Cyan
        Write-Host "--------------------------------------------------------------------------------------" -F Magenta
        # Switch to target subscription
        Set-AzContext -Subscription $paramSet.subscriptionId -EA 1 -WA 0 | Out-Null
        az account set --subscription $paramSet.subscriptionId
        # Create result summary
        $resultsObj = New-Object PsObject
        $resultsObj | Add-Member -MemberType NoteProperty -Name SubscriptionId -Value $($paramSet.subscriptionId)
        # Execute each deployment script from list
        $ifNullorEmpty = Check-NullorEmpty -ifNullorEmptyObj $paramSet
        foreach ($runScript in $runScriptsList) {
            $error.clear(); [System.Console]::ResetColor()
            Set-Location -Path $scriptPath
            if ($ifNullorEmpty -eq $true) { 
                $runResult = 'Skipped'
                $resultsObj | Add-Member -MemberType NoteProperty -Name $($runScript.Split("\")[-1].Split(".")[0]) -Value $runResult
            } else {
                Run-Wrapper -paramObj $paramSet -scriptFile $runScript -EA 0
                if ($error) { $runResult = 'Completed with error/s' } else { $runResult = 'Completed' }
                $resultsObj | Add-Member -MemberType NoteProperty -Name $($runScript.Split("\")[-1].Split(".")[0]) -Value $runResult 
            }
        }
        $runResultsSummary+=$resultsObj
    }

} catch {
    
    [System.Console]::ResetColor()
    Write-Output "ERROR: Script executed with errors. $error" | timestamp | Write-Host -F Red

} finally {
    
    [System.Console]::ResetColor()
    Set-Location $scriptPath
    Write-Host "`n--------------------------------------------------------------------------------------" -F Magenta
    Write-Host "Summary of deployment scripts execution:" -F Cyan
    if ($runResultsSummary) {$runResultsSummary | fl } else {"N/A"}
    Write-Host "--------------------------------------------------------------------------------------" -F Magenta
    Write-Output "INFO: Script execution finished. Refer to log - $logFilePath" | timestamp | Write-Host -F Yellow
    Stop-Transcript -EA 0 | Out-Null ;  $end = Get-Date
    Write-Host -F DarkGray "Script duration (mins):" ([math]::Round(($end - $start).TotalMinutes,2))
    Remove-Variable * -Force -EA 0 ; $error.Clear()
}
