﻿# Azure SQL PaaS Deployment

Uptime report has been deprecated under the story AZR-11404.
This folder doesn't contain any script now.

## Authors
* Santanu Sengupta 
