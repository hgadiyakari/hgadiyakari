<#
.SYNOPSIS
Creates Application Security Groups if they do exist, then adds Network Security Group (NSG) rules to existing NSG. 
NSG rules data is in CSV format. Can support multiple NSG rules (one per line)
.DESCRIPTION
Reads a csv file (the default is ./ASG-inputData.csv ) and based on the contents of that file creates Application Security Groups if they do not exist.
Then adds rules to the Network Security Group (NSG). Can support multiple NSG rules, one rule per line.
Preconditions:
    - The Resource group to hold the ASGs must exist.
    - The NSG must exist.

.INPUTS
The csv inputFile required columns:

    sourceType        - Use ASG, in future it will support IP’s and ServiceTag
    asgRGName         - ASG Resource Group name.  Must exist
    azLoc             - Azure region
    destinationType   - Use ASG,  in future it will support IP’s and ServiceTag
    nsgRuleName       - NSG Rule name 
    nsgRuleDescription - Provide a description for the rule
    access            - Allow or Deny
    direction         - Inbound or outbound
    priority          - unique integer , decides what priority your rule should have 
    protocol          - like TCP, RDP  or use * for Any 
    source            - For now source ASG name 
    sourcePortRange   - Port or use * for any 
    destination       - For now destination ASG name
    destinationPortRange - Destination port like 443, 8080 or use * for Any
    nsgName           - Existing NSG
    nsgRGName         - NSG Resource Group Name

.NOTES
=========================================================================================================================
Required - Powershell Version 7.0 or above, AZ.Network module is required
=========================================================================================================================
AUTHOR:  Murali Gowda
DATE:    11/12/2020
Version: 0.1
=========================================================================================================================
#>
#Requires -Version 7
#Requires -Modules AZ.Network

[CmdletBinding(SupportsShouldProcess=$true)]
Param (
     [Parameter(Mandatory=$true)] [String]$TenantID         ##Tenant ID to which subscription belongs to
    ,[Parameter(Mandatory=$true)] [String]$SubscriptionID   ##Specifies the Subscription ID of Subscription where the ASG's and NSG rules gets created.
    ,[Parameter(Mandatory=$false)] [string]$inputFile = ".\ASG-inputData.csv" ##Specifies the CSV which holds the NSG rules to be added
     )
    
$ErrorActionPreference = "Stop"
$ModuleURL = "https://dxcazuretoolsdev.blob.core.windows.net/installers/DXCPowershellModules/DXCEnvCheck.psm1"
$LocalModule = $PSScriptRoot + "\DXCEnvCheck.psm1"
(New-Object System.Net.WebClient).DownloadFile($ModuleURL, $LocalModule)
Import-Module $LocalModule -WA 0
Remove-Item -Path $LocalModule
    
Check-PSVersion -dxcPSVersion 7
Check-PSModule -dxcPSModule AZ.Network -dxcPSModuleVersion "3.0"
    
function ConnectToAzure($tenant, $subname)
{
	write-host "Switching to $subname in $tenant."
	# Now Switch Subscription, and login if required.
	Try {
		$found = $false
		foreach ($cntxt in Get-AzContext -ListAvailable) {
			if ($cntxt.Tenant.ID -eq $tenant -and $cntxt.Subscription.Name -eq $subName) {
				$selectedcntxt = Select-AzContext -name $cntxt.name
				Write-Host "`n $($cntxt.name) selected"
				$found = $true
				break
			}
		}
		if (-not $found) {
			Connect-AzAccount -Tenant $tenant -SubscriptionName $subName
			$selectedcntxt = Set-AzContext -Tenant $tenant -SubscriptionName $subName
		}
	} Catch {
		$error.clear()
		Connect-AzAccount -Tenant $tenant -SubscriptionName $subName
		$selectedcntxt = Set-AzContext -Tenant $tenant -SubscriptionName $subName
    }
	return $selectedcntxt
}

if (!(ConnectToAzure  -tenant $TenantID -subname $SubscriptionID)) {
    Write-Host "ERROR: Unable to login or switch to  subscription $SubscriptionID in tenant $TenantID." -ForegroundColor Yellow
    exit
}
Write-Host "INFORMATION: Connected to Azure Subscription $SubscriptionID in tenant $TenantID" -ForegroundColor Green

#Process each line of the input file
Import-Csv $inputFile | ForEach-Object {
    $srcASG=$null
    $dstASG=$null

    $srcASG=Get-AzApplicationSecurityGroup -ResourceGroupName $_.asgRGName -Name $_.source -ErrorVariable notAva -ErrorAction SilentlyContinue
    if (-not $srcASG) {
        #Create the Source ASG 
        Try {
            $srcASG=New-AzApplicationSecurityGroup -ResourceGroupName $_.asgRGName -Name $_.source -Location $_.azLoc
        } catch {
            $Error[0]
            $msg = "Failed to create the Source ASG"
            throw $msg 
        }
        Write-host "The Source ASG : " $_.source " created" 
    }   
     
    $dstASG=Get-AzApplicationSecurityGroup -ResourceGroupName $_.asgRGName -Name $_.destination -ErrorVariable notAva -ErrorAction SilentlyContinue
    if (-not $dstASG) {
        #Create the Destination ASG 
        try {
            $dstASG=New-AzApplicationSecurityGroup -ResourceGroupName $_.asgRGName -Name $_.destination -Location $_.azLoc
        } catch {
            $Error[0]
            $msg = "Failed to create the Destination ASG"
            throw $msg
        }
        Write-host "The Destination ASG: " $_.destination " created"
    }
    
    try {
        Get-AzNetworkSecurityGroup -Name $_.nsgName -ResourceGroupName $_.nsgRGName |
        Add-AzNetworkSecurityRuleConfig -Name $_.nsgRuleName -Description $_.nsgRuleDescription `
       -Access $_.access -Protocol $_.protocol -Direction $_.direction -Priority $_.priority -SourceApplicationSecurityGroupId $srcASG.Id `
       -SourcePortRange $_.sourcePortRange -DestinationApplicationSecurityGroupId $dstASG.Id  -DestinationPortRange $_.destinationPortRange |
        Set-AzNetworkSecurityGroup
    } catch {
        $Error[0]
        throw "Failed to add rule"
    }
    
    Write-Host "Rule" $_.nsgRuleName "created in NSG" $_.nsgName
}