**Resources**

This folder contains the resources for managing resources like Azure NSG
* createAsgNsg.ps1 – This power shell script deploys Application Security Group (ASG if not exists and add Network Security Group (NSG) rule with ASG’s to an existing NSG
* ASG-inputData.csv file that is used to provide NSG rule data.

**Note: _The ASG-inputData.csv is an example file to illustration purpose only. Make sure you delete the example data and add the project related data_** 

**Running the script**
Add the NSG rule data that needs to be added to existing NSG in the ASG-inputData.csv file. Note file includes a sample data record for reference, that should be deleted. Here is brief description of data 

* sourceType – Use ASG, in future it will support IP’s and ServiceTag
* asgRGName – ASG Resource Group name 
* azLoc – Azure region
* destinationType - Use ASG,  in future it will support IP’s and ServiceTag
* nsgRuleName – NSG Rule name 
* nsgRuleDescription – Provide a description for the rule
* access – Allow or Deny
* direction – Inbound or outbound
* priority – unique integer , decides what priority your rule should have 
* protocol – like TCP, RDP  or use * for Any 
* source – For now source ASG name 
* sourcePortRange – Port or use * for any 
* destination – For now destination ASG name
* destinationPortRange – Destination port like 443, 8080 or use * for Any
* nsgName – Existing NSG 
* nsgRGName – NSG Resource Group Name 

Refer here for more info [https://docs.microsoft.com/en-us/powershell/module/az.network/add-aznetworksecurityruleconfig?view=azps-5.0.0]

**Help on script**
Run  `help ./createAsgNsg.ps1`  to get details

**Run the Script**
Open Powershell 7 and go to script & data file folder

Run the script by providing Tenant ID and Subscription ID
`./createAsgNsg.ps1 -T <Tenant ID> -S <Sub Subscription ID> `

Or just run the script 
`./createAsgNsg.ps1 `
Provide tenant ID & Subscription Id when prompted.

After successful run go to Azure portal and verify the creation of ASG’s and NSG rule .
