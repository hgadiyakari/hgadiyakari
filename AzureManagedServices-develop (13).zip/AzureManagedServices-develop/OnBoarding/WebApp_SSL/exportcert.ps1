## This script exports an SSL Cert from Azure KeyVault as an PFX file with no password. 
## The PFX file will be placed in the root profile directory of the user running the script (e.g. C:\users\jdoe\webappcert.pfx)

#Create Variable for, Subscription ID, VaultName and Name of Certificate.


[CmdletBinding(SupportsShouldProcess=$true)]
Param(
    [Parameter(Mandatory=$true)] [String]$SubID,
    [Parameter(Mandatory=$true)] [String]$vaultName,
    [Parameter(Mandatory=$true)] [String]$Name
 

)

Connect-AzAccount -Subscription $SubID

$cert = Get-AzKeyVaultCertificate -VaultName $vaultName -Name $Name
$secret = Get-AzKeyVaultSecret -VaultName $vaultName -Name $cert.Name
$secretValueText = '';
$ssPtr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($secret.SecretValue)
try {
    $secretValueText = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($ssPtr)
} finally {
    [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ssPtr)
}
$secretByte = [Convert]::FromBase64String($secretValueText)
$x509Cert = new-object System.Security.Cryptography.X509Certificates.X509Certificate2
$x509Cert.Import($secretByte, "", "Exportable,PersistKeySet")
$type = [System.Security.Cryptography.X509Certificates.X509ContentType]::Pfx
$pfxFileByte = $x509Cert.Export($type, $password)

# Write to a file
[System.IO.File]::WriteAllBytes("webappcert.pfx", $pfxFileByte)