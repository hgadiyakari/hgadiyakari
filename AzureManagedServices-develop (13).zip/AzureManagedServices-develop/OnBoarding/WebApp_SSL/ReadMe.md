# WebApp_SSL Directory

This folder contains Scripts for adding Password protected SSL certificate to Web App. 
  
## Jira Epic
https://jira.dxc.com/browse/AZR-3655

## Jira Spike
https://jira.dxc.com/browse/AZR-15038

## Jira Story
https://jira.dxc.com/browse/AZR-17680

## Operations Guide
Section 3.53.4

## This script uploads an SSL Cert to Azure Webapp 

## Provide input to the following parameters: 
# Subscription ID, Resource Group where WebApp resides, WebAppName, FQDN of WebApp, Full PFX path where the file located with name and extension and certificate password

 
## Deployment Instructions
All Parameters are mandatory fields.

execution - .\webappcert.ps1

#Requirements:

Subscription ID				:	""
Resource Group				:	""
Name of Web App				:	""
FQDN of Web App				:	""
PFX Path					:	path where file exists with extension "C:\dxcappcert.pfx""
Password for pfx file		:	""
