## This script uploads an SSL Cert to Azure Webapp 

## Provide input to the following parameters: 
# Subscription ID, Resource Group where WebApp resides, WebAppName, FQDN of WebApp, Full PFX path where the file located with name and extension and certificate password

[CmdletBinding(SupportsShouldProcess=$true)]
Param(
    [Parameter(Mandatory=$true)] [String]$SubId,
    [Parameter(Mandatory=$true)] [String]$RG,
    [Parameter(Mandatory=$true)] [String]$WebApp,
    [Parameter(Mandatory=$true)] [String]$FQDN,
    [Parameter(Mandatory=$true)] [String]$PFXPath,
    [Parameter(Mandatory=$true)] [String]$CertPassword
)

Connect-AzAccount -Subscription $SubID

New-AzWebAppSSLBinding -WebAppName $WebApp -ResourceGroupName $RG -Name $FQDN -CertificateFilePath $PFXPath -CertificatePassword $CertPassword -SslState SniEnabled