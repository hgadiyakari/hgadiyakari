<#
=========================================================================================================================
Required - Powershell Version 7.1, AZ Modules
=========================================================================================================================
AUTHOR:  Harika Gadiyakari
DATE:    23/07/2021
Version: 1.0
=========================================================================================================================
.SYNOPSIS
   Onboards Azure Defender on given subscription
.DESCRIPTION
    .PARAMETER  dxcSubscriptionID
		Specifies the Subscription ID of Subscription on which Azure Defender is enabled.
    .PARAMETER  LogAnalyticsWorkspaceResourceID
		Specifies Log Analytic Workspace to which the Log Analytics agent will send the data it collects on the VMs associated with the subscription
#>
[CmdletBinding(SupportsShouldProcess=$true)]
Param
    (
    [Parameter(Mandatory=$true)] [String]$dxcSubscriptionID,
    [Parameter(Mandatory=$true)] [String]$LogAnalyticsWorkspaceResourceID

    )

#====================================================================================================================
# Variable Declaration
#====================================================================================================================
$subID = "/subscriptions/$dxcSubscriptionID"
#=====================================================================================================================
# IMPORTCUSTOM MODULES AND CHECK ENVIRONMENT FOR NECESSERY MODULES
#=====================================================================================================================
$dxcModuleList = "DXCEnvCheckV2.psm1", "DXCUtilityFunctions.psm1", "DXCDeploymentFunctions.psm1"
foreach ($dxcModule in $dxcModuleList)
    {
    [String]$dxcModuleURL = "https://dxcazuretoolsdev.blob.core.windows.net/installers/DXCPowershellModules/" + $dxcModule
    [String]$dxcLocalModule = $PSScriptRoot + "\" + $dxcModule
    (New-Object System.Net.WebClient).DownloadFile($dxcModuleURL, $dxcLocalModule)
    Import-Module $dxcLocalModule -WA 0
    Remove-Item -Path $dxcLocalModule
    }
$dxcPSCore = Check-PSCore -Version 7.0.0
if ($dxcPSCore) { $dxcAZ = Check-AzModule -Version 2.5.0 }
if ($dxcAZ) { $dxcAZCli = Check-AzureCLI -Version 2.1.0 }
if ($dxcAZCli) { $dxcAZStorage = Check-PSModule -Name "Az.Storage" -Version 1.5.1 }
if ($dxcAZStorage) { $dxcAZMonitor = Check-PSModule -Name "Az.Monitor" -Version 1.5.0 }
if($dxcAZMonitor){$dxcAZSecurity = Check-PSModule -Name "Az.Security" -Version 1.0.0 }
if (!$dxcAZSecurity)
    {
    Read-Host "`nPress 'ENTER'to exit the script........"
    exit
    }

#=====================================================================================================================
# LOGIN SECTION
#=====================================================================================================================
$error.Clear()

# If SubscriptionID provided, prompt for ARM Login
    if($dxcSubscriptionID)
    {
    Write-Host "`nINFORMATION: Please login to Azure Resource Manager." -ForegroundColor Green
    Connect-AzAccount
 
    if ($error) 
        { 
        Write-Host "WARNING:     Unable to connect to Azure. Check your internet connection and verify authentication details." -ForegroundColor Yellow
        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        exit 
        $error.Clear()
        }
    Write-Host "INFORMATION: Connected to Azure with provided authentication." -ForegroundColor Green 

    Set-AzContext -Subscription $dxcSubscriptionID

    if ($error) 
        { 
        Write-Host "WARNING:     Invalid Subscription ID. Please make sure you have proper access to this Azure Subscription and your Subscription ID is correct. " -ForegroundColor Yellow 
        Write-Host "             Run the Powershell Command: " -ForegroundColor Yellow -NoNewLine 
        Write-Host "Connect-AzAccount -Subscription $dxcSubscriptionID " -NoNewLine
        Write-Host "and login with your authentication details." -ForegroundColor Yellow
        Write-Host "             If you get error, you have access issues with the subscription." -ForegroundColor Yellow

        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        exit 
        }
    Write-Host "INFORMATION: Connected to Azure Subscription " -NoNewline -ForegroundColor Green
    Write-Host $dxcSubscriptionID -NoNewline
    Write-Host " with provided authentication." -ForegroundColor Green 
    }

    #Allow Execution Policy
    Write-Host "Setting execution policy to Allsigned"
    Set-ExecutionPolicy -ExecutionPolicy AllSigned


    #Onboarding Security Center
    Write-Host "Onboarding Security Center" -ForegroundColor Green
    Register-AzResourceProvider -ProviderNamespace 'Microsoft.Security'

    #Seting the Azure Defender on of the subscriptions.
    Write-Host "Seting the Azure Defender on $dxcSubscriptionID for VirtualMachines" -ForegroundColor Green
    Set-AzSecurityPricing -Name "virtualmachines" -PricingTier "Standard"

    #Configuring a Log Analytics workspace to which the agents will report
    write-host "Configuring a Log Analytics workspace" -ForegroundColor Green
    Set-AzSecurityWorkspaceSetting -Name "default" -Scope $subID -WorkspaceId $LogAnalyticsWorkspaceResourceID

    #Auto-provision installation of the Log Analytics agent on your Azure VMs
    write-host "Enabling AutoProvision installation of the Log Analytics agent on your Azure VMs" -ForegroundColor Green
    Set-AzSecurityAutoProvisioningSetting -Name "default" -EnableAutoProvision

    Write-Host "Successfully onboarded Azure Azure Defender on subscription: $dxcSubscriptionID " -ForegroundColor Green

