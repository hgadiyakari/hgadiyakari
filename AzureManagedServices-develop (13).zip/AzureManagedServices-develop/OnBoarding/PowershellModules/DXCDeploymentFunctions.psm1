$apiVersion = "2017-01-01-preview"
<#=========================================================================================================================
AUTHOR:  Santanu Sengupta 
DATE:    27/07/2020
Version: 2.0
Details: Module to import all the Azure Resource Deployment functions necessery for DXC Azure Offering Powershell Scripts.	
========================================================================================================================#>

#========================================================================================================================
#FUNCTION TO DEPLOY AZURE RESOURCEGROUP
#========================================================================================================================
Function Deploy-ResourceGroup
    {
    Param([String]$Location, [String]$Name)

    $ErrorActionPreference = "SilentlyContinue"
    $WarningPreference = "SilentlyContinue"
    Write-Host ""
    $objRG = Get-AzResourceGroup -Name $Name -ErrorVariable notPresent -EA 0

    if ($objRG) 
        { 
        [bool]$RGExists = $true
        Utility-DisplayInfo -dxcstr1 "INFORMATION: ResourceGroup" -dxcstr2 $Name -dxcstr3 "exist in the subscription. Skipping ResourceGroup deployment."
        }
    else
        {
        [bool]$RGExists = $false
        Utility-DisplayInfo -dxcstr1 "INFORMATION: ResourceGroup" -dxcstr2 $Name -dxcstr3 "doesn't exist, Deploying.... "
        $objRG = New-AzResourceGroup -Name $Name -Location $Location -EA 0

        if ($objRG.count -eq 1) { Write-Host "INFORMATION: ResourceGroup deployed successfully." -NoNewLine -ForegroundColor Green }
        else { Utility-DisplayWarning -dxcstr1 "WARNING:     Unable to deploy ResourceRroup" -dxcstr2 $Name -dxcstr3 ". Script will exit now." }
        }
    return $RGExists, $objRG
    }

#========================================================================================================================
#FUNCTION TO DEPLOY AZURE STORAGE ACCOUNT
#========================================================================================================================
Function Deploy-StorageAccount
    {
    Param([String]$Location, [String]$ResourceGroupName, [String]$Name, [String]$Container, [String]$Table, [String]$Queue, $Blobfiles)

    $ErrorActionPreference = "SilentlyContinue"
    $WarningPreference = "SilentlyContinue"
    Write-Host ""

    #Storage Account Creation
    $ObjStorage = Get-AzStorageAccount -ResourceGroupName $ResourceGroupName -Name $Name -ErrorVariable notPresent -EA 0

    if ($ObjStorage) 
        { 
        [bool]$StorageAccountExists = $true
        Utility-DisplayInfo -dxcstr1 "INFORMATION: Storage Account named" -dxcstr2 $Name -dxcstr3 "already present in the resource group. Skipping Storage Account deployment." 
        }
    else
        {
        [bool]$StorageAccountExists = $false
        Utility-DisplayInfo -dxcstr1 "INFORMATION: Creating storage Account with name" -dxcstr2 $Name  
        $error.Clear()
        $ObjStorage = New-AzStorageAccount -ResourceGroupName $ResourceGroupName -AccountName $Name -Location $Location -SkuName Standard_LRS -Kind StorageV2 -EnableHttpsTrafficOnly $true

        if ($error) 
            { 
            Write-Host "WARNING:     Unable to Create Storage Account. Script will exit now." -ForegroundColor Yellow
            $Blobfiles = "None" 
            }
        else
            {
            Utility-DisplayInfo -dxcstr1 "INFORMATION: Storage account named" -dxcstr2 $Name -dxcstr3 "created successfully." 

            #Creating Storage Table
            If ($Table -ne "None")
                {
                Utility-DisplayInfo -dxcstr1 "INFORMATION: Creating" -dxcstr2 $Table -dxcstr3 "storage Table...."
                $error.Clear()
                New-AzStorageTable -Name $Table -Context $ObjStorage.Context >$null

                if ($error) { Utility-DisplayWarning -dxcstr1 "WARNING:     Unable to Create" -dxcstr2 $Table -dxcstr3 "storage Table. It can be manually created later." }
                else { Write-Host 'INFORMATION: Storage Table created successfully.' -ForegroundColor Green }
                }

            #Creating Storage Queue
            If ($Queue -ne "None")
                {
                Utility-DisplayInfo -dxcstr1 "INFORMATION: Creating" -dxcstr2 $Queue -dxcstr3 "storage Table...."
                $error.Clear()
                New-AzStorageQueue -Name $Queue -Context $ObjStorage.Context >$null

                if ($error) { Utility-DisplayWarning -dxcstr1 "WARNING:     Unable to Create" -dxcstr2 $Queue -dxcstr3 "storage Queue. It can be manually created later." }
                else { Write-Host 'INFORMATION: Storage Queue created successfully.' -ForegroundColor Green }
                }

            #Creating Storage Container
            If ($Container -ne "None")
                {
                $Container = $Container.tolower()
                Utility-DisplayInfo -dxcstr1 "INFORMATION: Creating" -dxcstr2 $Container -dxcstr3 "storage Container...."
                $error.Clear()
                New-AzStorageContainer -Name "metric-alerts" -Context $ObjStorage.Context -Permission Off >$null

                if ($error) 
                    { 
                    Utility-DisplayWarning -dxcstr1 "WARNING:     Unable to Create" -dxcstr2 $Container -dxcstr3 "storage container. Script will exit now."
                    $ObjStorage = $null
                    }
                Else { Write-Host "INFORMATION: Storage Container created successfully." -ForegroundColor Green }
                }
            }
        }
    
    If ($Blobfiles -ne "None")
        {
        ForEach ($blobfile in $blobfiles)
            {
            Utility-DisplayInfo -dxcstr1 "INFORMATION: Uploading alert file" -dxcstr2 $blobfile.Split("\")[-1]
            $error.Clear()
            Set-AzStorageBlobContent -File $blobfile -Container $Container -Context $ObjStorage.Context -Force >$null
                    
            if ($error) { Write-Host 'WARNING:     Unable to upload alert files. These can be manually uploaded later with Microsoft Storage Explorer.' -ForegroundColor Yellow; Break }
            }
        }
    
    return $StorageAccountExists, $ObjStorage
    }

#========================================================================================================================
#FUNCTION TO DEPLOY AZURE FUNCTIONAPP
#========================================================================================================================
Function Deploy-FunctionApp
    {
    Param(
        [Parameter(Mandatory=$true)] [String]$SubscriptionId,
        [Parameter(Mandatory=$true)] [String]$Location,
        [Parameter(Mandatory=$true)] [String]$ResourceGroupName,
        [Parameter(Mandatory=$true)] [String]$Name,
        [Parameter(Mandatory=$true)] [String]$StorageAccountName,
        [Parameter(Mandatory=$true)] [String]$AppServicePlanName,
        [Parameter(Mandatory=$true)] [String]$Sku,
        [Parameter(Mandatory=$true)] [String]$AppInsights,
        [Parameter(Mandatory=$true)] [String]$OSType,
        [Parameter(Mandatory=$true)] [String]$Runtime,
        [Parameter(Mandatory=$true)] [Int]$FunctionVersion,
        [Parameter(Mandatory=$false)][Switch]$AlwaysON
        )

    $ErrorActionPreference = "SilentlyContinue"
    $WarningPreference = "SilentlyContinue"
    Write-Host ""

    $ObjFunctionApp = az functionapp show --name $Name --resource-group $ResourceGroupName | ConvertFrom-Json

    if ($ObjFunctionApp) 
        {
        [bool]$FunctionAppExists = $true 
        Utility-DisplayInfo -dxcstr1 "INFORMATION: FunctionApp named" -dxcstr2 $Name -dxcstr3 "already present. Skipping FunctionApp deployment." 
        }
    else
        {
        [bool]$FunctionAppExists = $false

        #Check and Create AppServicePlan
		Write-Host ""
        $Succeded = az functionapp plan show --name $AppServicePlanName --resource-group $ResourceGroupName | ConvertFrom-Json
        
        if ($Succeded) 
            { Utility-DisplayInfo -dxcstr1 "INFORMATION: AppServicePlan named" -dxcstr2 $AppServicePlanName -dxcstr3 "located in the resource group" -dxcstr4 $ResourceGroupName }
        else
            { 
             Write-Host "INFORMATION: Creating App Service Plan...." -ForegroundColor Green
             $Succeded = az functionapp plan create --name $AppServicePlanName --resource-group $ResourceGroupName --location $Location --sku $Sku | ConvertFrom-Json
  
            if ($Succeded) { Utility-DisplayInfo -dxcstr1 "INFORMATION: AppServicePlan named" -dxcstr2 $AppServicePlanName -dxcstr3 "created successfully." }
            else   
                { 
                Write-Host "WARNING:     Unable to Create AppServicePlan. Script will exit now." -ForegroundColor Yellow 
                return $FunctionAppExists, $null
                }
            }
        
        #Check and Create Application Insights
		Write-Host ""
        $dxcOBJAI = Get-AzApplicationInsights -ResourceGroupName $ResourceGroupName -Name $AppInsights
        
        if ($dxcOBJAI) { Utility-DisplayInfo -dxcstr1 "INFORMATION: Application Insight named" -dxcstr2 $AppInsights -dxcstr3 "located in the resource group" -dxcstr4 $ResourceGroupName }
        else    
            { 
            Utility-DisplayInfo -dxcstr1 "INFORMATION: Application Insight named" -dxcstr2 $AppInsights -dxcstr3 "doesn't exist, deploying..."
            $error.Clear()
            $dxcOBJAI = New-AzApplicationInsights -ResourceGroupName $ResourceGroupName -Name $AppInsights -location $Location
            if ($dxcOBJAI) { Utility-DisplayInfo -dxcstr1 "INFORMATION: Application Insights named" -dxcstr2 $AppInsights -dxcstr3 "created successfully." }
            else    
                { 
                Write-Host "WARNING:     Unable to Create Application Insight. Script will exit now." -ForegroundColor Yellow 
                return $FunctionAppExists, $null
                }
            }
        Write-Host "INFORMATION runtime: " $Runtime
        
        #Create Function App        
        Write-Host "`nINFORMATION: Creating FunctionApp...." -ForegroundColor Green
        $FunctionAppSettings = @{
            ServerFarmId="/subscriptions/$SubscriptionId/resourceGroups/$ResourceGroupName/providers/Microsoft.Web/serverfarms/$AppServicePlanName";
            httpsOnly=$True;
            }
        #Provision the function app service
        $ObjFunctionApp = New-AzResource -ResourceGroupName $ResourceGroupName -Location $Location -ResourceName $Name -Properties $FunctionAppSettings -ResourceType "microsoft.web/sites" -Kind "functionapp"  -Force
        $dxcObjFunctionApp = Get-AzFunctionApp -ResourceGroupName $ResourceGroupName -Name $Name
        if ($ObjFunctionApp) 
            {
            Utility-DisplayInfo -dxcstr1 "INFORMATION: FunctionApp named" -dxcstr2 $Name -dxcstr3 "created successfully."

            If ($AlwaysON)
                {
                Write-Host "INFORMATION: Pushing 'Always On' setting to FunctionApp...." -ForegroundColor Green
                $Succeded = $null
                $Succeded = az functionapp config set --always-on true --name $Name --resource-group $ResourceGroupName | ConvertFrom-Json
                
                if ($Succeded) { Write-Host "INFORMATION: 'Always On' is set to TRUE for the FunctionApp." -ForegroundColor Green }
                else { Write-Host "WARNING:     Unable to Set 'Always On' to TRUE. You need to set it manually after the deployment." -ForegroundColor Yellow }
                }
            }
        else { Write-Host "WARNING:     Unable to Create FunctionApp. Script will exit now." -ForegroundColor Yellow }
        }
    return $FunctionAppExists, $ObjFunctionApp
    }

#========================================================================================================================
#FUNCTION TO DEPLOY AZURE CONSUMPTION APPSERVICE PLAN
#========================================================================================================================
function deploy-ConsumptionAppServicePlan(
    [Parameter(Mandatory = $true)] [String]$AppServicePlanName,
    [Parameter(Mandatory = $true)] [String]$ResourceGroupName,
    [Parameter(Mandatory = $true)] [String]$Location 
    )
    {
	$ErrorActionPreference = "SilentlyContinue"
    $WarningPreference = "SilentlyContinue"
    Write-Host ""
    $SkuName = "Y1"
    $SkuTier = "Dynamic"
    $WebAppApiVersion = "2015-08-01"
    $FullObject = @{
                    location = $Location
                    sku = @{
                            name = $SkuName
                            tier = $SkuTier
                           }
                   }

    Utility-DisplayInfo -dxcstr1 "INFORMATION: Checking whether the AppServicePlan:" -dxcstr2 $AppServicePlanName -dxcstr3 "already exists."
    $ObjAppServicePlan = Get-AzAppServicePlan -Name $appServicePlanName -ResourceGroupName $ResourceGroupName -ErrorAction SilentlyContinue

    if($ObjAppServicePlan) 
        { Utility-DisplayInfo -dxcstr1 "INFORMATION: AppServicePlan:" -dxcstr2 $AppServicePlanName -dxcstr3 "already exists." }
    else
        {
        Utility-DisplayInfo -dxcstr1 "INFORMATION: AppServicePlan:" -dxcstr2 $AppServicePlanName -dxcstr3 "doesn't exist, deploying..."
        $error.clear()
        $ObjAppServicePlan = New-AzResource -ResourceGroupName $ResourceGroupName -ResourceType "Microsoft.Web/serverfarms" -Name $AppServicePlanName -IsFullObject -PropertyObject $FullObject -ApiVersion $WebAppApiVersion -Force

        if ($ObjAppServicePlan) { Utility-DisplayInfo -dxcstr1 "INFORMATION: AppServicePlan:" -dxcstr2 $AppServicePlanName -dxcstr3 "created successfully." }
        else
            { 
            Utility-DisplayWarning -dxcstr1 "WARNING:     Failed to Create AppServicePlan:" -dxcstr2 $AppServicePlanName -dxcstr3 ". Script will exit now."
            $ObjAppServicePlan = $null       
            }
        }
    return $ObjAppServicePlan
    }


#========================================================================================================================
#FUNCTION TO DEPLOY AZURE APPLICATION INSIGHTS
#========================================================================================================================
function deploy-AppInsights(
    [Parameter(Mandatory = $true)] [String]$AppInsightsName,
    [Parameter(Mandatory = $true)] [String]$ResourceGroupName,
    [Parameter(Mandatory = $true)] [String]$Location 
    )
    {
	$ErrorActionPreference = "SilentlyContinue"
    $WarningPreference = "SilentlyContinue"

    Write-Host ""
	Utility-DisplayInfo -dxcstr1 "INFORMATION: Checking whether the ApplicationInsights:" -dxcstr2 $AppInsightsName -dxcstr3 "already exists."
    $OBJAI = Get-AzApplicationInsights -ResourceGroupName $ResourceGroupName -Name $AppInsightsName
        
    if ($OBJAI) { Utility-DisplayInfo -dxcstr1 "INFORMATION: Application Insight named" -dxcstr2 $AppInsightsName -dxcstr3 "located in the resource group" -dxcstr4 $ResourceGroupName }
    else    
        { 
        Utility-DisplayInfo -dxcstr1 "INFORMATION: Application Insight named" -dxcstr2 $AppInsightsName -dxcstr3 "doesn't exist, deploying..."
        $OBJAI = New-AzApplicationInsights -ResourceGroupName $ResourceGroupName -Name $AppInsightsName -location $Location -ErrorAction SilentlyContinue
        
        if ($OBJAI) { Utility-DisplayInfo -dxcstr1 "INFORMATION: Application Insights named" -dxcstr2 $AppInsightsName -dxcstr3 "created successfully." }
        else    
            { 
            Write-Host "WARNING:     Unable to Create Application Insight. Script will exit now." -ForegroundColor Yellow 
            $OBJAI = $null
            }
        }
    return $OBJAI
    }

#========================================================================================================================
#FUNCTION TO DEPLOY AZURE FUNCTIONAPP ON CONSUMPTION APPSERVICEPLAN
#========================================================================================================================

function deploy-FunctionAppOnConsumptionPlan(
    [Parameter(Mandatory = $true)] [String]$FunctionAppName,
    [Parameter(Mandatory = $true)] [String]$ResourceGroupName,
    [Parameter(Mandatory = $true)] [String]$Location, 
    [Parameter(Mandatory = $true)] [String]$AppInsightsName,
    [Parameter(Mandatory = $true)] [String]$ConsumptionPlanName,
    [Parameter(Mandatory = $true)] [String]$StorageAccountName
    )
    {
	$ErrorActionPreference = "SilentlyContinue"
    $WarningPreference = "SilentlyContinue"
    Write-Host ""
    [string]$dxcFunctionAppJSON = "https://dxcazuretoolsdev.blob.core.windows.net/installers/JSON/FunctionApp/deployFunctionAppOnConsumptionPlan.json"
    [String]$dxcObjFunctionApp = New-AzResourceGroupDeployment -Name "FunctionAppDeployment" -ResourceGroupName $ResourceGroupName -TemplateURI $dxcFunctionAppJSON -storageAccountName $StorageAccountName -appInsightsName $AppInsightsName -hostingPlanName $ConsumptionPlanName -funcAppName $FunctionAppName -location $Location

    if ($dxcObjFunctionApp) 
        { 
        Utility-DisplayInfo -dxcstr1 "INFORMATION: FunctionApp named" -dxcstr2 $FunctionAppName -dxcstr3 "deployed successfully." 
        $dxcFunctionAppResourceId = (Get-AzResource -ResourceGroupName $ResourceGroupName -ResourceType "Microsoft.Web/sites" -Name $FunctionAppName).Id
        }
    else    
        { 
        Write-Host "WARNING:     Failed to deploy FunctionApp. Script will exit now." -ForegroundColor Yellow 
        $dxcFunctionAppResourceId = $null
        }
    return $dxcFunctionAppResourceId
    }

#========================================================================================================================
#FUNCTION TO HARDEN AZURE FUNCTIONAPP SECURITY
#========================================================================================================================

function deploy-FunctionAppSecurity(
    [Parameter(Mandatory = $true)]  [String]$FunctionAppName,
    [Parameter(Mandatory = $true)]  [String]$ResourceGroupName,
    [Parameter(Mandatory = $true)]  [String]$Location, 
    [Parameter(Mandatory = $false)] [Switch]$AppServiceAuthOn,
    [Parameter(Mandatory = $false)] [Switch]$HTTPSOnly,
    [Parameter(Mandatory = $false)] [Switch]$HTTP20Enabled,
    [Parameter(Mandatory = $false)] [Switch]$FTPDisabled
    )
    {
	$ErrorActionPreference = "SilentlyContinue"
    $WarningPreference = "SilentlyContinue"
    [String]$dxcWebResource = $FunctionAppName + "/web"
    [String]$dxcAuthResource = $FunctionAppName + "/authsettings"

    $dxcAuthSettings =    @{
                            "enabled" = "True";
                            "unauthenticatedClientAction" = "1";
                            "defaultProvider" = "0";
                            "tokenStoreEnabled" = "False";
                           }

    If ($HTTP20Enabled) { $dxcWebSecuritySettings = @{ "http20Enabled" = "True"; } }
    If ($FTPDisabled)   { $dxcWebSecuritySettings = @{ "ftpsState"="Disabled";   } }
    If ($HTTP20Enabled -and $FTPDisabled)
        {
        $dxcWebSecuritySettings = @{ 
                                    "http20Enabled" = "True";
                                    "ftpsState"="Disabled";
                                   }
        }

    $error.Clear()
	Write-Host "`nINFORMATION: Applying security settings for the Function App..." -ForegroundColor Green

	#If ($httpsOnly) { $dxcOutput = az functionapp update  --name $FunctionAppName --resource-group $ResourceGroupName --set httpsOnly=true }
	If ($AppServiceAuthOn) { New-AzResource -PropertyObject $dxcAuthSettings -ResourceGroupName $ResourceGroupName -ResourceType "Microsoft.Web/sites/config" -ResourceName $dxcAuthResource -ApiVersion 2015-08-01 -Force >$null}
	If ($HTTP20Enabled -or $FTPDisabled) { New-AzResource -PropertyObject $dxcWebSecuritySettings -ResourceGroupName $ResourceGroupName -ResourceType "Microsoft.Web/sites/config" -ResourceName $dxcWebResource -ApiVersion 2015-08-01 -Force >$null }

	If ($error) 
    	{
    	Write-Host "WARNING:     Failed to deploy some or all the security settngs, follow the below Wiki document to set the security settings manually if rest of the deployment is successfull." -ForegroundColor Yellow
    	Write-Host "             https://confluence.dxc.com/pages/viewpage.action?pageId=207312130"
    	}
	else { Write-Host "INFORMATION: Security settings implemented successfully." -ForegroundColor Green }
	}
#========================================================================================================================
Export-ModuleMember -Function 'Deploy-*'
