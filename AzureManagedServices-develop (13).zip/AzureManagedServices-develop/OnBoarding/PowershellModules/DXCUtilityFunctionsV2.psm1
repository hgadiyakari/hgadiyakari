﻿$apiVersion = "2017-01-01-preview"
<#=========================================================================================================================
AUTHOR:  Santanu Sengupta 
DATE:    27/03/2020
Version: 1.0
Details: Module to import all the utility functions necessery for DXC Azure Offering Powershell Scripts.	

AUTHOR:  Bang Bui
DATE:    11/05/2020
Version: 2.1
Details: Hotfix for Release 2.5 BUG AZR-16638
          Added Utility-LoginAZ-V2 which is called by "deployMetricAlertFunctions.ps1"

#========================================================================================================================#>
# FUNCTION TO DISPLAY INFORMATIONAL MESSAGE
#========================================================================================================================
Function Utility-DisplayInfo
    {
    Param($dxcstr1, $dxcstr2, $dxcstr3, $dxcstr4)
 
        Write-Host $dxcstr1" " -NoNewline -ForegroundColor Green
        Write-Host $dxcstr2" " -NoNewline
        Write-Host $dxcstr3" " -NoNewline -ForegroundColor Green
        Write-Host $dxcstr4" "
    }

#========================================================================================================================
# FUNCTION TO DISPLAY WARNING MESSAGE
#========================================================================================================================
Function Utility-DisplayWarning
    {
    Param($dxcstr1, $dxcstr2, $dxcstr3, $dxcstr4)
 
        Write-Host $dxcstr1" " -NoNewline -ForegroundColor yellow
        Write-Host $dxcstr2" " -NoNewline
        Write-Host $dxcstr3" " -NoNewline -ForegroundColor yellow
        Write-Host $dxcstr4" "
    }

#========================================================================================================================
# FUNCTION TO LOGIN WITH az
#========================================================================================================================
Function Utility-LoginAZ
    {
    Param ($dxcSubscriptionId)

    Set-AzContext -Subscription $dxcSubscriptionID -EA 0 -WA 0 -ErrorVariable setAzContextError >$null

    if ($setAzContextError) 
        { 
        $error.Clear()
        Write-Host "`nINFORMATION: Please login to Azure Resource Manager." -ForegroundColor Green
        Connect-AzAccount -WarningAction:Continue >$null
 
        if ($error) 
            { 
            Write-Host "WARNING:     Unable to connect to Azure. Check your Internet connection and verify authentication details." -ForegroundColor Yellow
            Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
            Read-Host "`nPress 'ENTER'to exit the script........"
            exit
            }
        Write-Host "INFORMATION: Connected to Azure with provided authentication." -ForegroundColor Green 

        Set-AzContext -Subscription $dxcSubscriptionID -EA 0 -WA 0 >$null
        if ($error) 
            { 
            Write-Host "WARNING:     Invalid Subscription ID. Please make sure you have proper access to this Azure Subscription." -ForegroundColor Yellow 
            Utility-DisplayWarning -dxcstr1 "             Run the Powershell Command:" -dxcstr2 "Login-AzAccount -Subscription $dxcSubscriptionID" -dxcstr3 "and login with your authentication details."
            Write-Host "             If you get error, you have access issues with the subscription." -ForegroundColor Yellow
            
            Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
            Read-Host "`nPress 'ENTER'to exit the script........"
            exit 
            }
        }
        Utility-DisplayInfo -dxcstr1 "INFORMATION: Connected to Azure Subscription" -dxcstr2 $dxcSubscriptionID -dxcstr3 "with provided authentication."
    }

#========================================================================================================================
# FUNCTION TO LOGIN WITH AZURE CLI
#========================================================================================================================
Function Utility-LoginAureCli
    {
    Param ($dxcSubscriptionId)

    Write-Host "`nINFORMATION: Please login to Azure with Azure CLI." -ForegroundColor Green
    $dxcOutput = az login --use-device-code | ConvertFrom-Json

    if (!$dxcOutput)  
        { 
        Write-Host "WARNING:     Unable to Login to Azure Subscription with Azure CLI." -ForegroundColor Yellow
        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        Read-Host "`nPress 'ENTER'to exit the script........"
        exit
        }
    az account set --subscription $dxcSubscriptionID
    Write-Host "INFORMATION: Connected to Azure with Azure CLI." -ForegroundColor Green	
    }

#========================================================================================================================
# FUNCTION TO GENERATE UNIQUE ID
#========================================================================================================================
Function Utility-GeneratingUniqueID
    {
    Param ($dxcResourceGroupName)
    [string]$dxctempJSON = "https://dxcazuretoolsdev.blob.core.windows.net/forautomation/UniqueStringGenerator.json"

    Write-Host "`nINFORMATION: Generating unique Id..." -ForegroundColor Green
    [String]$dxcRandom = (New-AzResourceGroupDeployment -Name "GeneratingUniqueID" -ResourceGroupName $dxcResourceGroupName -TemplateURI $dxctempJSON).Outputs.Values.value

    Utility-DisplayInfo -dxcstr1 "INFORMATION: Uniqie Id" -dxcstr2 $dxcRandom -dxcstr3 "generated."
    Return $dxcRandom
    }

#========================================================================================================================
Export-ModuleMember -Function 'Utility-*'
