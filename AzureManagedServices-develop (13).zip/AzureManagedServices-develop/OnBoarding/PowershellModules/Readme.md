﻿#Powershell Modules

This folder contains the PSM files that are used to import all of the needed powershell modules utilized by DXC Azure

## Jira Epic
N/A

## Deployment
For more information on how to utilize these PSM files see: TBD

## Members of this directory are:
* DXCDeploymentFunctions.psm1	Module to import all the Azure Resource Deployment functions necessery for DXC Azure Offering Powershell Scripts.
* DXCEnvCheck.psm1				Module to import all the environment checking functions necessery for DXC Azure Offering Powershell Scripts.
* DXCUtilityFunctions.psm1		Module to import all the utility functions necessery for DXC Azure Offering Powershell Scripts.

## Authors
* Santanu Sengupta 
