$apiVersion = "2017-01-01-preview"
<#=========================================================================================================================
AUTHOR:  Santanu Sengupta 
DATE:    25/08/2020
Version: 4
Details: Module to import all the environment checking functions necessery for DXC Azure Offering Powershell Scripts.	

#========================================================================================================================#>
# FUNCTION TO CHECK REQUIRED POWERSHELL CORE VERSION
#========================================================================================================================
Function Check-PSCore
    {
    Param($Version)

    if ($PSVersionTable.PSEdition -ne "Core")
        {
        Write-Host "`nWARNING:     You are not running the script on Powershell Core platform. Terminating the script execution." -ForegroundColor Yellow
        Write-Host "             Install the latest non-preview(reseased) version of powershell core from...." -ForegroundColor Yellow  
        Write-Host "             https://github.com/PowerShell/PowerShell/releases/"
        return $false
	    }
    else
        {
        [int]$dxcPSCoreInstalledVersion = ($PSVersionTable.psversion.major) * 100 + ($psversiontable.PSVersion.Minor) * 10 + $PSVersionTable.psversion.Patch
        [int]$dxcAZModuleRequiredVersion = ([int]($Version.Split("."))[0]*100 + [int](($Version.Split("."))[1])*10 + [int](($Version.Split("."))[2]))

        If ($dxcPSCoreInstalledVersion -ge $dxcAZModuleRequiredVersion)
            {
            Write-Host "INFORMATION: Powershell " -NoNewline -ForegroundColor Green
            Write-Host $Version  -NoNewline
            Write-Host " or higher Found." -ForegroundColor Green
            return $true
            } 
        else 
            {
            [String]$dxcPSCoreDisplayInstalledVersion = ($PSVersionTable.psversion.major).ToString() + "." + ($psversiontable.PSVersion.Minor).ToString() + "." + ($PSVersionTable.psversion.Patch).ToString()
            Write-Host "WARNING:     Powershell Core version " -NoNewline -ForegroundColor Yellow
            Write-Host $Version  -NoNewline
            Write-Host " or higher is required." -ForegroundColor Yellow
            Write-Host "             Present installed version is " -NoNewline -ForegroundColor Yellow
            Write-Host $dxcPSCoreDisplayInstalledVersion
            Write-Host "             Upgrade Powershell core with the latest non-preview(reseased) version from...." -ForegroundColor Yellow  
        	Write-Host "             https://github.com/PowerShell/PowerShell/releases/"
            return $false
	        }
        }
    }

#========================================================================================================================#>
# FUNCTION TO CHECK REQUIRED AZ MODULE VERSION
#========================================================================================================================
Function Check-AzModule
    {
    Param($Version)

    $Error.Clear()
    [int]$dxcInstalledMajor = (Get-InstalledModule -Name Az).Version.split(".")[0]

	If (!$dxcInstalledMajor)
		{
		Write-Host "WARNING:     Powershell AZ Module not found." -ForegroundColor Yellow
		Write-Host "             Please open Powershell Core as Administrator and install the latest version with the command...." -ForegroundColor Yellow
        Write-Host "             Install-Module -Name Az -AllowClobber"
		Write-Host "             Select" -NoNewline -ForegroundColor Yellow
		Write-Host " [A] Yes to All " -NoNewline
		Write-Host "when prompted." -ForegroundColor Yellow
        return $false
		}
	[int]$dxcInstalledMinor = (Get-InstalledModule -Name Az).Version.split(".")[1]
	[int]$dxcInstalledBuildNo = (Get-InstalledModule -Name Az).Version.split(".")[2]
    [int]$dxcAZModuleInstalledVersion = $dxcInstalledMajor * 100 + $dxcInstalledMinor * 10 + $dxcInstalledBuildNo
    [int]$dxcAZModuleRequiredVersion = ([int]($Version.Split("."))[0]*100 + [int](($Version.Split("."))[1])*10 + [int](($Version.Split("."))[2]))
    
    If (($Error.Count -eq 0) -and ( $dxcAZModuleInstalledVersion -ge $dxcAZModuleRequiredVersion))
        {
        Write-Host "INFORMATION: AZ Module " -NoNewline -ForegroundColor Green
        Write-Host $Version  -NoNewline
        Write-Host " or higher Found." -ForegroundColor Green
        return $true
        } 
    else 
        {
        Write-Host "WARNING:     AZ Module " -NoNewline -ForegroundColor Yellow
        Write-Host $Version  -NoNewline
        Write-Host " or higher is required." -ForegroundColor Yellow
        
        Write-Host "             Please open Powershell Core as Administrator and install the latest version with the command...." -ForegroundColor Yellow
        Write-Host "             Install-Module -Name Az -AllowClobber"
		Write-Host "             Select" -NoNewline -ForegroundColor Yellow
		Write-Host " [A] Yes to All " -NoNewline
		Write-Host "when prompted." -ForegroundColor Yellow
        return $false
	    }
    }

#========================================================================================================================
# FUNCTION TO CHECK REQUIRED ARM-CLIENT VERSION
#========================================================================================================================
Function Check-ArmClient
    {
    Param($Version)
    $ErrorActionPreference = 'SilentlyContinue'
    [String]$dxcACVersion = armclient | Select-String "ARMClient version"
    [String]$dxcACVersion = $dxcACVersion.Substring(18,7)
    
    if ($dxcACVersion)
        {
        if (([int]($dxcACVersion.Split("."))[0] + [int](($dxcACVersion.Split("."))[1])/10) -ge $Version)
            {
            Write-Host "INFORMATION: ARM Client version " -NoNewline -ForegroundColor Green
            Write-Host $Version -NoNewline
            Write-Host " or higher Found." -ForegroundColor Green
            return $true
            } 
        else 
            {
            Write-Host "WARNING:     ARM Client version " -NoNewline -ForegroundColor Yellow
            Write-Host $Version -NoNewline
            Write-Host " or higher is required, please install the latest version." -ForegroundColor Yellow
            return $false
            }
        }
    else
        {
        Write-Host "WARNING:     ARM Client not found, please install ARM Client version 1.2 or higher." -NoNewline -ForegroundColor Yellow
        return $false
        }
    }

#========================================================================================================================
# FUNCTION TO CHECK REQUIRED AZURE CLI VERSION
#========================================================================================================================
Function Check-AzureCLI
    {
    Param($Version)
    $ErrorActionPreference = 'SilentlyContinue'

    $error.Clear()
    [String]$dxcAZVersion = ((az --version)[0] -replace 'azure-cli', '') -replace '\s',''
    [String]$dxcAZVersion = ($dxcAZVersion) -replace '\*',''
    
    if ($error)
        {
        Write-Host "WARNING:     Azure CLI not found. Please Re-open Powershell as Administrator and then install the latest version with the below command. " -ForegroundColor Yellow
        Write-Host "             Invoke-WebRequest -Uri https://aka.ms/installazurecliwindows -OutFile .\AzureCLI.msi; Start-Process msiexec.exe -Wait -ArgumentList '/I AzureCLI.msi /quiet'"
        return $false
        }
    else
        {
        [int]$dxcAzCLIInstalledVersion = ([int]($dxcAZVersion.Split("."))[0]*1000 + [int](($dxcAZVersion.Split("."))[1])*100 + [int](($dxcAZVersion.Split("."))[2]))
        [int]$dxcAzCLIRequiredVersion = ([int]($Version.Split("."))[0]*1000 + [int](($Version.Split("."))[1])*100 + [int](($Version.Split("."))[2]))
        
        if ($dxcAzCLIInstalledVersion -ge $dxcAzCLIRequiredVersion)
            {
            Write-Host "INFORMATION: Azure CLI version " -NoNewline -ForegroundColor Green
            Write-Host $dxcAZVersion -NoNewline
            Write-Host " Found." -ForegroundColor Green
            return $true
            } 
        else 
            {
            Write-Host "WARNING:     Azure CLI version " -NoNewline -ForegroundColor Yellow
            Write-Host $Version -NoNewline
            Write-Host " or higher is required, Installed version is " -NoNewline -ForegroundColor Yellow
            Write-Host $dxcAZVersion
            Write-Host "WARNING:     Re-open powershell as Administrator and update AzureCLI to the latest version with the below command." -ForegroundColor Yellow
            Write-Host "             Invoke-WebRequest -Uri https://aka.ms/installazurecliwindows -OutFile .\AzureCLI.msi; Start-Process msiexec.exe -Wait -ArgumentList '/I AzureCLI.msi /quiet'"
            return $false
            }
        }    
    }
#========================================================================================================================
# FUNCTION TO CHECK REQUIRED POWERSHELL MODULE AND IT'S VERSION
#========================================================================================================================
Function Check-PSModule
    {
    Param($Name, $Version)

    [Single]$dxcRequiredVersion = [int]$Version.split(".")[0] + [int]$Version.split(".")[1]/10 + [int]$Version.split(".")[2]/100
    $dxcMyPSModule = (Get-Module -ListAvailable | Where-Object{ $_.Name -eq $Name }).Version

    # Check if Module is installed
    If ($dxcMyPSModule)
        {
        Write-Host "INFORMATION: " -NoNewLine -ForegroundColor Green
        Write-Host $Name -NoNewLine
        Write-Host " Powershell Module found. Checking for required version." -ForegroundColor Green
        
        #Check for Multiple versions
        if ($dxcMyPSModule.Count -gt 1)
            {
            Write-Host "WARNING:     Multiple versions of the module " -NoNewLine -ForegroundColor Yellow
            Write-Host $Name -NoNewLine
            Write-Host " detected." -ForegroundColor Yellow
            Write-Host "             Please uninstall all the versions and install only the required version by following the below steps.."-ForegroundColor Yellow
            Write-Host "             1. Open Powershell Core as Administrator (RunAsAdmin) and run the below command" -ForegroundColor Yellow
            Write-Host "                Uninstall-Module -Name $Name -AllVersions -Force"
            Write-Host "             2. Close Powershell Core session and re-open Powershell Core as Administrator (RunAsAdmin) and run the below command" -ForegroundColor Yellow
            Write-Host "                Get-Module -Name $Name -ListAvailable"
            Write-Host "             3. Check whether the output has only one entry of the module with required version, if the output shows no entry of the module, run the below command" -ForegroundColor Yellow
            Write-Host "                Install-Module -Name $Name -RequiredVersion '$Version' -AllowClobber"
            Write-Host "             4. Close Powershell Core session and re-open to run the script." -ForegroundColor Yellow
            return $false
            }

        # Check for required version
        [Single]$dxcInstalledVersion = [int]$dxcMyPSModule.Major[0] + [int]$dxcMyPSModule.Minor[0]/10 + [int]$dxcMyPSModule.Build[0]/100
        If ([Single]$dxcInstalledVersion -ge [Single]$dxcRequiredVersion)
            {
            Write-Host "INFORMATION: Powershell "-NoNewLine -ForegroundColor Green
            Write-Host $Name -NoNewLine
            Write-Host " Module Version " -NoNewLine -ForegroundColor Green
            Write-Host $Version  -NoNewLine
            Write-Host " or higher found." -ForegroundColor Green
            return $True
            } 
        else 
            {
            $dxcDisplayInstalledVersion = [string]$dxcMyPSModule.Major[0] + "." + [string]$dxcMyPSModule.Minor[0] + "." + [string]$dxcMyPSModule.Build[0]
            Write-Host "WARNING:     Powershell $Name Module Version $Version or higher is required, installed version is $dxcDisplayInstalledVersion " -ForegroundColor Yellow
            Write-Host "             Please uninstall the present versions and install the required version by running the below commands as Administrator (RunAsAdmin)"-ForegroundColor Yellow
            Write-Host "             Uninstall-Module -Name '$Name' -AllVersions -Force"
            Write-Host "             Install-Module -Name '$Name' -RequiredVersion '$Version' -AllowClobber"
	        }
        }
    
    # If Module is not installed, prompt for installation
    else
        {
         Write-Host "WARNING:     Powershell module " -NoNewLine -ForegroundColor Yellow
         Write-Host $Name -NoNewLine
         Write-Host " not found. " -ForegroundColor Yellow
         Write-Host "             Please install the required version of the module by running the below command as Administrator (RunAsAdmin)"-ForegroundColor Yellow
         Write-Host "             Install-Module -Name '$Name' -RequiredVersion '$Version' -AllowClobber"
        }
    return $false
    }

#========================================================================================================================
# FUNCTION TO VALIDATE EMAIL ADDRESS FORMAT
#========================================================================================================================
Function Check-EmailAddress
    {
    Param($EmailAddress)
    $dxcEmailFormat = '^.+?@dxc.com$'
    
    if (-not($EmailAddress -match $dxcEmailFormat))
        {
        Write-Host "WARNING:     " -NoNewline -ForegroundColor Yellow
        Write-Host $EmailAddress -NoNewline
        Write-Host " is an invalid Email Address, please enter a valid DXC Email Address while running the script." -ForegroundColor Yellow
        return $false
	    }
    return $true
    }
#========================================================================================================================

Export-ModuleMember -Function 'Check-*'
