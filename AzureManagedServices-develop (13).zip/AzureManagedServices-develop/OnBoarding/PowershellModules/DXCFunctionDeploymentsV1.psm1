$apiVersion = "2017-01-01-preview"
<#=========================================================================================================================
AUTHOR:  Santanu Sengupta 
DATE:    14/08/2020
Version: 1.0
Details: Module to import all the Azure Resource Deployment functions necessery for DXC Azure Offering Powershell Scripts.	
========================================================================================================================#>

#========================================================================================================================
#FUNCTION TO DEPLOY AZURE RESOURCEGROUP
#========================================================================================================================
Function Deploy-ResourceGroup
    {
    Param(
        [Parameter(Mandatory=$true)] [String]$Location,
        [Parameter(Mandatory=$true)] [String]$Name,
        [Parameter(Mandatory=$false)][Switch]$DeletionLock
         )

    $ErrorActionPreference = "SilentlyContinue"
    $WarningPreference = "SilentlyContinue"
    Write-Host ""
    $objRG = Get-AzResourceGroup -Name $Name -ErrorVariable notPresent -EA 0

    if ($objRG) 
        { 
        [bool]$RGExists = $true
        Utility-DisplayInfo -dxcstr1 "INFORMATION: ResourceGroup" -dxcstr2 $Name -dxcstr3 "exist in the subscription. Skipping ResourceGroup deployment."
        }
    else
        {
        [bool]$RGExists = $false
        Utility-DisplayInfo -dxcstr1 "INFORMATION: ResourceGroup" -dxcstr2 $Name -dxcstr3 "doesn't exist, Deploying.... "
        $objRG = New-AzResourceGroup -Name $Name -Location $Location -EA 0

        if ($objRG.count -eq 1) 
            { 
            Write-Host "INFORMATION: ResourceGroup deployed successfully." -NoNewLine -ForegroundColor Green 
            
            if ($DeletionLock)
                {
                Write-Host "INFORMATION: Applying Lock against accedental deletion of the ResourceGroup." -NoNewLine -ForegroundColor Green
                $error.clear
                New-AzResourceLock -ResourceGroupName $Name -LockName "DXC-Automation-RG-Lock" -LockNotes "Cannot Delete Lock applied on this Resource Group to avoid accidental deletion of all resources from automation resource group" -LockLevel "CanNotDelete" -Force >$null
                if ($error) { Utility-DisplayWarning -dxcstr1 "WARNING:     Unable to lock the ResourceGroup" -dxcstr2 $Name -dxcstr " . You need to Manually Lock it against deletion, post deployment." }
                Else { Utility-DisplayInfo -dxcstr1 "INFORMATION: Deletion Lock applied to the ResourceGroup" -dxcstr2 $Name }
                }
            }
        else { Utility-DisplayWarning -dxcstr1 "WARNING:     Unable to deploy ResourceRroup" -dxcstr2 $Name -dxcstr3 ". Script will exit now." }
        }
    return $RGExists, $objRG
    }

#========================================================================================================================
#FUNCTION TO DEPLOY AZURE STORAGE ACCOUNT
#========================================================================================================================
Function Deploy-StorageAccount
    {
    Param([String]$Location, [String]$ResourceGroupName, [String]$Name, [String]$Container, [String]$Table, [String]$Queue, $Blobfiles)

   $ErrorActionPreference = "SilentlyContinue"
   $WarningPreference = "SilentlyContinue"
    Write-Host ""

    #Storage Account Creation
    $ObjStorage = Get-AzStorageAccount -ResourceGroupName $ResourceGroupName -Name $Name -ErrorVariable notPresent -EA 0

    if ($ObjStorage) 
        { 
        [bool]$StorageAccountExists = $true
        Utility-DisplayInfo -dxcstr1 "INFORMATION: Storage Account named" -dxcstr2 $Name -dxcstr3 "already present in the resource group. Skipping Storage Account deployment." 
        }
    else
        {
        [bool]$StorageAccountExists = $false
        Utility-DisplayInfo -dxcstr1 "INFORMATION: Creating storage Account with name" -dxcstr2 $Name  
        $error.Clear()
        $ObjStorage = New-AzStorageAccount -ResourceGroupName $ResourceGroupName -AccountName $Name -Location $Location -SkuName Standard_LRS -Kind StorageV2 -EnableHttpsTrafficOnly $true

        if ($error) 
            { 
            Write-Host "WARNING:     Unable to Create Storage Account. Script will exit now." -ForegroundColor Yellow
            $Blobfiles = "None" 
            }
        else
            {
            Utility-DisplayInfo -dxcstr1 "INFORMATION: Storage account named" -dxcstr2 $Name -dxcstr3 "created successfully." 

            #Creating Storage Table
            If ($Table -ne "None")
                {
                Utility-DisplayInfo -dxcstr1 "INFORMATION: Creating" -dxcstr2 $Table -dxcstr3 "storage Table...."
                $error.Clear()
                New-AzStorageTable -Name $Table -Context $ObjStorage.Context >$null

                if ($error) { Utility-DisplayWarning -dxcstr1 "WARNING:     Unable to Create" -dxcstr2 $Table -dxcstr3 "storage Table. It can be manually created later." }
                else { Write-Host 'INFORMATION: Storage Table created successfully.' -ForegroundColor Green }
                }

            #Creating Storage Queue
            If ($Queue -ne "None")
                {
                Utility-DisplayInfo -dxcstr1 "INFORMATION: Creating" -dxcstr2 $Queue -dxcstr3 "storage Table...."
                $error.Clear()
                New-AzStorageQueue -Name $Queue -Context $ObjStorage.Context >$null

                if ($error) { Utility-DisplayWarning -dxcstr1 "WARNING:     Unable to Create" -dxcstr2 $Queue -dxcstr3 "storage Queue. It can be manually created later." }
                else { Write-Host 'INFORMATION: Storage Queue created successfully.' -ForegroundColor Green }
                }

            #Creating Storage Container
            If ($Container -ne "None")
                {
                $Container = $Container.tolower()
                Utility-DisplayInfo -dxcstr1 "INFORMATION: Creating" -dxcstr2 $Container -dxcstr3 "storage Container...."
                $error.Clear()
                New-AzStorageContainer -Name "metric-alerts" -Context $ObjStorage.Context -Permission Off >$null

                if ($error) 
                    { 
                    Utility-DisplayWarning -dxcstr1 "WARNING:     Unable to Create" -dxcstr2 $Container -dxcstr3 "storage container. Script will exit now."
                    $ObjStorage = $null
                    }
                Else { Write-Host "INFORMATION: Storage Container created successfully." -ForegroundColor Green }
                }
            }
        }
    
    If ($Blobfiles -ne "None")
        {
        ForEach ($blobfile in $blobfiles)
            {
            Utility-DisplayInfo -dxcstr1 "INFORMATION: Uploading alert file" -dxcstr2 $blobfile.Split("\")[-1]
            $error.Clear()
            Set-AzStorageBlobContent -File $blobfile -Container $Container -Context $ObjStorage.Context -Force >$null
                    
            if ($error) { Write-Host 'WARNING:     Unable to upload alert files. These can be manually uploaded later with Microsoft Storage Explorer.' -ForegroundColor Yellow; Break }
            }
        }
    
    return $StorageAccountExists, $ObjStorage
    }

#========================================================================================================================
#FUNCTION TO DEPLOY AZURE FUNCTIONAPP
#========================================================================================================================
Function Deploy-FunctionApp
    {
    Param(
        [Parameter(Mandatory=$true)] [String]$SubscriptionId,
        [Parameter(Mandatory=$true)] [String]$Location,
        [Parameter(Mandatory=$true)] [String]$ResourceGroupName,
        [Parameter(Mandatory=$true)] [String]$FunctionAppName,
        [Parameter(Mandatory=$true)] [String]$StorageAccountName,
        [Parameter(Mandatory=$true)] [String]$AppServicePlanName,
        [Parameter(Mandatory=$true)] [String]$Sku,
        [Parameter(Mandatory=$true)] [String]$AppInsightsName,
        [Parameter(Mandatory=$true)] [String]$OSType,
        [Parameter(Mandatory=$true)] [String]$Runtime,
        [Parameter(Mandatory=$true)] [String]$RuntimeVersion,
        [Parameter(Mandatory=$true)] [Int]$FunctionVersion,
		[Parameter(Mandatory=$true)] [hashtable]$AppSettings,
        [Parameter(Mandatory=$false)][Switch]$AlwaysON
        )
   
    ### VARIABLE SECTION ###
    $ErrorActionPreference = "SilentlyContinue"
    $WarningPreference = "SilentlyContinue"
    [string]$WebAppApiVersion = "2015-08-01"
    [string]$dxcFunctionAppJSON = "https://dxcazuretoolsdev.blob.core.windows.net/installers/JSON/FunctionApp/deployFunctionAppOnConsumptionPlan.json"
    
    Switch($Sku)
            { 
            "B1" { $SkuTier = "Basic" }
            "Y1" { $SkuTier = "Dynamic" }
            default { Utility-DisplayWarning -dxcstr1 "WARNING    : Sku Name" -dxcstr2 $Sku -dxcstr3 "is invalid. Valid types are 'B1' and 'Y1'."; return $null, $null }
            }

    ### MAIN BODY ###
    
    Write-Host ""
    $dxcObjFunctionApp = Get-AzResource -ResourceGroupName $ResourceGroupName -ResourceType "Microsoft.Web/sites" -Name $FunctionAppName

    if ($dxcObjFunctionApp) 
        {
        [bool]$dxcFunctionAppExists = $true 
        Utility-DisplayInfo -dxcstr1 "INFORMATION: FunctionApp named" -dxcstr2 $FunctionAppName -dxcstr3 "already present. Skipping FunctionApp deployment." 
        }
    else
        {
        [bool]$dxcFunctionAppExists = $false

        ### CHECK AND CREATE APPSERVICEPLAN ###

        Write-Host ""
        Utility-DisplayInfo -dxcstr1 "INFORMATION: Checking whether the AppServicePlan:" -dxcstr2 $AppServicePlanName -dxcstr3 "already exists."
        $dxcObjAppServicePlan = Get-AzAppServicePlan -Name $appServicePlanName -ResourceGroupName $ResourceGroupName -ErrorAction SilentlyContinue

        if($dxcObjAppServicePlan) { Utility-DisplayInfo -dxcstr1 "INFORMATION: AppServicePlan:" -dxcstr2 $AppServicePlanName -dxcstr3 "already exists." }
        else
            {
            Utility-DisplayInfo -dxcstr1 "INFORMATION: AppServicePlan:" -dxcstr2 $AppServicePlanName -dxcstr3 "doesn't exist, deploying..."
            $AppServicePlanProperties = @{
                                        location = $Location
                                        sku = @{
                                                name = $Sku
                                                tier = $SkuTier
                                                }
                                        }
            $error.clear()
            $dxcObjAppServicePlan = New-AzResource -ResourceGroupName $ResourceGroupName -ResourceType "Microsoft.Web/serverfarms" -Name $AppServicePlanName -IsFullObject -PropertyObject $AppServicePlanProperties -ApiVersion $WebAppApiVersion -Force

            if ($dxcObjAppServicePlan) { Utility-DisplayInfo -dxcstr1 "INFORMATION: AppServicePlan:" -dxcstr2 $AppServicePlanName -dxcstr3 "created successfully." }
            else
                { 
                Utility-DisplayWarning -dxcstr1 "WARNING:     Failed to Create AppServicePlan:" -dxcstr2 $AppServicePlanName -dxcstr3 ". Script will exit now."
                return $dxcFunctionAppExists, $null      
                }
            }

        ### CHECK AND CREATE APPLICATIONINSIGHTS ###

        Write-Host ""
	    Utility-DisplayInfo -dxcstr1 "INFORMATION: Checking whether the ApplicationInsights" -dxcstr2 $AppInsightsName -dxcstr3 "already exists."
        $dxcOBJAI = Get-AzApplicationInsights -ResourceGroupName $ResourceGroupName -Name $AppInsightsName
        
        if ($dxcOBJAI) { Utility-DisplayInfo -dxcstr1 "INFORMATION: Application Insight named" -dxcstr2 $AppInsightsName -dxcstr3 "located in the resource group" -dxcstr4 $ResourceGroupName }
        else    
            { 
            Utility-DisplayInfo -dxcstr1 "INFORMATION: Application Insight named" -dxcstr2 $AppInsightsName -dxcstr3 "doesn't exist, deploying..."
            $dxcOBJAI = New-AzApplicationInsights -ResourceGroupName $ResourceGroupName -Name $AppInsightsName -location $Location -ErrorAction SilentlyContinue
        
            if ($dxcOBJAI) { Utility-DisplayInfo -dxcstr1 "INFORMATION: Application Insights named" -dxcstr2 $AppInsightsName -dxcstr3 "created successfully." }
            else    
                { 
                Write-Host "WARNING:     Unable to Create Application Insight. Script will exit now." -ForegroundColor Yellow 
                return $dxcFunctionAppExists, $null
            }
        }
                                                                                                                                                                                                            
        ### CREATE FUNCTIONAPP ###
                
        Write-Host "`nINFORMATION: Creating FunctionApp...." -ForegroundColor Green
        
        Switch($Sku)
            { 
            "B1"
                {
                    $FunctionAppSettings = @{
                    ServerFarmId="/subscriptions/$SubscriptionId/resourceGroups/$ResourceGroupName/providers/Microsoft.Web/serverfarms/$AppServicePlanName";
                    httpsOnly=$True;
                	}
                $ObjFunctionApp = New-AzResource -ResourceGroupName $ResourceGroupName -Location $Location -ResourceName $FunctionAppName  -Properties $FunctionAppSettings -ResourceType "microsoft.web/sites" -Kind "functionapp"  -Force
                $dxcObjFunctionApp = Get-AzFunctionApp -ResourceGroupName $ResourceGroupName -Name $FunctionAppName
                Write-Host "Function App Name is ::" $dxcObjFunctionApp
                $resource = Get-AzResource -Name $AppInsightsName -ResourceType "Microsoft.Insights/components"
                $details = Get-AzResource -ResourceId $resource.ResourceId
                $applicationInsightsConnectionString = $details.Properties.ConnectionString
                az functionapp config appsettings set --name $FunctionAppName --resource-group $ResourceGroupName --settings "APPLICATIONINSIGHTS_CONNECTION_STRING = $applicationInsightsConnectionString"
            if ($dxcObjFunctionApp) 
                    {
                    Utility-DisplayInfo -dxcstr1 "INFORMATION: FunctionApp named" -dxcstr2 $FunctionAppName -dxcstr3 "deployd successfully."
                    #Update-AzFunctionApp -Name $FunctionAppName -ResourceGroupName $ResourceGroupName -IdentityType "SystemAssigned"
                    $AzFunctionAppStorageAccountKey = Get-AzStorageAccountKey -ResourceGroupName $ResourceGroupName -AccountName $StorageAccountName | Where-Object { $_.KeyName -eq "Key1" } | Select-Object Value
                    $AzFunctionAppStorageAccountConnectionString = "DefaultEndpointsProtocol=https;AccountName=$StorageAccountName;AccountKey=$($AzFunctionAppStorageAccountKey.Value);EndpointSuffix=core.windows.net"
                    az functionapp config appsettings set --name $FunctionAppName --resource-group $ResourceGroupName --settings "AzureWebJobsStorage=$AzFunctionAppStorageAccountConnectionString"
                    az functionapp config appsettings set --name $FunctionAppName --resource-group $ResourceGroupName --settings "FUNCTIONS_EXTENSION_VERSION=~3"  
                    az functionapp config appsettings set --name $FunctionAppName --resource-group $ResourceGroupName --settings "FUNCTIONS_WORKER_RUNTIME=powershell"  
                    az functionapp config appsettings set --name $FunctionAppName --resource-group $ResourceGroupName --settings "WEBSITE_NODE_DEFAULT_VERSION=~10"
                    $instrumentationKey = (Get-AzApplicationInsights -ResourceGroupName $ResourceGroupName -Name $AppInsightsName).InstrumentationKey
                    az functionapp config appsettings set --name $FunctionAppName --resource-group $ResourceGroupName --settings "APPINSIGHTS_INSTRUMENTATIONKEY =$instrumentationKey"
                    # appsettings
                    foreach ($AppSettingAdd in $AppSettings.GetEnumerator()) 
                    {
                      az functionapp config appsettings set --name $FunctionAppName --resource-group $ResourceGroupName --settings "$($AppSettingAdd.Name) = $($AppSettingAdd.Value)"
                    }
                    Set-AzResource -ResourceId "/subscriptions/$SubscriptionId/resourceGroups/$ResourceGroupName/providers/Microsoft.Web/sites/$FunctionAppName/config/web" -UsePatchSemantics -Properties @{ powerShellVersion = '~7' } -Force
                    If ($AlwaysON)
                        {
                        Write-Host "INFORMATION: Pushing 'Always On' setting to FunctionApp...." -ForegroundColor Green
                        $Succeded = $null
                        $Succeded = $dxcObjFunctionApp | Set-AzResource -PropertyObject @{"siteConfig" = @{"AlwaysOn" = $false}}
                
                        if ($Succeded) { Write-Host "INFORMATION: 'Always On' is set to TRUE for the FunctionApp." -ForegroundColor Green }
                        else { Write-Host "WARNING:     Unable to Set 'Always On' to TRUE. You need to set it manually after the deployment." -ForegroundColor Yellow }
                        }
                    }
                else 
                    { 
                    Write-Host "WARNING:     Unable to Create FunctionApp. Script will exit now." -ForegroundColor Yellow 
                    return $dxcFunctionAppExists, $null
                    }
                }
            "Y1"
                {
                $dxcObjFunctionApp = New-AzResourceGroupDeployment -Name "FunctionAppDeployment" -ResourceGroupName $ResourceGroupName -TemplateURI $dxcFunctionAppJSON -storageAccountName $StorageAccountName -appInsightsName $AppInsightsName -hostingPlanName $AppServicePlanName -funcAppName $FunctionAppName -location $Location

                if ($dxcObjFunctionApp) { Utility-DisplayInfo -dxcstr1 "INFORMATION: FunctionApp named" -dxcstr2 $FunctionAppName -dxcstr3 "deployed successfully." }
                else    
                    { 
                    Write-Host "WARNING:     Failed to deploy FunctionApp. Script will exit now." -ForegroundColor Yellow 
                    return $dxcFunctionAppExists, $null
                    }
                }
            }
        }
    return $dxcFunctionAppExists, $dxcObjFunctionApp
    }


#========================================================================================================================
#FUNCTION TO HARDEN AZURE FUNCTIONAPP SECURITY
#========================================================================================================================

function deploy-FunctionAppSecurity(
    [Parameter(Mandatory = $true)]  [String]$FunctionAppName,
    [Parameter(Mandatory = $true)]  [String]$ResourceGroupName,
    [Parameter(Mandatory = $true)]  [String]$Location, 
    [Parameter(Mandatory = $false)] [Switch]$AppServiceAuthOn,
    [Parameter(Mandatory = $false)] [Switch]$HTTPSOnly,
    [Parameter(Mandatory = $false)] [Switch]$HTTP20Enabled,
    [Parameter(Mandatory = $false)] [Switch]$FTPDisabled,
    [Parameter(Mandatory = $false)] [Switch]$FTPSOnly
    )
    {
    ### VARIABLE SECTION ###

	$ErrorActionPreference = "SilentlyContinue"
    $WarningPreference = "SilentlyContinue"

    [string]$WebAppApiVersion = "2015-08-01"
    [String]$dxcWebResource = $FunctionAppName + "/web"
    [String]$dxcAuthResource = $FunctionAppName + "/authsettings"
    $dxcAuthSettings =    @{
                            "enabled" = "True";
                            "unauthenticatedClientAction" = "1";
                            "defaultProvider" = "0";
                            "tokenStoreEnabled" = "False";
                           }

    ### MAIN BODY ###

    Write-Host "`nINFORMATION: Applying security settings for the Function App..." -ForegroundColor Green

    If ($FTPDisabled -and$FTPSOnly) { Write-Host "WARNING:     Cannot Push both 'FTPDisabled' and 'FTPSOnly' settings. Please remove one of these switches and try again." -ForegroundColor Yellow }

    If ($HTTP20Enabled) { $dxcWebSecuritySettings += @{ "http20Enabled" = "True"; } }
    If ($FTPDisabled)   { $dxcWebSecuritySettings += @{ "ftpsState"="Disabled";   } }
    If ($FTPSOnly)   { $dxcWebSecuritySettings += @{ "ftpsState"="FtpsOnly";   } }

    $error.Clear()
	If ($httpsOnly) 
        {
        $dxcObjFunctionApp = Get-AzResource -ResourceGroupName $ResourceGroupName -ResourceType "Microsoft.Web/sites" -Name $FunctionAppName 
        $dxcObjFunctionApp.Properties.httpsOnly=$true
        $dxcObjFunctionApp|Set-AzResource -Force >$null
        }
	If ($AppServiceAuthOn) { New-AzResource -PropertyObject $dxcAuthSettings -ResourceGroupName $ResourceGroupName -ResourceType "Microsoft.Web/sites/config" -ResourceName $dxcAuthResource -ApiVersion $WebAppApiVersion -Force >$null}
	If ($HTTP20Enabled -or $FTPDisabled -or $FTPSOnly) { New-AzResource -PropertyObject $dxcWebSecuritySettings -ResourceGroupName $ResourceGroupName -ResourceType "Microsoft.Web/sites/config" -ResourceName $dxcWebResource -ApiVersion $WebAppApiVersion -Force >$null }

	If ($error) 
    	{
    	Write-Host "WARNING:     Failed to deploy some or all the security settngs, follow the below Wiki document to set the security settings manually if rest of the deployment is successfull." -ForegroundColor Yellow
    	Write-Host "             https://confluence.dxc.com/pages/viewpage.action?pageId=207312130"
    	}
	else { Write-Host "INFORMATION: Security settings implemented successfully." -ForegroundColor Green }
	}


#========================================================================================================================
#FUNCTION TO DEPLOY AZURE TIME TRIGGER FUNCTION ON FUNCTIONAPP
#========================================================================================================================

function deploy-TimeTriggerFunction(
    [Parameter(Mandatory = $true)]  [String]$FunctionAppName,
    [Parameter(Mandatory = $true)]  [String]$ResourceGroupName,
    [Parameter(Mandatory = $true)]  [String]$Location, 
    [Parameter(Mandatory = $true)]  [String]$FunctionName,
    [Parameter(Mandatory = $true)]  [String]$SourceCodeFileName,
    [Parameter(Mandatory = $true)]  [String]$Schedule
    )
    {
    ### VARIABLE SECTION ###

    $ErrorActionPreference = "SilentlyContinue"
    $WarningPreference = "SilentlyContinue"
    [string]$WebAppApiVersion = "2015-08-01"
    $TimeTrigger = @{ config = @{ 'bindings' = @(
                                                    @{ 'name' = 'Timer'
                                                       'type' = 'timerTrigger'
                                                       'direction' = 'in'
                                                       'schedule' = $Schedule
                                                     }
                                                )
                                }
                    }

    ### MAIN BODY ###

    $dxcObjFunctionApp = Get-AzResource -ResourceGroupName $ResourceGroupName -ResourceType "Microsoft.Web/sites" -Name $FunctionAppName
    $dxcSourceContent = Get-Content -Raw $SourceCodeFileName
    $TimeTrigger.files = @{ 'run.ps1' = "$dxcSourceContent" }
    $dxcFunctionResourceId = '{0}/functions/{1}' -f $dxcObjFunctionApp.Id, $FunctionName 

    Write-Host ""
    Utility-DisplayInfo -dxcstr1 "INFORMATION: Deploying Time Trigger Function" -dxcstr2 $FunctionName -dxcstr3 ". It may take few minutes..."
    $ObjFunction = New-AzResource -ResourceId $dxcFunctionResourceId -Properties $TimeTrigger -ApiVersion $WebAppApiVersion -force
   
    if($ObjFunction) 
        { 
        Utility-DisplayInfo -dxcstr1 "INFORMATION: Function" -dxcstr2 $FunctionName -dxcstr3 "deployed successfully." 
        return $true
        }
    else    
        { 
        Utility-DisplayWarning -dxcstr1 "WARNING:     Failed to deploy the Function" -dxcstr2 $FunctionName -dxcstr3 ". Script will exit now."
        return $false
        }
    }


#========================================================================================================================
#FUNCTION TO DEPLOY AZURE HTTP TRIGGER FUNCTION ON FUNCTIONAPP
#========================================================================================================================

function deploy-HTTPTriggerFunction(
    [Parameter(Mandatory = $true)]  [String]$FunctionAppName,
    [Parameter(Mandatory = $true)]  [String]$ResourceGroupName,
    [Parameter(Mandatory = $true)]  [String]$Location, 
    [Parameter(Mandatory = $true)]  [String]$FunctionName,
    [Parameter(Mandatory = $true)]  [String]$SourceCodeFileName
    )
    {
    ### VARIABLE SECTION ###

    $ErrorActionPreference = "SilentlyContinue"
    $WarningPreference = "SilentlyContinue"
    [string]$WebAppApiVersion = "2015-08-01"

    $HTTPTrigger = @{ config = @{ 'bindings' = @(
                                                        @{ 'authLevel' = 'function'
                                                           'type' = 'httpTrigger'
                                                           'direction' = 'in'
                                                           'name' = 'Request'
                                                           'methods' = @( 'get','post')
                                                          }
                                                         @{'type' = 'http'
                                                           'direction' = 'out'
                                                           'name' = 'Response'
                                                          }
                                                    )
                                    }
                        }
  

    ### MAIN BODY ###

    $dxcObjFunctionApp = Get-AzResource -ResourceGroupName $ResourceGroupName -ResourceType "Microsoft.Web/sites" -Name $FunctionAppName
    $dxcSourceContent = Get-Content -Raw $SourceCodeFileName
    $HTTPTrigger.files = @{ 'run.ps1' = "$dxcSourceContent" }
    $dxcFunctionResourceId = '{0}/functions/{1}' -f $dxcObjFunctionApp.Id, $FunctionName 

    Write-Host ""
    Utility-DisplayInfo -dxcstr1 "INFORMATION: Deploying Time HTTP Function" -dxcstr2 $FunctionName -dxcstr3 ". It may take few minutes..."
    $error.clear
    New-AzResource -ResourceId $dxcFunctionResourceId -Properties $TimeTrigger -ApiVersion $WebAppApiVersion -force
    
    if($error) 
        { 
        Utility-DisplayWarning -dxcstr1 "WARNING:     Failed to deploy the Function" -dxcstr2 $FunctionName -dxcstr3 ". Script will exit now."
        return $false
        }
    else    
        { 
        Utility-DisplayInfo -dxcstr1 "INFORMATION: Function" -dxcstr2 $FunctionName -dxcstr3 "deployed successfully." 
        return $true
        }
    }



#========================================================================================================================
#FUNCTION TO DEPLOY ROLL BASED ACCESS TO THE FUNCTIONAPP IDENTITY
#========================================================================================================================

function deploy-RBACRule(
    [Parameter(Mandatory = $true)]  [String]$FunctionAppName,
	[Parameter(Mandatory = $true)]  [String]$ResourceGroupName,
    [Parameter(Mandatory = $true)]  [String]$Scope,
    [Parameter(Mandatory = $true)]  [String]$RoleDefinitionName
    )
    {
    ### VARIABLE SECTION ###

    $ErrorActionPreference = "SilentlyContinue"
    $WarningPreference = "SilentlyContinue"

    ### MAIN BODY ###
    $dxcObjFunctionApp = Get-AzResource -Name $FunctionAppName -ResourceGroupName $ResourceGroupName -ResourceType "Microsoft.Web/sites" -EA 0
    New-AzRoleAssignment -ObjectId $dxcObjFunctionApp.Identity.PrincipalId -Scope $Scope -RoleDefinitionName $RoleDefinitionName >$null
    
    if ($error) 
        { 
        Write-Host "WARNING:     Unable to provide necessery access to FunctionApp. You may not have 'Owner' rights to the subscription." -ForegroundColor Yellow
        Utility-DisplayWarning -dxcstr1 "             The script will continue to deploy but for proper functioning, some one with owner rights have to assign its System Assigned Identity" -dxcstr2 $FunctionAppIdentity -dxcstr3 "the below RBAC Role..."
        Utility-DisplayWarning -dxcstr1 "             Scope:" -dxcstr2 $Scope -dxcstr3 "      Role Defination Name:" -dxcstr4 $RoleDefinitionName
        }
    Else 
        { 
        Utility-DisplayInfo -dxcstr1 "INFORMATION: FunctionApp's System Assigned Identity" -dxcstr2 $dxcObjFunctionApp.Identity.PrincipalId -dxcstr3 "has been successfully assigned" -dxcstr4 $RoleDefinitionName
        Utility-DisplayInfo -dxcstr1 "             role on Scope" -dxcstr2 $Scope
        }
    }

#========================================================================================================================
Export-ModuleMember -Function 'Deploy-*'





                 