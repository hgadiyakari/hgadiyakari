$apiVersion = "2017-01-01-preview"
<#=========================================================================================================================
AUTHOR:  Santanu Sengupta 
DATE:    25/10/2019
Version: 3.1
Details: Module to import all the environment checking functions necessery for DXC Azure Offering Powershell Scripts.	
#========================================================================================================================#>
# FUNCTION TO CHECK REQUIRED POWERSHELL VERSION
#========================================================================================================================
Function Check-PSVersion
    {
    Param($dxcPSVersion)
    If ((($PSVersionTable.psversion.major) + ($psversiontable.PSVersion.Minor)/10) -ge $dxcPSVersion)
        {
        Write-Host "INFORMATION: Powershell " -NoNewline -ForegroundColor Green
        Write-Host $dxcPSVersion  -NoNewline
        Write-Host " or higher Found." -ForegroundColor Green
        } 
    else 
        {
        Write-Host "WARNING:     Powershell " -NoNewline -ForegroundColor Yellow
        Write-Host $dxcPSVersion  -NoNewline
        Write-Host " or higher is required, please exit and install the latest version." -ForegroundColor Yellow

        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        Read-Host "`nPress 'ENTER'to exit the script........"
        Exit
	    }
    }
#========================================================================================================================#>
# FUNCTION TO CHECK REQUIRED POWERSHELL CORE VERSION
#========================================================================================================================
Function Check-PSCoreVersion
    {
    Param($dxcPSVersion)

    if ($PSVersionTable.PSEdition -ne "Core")
        {
        Write-Host "`nWARNING:     You are not running the script on Powershell Core platform. Terminating the script execution." -ForegroundColor Yellow
        Write-Host "             Install the latest non-preview(reseased) version of powershell core from...." -ForegroundColor Yellow  
        Write-Host "             https://github.com/PowerShell/PowerShell/releases/"
		
		Read-Host "`nPress 'ENTER'to exit the script........"
		Exit
	    }
    else
        {
        [int]$dxcPSCoreInstalledVersion = ($PSVersionTable.psversion.major) * 100 + ($psversiontable.PSVersion.Minor) * 10 + $PSVersionTable.psversion.Patch
        [int]$dxcAZModuleRequiredVersion = ([int]($dxcPSVersion.Split("."))[0]*100 + [int](($dxcPSVersion.Split("."))[1])*10 + [int](($dxcPSVersion.Split("."))[2]))

        If ($dxcPSCoreInstalledVersion -ge $dxcAZModuleRequiredVersion)
            {
            Write-Host "INFORMATION: Powershell " -NoNewline -ForegroundColor Green
            Write-Host $dxcPSVersion  -NoNewline
            Write-Host " or higher Found." -ForegroundColor Green
            } 
        else 
            {
            Write-Host "WARNING:     Powershell Core version " -NoNewline -ForegroundColor Yellow
            Write-Host $dxcPSVersion  -NoNewline
            Write-Host " or higher is required." -ForegroundColor Yellow
            
            Write-Host "             Upgrade Powershell core with the latest non-preview(reseased) version from...." -ForegroundColor Yellow  
        	Write-Host "             https://github.com/PowerShell/PowerShell/releases/"
		
            Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
            Read-Host "`nPress 'ENTER'to exit the script........"
            Exit
	        }
        }
    }
#========================================================================================================================#>
# FUNCTION TO CHECK REQUIRED AZ MODULE VERSION
#========================================================================================================================
Function Check-AzModuleVersion
    {
    Param($dxcAzModuleVersion)

    $Error.Clear()
    [int]$dxcInstalledMajor = (Get-InstalledModule -Name Az).Version.split(".")[0]

	If (!$dxcInstalledMajor)
		{
		Write-Host "WARNING:     Powershell AZ Module not found." -ForegroundColor Yellow
		Write-Host "             Please open Powershell Core as Administrator and install the latest version with the command...." -ForegroundColor Yellow
        Write-Host "             Install-Module -Name Az -AllowClobber"
		Write-Host "             Select" -NoNewline -ForegroundColor Yellow
		Write-Host " [A] Yes to All " -NoNewline
		Write-Host "when prompted." -ForegroundColor Yellow

        Read-Host "`nPress 'ENTER'to exit the script........"
        Exit
		}
	[int]$dxcInstalledMinor = (Get-InstalledModule -Name Az).Version.split(".")[1]
	[int]$dxcInstalledBuildNo = (Get-InstalledModule -Name Az).Version.split(".")[2]
    [int]$dxcAZModuleInstalledVersion = $dxcInstalledMajor * 100 + $dxcInstalledMinor * 10 + $dxcInstalledBuildNo
    [int]$dxcAZModuleRequiredVersion = ([int]($dxcAzModuleVersion.Split("."))[0]*100 + [int](($dxcAzModuleVersion.Split("."))[1])*10 + [int](($dxcAzModuleVersion.Split("."))[2]))
    
    If (($Error.Count -eq 0) -and ( $dxcAZModuleInstalledVersion -ge $dxcAZModuleRequiredVersion))
        {
        Write-Host "INFORMATION: AZ Module " -NoNewline -ForegroundColor Green
        Write-Host $dxcAzModuleVersion  -NoNewline
        Write-Host " or higher Found." -ForegroundColor Green
        } 
    else 
        {
        Write-Host "WARNING:     AZ Module " -NoNewline -ForegroundColor Yellow
        Write-Host $dxcAzModuleVersion  -NoNewline
        Write-Host " or higher is required." -ForegroundColor Yellow
        
        Write-Host "             Please open Powershell Core as Administrator and install the latest version with the command...." -ForegroundColor Yellow
        Write-Host "             Install-Module -Name Az -AllowClobber"
		Write-Host "             Select" -NoNewline -ForegroundColor Yellow
		Write-Host " [A] Yes to All " -NoNewline
		Write-Host "when prompted." -ForegroundColor Yellow

        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        Read-Host "`nPress 'ENTER'to exit the script........"
        Exit
	    }
    }

#========================================================================================================================
# FUNCTION TO CHECK REQUIRED ARM-CLIENT VERSION
#========================================================================================================================
Function Check-ArmClientVersion
    {
    Param($dxcArmClientVersion)
    $ErrorActionPreference = 'SilentlyContinue'
    [String]$dxcACVersion = armclient | Select-String "ARMClient version"
    [String]$dxcACVersion = $dxcACVersion.Substring(18,7)
    
    if ($dxcACVersion)
        {
        if (([int]($dxcACVersion.Split("."))[0] + [int](($dxcACVersion.Split("."))[1])/10) -ge $dxcArmClientVersion)
            {
            Write-Host "INFORMATION: ARM Client version " -NoNewline -ForegroundColor Green
            Write-Host $dxcArmClientVersion -NoNewline
            Write-Host " or higher Found." -ForegroundColor Green
            } 
        else 
            {
            Write-Host "WARNING:     ARM Client version " -NoNewline -ForegroundColor Yellow
            Write-Host $dxcArmClientVersion -NoNewline
            Write-Host " or higher is required, please install the latest version." -ForegroundColor Yellow
            Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
            Read-Host "`nPress 'ENTER'to exit the script........"
            Exit
            }
        }
    else
        {
        Write-Host "WARNING:     ARM Client not found, please install ARM Client version 1.2 or higher." -NoNewline -ForegroundColor Yellow
        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        Read-Host "`nPress 'ENTER'to exit the script........"
        Exit
        }
    }

#========================================================================================================================
# FUNCTION TO CHECK REQUIRED AZURE CLI VERSION
#========================================================================================================================
Function Check-AzureCLIVersion
    {
    Param($dxcAZRequiredVersion)
    $ErrorActionPreference = 'SilentlyContinue'

    $error.Clear()
    [String]$dxcAZVersion = ((az --version)[0] -replace 'azure-cli', '') -replace '\s',''
    [String]$dxcAZVersion = ($dxcAZVersion) -replace '\*',''
    
    if ($error)
        {
        Write-Host "WARNING:     Azure CLI not found. Please Re-open Powershell as Administrator and then install the latest version with the below command. " -ForegroundColor Yellow
        Write-Host "             Invoke-WebRequest -Uri https://aka.ms/installazurecliwindows -OutFile .\AzureCLI.msi; Start-Process msiexec.exe -Wait -ArgumentList '/I AzureCLI.msi /quiet'"
        Read-Host "`nPress 'ENTER'to exit the script........"
        Exit
        }
    else
        {
        [int]$dxcAzCLIInstalledVersion = ([int]($dxcAZVersion.Split("."))[0]*1000 + [int](($dxcAZVersion.Split("."))[1])*100 + [int](($dxcAZVersion.Split("."))[2]))
        [int]$dxcAzCLIRequiredVersion = ([int]($dxcAZRequiredVersion.Split("."))[0]*1000 + [int](($dxcAZRequiredVersion.Split("."))[1])*100 + [int](($dxcAZRequiredVersion.Split("."))[2]))
        
        if ($dxcAzCLIInstalledVersion -ge $dxcAzCLIRequiredVersion)
            {
            Write-Host "INFORMATION: Azure CLI version " -NoNewline -ForegroundColor Green
            Write-Host $dxcAZVersion -NoNewline
            Write-Host " Found." -ForegroundColor Green
            } 
        else 
            {
            Write-Host "WARNING:     Azure CLI version " -NoNewline -ForegroundColor Yellow
            Write-Host $dxcAZRequiredVersion -NoNewline
            Write-Host " or higher is required, Installed version is " -NoNewline -ForegroundColor Yellow
            Write-Host $dxcAZVersion
            Write-Host "WARNING:     Re-open powershell as Administrator and update AzureCLI to the latest version with the below command." -ForegroundColor Yellow
            Write-Host "             Invoke-WebRequest -Uri https://aka.ms/installazurecliwindows -OutFile .\AzureCLI.msi; Start-Process msiexec.exe -Wait -ArgumentList '/I AzureCLI.msi /quiet'"
            Read-Host "`nPress 'ENTER'to exit the script........"
            Exit
            }
        }    
    }
#========================================================================================================================
# FUNCTION TO CHECK REQUIRED POWERSHELL MODULE AND IT'S VERSION
#========================================================================================================================
Function Check-PSModule
    {
    Param($dxcPSModule, $dxcPSModuleVersion)

    [Single]$dxcRequiredVersion = [int]$dxcPSModuleVersion.split(".")[0] + [int]$dxcPSModuleVersion.split(".")[1]/10 + [int]$dxcPSModuleVersion.split(".")[2]/100
    $dxcMyPSModule = (Get-Module -ListAvailable | Where-Object{ $_.Name -eq $dxcPSModule }).Version

    # Check if Module is installed
    If ($dxcMyPSModule)
        {
        Write-Host "INFORMATION: " -NoNewLine -ForegroundColor Green
        Write-Host $dxcPSModule -NoNewLine
        Write-Host " Powershell Module found. Checking for required version." -ForegroundColor Green

        # If Module is installed, check for required version
        [Single]$dxcInstalledVersion = [int]$dxcMyPSModule.Major[0] + [int]$dxcMyPSModule.Minor[0]/10 + [int]$dxcMyPSModule.Build[0]/100
        If ([Single]$dxcInstalledVersion -ge [Single]$dxcRequiredVersion)
            {
            Write-Host "INFORMATION: Powershell "-NoNewLine -ForegroundColor Green
            Write-Host $dxcPSModule -NoNewLine
            Write-Host " Module Version " -NoNewLine -ForegroundColor Green
            Write-Host $dxcPSModuleVersion  -NoNewLine
            Write-Host " or higher found." -ForegroundColor Green
            } 
        else 
            {
            $dxcDisplayInstalledVersion = [string]$dxcMyPSModule.Major[0] + "." + [string]$dxcMyPSModule.Minor[0] + "." + [string]$dxcMyPSModule.Build[0]
            Write-Host "WARNING:     Powershell $dxcPSModule Module Version $dxcPSModuleVersion or higher is required, installed version is $dxcDisplayInstalledVersion " -ForegroundColor Yellow
            Write-Host "             Please uninstall the present version, run the script again with Administrator rights and accept the prompt to install the latest version of the module." -ForegroundColor Yellow
            Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
	        Read-Host "`nPress 'ENTER'to exit the script........"
            Exit
	        }
        }
    
    # If Module is not installed, prompt for installation
    else
        {
        Write-Host "WARNING:     $dxcPSModule module not found. Do you want to try and install it now?" -ForegroundColor Yellow
        $dxcReadHost = Read-Host " (y/n) "
        Switch ($dxcReadHost)
            {
            Y       {
                    Write-Host "INFORMATION: Yes, Install Module" -ForegroundColor Green
                    $error.Clear()
                    Install-Module -Name $dxcPSModule  -Scope CurrentUser -Force
                    If ($error)
                        {
                         Write-Host "WARNING:     " $Error[0] -split '"."' -ForegroundColor Yellow
                         Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
                         Exit
                        }
                    }
            N       {
                    Write-Host "WARNING:     No, Exit script" -ForegroundColor Yellow
                    Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
					Read-Host "`nPress 'ENTER'to exit the script........"
                    Exit
                    }
            Default {
                    Write-Host "WARNING:     Default, Exit script" -ForegroundColor Yellow
                    Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
					Read-Host "`nPress 'ENTER'to exit the script........"
                    Exit
                    }
            }
        }
    }

#========================================================================================================================
# FUNCTION TO VALIDATE EMAIL ADDRESS FORMAT
#========================================================================================================================
Function Check-EmailAddress
    {
    Param($dxcEmailAddress)
    $dxcEmailFormat = '^.+?@dxc.com$'
    
    if (-not($dxcEmailAddress -match $dxcEmailFormat))
        {
        Write-Host "WARNING:     " -NoNewline -ForegroundColor Yellow
        Write-Host $dxcEmailAddress -NoNewline
        Write-Host " is an invalid Email Address, please enter a valid DXC Email Address while running the script." -ForegroundColor Yellow

        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        Read-Host "`nPress 'ENTER'to exit the script........"
        Exit
	    }
    }
#========================================================================================================================

Export-ModuleMember -Function 'Check-*'
