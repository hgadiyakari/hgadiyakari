$apiVersion = "2017-01-01-preview"
<#=========================================================================================================================
AUTHOR:  Santanu Sengupta 
DATE:    11/05/2020
Version: 2.0
Details: Module to import all the utility functions necessery for DXC Azure Offering Powershell Scripts.	
#========================================================================================================================#>
# FUNCTION TO DISPLAY INFORMATIONAL MESSAGE
#========================================================================================================================
Function Utility-DisplayInfo
    {
    Param($dxcstr1, $dxcstr2, $dxcstr3, $dxcstr4)
 
        Write-Host $dxcstr1" " -NoNewline -ForegroundColor Green
        Write-Host $dxcstr2" " -NoNewline
        Write-Host $dxcstr3" " -NoNewline -ForegroundColor Green
        Write-Host $dxcstr4" "
    }

#========================================================================================================================
# FUNCTION TO DISPLAY WARNING MESSAGE
#========================================================================================================================
Function Utility-DisplayWarning
    {
    Param($dxcstr1, $dxcstr2, $dxcstr3, $dxcstr4)
 
        Write-Host $dxcstr1" " -NoNewline -ForegroundColor yellow
        Write-Host $dxcstr2" " -NoNewline
        Write-Host $dxcstr3" " -NoNewline -ForegroundColor yellow
        Write-Host $dxcstr4" "
    }

#========================================================================================================================
# FUNCTION TO LOGIN WITH az
#========================================================================================================================
Function Utility-LoginAZ
    {
    Param ($dxcSubscriptionId)

    Set-AzContext -Subscription $dxcSubscriptionID -EA 0 -WA 0 >$null

    if ($global:error) 
        { 
        $global:error.Clear()
        Write-Host "`nINFORMATION: Please login to Azure Resource Manager." -ForegroundColor Green
        Connect-AzAccount -WarningAction:Continue >$null
 
        if ($global:error) 
            { 
            Write-Host "WARNING:     Unable to connect to Azure. Check your Internet connection and verify authentication details." -ForegroundColor Yellow
            Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
            Read-Host "`nPress 'ENTER'to exit the script........"
            exit
            }
        Write-Host "INFORMATION: Connected to Azure with provided authentication." -ForegroundColor Green 

        Set-AzContext -Subscription $dxcSubscriptionID -EA 0 -WA 0 >$null
        if ($global:error) 
            { 
            Write-Host "WARNING:     Invalid Subscription ID. Please make sure you have proper access to this Azure Subscription." -ForegroundColor Yellow 
            Utility-DisplayWarning -dxcstr1 "             Run the Powershell Command:" -dxcstr2 "Login-AzAccount -Subscription $dxcSubscriptionID" -dxcstr3 "and login with your authentication details."
            Write-Host "             If you get error, you have access issues with the subscription." -ForegroundColor Yellow
            
            Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
            Read-Host "`nPress 'ENTER'to exit the script........"
            exit 
            }
        }
        Utility-DisplayInfo -dxcstr1 "INFORMATION: Connected to Azure Subscription" -dxcstr2 $dxcSubscriptionID -dxcstr3 "with provided authentication."
    }

#========================================================================================================================
# FUNCTION TO LOGIN WITH az (WITH TENANTID)
#========================================================================================================================
Function Utility-LoginAZTenant
    {
    Param ($TenantId, $SubscriptionId)

    Set-AzContext -Subscription $SubscriptionID -Tenant $TenantId -EA 0 -WA 0 >$null

    if ($global:error) 
        { 
        $global:error.Clear()
        Write-Host "`nINFORMATION: Please login to Azure Resource Manager." -ForegroundColor Green
        Connect-AzAccount -WarningAction:Continue >$null
 
        if ($global:error) 
            { 
            Write-Host "WARNING:     Unable to connect to Azure. Check your Internet connection and verify authentication details." -ForegroundColor Yellow
            Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
            Read-Host "`nPress 'ENTER'to exit the script........"
            exit
            }
        Write-Host "INFORMATION: Connected to Azure with provided authentication." -ForegroundColor Green 

        Set-AzContext -Subscription $SubscriptionID -Tenant $TenantId -EA 0 -WA 0 >$null
        if ($global:error) 
            { 
            Write-Host "WARNING:     Invalid Subscription ID or TenantID. Please make sure you have proper access to this Azure Subscription." -ForegroundColor Yellow 
            Utility-DisplayWarning -dxcstr1 "             Run the Powershell Command:" -dxcstr2 "Login-AzAccount -Subscription $SubscriptionID -Tenant $TenantId" -dxcstr3 "and login with your authentication details."
            Write-Host "             If you get error, you have access issues with the subscription." -ForegroundColor Yellow
            
            Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
            Read-Host "`nPress 'ENTER'to exit the script........"
            exit 
            }
        }
        Utility-DisplayInfo -dxcstr1 "INFORMATION: Connected to Azure Subscription" -dxcstr2 $SubscriptionID -dxcstr3 "with provided authentication."
    }

#========================================================================================================================
# FUNCTION TO LOGIN WITH az (WITH SPN)
#========================================================================================================================
Function Utility-LoginAZSpn
    {
    Param ($TenantId, $SpnKey, $ClientId, $SubscriptionId)

	$error.Clear()
	$SecurePass = $SpnKey | ConvertTo-SecureString -AsPlainText -Force
	$dxcAzureEnv = Get-AzEnvironment 'AzureCloud'
	$cred = new-object -typename System.Management.Automation.PSCredential -argumentlist "$ClientId", $SecurePass
	$dxcOutput = Connect-AzAccount -Environment $dxcAzureEnv -Credential $cred -Tenant $TenantId -ServicePrincipal -Subscription $SubscriptionId
	
	if (!$dxcOutput)
		{
        Write-Host "ERROR:     Invalid Service Principal Key, ClientID, or TenantID. Please ensure proper access to this Azure Subscription." -ForegroundColor Yellow 
        Utility-DisplayWarning -dxcstr1 "           Run the Powershell Command:" -dxcstr2 "Connect-AzAccount -Environment AzureCloud -Credential YourCredentialVar -Tenant $TenantId" -dxcstr3 "to login with your Service Principal."
        Write-Host "          If an error occurs, there are issues with the Service Principal / Client / Tenant combination." -ForegroundColor Yellow
        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
		exit 5
        }
    Utility-DisplayInfo -dxcstr1 "INFORMATION: Connected to Azure Tenant" -dxcstr2 $TenantId -dxcstr3 "with provided authentication."
    }
	
#========================================================================================================================
# FUNCTION TO LOGIN WITH AZURE CLI
#========================================================================================================================
Function Utility-LoginAureCli
    {
    Param ($dxcSubscriptionId)

    Write-Host "`nINFORMATION: Please login to Azure with Azure CLI." -ForegroundColor Green
    $dxcOutput = az login --use-device-code | ConvertFrom-Json

    if (!$dxcOutput)  
        { 
        Write-Host "WARNING:     Unable to Login to Azure Subscription with Azure CLI." -ForegroundColor Yellow
        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        Read-Host "`nPress 'ENTER'to exit the script........"
        exit
        }
    az account set --subscription $dxcSubscriptionID
    Write-Host "INFORMATION: Connected to Azure with Azure CLI." -ForegroundColor Green	
    }

#========================================================================================================================
# FUNCTION TO LOGIN WITH AZURE CLI (WITH TENANTID)
#========================================================================================================================
Function Utility-LoginAureCliTenant
    {
    Param ($TenantId, $SubscriptionId)

    Write-Host "`nINFORMATION: Please login to Azure with Azure CLI." -ForegroundColor Green
    $dxcOutput = az login --tenant $TenantId --use-device-code | ConvertFrom-Json

    if (!$dxcOutput)  
        { 
        Write-Host "WARNING:     Unable to Login to Azure Subscription with Azure CLI. Check for proper TenantId and authentication details" -ForegroundColor Yellow
        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        Read-Host "`nPress 'ENTER'to exit the script........"
        exit
        }	
    az account set --subscription $SubscriptionId
    Write-Host "INFORMATION: Connected to Azure with Azure CLI." -ForegroundColor Green	
    }

#========================================================================================================================
# FUNCTION TO LOGIN WITH AZURE CLI (WITH SPN)
#========================================================================================================================
Function Utility-LoginAzureCliSpn
    {
	Param ($TenantId, $SpnKey, $ClientId, $SubscriptionId)

	$SecurePass = $SpnKey | ConvertTo-SecureString -AsPlainText -Force
	$cred = new-object -typename System.Management.Automation.PSCredential -argumentlist "$ClientId", $SecurePass
    $dxcOutput = az login --service-principal -u $cred.UserName -p $cred.GetNetworkCredential().Password --tenant $TenantId | ConvertFrom-Json

    if (!$dxcOutput)  
        { 
        Write-Host "ERROR:     Unable to Login to Azure Subscription with Azure CLI. Check for proper Service Principal and authentication details" -ForegroundColor Yellow
        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        exit 5
        }
    az account set --subscription $SubscriptionId
    Write-Host "INFORMATION: Connected to Azure with Azure CLI." -ForegroundColor Green	
    }

#========================================================================================================================
# FUNCTION TO GENERATE UNIQUE ID
#========================================================================================================================
Function Utility-GeneratingUniqueID
    {
    Param ($dxcResourceGroupName)
    [string]$dxctempJSON = "https://dxcazuretoolsdev.blob.core.windows.net/forautomation/UniqueStringGenerator.json"

    Write-Host "`nINFORMATION: Generating unique Id..." -ForegroundColor Green
    [String]$dxcRandom = (New-AzResourceGroupDeployment -Name "GeneratingUniqueID" -ResourceGroupName $dxcResourceGroupName -TemplateURI $dxctempJSON).Outputs.Values.value

    Utility-DisplayInfo -dxcstr1 "INFORMATION: Uniqie Id" -dxcstr2 $dxcRandom -dxcstr3 "generated."
    Return $dxcRandom
    }

#========================================================================================================================
Export-ModuleMember -Function 'Utility-*'
