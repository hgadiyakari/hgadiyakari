# Application Insights Alerts

This directory contains ARM templates and PowerShell scripts related to DXC Application Insights alerts deployment

alerts-appinsights.json - App Insights alert rules setup for LA/ServiceNow integration of App Insights resource monitoring. 
This alert json is not to be a part of onboarding as it has a dependency on an App Insight resource getting created beforehand as they are tightly coupled.

## Jira Epic
https://jira.dxc.com/browse/AZR-3679

## Deployment
For more information on Application Insights Alerts, please see section 3.39 of the Operations Guide

## Members of this directory are:
* alerts-appinsights-availability.json		Availability alerts
* alerts-appinsights-custommetrics.json		Custom Metrics alerts
* alerts-appinsights.json					App Insights alerts

## Authors
* Bang Bui
