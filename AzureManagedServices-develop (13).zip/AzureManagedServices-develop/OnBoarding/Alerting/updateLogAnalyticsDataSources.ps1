﻿#-----------------------------------------------------------[Comments]-------------------------------------------------------------
<#
.DOCUMENTATION LINK
https://confluence.dxc.com/display/CSA/AZR-12265+-+Provide+CloudOps+with+option+to+upgrade+existing+customers+to+enable+application+logs

.SYNOPSIS
This PowerShell script performs the update of data sources in Log Analytics based on the standard deployment template. 
This script also requires the following mandatory parameters -
- Subscription Id
- Log Analytics workspace name
Also, the template file - deployLogAnalytics.json is a default input to fetch the additional or updated data sources .

.EXAMPLES
 .\updateLogAnalyticsDataSources.ps1 -dxcSubscriptionId <SubscriptionId> -dxcLogAnalyticsWorkspaceName <LogAnalyticsWorkspaceName>

.REVISION HISTORY
    20-Feb-2020 - Initial script development
#>

#---------------------------------------------------------[Initializations]-------------------------------------------------------- 
[CmdletBinding()]
Param(
    [Parameter(HelpMessage = "Please enter the Subscription ID.", Position=1, Mandatory = $true, ValueFromPipeline = $true)]
    [ValidateNotNullOrEmpty()][string]$dxcSubscriptionId,
    [Parameter(HelpMessage = "Please enter the Log Analytics workspace name.", Position=2, Mandatory = $true, ValueFromPipeline = $true)]
    [ValidateNotNullOrEmpty()][string]$dxcLogAnalyticsWorkspaceName
)

#----------------------------------------------------------[Declarations]----------------------------------------------------------
$ErrorActionPreference = 'SilentlyContinue'
$dxcScriptName = "updateLogAnalyticsDataSources"
$global:LogFilePath = (Get-Item -Path .\ -Verbose).Fullname + '\' + $dxcScriptName + '-{0:dd-MMM-yyyy_HHmm}' -f (Get-Date) + '.log'
$dxcLogAnalyticsTemplate = '.\deployLogAnalytics.json'
$global:dataSourceKindInScope = 'WindowsEvent','AzureActivityLog','CustomLog', 'CustomLogCollection', 'LinuxPerformanceCollection', 'LinuxPerformanceObject', 'LinuxSyslog', 'LinuxSyslogCollection', 'WindowsPerformanceCounter' , 'ApplicationInsights'

#-----------------------------------------------------------[Functions]------------------------------------------------------------

function Write-Log { # This function writes script messages to active session and outputs to log file.
Param ([ValidateSet('Cyan','Gray','Green','Red','White','Yellow')][string]$logColor,
[string]$logText, [int]$logCode)

$logTimeStamp = Get-Date -Format MM-dd-yyyy-hh:mm:ss
switch ($logCode) {
    0 { Write-Output $logText | Tee-Object -FilePath $global:LogFilePath -Append | Out-Null;
        Write-Host -F $logColor $logText } # Use for general messages
    1 { Write-Output "$logTimeStamp INFO: $logText"| Tee-Object -FilePath $global:LogFilePath -Append | Out-Null;
        Write-Host -F $logColor "$logTimeStamp INFO: $logText" } # Use for Informational messages
    2 { Write-Output "$logTimeStamp ERROR: $logText"| Tee-Object -FilePath $global:LogFilePath -Append | Out-Null;
        Write-Host -F $logColor "$logTimeStamp ERROR: $logText" } # Use for Error messsages
    3 { Write-Output "$logTimeStamp WARN: $logText"| Tee-Object -FilePath $global:LogFilePath -Append | Out-Null;
        Write-Host -F $logColor "$logTimeStamp WARN: $logText" } # Use for Warning messages
}

}

function Run-PreChecks { # This function performs the required prerequisite checks.

# Check deployLogAnalytics.json
if (Test-Path -Path $dxcLogAnalyticsTemplate) {
    $global:dxcDataSourceFile = Get-Content $dxcLogAnalyticsTemplate | Out-String | ConvertFrom-Json
    Write-Log White "Successfully imported deployLogAnalytics.json." 1
} else {
    Write-Log Red "Unable to find/import Log Analytics template. Please ensure file is present in directory and/or path is correct." 2
    exit
}

}

function Get-AzCachedAccessToken { 
    if(-not (Get-Module Az.Accounts)) {
        Import-Module Az.Accounts
    }
    $azProfile = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile
    if(-not $azProfile.Accounts.Count) {
        Write-Error "Ensure you have logged in before calling this function."    
    }
  
    $currentAzureContext = Get-AzContext
    $profileClient = New-Object Microsoft.Azure.Commands.ResourceManager.Common.RMProfileClient($azProfile)
    Write-Debug ("Getting access token for tenant" + $currentAzureContext.Tenant.TenantId)
    $token = $profileClient.AcquireAccessToken($currentAzureContext.Tenant.TenantId)
    $token.AccessToken
}

function Get-AzBearerToken {
    ('Bearer {0}' -f (Get-AzCachedAccessToken))
}

function Update-DataSource { # Create/update Log Analytics datasource/s
Param($apiDataSource)

if ($global:dataSourceKindInScope -eq $apiDataSource.kind) {
    if ($apiDataSource.name -eq "AzureActivityLog") {
        $apiDataSource.properties.linkedResourceId = "/subscriptions/$dxcSubscriptionId/providers/Microsoft.Insights/eventTypes/management" }
    $dataSrc = ($apiDataSource.name).ToString()
    $requestUpdateUri = "https://management.azure.com/subscriptions/$dxcSubscriptionId/resourcegroups/$global:dxcWorkspaceResourceGroup/providers/Microsoft.OperationalInsights/workspaces/$global:dxcWorkspaceName/dataSources/$dataSrc`?api-version=2015-11-01-preview"
    $body = ($apiDataSource | Select-Object name,type,kind,properties | ConvertTo-Json -Depth 15)
    $armToken = Get-AzBearerToken

    $apiResponse = Invoke-WebRequest -Uri $requestUpdateUri `
            -Method PUT -ContentType "application/json" `
            -Body $body -Headers @{ Authorization ="$armToken"}`
            –UseBasicParsing -ErrorAction $ErrorActionPreference

    if ($apiResponse.StatusCode -eq 200) {
        $result = Get-AzOperationalInsightsDataSource -Workspace $global:dxcWorkspace -Name $apiDataSource.name -WA Ignore
        Write-Log Green ("Successfully updated datasource: " +  $apiDataSource.Name) 1
        Write-Log White ($result | Out-String) 0
    } else {
        Write-Log Red ("Failed to update datasource on " + $apiDataSource.Name + " on $global:dxcWorkspaceName. $error") 1
    }
} else {
    Write-Log Gray ($apiDataSource.Name + " update skipped.") 1
}

}
#-----------------------------------------------------------[Execution]------------------------------------------------------------

try {
$error.clear()

# Create the log file
New-Item $global:LogFilePath -ItemType File | Out-Null

Write-Log Yellow "Script execution started." 1

# Run prerequisite checks
Run-PreChecks 
if ($error) { Write-Log Red $error 2; exit }

# Login to Azure
Write-Log Cyan "Please login to Azure Resource Manager." 0
Connect-AzAccount -Subscription $dxcSubscriptionId | Out-Null
if ($error) { Write-Log "Unable to connect to Azure. Check your internet connection and verify authentication details." 1; exit }
Write-Log White "Connected to Azure with provided authentication." 1
Sleep 3

# Get workspace information
$dxcObjWorkspaces  = Get-AzOperationalInsightsWorkspace
foreach ($dxcObjWorkspace in $dxcObjWorkspaces) {
    if ($dxcObjWorkspace.Name -eq $dxcLogAnalyticsWorkspaceName) {
        $global:dxcWorkspace = $dxcObjWorkspace
        $global:dxcWorkspaceName = $dxcObjWorkspace.Name
        $global:dxcWorkspaceResourceGroup = $dxcObjWorkspace.ResourceGroupName
        Write-Log Cyan "Log Analytics workspace found: $global:dxcWorkspaceName." 1
        Write-Log White ($dxcObjWorkspace | Out-String) 0
        break
    }
}
    if (($global:dxcWorkspaceName -eq $null) -and ($global:dxcWorkspaceResourceGroup -eq $null)) { 
        Write-Log Red "Log Analytics workspace not found in this subscription. Please check if workspace name is correct." 2
        exit
    }

# Get the standard data sources from released workspace template
$dxcDataSources = ($global:dxcDataSourceFile.resources | ? {$_.type -eq 'Microsoft.OperationalInsights/workspaces'}).resources

# Determine which data sources to create/update
foreach ($dxcDataSource in $dxcDataSources) {
    if ($dxcDataSource.Name -ne "ApplicationLogs") { continue } # REMOVE THIS LINE TO UPDATE OTHER DATASOURCES.
    $checkDataSource = Get-AzOperationalInsightsDataSource -Workspace $global:dxcWorkspace -Name $dxcDataSource.Name
    if (!($checkDataSource)) {
        # Add if not existing
        Write-Log White ("Adding new datasource - " + $dxcDataSource.Name + " in $global:dxcWorkspaceName") 1
        Update-DataSource $dxcDataSource
            if ($error) { Write-Log Red ("Failed to update " + $dataSource.name + " in $global:dxcWorkspaceName. $error") 1 }
    } else {
        # Update/overwrite if existing
        Write-Log White ("Updating datasource - " + $dxcDataSource.Name + " in $global:dxcWorkspaceName") 1
        Update-DataSource $dxcDataSource
            if ($error) { Write-Log Red ("Failed to update " + $dataSource.name + " in $global:dxcWorkspaceName. $error") 1 }
    }
}

} catch {
Write-Log Red "Script executed with errors. $error." 2

} finally {
Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
Disconnect-AzAccount | Out-Null
Write-Log White "Disconnected from Resource Manager." 1
Write-Log Yellow "Script execution finished. Refer to log - $global:LogFilePath." 1

}
