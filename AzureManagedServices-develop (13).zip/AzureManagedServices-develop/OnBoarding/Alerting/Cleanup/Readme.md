﻿# Clean up

This folder contains a powershell script for removing Alerts specified in the varible section from one or multiple subscriptions

## Jira Epic
https://jira.dxc.com/browse/AZR-6927

## Deployment
For more information on this script see
https://confluence.dxc.com/display/CSA/AZR-6653+Automate+Removal+of+Deployed+Alerts

## Members of this directory are:
* removeAlerts.ps1	Removes Alerts specified in the varible section from one or multiple subscriptions

## Authors
* Santanu Sengupta