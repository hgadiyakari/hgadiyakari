<#
=========================================================================================================================
Required - Powershell Core 7.00 or higher and AZ Module Version 2.5.0 or higher
=========================================================================================================================
AUTHOR:  Santanu Sengupta 
DATE:    27/08/2019
Version: 1.1
Documentation: https://confluence.csc.com/pages/viewpage.action?pageId=170854099
=========================================================================================================================
.SYNOPSIS
    Removes Alerts specified in the varible section from one or multiple subscriptions.
.DESCRIPTION
    .PARAMETER  dxcSubscriptionIDs
		Specifies the Subscription ID of Subscription where the Alert is deployed. Multiple Subscription IDs can be specified seperating them by "Comma"
#>

[CmdletBinding(SupportsShouldProcess=$true)]
Param
    (
    [Parameter(Mandatory=$true)] [String]$dxcSubscriptionIDs
    )

#=====================================================================================================================
# CHECK ENVIRONMENT FOR NECESSERY MODULES
#=====================================================================================================================
$ModuleURL = "https://dxcazuretoolsdev.blob.core.windows.net/installers/DXCPowershellModules/DXCEnvCheck.psm1"
$LocalModule = $PSScriptRoot + "\DXCEnvCheck.psm1"
(New-Object System.Net.WebClient).DownloadFile($ModuleURL, $LocalModule)
Import-Module $LocalModule -WA 0
Remove-Item -Path $LocalModule

Check-AzModuleVersion -dxcAzModuleVersion 2.5.0

#=====================================================================================================================
# VARIABLE SECTION
#=====================================================================================================================
$ErrorActionPreference = "SilentlyContinue"
$dxcRemoveAlertList = @()
$dxcArraySubs = $dxcSubscriptionIDs.split(",")
$dxclogFile = "Alert Removal " + (Get-Date -Format "MM-dd-yyyy_hh-mm") + ".log"

#ADD THE LIST OF ALERTS THAT REQUIRES REMOVAL

$dxcRemoveAlertList += "DXC-Critical-Customer Activity Logs"
$dxcRemoveAlertList += "DXC-Critical-API Management Service-Total Gateway Requests"
$dxcRemoveAlertList += "DXC-Warning-API Management Service-Total Gateway Requests"
$dxcRemoveAlertList += "DXC-Critical-Application Gateway-Instance Stop"
$dxcRemoveAlertList += "DXC-Informational-Application Gateway-Instance Start"
$dxcRemoveAlertList += "DXC-Warning-Application Gateway-Instance Throughput Medium Limit"
$dxcRemoveAlertList += "DXC-Critical-App Service Plan-CPU Util"
$dxcRemoveAlertList += "DXC-Critical-App Service Plan-Mem Util"
$dxcRemoveAlertList += "DXC-Critical-ASR-Alert Condition"
$dxcRemoveAlertList += "DXC-Critical-ASR-Failover Initiated"
$dxcRemoveAlertList += "DXC-Warning-Resource-DXCDeploy tag missing"
$dxcRemoveAlertList += "DXC-Informational-Stack-CMDB-Update Availability Set"
$dxcRemoveAlertList += "DXC-Informational-Stack-CMDB-Update Load Balancer"
$dxcRemoveAlertList += "DXC-Informational-Stack-CMDB-Update Network Interface"
$dxcRemoveAlertList += "DXC-Informational-Stack-CMDB-Update Public IP Address"
$dxcRemoveAlertList += "DXC-Informational-Stack-CMDB-Update Resource Group"
$dxcRemoveAlertList += "DXC-Informational-Stack-CMDB-Update Deployment"
$dxcRemoveAlertList += "DXC-Informational-Stack-CMDB-Update Storage Account"
$dxcRemoveAlertList += "DXC-Informational-Stack-CMDB-Update Virtual Machine"
$dxcRemoveAlertList += "DXC-Informational-Stack-CMDB-Update Virtual Network"
$dxcRemoveAlertList += "DXC-Warning-Azure Stack"
$dxcRemoveAlertList += "DXC-Critical-Azure Stack"
$dxcRemoveAlertList += "DXC-Warning-Azure Stack Remediation"
$dxcRemoveAlertList += "DXC-Critical-Service Fabric Cluster-Unhealthy"
$dxcRemoveAlertList += "DXC-Critical-Physical Disk-Connectivity error"
$dxcRemoveAlertList += "DXC-Critical-Remote Service-Connectivity error"
$dxcRemoveAlertList += "DXC-Critical-Scale unit node offline"
$dxcRemoveAlertList += "DXC-Warning-Resource Provider-Health"
$dxcRemoveAlertList += "DXC-Critical-Resource Provider-Health"
$dxcRemoveAlertList += "DXC-Critical-Azure Bridge-Down"
$dxcRemoveAlertList += "DXC-Warning-Azure Bridge-Down"
$dxcRemoveAlertList += "DXC-Warning-Top-Of-Rack Switch Syslog"
$dxcRemoveAlertList += "DXC-Critical-Top-Of-Rack Switch Syslog Critical"
$dxcRemoveAlertList += "DXC-Critical-Top-Of-Rack Switch Syslog Emergency"
$dxcRemoveAlertList += "DXC-Critical-Top-Of-Rack Switch Syslog Error"
$dxcRemoveAlertList += "DXC-Critical-Top-Of-Rack Switch Syslog Alert"
$dxcRemoveAlertList += "DXC-Critical-Backup-Job Failure"
$dxcRemoveAlertList += "DXC-Informational-CMDB-Update PostgreSQL"
$dxcRemoveAlertList += "DXC-Informational-CMDB-Update Availability Set"
$dxcRemoveAlertList += "DXC-Informational-CMDB-Update Load Balancer"
$dxcRemoveAlertList += "DXC-Informational-CMDB-Update Network Interface"
$dxcRemoveAlertList += "DXC-Informational-CMDB-Update Public IP Address"
$dxcRemoveAlertList += "DXC-Informational-CMDB-Update Resource Group"
$dxcRemoveAlertList += "DXC-Informational-CMDB-Update Deployment"
$dxcRemoveAlertList += "DXC-Informational-CMDB-Update Storage Account"
$dxcRemoveAlertList += "DXC-Informational-CMDB-Update Virtual Machine"
$dxcRemoveAlertList += "DXC-Informational-CMDB-Update Virtual Network"
$dxcRemoveAlertList += "DXC-Informational-CMDB-Update SQL PaaS"
$dxcRemoveAlertList += "DXC-Informational-CMDB-Update Application Gateway"
$dxcRemoveAlertList += "DXC-Informational-CMDB-Update Key Vault"
$dxcRemoveAlertList += "DXC-Informational-CMDB-Update ExpressRoute Circuit"
$dxcRemoveAlertList += "DXC-Informational-CMDB-Update Web Apps"
$dxcRemoveAlertList += "DXC-Informational-CMDB-Update Application Insights"
$dxcRemoveAlertList += "DXC-Critical-Linux-Configuration file change"
$dxcRemoveAlertList += "DXC-Critical-CrowdStrike-Detection"
$dxcRemoveAlertList += "DXC-Critical-Linux-CrowdStrike SVC Stopped"
$dxcRemoveAlertList += "DXC-Critical-Windows-Crowdstrike SVC Uninstalled"
$dxcRemoveAlertList += "DXC-Critical-SymantecCWP-ConnectFail"
$dxcRemoveAlertList += "DXC-Critical-Crowdstrike SIEM-ConnectFail"
$dxcRemoveAlertList += "DXC-Critical-Automation Account-Job Failed or Suspended"
$dxcRemoveAlertList += "DXC-Critical-Windows OS-BSOD"
$dxcRemoveAlertList += "DXC-Critical-Windows OS-unexpected reboot"
$dxcRemoveAlertList += "DXC-Critical-Windows OS-Netlogon service"
$dxcRemoveAlertList += "DXC-Critical-Windows OS-NTFS Error"
$dxcRemoveAlertList += "DXC-Critical-Windows OS-Out of paged pool memory"
$dxcRemoveAlertList += "DXC-Critical-Windows OS-TCPIP failed"
$dxcRemoveAlertList += "DXC-Critical-Microsoft AAD Application Proxy Connector Event Log"
$dxcRemoveAlertList += "DXC-Critical-Directory Service Event Log"
$dxcRemoveAlertList += "DXC-Critical-Windows Server Failover Clustering Event Log"
$dxcRemoveAlertList += "DXC-Critical-ExpressRoute Circuit-Circuit network Utilization"
$dxcRemoveAlertList += "DXC-Critical-ExpressRoute Circuit-Connection network Utilization"
$dxcRemoveAlertList += "DXC-Critical-ExpressRoute Circuit-Utilization Metrics"
$dxcRemoveAlertList += "DXC-Warning-ExpressRoute Circuit-Configuration Failure"
$dxcRemoveAlertList += "DXC-Critical-ITSM Connector-Health"
$dxcRemoveAlertList += "DXC-Warning-Key Vault-Unauthorized access attempt"
$dxcRemoveAlertList += "DXC-Warning-Key Vault-Change in Access Policies"
$dxcRemoveAlertList += "DXC-Warning-Key Vault-Secret delete"
$dxcRemoveAlertList += "DXC-Warning-Key Vault-Latency delay"
$dxcRemoveAlertList += "DXC-Warning-LoadBalancer-Health Probe Status"
$dxcRemoveAlertList += "DXC-Critical-LoadBalancer-Health Probe Status"
$dxcRemoveAlertList += "DXC-Warning-PageFile-SwapFile"
$dxcRemoveAlertList += "DXC-Critical-PageFile-SwapFile"
$dxcRemoveAlertList += "DXC-Warning-Memory-Available"
$dxcRemoveAlertList += "DXC-Critical-Memory-Available"
$dxcRemoveAlertList += "DXC-Warning-Memory-Usage"
$dxcRemoveAlertList += "DXC-Critical-Memory-Usage"
$dxcRemoveAlertList += "DXC-Warning-Windows CPU-Threshold"
$dxcRemoveAlertList += "DXC-Critical-Windows CPU-Threshold"
$dxcRemoveAlertList += "DXC-Warning-Linux CPU-Threshold"
$dxcRemoveAlertList += "DXC-Critical-Linux CPU-Threshold"
$dxcRemoveAlertList += "DXC-Warning-Windows Volume-Free Space"
$dxcRemoveAlertList += "DXC-Critical-Windows Volume-Free Space"
$dxcRemoveAlertList += "DXC-Warning-Linux Volume-Used Space"
$dxcRemoveAlertList += "DXC-Critical-Linux Volume-Used Space"
$dxcRemoveAlertList += "DXC-Critical-Redis Cache-CPU Util"
$dxcRemoveAlertList += "DXC-Critical-Redis Cache-Server Load"
$dxcRemoveAlertList += "DXC-Critical-Redis Cache-Mem Util"
$dxcRemoveAlertList += "DXC-Critical-SymantecCWP-Linux-Detection"
$dxcRemoveAlertList += "DXC-Critical-SymantecCWP-Windows-Detection"
$dxcRemoveAlertList += "DXC-Critical-Linux-SymantecCWP SVC Stopped"
$dxcRemoveAlertList += "DXC-Critical-Windows-SecurityAgent SVC Stopped"
$dxcRemoveAlertList += "DXC-Critical-Windows-SecurityAgent SVC Didnt Start"
$dxcRemoveAlertList += "DXC-Critical-Windows-SymantecCWP SVC Uninstalled"
$dxcRemoveAlertList += "DXC-Warning-Database Managed Instance-CPU Consumption"
$dxcRemoveAlertList += "DXC-Critical-Database Managed Instance-CPU Consumption"
$dxcRemoveAlertList += "DXC-Critical-Database Managed Instance-Storage Consumption"
$dxcRemoveAlertList += "DXC-Warning-Database-DTU Consumption"
$dxcRemoveAlertList += "DXC-Critical-Database-DTU Consumption"
$dxcRemoveAlertList += "DXC-Critical-Database-Deadlocks"
$dxcRemoveAlertList += "DXC-Critical-Database-Failed Connections"
$dxcRemoveAlertList += "DXC-Critical-Database-Storage Consumption"
$dxcRemoveAlertList += "DXC-Warning-Database-Sev0-16 Error"
$dxcRemoveAlertList += "DXC-Critical-Database-Sev17plus Error"
$dxcRemoveAlertList += "DXC-Warning-Database-Process Blocks"
$dxcRemoveAlertList += "DXC-Critical-Database-Elastic-Pool-DTU Consumption"
$dxcRemoveAlertList += "DXC-Critical-Database-Elastic-Pool-Storage Consumption"
$dxcRemoveAlertList += "DXC-Critical-SQL VM-Database Error"
$dxcRemoveAlertList += "DXC-Warning-SQL VM-Database Warning"
$dxcRemoveAlertList += "DXC-Critical-Traffic Manager Profile-has been disabled"
$dxcRemoveAlertList += "DXC-Critical-Traffic Manager Profile-Endpoint monitoring health checks are failing"
$dxcRemoveAlertList += "DXC-Critical-Traffic Manager Profile-Endpoint cloud service or web app is not running"

#=====================================================================================================================
# LOGIN SECTION
#=====================================================================================================================
Write-Host "`nINFORMATION: Please login to Azure Resource Manager." -ForegroundColor Green
$error.Clear()
Connect-AzAccount

if ($error) 
    { 
    Write-Host "WARNING:     Unable to connect to Azure. Check your internet connection and verify authentication details." -ForegroundColor Yellow
    Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
    exit 
    }
Write-Host "INFORMATION: Connected to Azure with provided authentication." -ForegroundColor Green 

#=====================================================================================================================
# MAIN BODY
#=====================================================================================================================
if ($dxcRemoveAlertList -match '\*')
    {
    Write-Host "WARNING:     One or more Alert Rule name contains wildcard character (*). Running wildcard character is not supported. Terminating the script." -ForegroundColor Yellow
    Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
    exit
    }

foreach ($dxcSubscriptionID in $dxcArraySubs)
    {
    $error.Clear()
    $dxcSubscriptionID = $dxcSubscriptionID.Trim()
    Write-Host "############################################################################################"
    "############################################################################################" | Out-File $dxclogFile -Append
    Set-AzContext -Subscription $dxcSubscriptionID -EA SilentlyContinue -WA SilentlyContinue >$null

    if ($error) 
        { 
        Write-Host $dxcSubscriptionID -NoNewline
        Write-Host " - Invalid Subscription ID or No access to the Subscription." -ForegroundColor Yellow 
        Write-Host "`n############################################################################################"
        $dxcSubscriptionID + "- Invalid Subscription ID or No access to the Subscription." | Out-File $dxclogFile -Append
        "`n############################################################################################" | Out-File $dxclogFile -Append
        }
    else
        {
        Write-Host "Connected to Subscription:" -NoNewline -ForegroundColor Green
        Write-Host $dxcSubscriptionID
        Write-Host "############################################################################################"
        "Connected to Subscription: " + $dxcSubscriptionID| Out-File $dxclogFile -Append
        "############################################################################################" | Out-File $dxclogFile -Append

        ForEach ($dxcRemoveAlert in $dxcRemoveAlertList)
            {
            $error.Clear()
            $dxcAlertRules = @()
            $dxcRemoveAlert = $dxcRemoveAlert.Trim()
            $dxcAlertRules = Get-AzResource -ResourceType microsoft.insights/scheduledQueryRules -Name $dxcRemoveAlert -WA 0 -EA 0
        
            if ($dxcAlertRules.Count -gt 0)
                {
                foreach ($dxcAlertRule in $dxcAlertRules)
                    { 
                    $Error.Clear()
                    Remove-AzResource -ResourceId $dxcAlertRule.ResourceId -Force >$null
                    If ($Error)
                        {
                        Write-Host "Couldn't delete Alert Rule: " -NoNewline -ForegroundColor Yellow
                        Write-Host $dxcAlertRule.Name -NoNewline
                        Write-Host " in ResourceGroup: " -NoNewline -ForegroundColor Yellow
                        Write-Host $dxcAlertRule.ResourceGroupName
                        "Couldn't delete Alert Rule: " + $dxcAlertRule.Name + "in ResourceGroup:" + $dxcAlertRule.ResourceGroupName | Out-File $dxclogFile -Append
                        }
                    else
                        {
                        Write-Host "Successfully deleted Alert Rule: " -NoNewline -ForegroundColor Green
                        Write-Host $dxcAlertRule.Name -NoNewline
                        Write-Host " in ResourceGroup: " -NoNewline -ForegroundColor Green
                        Write-Host $dxcAlertRule.ResourceGroupName
                        "Successfully deleted Alert Rule: " + $dxcAlertRule.Name + "in ResourceGroup:" + $dxcAlertRule.ResourceGroupName | Out-File $dxclogFile -Append
                        }
                    }
                }
            else
                {
                Write-Host "Alert Rule: " -NoNewline -ForegroundColor Green
                Write-Host $dxcRemoveAlert -NoNewline
                Write-Host " not found in this subscription." -ForegroundColor Green
                "Alert Rule: " + $dxcRemoveAlert + "not found in this subscription." | Out-File $dxclogFile -Append
                }
            }
        }
    }
"################################ END OF SCRIPT EXECUTION ###################################" | Out-File $dxclogFile -Append   
