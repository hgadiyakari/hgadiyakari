#=====================================================================================================================
# DOCUMENTATION LINK
# https://confluence.dxc.com/display/CSA/AZR-12228+Create+function+app+for+SNOW+Connectivity+Alerting
#=====================================================================================================================

[CmdletBinding(SupportsShouldProcess=$true)]
Param
    (
    [Parameter(Mandatory=$true)] [String]$SubscriptionId,
    [Parameter(Mandatory=$true)] [String]$TenantId,
    [Parameter(Mandatory=$true)] [String]$LogAnalyticsWorkspaceName,
    [Parameter(Mandatory=$true)] [String]$KeyVaultName,
    [Parameter(Mandatory=$true)] [String]$ServiceNowURL,
	[Parameter(Mandatory=$false)] [String]$SpKey,
	[Parameter(Mandatory=$false)] [String]$ClientID
    )
#=====================================================================================================================
# IMPORTCUSTOM MODULES AND CHECK ENVIRONMENT FOR NECESSERY MODULES
#=====================================================================================================================
$dxcModuleList = "DXCEnvCheckV2.psm1", "DXCUtilityFunctions.psm1", "DXCFunctionDeploymentsV1.psm1"

foreach ($dxcModule in $dxcModuleList)
    {
    [String]$dxcModuleURL = "https://dxcazuretoolsdev.blob.core.windows.net/installers/DXCPowershellModules/" + $dxcModule
    [String]$dxcLocalModule = "C:\Users\ssengupta22\OneDrive - DXC Production\Scripts\FunctionApp\SNOWConnectionMonitoringAlertDeployment\$dxcModule"
    [String]$dxcLocalModule = $PSScriptRoot + "\" + $dxcModule
    (New-Object System.Net.WebClient).DownloadFile($dxcModuleURL, $dxcLocalModule)
    Import-Module $dxcLocalModule -WA 0
    Remove-Item -Path $dxcLocalModule
    }

$dxcPSCore = Check-PSCore -Version 7.0.0
if ($dxcPSCore) { $dxcAZ = Check-AzModule -Version 2.5.0 }
if ($dxcAZ) { $dxcAZResources = Check-PSModule -Name "Az.Resources" -Version 1.6.1 }
if ($dxcAZResources) { $dxcAZFunctions = Check-PSModule -Name "Az.Functions" -Version 1.0.1 }
if ($dxcAZFunctions) { $dxcAZKeyvault = Check-PSModule -Name "Az.KeyVault" -Version 1.3.0 }
if ($dxcAZKeyvault) { $dxcAZStorage = Check-PSModule -Name "Az.Storage" -Version 1.5.1 }
if ($dxcAZStorage) { $dxcAZWebsites = Check-PSModule -Name "Az.Websites" -Version 1.5.1 }
if ($dxcAZWebsites) { $dxcAZApplicationInsights = Check-PSModule -Name "Az.ApplicationInsights" -Version 1.0.3 }
if ($dxcAZApplicationInsights) { $dxcAZOperationalInsights = Check-PSModule -Name "Az.OperationalInsights" -Version 1.3.2 }
if($dxcAZApplicationInsights){$dxcAZResource = Check-PSModule -Name "Az.Resources" -Version 3.2.0 }
if (!$dxcAZResource)
    {
    Read-Host "`nPress 'ENTER'to exit the script........"
    exit
    }
    
#=====================================================================================================================
# LOGIN SECTION
#=====================================================================================================================
if ($SpKey) {
    Utility-LoginAZSpn -TenantId $TenantId -SpnKey $SpKey -ClientId $ClientID -SubscriptionId $SubscriptionId
    Utility-LoginAzureCliSpn -TenantId $TenantId -SpnKey $SpKey -ClientId $ClientID -SubscriptionId $SubscriptionId
}
else {
    Utility-LoginAZTenant -TenantId $TenantId -SubscriptionId $SubscriptionId
    Utility-LoginAureCliTenant -TenantId $TenantId -SubscriptionId $SubscriptionId
}

#=====================================================================================================================
# VARIABLE SECTION
#=====================================================================================================================
$ErrorActionPreference = "SilentlyContinue"
$WarningPreference = "SilentlyContinue"
[String]$itsmuserURI = (get-azkeyvaultsecret -vaultname $KeyVaultName -name itsmintegrationuser).id
[String]$itsmpassURI = (get-azkeyvaultsecret -vaultname $KeyVaultName -name itsmintegrationpass).id
[String]$dxcEventProcessingSchema = "3.0"
[String]$dxcFunctionAppRGName = "dxc-automation-rg"
[String]$dxcFunctionName = "EndToEndSNOWConnectivity"
[String]$dxcTeamsNotificationURL = "https://outlook.office.com/webhook/8806c95a-dbd8-47f8-8386-4ed6947e025f@93f33571-550f-43cf-b09f-cd331338d086/IncomingWebhook/e7b2b2376e2a4b3e8ff1ae68b79cb9fe/27b9fc4d-0529-4a11-a230-72f2fc44ccf4"
if (-not( $ServiceNowURL.substring($ServiceNowURL.length -1) -eq "/")) { $ServiceNowURL = $ServiceNowURL + "/" }

[String]$SourceCodeFileName = "TimeTrigger-FunctionCode.ps1"
[String]$dxcTimeTriggerSchedule = '0 15 * * * *' # 15th minute of every hour in UTC.
[Hashtable]$dxcAppSettings = @{ 'SNOW_URI' = $ServiceNowURL;
                                'KEYVAULT_NAME' = $KeyVaultName;
                                'WORKSPACE_NAME' = $LogAnalyticsWorkspaceName;
                                'ITSMIntegrationUser' = "@Microsoft.KeyVault(SecretUri=$itsmuserURI)";
                                'ITSMIntegrationPass' = "@Microsoft.KeyVault(SecretUri=$itsmpassURI)";
                                'TEAMS_NOTIFICATION_URL' = $dxcTeamsNotificationURL;
                                'EVENT_PROCESSING_SCHEMA' = $dxcEventProcessingSchema
                              }
                             
#========================================================================================================================
# MAIN BODY OF THE SCRIPT
#========================================================================================================================
#Collect Maintenance ResourceGroup Details.
$dxcObjWorkspace = Get-AzOperationalInsightsWorkspace | Where-Object { $_.Name -Match $LogAnalyticsWorkspaceName }
If ($dxcObjWorkspace)
    {
    [String]$dxcResourceGroup = $dxcObjWorkspace.ResourceGroupName
    [String]$dxcWorkspaceRegion = (($dxcObjWorkspace.location).ToLower()) -replace '\s',''
    [String]$dxcFunctionAppIdentityScope = '/subscriptions/' + $SubscriptionId + '/resourceGroups/' + $dxcResourceGroup

    Utility-DisplayInfo -dxcstr1 "INFORMATION: Loganalytics Workspace named" -dxcstr2 $LogAnalyticsWorkspaceName -dxcstr3 "located under ResourceGroup" -dxcstr4 $dxcResourceGroup
    }
else
    {
    Write-Host "WARNING:     Loganalytics Workspace not found. Please enter correct workspace name while running the script." -ForegroundColor Yellow
    Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
    Read-Host "`nPress 'ENTER'to exit the script........"
    exit
    }

#Collect KeyVault Details.
$dxcObjKV = Get-AzKeyVault -VaultName $KeyVaultName

If ($dxcObjKV) { Utility-DisplayInfo -dxcstr1 "INFORMATION: KeyVault named" -dxcstr2 $dxcObjKV.VaultName -dxcstr3 "located under ResourceGroup" -dxcstr4 $dxcObjKV.ResourceGroupName }
else
    {
    Write-Host "WARNING:     KeyVault not found. Please enter correct KeyVault name while running the script." -ForegroundColor Yellow
    Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
    Read-Host "`nPress 'ENTER'to exit the script........"
    exit
    }
	
Write-Host "`n##########################################################"
Write-Host "STAGE1: RESOURCEGROUP DEPLOYMENT SECTION"
Write-Host "##########################################################"

$dxcRGExtsts, $dxcobjRG = Deploy-ResourceGroup -Location $dxcWorkspaceRegion -Name $dxcFunctionAppRGName  -DeletionLock

if (!$dxcobjRG)
    {
    Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
    Read-Host "`nPress 'ENTER'to exit the script........"
    exit
    }

[String]$dxcRandom = Utility-GeneratingUniqueID -dxcResourceGroupName $dxcFunctionAppRGName
[String]$dxcStorageAccountName = 'dxce2e' + $dxcRandom + 'sa'
[String]$dxcAppServicePlan = 'dxc-FuncAppB1-' + $dxcRandom + '-ASP'
[String]$dxcFunctionAppName = 'dxc-SNOWConnectionMonitoring-' + $dxcRandom + '-FA'
[String]$dxcAppInsightName = 'dxc-FuncApp-' + $dxcRandom + '-AI'

Write-Host "`n##########################################################"
Write-Host "STAGE2: STORAGE ACCOUNT DEPLOYMENT SECTION"
Write-Host "##########################################################"
$error.Clear()
$dxcStorageExists, $dxcObjStorage = Deploy-StorageAccount -Location $dxcWorkspaceRegion -ResourceGroupName $dxcFunctionAppRGName -Name $dxcStorageAccountName -Container "None" -Table "None" -Queue "None" -Blobfiles "None"

if (!$dxcObjStorage)
    {
    Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
    Read-Host "`nPress 'ENTER'to exit the script........"
    exit
    }
  
Write-Host "`n##########################################################"
Write-Host "STAGE3: FUNCTIONAPP DEPLOYMENT AND CONFIGURATION SECTION"
Write-Host "##########################################################"

$dxcFunctionAppExists, $dxcObjFunctionApp = Deploy-FunctionApp -SubscriptionId $SubscriptionId  -Location $dxcWorkspaceRegion -ResourceGroupName $dxcFunctionAppRGName -FunctionAppName $dxcFunctionAppName -StorageAccountName $dxcStorageAccountName -AppServicePlanName $dxcAppServicePlan -Sku "B1" -AppInsightsName $dxcAppInsightName -OSType "Windows" -Runtime "powershell" -RuntimeVersion "7.0" -FunctionVersion 3 -AppSettings $dxcAppSettings
$dxcObjFunctionApp = Get-AzFunctionApp -ResourceGroupName $dxcFunctionAppRGName -Name $dxcFunctionAppName
If ($dxcObjFunctionApp) {
    [bool]$FunctionAppExists = $true

}
else {
    [bool]$FunctionAppExists = $false
    Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
    Read-Host "`nPress 'ENTER'to exit the script........"
    exit
    }

Write-Host "`n###############################################################"
Write-Host "STAGE4: FUNCTIONAPP ACCESS SETTINGS"
Write-Host "###############################################################`n"

If($dxcFunctionAppExists) { 
                    
                    Set-AzWebApp -AssignIdentity $true -Name $dxcFunctionAppName -ResourceGroupName $dxcFunctionAppRGName
                    $objectId=$(az webapp identity assign --name $dxcFunctionAppName --resource-group $dxcFunctionAppRGName --query principalId)
                    az keyvault set-policy --name $KeyVaultName --object-id $objectId --secret-permissions get list
                    Write-Host "INFORMATION: Skipping Access section as the FunctionApp already exists." -ForegroundColor Green }
else
    {
    #Provide "Reader" Access to Subscription
    deploy-RBACRule -FunctionAppName $dxcFunctionAppName -ResourceGroupName $dxcFunctionAppRGName -Scope $dxcFunctionAppIdentityScope -RoleDefinitionName "Reader"

    #Provide necessery KeyVault Access
    $dxcKVAccess = Set-AzKeyVaultAccessPolicy -VaultName $KeyVaultName -ObjectId $dxcObjFunctionApp.IdentityPrincipalId -PermissionsToSecrets Get -PassThru
    if (!$dxcKVAccess) 
        { 
        Write-Host "WARNING:     Unable to add 'Get' access in KeyVault for the FunctionApp System Assigned Identity. You may not have necessery rights to the KeyVault." -ForegroundColor Yellow
        Write-Host "             For the FunctionApp to perform its task, you need to manually assign this permission." -ForegroundColor Yellow
        Write-Host "             The script will continue its deployment now." -ForegroundColor Yellow
        }
    Else { Utility-DisplayInfo -dxcstr1 "INFORMATION: FunctionApp" -dxcstr2 $dxcFunctionAppName -dxcstr3 "has been provided 'Get' access to the KeyVault" -dxcstr4 $KeyVaultName }
    }
  
  
Write-Host "`n##########################################################"
Write-Host "STAGE5: FUNCTIONAPP SECURITY AND FUNCTION DEPLOYMENT SECTION"
Write-Host "##########################################################`n"

$dxcDeployFunction = deploy-TimeTriggerFunction -FunctionAppName $dxcFunctionAppName -ResourceGroupName $dxcFunctionAppRGName -Location $dxcWorkspaceRegion -FunctionName $dxcFunctionName -SourceCodeFileName $SourceCodeFileName -Schedule $dxcTimeTriggerSchedule

if (!$dxcDeployFunction) 
    { 
    Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
    Read-Host "`nPress 'ENTER'to exit the script........"
    Exit
    }

#Apply Security Settings
deploy-FunctionAppSecurity -FunctionAppName $dxcFunctionAppName -ResourceGroupName $dxcFunctionAppRGName -Location $dxcWorkspaceRegion -AppServiceAuthOn -HTTPSOnly -HTTP20Enabled -FTPDisabled
######## Update Tags For AI, ASP, storage account #########

$dxcTags = @{
    "dxcManaged" = "True"
    "dxcMonitored" = "False"
    "dxcConfigurationCheck" = ([System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId((Get-Date), 'UTC')).ToString("yyyyMMddTHHmmssZ")
}

$resources = $dxcAppServicePlan, $dxcAppInsightName
foreach ($functionresources in $resources) { 
    Update-AzTag -ResourceId (Get-AzResource -Name $functionresources).ResourceId -Tag $dxcTags -Operation Merge
}

$MonitorTags = @{
    "dxcManaged" = "True"
    "dxcMonitored" = "True"
    "dxcConfigurationCheck" = ([System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId((Get-Date), 'UTC')).ToString("yyyyMMddTHHmmssZ")
}

$monitoredresources = $dxcStorageAccountName,$dxcFunctionAppName
foreach ($monitoredresource in $monitoredresources)
{
    Update-AzTag -ResourceId (Get-AzResource -Name $monitoredresource).ResourceId -Tag $MonitorTags -Operation Merge
}


Write-Host "`n##########################################################"
Write-Host "STAGE6: FUNCTIONAPP ALERT DEPLOYMENT SECTION"
Write-Host "##########################################################`n"

Utility-DisplayInfo -dxcstr1 "INFORMATION: Run the below command in powershell 7.x console, from" -dxcstr2 "...\OnBoarding\Alerting\FunctionAppAlertDeployment\" -dxcstr3 "folder to deploy alerts for this FunctionApp"
Write-Host ".\deployFunctionAppAlerts.ps1 -functionAppName $dxcFunctionAppName -appInsightsName $dxcAppInsightName -logAnalyticsWorkspaceName $LogAnalyticsWorkspaceName -subscriptionId $SubscriptionId"

Write-Host "`n*****************End OF SCRIPT EXECUTION*****************"
