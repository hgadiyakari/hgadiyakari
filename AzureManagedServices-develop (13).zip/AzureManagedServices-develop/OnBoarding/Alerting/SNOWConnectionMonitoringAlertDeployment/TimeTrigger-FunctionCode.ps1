param($Timer)

#SET ENVIRONMENT
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12;
Set-Item -Path Env:\SuppressAzurePowerShellBreakingChangeWarnings -Value $true

#VARIABLE DECLERATION
[String]$dxcSnowUrl = $env:SNOW_URI
[String]$dxcKeyVaultName = $env:KEYVAULT_NAME
[String]$dxcworkspaceName = $env:WORKSPACE_NAME
[String]$dxcTeamsNotificationURL = $env:TEAMS_NOTIFICATION_URL
[String]$dxcEventProcessingSchema = $env:EVENT_PROCESSING_SCHEMA
[String]$dxcSnowUser = $env:ITSMIntegrationUser
[String]$dxcSnowPassword = $env:ITSMIntegrationPass

[String]$dxcEventFilter = "api/now/table/em_event?sysparm_query=ORDERBYDESCsys_created_on&source=OMS&type=Availability&node=" + $dxcworkspaceName + "&sysparm_limit=1"
[String]$dxcURI = $dxcSnowUrl + $dxcEventFilter

$Requests = $null
$dxcStatusCode = $null
$TeamsNotificationMessage = $null
$dxcSubscription = (Get-AzContext).Subscription  

#VERIFY TEAMS CHENNAL 
if (!$dxcTeamsNotificationURL) { Write-Warning "Teams notification channel URL is not defined."; exit }

#VERIFY WORKSPACE DETAILS
$dxcObjWorkspace = Get-AzOperationalInsightsWorkspace | ? { $_.Name -Match $dxcworkspaceName }
If ($dxcObjWorkspace)
    {
    [String]$dxcworkspaceResourceId = $dxcObjWorkspace.ResourceId
    [String]$dxcworkspaceName = $dxcObjWorkspace.Name
    }
else { Write-Warning "Loganalytics Workspace $($dxcworkspaceName) not found or inaccessable."; exit }

#SET CREDENTIALS
If( $dxcSnowUser -and $dxcSnowPassword)
    {
    $dxcSnowPasswordSecure = $dxcSnowPassword | ConvertTo-SecureString -asPlainText -Force 
    $SNowCreds = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $dxcSnowUser, $dxcSnowPasswordSecure 
    }
else { Write-Warning "Couldn't fetch Service Now credentials from $($dxcKeyVaultName) , required keys not found."; exit }

#PULL LATEST EVENT
$Error.Clear()

$Requests = 
try {
    Invoke-RestMethod -Uri $dxcURI -Credential $SNowCreds -Method GET -ContentType "application/json"
    } 
catch 
    {
    $dxcStatusCode = $_.Exception.Response.StatusCode.value__ 
    $dxcStatusMessage = $_.Exception.Message
    }

If ($dxcStatusCode -ge 400)
    {  
    Write-Error "Service Now API call status: $dxcStatusMessage "
  
    #SENT TEAMS NOTIFICATION
    $notification = ConvertTo-Json -Depth 4 @{
            text = "Service Now API call status: " + $dxcStatusMessage
                sections = @(
                    @{
                    facts = @(  
                        @{
                        name = "Subscription Name:"
                        value = $($dxcSubscription.Name)
                        },
                        @{
                        name = "Subscription Id:"
                        value = $($dxcSubscription.Id)
                        },
                        @{
                        name = "LogAnalytics Workspace:"
                        value = $($dxcworkspaceName)
                        })
                    })
            }
     Invoke-RestMethod -Uri $dxcTeamsNotificationURL -Method "Post" -Body $notification -ContentType "application/json"
     Exit
     } 

If (!$Requests) {  Write-Error "No Event found in event table."; Exit } 

[datetime]$eventGenarationTime = $Requests.Result.sys_created_on
[datetime]$presentTime = (Get-Date).ToUniversalTime()
[int]$TimeGapInMinutes = ($presentTime - $eventGenarationTime).TotalMinutes
Write-Host "Last End-To-End information event reached Service Now $($TimeGapInMinutes) minutes back."

If ((!$eventGenarationTime) -or ($TimeGapInMinutes -gt 65))
    {  
    Write-Host "Events from Azure not reaching Service Now. Threshold of 65 minutes delay breached."

    #SENT TEAMS NOTIFICATION
    $notification = ConvertTo-Json -Depth 4 @{
            text = "DXC-Critical-Service Now Connectivity is down..."
                sections = @(
                    @{
                    facts = @(  
                        @{
                        name = "Subscription Name:"
                        value = $($dxcSubscription.Name)
                        },
                        @{
                        name = "Subscription Id:"
                        value = $($dxcSubscription.Id)
                        },
                        @{
                        name = "LogAnalytics Workspace:"
                        value = $($dxcworkspaceName)
                        })
                    })
            }
     Invoke-RestMethod -Uri $dxcTeamsNotificationURL -Method "Post" -Body $notification -ContentType "application/json"
       
    #SEND WEBHOOK ALERT TO SNOW
    $dxcEventDescription = @"
Alert : DXC-Critical-SNOW connectivily is Down
Description : End-To-End information events are not reaching Service Now event table. Either the alert has been disabled/deleted or the ITSM connector is down.
TimeGenerated : $($presentTime)
SubscriptionId : $($dxcSubscription.Id)
Resource : $($dxcworkspaceName)
ResourceId : $($dxcworkspaceResourceId)
eventType : Availability
eventResource : SNOW Connectivity
eventFormat : WebHook
eventProcessingSchema : $($dxcEventProcessingSchema)
"@
           
    $dxcEventBody = 
    @{
    source = "OMS"
    severity = "1"            
    type = "Availability"
    resource = "SNOW Connectivity"
    event_class = "WebHook"
    node = $dxcworkspaceName
    description = $dxcEventDescription
    }

    $dxcCredPair = "$($dxcSnowUser):$($dxcSnowPassword)"
    $dxcEncodedCred = [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes($dxcCredPair))
    $dxcHeaders = 
        @{
        'Authorization' = "Basic $($dxcEncodedCred)"
        'Content-Type' = "application/json"
        'Accept' = "application/json"
        }
    $dxcJSONBody = $dxcEventBody | ConvertTo-Json
    
    $dxcResponse = 
    try 
        { 
        (Invoke-Webrequest -Uri $dxcURI -Header $dxcHeaders -Method POST -Body $dxcJSONBody -ErrorAction Stop).BaseResponse 
        } 
    catch [System.Net.WebException] 
        { 
        Write-Error "An exception was caught while processing Sercive Now connectivity down alert for $($dxcworkspaceResourceId) .Message: $($_.Exception.Message)"
        $_.Exception.Response 
        } 
    $dxcStatusCodeInt = [int]$Response.BaseResponse.StatusCode
    Write-Host "Status Code: $($dxcStatusCodeInt)"
    }