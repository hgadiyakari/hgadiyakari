# Alerts Directory

This folder contains OMS ARM Templates and Automation Scripts required for deploying OMS Workspaces & alerts

## Jira Epic
N/A

## Deployment
For more information on how to deploy the contents of this directory itself please see:
* See section 3.3.3 of Operations Guide for more details

## Members of this directory are:
* Numerous Alert json files are executed by main powershell script

* deployAlerts.ps1			Main script to deploy all alerts in this directory to an OMS Workspace
* deployITSMActionGroup		Deploys ITSM Action Group in OMS workspace

## Authors
* Azure Engineering Team
