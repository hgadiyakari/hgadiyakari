# Input bindings are passed in via param block.
param([string] $QueueItem, $TriggerMetadata)

Import-Module DXC-FuncAppUtils
Import-Module DXC-HBUtils

# Write out the queue message and insertion time to the information log.
Write-Host "PowerShell queue trigger function processed work item: $QueueItem"
Write-Host "Queue item insertion time: $($TriggerMetadata.InsertionTime)"
Write-Information ($TriggerMetadata | ConvertTo-JSON)
Write-Information $TriggerMetadata.QueueTrigger.ResourceId

$AlertData = $TriggerMetadata.QueueTrigger
$AlertReport = Get-VMReport -ResourceId $AlertData.ResourceId
Write-Information "## Report returned from Get-VMReport:"
Write-Information ($AlertReport| ConvertTo-Json | Out-String)
$AlertResults = Test-VMReport -Report $AlertReport
Write-Information "## Alert Assessment returned from Test-VMReport" 
Write-Information ($AlertResults | ConvertTo-Json | Out-String)

# Send triaged positive alert notifications to Teams
if ($ENV:AlertMode -Match "notify") {
    if ($AlertResults.AlertState -eq $true) {
        if ($ENV:TeamsNotificationURL){
            Send-TeamsHBAlertNotification -AlertResults $AlertResults -ChannelURL $env:TeamsNotificationURL
        } else {
            Write-Warning "Teams notification channel URL is not defined"
        }
    }
}

# Send triaged positive alerts to Service Now
if ($ENV:AlertMode -Match "alert") {
    if ($AlertResults.AlertState -eq $true) {
        if ($ENV:ServiceNowUrl){
            Write-Information "Dispatching alert to Service Now"
            Send-SNOWHBEvent -AlertData $AlertData -AlertResults $AlertResults
        } else {
            Write-Warning "Service Now URL is not defined"
        }
    }
}

# Send details of all tested Heartbeat alerts to Log Analytics
if ($ENV:AlertMode -Match "log") {
    $workspace = Get-AzOperationalInsightsWorkspace -ResourceGroupName $ENV:LogAnalyticsWorkspaceResourceGroup -Name $ENV:LogAnalyticsWorkspaceName
    $primaryKey = ($workspace | Get-AzOperationalInsightsWorkspaceSharedKeys).PrimarySharedKey
    $logType = "HeartbeatAlertLog"
    $jsonBody = $AlertResults | ConvertTo-Json
    Write-Information "Sending Log Entry to Workspace $($workspace.CustomerId)"
    Write-Information $jsonbody
    $LAResponseCode = Send-LogAnalyticsData -customerId $workspace.CustomerId -sharedKey $primaryKey -body ([System.Text.Encoding]::UTF8.GetBytes($jsonBody)) -logType $logType
    Write-Information "Log Analytics response code: $LAResponseCode"
}

