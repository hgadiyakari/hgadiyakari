function Test-CASSchemaPresent {
    <#
    .SYNOPSIS
        Tests a powershell object to see if it conforms to the Common Alert Schema
    .DESCRIPTION
        Common Alert Schema is an Azure Monitor ALert format to convey alert data
        in a standardised way. This function tests if the SchemaId member is set
    .EXAMPLE
        PS:/> Test-CASSchemaPresent -Body $BodyObject
        Determines if the PSObject $BodyObject has SchemaId set to "azureMonitorCommonAlertSchema"
    .INPUTS
        $Body object derived from a JSON Azure Monitor Alert payload
    .OUTPUTS
        $true if the object has a SchemaId corresponding to the CAS
    .NOTES
        A superficial check to confirm the SchemaId is present and correct
        (C) DXC Technology 2020
    #>
    [CmdletBinding()]
    [OutputType([boolean])]
    param (
        [parameter(Mandatory = $true)]
        [Object]
        $Body
    )
    process {
        Write-Debug "## Test-CASSchemaPresent ##"
        Write-Debug "Testing SchemaId"
        if (($Body.SchemaId) -and ($Body.SchemaId -eq "azureMonitorCommonAlertSchema")){
            $SchemaOK = $true
        } else {
            $SchemaOK = $false
        }
        Write-Debug "CAS Schema present: $($SchemaOK)"
        $SchemaOK
    }
}
function Get-CASVersions {
    [CmdletBinding()]
    [OutputType([psobject])]
    param (
        [parameter(Mandatory = $true)]
        [psobject]
        $Body
    )
    process {
        Write-Debug "## Get-CASVersions ##"
        $Versions =@{
            EssentialsVersion = $Body.data.essentials.essentialsVersion
            AlertContextVersion = $Body.data.essentials.alertContextVersion
        }
        New-Object -Property $Versions -TypeName psobject
    }
}
function Get-CASLogQuerySearchResults {
    [CmdletBinding()]
    [OutputType([psobject])]
    param (
        [parameter(Mandatory = $true)]
        $AlertData
    )
    process {
        Write-Debug "## Get-CASLogQuerySearchResults ##"
        foreach ($table in $AlertData.alertContext.SearchResults.tables){
            $AlertResults = @()
            if ($table.name -eq "PrimaryResult"){
                foreach ($row in $table.rows){
                    $ResultObject = New-Object -Typename psobject
                    $RowIndex = 0
                    foreach ($value in $row){
                        Write-Debug "$($table.columns[$RowIndex].name): $($value)"
                        $ResultObject | Add-Member -MemberType NoteProperty -Name $table.columns[$RowIndex].name $value
                        $RowIndex++
                    }
                    $AlertResults += $ResultObject
                }
            } else {
                Write-Warning "Unexpected table name: $($table.name) found in Log Query Search Results"
            }
        }
        $AlertResults
    }
}
# Function to create the authorization signature
Function Build-Signature
{
    param($customerId, $sharedKey, $date, $contentLength, $method, $contentType, $resource)
    $xHeaders = "x-ms-date:" + $date
    $stringToHash = $method + "`n" + $contentLength + "`n" + $contentType + "`n" + $xHeaders + "`n" + $resource

    $bytesToHash = [Text.Encoding]::UTF8.GetBytes($stringToHash)
    $keyBytes = [Convert]::FromBase64String($sharedKey)

    $sha256 = New-Object System.Security.Cryptography.HMACSHA256
    $sha256.Key = $keyBytes
    $calculatedHash = $sha256.ComputeHash($bytesToHash)
    $encodedHash = [Convert]::ToBase64String($calculatedHash)
    $authorization = 'SharedKey {0}:{1}' -f $customerId,$encodedHash
    return $authorization
}
Function Send-LogAnalyticsData
{
    param($customerId, $sharedKey, $body, $logType)
    $method = "POST"
    $contentType = "application/json"
    $resource = "/api/logs"
    $rfc1123date = [DateTime]::UtcNow.ToString("r")
    $contentLength = $body.Length
    $signature = Build-Signature `
        -customerId $customerId `
        -sharedKey $sharedKey `
        -date $rfc1123date `
        -contentLength $contentLength `
        -method $method `
        -contentType $contentType `
        -resource $resource
    $uri = "https://" + $customerId + ".ods.opinsights.azure.com" + $resource + "?api-version=2016-04-01"

    # Do not pass in time field via headers - accept the default applied by Log Analytics
    $headers = @{
        "Authorization" = $signature;
        "Log-Type" = $logType;
        "x-ms-date" = $rfc1123date;
    }

    $response = Invoke-WebRequest -Uri $uri -Method $method -ContentType $contentType -Headers $headers -Body $body -UseBasicParsing
    return $response.StatusCode

}
function Send-TeamsNotification {
    param (
        $ChannelURL,
        $MessageBody
    )
    # Send Data to Teams

    Write-Information "## Get-Send-TeamsNotification ##"      
    # call Teams webhook
    try {
        write-Information '## Invoke-RestMethod ##'
        #Write-Information "Calling Uri: $($ChannelURL)"
        #Write-Information "With Message Body:"
        #$MessageBody | Write-Information
        Invoke-RestMethod -Method "Post" -Uri $ChannelURL -Body $MessageBody | Write-output
    }
    catch {
        $ErrorMessage = $_.Exception.message
        write-error ('Error with invoke-restmethod ' + $ErrorMessage)
        Break
    }
}
function Send-SNOWEvent {
    param (
        $EventDescription,
        $SubscriptionId,
        $EventResource,
        $EventType,
        $EventFormat,
        $EventSeverity,
        $ResourceId,
        $Resource
    )
    $MessageKey = "OMS_$($SubscriptionId)_$($ResourceId)_$($EventType)_$($EventResource)"
    $EventBody =@{
        source = "OMS"
        severity = $EventSeverity
        type = $EventType
        resource = $EventResource
        event_class = $EventFormat
        node = $Resource
        description = $EventDescription
        message_key = $MessageKey
    }
    $CredentialPair = "$($ENV:ServiceNowUser):$($ENV:ServiceNowPassword)"
    $EncodedCredential = [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes($CredentialPair))
    $Headers = @{
        'Authorization' = "Basic $($EncodedCredential)"
        'Content-Type' = "application/json"
        'Accept' = "application/json"
    }
    $SnowAPIUri = $ENV:ServiceNowUrl + "api/now/table/em_event"
    $JSONBody = $EventBody | ConvertTo-Json
    $Response = try {
        Write-Information $SnowAPIUri
        Write-Information $Headers
        Write-Information $JSONBody
        (Invoke-Webrequest -Uri $SnowAPIUri -Header $Headers -Method POST -Body $JSONBody -ErrorAction Stop).BaseResponse
    } catch [System.Net.WebException] { 
        Write-Error $JSONBody
        Write-Verbose "An exception was caught: $($_.Exception.Message)"
        $_.Exception.Response 
    } 
    
    #then convert the status code enum to int by doing this
    $statusCodeInt = [int]$Response.BaseResponse.StatusCode
    #or this
    #$statusCodeInt = $response.BaseResponse.StatusCode.Value__
    Write-Information "Status Code returned from Service Now: $($statusCodeInt)"
}
function Send-SNOWHBEvent {
    param (
        $AlertData,
        $AlertResults
    )
    <#
        <-- Log Entry -->
        TimeGenerated : 2/29/2020 1:34:08 PM
        SubscriptionId : b47b134f-d1e7-4f79-8a4c-043a355acf6d
        Resource : monvmlx001
        ResourceId : /subscriptions/b47b134f-d1e7-4f79-8a4c-043a355acf6d/resourcegroups/rg-rn-monitortests/providers/microsoft.compute/virtualmachines/monvmlx001
        AggregatedValue : 0
        eventType : Availability
        eventResource : Virtual Machine
        eventFormat : HeartbeatLogMetric
        <-- Log Entry -->
    #>
    #$VMResourceId = "/subscriptions/$($AlertResults.Subscription)/resourcegroups/$($AlertResults.ResourceGroup)/providers/Microsoft.Compute/virtualMachines/$($AlertResults.Name)"
    $TargetURL = "https://portal.azure.com/#resource" + $AlertData.ResourceId + "/overview"
    $AgentStatus = ($AlertResults.AgentStatusObj | ConvertTo-Json)
    $VMStatus = ( $AlertResults.StatusObj | ConvertTo-Json )
    $EventDescription = @"
Alert : DXC-Major-Heartbeat Missing
Description : Heartbeat Alert Processed by triage function
Result : $($AlertResults.Summary)
VM Status : $($VMStatus)
Agent Status : $($AgentStatus)
SubscriptionId : $($AlertData.SubscriptionId)
Resource : $($AlertData.Resource)
ResourceId : $($AlertData.ResourceId)
eventType : $($AlertData.eventType)
eventResource : $($AlertData.eventResource)
eventFormat : $($AlertData.eventFormat)
eventProcessingSchema : 3.0
Click [code]<a href="$($TargetURL)">here</a>[/code] to go to the Virtual Machine

"@

    Write-Information "SubscriptionId: $($AlertData.SubscriptionId)"
    Write-Information "Resource: $($AlertData.Resource)"
    Send-SNOWEvent  -SubscriptionId $AlertData.SubscriptionId `
                    -ResourceId $AlertData.ResourceId `
                    -Resource $AlertData.Resource `
                    -EventResource $AlertData.eventResource `
                    -EventType $AlertData.eventType `
                    -EventFormat $AlertData.eventFormat `
                    -EventSeverity 2 `
                    -EventDescription $EventDescription
}
function Send-TeamsHBAlertNotification {
    param(
        $AlertResults,
        $ChannelURL
    )
    process {
        # Send Data to Teams
        # Build the message body
        $image = ""
#     /subscriptions/Subscription/resourcegroups/ResourceGroup/providers/Microsoft.Compute/virtualMachines/Name"

        $VMResourceId = "/subscriptions/$($AlertResults.Subscription)/resourcegroups/$($AlertResults.ResourceGroup)/providers/Microsoft.Compute/virtualMachines/$($AlertResults.Name)"
        $TargetURL = "https://portal.azure.com/#resource" + $VMResourceId + "/overview"
        $AgentStatus = ($AlertResults.AgentStatusObj | ConvertTo-Json)
        $VMStatus = ( $AlertResults.StatusObj | ConvertTo-Json )
        try {    
            $TeamsNotificationBody = ConvertTo-Json -ErrorAction Stop -Depth 4 @{
                title           = 'Azure VM Availability Notification' 
                text            = 'A new Azure Heartbeat Availability Alert has been processed'
                sections        = @(
                    @{
                        activityTitle    = "Alert received from: $VMResourceId"
                        activitySubtitle = $AlertResults.Subscription
                        activityText     = $AlertResults.Summary
                        activityImage    = $image
                        facts = @(
                            @{
                                name = "Virtual Machine"
                                value = $AlertResults.Name
                            }
                            @{
                                name = "Resource Group"
                                value = $AlertResults.ResourceGroup
                            }
                            @{
                                name = "Subscription"
                                value = $AlertResults.Subscription
                            }
                            @{
                                name = "Assessment Summary"
                                value = $AlertResults.Summary
                            }
                            @{
                                name = "Alert State"
                                value = $AlertResults.AlertState
                            }
                            @{
                                name = "VM ARM Status"
                                value = $VMStatus
                            }
                            @{
                                name = "VM Agent Status"
                                value = $AgentStatus
                            }
                            @{
                                name = "VM Power State"
                                value = $AlertResults.PowerState
                            }
                            @{
                                name = "VM Provisioning State"
                                value = $AlertResults.ProvisioningState
                            }
                            @{
                                name = "Agent State"
                                value = $AlertResults.AgentProvisioningState
                            }
                            @{
                                name = "Agent State is Current"
                                value = $AlertResults.AgentStateCurrent
                            }
                            @{
                                name = "Monitoring Agent Provisioning State"
                                value = $AlertResults.MonitoringAgentProvisioningState
                            }
                            @{
                                name = "Monitoring Agent Display Status"
                                value = $AlertResults.MonitoringAgentDisplayStatus
                            }
                        )
                    }
                )
                potentialAction = @(@{
                        '@context' = 'http://schema.org'
                        '@type'    = 'ViewAction'
                        name       = 'Click here to go to the Virtual Machine in the portal'
                        target     = @($TargetURL)
                    })
            }
        }
        catch {
            $ErrorMessage = $_.Exception.message
            write-error ('Error converting body to JSON ' + $ErrorMessage)
            Break
        }
        Send-TeamsNotification -ChannelURL $ChannelURL -MessageBody $TeamsNotificationBody

    }
}
