function Get-VMReport {
    <#
    .SYNOPSIS
        Create VM status report

    .DESCRIPTION
        Uses the Get-AzVM Cmdlet to create and return a report on the status of a Virtual Machine, the Azure VM Agent (WAAgent)
        and any installed extensions. This is used as part of the function app based assessment of availability alerts
        triggered by heartbeat log query alerts.

    .EXAMPLE
        $Report = Get-VMReport -ResourceId /subscriptions/xyz/resourceGroups/abc/providers/Microsoft.Compute/virtualMachines/vm001

    .NOTES
        (C) Copyright DXC Technology, 2020. All rights reserved

    #>
    [CmdletBinding()]
    param (
        [Parameter()]
        [String]
        # Resource ID of the Virtual Machine to be examined
        $ResourceId
    )
    # Regex to extract fields from VM Resource Id
    $Regex = "^\/subscriptions\/(?<Subscription>.+)\/resourcegroups\/(?<ResourceGroup>.+)\/providers\/Microsoft.Compute\/virtualMachines\/(?<Name>.+)$"
    # Report object returned by the function
    $Report = @{
        Name = $null                 # VM Name
        ResourceGroup = $null        # VM Resource Group
        Subscription = $null         # VM Subscription Id
        Summary = $null              # Summary description of test outcomes
        CompletionStatus = $null     # OK if test was completed successfully or ERROR otherwise - note that OK does not necessarily mean the VM is OK, just the test completed
        SummaryCode = $null          # Test outcome code to allow evaluation of success/failure reasons
        StatusObj = $null            # VM power and provisioning state records
        EvaluationTime = $null       # time when VM polled for state information
        AgentStatusObj = $null       # State record for VM agent (WAAgent)
        ExtensionStatusObj = $null   # State of installed extensions - AZR-13928 - track monitoring agent status

    }
    if ($ResourceId -match $Regex) {
        $Report.Name = $Matches.Name
        $Report.ResourceGroup = $Matches.ResourceGroup
        $Report.Subscription = $Matches.Subscription
        try {
            Write-Information "Set context to Subscription $($Matches.Subscription)"
            $SubscriptionObject = Get-AzSubscription -SubscriptionId $Matches.Subscription -ErrorAction Stop
            $TenantId = $SubscriptionObject.TenantId
            Write-Information "Tenant Id: $($SubscriptionObject.TenantId)"
            Set-AzContext -SubscriptionId $Matches.Subscription -TenantId $SubscriptionObject.TenantId -ErrorAction Stop | Out-Null
        }
        catch {
            # Cannot set context to the subscription hosting the VM - this should not happen
            # Write-Error $_.Exception
            $Report = Set-ReportStatus -Report $Report -CompletionStatus "ERROR" -SummaryCode "INVALID_SUBSCRIPTION" -Summary "Unable to set context to subscription $($Matches.Subscription)"
            return $Report
        }
        try {
            Write-Information "Get Resource Group status $($Matches.ResourceGroup)"
            Get-AzResourceGroup -Name $Matches.ResourceGroup -ErrorAction Stop | Out-Null
        }
        catch {
            # Resource Group has been deleted
            # Write-Error $_.Exception
            $Report = Set-ReportStatus -Report $Report -CompletionStatus "OK" -SummaryCode "RESOURCEGROUP_DELETED" -Summary "Resource Group $($Matches.ResourceGroup) not found. It has been deleted"
            return $Report
        }
        try {
            $Attempts = 0
            do {
                $Attempts++
                if ($Attempts -gt 5){
                    # Too many attempts to get VM Status - return an error
                    $Report = Set-ReportStatus -Report $Report -CompletionStatus "ERROR" -SummaryCode "VM_NOSTATUS" -Summary "VM $($Matches.Name): too many attempts to retrieve VM Status and Agent data"
                    break
                }
                if ($Attempts -gt 1){
                    # Back off for subsequent attempts
                    Start-Sleep -Seconds $Attempts 
                } 
                $Report.EvaluationTime = Get-Date -Format u
                $VMDetails = Get-AzVM -ResourceGroupName $Matches.ResourceGroup -Name $Matches.Name -Status -ErrorAction Stop 
            } while ($null -eq $VMDetails.VMAgent.Statuses)
            $Report = Set-ReportStatus -Report $Report -CompletionStatus "OK" -SummaryCode "VM_TESTED" -Summary "Virtual Machine $($Matches.Name) successfully tested"
        }
        catch {
            # VM has been deleted
            $Report = Set-ReportStatus -Report $Report -CompletionStatus "OK" -SummaryCode "VM_DELETED" -Summary "VM $($Matches.Name) not found. It has been deleted"
            return $Report
        }
    } else {
        Set-ReportStatus -Report $Report -CompletionStatus "ERROR" -SummaryCode "INVALID_RESOURCEID" -Summary "Cannot parse Resource Id $ResourceId"
        return
    }
    $Report["StatusObj"] = $VMDetails.Statuses
    $Report["AgentStatusObj"] = $VMDetails.VMAgent.Statuses
    $Report["ExtensionStatusObj"] = $VMDetails.VMAgent.ExtensionHandlers
    return $Report
}
function Test-VMReport {
    <#
    .SYNOPSIS
        Assesses the health of a VM by parsing the Report created by Get-VMReport

    .DESCRIPTION
        Test-VMReport analyses the output report created by Get-VMReport to determine the status of the VM in question. This is part 
        of the function app based triage/assessment process to determine if heartbeat availability log query alerts are vailid or not.

    .EXAMPLE
        $Results = Test-VMReport -Report $VMReport

    .NOTES
        (C) Copyright DXC Technology, 2020. All rights reserved

    #>
    param (
        $Report
    )
    $Assessment =@{}
    $Assessment["Name"] = $Report.Name
    $Assessment["ResourceGroup"] = $Report.ResourceGroup
    $Assessment["Subscription"] = $Report.Subscription

    # If the VM Agent reports an update time earlier than the current time minus this timeout period
    # this will create an alert
    $VMAgentTimeout = New-TimeSpan -Minutes 5

    # If the VM report could not be completed, we have to return an error
    if ($Report.CompletionStatus -ne "OK") {
        $Assessment["Summary"] = "Error: $($Report.SummaryCode) : $($Report.Summary)"
        $Assessment["AlertState"] = $true
        return $Assessment
    }
  
    # VM report completed successfully, but the VM or ResourceGroup was deleted
    # Do not return an alert
    if ($Report.SummaryCode -eq "VM_DELETED" -or $Report.SummaryCode -eq "RG_DELETED") {
        $Assessment["Summary"] = "Virtual machine or Resource Group has been deleted"
        $Assessment["AlertState"] = $false
        return $Assessment
    }

    # VM Report completed successfully and we have to assess the report results 
   
    $Assessment["EvaluationTime"] = $Report.EvaluationTime
    $Assessment["PowerState"] = (Get-ReportedVMPowerState -Report $Report).Code
    $Assessment["ProvisioningState"] = (Get-ReportedVMProvisioningState -Report $Report).Code
    $Assessment["Status"] = $Report.StatusObj
    $Assessment["AgentProvisioningState"] = (Get-ReportedVMAgentState -Report $Report).Code
    $Assessment["AgentStateCurrent"] = (Test-ReportedVMAgentStateCurrent -Report $Report -Timeout $VMAgentTimeout)
    $Assessment["AgentStatus"] = $Report.AgentStatusObj
    $Assessment["MonitoringAgentProvisioningState"] = (Get-ReportedVMMonitoringAgentState -Report $Report).Code
    $Assessment["MonitoringAgentDisplayStatus"] = (Get-ReportedVMMonitoringAgentState -Report $Report).DisplayStatus
    $Assessment["MonitoringAgentStatus"] = Get-ReportedVMMonitoringAgentState -Report $Report

    # Determine VM State based on combinations of attributes
    switch ( $Assessment ) {
        # VM has been deallocated by Resource Manager
        ({
            $PSItem.PowerState -match '^PowerState\/deallocat[ed|ing]'
            
        })
        {
            Write-Information "VM Deallocated by Resource Manager"
            $Assessment["Summary"] = "Virtual machine has been deallocated by ARM, no alert state"
            $Assessment["AlertState"] = $false
            break
        }
        # VM stopped in guest - i.e. shutdown at OS level
        # We will still report an error because monitored machines should not be stopped outside of 
        # maintenance periods
        ({
            $PSItem.PowerState -match '^PowerState\/stopp[ed|ing]'
        })
        {
            Write-Information "VM shutdown in guest"
            $Assessment["Summary"] = "Virtual machine has been stopped in OS"
            $Assessment["AlertState"] = $true
            break
        }
        # Virtual Machine is healthy
        ({
            $PSItem.PowerState -eq "PowerState/running" `
            -and $PSItem.ProvisioningState -eq "ProvisioningState/succeeded" `
            -and $PSItem.AgentProvisioningState -eq "ProvisioningState/succeeded" `
            -and $PSItem.AgentStateCurrent -eq $true `
            -and $PSItem.MonitoringAgentProvisioningState -eq "ProvisioningState/succeeded" `
            -and $PSItem.MonitoringAgentDisplayStatus -eq "Ready"
        })
        {
            Write-Information "VM Healthy"
            $Assessment["Summary"] = "Virtual machine is healthy"
            $Assessment["AlertState"] = $false
            break
        }
        # VM Provisioning status updating, but all else OK
        ({
            $PSItem.PowerState -eq "PowerState/running" `
            -and $PSItem.ProvisioningState -eq "ProvisioningState/updating" `
            -and $PSItem.AgentProvisioningState -eq "ProvisioningState/succeeded" `
            -and $PSItem.AgentStateCurrent -eq $true `
            -and $PSItem.MonitoringAgentProvisioningState -eq "ProvisioningState/succeeded" `
            -and $PSItem.MonitoringAgentDisplayStatus -eq "Ready"
        })
        {
            Write-Information "VM Healthy but VM provisioning state updating"
            $Assessment["Summary"] = "Virtual Machine in updating state"
            $Assessment["AlertState"] = $false
            break
        }     
        # VM Healthy, but monitoring agent failed
        # Added to address AZR-13928 - Monitoring agent status not tracked in heartbeat monitoring alert
        ({
            ($PSItem.PowerState -eq "PowerState/running")`
            -and $PSItem.ProvisioningState -eq "ProvisioningState/succeeded" `
            -and ($PSItem.AgentProvisioningState -eq "ProvisioningState/succeeded")`
            -and ($PSItem.MonitoringAgentDisplayStatus -ne "Ready")`
            -and $PSItem.AgentStateCurrent -eq $true
        })
        {
            Write-Information "Monitoring Agent Failed"
            $Assessment["Summary"] = "Virtual machine is healthy, but monitoring agent failed"
            $Assessment["AlertState"] = $true
            break
        }

        # VM Crashed or in hung state
        ({
            ($PSItem.PowerState -eq "PowerState/running"`
            -and $PSItem.AgentProvisioningState -eq "ProvisioningState/succeeded"`
            -and $PSItem.AgentStateCurrent -eq $false)`
            -or ($PSItem.PowerState -eq "PowerState/running"`
            -and $PSItem.AgentProvisioningState -eq "ProvisioningState/Unavailable")
        })
        {
            Write-Information "VM Agent Unresponsive - system may have crashed or hung"
            $Assessment["Summary"] = "Virtual machine agent unresponsive or unavailable. VM could be down, hung or VM Agent not functioning"
            $Assessment["AlertState"] = $true
            break
        }
        # VM Starting - potential to further refine this state
        # 
        ({
            $PSItem.PowerState -match '^PowerState\/starting'
        })
        {
            Write-Information "VM restarting"
            $Assessment["Summary"] = "Virtual machine is being restarted - it may have been unintentionally rebooted"
            # AZR-16740 - Reduce heartbeat alerts due to slow machine startup
            $Assessment["AlertState"] = $false  # change from true to false, we no need incidents on booting VM
            break 
        }
        default
        {
            Write-Host "Default Switch condition - no assessment evaluation"
            Write-Host "VM Power State: $($PSItem.PowerState)"
            Write-Host "VM Provisioning State: $($PSItem.ProvisioningState)"
            Write-Host "VM Agent Provisioning State: $($PSItem.AgentProvisioningState)"
            Write-Host "VM Agent reporting: $($PSItem.AgentStateCurrent)" 
            Write-Host "VM Monitoring Agent State: $($PSItem.MonitoringAgentProvisioningState)"
            Write-Host "VM Monitoring Agent Display Status: $($PSItem.MonitoringAgentDisplayStatus)"
           $Assessment["Summary"] = "Virtual machine status unknown"
           $Assessment["AlertState"] = $true
        }
    }

    $Assessment
}
function Set-ReportStatus {
    <#
    .SYNOPSIS
        Utility function used by Get-VMReport to set output status fields

    .DESCRIPTION
        Provides consistent means of setting completion status, a summary code and a summary for the VM in
        the output report object

    .EXAMPLE
        $Report = Set-ReportStatus -Report $Report -CompletionStatus "OK" -SummaryCode "VM_TESTED" -Summary "Virtual Machine successfully tested"

    .NOTES
        (C) Copyright DXC Technology, 2020. All rights reserved

    #>
    [CmdletBinding()]
    param (
        # Report object to update
        [Parameter(mandatory=$true)]
        [PSObject]
        $Report,
        # Report output status to set - OK or ERROR
        [Parameter(mandatory=$true)]
        [String]
        $CompletionStatus,
        # Summary Code for output status
        [Parameter(mandatory=$true)]
        [String]
        $SummaryCode,
        # Summary of VM report outcomes
        [Parameter(mandatory=$true)]
        [String]
        $Summary  
    )
    process {
        $Report["CompletionStatus"] = $CompletionStatus
        $Report["SummaryCode"] = $SummaryCode
        $Report["Summary"] = $Summary

        $Report
    }
}
function Get-ReportedVMPowerState {
    <#
    .SYNOPSIS
        Utility function used by Test-VMReport to extract the VM PowerState

    .DESCRIPTION
        Extracts the VM Powerstate status object from the report generated by Get-VMReport. This is a convenience to allow
        Test-VMReport to be simplified

    .EXAMPLE
        $PowerState = (Get-ReportedVMPowerState -Report $Report).Code

    .NOTES
        (C) Copyright DXC Technology, 2020. All rights reserved

    #>
    param (
        # Report object to examine
        [Parameter(mandatory=$true)]
        [PSObject]
        $Report
    )
    process {
        if (-not $Report.ContainsKey('StatusObj')) {
            Write-Error "Cannot determine VM PowerState - no VM Status Object present"
            return $null
        }
        foreach ($Status in $Report.StatusObj) {
            if ($Status.Code -match "PowerState") {
                return $Status
            }
        }
        return $null
    } 
}
function Get-ReportedVMProvisioningState {
    <#
    .SYNOPSIS
        Utility function used by Test-VMReport to extract the VM Provisioning State

    .DESCRIPTION
        Extracts the VM Provisioning status object from the report generated by Get-VMReport. This is a convenience to allow
        Test-VMReport to be simplified

    .EXAMPLE
        $ProvisioningState = (Get-ReportedVMProvisioningState -Report $Report).Code

    .NOTES
        (C) Copyright DXC Technology, 2020. All rights reserved

    #>
    param (
        # Report object to examine
        [Parameter(mandatory=$true)]
        [PSObject]
        $Report
    )
    process {
        if (-not $Report.ContainsKey('StatusObj')) {
            Write-Error "Cannot determine VM ProvisioningState - no VM Status Object present"
            return $null
        }
        foreach ($Status in $Report.StatusObj) {
            if ($Status.Code -match "ProvisioningState") {
                return $Status
            }
        }
        return $null
    } 
}
function Get-ReportedVMAgentState {
    <#
    .SYNOPSIS
        Utility function used by Test-VMReport to extract the VM Agent State

    .DESCRIPTION
        Extracts the VM Agent (WAAgent) status object from the report generated by Get-VMReport. This is a convenience to allow
        Test-VMReport to be simplified

    .EXAMPLE
        $AgentProvisioningState = (Get-ReportedVMAgentState -Report $Report).Code

    .NOTES
        (C) Copyright DXC Technology, 2020. All rights reserved

    #>
    param (
        # VM Report object to check
        [Parameter(mandatory=$true)]
        [PSObject]
        $Report
    )
    process {
        if (-not $Report.ContainsKey('AgentStatusObj')) {
            Write-Error "Cannot determine VM Agent status - no Agent status object present"
            return $null
        }
        foreach ($Status in $Report.AgentStatusObj) {
            if ($Status.Code -match "ProvisioningState") {
                return $Status
            }
        }
        return $null
    }
    
}
function Test-ReportedVMAgentStateCurrent {
    <#
    .SYNOPSIS
        Utility function used by Test-VMReport to determine if the VM Agent is currently responding

    .DESCRIPTION
        Uses the report generated by Get-VMReport to determine if the VM Agent has updated its state
        during the period defined by $Timeout prior to the VM report being generated 

    .EXAMPLE
        $AgentStateCurrent = Test-ReportedVMAgentStateCurrent -Report $Report -Timeout $VMAgentTimeout

    .NOTES
        (C) Copyright DXC Technology, 2020. All rights reserved

    #>
    param(
        # VM Report Object to test
        [Parameter(mandatory=$true)]
        [PSObject]
        $Report,
        # Age threshold to consider agent not responding
        [Parameter(mandatory=$true)]
        [TimeSpan]
        $Timeout
    )
    process {
        if (-not $Report.ContainsKey('AgentStatusObj')) {
            Write-Error "Cannot determine VM Agent health - no Agent status object present"
            return $false
        }
        foreach($AgentStatus in $Report.AgentStatusObj) {
            if ($AgentStatus.Code -match "ProvisioningState") {
                $Delta = New-TimeSpan -Start $AgentStatus.Time -End $Report.EvaluationTime
                if ($Delta.TotalSeconds -gt $Timeout.TotalSeconds) {
                    return $false
                } else {
                    return $true
                }
                
            }
        }
    }
}
function Get-ReportedVMMonitoringAgentState {
    <#
    .SYNOPSIS
        Utility function used by Test-VMReport to extract the VM Monitoring Agent State

    .DESCRIPTION
        Extracts the VM Monitoring Agent State object from the report generated by Get-VMReport. This is a convenience to allow
        Test-VMReport to be simplified

    .EXAMPLE
        $MonitoringAgentProvisioningState = (Get-ReportedVMMonitoringAgentState -Report $Report).Code

    .NOTES
        (C) Copyright DXC Technology, 2020. All rights reserved

    #>
    [CmdletBinding()]
    param (
        # VM Report object
        [Parameter(mandatory=$true)]
        [PSObject]
        $Report
    )
    process {
        foreach ($ExtensionHandler in $Report.ExtensionStatusObj) {
            #Write-Host "Assessing Extension: " ($ExtensionHandler | ConvertTo-Json)
            If (($ExtensionHandler.Type -contains 'Microsoft.EnterpriseCloud.Monitoring.MicrosoftMonitoringAgent') -or `
                ($ExtensionHandler.Type -contains 'Microsoft.EnterpriseCloud.Monitoring.OmsAgentForLinux'))
                {
                    return $ExtensionHandler.Status
                }
        }
    }
}