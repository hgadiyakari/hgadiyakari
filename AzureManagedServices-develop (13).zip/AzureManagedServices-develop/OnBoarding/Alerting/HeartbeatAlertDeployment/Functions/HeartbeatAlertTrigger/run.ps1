using namespace System.Net

# Input bindings are passed in via param block.
param($Request, $TriggerMetadata)

Import-Module DXC-FuncAppUtils
# Write to the Azure Functions log stream.
Write-Host "PowerShell HTTP trigger function processed a request."

# Check if CAS payload present

if (Test-CASSchemaPresent -Body $Request.Body) {
    $status = [HttpStatusCode]::OK
    $body = "Processed CAS Alert"
}
else {
    $status = [HttpStatusCode]::BadRequest
    $body = "Request Body does not contain CAS Schema alert"
}
$AlertVMs = Get-CASLogQuerySearchResults($Request.Body.data)
<#
Example of Query Results for Heartbeat Log Query search
{
    "eventFormat": "HeartbeatLogQuery",
    "ResourceId": "/subscriptions/b47b134f-d1e7-4f79-8a4c-043a355acf6d/resourceGroups/rg-rn-monitortests/providers/Microsoft.Compute/virtualMachines/monvmlx001",
    "eventType": "Availability",
    "SubscriptionId": "b47b134f-d1e7-4f79-8a4c-043a355acf6d",
    "eventResource": "Virtual Machine",
    "Resource": "monvmlx001"
}
#>

foreach($AlertVM in $AlertVMs){
    Write-Information "Writing HB alert for $($AlertVM.Resource) to output queue"
    $AlertVM | ConvertTo-JSON | Push-OutputBinding -Name OutputQueue
}
# Associate values to output bindings by calling 'Push-OutputBinding'.
Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
    StatusCode = $status
    Body = $body
})
