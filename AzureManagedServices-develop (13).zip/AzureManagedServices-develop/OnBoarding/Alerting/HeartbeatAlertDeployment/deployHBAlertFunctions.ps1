#=====================================================================================================================
# DOCUMENTATION LINK
# https://confluence.dxc.com/display/CSA/AZR-12433%2C+AZR-12434+and+AZR-12435+Deployment+Script+for+Heartbeat+Alert
#=====================================================================================================================

[CmdletBinding(SupportsShouldProcess=$true)]
Param
    (
    [Parameter(Mandatory=$true)] [String]$SubscriptionId,
    [Parameter(Mandatory=$true)] [String]$TenantId,
    [Parameter(Mandatory=$true)] [String]$LogAnalyticsWorkspaceName,
    [Parameter(Mandatory=$true)] [String]$ServiceNowURL,
    [Parameter(Mandatory=$true)] [String]$ServiceNowUser,
    [Parameter(Mandatory=$true)] [String]$ServiceNowUserPwd,
    [Parameter(Mandatory=$true)] [ValidateSet("Auto","Yes")] [String]$UpgradeFunctionCodes,
    [Parameter(Mandatory=$true)] [ValidateSet("Auto","Yes")] [String]$UpgradeEnvVariables,
    [Parameter(Mandatory=$false)] [String]$SpKey,
    [Parameter(Mandatory=$false)] [String]$ClientID
    )
#=====================================================================================================================
# CHECK ENVIRONMENT FOR NECESSERY MODULES
#=====================================================================================================================
$dxcModuleList = "DXCEnvCheckV2.psm1", "DXCUtilityFunctions.psm1", "DXCDeploymentFunctions.psm1"
foreach ($dxcModule in $dxcModuleList)
    {
    [String]$dxcModuleURL = "https://dxcazuretoolsdev.blob.core.windows.net/installers/DXCPowershellModules/" + $dxcModule
    [String]$dxcLocalModule = Join-Path -Path $PSScriptRoot -ChildPath $dxcModule
    (New-Object System.Net.WebClient).DownloadFile($dxcModuleURL, $dxcLocalModule)
    Import-Module $dxcLocalModule -WA 0
    Remove-Item -Path $dxcLocalModule
    }

$dxcPSCore = Check-PSCore -Version 7.0.0
if ($dxcPSCore) { $dxcAZ = Check-AzModule -Version 2.5.0 }
if ($dxcAZ) { $dxcAZCli = Check-AzureCLI -Version 2.1.0 }
if ($dxcAZCli) { $dxcAZStorage = Check-PSModule -Name "Az.Storage" -Version 1.5.1 }
if ($dxcAZStorage) { $dxcAZMonitor = Check-PSModule -Name "Az.Monitor" -Version 1.5.0 }
if ($dxcAZMonitor) { $dxcAZFunctions = Check-PSModule -Name "Az.Functions" -Version 1.0.0 }
if ($dxcAZFunctions) { $dxcAZApplicationInsights = Check-PSModule -Name "Az.ApplicationInsights" -Version 1.0.1 }
if($dxcAZApplicationInsights){$dxcAZResource = Check-PSModule -Name "Az.Resources" -Version 3.2.0 }
if (!$dxcAZResource)
    {
    Read-Host "`nPress 'ENTER'to exit the script........"
    exit
    }
$dxcAzInsights = Get-Module -Name Az.Insights -ListAvailable
if ($dxcAzInsights) {
    Write-Host "Az.Insights modules exists, please uninstall before proceeding further"
    Read-Host "`nPress 'ENTER'to exit the script........"
    exit
} 

#=====================================================================================================================
# LOGIN SECTION
#=====================================================================================================================
$error.Clear()

if ($SpKey) {
	Utility-LoginAZSpn -TenantId $TenantId -SpnKey $SpKey -ClientId $ClientID -SubscriptionId $SubscriptionId
	Utility-LoginAzureCliSpn -TenantId $TenantId -SpnKey $SpKey -ClientId $ClientID -SubscriptionId $SubscriptionId
	}
else {
	Utility-LoginAZTenant -TenantId $TenantId -SubscriptionId $SubscriptionId
	Utility-LoginAureCliTenant -TenantId $TenantId -SubscriptionId $SubscriptionId
	}

  
#=====================================================================================================================
# VARIABLE SECTION
#=====================================================================================================================
$ErrorActionPreference = "SilentlyContinue"
$WarningPreference = "SilentlyContinue"
[String]$dxcAlertVersion = "2.8"
[String]$dxcFunctionAppRGName = "dxc-automation-rg"
[String]$dxcActionGroup = "DXC-HB-Major"
[String]$dxcActionGroupShortName = "dxcHBMaj"
[String]$dxcTeamsNotificationURL = "https://outlook.office.com/webhook/9de3af8e-7f6c-487d-9204-05ce8ad65a41@93f33571-550f-43cf-b09f-cd331338d086/IncomingWebhook/c8fa16b940dc40ff9fe758965011e414/200a8b3f-b6fb-45d7-b113-45ca0356bb83%22"       
[String]$dxcRandom = Utility-GeneratingUniqueID -dxcResourceGroupName $dxcFunctionAppRGName
[String]$dxcStorageAccountName = 'dxchb' + $dxcRandom + 'stg'
[String]$dxcAppInsightName = 'dxc-FuncApp-' + $dxcRandom + '-AI'
[String]$dxcFunctionAppName = 'dxc-Heartbeat-' + $dxcRandom + '-FA'
[String]$dxcAppServicePlan = 'dxc-FuncAppCo-' + $dxcRandom + '-ASP'
[String]$dxcHBLogAlertJSON = Join-Path -Path $PSScriptRoot -ChildPath '\alerts-vm-availability-hbm.json'
[String]$dxcZippedFunctionPath = Join-Path -Path $PSScriptRoot -ChildPath "$dxcFunctionAppName.zip"
[String]$dxcFunctionAppIdentityScope = '/subscriptions/' + $SubscriptionId
if (-not( $ServiceNowURL.substring($ServiceNowURL.length -1) -eq "/")) { $ServiceNowURL = $ServiceNowURL + "/" }

#========================================================================================================================
# MAIN BODY OF THE SCRIPT
#========================================================================================================================
# Collect Maintenance ResourceGroup and OMS Workspace Details.
$dxcObjWorkspace = Get-AzOperationalInsightsWorkspace | Where-Object { $_.Name -Match $LogAnalyticsWorkspaceName }
If ($dxcObjWorkspace)
    {
    [String]$LogAnalyticsWorkspaceName = $dxcObjWorkspace.Name
    [String]$dxcResourceGroup = $dxcObjWorkspace.ResourceGroupName
    [String]$dxcWorkspaceRegion = (($dxcObjWorkspace.location).ToLower()) -replace '\s',''
    [String]$dxcWorkspaceResourceId = $dxcObjWorkspace.ResourceId

    Utility-DisplayInfo -dxcstr1 "INFORMATION: Loganalytics Workspace named" -dxcstr2 $LogAnalyticsWorkspaceName -dxcstr3 "located under ResourceGroup" -dxcstr4 $dxcResourceGroup
    }
else
    {
    Write-Host "WARNING:     Loganalytics Workspace not found. Please enter correct workspace name while running the script." -ForegroundColor Yellow
    Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
    Read-Host "`nPress 'ENTER'to exit the script........"
    exit
    }

Write-Host "`n##########################################################"
Write-Host "STAGE1: RESOURCE GROUP DEPLOYMENT SECTION"
Write-Host "############################################################"

$dxcRGExtsts, $dxcobjRG = Deploy-ResourceGroup -Name $dxcFunctionAppRGName -Location $dxcWorkspaceRegion


if (!$dxcobjRG)
    {
    Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
    Read-Host "`nPress 'ENTER'to exit the script........"
    exit
    }

if (!$dxcRGExtsts) 
    { 
    $error.Clear()
    New-AzResourceLock -ResourceGroupName $dxcFunctionAppRGName -LockName "DXC-Automation-RG-Lock" -LockNotes "Cannot Delete Lock applied on this Resource Group to avoid accidental deletion of all resources from automation resource group" -LockLevel "CanNotDelete" -Force >$null

    if ($error) { Utility-DisplayWarning -dxcstr1 "WARNING:     Unable to lock the ResourceGroup" -dxcstr2 $dxcFunctionAppRGName -dxcstr " . You need to Manually Lock it against deletion, post deployment." }
    Else { Utility-DisplayInfo -dxcstr1 "INFORMATION: Deletion Lock applied to the ResourceGroup" -dxcstr2 $dxcFunctionAppRGName }
	}

Write-Host "`n##########################################################"
Write-Host "STAGE2: STORAGE ACCOUNT DEPLOYMENT SECTION"
Write-Host "############################################################"

$error.Clear()
$dxcStorageExists, $dxcObjStorage = Deploy-StorageAccount -Location $dxcWorkspaceRegion -ResourceGroupName $dxcFunctionAppRGName -Name $dxcStorageAccountName -Container "None" -Table "None" -Queue "hb-alert-queue" -Blobfiles "None"

if (!$dxcObjStorage)
    {
    Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
    Read-Host "`nPress 'ENTER'to exit the script........"
    exit
    }

Write-Host "`n##########################################################"
Write-Host "STAGE3: FUNCTIONAPP DEPLOYMENT AND CONFIGURATION SECTION"
Write-Host "############################################################"

$dxcObjFunctionApp = Get-AzResource -Name $dxcFunctionAppName -ResourceGroupName $dxcFunctionAppRGName -ResourceType "Microsoft.Web/sites" -EA 0

if ($dxcObjFunctionApp) 
    { 
    $dxcFunctionAppResourceId = $dxcObjFunctionApp.ResourceId
    $function_extension_version = az functionapp config appsettings list --name $dxcFunctionAppName --resource-group $dxcFunctionAppRGName --query "[?name=='FUNCTIONS_EXTENSION_VERSION'].value" | ConvertFrom-Json
    if ($function_extension_version -ne "~3") 
        {
         Utility-DisplayInfo -dxcstr1 "INFORMATION: FunctionApp named" -dxcstr2 $dxcFunctionAppName -dxcstr3 "being updated to powershell 7"
         az functionapp config appsettings set --name $dxcFunctionAppName --resource-group $dxcFunctionAppRGName --settings FUNCTIONS_EXTENSION_VERSION="~3" 
		 Set-AzResource -ResourceId "/subscriptions/$SubscriptionId/resourceGroups/$dxcFunctionAppRGName/providers/Microsoft.Web/sites/$dxcFunctionAppName/config/web" -UsePatchSemantics -Properties @{ powerShellVersion = '~7' } -Force
        }
    else 
        {
        Utility-DisplayInfo -dxcstr1 "INFORMATION: FunctionApp already has FUNCTIONS_EXTENSION_VERSION = ~3"
        }        
    Utility-DisplayInfo -dxcstr1 "INFORMATION: FunctionApp named" -dxcstr2 $dxcFunctionAppName -dxcstr3 "already present. Skipping Stage3 and Stage4." 
    $dxcFunctionAppExists = $True
    
    #Get the list of tags on FunctionApp
    $Resourcetags = (Get-AzResource -Name $dxcFunctionAppName).Tags
    #Check if dxcManaged and dxcMonitored tags exists
    if (($Resourcetags.Keys -contains "dxcManaged") -and ($Resourcetags.Keys -contains "dxcMonitored") -and ($Resourcetags.Keys -contains "dxcConfigurationCheck")) {
        Utility-DisplayInfo -dxcstr1 "INFORMATION: dxcManaged,dxcMonitored and dxcConfigurationCheck tags already applied to FunctionApp named" -dxcstr2 $dxcFunctionAppName
       }
    else {
        $Timestamp = (get-date).ToUniversalTime().ToString("yyyyMMddTHHmmssZ")
        $Newtags = @{"dxcManaged"="True"; "dxcMonitored"="True"; "dxcConfigurationCheck"="$Timestamp"}
        #Updating new tags to Functionapp
        Update-AzTag -ResourceId $dxcFunctionAppResourceId -Tag $Newtags -Operation Merge
        Utility-DisplayInfo -dxcstr1 "INFORMATION: dxcManaged,dxcMonitored and dxcConfigurationCheck tags applied to FunctionApp named" -dxcstr2 $dxcFunctionAppName
        }
    }
else
    {
    #Verify and deploy AppServicePlan
    $dxcObjAppServicePlan = deploy-ConsumptionAppServicePlan -AppServicePlanName $dxcAppServicePlan -ResourceGroupName $dxcFunctionAppRGName -Location $dxcWorkspaceRegion
    if (!$dxcObjAppServicePlan) 
        { 
        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        Read-Host "`nPress 'ENTER'to exit the script........"
        exit
        }

    #Verify and deploy Application Insights
    $dxcObjAI = deploy-AppInsights -AppInsightsName $dxcAppInsightName -ResourceGroupName $dxcFunctionAppRGName -Location $dxcWorkspaceRegion
    if (!$dxcObjAI) 
        { 
        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        Read-Host "`nPress 'ENTER'to exit the script........"
        exit
        }

    #Deploy FunctionApp
    $dxcFunctionAppResourceId = deploy-FunctionAppOnConsumptionPlan -FunctionAppName $dxcFunctionAppName -ResourceGroupName $dxcFunctionAppRGName -Location $dxcWorkspaceRegion -AppInsightsName $dxcAppInsightName -ConsumptionPlanName $dxcAppServicePlan -StorageAccountName $dxcStorageAccountName
    az functionapp config appsettings set --name $dxcFunctionAppName --resource-group $dxcFunctionAppRGName --settings "ApplicationInsightsAgent_EXTENSION_VERSION=enabled" FUNCTIONS_EXTENSION_VERSION="~3" 
    Set-AzResource -ResourceId "/subscriptions/$SubscriptionId/resourceGroups/$dxcFunctionAppRGName/providers/Microsoft.Web/sites/$dxcFunctionAppName/config/web" -UsePatchSemantics -Properties @{ powerShellVersion = '~7' } -Force

    if (!$dxcFunctionAppResourceId) 
        { 
        Write-Host -dxcstr1 "WARNING    : Failed to create FunctionApp. Script will exit now." 
        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        Read-Host "`nPress 'ENTER'to exit the script........"
        exit
        }

    
    Write-Host "`n######################################################################"
    Write-Host "STAGE4: FUNCTIONAPP IDENTITY, SECURITY AND ENVIRONMENT SETTINGS SECTION"
    Write-Host "########################################################################"

    $dxcOutput = az functionapp identity assign -g $dxcFunctionAppRGName -n $dxcFunctionAppName --role reader --scope $dxcFunctionAppIdentityScope
    if ($dxcOutput) { $dxcOutput = az functionapp identity assign -g $dxcFunctionAppRGName -n $dxcFunctionAppName --role "Log Analytics Contributor" --scope $dxcWorkspaceResourceId }

    if (!$dxcOutput) 
        { 
        Write-Host "WARNING:     Unable to provide necessery access to FunctionApp. You may not have 'Owner' rights to the subscription." -ForegroundColor Yellow
        Write-Host "WARNING:     The script will continue to deploy but for proper functioning, some one with owner rights have to assign it the necessery permissions." -ForegroundColor Yellow
        Write-Host "WARNING:     Please follow the direction in its wiki link to assign permission to this functionapp after deployment." -ForegroundColor Yellow
        }
    else { Utility-DisplayInfo -dxcstr1 "INFORMATION: FunctionApp" -dxcstr2 $dxcFunctionAppName -dxcstr3 "has been provided 'Reader' access to the Subscription and 'Log Analytics Contributor' access to the LogAnalytics Workspace." }
    }

#Set Environtment Variables for the FunctionApp
if (!$dxcFunctionAppExists -or ($UpgradeEnvVariables -eq "Yes" ))
    {
    $error.Clear()
    Write-Host "`nINFORMATION: Settting up environment variable for the powershell function...." -ForegroundColor Green
    $dxcOutput = az functionapp config appsettings set --name $dxcFunctionAppName --resource-group $dxcFunctionAppRGName `
            --settings "ServiceNowUrl=$ServiceNowURL" "ServiceNowUser=$ServiceNowUser" "ServiceNowPassword=$ServiceNowUserPwd" "AlertMode=log alert" "TeamsNotificationURL=$dxcTeamsNotificationURL" "LogAnalyticsWorkspaceName=$LogAnalyticsWorkspaceName" "LogAnalyticsWorkspaceResourceGroup=$dxcResourceGroup" | ConvertFrom-Json

    if (!$dxcOutput) 
        { 
        Write-Host "WARNING:     Unable to set environment variables to FunctionApp. Script will exit now." -ForegroundColor Yellow
        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        Read-Host "`nPress 'ENTER'to exit the script........"
        exit
        }
    Write-Host "INFORMATION: Environment variable setup completed successfully." -ForegroundColor Green
    }
    else { Utility-DisplayInfo "INFORMATION: Skipping Environment variable setup as parameter" -dxcstr2 "dxcUpgradeEnvVariables" -dxcstr3 "is set to" -dxcstr4 "Auto" }
  
#Apply Security Settings
deploy-FunctionAppSecurity -FunctionAppName $dxcFunctionAppName -ResourceGroupName $dxcFunctionAppRGName -Location $dxcWorkspaceRegion -AppServiceAuthOn -HTTPSOnly -HTTP20Enabled -FTPDisabled
## Update Tags to ASP ###

Write-Host "`n##########################################################"
Write-Host "STAGE5: FUNCTION DEPLOYMENT SECTION"
Write-Host "############################################################`n"

if (!$dxcFunctionAppExists -or ($UpgradeFunctionCodes -eq "Yes" )) {

    # Copy function code files to temporary deployment zip file

    if (Test-Path -Path $dxcZippedFunctionPath) {
        Remove-Item -Path $dxcZippedFunctionPath
    }

    # $FilesToInclude = @('Functions/host.json', 'Functions/proxies.json', 'Functions/requirements.psd1', 'Functions/profile.ps1')

    # Compress-Archive -Path 'Functions/Modules' -DestinationPath $dxcZippedFunctionPath
    # Compress-Archive -Path 'Functions/HBAlertQueueTrigger' -DestinationPath $dxcZippedFunctionPath -Update
    # Compress-Archive -Path 'Functions/HeartbeatAlertTrigger' -DestinationPath $dxcZippedFunctionPath -Update
    # Compress-Archive -LiteralPath $FilesToInclude -DestinationPath $dxcZippedFunctionPath -Update

    Compress-Archive   -path 'Functions/*' -destinationpath $dxcZippedFunctionPath -force

    $error.Clear()
    $dxcOutput = az functionapp deployment source config-zip -g $dxcFunctionAppRGName -n $dxcFunctionAppName --src $dxcZippedFunctionPath | ConvertFrom-Json
    Remove-Item -Path $dxcZippedFunctionPath -Force >$null
    
    if (!$dxcOutput) 
        { 
        Utility-DisplayWarning -dxcstr1 "WARNING:     Unable to deploy" -dxcstr2 $dxcHBFunctionZip.Split("\")[-1] -dxcstr3 ". Script will exit now."

        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        Read-Host "`nPress 'ENTER'to exit the script........"
        exit
        }
    Utility-DisplayInfo -dxcstr1 "INFORMATION: Function from zip file" -dxcstr2 $dxcHBFunctionZip.Split("\")[-1] -dxcstr3 "has been deployed successfully."
    }
else { Utility-DisplayInfo "INFORMATION: Skipping Function Code deployment as parameter" -dxcstr2 "dxcUpgradeFunctionCodes" -dxcstr3 "is set to" -dxcstr4 "Auto" }

###### Tagging ASP, AI and Storage Account ####################

$dxcTags = @{
    "dxcManaged" = "True"
    "dxcMonitored" = "False"
    "dxcConfigurationCheck" = ([System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId((Get-Date), 'UTC')).ToString("yyyyMMddTHHmmssZ")
}

$resources = $dxcAppServicePlan, $dxcAppInsightName
foreach ($functionresources in $resources) { 
    Update-AzTag -ResourceId (Get-AzResource -Name $functionresources).ResourceId -Tag $dxcTags -Operation Merge
}

$MonitorTags = @{
    "dxcManaged" = "True"
    "dxcMonitored" = "True"
    "dxcConfigurationCheck" = ([System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId((Get-Date), 'UTC')).ToString("yyyyMMddTHHmmssZ")
}

 Update-AzTag -ResourceId (Get-AzResource -Name $dxcStorageAccountName).ResourceId -Tag $MonitorTags -Operation Merge



Write-Host "`n##########################################################"
Write-Host "STAGE6: ACTION GROUP DEPLOYMENT SECTION"
Write-Host "############################################################`n"
$error.Clear()
Get-AzActionGroup -ResourceGroupName $dxcResourceGroup -Name $dxcActionGroup >$null 

if ($error)
    {
    Utility-DisplayInfo -dxcstr1 "INFORMATION: Deploying" -dxcstr2 $dxcActionGroup -dxcstr3 "actiongroup, this may take few minutes..."

    $dxcKeyListObject = az rest --method post --uri "https://management.azure.com/subscriptions/$SubscriptionId/resourceGroups/$dxcFunctionAppRGName/providers/Microsoft.Web/sites/$dxcFunctionAppName/host/default/listKeys?api-version=2018-11-01" | ConvertFrom-Json
    $dxcFunctionURI = "https://" + $dxcFunctionAppName + ".azurewebsites.net/api/HeartbeatAlertTrigger?code=" + $dxcKeyListObject.functionKeys.default

    $dxcFunctionReceiver = New-AzActionGroupReceiver -Name "HBFunction" -UseCommonAlertSchema -AzureFunctionReceiver -FunctionAppResourceId $dxcFunctionAppResourceId -HttpTriggerUrl $dxcFunctionURI -FunctionName "HeartbeatAlertTrigger" 
    $error.Clear()
    Set-AzActionGroup -ResourceGroupName $dxcResourceGroup -Name $dxcActionGroup -ShortName $dxcActionGroupShortName -Receiver $dxcFunctionReceiver >$null

    if ($error) 
        { 
        Utility-DisplayWarning -dxcstr1 "WARNING:     Unable to deploy ActionGroup" -dxcstr2 $dxcActionGroup -dxcstr3 ". Script will exit now."

        Read-Host "`nPress 'ENTER'to exit the script........"
        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        Exit
        }
    else { Utility-DisplayInfo -dxcstr1 "INFORMATION: Action Group" -dxcstr2 $dxcActionGroup -dxcstr3 "has been deployed successfully." }
    }
 else { Utility-DisplayInfo -dxcstr1 "INFORMATION: ActionGroup" -dxcstr2 $dxcActionGroup -dxcstr3 "found in resourcegroup" -dxcstr4 $dxcResourceGroup }

Write-Host "`n##########################################################"
Write-Host "STAGE7: HEARTBEAT LOG ALERT DEPLOYMENT SECTION"
Write-Host "############################################################`n"

Write-Host "INFORMATION: Deploying Heartbeat log alert, this may take few minutes..." -ForegroundColor Green
$error.Clear()
New-AzResourceGroupDeployment -Name "HeartbeatLogAlertDeployment" -ResourceGroupName $dxcResourceGroup -TemplateFile $dxcHBLogAlertJSON -omsWorkspaceName $LogAnalyticsWorkspaceName -omsWorkspaceLocation $dxcWorkspaceRegion -actionGroupName $dxcActionGroup -alertVersion $dxcAlertVersion >$null
if ($Error) { Write-Host "WARNING:     Alert Deployment failed. For detailed error message, please check deployment error in the Resource Group from Azure Portal." -ForegroundColor yellow }
else { Write-Host "INFORMATION: Alert deployment successfull." -ForegroundColor Green }

Write-Host "`n##########################################################"
Write-Host "STAGE8: FUNCTIONAPP ALERT DEPLOYMENT SECTION"
Write-Host "##########################################################`n"

Utility-DisplayInfo -dxcstr1 "INFORMATION: Run the below command in powershell 7.x console, from" -dxcstr2 "...\OnBoarding\Alerting\FunctionAppAlertDeployment\" -dxcstr3 "folder to deploy alerts for this FunctionApp"
Write-Host ".\deployFunctionAppAlerts.ps1 -functionAppName $dxcFunctionAppName -appInsightsName $dxcAppInsightName -logAnalyticsWorkspaceName $LogAnalyticsWorkspaceName -subscriptionId $SubscriptionId -applicationName 'dxc-Heartbeat'"
Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
Write-Host "`n*****************End OF SCRIPT EXECUTION*****************"
