﻿# Heartbeat Alert Deployment

This folder contains the json and powershell files that are used to deploy Heartbeat function app and alerts

## Jira Epic
https://jira.dxc.com/browse/AZR-12404

## Deployment
For more information on how to deploy heartbeat alerts see:
* Section 3.44 of Operations Guide
* https://confluence.dxc.com/display/CSA/AZR-12433%2C+AZR-12434+and+AZR-12435+Deployment+Script+for+Heartbeat+Alert

## Members of this directory are:
* DeployFunctions-HBAlerts.zip					Artifacts used by main script
* alerts-vm-availability-hbm.json				Child json executed by main script
* deployHBAlertFunctions.ps1					Main deployment script for heartbeat alerts
* Functions                           Subdirecory containing function app code which is zipped and deployed by the script

## Authors
* Santanu Sengupta
