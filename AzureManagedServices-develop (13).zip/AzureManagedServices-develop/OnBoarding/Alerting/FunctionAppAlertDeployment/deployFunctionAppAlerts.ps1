<#=======================================================================================================================
Required - Powershell Version 7.0, Powershell Az module 2.5.0, Az.Monitor 1.5.0 and Az.ApplicationInsights 1.0.1
=========================================================================================================================
AUTHOR:  Santanu Sengupta 
DATE:    14/07/2020
Version: 1.0
Documentation: https://confluence.dxc.com/display/CSA/AZR-15186+Deploy+Function+App+alerts
=========================================================================================================================#>

[CmdletBinding(SupportsShouldProcess=$true)]
Param
    (
    [Parameter(Mandatory=$true)]   [String]$functionAppName,
    [Parameter(Mandatory=$true)]   [String]$appInsightsName,
    [Parameter(Mandatory=$true)]   [String]$logAnalyticsWorkspaceName,
    [Parameter(Mandatory=$true)]   [String]$subscriptionId,
    [Parameter(Mandatory=$false)]  [String]$applicationName,
    [Parameter(Mandatory=$false)]  [Switch]$CustomTrace,
	[Parameter(Mandatory=$false)] [String]$TenantId,
	[Parameter(Mandatory=$false)] [String]$SpKey,
	[Parameter(Mandatory=$false)] [String]$ClientID
    )

#========================================================================================================================
# SEVERITY MAPPING SECTION (Conditions can be  "==", ">=" or "<=")
#========================================================================================================================
$dxcSeverityList = @(
    [PSCustomObject]@{ alertSeverity = "Informational";       logSeverityLevel = 0    ; }
    [PSCustomObject]@{ alertSeverity = "Minor";               logSeverityLevel = "==2"     ; }
    [PSCustomObject]@{ alertSeverity = "Major";               logSeverityLevel = 0 ; }
    [PSCustomObject]@{ alertSeverity = "Critical";            logSeverityLevel = ">=4" ; }
    )

#========================================================================================================================
# IMPORT CUSTOM MODULES AND CHECK POWERSHELL ENVIRONMENT
#========================================================================================================================
$dxcModuleList = "DXCEnvCheck.psm1", "DXCUtilityFunctions.psm1"

foreach ($dxcModule in $dxcModuleList)
    {
    [String]$dxcModuleURL = "https://dxcazuretoolsdev.blob.core.windows.net/installers/DXCPowershellModules/" + $dxcModule
    [String]$dxcLocalModule = $PSScriptRoot + "\" + $dxcModule
    (New-Object System.Net.WebClient).DownloadFile($dxcModuleURL, $dxcLocalModule)
    Import-Module $dxcLocalModule -WA 0
    Remove-Item -Path $dxcLocalModule
    }
Check-PSVersion -dxcPSVersion 7.0
Check-AzModuleVersion -dxcAzModuleVersion 2.5.0
Check-PSModule -dxcPSModule "Az.Monitor" -dxcPSModuleVersion 1.5.0
Check-PSModule -dxcPSModule "Az.ApplicationInsights" -dxcPSModuleVersion 1.0.1

#========================================================================================================================
# VARIABLE SECTION
$ErrorActionPreference = "SilentlyContinue"
$WarningPreference = "SilentlyContinue"

[String]$dxcEventProcessingSchema = "3.0"
[String]$dxcAlertVersion = "2.4.6"
[String]$dxcARMStandard = $PSScriptRoot + "\alerts-FunctionApp-Standard.json"

If(-not($applicationName)) { $applicationName = $functionAppName }

#Count number of deploying alert
$dxcNewStandardAlertContent =  Get-Content -Raw -Path $dxcARMStandard | ConvertFrom-Json
$dxcNewStandardAlertCount = ($dxcNewStandardAlertContent.variables.alertsArray).Count
[int]$dxcNewTracesAlertCount = 0

if ($CustomTrace)
    {
    [String]$dxcARMTraces = $PSScriptRoot + "\alerts-FunctionTraces-Custom.json"

    $dxcARMTracesCustomContent = Get-Content -Raw -Path $dxcARMTraces | ConvertFrom-Json
    $dxcNewTracesAlertCount = ($dxcARMTracesCustomContent.variables.alertArray).Count
    }
else
    {
    [String]$dxcARMTraces = $PSScriptRoot + "\alerts-FunctionTraces-Standard.json"

    foreach ($logSeverityLevel in $dxcSeverityList.logSeverityLevel)
        {
        If ($logSeverityLevel -ne 0) { $dxcNewTracesAlertCount++ }
        }
    }
$dxcTotalNewDeployments = $dxcNewStandardAlertCount + $dxcNewTracesAlertCount
$dxcAlertFileList = $dxcARMStandard.split("\")[-1] , $dxcARMTraces.split("\")[-1]

#========================================================================================================================
# MAIN BODY OF THE SCRIPT
#========================================================================================================================
#Login to Azure
if ($SpKey) {
	Utility-LoginAZSpn -TenantId $TenantId -SpnKey $SpKey -ClientId $ClientID -SubscriptionId $SubscriptionId
	}
else {
	Utility-LoginAZ -dxcSubscriptionId $subscriptionId
	}


#Check Subscription Capacity for Alert deployment
$dxcSubscriptionAlertCount = (Get-AzScheduledQueryRule).Count
$dxcARMStandardContent = Get-Content -Raw -Path $dxcARMStandard | ConvertFrom-Json
$dxcNewStandardAlertCount = ($dxcARMStandardContent.variables.alertsArray).Count



If (( $dxcSubscriptionAlertCount + $dxcNewStandardAlertCount ) -gt 512 )
    { 
    Utility-DisplayWarning -dxcstr1 "`nWARNING:     Existing number of deployed scheduled query alert rule in the subscription is" -dxcstr2 $dxcSubscriptionAlertCount -dxcstr3 "," 
    Utility-DisplayWarning -dxcstr1 "             and this script is going to deploy" -dxcstr2 $dxcTotalNewDeployments -dxcstr3 "more."
    Utility-DisplayWarning -dxcstr1 "             The default maximum value per subscription is" -dxcstr2 "512" 
    Write-Host "             Please engage Microsoft to increase maximum allowed value as per requirement, otherwise the deployment will fail." -ForegroundColor Yellow
    Write-Host "             Ignore this warning if necessery step has already been taken.`n" -ForegroundColor Yellow
    }
#>
# Collect Maintenance ResourceGroup and OMS Workspace Details.
$dxcObjWorkspace = Get-AzOperationalInsightsWorkspace | Where-Object { $_.Name -Match $logAnalyticsWorkspaceName }
If ($dxcObjWorkspace)
    {
    [String]$dxcLogAnalyticsWorkspaceName = $dxcObjWorkspace.Name
    [String]$dxcResourceGroup = $dxcObjWorkspace.ResourceGroupName
    [String]$dxcWorkspaceRegion = (($dxcObjWorkspace.location).ToLower()) -replace '\s',''

    Utility-DisplayInfo -dxcstr1 "INFORMATION: Loganalytics Workspace named" -dxcstr2 $dxcLogAnalyticsWorkspaceName -dxcstr3 "located under ResourceGroup" -dxcstr4 $dxcResourceGroup
    }
else
    {
    Write-Host "WARNING:     Loganalytics Workspace not found. Please enter correct workspace name while running the script." -ForegroundColor Yellow
    Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
    Read-Host "`nPress 'ENTER'to exit the script........"
    exit
    }

# Collect Application Insight and FunctionApp Details.
$dxcObjFunctionApp = Get-AZWebApp | Where-Object {($_.Kind -Match 'functionapp') -and ($_.Name -Match $functionAppName)}

If ($dxcObjFunctionApp)
    {
    $dxcFunctionAppRG = $dxcObjFunctionApp.ResourceGroup
    $dxcFunctionAppId = $dxcObjFunctionApp.Id
    Utility-DisplayInfo -dxcstr1 "INFORMATION: FunctionApp named" -dxcstr2 $functionAppName -dxcstr3 "located under ResourceGroup" -dxcstr4 $dxcFunctionAppRG

    $dxcObjAppInsight = Get-AzApplicationInsights -Name $appInsightsName -ResourceGroupName $dxcFunctionAppRG
    
    If ($dxcObjAppInsight)
        {
        Utility-DisplayInfo -dxcstr1 "INFORMATION: Application Insight named" -dxcstr2 $appInsightsName -dxcstr3 "located under ResourceGroup" -dxcstr4 $dxcFunctionAppRG
        }
    else 
        {
        Utility-DisplayWarning -dxcstr1 "WARNING:     Application Insight not found under the FunctionApp ResourceGroup" -dxcstr2 $dxcFunctionAppRG -dxcstr3 " . Please enter correct Application Insight name while running the script."
        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        Read-Host "`nPress 'ENTER'to exit the script........"
        exit
        }
    }
else
    {
    Write-Host "WARNING:     FunctionApp not found. Please enter correct FunctionApp name while running the script." -ForegroundColor Yellow
    Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
    Read-Host "`nPress 'ENTER'to exit the script........"
    exit
    }

foreach( $dxcAlertFileName in $dxcAlertFileList )
    {
    $dxcDeploymentName = $dxcAlertFileName.split(".")[0]
    Utility-DisplayInfo -dxcstr1 "`nINFORMATION: Alert file" -dxcstr2 $dxcAlertFileName -dxcstr3 "deployment in progress, it may take few minutes..."

    $error.clear() 
    if ( $dxcAlertFileName -eq "alerts-FunctionTraces-Standard.json" )
        { 
        ForEach ($dxcSeverity in $dxcSeverityList)
            {
            If ($dxcSeverity.logSeverityLevel -ne 0) 
                { New-AzResourceGroupDeployment -Name $dxcDeploymentName -ResourceGroupName $dxcResourceGroup -TemplateFile $dxcARMTraces -functionAppName $functionAppName -applicationName $applicationName -alertSeverity $dxcSeverity.alertSeverity -logSeverityLevel $dxcSeverity.logSeverityLevel -appInsightsName $appInsightsName -appInsightsResourceGroup $dxcFunctionAppRG -logAnalyticsWorkspaceName $dxcLogAnalyticsWorkspaceName -logAnalyticsWorkspaceLocation $dxcWorkspaceRegion -logAnalyticsWorkspaceResourceGroup $dxcResourceGroup -eventProcessingSchema  $dxcEventProcessingSchema -alertVersion $dxcAlertVersion }
            }
        }

    elseif ( $dxcAlertFileName -eq "alerts-FunctionTraces-Custom.json" )
        { New-AzResourceGroupDeployment -Name $dxcDeploymentName -ResourceGroupName $dxcResourceGroup -TemplateFile $dxcARMTraces -functionAppName $functionAppName -applicationName $applicationName -appInsightsName $appInsightsName -appInsightsResourceGroup $dxcFunctionAppRG -logAnalyticsWorkspaceName $dxcLogAnalyticsWorkspaceName -logAnalyticsWorkspaceLocation $dxcWorkspaceRegion -logAnalyticsWorkspaceResourceGroup $dxcResourceGroup -eventProcessingSchema  $dxcEventProcessingSchema -alertVersion $dxcAlertVersion } 
    
    else 
        { New-AzResourceGroupDeployment -Name $dxcDeploymentName -ResourceGroupName $dxcResourceGroup -TemplateFile $dxcARMStandard -functionAppName $functionAppName -applicationName $applicationName -appInsightsName $appInsightsName -appInsightsResourceGroup $dxcFunctionAppRG -logAnalyticsWorkspaceName $dxcLogAnalyticsWorkspaceName -logAnalyticsWorkspaceLocation $dxcWorkspaceRegion -logAnalyticsWorkspaceResourceGroup $dxcResourceGroup -eventProcessingSchema  $dxcEventProcessingSchema -alertVersion $dxcAlertVersion } 
    
    if ($Error) 
        { 
        Utility-DisplayWarning -dxcstr1 "WARNING:     Alert deployment failed, to check for details, go to the ResourceGroup" -dxcstr2 $dxcResourceGroup -dxcstr3 "in Azure portal and look for errors under deployment named" -dxcstr4 $dxcDeploymentName
        }
    else { Utility-DisplayInfo -dxcstr1 "INFORMATION: Deployment" -dxcstr2 $dxcDeploymentName -dxcstr3 "completed successfully." }
    }
