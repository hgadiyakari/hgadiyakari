<#=================================================================================================================
Required - Powershell Version 7.0, Azure CLI Version 2.1.0
===================================================================================================================
===================================================================================================================
AUTHOR:  Mustafa El-Jarrah
DATE:    28/04/2021
Version: 1.0
==================================================================================================================#>

#Requires -Version 7
#Requires -PSEdition Core

#Collect required parameters
[CmdletBinding(SupportsShouldProcess=$true)]
Param
    (
    [Parameter(Mandatory=$true)] [String]$subscriptionId,    
    [Parameter(Mandatory=$true)] [String]$actionRuleName,
    [Parameter(Mandatory=$true)] [ValidateSet("True","False")] [String]$suppressAlerts,
        [Parameter(Mandatory=$false)] [String]$tenantId,
        [Parameter(Mandatory=$false)] [String]$spKey,
        [Parameter(Mandatory=$false)] [String]$clientID
    )

$WarningPreference = "SilentlyContinue"


#Check environemnt for required modules
$dxcModuleList = "DXCEnvCheckV2.psm1"
foreach ($dxcModule in $dxcModuleList)
    {
    [String]$dxcModuleURL = "https://dxcazuretools.blob.core.windows.net/installers/DXCPowershellModules/" + $dxcModule
    [String]$dxcLocalModule = $PSScriptRoot + "\" + $dxcModule
    (New-Object System.Net.WebClient).DownloadFile($dxcModuleURL, $dxcLocalModule)
    Import-Module $dxcLocalModule -WA 0
    Remove-Item -Path $dxcLocalModule
    }


$dxcAZCli = Check-AzureCLI -Version 2.1.0 
if (!$dxcAZCli)
    {
    Read-Host "`Press 'ENTER' to exit the script........"
    exit
    }

#Connect to Azure & Subscription
Write-Host "Connecting to Azure and subscription"
Start-Sleep -S 3
if ($SpKey) {
	Utility-LoginAZSpn -TenantId $tenantId -SpnKey $spKey -ClientId $clientID -SubscriptionId $subscriptionId
	}
else {
	Login-AzAccount -SubscriptionId $subscriptionId
	}

#Suppress alerts or disable suppression based on user response
if ($suppressAlerts -eq "true")
    {
        Set-AzActionRule -ResourceGroupName "DXC-Maint-RG" -Name $actionRuleName -Scope "/subscriptions/$subscriptionId" -MonitorCondition "NotEquals:Resolved" -Description "DXC NIST Alerts are suppressed" -Status "Enabled" -ActionRuleType "Suppression" -DescriptionCondition "Contains:NIST-DXC-Alert" -ReccurenceType "Always" 
        Write-Host "NIST Alerts have been suppressed"
        exit
    }

elseif ($suppressAlerts -eq "false") {
       Update-AzActionRule -ResourceGroupName "DXC-Maint-RG" -Name $actionRuleName -Status "Disabled"
       Write-Host "NIST Alert suppression has been disabled"
       exit
    }