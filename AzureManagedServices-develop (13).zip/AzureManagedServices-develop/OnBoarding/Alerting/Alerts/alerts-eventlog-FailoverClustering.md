## Monitoring Microsoft Failover Cluster Service on Azure VMs.

Microsoft suggested to monitor:
- Event ID 1135 - Cluster node ‘NodeName’ was Removed From the Active Failover Cluster Membership: -- http://blogs.technet.com/b/askcore/archive/2012/02/08/having-a-problem-with-nodes-being-removed-from-active-failover-cluster-membership.aspx 
- Event ID 1069: http://technet.microsoft.com/en-us/library/cc756225(v=ws.10).aspx 
- Event ID 1177 for Quorum loss: http://technet.microsoft.com/en-us/library/cc773498(v=ws.10).aspx 
- Event ID 1006 for Cluster service halted: http://technet.microsoft.com/en-us/library/cc773418(v=WS.10).aspx 
- Event ID 1230: (resource type '', DLL 'clusres.dll') either crashed or deadlocked. https://docs.microsoft.com/en-us/previous-versions/windows/it-pro/windows-server-2008-R2-and-2008/cc773436(v=ws.10)
- Event ID 1146 “The cluster Resource Hosting Subsystem (RHS) process was terminated and will be restarted. This is typically associated with cluster health detection and recovery of a resource. Refer to the System event log to determine which resource and resource DLL is causing the issue.” https://docs.microsoft.com/en-us/previous-versions/windows/it-pro/windows-server-2008-R2-and-2008/cc773478(v=ws.10)?redirectedfrom=MSDN

Another request came part of Jira case: https://jira.csc.com/browse/AZR-11291
- Event ID 1205: http://kb.eventtracker.com/evtpass/evtpages/EventId_1205_Microsoft-Windows-FailoverClustering_65145.asp  - Cluster service failed to bring clustered service or application completely online or offline.
