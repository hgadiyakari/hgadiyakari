﻿#Searches for and removes any legacy OMS Log Analytics Alert Rules for SQL Managed instance.

param(
       [Parameter(Position = 0)][string[]]$alertrules
    )

#Checks subscription in use"
$SubContext = get-azcontext
Write-Host "Using subscription" $SubContext.name


if (($RGName = Read-Host -Prompt "Enter Resource Group Name. Default is [DXC-Maint-rg]") -eq "") {$RGName= "DXC-Maint-rg"}      



Foreach ($alertrule in $alertrules)
    {
    Write-Host "Searching for legacy SQL Managed Instance Alert Rules in Log Analytics" -ForegroundColor Green
    $alertcheck = Get-azscheduledqueryrule -ResourceGroupName $RGName -Name $alertrule -WarningAction SilentlyContinue
        
        if ($null -ne $alertcheck){
            Write-Host "Found Alert Rule $alertrule. Attempting to delete $alertrule." -ForegroundColor Green
            Remove-AzScheduledQueryRule -ResourceGroupName $RGName -name $alertrule
            $alertcheck = Get-azscheduledqueryrule -ResourceGroupName $RGName -Name $alertrule -WarningAction SilentlyContinue

            if ($null -eq $alercheck){
                 Write-Host "Alert Rule $alertrule deleted." -ForegroundColor Green
                }
        
            else{
                 Write-Host "Could not delete $alertrule. Check your permissions and try again." -ForegroundColor Red
             }
        }
            
        else {
        Write-Host $alertrule "not found." -ForegroundColor Blue
        }
        
    }

    