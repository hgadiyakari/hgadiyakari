<#=======================================================================================================================
Required - Powershell Version 5.1, Powershell Azure module 5.0.0
=========================================================================================================================
AUTHOR:  Santanu Sengupta 
DATE:    14/04/2020
Version: 7.0
Documentation: https://confluence.csc.com/pages/viewpage.action?pageId=205535085
=========================================================================================================================
.SYNOPSIS
    Creates ITSM connector. Deploys ActionGroups with ITSM Actions and/or Email Actions. Deploys Alerts.
.DESCRIPTION
    .PARAMETER  dxcSubscriptionID
		Specifies the Subscription ID of Susbcription hosting the Log Analytics Workspace.
    .PARAMETER  dxcLogAnalyticsWorkspaceName
		Specifies the name Log Analytics Workspace used for connecting to DXC ServiceNow instance.
    .PARAMETER  dxcAlertNotificationEmail
		Specifies the support team's email address for email notifications.
    .OPTIONAL PARAMETER  dxcAppID
		Application ID for Authentication with Service Principal Name.
    .OPTIONAL PARAMETER  dxcAppKey
		Application Key for Authentication with Service Principal Name.
    .OPTIONAL PARAMETER  dxcTenantID
		Tenant ID for Authentication with Service Principal Name.
    .SWITCH PARAMETER  AzureStack
		To deploy additional Azure Stack related Alerts.
=======================================================================================================================#>

[CmdletBinding(SupportsShouldProcess=$true)]
Param
    (
    [Parameter(Mandatory=$true)]  [String]$dxcSubscriptionID,
    [Parameter(Mandatory=$true)]  [String]$dxcLogAnalyticsWorkspaceName,
    [Parameter(Mandatory=$true)]  [String]$dxcalertNotificationEmail,
    [Parameter(Mandatory=$false)] [String]$dxcAppID,
    [Parameter(Mandatory=$false)] [String]$dxcAppKey,
    [Parameter(Mandatory=$false)] [String]$dxcTenantID,
    [Parameter(Mandatory=$false)] [Switch]$AzureStack
    )

#========================================================================================================================
# IMPORT CUSTOM MODULES AND CHECK POWERSHELL ENVIRONMENT
#========================================================================================================================
$dxcModuleList = "DXCEnvCheck.psm1", "DXCUtilityFunctions.psm1"

foreach ($dxcModule in $dxcModuleList)
    {
    [String]$dxcModuleURL = "https://dxcazuretoolsdev.blob.core.windows.net/installers/DXCPowershellModules/" + $dxcModule
    [String]$dxcLocalModule = $PSScriptRoot + "\" + $dxcModule
    (New-Object System.Net.WebClient).DownloadFile($dxcModuleURL, $dxcLocalModule)
    Import-Module $dxcLocalModule -WA 0
    Remove-Item -Path $dxcLocalModule
    }
Check-PSVersion -dxcPSVersion 7.0
Check-AzModuleVersion -dxcAzModuleVersion 2.5.0

# Validate Email Address Format
Check-EmailAddress -dxcEmailAddress $dxcalertNotificationEmail 

#========================================================================================================================
# VARIABLE SECTION
#========================================================================================================================
$ErrorActionPreference = "SilentlyContinue"
$WarningPreference = "SilentlyContinue"

[String]$dxcEventProcessingSchema = "3.0"
[String]$dxcAlertVersion = "2.16"
$dxcITSMAG = $PSScriptRoot + '\deployITSMActionGroup.json'
$dxcEmailUser = $dxcalertNotificationEmail.Split('@')[0]

#Declare required ActionGroups here
$dxcCreateAGList = @(
    [PSCustomObject]@{ Name = "DXC-AG-Critical";      Severity = "Critical"; SeverityNumber = 1; }
    [PSCustomObject]@{ Name = "DXC-AG-Major";         Severity = "Major";    SeverityNumber = 2; }
    [PSCustomObject]@{ Name = "DXC-AG-Minor";         Severity = "Minor";    SeverityNumber = 3; }
    [PSCustomObject]@{ Name = "DXC-AG-Warning";       Severity = "Warning";  SeverityNumber = 4; }
    [PSCustomObject]@{ Name = "DXC-AG-Informational"; Severity = "Info";     SeverityNumber = 5; }
    [PSCustomObject]@{ Name = "DXC-AG-Email";         Severity = "Email";    SeverityNumber = 1; }
    )

#========================================================================================================================
# MAIN BODY OF THE SCRIPT
#========================================================================================================================

#Login to Azure
if ($dxcAppKey) {
	Utility-LoginAZSpn -TenantId $dxcTenantID -SpnKey $dxcAppKey -ClientId $dxcAppID -SubscriptionId $dxcSubscriptionID
	}
else {
	Utility-LoginAZ -dxcSubscriptionId $dxcSubscriptionID
	}

# Collect Maintenance ResourceGroup and OMS Workspace Details.
$dxcObjWorkspace = Get-AzOperationalInsightsWorkspace | Where-Object { $_.Name -Match $dxcLogAnalyticsWorkspaceName }
If ($dxcObjWorkspace)
    {
    [String]$dxcLogAnalyticsWorkspaceName = $dxcObjWorkspace.Name
    [String]$dxcResourceGroup = $dxcObjWorkspace.ResourceGroupName
    [String]$dxcWorkspaceRegion = (($dxcObjWorkspace.location).ToLower()) -replace '\s',''
    $dxcWorkspaceId = $dxcObjWorkspace.CustomerId.Guid

    Utility-DisplayInfo -dxcstr1 "INFORMATION: Loganalytics Workspace named" -dxcstr2 $dxcLogAnalyticsWorkspaceName -dxcstr3 "located under ResourceGroup" -dxcstr4 $dxcResourceGroup
    }
else
    {
    Write-Host "WARNING:     Loganalytics Workspace not found. Please enter correct workspace name while running the script." -ForegroundColor Yellow
    Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
    Read-Host "`nPress 'ENTER'to exit the script........"
    exit
    }

#Check for the availability of Required Action Groups and create if missing
$dxcAGlist = Get-AzActionGroup -ResourceGroupName $dxcResourceGroup | Where-Object {($_.GroupShortName -match "dxc") -and ($_.Name -match "DXC-")}

foreach($dxcCreateAG in $dxcCreateAGList)
    {
    [bool]$flgDeployAG = $true
    if ($dxcAGlist.count -gt 0 )
        {
        foreach($dxcAG in $dxcAGlist)
            {
            If ($dxcAG.Name -ieq $dxcCreateAG.Name) { $flgDeployAG = $false; break }
            }
        }
    if($flgDeployAG)
        {
        Utility-DisplayInfo -dxcstr1 "INFORMATION: ActionGroup" -dxcstr2 $dxcCreateAG.Name -dxcstr3 "not found. Creating..."
        $error.Clear()
        If ($dxcCreateAG.Name -ieq "DXC-AG-Email")
            {
            $email1 = New-AzActionGroupReceiver -Name $dxcEmailUser -EmailReceiver -EmailAddress $dxcalertNotificationEmail
            Set-AzActionGroup -Name $dxcCreateAG.Name -ResourceGroup $dxcResourceGroup -ShortName 'dxcEmail' -Receiver $email1
            }
        else { New-AzResourceGroupDeployment -Name $dxcCreateAG.Name -ResourceGroupName $dxcResourceGroup -TemplateFile $dxcITSMAG -Severity $dxcCreateAG.severity -SeverityNo $dxcCreateAG.SeverityNumber -omsWorkspaceId $dxcWorkspaceId -omsWorkspaceRegion $dxcWorkspaceRegion }

        if ($error) 
            { 
            Utility-DisplayWarning -dxcstr1 "WARNING:     Failed to deploy ActionGroup" -dxcstr2 $dxcCreateAG.Name -dxcstr3 ". Script will exit now."
            Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
            Read-Host "`nPress 'ENTER'to exit the script........"
            exit
            }
        else { Utility-DisplayInfo -dxcstr1 "INFORMATION: ActionGroup" -dxcstr2 $dxcCreateAG.Name -dxcstr3 "deployed successfully." }
        }
    }

# Get list of Alert templates to be deployed based on switch selection
if($AzureStack -eq $false) { $dxcAlertFileList = (get-childitem ($PSScriptRoot + '\alerts-*.json') -exclude 'alerts-azurestack-*.json' |select FullName) }
else { $dxcAlertFileList = (get-childitem ($PSScriptRoot + '\alerts-*.json') |select FullName) }

# Deploy the arm templates one by one
ForEach ($dxcAlertFileName in $dxcAlertFileList)
    {
	$dxcThisAlertFileName = $dxcAlertFileName.FullName
    $dxcThisAlertDeploymentFile = ($dxcThisAlertFileName.Split("\"))[($dxcThisAlertFileName.Split("\")).Count -1]

    Utility-DisplayInfo -dxcstr1 "INFORMATION: Calling Alert Deployment ARM Template" -dxcstr2 $dxcThisAlertDeploymentFile -dxcstr3 "to Deploy Alerts."
    [String]$dxcThisAlertDeploymentName = ($dxcThisAlertDeploymentFile.Split("."))[0]

    $Error.Clear() 	
    if($dxcThisAlertDeploymentName -eq "alerts-itsm") { New-AzResourceGroupDeployment -Name $dxcThisAlertDeploymentName -ResourceGroupName $dxcResourceGroup -TemplateFile $dxcThisAlertFileName -omsWorkspaceName $dxcLogAnalyticsWorkspaceName -omsWorkspaceLocation $dxcWorkspaceRegion -alertVersion $dxcAlertVersion }
    elseif (($dxcThisAlertDeploymentName -eq "alerts-azurestack-CMDBUpdates") -or ($dxcThisAlertDeploymentName -eq "alerts-azurestack-platform") -or ($dxcThisAlertDeploymentName -eq "alerts-azurestack-syslog-TOR"))
        { New-AzResourceGroupDeployment -Name $dxcThisAlertDeploymentName -ResourceGroupName $dxcResourceGroup -TemplateFile $dxcThisAlertFileName -omsWorkspaceName $dxcLogAnalyticsWorkspaceName -omsWorkspaceId $dxcWorkspaceId -omsWorkspaceLocation $dxcWorkspaceRegion -alertVersion $dxcAlertVersion -alertNotificationEmail $dxcalertNotificationEmail }
    else { New-AzResourceGroupDeployment -Name $dxcThisAlertDeploymentName -ResourceGroupName $dxcResourceGroup -TemplateFile $dxcThisAlertFileName -omsWorkspaceName $dxcLogAnalyticsWorkspaceName -omsWorkspaceLocation $dxcWorkspaceRegion -eventProcessingSchema  $dxcEventProcessingSchema -alertVersion $dxcAlertVersion }	
	
    if ($Error) { Write-Host "WARNING:     Alert Deployment failed. For detailed error message, please check deployment error in the Resource Group from Azure Portal." -ForegroundColor yellow }
    }       
Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0

Write-Host "`n####################### END OF SCRIPT EXECUTION ###################################"

