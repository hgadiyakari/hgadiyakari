# ADDS critical events templates

This document describes how to setup Domain Controller's Directory critical event services monitoring.

In order to get alerts from Domain Controller's Directory Services related events two templates were modified:

1. **deployLogAnalytics.json** modified by adding section:
 
  {  
               "apiVersion":"2015-11-01-preview",  
               "type":"datasources",  
               "name":"DirectoryServicesLogs",  
               "dependsOn":[    
                  "[concat('Microsoft.OperationalInsights/workspaces/', variables('omsWorkspaceName'))]"  
               ],  
               "kind":"WindowsEvent",  
               "properties":{    
                  "eventLogName":"Directory Service",  
                  "eventTypes":[    
                     {    
                        "eventType":"Error"  
                     }	  
                  ]  
               }  
            },  
 
 -this will fetch "Directory Services" windows eventlog errors to Log Analytics Workspace
   
   2. **alerts-eventlog.json** modified by adding section:  
   >  {  
                  "alertName":"DXC-Critical-Directory Service Event Log",  
                  "description":"Directory Service Event Logs Critical",  
                  "severity":"0",  
                  "query":"Event | where  EventLog=='Directory Service' and EventLevelName=='Error'",  
                  "searchCategory":"Event",  
                  "alertThresholdValue":0,  
                  "operator":"GreaterThan",  
                  "scheduleIntervalInMinutes":5,  
                  "scheduleQueryTimeSpan":5,        
                  "eventType":"Event Log",  
                  "eventResource":"Directory Service",  
            	     "actionGroupName":"DXC-AG-Critical"  
                  }    
   
   -this will create alert based on events from "Directory Service"
   
   # Service Now side
      
   In order to route alerts to AD assignment group the record have to be created in Service Now "Alert Directors" table:   
   Note. AD assignment group must exist in SNOW before adding record to "Alert Directors" table (if not present, can be created with People & Places -> Groups)
   
   
   > Subscription: - subscription name  
   > Company: SNOW company name  
   > Resource: "Directory Service"  
   > Source: "OMS"  
   > Type: "Event Log"  
   > Assignment group: - AD assignment group name 
