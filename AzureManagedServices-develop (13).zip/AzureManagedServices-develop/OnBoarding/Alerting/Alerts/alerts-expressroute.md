## Express Route Alerts 
## ER Alerts (alerts-expressroute.json template)
- Template to be used with powershell script to install alerts for Express Route monitoring.
- Template required parameters are all related to Log Analytics Workspace (RG, Location, LAW Name, LAW ID, LAW Region, Version and E-mail)
### alerts-appgw.json template creates folowing alerts:
### 1 alert: DXC-Critical-ExpressRoute Circuit-Circuit network Utilization
- Severity: Critical
- Query: NetworkMonitoring  | where SubType == 'ERCircuitTotalUtilization' | where UtilizationHealthState <> 'Healthy' or BitsInPerSecond == 0 or BitsOutPerSecond == 0
- Description: ExpressRoute Circuit, Circuit Utilization status from NetMon is not healthy (HW/Partner/Azure network related)
- Requirements: 1. NetworkMonitoring Solution, 2. Network Performance Monitor Configuration (see NPM section bellow) 
- Trigger: trigger if status is unhealthy or no trafic (BitsInPerSecond or BitsOutPerSecond are zeros)
### 2 alert: DXC-Critical-ExpressRoute Circuit-Connection network Utilization
- Severity: Critical
- Query: NetworkMonitoring  | where SubType == 'ERVNetConnectionUtilization' | where UtilizationHealthState <> 'Healthy' or BitsInPerSecond == 0 or BitsOutPerSecond == 0
- Description: ExpressRoute Circuit, Connection Utilization status from NetMon is not healthy (SW/AzureGW/ClientGW network related)
- Requirements: 1. NetworkMonitoring Solution, 2. Network Performance Monitor Configuration (see NPM section bellow) 
- Trigger: trigger if status is unhealthy or no trafic (BitsInPerSecond or BitsOutPerSecond are zeros)
### 3 alert: DXC-Critical-ExpressRoute Circuit-Utilization
- Severity: Critical
- Query: AzureMetrics | where ResourceProvider == 'MICROSOFT.NETWORK' | where ResourceId has 'EXPRESSROUTECIRCUITS' | where MetricName == 'BitsInPerSecond' or MetricName == 'BitsOutPerSecond' | where Average == 0
- Description: ExpressRoute Circuit, Utilization from Metrics is not healthy (ER/Azure related)
- Requirements: DXCdiagnostics enabled for Expressroute Circuit
- Trigger: trigger if no trafic (BitsInPerSecond or BitsOutPerSecond are zeros)
### 4 alert: DXC-Warning-ExpressRoute Circuit-Configuration Failure
- Severity: Warning
- Query: AzureActivity | where ResourceProvider == 'Microsoft.Network' | where Level == 'Error' | where OperationName has 'VirtualNetworkGatewayConnection' or  OperationName has 'ExpressRouteCircuit'
- Description: ExpressRoute Circuit, ER/GW Configuration Failures, OMS logs shows only certain configuration changes when it is initiated by person, at the submit time only.
- Requirements: DXCdiagnostics enabled for Expressroute Circuit and Virtual network gateway
- Trigger: when there is configuration change with failed state

## Network Performance Monitor Configuration
- To add ER resources to NPM you need to do these steps:
- Open Network Monitoring solution 
- On Overview tab: press on NPM Box (or View Summary)
- Select Configure
- Select EXPRESSROUTE MONITOR 
- Select Subsscribtion 
- Run Discover ExpressRoute resources
- Select found resources and do Monitor for them
- Open Monitoring Tab
- Select check boxes Monitoring+Health+Bandwidth for both Circuits and Peerings (or any other resource you discover)
