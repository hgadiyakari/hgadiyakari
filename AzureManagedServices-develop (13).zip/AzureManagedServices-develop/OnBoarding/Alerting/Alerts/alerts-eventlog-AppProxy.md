## Application Proxy alert

Application Proxy alert will query Event table for Windows System Events.
Application Proxy alert will triger when service 'Microsoft AAD Application Proxy Connector' enter any other state than running.
Application Proxy alert should be installed together with all other alerts.
