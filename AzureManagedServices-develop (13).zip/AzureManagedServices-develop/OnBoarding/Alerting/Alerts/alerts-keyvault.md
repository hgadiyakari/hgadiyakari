# Azure Key Vault alert deployment template

Template location: https://github.dxc.com/cloud/AzureOffering_ServiceNow/blob/master/OMS/oms-alerts/alerts-keyvault.json

Paramaters:

* omsWorkspaceName - name of Log Analytics workspace from which alerts will take data.

* omsWorkspaceId -  id of Log Analytics workspace from which alerts will take data (can be found in log analytics workspace "Overview" page in Azure portal).

* omsWorkspaceRegion - Region of Log Analytics workspace (can be found in log analytics workspace "Overview" page in Azure portal as "Location", space character have to be removed from Location. For example: "WestEurope").

* alertVersion - current alert version according to DXC offering versioning system.

* alertNotificationEmail - an email to which notification will be send.

## Alerts created by template
**DXC-Warning-KeyVault-unauthorized-access-attempt** 
* Severity: Warning.
* Event Type: Security
* Description: This is achieved by filtering log analytics workspace with *AzureDiagnostics| where ResourceProvider == 'MICROSOFT.KEYVAULT' | where ResultSignature == 'Forbidden'* query. Occurs when someone try to access KeyVault but  access attempt violetes Key Vault access policy.
<br/>  
<br/>  

**DXC-Warning-KeyVault-change-in-access-policies** 
* Severity: Warning.
* Event Type: Change
* Description: Occurs then Key Vault access policy changed. Based on *query":"AzureDiagnostics| where ResourceProvider == 'MICROSOFT.KEYVAULT' | where OperationName == 'VaultPatch'* query.
 <br/>  
<br/>  
 
**DXC-Warning-KeyVault-secret-delete** 
* Severity: Warning.
* Event Type: Change
* Description: Occurs then secret is deleted from the Key Vault. Based on *AzureDiagnostics| where ResourceProvider == 'MICROSOFT.KEYVAULT'| where OperationName == 'SecretDelete'* query.
<br/>  
<br/>  
 
**DXC-Warning-KeyVault-Latency-delay**
* Severity: Warning.
* Event Type: Performance
* Description: Occurs then latency of key Vault operations exceed 53 (could be any other client dependent value). Based on *AzureMetrics| where ResourceProvider == 'MICROSOFT.KEYVAULT'| where MetricName == 'ServiceApiLatency' and Average>53* query.
 <br/>  
<br/>  
 


### Prerequisities
* It is recommended to create log analytics with keyVaultAnalytics solution (template for this can be found in https://github.dxc.com/cloud/AzureOffering_ServiceNow/blob/master/OMS/oms-production-v2.1.json)
* Resource group to which Key Vault is deployed must have "itsmc_id" tag. Value of the tag is ITSM (Service Now) GUID.
* Deploying template user must be logged to required subscription

## Deployment
### Azure portal deployment
![azure portal deployment](https://github.dxc.com/cloud/AzureOffering_ServiceNow/blob/master/OMS/oms-alerts/alerts-keyvault.png)
### AZ CLI deployment
 Another way to deploy templates is using AZ CLI.
After establishing AZ CLI connection to required subscription following commands can be performed in order to Validate and Deploy template:

**Validation:**  
*az group deployment validate ^  
--resource-group  \<yourRGname\> ^  
  --template-file  \<local path to file\>\alerts-keyvault.json ^  
  --parameters @\<local path to file\>\alerts-keyvault_paramaters.json*

Output of validate command should be examined for errors


**Deployment:**  
*az group deployment create ^  
--name KeyVaultAlertsDeploymentName ^  
--resource-group  \<yourRGname\>  ^  
--template-file  \<local path to file\>\alerts-keyvault.json ^  
--parameters @\<local path to file\>\alerts-keyvault_paramaters.json.json*

After running this command, you can go to Resource group in Azure portal, select Deployments and verify status of KeyVaultDeployment job


"^" symbol is used to split one line intoto multiple lines - it works under Windows AZ CLI, Some other installations of AZ CLI use "\\" for creating multiline commands

### Powershell deployment
Template deployment can be performed with following powershell command:

*New-AzResourceGroupDeployment -Name KeyVaultAlertsDeploymentName -ResourceGroupName \<yourRGname\> `
  -TemplateFile c:\MyTemplates\alerts-keyvault.json `
  -TemplateParameterFile c:\MyTemplates\alerts-keyvault_parameters.json*


