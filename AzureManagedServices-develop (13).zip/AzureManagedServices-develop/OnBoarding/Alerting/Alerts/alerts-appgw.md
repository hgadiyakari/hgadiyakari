## AppGW Alerts (alerts-appgw.json template)
- Template to be used with powershell script to install alerts for Application Gateway monitoring.
- Template required parameters are all related to Log Analytics Workspace (RG, Location, LAW Name, LAW ID, LAW Region, Version and E-mail)
### AppGW Alert Action Groups
- alerts-appgw.json template creates following groups:
- DXC-AG-AGWactInf - Activity Informational
- DXC-AG-AGWactWar - Activity Warning
- DXC-AG-AGWactCri - Activity Critical
### alerts-appgw.json template creates folowing alerts:

### 1 alert: DXC-Critical-ApplicationGateway-InstanceSTOP
- Severity: Critical
- Query: AzureActivity | where OperationName == "Stop an application gateway" and ActivityStatusValue == "Succeeded"
- Description: AppGW Stop/Start detection, backend services may be unaccesible, critical, this activity creates multiple log entries to triger alert only once we search for value 'Succeeded'
- Trigger: az network application-gateway stop -g AppGWResourceGroup -n AppGWName

### 2 alert: DXC-Informational-ApplicationGateway-InstanceSTART
- Severity: Informational
- Query: AzureActivity | where OperationName == "Start an application gateway" and ActivityStatusValue == "Succeeded"
- Description: Informational, this activity creates multiple log entries to triger alert only once we search for value 'Succeeded'
- Trigger: az network application-gateway start -g AppGWResourceGroup -n AppGWName

### 3 alert: DXC-Warning-ApplicationGateway-InstanceThroughputMediumLimit
- Severity: Warning
- Query: AzureMetrics | where ResourceId like "microsoft.network/applicationgateways" | where MetricName=="Throughput" and Average > 99614720
- Description: Number of bytes per second the Application Gateway has served. Medium sized intance limits are 100Mbps.
- Trigger: Alert if Avarage >95%
