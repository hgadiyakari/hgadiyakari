# Suppress NIST Alerts
The 'suppress-nist-alerts.ps1' script can be used to suppress NIST Alerts so they are not sent to SNOW. This provides and opportunity for the user to remediate 
any non-compliant controls before disabling the suppression. The script can also be run to disable any existing suppression.

Before running the script, please install the required module in Powershell by running the following command.
```
Install-Module Az.AlertManagement
```

## Parameters
The following parameters are required for this script:

| Parameter | Required Information |
| ----------- | ----------- |
| subscriptionId | Target subscription id |
| actionRuleName | Action Rule Name e.g NIST-Alert-Suppression | 
| suppressAlerts| 'True' or 'False' True will enable suppression and False will disable suppression | 

#### Author
- Mustafa El-Jarrah
- mustafa.eljarrah@dxc.com
