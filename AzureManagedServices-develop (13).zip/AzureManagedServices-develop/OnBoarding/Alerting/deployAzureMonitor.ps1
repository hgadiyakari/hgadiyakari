<#
=========================================================================================================================
Required - Powershell Core Version 7.00, Powershell Azure module 5.0 & ArmClient 2.1 (https://github.com/projectkudu/ARMClient)
=========================================================================================================================
AUTHOR:  Santanu Sengupta 
DATE:    13/11/2019
Version: 1.2
Documentation: https://confluence.csc.com/pages/viewpage.action?pageId=162088464
=========================================================================================================================
Name:  Micah Castorina
Date:    11/30/2020
Version: 1.2.1
Notes: Updated Retention Period
=========================================================================================================================
Azr-18637-Update-retention-period
.SYNOPSIS
    Creates ITSM connector. Deploys ActionGroups with ITSM Actions and/or Email Actions. Deploys Alerts.
.DESCRIPTION
    .PARAMETER  dxcSubscriptionID
		Specifies the Subscription ID of Subscription where the Log Analytics Workspace to be created.
    .PARAMETER  dxcResourceGroup
		Specifies the name of the Resource Group for the Log Analytics Workspace.
    .PARAMETER  dxcCustomerCompanyCode
		Specifies 4 to 6 digit alphanumeric customer code.
    .PARAMETER  dxcWorkspaceRegion
                Specifies the Location of the Log Analytics Workspace.Allowed values are "EastUS", "WestUS2", "SouthCentralUS", "WestCentralUS", "USGovArizona", "USGovVirginia", "CanadaCentral", "WestEurope", "UKSouth", "SoutheastAsia", "JapanEast", "CentralIndia", "AustraliaSoutheast".
    .PARAMETER  $dxcServiceTier
		Specifies the ServiceTier of Log Analytics Workspace.Allowed values are Standalone, PerNode and PerGB2018
    .PARAMETER  $dxcDataRetention
		Specifies the Data Retention period of Log Analytics Workspace. Default value is 7, maximum value is 730.
    .PARAMETER  dxcServiceNowURL
		URL of the ServiceNow Global Blueprint Instance to connect to.
    .PARAMETER  dxcServiceNowUser
		ServiceNow Integration User Name to be used for events insertion in ServiceNow.
    .PARAMETER  dxcServiceNowUserPwd
		ServiceNow Integration User password to be used for events insertion in ServiceNow.
    .PARAMETER  dxcServiceNowClientId
		ServiceNow Client Id to be used for ServiceNow Auth authentication.
    .PARAMETER  dxcServiceNowClientSecret
		ServiceNow Client Secret to be used for ServiceNow Auth authentication.
    .PARAMETER  dxcTenantID
		Tenant ID for Authentication with Service Principle Name
    .OPTIONAL PARAMETER  dxcAppID
		Application ID for Authentication with Service Principle Name.
    .OPTIONAL PARAMETER  dxcAppKey
		Application Key for Authentication with Service Principle Name.
#>

[CmdletBinding(SupportsShouldProcess=$true)]
Param
    (
    [Parameter(Mandatory=$true)] [String]$dxcSubscriptionID,
    [Parameter(Mandatory=$true)] [String]$dxcResourceGroup,
    [Parameter(Mandatory=$true)] [ValidatePattern('^[a-zA-Z0-9]+$')] [String]$dxcCustomerCompanyCode,
    [Parameter(Mandatory=$true)] [ValidateSet("EastUS", "WestUS2", "SouthCentralUS", "WestCentralUS", "USGovArizona", "USGovVirginia", "CanadaCentral", "WestEurope", "UKSouth", "SoutheastAsia", "JapanEast", "CentralIndia", "AustraliaSoutheast", IgnoreCase = $false)] [String]$dxcWorkspaceRegion,
    [Parameter(Mandatory=$true)] [ValidateSet("Standalone","PerNode", "PerGB2018",IgnoreCase = $false)]  [String]$dxcServiceTier,
    [Parameter(Mandatory=$true)] [ValidateRange(30,730)] [Int]$dxcDataRetention,
    [Parameter(Mandatory=$true)] [String]$dxcServiceNowURL,
    [Parameter(Mandatory=$true)] [String]$dxcServiceNowUser,
    [Parameter(Mandatory=$true)] [String]$dxcServiceNowUserPwd,
    [Parameter(Mandatory=$true)] [String]$dxcServiceNowClientId,
    [Parameter(Mandatory=$true)] [String]$dxcServiceNowClientSecret,
    [Parameter(Mandatory=$true)] [String]$dxcTenantID,
    [Parameter(Mandatory=$false)] [String]$dxcAppID,
    [Parameter(Mandatory=$false)] [String]$dxcAppKey
    )
#=====================================================================================================================
# CHECK ENVIRONMENT FOR NECESSERY MODULES
#=====================================================================================================================
$ModuleURL = "https://dxcazuretoolsdev.blob.core.windows.net/installers/DXCPowershellModules/DXCEnvCheck.psm1"
$LocalModule = $PSScriptRoot + "\DXCEnvCheck.psm1"
(New-Object System.Net.WebClient).DownloadFile($ModuleURL, $LocalModule)
Import-Module $LocalModule -WA 0
Remove-Item -Path $LocalModule

Check-PSVersion -dxcPSVersion 7.0
Check-PSModule -dxcPSModule Az -dxcPSModuleVersion 2.5.0
Check-ArmClientVersion -dxcArmClientVersion 1.2

#=====================================================================================================================
# VARIABLE SECTION
#=====================================================================================================================

$ErrorActionPreference = "Stop"
$Env:ARMCLIENT_TENANT =  $dxcTenantID

$dxcITSMconnectionName = $dxcCustomerCompanyCode + "-ITSMC"
$dxcLogAnalyticsWorkspaceName = 'DXC-' + $dxcCustomerCompanyCode + '-' + $dxcSubscriptionID.Substring(0,4) + '-loganalyticsWorkspace'
$dxcAzureMonitorSolutionJson = $PSScriptRoot + '\deployLogAnalytics.json'

#=====================================================================================================================
# LOGIN SECTION
#=====================================================================================================================
$error.Clear()
# If SPN Details provided, Login with the details.
If ($dxcAppID -and $dxcAppKey)
    {
    $dxcSecureAppKey = ConvertTo-SecureString $dxcAppKey -AsPlainText -Force
    $dxcCred = New-Object System.Management.Automation.PSCredential ($dxcAppID, $dxcSecureAppKey)
    $dxcAzureEnv = Get-AzEnvironment 'AzureCloud'

    Connect-AzAccount -Environment $dxcAzureEnv -TenantId $dxcTenantID -Credential $dxcCred -ServicePrincipal -EA SilentlyContinue -WA SilentlyContinue
    ARMClient spn $dxcTenantID $dxcAppID $dxcAppKey

    if ($error) 
        { 
        Write-Host "`nWARNING:     Unable to connect to Azure. Check your internet connection and verify SPN details." -ForegroundColor Yellow
        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        exit 
        }
    else
        {
        Write-Host "`nINFORMATION: Connected to Azure with SPN authentication." -ForegroundColor Green
        }
   
    if ($dxcSubscriptionID -ne (armclient GET /subscriptions?api-version=2014-04-01 | convertfrom-json).value.subscriptionID)
        {
        Write-Host "WARNING:     The SPN details provided here are valid but doesn't belong to the Subscription ID mentioned. Please verify and run the script again." -ForegroundColor Yellow
        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        exit
        }
    }
# If SPN Details not provided, prompt for ARM Login
Else
    {
    Write-Host "`nINFORMATION: Please login to Azure Resource Manager." -ForegroundColor Green
    Connect-AzAccount
 
    if ($error) 
        { 
        Write-Host "WARNING:     Unable to connect to Azure. Check your internet connection and verify authentication details." -ForegroundColor Yellow
        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        exit 
        $error.Clear()
        }
    Write-Host "INFORMATION: Connected to Azure with provided authentication." -ForegroundColor Green 

    Set-AzContext -Subscription $dxcSubscriptionID


    if ($error) 
        { 
        Write-Host "WARNING:     Invalid Subscription ID. Please make sure you have proper access to this Azure Subscription." -ForegroundColor Yellow 
        Write-Host "             Run the Powershell Command: " -ForegroundColor Yellow -NoNewLine 
        Write-Host "Connect-AzAccount -Subscription $dxcSubscriptionID " -NoNewLine
        Write-Host "and login with your authentication details." -ForegroundColor Yellow
        Write-Host "             If you get error, you have access issues with the subscription." -ForegroundColor Yellow

        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        exit 
        }
    }
    
function ConnectToAzure($tenant, $subname)
{
        write-host "Switching to $subname in $tenant."
        # Now Switch Subscription, and login if required.
        Try {
                $found = $false
                foreach ($cntxt in Get-AzContext -ListAvailable) {
                        if ($cntxt.Tenant.ID -eq $tenant -and $cntxt.Subscription.Name -eq $subName) {
                                $selectedcntxt = Select-AzContext -name $cntxt.name
                                Write-Host "`n $($cntxt.name) selected"
                                $found = $true
                                break
                        }
                }
                if (-not $found) {
                        Connect-AzAccount -Tenant $tenant -SubscriptionName $subName
                        $selectedcntxt = Set-AzContext -Tenant $tenant -SubscriptionName $subName
                }
        } Catch {
                $error.clear()
                Connect-AzAccount -Tenant $tenant -SubscriptionName $subName
                $selectedcntxt = Set-AzContext -Tenant $tenant -SubscriptionName $subName
    }
        return $selectedcntxt
}

#=====================================================================================================================
# MAIN BODY
#=====================================================================================================================
Write-Host "`n##########################################################"
Write-Host "STAGE1: RESOURCE GROUP DEPLOYMENT SECTION"
Write-Host "##########################################################`n"

$dxcobjRG = Get-AzResourceGroup -Name $dxcResourceGroup -ErrorVariable notPresent -EA 0

if (-not ($dxcobjRG))
    {
    $dxcFlgRG = $False
    Write-Host "INFORMATION: Resource Group " -NoNewLine -ForegroundColor Green
    Write-Host $dxcResourceGroup -NoNewLine
    Write-Host " doesn't exist, Deploying.... " -ForegroundColor Green
    $dxcobjRG = New-AzResourceGroup -Name $dxcResourceGroup -Location $dxcWorkspaceRegion -EA 0

    if ($dxcobjRG.count -eq 1)
        {
        Write-Host "INFORMATION: Resource Group deployed successfully." -NoNewLine -ForegroundColor Green
        New-AzResourceLock -LockName LockGroup -LockLevel CanNotDelete -ResourceGroupName $dxcResourceGroup
        Write-Host "INFORMATION: Delete lock applied on Resource Group successfully." -NoNewLine -ForegroundColor Green
        }
    }
else 
    {
    $dxcFlgRG = $True
    Write-Host "INFORMATION: Resource Group " -NoNewLine -ForegroundColor Green
    Write-Host $dxcResourceGroup -NoNewLine
    Write-Host " exist in the subscription, Continuing.... " -ForegroundColor Green
    }


Write-Host "`n##########################################################"
Write-Host "STAGE2: Azure MONITOR SOLUTION DEPLOYMENT SECTION"
Write-Host "##########################################################`n"

$Error.Clear()
$dxcFlgWS = $False

if ($dxcFlgRG )
    {
    $dxcObjExistingWorkspace = Get-AzOperationalInsightsWorkspace -ResourceGroupName $dxcResourceGroup -Name $dxcLogAnalyticsWorkspaceName -ErrorAction SilentlyContinue

    if (-not ($dxcObjExistingWorkspace.count -eq 0))
        {

        If ((Get-AzOperationalInsightsIntelligencePack -ResourceGroupName $dxcResourceGroup -WorkspaceName $dxcLogAnalyticsWorkspaceName).Where({($_.enabled -eq $true)}).count -ge 8)
            {
            $dxcFlgWS = $True
            Write-Host "INFORMATION: OMS Workspace named " -NoNewLine -ForegroundColor Green
            Write-Host $dxcLogAnalyticsWorkspaceName -NoNewLine
            Write-Host " found in " -NoNewLine -ForegroundColor Green
            Write-Host $dxcResourceGroup -NoNewLine
            Write-Host " Resource Group with all the required solutions. " -ForegroundColor Green
            }
        Else
            {
            Write-Host "WARNING:     Azure Monitor Deployment failed. A partial deployment is found in the Resource Group " -NoNewLine -ForegroundColor yellow
            Write-Host $dxcResourceGroup
            Write-Host "             Please cleanup all the AzureMonitor component from the ResourceGroup and then run the script again." -ForegroundColor yellow
            Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
            Exit
            }
        }
    }
if ($dxcFlgWS -eq $False)
    {
    $Error.Clear()
    $dxcObjWorkspace = New-AzResourceGroupDeployment -Name "AzureMonitorDeployment" -ResourceGroupName $dxcResourceGroup -TemplateFile $dxcAzureMonitorSolutionJson `
	 -customerCompanyCode $dxcCustomerCompanyCode -customerSubscriptionID $dxcSubscriptionID -omsWorkspaceRegion $dxcWorkspaceRegion `
     -serviceTier $dxcServiceTier -dataRetention $dxcDataRetention -EA 0
     
    if ($dxcObjWorkspace.count -eq 1) 
        {
        Write-Host "INFORMATION: OMS Workspace named " -NoNewLine -ForegroundColor Green
        Write-Host $dxcLogAnalyticsWorkspaceName -NoNewLine
        Write-Host " deployed in " -NoNewLine -ForegroundColor Green
        Write-Host $dxcResourceGroup -NoNewLine
        Write-Host " Resource Group with all the required solutions. " -ForegroundColor Green
        }
    else
        { 
        Write-Host "WARNING:     Azure Monitor Deployment failed. For detailed error message, please check deployment error in the Resource Group from Azure Portal." -ForegroundColor yellow
        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        Exit
        }
    }

Write-Host "`n##########################################################"
Write-Host "STAGE3: ITSM CONNECTOR DEPLOYMENT SECTION"
Write-Host "##########################################################`n"
$Error.Clear()
if ($dxcFlgWS -and ($dxcobjRG.Tags.itsmc_id.count -eq 1))
    {
    Write-Host "INFORMATION: ResourceGroup alredy contains " -NoNewLine -ForegroundColor Green
    Write-Host "itsmc_id" -NoNewLine
    Write-Host " Tag, skipping ITSM COnnection deployment." -ForegroundColor Green
    }
else
    {
    # Login to ARM Client if SPN parameters not mentioned.
    If (-not($dxcAppID -and $dxcAppKey -and $dxcTenantID))
        {
        Write-Host "`nINFORMATION: Please login to Azure with ARM Client." -ForegroundColor Green 
        armclient login

        if ($error) 
            {    
            Write-Host "WARNING:     Unable to connect to Azure with ARM Client. Check your internet connection and verify authentication details." -ForegroundColor Yellow
            exit 
            $error.Clear()
            }
        Write-Host "INFORMATION: Connected to Azure with provided authentication." -ForegroundColor Green 
        }

    Write-Host "INFORMATION: Creating ITSM Connector named " -NoNewLine -ForegroundColor Green
    Write-Host $dxcITSMconnectionName

    $dxcRequestURL = "https://management.azure.com/subscriptions/" + $dxcSubscriptionID + "/resourcegroups/" + $dxcResourceGroup + "/providers/Microsoft.OperationalInsights/workspaces/" + $dxcLogAnalyticsWorkspaceName + "/connections/" + $dxcITSMconnectionName +"?api-version=2017-04-26-preview"
    $dxcRequestbody = "{ 'properties': { 'Url':'" + $dxcServiceNowURL + "', 'UserName':'" + $dxcServiceNowUser + "', 'Password':'" +  $dxcServiceNowUserPwd + "','ClientId':'" + $dxcServiceNowClientId + "','ClientSecret':'" + $dxcServiceNowClientSecret + "','AuthProvider':'ServiceNow' } }" 
 
    armclient put $dxcRequestURL $dxcRequestbody

    $dxcRequestURL = "https://management.azure.com/subscriptions/" + $dxcSubscriptionID + "/resourcegroups/" + $dxcResourceGroup + "/providers/Microsoft.OperationalInsights/workspaces/" + $dxcLogAnalyticsWorkspaceName + "/datasources/itsmconfiguration_" + $dxcITSMconnectionName +"?api-version=2015-11-01-preview"
    $dxcRequestbody = "{'kind': 'ITSM', 'properties': {'connectionName': '" + $dxcITSMconnectionName + "', 'lastDataSyncDays': '60','allowCreateCI': 'false', 'workItemsToSync': [] } }" 
    [array]$dxcObjITSMC = armclient put $dxcRequestURL $dxcRequestbody

    # Fetch ITSM ConnectionID
    [string]$dxcIDLine = $dxcObjITSMC | Select-String "ConnectionId"
    [String]$dxcITSMConnectionId = ($dxcIDLine.Trim()).Substring(17,36)

    if ($error) 
        {    
        Write-Host "WARNING:     Unable to create ITSM connector. Please verify ServiceNow connection parameters, if the problem persists contact the ServiceNow team." -ForegroundColor Yellow
        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        exit 
        }

    Write-Host "INFORMATION: ITSM Connector created with connection ID " -NoNewLine -ForegroundColor Green
    Write-Host $dxcITSMConnectionId

    # Set the ITSM Connection ID as a Tag for the Maintainance Resource Group
    Write-Host "`nINFORMATION: Setting ITSM Connection ID as a Tag for the Maintainance ResourceGroup " -NoNewLine -ForegroundColor Green
    Write-Host $dxcResourceGroup

    #Get List of existing tags in ResourceGroup
    $ResourceGrouptags = (Get-AzResourceGroup -Name $dxcResourceGroup).Tags
    #Adding itms connction id as a tag to the existing tags
    $ResourceGrouptags += @{itsmc_id=$dxcITSMConnectionId}
    #Setting tags in resource group
    Set-AzResourceGroup -ResourceGroupName $dxcResourceGroup -Tag $ResourceGrouptags
    

    if ($error) 
        {    
        Write-Host "WARNING:     Unable to Tag the ITSM Connection ID on to Maintainance ResourceGroup due to unknown reasons." -ForegroundColor Yellow
        }
    Write-Host "INFORMATION: ITSM Connection ID TAG applied to Maintainance ResourceGroup." -ForegroundColor Green 
    }
  
Write-Host "`n####################### END OF SCRIPT EXECUTION ###################################"
