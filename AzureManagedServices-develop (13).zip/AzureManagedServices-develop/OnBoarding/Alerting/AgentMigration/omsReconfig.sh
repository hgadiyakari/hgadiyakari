#!/bin/bash
# -----------------------------------------------------------------------
# Author:    Santanu Sengupta
# Date:      22nd Nov 2018
# Comments:  Cleanup OMS agent installation.
# -----------------------------------------------------------------------
echo "################################################################" >> /tmp/omsReconfig.log
echo "Cleanup date and Time: `date`" >> /tmp/omsReconfig.log
echo "################################################################" >> /tmp/omsReconfig.log

wget -O onboard_agent.sh https://raw.githubusercontent.com/Microsoft/OMS-Agent-for-Linux/master/installer/scripts/onboard_agent.sh
sudo sh onboard_agent.sh --purge
echo "Purging operation retcode ($?)" >> /tmp/omsReconfig.log

sudo rm -rf /var/opt/microsoft/omsagent/
echo "rm -rf /var/opt/microsoft/omsagent/ retcode ($?)" >> /tmp/omsReconfig.log
sudo rm -rf /etc/opt/microsoft/omsagent/
echo "rm -rf /etc/opt/microsoft/omsagent/ retcode ($?)" >> /tmp/omsReconfig.log
sudo rm -rf /opt/microsoft/omsagent/
echo "rm -rf /opt/microsoft/omsagent/ retcode ($?)" >> /tmp/omsReconfig.log
