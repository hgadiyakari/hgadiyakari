[CmdletBinding(SupportsShouldProcess=$true)]
Param
    (
    [Parameter(Mandatory=$true)]  [String]$dxcSubscriptionID
    )

########### Variable section ###########

$ErrorActionPreference = "SilentlyContinue"
$dxcvmlist = @()
$dxcfileURL =  "https://dxcazuretoolsdev.blob.core.windows.net/installers/omsReconfig.sh"
$dxcScriptFilePath = $PSScriptRoot + "/" + $dxcfileURL.Split('/')[-1]


########### Login Section ###########

Connect-AzAccount
 
if ($error) 
    { 
    Write-Host "WARNING:     Unable to connect to Azure. Check your internet connection and verify authentication details." -ForegroundColor Yellow
    }
Write-Host "INFORMATION: Logged in to Azure with provided authentication." -ForegroundColor Green 

$error.Clear() 
Set-AzContext -Subscription $dxcSubscriptionID

if ($error) 
    { 
    Write-Host "WARNING:     Invalid Subscription ID. Please make sure you have proper access to this Azure Subscription." -ForegroundColor Yellow 
    Write-Host "             Run the Powershell Command: " -ForegroundColor Yellow -NoNewLine 
    Write-Host "Connect-AzAccount -Subscription $dxcSubscriptionID " -NoNewLine
    Write-Host "and login with your authentication details." -ForegroundColor Yellow
    Write-Host "             If you get error, you have access issues with the subscription." -ForegroundColor Yellow

    Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
    exit 
    }
Write-Host "INFORMATION: Connected to Azure Subscription " -NoNewline -ForegroundColor Green
Write-Host $dxcSubscriptionID -NoNewline
Write-Host " with provided authentication." -ForegroundColor Green 


########### Main Body ############

(New-Object System.Net.WebClient).DownloadFile($dxcfileURL, $dxcScriptFilePath)
Write-Host "`nINFORMATION: Collecting the list of all powered on VMs in the subscription. This may take some time...." -ForegroundColor Green
$dxcvmlist += Get-AzVM -status | Where-Object {$_.PowerState -match "running"}
if ($dxcvmlist.Length -eq 0 )
    {
    Write-Host "INFORMATION: No Running VM found in the Azure Subscription " -ForegroundColor Green
    Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
    exit 
    }

$dxcSubscriptionName = (Get-AzSubscription -SubscriptionId $dxcSubscriptionID).Name
$dxcLogFile = "OMS_Cleanup " + $dxcSubscriptionName + " " + (Get-Date -Format "MM-dd-yyyy_hh-mm") + ".log"

Write-Host "VirtualMachine `t Status"
"VirtualMachine `t Status" | Out-File $dxcLogFile -Append

foreach($dxcline in Get-Content .\serverlist.txt)
    {
    $dxcvmMatched = "False"
    $dxcOMSExtensionExists = "False"
    $dxcWindows = "True"
    foreach ($dxcvm in $dxcvmlist)
        {
        if($dxcline -eq $dxcvm.name)
            {
            $dxcvmMatched = "True"
            $dxcOSType = $dxcvm.StorageProfile.OsDisk.OsType
            if ($dxcvm.Extensions)
			    {
                $dxcVMExtension = ($dxcvm.Extensions.ID).Split('/')[-1]	
                				
			    if(( $dxcVMExtension -like "*omsagent*") -or ($dxcVMExtension -like "*MicrosoftMonitoringAgent*"))
				    {
                    $dxcOMSExtensionExists = "True"
                    }
                }
            if (($dxcOMSExtensionExists -eq "False") -and ($dxcOSType -eq "Linux"))
                {
                $dxcWindows = "False"
                $dxcVMName = $dxcvm.name
                $dxcVMRG = $dxcvm.ResourceGroupName
                
                Invoke-AzVMRunCommand -ResourceGroupName $dxcVMRG -Name $dxcVMName -CommandId 'RunShellScript' -ScriptPath $dxcScriptFilePath -AsJob >$null
                }
            }
        }
    if($dxcvmMatched -eq "False")
        {
        Write-Host $dxcline "`t Doesn't exists in the subscription or is in powered off state"
        $dxcline + "`t Doesn't exists in the subscription or it is in powered off state" | Out-File $dxcLogFile -Append
        }
    elseif ($dxcOMSExtensionExists -eq "True") 
        {
        Write-Host $dxcline "`t OMS Extension still exists. Please try after sometime or run the Uninstall script again."
        $dxcline + "`t OMS Extension still exists. Please try after sometime or run the Uninstall script again." | Out-File $dxcLogFile -Append
        }
    elseif ($dxcWindows -eq "True")
        {
        Write-Host $dxcline "`t Windows machine, so Cleanup script not executed."
        $dxcline + "`t Windows machine, so Cleanup script not executed." | Out-File $dxcLogFile -Append
        }
    else
        {
        Write-Host $dxcline "`t Cleanup task executed."
        $dxcline + "`t Cleanup task executed." | Out-File $dxcLogFile -Append
        }
    }
Remove-Item -path $dxcScriptFilePath

Write-Host "`nINFORMATION: Asynchronous Job Execution completed and output log generated in " -NoNewLine -ForegroundColor Green 
Write-Host $dxclogFile  
Write-Host "             Please check the status after 30 minutes." -ForegroundColor Green
Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0