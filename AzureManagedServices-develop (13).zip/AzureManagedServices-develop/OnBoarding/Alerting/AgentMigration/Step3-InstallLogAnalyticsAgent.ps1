[CmdletBinding(SupportsShouldProcess=$true)]
Param
    (
    [Parameter(Mandatory=$true)]  [String]$dxcSubscriptionID,
    [Parameter(Mandatory=$true)]  [String]$dxcLogAnalyticsWorkspaceID,
    [Parameter(Mandatory=$true)]  [String]$dxcLogAnalyticsWorkspaceKey
    )

########### Variable section ###########

$ErrorActionPreference = "SilentlyContinue"
$dxcvmlist = @()
$dxcPublicSettings = @{"workspaceId" = $dxcLogAnalyticsWorkspaceID }
$dxcProtectedSettings = @{"workspaceKey" = $dxcLogAnalyticsWorkspaceKey }

########### Login Section ###########

$error.Clear()
Write-Host "`nINFORMATION: Please login to Azure." -ForegroundColor Green

Connect-AzAccount
 
if ($error) 
    { 
    Write-Host "WARNING:     Unable to connect to Azure. Check your internet connection and verify authentication details." -ForegroundColor Yellow
    }
Write-Host "INFORMATION: Logged in to Azure with provided authentication." -ForegroundColor Green 

$error.Clear()
Set-AzContext -Subscription $dxcSubscriptionID

if ($error) 
    { 
    Write-Host "WARNING:     Invalid Subscription ID. Please make sure you have proper access to this Azure Subscription." -ForegroundColor Yellow 
    Write-Host "             Run the Powershell Command: " -ForegroundColor Yellow -NoNewLine 
    Write-Host "Connect-AzAccount -Subscription $dxcSubscriptionID " -NoNewLine
    Write-Host "and login with your authentication details." -ForegroundColor Yellow
    Write-Host "             If you get error, you have access issues with the subscription." -ForegroundColor Yellow

    Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
    exit 
    }
Write-Host "INFORMATION: Connected to Azure Subscription " -NoNewline -ForegroundColor Green
Write-Host $dxcSubscriptionID -NoNewline
Write-Host " with provided authentication." -ForegroundColor Green 


########### Main Body ############

Write-Host "`nINFORMATION: Collecting the list of all powered on VMs in the subscription. This may take some time...." -ForegroundColor Green
$dxcvmlist += Get-AzVM -status | Where-Object {$_.PowerState -match "running"}
if ($dxcvmlist.Length -eq 0 )
    {
    Write-Host "INFORMATION: No Running VM found in the Azure Subscription " -ForegroundColor Green
    Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
    exit 
    }

$dxcSubscriptionName = (Get-AzSubscription -SubscriptionId $dxcSubscriptionID).Name
$dxcLogFile = "OMS_Installation " + $dxcSubscriptionName + " " + (Get-Date -Format "MM-dd-yyyy_hh-mm") + ".log"

Write-Host "VirtualMachine `t Status"
"VirtualMachine `t Status" | Out-File $dxcLogFile -Append

foreach($dxcline in Get-Content .\serverlist.txt)
    {
    $dxcvmMatched = "False"
    $dxcOMSExtensionExists = "False"
    foreach ($dxcvm in $dxcvmlist)
        {
        if($dxcline -eq $dxcvm.name)
            {
            $dxcvmMatched = "True"
            if ($dxcvm.Extensions)
			    {
                $dxcVMExtension = ($dxcvm.Extensions.ID).Split('/')[-1]	
                				
			    if(( $dxcVMExtension -like "*omsagent*") -or ($dxcVMExtension -like "*MicrosoftMonitoringAgent*"))
				    {
                    $dxcOMSExtensionExists = "True"
                    }
                }
            if ($dxcOMSExtensionExists -eq "False")
                {
                $dxcVMName = $dxcvm.name
                $dxcVMRG = $dxcvm.ResourceGroupName
                $dxcVMLocation = $dxcvm.Location
                $dxcOSType = $dxcvm.StorageProfile.OsDisk.OsType

                if ($dxcOSType -eq "Windows")
                    {
                    Set-AzMExtension -ExtensionName "OMSAgent" -ResourceGroupName $dxcVMRG -VMName $dxcVMName -Location $dxcVMLocation `
                        -Publisher "Microsoft.EnterpriseCloud.Monitoring" -ExtensionType "MicrosoftMonitoringAgent" `
                        -TypeHandlerVersion "1.0" -Settings $dxcPublicSettings -ProtectedSettings $dxcProtectedSettings -AsJob >$null
                    }
                else
                    {
                    Set-AzVMExtension -ExtensionName "OMSAgent" -ResourceGroupName $dxcVMRG -VMName $dxcVMName -Location $dxcVMLocation `
                        -Publisher "Microsoft.EnterpriseCloud.Monitoring" -ExtensionType "OmsAgentForLinux" `
                        -TypeHandlerVersion 1.7 -Settings $dxcPublicSettings -ProtectedSettings $dxcProtectedSettings -AsJob >$null
                    }
                    
                }
            }
        }
    if($dxcvmMatched -eq "False")
        {
        Write-Host $dxcline "`t Doesn't exists in the subscription or is in powered off state"
        $dxcline + "`t Doesn't exists in the subscription or it is in powered off state" | Out-File $dxcLogFile -Append
        }
    elseif ($dxcOMSExtensionExists -eq "True") 
        {
        Write-Host $dxcline "`t OMS Extension already exists."
        $dxcline + "`t OMS Extension already exists" | Out-File $dxcLogFile -Append
        }
    else
        {
        Write-Host $dxcline "`t OMS Extension task executed."
        $dxcline + "`t OMS Extension task executed." | Out-File $dxcLogFile -Append
        }
    }

Write-Host "`nINFORMATION: Asynchronous Job Execution completed and output log generated in " -NoNewLine -ForegroundColor Green 
Write-Host $dxclogFile  
Write-Host "             Please check the status after 30 minutes." -ForegroundColor Green
Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0