# Agent Migration

This folder contains scripts with The primary objective to assist with resolution of incidents related to agent health 
with a temporary fix or workaround; which may also be a final solution

## Jira Epic
https://jira.dxc.com/browse/AZR-10730

## Deployment
For more information on the contents of this directory see:
* https://confluence.dxc.com/pages/viewpage.action?pageId=181707644

## Members of this directory are:
* Step1-UninstallLogAnalyticsAgent.ps1
* Step2-RunCleanupCommands.ps1
* Step3-InstallLogAnalyticsAgent.ps1

## Authors
* Azure Engineering Team
