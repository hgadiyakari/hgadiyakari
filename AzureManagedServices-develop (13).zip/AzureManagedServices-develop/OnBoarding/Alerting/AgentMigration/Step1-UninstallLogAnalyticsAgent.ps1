[CmdletBinding(SupportsShouldProcess=$true)]
Param
    (
    [Parameter(Mandatory=$true)]  [String]$dxcSubscriptionID
    )

########### Environment Checking section ###########

$ModuleURL = "https://dxcazuretoolsdev.blob.core.windows.net/installers/DXCPowershellModules/DXCEnvCheck.psm1"
$LocalModule = $PSScriptRoot + "\DXCEnvCheck.psm1"
(New-Object System.Net.WebClient).DownloadFile($ModuleURL, $LocalModule)
Import-Module $LocalModule -WA 0
Remove-Item -Path $LocalModule

Check-PSVersion -dxcPSVersion 7.0


########### Variable section ###########

$ErrorActionPreference = "SilentlyContinue"
$dxcvmlist = @()

$dxcCleanup = { 
              param ($dxcsbExtName,$dxcsbRGName, $dxcsbVMName)
              Remove-AzVMExtension -ResourceGroupName $dxcsbRGName -Name $dxcsbExtName -VMName $dxcsbVMName -Force
              }


########### Login Section ###########

$error.Clear()
Write-Host "`nINFORMATION: Please login to Azure." -ForegroundColor Green

Connect-AzAccount
Write-Host $error

if ($error) 
    { 
    Write-Host "WARNING:     Unable to connect to Azure. Check your internet connection and verify authentication details." -ForegroundColor Yellow
    Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
    exit 
    }
Write-Host "INFORMATION: Logged in to Azure with provided authentication." -ForegroundColor Green 

Set-AzContext -Subscription $dxcSubscriptionID

if ($error) 
    { 
    Write-Host "WARNING:     Invalid Subscription ID. Please make sure you have proper access to this Azure Subscription." -ForegroundColor Yellow 
    Write-Host "             Run the Powershell Command: " -ForegroundColor Yellow -NoNewLine 
    Write-Host "Connect-AzAccount -Subscription $dxcSubscriptionID " -NoNewLine
    Write-Host "and login with your authentication details." -ForegroundColor Yellow
    Write-Host "             If you get error, you have access issues with the subscription." -ForegroundColor Yellow

    Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
    exit 
    }
Write-Host "INFORMATION: Connected to Azure Subscription " -NoNewline -ForegroundColor Green
Write-Host $dxcSubscriptionID -NoNewline
Write-Host " with provided authentication." -ForegroundColor Green 


########### Main Body ########### 

Write-Host "`nINFORMATION: Collecting the list of all powered on VMs in the subscription. This may take some time...." -ForegroundColor Green
$dxcvmlist += Get-AzVM -status | Where-Object {$_.PowerState -match "running"}
if ($dxcvmlist.Length -eq 0 )
    {
    Write-Host "INFORMATION: No Running VM found in the Azure Subscription " -ForegroundColor Green
    Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
    exit 
    }
$dxcSubscriptionName = (Get-AzSubscription -SubscriptionId $dxcSubscriptionID).Name
$dxclogFile = "OMS_Uninstall " + $dxcSubscriptionName + " " + (Get-Date -Format "MM-dd-yyyy_hh-mm") + ".log"

Write-Host "VirtualMachine `t Status"
"VirtualMachine `t Status" | Out-File $dxclogFile -Append

foreach($dxcline in Get-Content .\serverlist.txt)
    {
    $dxcvmMatched = "False"
    $dxcOMSExtensionExists = "False"
    foreach ($dxcvm in $dxcvmlist)
        {
        if($dxcline -eq $dxcvm.name)
            {
            $dxcvmMatched = "True"
            if($dxcvm.Extensions)
			    {
                $dxcVMExtension = ($dxcvm.Extensions.ID).Split('/')[-1]					
			    if(( $dxcVMExtension -like "*omsagent*") -or ($dxcVMExtension -like "*MicrosoftMonitoringAgent*"))
				    {
                    $dxcOMSExtensionExists = "True"
                    $dxcVMName = $dxcvm.name
                    $dxcVMRG = $dxcvm.ResourceGroupName
             
                    Start-Job -ScriptBlock $dxcCleanup -ArgumentList @($dxcVMExtension,$dxcVMRG, $dxcVMName) > $null
                    }
                }
            }
        }
    if($dxcvmMatched -eq "False")
        {
        Write-Host $dxcline "`t Doesn't exists in the subscription or is in powered off state."
        $dxcline + "`t Doesn't exists in the subscription or it is in powered off state" | Out-File $dxclogFile -Append
        }
    elseif ($dxcOMSExtensionExists -eq "False") 
        {
        Write-Host $dxcline "`t Doesn't have OMS Extension."
        $dxcline + "`t Doesn't have OMS Extension" | Out-File $dxclogFile -Append
        }
    else
        {
        Write-Host $dxcline "`t Cleanup task executed."
        $dxcline + "`t Cleanup task executed." | Out-File $dxclogFile -Append
        }
    }

 Write-Host "`nINFORMATION: Asynchronous Job Execution completed and output log generated in " -NoNewLine -ForegroundColor Green 
 Write-Host $dxclogFile  
 Write-Host "             Please check the status after 30 minutes." -ForegroundColor Green
 Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0