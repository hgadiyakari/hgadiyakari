# Copyright DXC Technology 2020
#
#Scripts creates the following:
# Azure Web App Resource
# Custom webApp alerts 
# ./deployWebAppAlerts.ps1 -Tenant '93f33571-550f-43cf-b09f-cd331338d086' -Subscription '41de9402-bdbf-4272-83b5-c47919900bd6' -ResourceGroupLocation 'eastus'-ResourceGroupName 'dr-rg-ea1' -logAnalyticsResourceGroupName 'dxc-maint-rg' -webAppName 'dr-as-ea1-app1' -logAnalyticsWorkspaceName 'DXC-EA1C-41de-loganalyticsWorkspace' -logAnalyticsLocation 'UK South' -deploymentType 'custom' -customWebAppAlerts '[{"alertName":"DXC-Major-dr-as-ea1-app1-AppConnections","description" :"No.of connections is using by web app.","severity":"2","operator" :"GreaterThan","eventType"  :"Avialability","timeAggregation" : "Maximum","aggregationGranularity" : "5","frequencyOfevaluation" : "5","thresholdValue" : "1","appservicePlan"  : "standard","actionGroupName" :"dxc-ag-major","metricName" : "AppConnections","eventResource" : "Application Service"},{"alertName":"DXC-Major-dr-as-ea1-app1-MemoryWorkingSet","description" :"The current amount of memory used by the app, in megabytes.","severity":"2","operator" :"GreaterThan","eventType"  :"Performace","timeAggregation" : "Maximum","aggregationGranularity" : "5", "frequencyOfevaluation" : "5","thresholdValue" : "1","appservicePlan"  : "standard","actionGroupName" :"dxc-ag-major","metricName" : "MemoryWorkingSet","eventResource" : "Memory"},{"alertName":"DXC-Major-dr-as-ea1-app1-AverageMemoryWorkingSet","description" :"The average amount of memory used by the app, in megabytes.","severity":"2","operator" :"GreaterThan","eventType"  :"Performace","timeAggregation" : "Maximum","aggregationGranularity" : "5","frequencyOfevaluation" : "5","thresholdValue" : "1","appservicePlan"  : "standard","actionGroupName" :"dxc-ag-major","metricName" : "AverageMemoryWorkingSet","eventResource" : "Memory"},{"alertName":"DXC-Major-dr-as-ea1-app1-BytesReceived","description" :"The amount of incoming bandwidth consumed by the app, in MiB.","severity":"2","operator" :"GreaterThan","eventType"  :"Performace","timeAggregation" : "Maximum","aggregationGranularity" : "5","frequencyOfevaluation" : "5", "thresholdValue" : "1","appservicePlan"  : "standard","actionGroupName" :"dxc-ag-major", "metricName" : "BytesReceived","eventResource" : "Incoming Bandwidth"},{"alertName":"DXC-Major-dr-as-ea1-app1-BytesSent","description" :"The amount of incoming bandwidth consumed by the app, in MiB.","severity":"2","operator" :"GreaterThan","eventType"  :"Performace","timeAggregation" : "Maximum","aggregationGranularity" : "5","frequencyOfevaluation" : "5","thresholdValue" : "1","appservicePlan"  : "standard","actionGroupName" :"dxc-ag-major","metricName" : "BytesSent","eventResource" : "Outgoing Bandwidth"},{"alertName":"DXC-Major-dr-as-ea1-app1-CpuTime","description" :"The amount of CPU consumed by the app, in seconds.","severity":"2","operator" :"GreaterThan","eventType"  :"Performance","timeAggregation" : "Maximum","aggregationGranularity" : "5","frequencyOfevaluation" : "5","thresholdValue" : "1","appservicePlan"  : "standard","actionGroupName" :"dxc-ag-major", "metricName" : "CpuTime","eventResource" : "CPU"},{"alertName":"DXC-Major-dr-as-ea1-app1-FileSystemUsage","description" :"Percentage of filesystem quota consumed by the app.","severity":"2","operator" :"GreaterThan","eventType"  :"Capacity","timeAggregation" : "Maximum","aggregationGranularity" : "5", "frequencyOfevaluation" : "5","thresholdValue" : "1","appservicePlan"  : "standard", "actionGroupName" :"dxc-ag-major","metricName" : "FileSystemUsage","eventResource" : "File System"},{"alertName":"DXC-Major-dr-as-ea1-app1-HealthCheckStatus","description" :"Check the status of Web App Service Availability","severity":"2", "operator" :"GreaterThan", "eventType"  :"Health","timeAggregation" : "Maximum","aggregationGranularity" : "5","frequencyOfevaluation" : "5","thresholdValue" : "1","appservicePlan"  : "standard", "actionGroupName" :"dxc-ag-major","metricName" : "HealthCheckStatus","eventResource" : "Web App"},{"alertName":"DXC-Major-dr-as-ea1-app1-HttpResponseTime","description" :"The time taken for the app to serve requests, in seconds.", "severity":"2","operator" :"GreaterThan","eventType"  :"Performace","timeAggregation" : "Maximum","aggregationGranularity" : "5","frequencyOfevaluation" : "5","thresholdValue" : "1", "appservicePlan"  : "standard","actionGroupName" :"dxc-ag-major","metricName" : "HttpResponseTime", "eventResource" : "Web App"},{"alertName":"DXC-Major-dr-as-ea1-app1-Http404", "description" :"Check the availability if web app or any services.", "severity":"2", "operator" :"GreaterThan", "eventType"  :"Availability", "timeAggregation" : "Maximum", "aggregationGranularity" : "5", "frequencyOfevaluation" : "5", "thresholdValue" : "1", "appservicePlan"  : "standard","actionGroupName" :"dxc-ag-major", "metricName" : "Http404", "eventResource" : "Web App"}]'

# Default
# ./deployWebAppAlerts.ps1 -Tenant '93f33571-550f-43cf-b09f-cd331338d086' -Subscription '41de9402-bdbf-4272-83b5-c47919900bd6' -ResourceGroupLocation 'eastus' -ResourceGroupName 'Dinesh-RG' -logAnalyticsResourceGroupName 'DXC-Maint-RG' -webAppName 'dinesh-webapp'  -logAnalyticsWorkspaceName 'DXC-EA1C-41de-loganalyticsWorkspace' -logAnalyticsLocation 'UK South' -deploymentType 'default' -actionGroupName 'DXC-AG-Major'

[CmdletBinding(SupportsShouldProcess=$true)]
Param(	
	[String] [Parameter(Mandatory=$true)]$tenant,
	[String] [Parameter(Mandatory=$true)]$subscriptionId,
	[String] [Parameter(Mandatory=$true)]$ResourceGroupLocation,
	[String] [Parameter(Mandatory=$true)]$ResourceGroupName,
	[String] [Parameter(Mandatory=$true)]$webAppName,
	[String] [Parameter(Mandatory=$true)]$logAnalyticsResourceGroupName,
	[String] [Parameter(Mandatory=$true)]$logAnalyticsWorkspaceName,
	[String] [Parameter(Mandatory=$true)]$logAnalyticsLocation,
	[String] [Parameter(Mandatory=$true)]$deploymentType,
	[String] [Parameter(Mandatory=$false)]$actionGroupName,
	[string] [Parameter(Mandatory=$false)]$customWebAppAlerts
	)

###################################
# Default values are assigned to variables
###################################
 
[String] $customeventProcessingSchema = "3.0"
[string] $alertVersion = "2.4.2"

if (($deploymentType.ToLower() -ne "custom") -and ($deploymentType.ToLower() -ne "default"))
{
	Write-Host "Invaild Deployment Type, It Should be 'custom' or 'default'" 
	exit
}


#Login the Azure resource
Connect-AzAccount -Tenant $tenant -Subscription $subscriptionId


#Validate the azure web app is exists in respective resource group
if ($null -eq (Get-AzResourceGroup -Name $ResourceGroupName -Location $ResourceGroupLocation -Verbose -ErrorAction SilentlyContinue)) 
{
   Write-Host 'Web App is not available'
   exit
} 

#Validate the azure log Analytics is exists in respective resource group
if ($null -eq (Get-AzResourceGroup -Name $logAnalyticsResourceGroupName -Location $logAnalyticsLocation -Verbose -ErrorAction SilentlyContinue)) {
    Write-Host 'Log Analytics workspace is not available'
    exit
}

#To Identify the App Service Plan
$resourceHash = Get-AzWebApp -ResourceGroupName $ResourceGroupName -Name $webAppName
$t = $resourceHash.ServerFarmId.Split("/")
$appservicePlanName = $t[$t.Length -1]

$appresourceplan = Get-AzAppServicePlan -ResourceGroupName $ResourceGroupName -Name $appservicePlanName  
$appservicePlanTier = $appresourceplan.Sku.Tier

$today=Get-Date -Format "ddMMyyyyHHMMss"
$deployname = "deployment" + "-" + $today        

if ($resourceHash.Tags.dxcMonitored -eq 'true') {

	if ($deploymentType.ToLower() -eq "custom")
	{
		#if user did not specify custom webapp definition then do not create alerts
		if ($customWebAppAlerts) 
		{
			Write-Host "Processing Custom webapp alerts"
			$appserviceAlerts = @($customWebAppAlerts) 
			$data = $appserviceAlerts | ConvertFrom-Json
			foreach($i in 0..($data.Count - 1 )){
				$alertName = $data[$i].alertName;
				$description = $data[$i].description
				$severity = $data[$i].severity
				$operator =$data[$i].operator
				$eventType = $data[$i].eventType
				$timeAggregation = $data[$i].timeAggregation
				$aggregationGranularity =$data[$i].aggregationGranularity
				$frequencyOfevaluation =$data[$i].frequencyOfevaluation
				$thresholdValue = $data[$i].thresholdValue
				$appservicePlan = $data[$i].appservicePlan
				$actionGroupName =$data[$i].actionGroupName
				$metricName =$data[$i].metricName
				$eventResource = $data[$i].eventResource
				Write-Host $alertName
				if (($alertName -eq "") -or ($alertName -eq $null))
				{
					Write-Host 'Invalid alertName'
					exit
				}
				if (($metricName -eq "") -or ($metricName -eq $null))
				{
					Write-Host 'Invalid webapp alert Name'
					exit
				}
			
				if ( $appservicePlan.ToLower() -ne $appservicePlanTier.ToLower() ) {
					Write-Host 'App Service plan is invaild, The Current Plan is' $appservicePlanTier
					exit
				}
				$alertTemplateURI = './alerts-custom-webapp.json'
				New-AzResourceGroupDeployment -ResourceGroupName $logAnalyticsResourceGroupName -Name $deployname -TemplateFile $alertTemplateURI `
				-webAppName $webAppName -omsWorkspaceName $logAnalyticsWorkspaceName  -omsWorkspaceLocation $logAnalyticsLocation -eventProcessingSchema $customeventProcessingSchema `
				-alertVersion $alertVersion -alertName $alertName -description $description  -severity $severity `
				-operator $operator  -eventType $eventType -actionGroupName $actionGroupName -timeAggregation $timeAggregation -aggregationGranularity $aggregationGranularity `
				-frequencyOfevaluation $frequencyOfevaluation -thresholdValue $thresholdValue -metricName $metricName -eventResource $eventResource

				$i++
			}
		}
		else 
		{
			Write-Host 'Invalid Custom WebApp Alert'
			exit
		}
		Write-Host "Custom Deployment Process Completed"
	}
	elseif ($deploymentType.ToLower() -eq "default")
	{
		$alertTemplateURI = './alerts-webapp.json'
		if (($actionGroupName -eq "") -or ($actionGroupName -eq $null))
		{	
			Write-Host "Action group is empty"
			exit
		}
		New-AzResourceGroupDeployment  -ResourceGroupName $logAnalyticsResourceGroupName -Name $deployname -TemplateFile $alertTemplateURI `
		-webAppName $webAppName -omsWorkspaceName $logAnalyticsWorkspaceName  -omsWorkspaceLocation $logAnalyticsLocation -actionGroupName $actionGroupName 
	
		Write-Host "Default Deployment Process Completed"
	}
} 
else {
	Write-Host "Alerts are not deployed as dxcMonitored tag is set to false" -ForegroundColor Red
}

