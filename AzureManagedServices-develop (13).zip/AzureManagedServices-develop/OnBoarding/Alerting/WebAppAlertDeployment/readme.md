# Azure App Service alerts deployment

### Template information
- Template for deploying azure app service alerts.
- Template configure to assign alerts to azure app service with default/custom threshold values. 
- Send alerts to Service Now through configured LogAnalytics.
- alerts-custom-webapp.json for custom parameters.
- alerts-webapp.json for default parameters.

### Jira Epic
https://jira.dxc.com/browse/AZR-3655

### Jira Story
https://jira.dxc.com/browse/AZR-7119

### Deployment
For more information on how to deploy an Azure App Service, please see:
Section 3.52 Azure Web App Service of Operations Guide
Section 3.52.3	Monitoring support for Azure Web App Service

### Requirements to deploy template
- Creates alerts for App Service with respective threshold values configuration.
- Alerts are created through custom and default configuration.
- Alerts created can be seen in associated LogAnalytic workspace.
- Custom alerts are generated based on client threshold values.
- Validate the parameters are correctly configured for default and custom configurations.

### Steps to fill in template
- For standard template need to update the default parameter file with required configuration.
- For custom template need to update the custom parameters with required configuration.
- LogAnalytics workspace and resource group are associated with the same resource group.
- Custom alerts are generated to test with minimum alerts configuration to view the alerts in SNOW.

Aproximate time needed for deployment of application gateway is 5min.

### App Service alerts monitoring using LogAnalytics
- Verify all alerts created in Workspace.
- Validate the alerts in SNOW.
