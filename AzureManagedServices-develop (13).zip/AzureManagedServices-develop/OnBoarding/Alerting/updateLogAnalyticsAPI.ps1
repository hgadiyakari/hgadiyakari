<#
=========================================================================================================================
Required -  ArmClient 2.1 (https://github.com/projectkudu/ARMClient)
=========================================================================================================================
AUTHOR:  David Warren 
DATE:    12/05/2019
Version: 1.0
=========================================================================================================================
.SYNOPSIS
    Updates a subscription to switch from legacy Log Analytics Alerts API to scheduledQueryRules API.
.DESCRIPTION
    .PARAMETER  dxcSubscriptionID
		Specifies the Subscription ID of Subscription where the Log Analytics Workspace to be created.
    .PARAMETER  dxcResourceGroup
		Specifies the name of the Resource Group for the Log Analytics Workspace.
    .PARAMETER  dxcLogAnalyticsWorkspace
		Specifies the LogAnalytics Workspace name to update.
    .OPTIONAL PARAMETER  dxcAppID
		Application ID for Authentication with Service Principle Name.
    .OPTIONAL PARAMETER  dxcAppKey
		Application Key for Authentication with Service Principle Name.
    .OPTIONAL PARAMETER  dxcTenantID
		Tenant ID for Authentication with Service Principle Name.
    .SWITCH trace
        (Internal) enable debugging output
#>

[CmdletBinding(SupportsShouldProcess=$true)]
Param
    (
    [Parameter(Mandatory=$true)] [String]$dxcSubscriptionID,
    [Parameter(Mandatory=$true)] [String]$dxcResourceGroup,
    [Parameter(Mandatory=$true)] [String]$dxcLogAnalyticsWorkspace,
    [Parameter(Mandatory=$false)] [String]$dxcAppID,
    [Parameter(Mandatory=$false)] [String]$dxcAppKey,
    [Parameter(Mandatory=$false)] [String]$dxcTenantID,
    [Parameter(Mandatory=$false)] [switch]$trace
    )
#=====================================================================================================================
# CHECK ENVIRONMENT FOR NECESSERY MODULES
#=====================================================================================================================
$ModuleURL = "https://dxcazuretoolsdev.blob.core.windows.net/installers/DXCPowershellModules/DXCEnvCheck.psm1"
$LocalModule = $PSScriptRoot + "\DXCEnvCheck.psm1"
(New-Object System.Net.WebClient).DownloadFile($ModuleURL, $LocalModule)
Import-Module $LocalModule -WA 0
Remove-Item -Path $LocalModule

Check-ArmClientVersion -dxcArmClientVersion 1.2

if ((Get-Module -ListAvailable Az.Accounts) -and (Get-Module -ListAvailable Az.Resources)) 
    { 
    Write-Host "INFORMATION: AZ Modules are installed." -ForegroundColor Green 
    }
else
    {
    Write-Host "WARNING: Powershell AZ Modules are required, please exit and install them." -ForegroundColor Yellow
    Exit
    }

#=====================================================================================================================
# VARIABLE SECTION
#=====================================================================================================================
if ($trace) 
    {
    Write-Host "Trace enabled"
    $ErrorActionPreference = "Continue"
    $WarningPreference = "Continue"
    } 
else
    {
    $ErrorActionPreference = "SilentlyContinue"
    $WarningPreference = "SilentlyContinue"
    }

$dxcLogAnalyticsWorkspaceName = $dxcLogAnalyticsWorkspace

#=====================================================================================================================
# LOGIN SECTION
#=====================================================================================================================
$error.Clear()
# If SPN Details provided, Login with the details.
If ($dxcAppID -and $dxcAppKey -and $dxcTenantID)
    {
    $dxcSecureAppKey = ConvertTo-SecureString $dxcAppKey -AsPlainText -Force
    $dxcCred = New-Object System.Management.Automation.PSCredential ($dxcAppID, $dxcSecureAppKey)
    $dxcAzureEnv = Get-AzEnvironment 'AzureCloud'

    Connect-AzAccount -Environment $dxcAzureEnv -TenantId $dxcTenantID -Credential $dxcCred -ServicePrincipal  >$null
    ARMClient spn $dxcTenantID $dxcAppID $dxcAppKey >$null

    if ($error) 
        { 
        Write-Host "`nWARNING:     Unable to connect to Azure. Check your internet connection and verify SPN details." -ForegroundColor Yellow
        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        exit 
        }
    else
        {
        Write-Host "`nINFORMATION: Connected to Azure with SPN authentication." -ForegroundColor Green
        }
   
    if ($dxcSubscriptionID -ne (armclient GET /subscriptions?api-version=2014-04-01 | convertfrom-json).value.subscriptionID)
        {
        Write-Host "WARNING:     The SPN details provided here are valid but doesn't belong to the Subscription ID mentioned. Please verify and run the script again." -ForegroundColor Yellow
        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        exit
        }
    }
# If SPN Details not provided, prompt for ARM Login
Else
    {
    Write-Host "`nINFORMATION: Please login to Azure Resource Manager." -ForegroundColor Green

    Connect-AzAccount -Subscription $dxcSubscriptionID | Out-Null
    
    if ($error) 
        { 
        Write-Host "WARNING:     Unable to connect to Azure. Check your internet connection and verify authentication details." -ForegroundColor Yellow
        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        exit 
        $error.Clear()
        }
    Write-Host "INFORMATION: Connected to Azure with provided authentication." -ForegroundColor Green 

    Set-AzContext -Subscription $dxcSubscriptionID

    if ($error) 
        { 
        Write-Host "WARNING:     Invalid Subscription ID. Please make sure you have proper access to this Azure Subscription." -ForegroundColor Yellow 
        Write-Host "             Run the Powershell Command: " -ForegroundColor Yellow -NoNewLine 
        Write-Host "Login-AzAccount -Subscription $dxcSubscriptionID " -NoNewLine
        Write-Host "and login with your authentication details." -ForegroundColor Yellow
        Write-Host "             If you get error, you have access issues with the subscription." -ForegroundColor Yellow

        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        exit 
        }
    Write-Host "INFORMATION: Connected to Azure Subscription " -NoNewline -ForegroundColor Green
    Write-Host $dxcSubscriptionID -NoNewline
    Write-Host " with provided authentication." -ForegroundColor Green 
    }

#=====================================================================================================================
# MAIN BODY
#=====================================================================================================================
Write-Host "`n##########################################################"
Write-Host "STAGE1: Check for Resource Group"
Write-Host "##########################################################`n"

$dxcobjRG = Get-AzResourceGroup -Name $dxcResourceGroup -ErrorVariable notPresent -EA 0

if (-not ($dxcobjRG))
    {
    Write-Host "INFORMATION: Resource Group " -NoNewLine -ForegroundColor Green
    Write-Host $dxcResourceGroup -NoNewLine
    Write-Host " doesn't exist " -ForegroundColor Green
    Exit
    }
else 
    { 
    Write-Host "INFORMATION: Resource Group " -NoNewLine -ForegroundColor Green
    Write-Host $dxcResourceGroup -NoNewLine
    Write-Host " exist in the subscription, Continuing.... " -ForegroundColor Green
    }


Write-Host "`n##########################################################"
Write-Host "STAGE2: Check for Azure Monitor"
Write-Host "##########################################################`n"

$Error.Clear()

$dxcObjExistingWorkspace = Get-AzOperationalInsightsWorkspace -ResourceGroupName $dxcResourceGroup -Name $dxcLogAnalyticsWorkspaceName 

if ($dxcObjExistingWorkspace.count -eq 0)
    {
        Write-Host "WARNING:     Azure Monitor Workspace with the following name does not exist " -NoNewLine -ForegroundColor yellow
        Write-Host $dxcLogAnalyticsWorkspaceName
        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        Exit
        
    }
else 
    {
    Write-Host "INFORMATION: Workspace Found, continuing" -ForegroundColor Green
    }


Write-Host "`n##########################################################"
Write-Host "STAGE3: Update Subscription"
Write-Host "##########################################################`n"
$Error.Clear()
# Login to ARM Client if SPN parameters not mentioned.
If (-not($dxcAppID -and $dxcAppKey -and $dxcTenantID))
    {
    Write-Host "`nINFORMATION: Please login to Azure with ARM Client." -ForegroundColor Green 
    armclient login >$null

    if ($error) 
        {    
        Write-Host "WARNING:     Unable to connect to Azure with ARM Client. Check your internet connection and verify authentication details." -ForegroundColor Yellow
        exit 
        $error.Clear()
        }
    Write-Host "INFORMATION: Connected to Azure with provided authentication." -ForegroundColor Green 
    }

$dxcRequestURL = "https://management.azure.com/subscriptions/" + $dxcSubscriptionID + "/resourcegroups/" + $dxcResourceGroup + "/providers/Microsoft.OperationalInsights/workspaces/" + $dxcLogAnalyticsWorkspaceName + "/alertsVersion?api-version=2017-04-26-preview"
$dxcRequestbody = "{'scheduledQueryRulesEnabled': true }" 
 
armclient put $dxcRequestURL $dxcRequestbody >$null

armclient get $dxcRequestURL
    
Write-Host "`n####################### END OF SCRIPT EXECUTION ###################################"
