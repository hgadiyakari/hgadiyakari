<#
=========================================================================================================================
Required - Powershell Version 5.1, AZ Modules
=========================================================================================================================
AUTHOR:  Miroslav Dimitrov
DATE:    27/09/2019
Version: 1.0
=========================================================================================================================
.SYNOPSIS
    Updates existing LogAnalytics workspace with the solutions from the respective deployLogAnalytics.json file via incremental deployment.
.DESCRIPTION
    .PARAMETER  dxcSubscriptionID
		Specifies the Subscription ID of Subscription where the Log Analytics Workspace is located.
    .PARAMETER  dxcResourceGroup
		Specifies the name of the Resource Group of the existing Log Analytics Workspace.
    .PARAMETER  dxcCustomerCompanyCode
		Specifies 4 to 6 digit alphanumeric customer code.
#>

[CmdletBinding(SupportsShouldProcess=$true)]
Param
    (
    [Parameter(Mandatory=$true)] [String]$dxcSubscriptionID,
    [Parameter(Mandatory=$true)] [String]$dxcResourceGroup,
    [Parameter(Mandatory=$true)] [ValidatePattern('^[a-zA-Z0-9]+$')] [String]$dxcCustomerCompanyCode

    )
#========================================================================================================================
# CHECK ENVIRONMENT FOR Powershell Version 7.0 and for AZ modules
#========================================================================================================================
Write-Host "INFORMATION: Checking for Powershell 7.0 and AZ Modules." -ForegroundColor Green
$PSVersion= "7.0"
IF ((($PSVersionTable.psversion.major) + ($psversiontable.PSVersion.Minor)/10) -ge $dxcPSVersion)
        {
        Write-Host "INFORMATION: Powershell $PSVersion or higher found. "  -ForegroundColor Green
        } 
    else 
        {
        Write-Host "WARNING: Powershell $dxcPSVersion or higher is required, please exit and install the latest version." -ForegroundColor Yellow
        Exit
	    }
IF ((Get-Module -ListAvailable Az.Accounts) -and (Get-Module -ListAvailable Az.Resources)) 
{ Write-Host "INFORMATION: AZ Modules are installed." -ForegroundColor Green }
    else
{
        Write-Host "WARNING: Powershell AZ Modules are required, please exit and install them." -ForegroundColor Yellow
        Exit
	    }

#=====================================================================================================================
# VARIABLE SECTION
#=====================================================================================================================
$ErrorActionPreference = "SilentlyContinue"
$dxcLogAnalyticsWorkspaceName = 'DXC-' + $dxcCustomerCompanyCode + '-' + $dxcSubscriptionID.Substring(0,4) + '-loganalyticsWorkspace'
$dxcAzureMonitorSolutionJson = $PSScriptRoot + '\deployLogAnalytics.json'

#=====================================================================================================================
# LOGIN SECTION
#=====================================================================================================================
$error.Clear()

# If SubscriptionID provided, prompt for ARM Login
    if($dxcSubscriptionID)
    {
    Write-Host "`nINFORMATION: Please login to Azure Resource Manager." -ForegroundColor Green
    Connect-AzAccount
 
    if ($error) 
        { 
        Write-Host "WARNING:     Unable to connect to Azure. Check your internet connection and verify authentication details." -ForegroundColor Yellow
        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        exit 
        $error.Clear()
        }
    Write-Host "INFORMATION: Connected to Azure with provided authentication." -ForegroundColor Green 

    Set-AzContext -Subscription $dxcSubscriptionID

    if ($error) 
        { 
        Write-Host "WARNING:     Invalid Subscription ID. Please make sure you have proper access to this Azure Subscription and your Subscription ID is correct. " -ForegroundColor Yellow 
        Write-Host "             Run the Powershell Command: " -ForegroundColor Yellow -NoNewLine 
        Write-Host "Connect-AzAccount -Subscription $dxcSubscriptionID " -NoNewLine
        Write-Host "and login with your authentication details." -ForegroundColor Yellow
        Write-Host "             If you get error, you have access issues with the subscription." -ForegroundColor Yellow

        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        exit 
        }
    Write-Host "INFORMATION: Connected to Azure Subscription " -NoNewline -ForegroundColor Green
    Write-Host $dxcSubscriptionID -NoNewline
    Write-Host " with provided authentication." -ForegroundColor Green 
    }

#=====================================================================================================================
# MAIN BODY
#=====================================================================================================================
Write-Host "`n##########################################################"
Write-Host "STAGE1: RESOURCE GROUP CHECK SECTION"
Write-Host "##########################################################`n"

$dxcobjRG = Get-AzResourceGroup -Name $dxcResourceGroup -ErrorVariable notPresent -EA 0

if ($dxcobjRG)
    {
    $dxcFlgRG = "True"
    Write-Host "INFORMATION: Resource Group " -NoNewLine -ForegroundColor Green
    Write-Host $dxcResourceGroup -NoNewLine
    Write-Host " exist in the subscription, Continuing.... " -ForegroundColor Green

    }
else 
    {
    $dxcFlgRG = "False"
    Write-Host "Warning: Resource Group " -NoNewLine -ForegroundColor Yellow
    Write-Host $dxcResourceGroup -NoNewLine -ForegroundColor Yellow
    Write-Host " doesn't exist in your subscription. Please provide a valid RG name and run the script again. " -ForegroundColor Yellow
    Exit
    }
#=====================================================================================================================
Write-Host "`n##########################################################"
Write-Host "STAGE2: EXISTING WORKSPACE CHECK AND UPGRADE SECTION"
Write-Host "##########################################################`n"


$Error.Clear()
$dxcObjExistingWorkspace = Get-AzOperationalInsightsWorkspace -ResourceGroupName $dxcResourceGroup -Name $dxcLogAnalyticsWorkspaceName -ErrorAction SilentlyContinue
$dxcWorkspaceRegion = $dxcObjExistingWorkspace.Location
$dxcServiceTier = $dxcObjExistingWorkspace.Sku
$dxcDataRetention = $dxcObjExistingWorkspace.retentionInDays
$dxcResourceId = $dxcObjExistingWorkspace.ResourceID
$existingTags = $dxcObjExistingWorkspace.Tags
$existingTags.Remove('dxcManaged') > $null
$existingTags.Remove('dxcConfigurationCheck') > $null
$existingTags.Remove('dxcMonitored') > $null

    if ($dxcObjExistingWorkspace.count -eq $false)
        { 
        Write-Host "Warning: There is no such existing LogAnalytics Workspace in Resource Group $dxcResourceGroup. Please provide a valid dxcCustomerCompanyCode name and try again. " -ForegroundColor Yellow
        Exit
        }
    if ($dxcObjExistingWorkspace.count -eq $true)
        { 
        Write-Host "INFORMATION: Existing Workspace named $dxcLogAnalyticsWorkspaceName found in provided Resource Group $dxcResourceGroup. " -ForegroundColor Green
    
        # Powershell dxcObjExistingWorkspace.Sku returns the Pricing Tier values of the workspace with all small letters like standalone, pergb2018, pernode. 
        # The deployLogAnalytics.json expects the values with upper cases like Standalone, PerGB2018, PerNode. So we are converting the the pricing tier strings to the desired
        # format with ToUpper functions.
        if ($dxcServiceTier -like 'standalone')
        {
        $convertedstandalone = $dxcServiceTier.Substring(0,1).ToUpper() + $dxcServiceTier.Substring(1,9)
        Write-Host "INFORMATION: Upgrading this workspace with the required solutions using existing $convertedstandalone pricing tier and existing data retention of $dxcDataRetention days. " -ForegroundColor Green
        New-AzResourceGroupDeployment -Name "AzureMonitorUpgrade" -ResourceGroupName $dxcResourceGroup -TemplateFile $dxcAzureMonitorSolutionJson -customerCompanyCode $dxcCustomerCompanyCode -customerSubscriptionID $dxcSubscriptionID -omsWorkspaceRegion $dxcWorkspaceRegion ` -serviceTier $convertedstandalone -EA 0
        }
        if ($dxcServiceTier -like 'pergb2018')
        {
        $convertedpergb = $dxcServiceTier.Substring(0,1).ToUpper() + $dxcServiceTier.Substring(1,2) + $dxcServiceTier.Substring(3,6).ToUpper()
        Write-Host "INFORMATION: Upgrading this workspace with the required solutions using existing $convertedpergb pricing tier and existing data retention of $dxcDataRetention days. " -ForegroundColor Green
        New-AzResourceGroupDeployment -Name "AzureMonitorUpgrade" -ResourceGroupName $dxcResourceGroup -TemplateFile $dxcAzureMonitorSolutionJson -customerCompanyCode $dxcCustomerCompanyCode -customerSubscriptionID $dxcSubscriptionID -omsWorkspaceRegion $dxcWorkspaceRegion ` -serviceTier $convertedpergb -dataRetention $dxcDataRetention -EA 0
        }
        if ($dxcServiceTier -like 'pernode')
        {
        $convertedpernode = $dxcServiceTier.Substring(0,1).ToUpper() + $dxcServiceTier.Substring(1,2) + $dxcServiceTier.Substring(3,1).ToUpper() + $dxcServiceTier.Substring(4)
        Write-Host "INFORMATION: Upgrading this workspace with the required solutions using existing $convertedpernode pricing tier and existing data retention of $dxcDataRetention days. " -ForegroundColor Green
        New-AzResourceGroupDeployment -Name "AzureMonitorUpgrade" -ResourceGroupName $dxcResourceGroup -TemplateFile $dxcAzureMonitorSolutionJson -customerCompanyCode $dxcCustomerCompanyCode -customerSubscriptionID $dxcSubscriptionID -omsWorkspaceRegion $dxcWorkspaceRegion ` -serviceTier $convertedpernode -dataRetention $dxcDataRetention -EA 0
        }
        if ($dxcServiceTier -like 'free')
        {
        Write-Host "WARNING: Your workspace has not supported $dxcServiceTier pricing tier and cannot be upgraded now. Please consider changing the pricing tier to a supported one and try again. " -ForegroundColor Yellow
        Exit
        }
        if (-not ($Error))
        {
          Update-AzTag -ResourceId $dxcResourceId -Tag $existingTags -Operation Merge
          Write-Host "INIFORMATION: Workspace named $dxcLogAnalyticsWorkspaceName found in ResourceGroup $dxcResourceGroup upgraded with all the required solutions. " -ForegroundColor Green
        }
        else
        { 

          Write-Host "WARNING:     Azure Monitor Upgrade failed. Please verify your provided values and check for a deployment error in the Resource Group from Azure Portal. " -NoNewLine -ForegroundColor Yellow
          Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
          Exit
        }}
  
 Write-Host "`n####################### END OF SCRIPT EXECUTION ###################################"
