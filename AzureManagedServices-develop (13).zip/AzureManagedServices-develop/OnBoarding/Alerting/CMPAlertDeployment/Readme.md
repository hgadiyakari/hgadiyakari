# CMP Cloud Events and Alert Deployment

This folder contains the json and powershell files that are used to deploy CMP Cloud Events function app and alerts

## Jira Epic
https://jira.dxc.com/browse/AZR-19496

## Deployment
For more information on how to deploy alerts see:
* https://confluence.dxc.com/pages/viewpage.action?pageId=222559265


## To execute:

.\deployCMPAlertFunctions.ps1 -SubscriptionId 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx' -TenantId "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" -LogAnalyticsWorkspaceName 'MY-loganalyticsWorkspace' -ServiceNowURL ```"http://MyCompany.servicenow.com"``` -ServiceNowUser 'user1' -ServiceNowUserPwd 'pwd1' -UpgradeFunctionCodes 'Auto' -UpgradeEnvVariables 'Auto' -SpKey "w0jsljefsoinv0w8nsoihdv48483ek=" -ClientID "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" -dxcManaged 'true' -dxcMonitored 'true'


| Parameter Name            | Type   | Required | Usage                                                                                                            |
| ------------------------- | ------ | -------- | ---------------------------------------------------------------------------------------------------------------- |
| SubscriptionId            | String | True     | Azue subscription in the form of: 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'                                         |
| TenantId                  | String | True     | Tenant Id in the form of: 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'                                                 |
| LogAnalyticsWorkspaceName | String | True     | The name of the log analytics workspace, can be found under DXC-Maint-RG                                         |
| ServiceNowURL             | String | True     | The ServiceNow URL.  May be in the format of: https://xxxx.service-now.com                                       |
| ServiceNowUser            | String | True     | Userid used to connect to above ServiceNow instance                                                              |
| ServiceNowUserPwd         | String | True     | Password for above ServiceNow userid                                                                             |
| UpgradeFunctionCodes      | String | True     | Will update the FunctionApp CPW Function code.                                                                   |
| UpgradeEnvVariables       | String | True     | Will update the Environmental Variables (i.e ServiceNow URL, User, password) specified in the deployment script. |
| SpKey                     | String | False    | Service Principal Key (also known as clientKey)                                                                  |
| ClientID                  | String | False    | Service Principal ID                                                                                             |
| dxcManaged                | String | False    | Sets resource to DXC managed.  Default is false                                                                  |
| dxcMonitored              | String | False    | Sets resource to DXC monitored.  Default is false                                                                |



## Members of this directory are:
* deployCMPAlertFunctions.ps1				- m     ain deployment script for heartbeat alerts
* Functions									- subdirecory containing function app code which is zipped and deployed by the script
* Readme.md                                 - this file.

## Authors
* Bang Bui 2020
* Brian Bradley 2021
* Kevin Bilderback 2021
