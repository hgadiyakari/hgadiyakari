using namespace System.Net

# Input bindings are passed in via param block.
param($Request, $TriggerMetadata)

#VARIABLE SECTION
$dxcSnowUser = $env:ServiceNowUser
$dxcSnowPassword = $env:ServiceNowPassword
$dxcSnowAPIUri = $env:ServiceNowUrl + "api/now/cloud_event"
$ErrorActionPreference = "SilentlyContinue"


$dxcCredPair = "$($dxcSnowUser):$($dxcSnowPassword)"
$dxcEncodedCred = [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes($dxcCredPair))
$dxcHeaders = 
    @{
    'Authorization' = "Basic $($dxcEncodedCred)"
    'Content-Type' = "application/json"
    'Accept' = "application/json"
    'user-agent' = 'IcMBroadcaster'  # Required for Cloud Event processing
    }

## Common Schema
$alert = ConvertTo-Json $Request.Body -Depth 10
#$resourceLocation = $Request.Body.data.alertContext.SearchResults.dataSources.region

#Write-Host "Row Count" ($Request.Body.data.alertContext.SearchResults.tables[0].rows).Count
#Write-Host "Here is the row output\n%%%%%%%%%%%%%%%%%%%%%%"
#Write-Host $Request.Body.data.alertContext.SearchResults.tables[0].rows
#Write-Host "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n\n"

$constantResourceId = $Request.Body.data.alertContext.SearchResults.tables[0].rows[1]
$constantOperationName = $Request.Body.data.alertContext.SearchResults.tables[0].rows[4]
$cntr = 0

Foreach ($row in $Request.Body.data.alertContext.SearchResults.tables[0].rows) {
    $eventTime = $row[0]
    $dxcresourceId = $row[1]
    $dxcSubscriptionId = $row[2]
    $dxcResourceGroup = $row[3]
    $operationName =  $row[4]
    $status =  $row[5]
    $resourceName = $row[6]
	$resourceFetch = get-AZResource -resourceID $dxcresourceId
	$resourceLocation = $resourceFetch.Location

    if (($cntr -gt 0) -And ($constantResourceId -eq $dxcresourceId) -And ($constantOperationName -eq $operationName))  {
        #Write-Host "Skipped.........."
        Continue
    }   
    # Previous Method of retrieving the Resource Type
    #$null, $null, $subId, $null, $dxcRG, $null, $dxcProvider, $dxcType, $Resource  = $dxcResourceId.Split('/')
    #$dxcResourceType = "$dxcProvider/$dxcType"

    $dxcResourceType = $operationName -replace '/write' -replace '/delete' -replace '/update' -replace '/create' -replace '/deallocate/action' -replace '/start/action' -replace '/restart/action'
    
    $jsonBase = @{}
    $dataArray = @{}
    $contextarray = @{}
    $activitylogArray = @{
        "resourceId" = $dxcresourceId
        "resourceGroupName" = $dxcResourceGroup
        "resourceLocation" = $resourceLocation
        "operationName" = $operationName
        "status" = $status
        "resourceType" = $dxcResourceType
        "eventTimestamp" = $eventTime
        "subscriptionId" = $dxcSubscriptionId
        "resourceName" = $resourceName
    }
    $contextarray.Add("activityLog",$activitylogArray)
    $dataArray.Add("context",$contextarray)
    $jsonBase.Add("data",$dataArray)

    if ($dxcResourceType -eq 'Microsoft.Web/sites' -And $operationName -ne 'Microsoft.Web/sites/delete') {
        Set-AzContext $dxcSubscriptionId
        $webAppType = (Get-AzwebApp -ResourceGroupName $dxcResourceGroup -Name $resourceName).kind
        $jsonBase.data.Context.activityLog += @{webAppType = $webAppType}
        Write-Host "Is a web app"
        }

    $printjson = $jsonBase | ConvertTo-Json -Depth 10
    Invoke-Webrequest -Uri $dxcSnowAPIUri -Header $dxcHeaders -Method POST -Body $printjson

    Write-Host "### Start Variables ###"
    Write-Host $dxcresourceId
    Write-Host $operationName
    Write-Host $status
    Write-Host $eventTime
    Write-Host $dxcResourceGroup
    Write-Host $resourceName
    Write-Host $dxcResourceType
    Write-Host $dxcSubscriptionId
    Write-Host $resourceLocation
    Write-Host $webAppType
    Write-Host $printjson
    Write-Host $alert
    Write-Host "### end Variables ###"
    $cntr++
}
