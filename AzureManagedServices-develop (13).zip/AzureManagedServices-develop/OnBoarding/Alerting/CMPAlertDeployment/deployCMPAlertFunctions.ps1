#=====================================================================================================================
# DOCUMENTATION LINK
# Function App to process Azure Status change logs and submit CMP Cloud Event alerts to ServiceNow for ServiceNow to update CMDB.
# This replaces the CMDB Updates alerts, which needs to be manually coded for each new RESOURCE
#=====================================================================================================================

[CmdletBinding(SupportsShouldProcess = $true)]
Param
(
    [Parameter(Mandatory = $true)] [String]$SubscriptionId,
    [Parameter(Mandatory = $true)] [String]$TenantId,
    [Parameter(Mandatory = $true)] [String]$LogAnalyticsWorkspaceName,
    [Parameter(Mandatory = $true)] [String]$ServiceNowURL,
    [Parameter(Mandatory = $true)] [String]$ServiceNowUser,
    [Parameter(Mandatory = $true)] [String]$ServiceNowUserPwd,
    [Parameter(Mandatory = $true)] [ValidateSet("Auto", "Yes")] [String]$UpgradeFunctionCodes,
    [Parameter(Mandatory = $true)] [ValidateSet("Auto", "Yes")] [String]$UpgradeEnvVariables,
    [Parameter(Mandatory = $false)] [String]$SpKey,
    [Parameter(Mandatory = $false)] [String]$ClientID,
    # Below parameters are used for debug and testing
    [Parameter(Mandatory = $false)] [String]$dxcFunctionAppRGName = "dxc-automation-rg",
    [Parameter(Mandatory = $false)] [String]$dxcActionGroupShortName = "dxcCMPIn",
    [Parameter(Mandatory = $false)] [String]$dxcActionGroup = "DXC-AG-CMP-Informational",
    [Parameter(Mandatory = $false)] [ValidateSet("unique", "random")][String]$uniqueType = "unique"
)

#Per discussions, dxcManaged and dxcMonitored are always set to true for this resource since it's ours.
$dxcManaged = "true"
$dxcMonitored = "true"

#=====================================================================================================================
# CHECK ENVIRONMENT FOR NECESSERY MODULES
#=====================================================================================================================
$dxcModuleList = "DXCEnvCheckV2.psm1", "DXCUtilityFunctions.psm1", "DXCDeploymentFunctions.psm1"
foreach ($dxcModule in $dxcModuleList) {
    [String]$dxcModuleURL = "https://dxcazuretools.blob.core.windows.net/installers/DXCPowershellModules/" + $dxcModule
    [String]$dxcLocalModule = Join-Path -Path $PSScriptRoot -ChildPath $dxcModule
    (New-Object System.Net.WebClient).DownloadFile($dxcModuleURL, $dxcLocalModule)
    Import-Module $dxcLocalModule -WA 0
    Remove-Item -Path $dxcLocalModule
}

$dxcPSCore = Check-PSCore -Version 7.0.0
if ($dxcPSCore) { $dxcAZ = Check-AzModule -Version 2.5.0 }
if ($dxcAZ) { $dxcAZCli = Check-AzureCLI -Version 2.1.0 }
if ($dxcAZCli) { $dxcAZStorage = Check-PSModule -Name "Az.Storage" -Version 1.5.1 }
if ($dxcAZStorage) { $dxcAZMonitor = Check-PSModule -Name "Az.Monitor" -Version 1.5.0 }
if ($dxcAZMonitor) { $dxcAZFunctions = Check-PSModule -Name "Az.Functions" -Version 1.0.0 }
if ($dxcAZFunctions) { $dxcAZApplicationInsights = Check-PSModule -Name "Az.ApplicationInsights" -Version 1.0.1 }

if (!$dxcAZApplicationInsights) {
    Read-Host "`nPress 'ENTER'to exit the script........"
    exit
}
$dxcAzInsights = Get-Module -Name Az.Insights -ListAvailable
if ($dxcAzInsights) {
    Write-Host "Az.Insights modules exists, please uninstall before proceeding further"
    Read-Host "`nPress 'ENTER'to exit the script........"
    exit
}

#=====================================================================================================================
# LOGIN SECTION
#=====================================================================================================================
$error.Clear()

if ($SpKey) {
    Utility-LoginAZSpn -TenantId $TenantId -SpnKey $SpKey -ClientId $ClientID -SubscriptionId $SubscriptionId
    Utility-LoginAzureCliSpn -TenantId $TenantId -SpnKey $SpKey -ClientId $ClientID -SubscriptionId $SubscriptionId
}
else {
    Utility-LoginAZTenant -TenantId $TenantId -SubscriptionId $SubscriptionId
    Utility-LoginAureCliTenant -TenantId $TenantId -SubscriptionId $SubscriptionId
}

#=====================================================================================================================
# VARIABLE SECTION
#=====================================================================================================================
$ErrorActionPreference = "SilentlyContinue"
$WarningPreference = "SilentlyContinue"
[String]$dxcAlertVersion = "2.9"
[String]$dxcTeamsNotificationURL = "https://outlook.office.com/webhook/9de3af8e-7f6c-487d-9204-05ce8ad65a41@93f33571-550f-43cf-b09f-cd331338d086/IncomingWebhook/c8fa16b940dc40ff9fe758965011e414/200a8b3f-b6fb-45d7-b113-45ca0356bb83%22"
if ($uniqueType -eq "unique") {
    [String]$dxcRandom = Utility-GeneratingUniqueID -dxcResourceGroupName $dxcFunctionAppRGName
}
else {
    [String]$dxcRandom = ( -join ((0x30..0x39) + ( 0x41..0x5A) + ( 0x61..0x7A) | Get-Random -Count 13 | ForEach-Object { [char]$_ })).toLower()
}
[String]$dxcStorageAccountName = 'dxccmp' + $dxcRandom + 'stg'
[String]$dxcAppInsightName = 'dxc-FuncApp-' + $dxcRandom + '-AI'
[String]$dxcFunctionAppName = 'dxc-CMPCloudEvent-' + $dxcRandom + '-FA'
[String]$dxcAppServicePlan = 'dxc-CMPCo-' + $dxcRandom + '-ASP'
[String]$dxcCELogAlertJSON = Join-Path -Path $PSScriptRoot -ChildPath '\alerts-cmp-status-change.json'
[String]$dxcCEAlertRuleName = 'dxc-informational-cmp-change'
[String]$dxcZippedFunctionPath = Join-Path -Path $PSScriptRoot -ChildPath "$dxcFunctionAppName.zip"
[String]$dxcFunctionAppIdentityScope = '/subscriptions/' + $SubscriptionId
if (-not( $ServiceNowURL.substring($ServiceNowURL.length - 1) -eq "/")) { $ServiceNowURL = $ServiceNowURL + "/" }

#========================================================================================================================
# MAIN BODY OF THE SCRIPT
#========================================================================================================================
# Collect Maintenance ResourceGroup and OMS Workspace Details.
$dxcObjWorkspace = Get-AzOperationalInsightsWorkspace | ? { $_.Name -Match $LogAnalyticsWorkspaceName }
If ($dxcObjWorkspace) {
    [String]$LogAnalyticsWorkspaceName = $dxcObjWorkspace.Name
    [String]$dxcResourceGroup = $dxcObjWorkspace.ResourceGroupName
    [String]$dxcWorkspaceRegion = (($dxcObjWorkspace.location).ToLower()) -replace '\s', ''
    [String]$dxcWorkspaceResourceId = $dxcObjWorkspace.ResourceId

    Utility-DisplayInfo -dxcstr1 "INFORMATION: Loganalytics Workspace named" -dxcstr2 $LogAnalyticsWorkspaceName -dxcstr3 "located under ResourceGroup" -dxcstr4 $dxcResourceGroup
}
else {
    Write-Host "WARNING:     Loganalytics Workspace not found. Please enter correct workspace name while running the script." -ForegroundColor Yellow
    Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
    Read-Host "`nPress 'ENTER'to exit the script........"
    exit
}

Write-Host "`n##########################################################"
Write-Host "STAGE1: RESOURCE GROUP DEPLOYMENT SECTION"
Write-Host "############################################################"

$dxcRGExtsts, $dxcobjRG = Deploy-ResourceGroup -Name $dxcFunctionAppRGName -Location $dxcWorkspaceRegion

if (!$dxcobjRG) {
    Write-host $error
    Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
    Read-Host "`nPress 'ENTER'to exit the script........"
    exit
}

if (!$dxcRGExtsts) { 
    $error.Clear()
    New-AzResourceLock -ResourceGroupName $dxcFunctionAppRGName -LockName "DXC-Automation-RG-Lock" -LockNotes "Cannot Delete Lock applied on this Resource Group to avoid accidental deletion of all resources from automation resource group" -LockLevel "CanNotDelete" -Force >$null

    if ($error) {
        Write-Host $error
        Utility-DisplayWarning -dxcstr1 "WARNING:     Unable to lock the ResourceGroup" -dxcstr2 $dxcFunctionAppRGName -dxcstr " . You need to Manually Lock it against deletion, post deployment." 
    }
    Else { 
        Utility-DisplayInfo -dxcstr1 "INFORMATION: Deletion Lock applied to the ResourceGroup" -dxcstr2 $dxcFunctionAppRGName 
    }
}

Write-Host "`n##########################################################"
Write-Host "STAGE2: STORAGE ACCOUNT DEPLOYMENT SECTION"
Write-Host "############################################################"

$error.Clear()
$dxcStorageExists, $dxcObjStorage = Deploy-StorageAccount -Location $dxcWorkspaceRegion -ResourceGroupName $dxcFunctionAppRGName -Name $dxcStorageAccountName -Container "None" -Table "None" -Queue "None" -Blobfiles "None"

if (!$dxcObjStorage) {
    Write-Host $error
    Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
    Read-Host "`nPress 'ENTER'to exit the script........"
    exit
}


Write-Host "`n##########################################################"
Write-Host "STAGE3: FUNCTIONAPP DEPLOYMENT AND CONFIGURATION SECTION"
Write-Host "############################################################"

$dxcObjFunctionApp = Get-AzResource -Name $dxcFunctionAppName -ResourceGroupName $dxcFunctionAppRGName -ResourceType "Microsoft.Web/sites" -EA 0

if ($dxcObjFunctionApp) { 
    $dxcFunctionAppResourceId = $dxcObjFunctionApp.ResourceId
    $function_extension_version = az functionapp config appsettings list --name $dxcFunctionAppName --resource-group $dxcFunctionAppRGName --query "[?name=='FUNCTIONS_EXTENSION_VERSION'].value" | ConvertFrom-Json
    if ($function_extension_version -ne "~3") {
        Utility-DisplayInfo -dxcstr1 "INFORMATION: FunctionApp named" -dxcstr2 $dxcFunctionAppName -dxcstr3 "being updated to powershell 7"
        az functionapp config appsettings set --name $dxcFunctionAppName --resource-group $dxcFunctionAppRGName --settings FUNCTIONS_EXTENSION_VERSION="~3" 
        Set-AzResource -ResourceId "/subscriptions/$SubscriptionId/resourceGroups/$dxcFunctionAppRGName/providers/Microsoft.Web/sites/$dxcFunctionAppName/config/web" -UsePatchSemantics -Properties @{ powerShellVersion = '~7' } -Force
    }
    else {
        Utility-DisplayInfo -dxcstr1 "INFORMATION: FunctionApp already has FUNCTIONS_EXTENSION_VERSION = ~3"
    }        
    Utility-DisplayInfo -dxcstr1 "INFORMATION: FunctionApp named" -dxcstr2 $dxcFunctionAppName -dxcstr3 "already present. Skipping Stage3 and Stage4." 
    $dxcFunctionAppExists = $True
}
else {
    #Verify and deploy AppServicePlan
    $error.Clear()
    $dxcObjAppServicePlan = deploy-ConsumptionAppServicePlan -AppServicePlanName $dxcAppServicePlan -ResourceGroupName $dxcFunctionAppRGName -Location $dxcWorkspaceRegion

    if (!$dxcObjAppServicePlan) { 
        Write-Host $error
        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        Read-Host "`nPress 'ENTER'to exit the script........"
        exit
    }

    #Verify and deploy Application Insights
    $error.Clear()
    $dxcObjAI = deploy-AppInsights -AppInsightsName $dxcAppInsightName -ResourceGroupName $dxcFunctionAppRGName -Location $dxcWorkspaceRegion
    if (!$dxcObjAI) { 
        Write-Host $error
        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        Read-Host "`nPress 'ENTER'to exit the script........"
        exit
    }

    #Deploy FunctionApp
    $error.Clear()
    $dxcFunctionAppResourceId = deploy-FunctionAppOnConsumptionPlan -FunctionAppName $dxcFunctionAppName -ResourceGroupName $dxcFunctionAppRGName -Location $dxcWorkspaceRegion -AppInsightsName $dxcAppInsightName -ConsumptionPlanName $dxcAppServicePlan -StorageAccountName $dxcStorageAccountName
    az functionapp config appsettings set --name $dxcFunctionAppName --resource-group $dxcFunctionAppRGName --settings "ApplicationInsightsAgent_EXTENSION_VERSION=enabled" FUNCTIONS_EXTENSION_VERSION="~3" 
    Set-AzResource -ResourceId "/subscriptions/$SubscriptionId/resourceGroups/$dxcFunctionAppRGName/providers/Microsoft.Web/sites/$dxcFunctionAppName/config/web" -UsePatchSemantics -Properties @{ powerShellVersion = '~7' } -Force
    if (!$dxcFunctionAppResourceId) { 
        Write-Host $error
        Write-Host -dxcstr1 "WARNING    : Failed to create FunctionApp. Script will exit now." 
        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        Read-Host "`nPress 'ENTER'to exit the script........"
        exit
    }
    
    Write-Host "`n######################################################################"
    Write-Host "STAGE4: FUNCTIONAPP IDENTITY, SECURITY AND ENVIRONMENT SETTINGS SECTION"
    Write-Host "########################################################################"

    $error.Clear()
    $dxcOutput = az functionapp identity assign -g $dxcFunctionAppRGName -n $dxcFunctionAppName --role reader --scope $dxcFunctionAppIdentityScope
    if ($dxcOutput) { $dxcOutput = az functionapp identity assign -g $dxcFunctionAppRGName -n $dxcFunctionAppName --role "Log Analytics Contributor" --scope $dxcWorkspaceResourceId }

    if (!$dxcOutput) { 
        Write-Host $error
        Write-Host "WARNING:     Unable to provide necessery access to FunctionApp. You may not have 'Owner' rights to the subscription." -ForegroundColor Yellow
        Write-Host "WARNING:     The script will continue to deploy but for proper functioning, some one with owner rights have to assign it the necessery permissions." -ForegroundColor Yellow
        Write-Host "WARNING:     Please follow the direction in its wiki link to assign permission to this functionapp after deployment." -ForegroundColor Yellow
    }
    else { 
        Utility-DisplayInfo -dxcstr1 "INFORMATION: FunctionApp" -dxcstr2 $dxcFunctionAppName -dxcstr3 "has been provided 'Reader' access to the Subscription and 'Log Analytics Contributor' access to the LogAnalytics Workspace." 
    }
}

#Set Environtment Variables for the FunctionApp
if (!$dxcFunctionAppExists -or ($UpgradeEnvVariables -eq "Yes" )) {
    $error.Clear()
    Write-Host "`nINFORMATION: Settting up environment variable for the powershell function...." -ForegroundColor Green
    $dxcOutput = az functionapp config appsettings set --name $dxcFunctionAppName --resource-group $dxcFunctionAppRGName `
        --settings "ServiceNowUrl=$ServiceNowURL" "ServiceNowUser=$ServiceNowUser" "ServiceNowPassword=$ServiceNowUserPwd" "AlertMode=log alert" "TeamsNotificationURL=$dxcTeamsNotificationURL" "LogAnalyticsWorkspaceName=$LogAnalyticsWorkspaceName" "LogAnalyticsWorkspaceResourceGroup=$dxcResourceGroup" | ConvertFrom-Json

    if (!$dxcOutput) { 
        Write-Host "WARNING:     Unable to set environment variables to FunctionApp. Script will exit now." -ForegroundColor Yellow
        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        Read-Host "`nPress 'ENTER'to exit the script........"
        exit
    }
    Write-Host "INFORMATION: Environment variable setup completed successfully." -ForegroundColor Green
}
else { Utility-DisplayInfo "INFORMATION: Skipping Environment variable setup as parameter" -dxcstr2 "dxcUpgradeEnvVariables" -dxcstr3 "is set to" -dxcstr4 "Auto" }
  
#Apply Security Settings
deploy-FunctionAppSecurity -FunctionAppName $dxcFunctionAppName -ResourceGroupName $dxcFunctionAppRGName -Location $dxcWorkspaceRegion -AppServiceAuthOn -HTTPSOnly -HTTP20Enabled -FTPDisabled
Write-Host "`n##########################################################"
Write-Host "STAGE5: FUNCTION DEPLOYMENT SECTION"
Write-Host "############################################################`n"

if (!$dxcFunctionAppExists -or ($UpgradeFunctionCodes -eq "Yes" )) {

    # Copy function code files to temporary deployment zip file

    if (Test-Path -Path $dxcZippedFunctionPath) {
        Remove-Item -Path $dxcZippedFunctionPath
    }
    $FilesToInclude = @('Functions/host.json', 'Functions/proxies.json', 'Functions/requirements.psd1', 'Functions/profile.ps1')

    Compress-Archive -Path 'Functions/Modules' -DestinationPath $dxcZippedFunctionPath
    Compress-Archive -Path 'Functions/CMPAlertTrigger' -DestinationPath $dxcZippedFunctionPath -Update
    Compress-Archive -LiteralPath $FilesToInclude -DestinationPath $dxcZippedFunctionPath -Update

    $error.Clear()
    $dxcOutput = az functionapp deployment source config-zip -g $dxcFunctionAppRGName -n $dxcFunctionAppName --src $dxcZippedFunctionPath | ConvertFrom-Json
    Remove-Item -Path $dxcZippedFunctionPath -Force >$null

    if (!$dxcOutput) { 
        Write-host $error
        Utility-DisplayWarning -dxcstr1 "WARNING:     Unable to deploy" -dxcstr2 $dxcZippedFunctionPath.Split("\")[-1] -dxcstr3 ". Script will exit now."
        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        Read-Host "`nPress 'ENTER'to exit the script........"
        exit
    }
    
    Utility-DisplayInfo -dxcstr1 "INFORMATION: Function from zip file" -dxcstr2 $dxcZippedFunctionPath.Split("\")[-1] -dxcstr3 "has been deployed successfully."
}
else { 
    Utility-DisplayInfo "INFORMATION: Skipping Function Code deployment as parameter" -dxcstr2 "dxcUpgradeFunctionCodes" -dxcstr3 "is set to" -dxcstr4 "Auto" 
}

Write-Host "`n##########################################################"
Write-Host "STAGE6: ACTION GROUP DEPLOYMENT SECTION"
Write-Host "############################################################`n"
$error.Clear()
Get-AzActionGroup -ResourceGroupName $dxcResourceGroup -Name $dxcActionGroup >$null 

if ($error) {
    Utility-DisplayInfo -dxcstr1 "INFORMATION: Deploying" -dxcstr2 $dxcActionGroup -dxcstr3 "actiongroup, this may take few minutes..."
    $dxcKeyListObject = az rest --method post --uri "https://management.azure.com/subscriptions/$SubscriptionId/resourceGroups/$dxcFunctionAppRGName/providers/Microsoft.Web/sites/$dxcFunctionAppName/host/default/listKeys?api-version=2018-11-01" | ConvertFrom-Json
    $dxcFunctionURI = "https://" + $dxcFunctionAppName + ".azurewebsites.net/api/CMPAlertTrigger?code=" + $dxcKeyListObject.functionKeys.default

    $dxcFunctionReceiver = New-AzActionGroupReceiver -Name "CMPFunction" -AzureFunctionReceiver -FunctionAppResourceId $dxcFunctionAppResourceId -HttpTriggerUrl $dxcFunctionURI -FunctionName "CMPAlertTrigger" -UseCommonAlertSchema
    $error.Clear()
    Set-AzActionGroup -ResourceGroupName $dxcResourceGroup -Name $dxcActionGroup -ShortName $dxcActionGroupShortName -Receiver $dxcFunctionReceiver >$null

    if ($error) { 
        Write-Host $error
        Utility-DisplayWarning -dxcstr1 "WARNING:     Unable to deploy ActionGroup" -dxcstr2 $dxcActionGroup -dxcstr3 ". Script will exit now."
        Read-Host "`nPress 'ENTER'to exit the script........"
        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        Exit
    }
    else { 
        Utility-DisplayInfo -dxcstr1 "INFORMATION: Action Group" -dxcstr2 $dxcActionGroup -dxcstr3 "has been deployed successfully." 
    }
}
else { 
    Utility-DisplayInfo -dxcstr1 "INFORMATION: ActionGroup" -dxcstr2 $dxcActionGroup -dxcstr3 "found in resourcegroup" -dxcstr4 $dxcResourceGroup 
}

Write-Host "`n##########################################################"
Write-Host "STAGE7A: FUNCTIONAPP TAGGING SECTION"
Write-Host "##########################################################`n"

#$faTags = (get-AzResource -ResourceGroupName $dxcFunctionAppRGName -Name $dxcFunctionAppName).Tags
if ($dxcManaged -eq "true") {
    $faTags += @{dxcManaged = "true" }
    if ($dxcMonitored -ceq "true") {
        $faTags += @{dxcMonitored = "true" }
    }
    else {
        $faTags += @{dxcMonitored = "false" }
    }
}
else {
    $faTags += @{dxcManaged = "false" }
    $faTags += @{dxcMonitored = "false" }
}
$faTags += @{dxcConfigurationCheck = [DateTime]::UtcNow.ToString("yyyyMMddTHHmmssZ") }
Update-AzTag -ResourceId $dxcFunctionAppResourceId -Tag $faTags -Operation Replace

if ($dxcMonitored -eq "true") 
{
    $dxcStorageAccountId = (Get-AzResource -ResourceGroup $dxcFunctionAppRGName -Name $dxcStorageAccountName).Id
    Set-AzDiagnosticSetting -Name dxcDiagnostics -ResourceId $dxcFunctionAppResourceId -Category FunctionAppLogs -MetricCategory AllMetrics -Enabled $true -StorageAccountId $dxcStorageAccountId -WorkspaceId $dxcWorkspaceResourceId
}
######## Update Tags For AI, ASP, storage account #########

$dxcTags = @{
    "dxcManaged" = "True"
    "dxcMonitored" = "False"
    "dxcConfigurationCheck" = ([System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId((Get-Date), 'UTC')).ToString("yyyyMMddTHHmmssZ")
}

$resources = $dxcAppServicePlan, $dxcAppInsightName
foreach ($functionresources in $resources) { 
    Update-AzTag -ResourceId (Get-AzResource -Name $functionresources).ResourceId -Tag $dxcTags -Operation Merge
}

$MonitorTags = @{
    "dxcManaged" = "True"
    "dxcMonitored" = "True"
    "dxcConfigurationCheck" = ([System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId((Get-Date), 'UTC')).ToString("yyyyMMddTHHmmssZ")
}

    Update-AzTag -ResourceId (Get-AzResource -Name $dxcStorageAccountName).ResourceId -Tag $MonitorTags -Operation Merge

Write-Host "`n##################################################################"
Write-Host "STAGE7B: COPY CMPV2 SPECIFIC CMDB UPDATE ALERTS TO ALERTS DIRECTORY"
Write-Host "####################################################################`n"

$cmpDeploymentDirectory = (Get-Item alerts-CMDBUpdates.json).Directory

if ( $cmpDeploymentDirectory -match ".*CMPAlertDeployment$" ) {
    Copy-Item .\alerts-CMDBUpdates.json (Join-Path $cmpDeploymentDirectory.Parent  "Alerts")
} else {
    Write-Host "Expected to be in CMPAlertDeployment folder, but was in $cmpDeploymentDirectory"
    Write-Host "You'll need to manually copy alerts-CMDBUpdates from the CMPAlertDeployment folder to Alerting\Alerts"
}

Write-Host "`n##########################################################"
Write-Host "STAGE8: FUNCTIONAPP ALERT DEPLOYMENT SECTION"
Write-Host "##########################################################`n"

Utility-DisplayInfo -dxcstr1 "INFORMATION: Run the below command in powershell 7.x console, from" -dxcstr2 "...\OnBoarding\Alerting\FunctionAppAlertDeployment\" -dxcstr3 "folder to deploy alerts for this FunctionApp"
Write-Host ".\deployFunctionAppAlerts.ps1 -functionAppName $dxcFunctionAppName -appInsightsName $dxcAppInsightName -logAnalyticsWorkspaceName $LogAnalyticsWorkspaceName -subscriptionId $SubscriptionId -applicationName 'dxc-CMPCloudEvent'"
Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
Write-Host "`n*****************End OF SCRIPT EXECUTION*****************"
