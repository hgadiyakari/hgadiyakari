#=====================================================================================================================
# DOCUMENTATION LINK
# https://confluence.dxc.com/display/CSA/AZR-12006+Create+function+app+to+manage+metric+alerts
#=====================================================================================================================

[CmdletBinding(SupportsShouldProcess=$true)]
Param
    (
    [Parameter(Mandatory=$true)] [String]$SubscriptionId,
    [Parameter(Mandatory=$true)] [String]$TenantId,
    [Parameter(Mandatory=$true)] [String]$LogAnalyticsWorkspaceName,
    [Parameter(Mandatory=$true)] [String]$ServiceNowURL,
    [Parameter(Mandatory= $true)][String]$keyVault = "",
    [Parameter(Mandatory=$true)] [ValidateSet("Auto","Yes")] [String]$UpgradeFunctionCodes,
    [Parameter(Mandatory=$true)] [ValidateSet("Auto","Yes")] [String]$UpgradeEnvVariables,
	[Parameter(Mandatory=$false)] [String]$SpKey,
	[Parameter(Mandatory=$false)] [String]$ClientID
    )
#=====================================================================================================================
# IMPORTCUSTOM MODULES AND CHECK ENVIRONMENT FOR NECESSERY MODULES
#=====================================================================================================================
$dxcModuleList = "DXCEnvCheckV2.psm1", "DXCUtilityFunctions.psm1", "DXCDeploymentFunctions.psm1"
foreach ($dxcModule in $dxcModuleList)
    {
    [String]$dxcModuleURL = "https://dxcazuretoolsdev.blob.core.windows.net/installers/DXCPowershellModules/" + $dxcModule
    [String]$dxcLocalModule = $PSScriptRoot + "\" + $dxcModule
    (New-Object System.Net.WebClient).DownloadFile($dxcModuleURL, $dxcLocalModule)
    Import-Module $dxcLocalModule -WA 0
    Remove-Item -Path $dxcLocalModule
    }   
$dxcPSCore = Check-PSCore -Version 7.0.0
if ($dxcPSCore) { $dxcAZ = Check-AzModule -Version 2.5.0 }
if ($dxcAZ) { $dxcAZCli = Check-AzureCLI -Version 2.1.0 }
if ($dxcAZCli) { $dxcAZStorage = Check-PSModule -Name "Az.Storage" -Version 1.5.1 }
if ($dxcAZStorage) { $dxcAZMonitor = Check-PSModule -Name "Az.Monitor" -Version 1.5.0 }
if ($dxcAZMonitor) { $dxcAZFunctions = Check-PSModule -Name "Az.Functions" -Version 1.0.0 }
if ($dxcAZFunctions) { $dxcAZNetApp = Check-PSModule -Name "Az.NetAppFiles" -Version 0.3.0 }
if ($dxcAZNetApp) { $dxcAZApplicationInsights = Check-PSModule -Name "Az.ApplicationInsights" -Version 1.0.1 }
if($dxcAZApplicationInsights){$dxcAZResource = Check-PSModule -Name "Az.Resources" -Version 3.2.0 }
if (!$dxcAZResource)
    {
    Read-Host "`nPress 'ENTER'to exit the script........"
    exit
    }

#=====================================================================================================================
# LOGIN SECTION
#=====================================================================================================================
$error.Clear()

if ($SpKey) {
	Utility-LoginAZSpn -TenantId $TenantId -SpnKey $SpKey -ClientId $ClientID -SubscriptionId $SubscriptionId
	Utility-LoginAzureCliSpn -TenantId $TenantId -SpnKey $SpKey -ClientId $ClientID -SubscriptionId $SubscriptionId
	}
else {
	Utility-LoginAZTenant -TenantId $TenantId -SubscriptionId $SubscriptionId
	Utility-LoginAureCliTenant -TenantId $TenantId -SubscriptionId $SubscriptionId
	}

##############################################################
write-host "Information: Retrieving secrets from Key Vault"
##############################################################
$ServiceNowUser = Get-AzKeyVaultSecret -vaultName $keyVault -name "ITSMIntegrationUser" -AsPlainText
$ServiceNowUserPwd = Get-AzKeyVaultSecret -vaultName $keyVault -name "ITSMIntegrationPass" -AsPlainText

#Check values for SNOW username and password were successfully retrieved.
If (($null -eq $ServiceNowUser) -or ($null -eq $ServiceNowUserPwd)) 
    {
    Write-Host "ERROR:     Unable to retrieve SNOW username or password from the specified keyvault: $keyvault" -ForegroundColor Red
    Write-Host "ERROR:     Confirm you have access to the keyvault and the secrets ITSMIntegrationUser and ITSMIntegrationPass are populated." -ForegroundColor Red
    Read-Host "`nPress 'ENTER'to exit the script........"
    exit
    }      
    

#=====================================================================================================================
# VARIABLE SECTION
#=====================================================================================================================
[String]$dxcEventProcessingSchema = "3.0"
[String]$dxcFunctionAppRGName = "dxc-automation-rg"
[String]$dxcActionGroup = "DXC-AG-Metric"
[String]$dxcFunctionAppIdentityScope = '/subscriptions/' + $SubscriptionId
[array]$blobfiles = (Get-ChildItem ($PSScriptRoot + '\Metric_Alerts\metricAlerts_*.json')).FullName       
[String]$dxcFunctionAppAlertJSON = $PSScriptRoot + '\alerts-FunctionApp.json'
if (-not( $ServiceNowURL.substring($ServiceNowURL.length -1) -eq "/")) { $ServiceNowURL = $ServiceNowURL + "/" }


[String]$dxcRandom = Utility-GeneratingUniqueID -dxcResourceGroupName $dxcFunctionAppRGName
[String]$dxcStorageAccountName = 'dxcmtr' + $dxcRandom + 'sa'
[String]$dxcAppServicePlan = 'dxc-FuncAppB1-' + $dxcRandom + '-ASP'
[String]$dxcFunctionAppName = 'dxc-MetricAlerts-' + $dxcRandom + '-FA'
[String]$dxcAppInsight = 'dxc-FuncApp-' + $dxcRandom + '-AI'
[String]$dxcWebResource = $dxcFunctionAppName + "/web"
[String]$dxcAuthResource = $dxcFunctionAppName + "/authsettings"
[String]$dxcZippedFunctionPath = $PSScriptRoot + '\' + $dxcFunctionAppName + '.zip'

#SECUTIRY SETTINGS
$httpsOnly = $true
$dxcWebSecuritySettings = @{ 
                            "http20Enabled" = "True";
                            "ftpsState"="Disabled";
                           }

$dxcAuthSettings =        @{
                            "enabled" = "True";
                            "unauthenticatedClientAction" = "1";
                            "defaultProvider" = "0";
                            "tokenStoreEnabled" = "False";
                           }

#========================================================================================================================
# MAIN BODY OF THE SCRIPT
#========================================================================================================================
$ErrorActionPreference = "SilentlyContinue"
$WarningPreference = "SilentlyContinue"

#Collect Maintenance ResourceGroup and OMS Workspace Details.
$dxcObjWorkspace = Get-AzOperationalInsightsWorkspace | Where-Object { $_.Name -Match $LogAnalyticsWorkspaceName }
If ($dxcObjWorkspace)
    {
    [String]$LogAnalyticsWorkspaceName = $dxcObjWorkspace.Name
    [String]$dxcResourceGroup = $dxcObjWorkspace.ResourceGroupName
    [String]$dxcWorkspaceRegion = (($dxcObjWorkspace.location).ToLower()) -replace '\s',''

    Utility-DisplayInfo -dxcstr1 "INFORMATION: Loganalytics Workspace named" -dxcstr2 $LogAnalyticsWorkspaceName -dxcstr3 "located under ResourceGroup" -dxcstr4 $dxcResourceGroup
    }
else
    {
    Write-Host "WARNING:     Loganalytics Workspace not found. Please enter correct workspace name while running the script." -ForegroundColor Yellow
    Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
    Read-Host "`nPress 'ENTER'to exit the script........"
    exit
    }
    
Write-Host "`n##########################################################"
Write-Host "STAGE1: RESOURCE GROUP DEPLOYMENT SECTION"
Write-Host "##########################################################`n"

$dxcRGExtsts, $dxcobjRG = Deploy-ResourceGroup -Name $dxcFunctionAppRGName -Location $dxcWorkspaceRegion

if (!$dxcobjRG)
    {
    Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
    Read-Host "`nPress 'ENTER'to exit the script........"
    exit
    }
$error.Clear()
New-AzResourceLock -ResourceGroupName $dxcFunctionAppRGName -LockName "DXC-Automation-RG-Lock" -LockNotes "Cannot Delete Lock applied on this Resource Group to avoid accidental deletion of all resources from automation resource group" -LockLevel "CanNotDelete" -Force >$null

if (!$dxcOutput) { Utility-DisplayWarning -dxcstr1 "WARNING:     Unable to lock the ResourceGroup" -dxcstr2 $dxcFunctionAppRGName -dxcstr " . You need to Manually Lock it against deletion, post deployment." }
Else { Utility-DisplayInfo -dxcstr1 "INFORMATION: Deletion Lock applied to the ResourceGroup" -dxcstr2 $dxcFunctionAppRGName }
	
#Create storage account and Table
Write-Host "`n##########################################################"
Write-Host "STAGE2: STORAGE ACCOUNT DEPLOYMENT SECTION"
Write-Host "##########################################################`n"
$error.Clear()
$dxcStorageExists, $dxcObjStorage = Deploy-StorageAccount -Location $dxcWorkspaceRegion -ResourceGroupName $dxcFunctionAppRGName -Name $dxcStorageAccountName -Container "metric-alerts" -Table "CustomAlerts" -Queue "None" -Blobfiles $blobfiles

if (!$dxcObjStorage)
    {
    Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
    Read-Host "`nPress 'ENTER'to exit the script........"
    exit
    }

if (!$dxcStorageExists)
    {
    write-host $dxcObjStorage.Context
    $dxcStorageTable = Get-AzStorageTable -Name "CustomAlerts" -Context $dxcObjStorage.Context
    Add-AzTableRow -table $dxcStorageTable.CloudTable -partitionKey "Enter Resource Name in this Column" -rowKey ("Enter Alert Name in this Column") -property @{"ResourceType"="Enter Azure Resource Type in this Column";"Threshold"="Enter Custom Threshold in this Column"} >$null
    $error.Clear()
    }
     
#Create the FunctionApp and Configure it
Write-Host "`n##########################################################"
Write-Host "STAGE3: FUNCTIONAPP DEPLOYMENT AND CONFIGURATION SECTION"
Write-Host "##########################################################`n"
$dxcFunctionAppExists, $dxcObjFunctionApp = Deploy-FunctionApp -SubscriptionId $SubscriptionId  -Location $dxcWorkspaceRegion -ResourceGroupName $dxcFunctionAppRGName -Name $dxcFunctionAppName -StorageAccountName $dxcStorageAccountName -AppServicePlanName $dxcAppServicePlan -Sku "B1" -AppInsights $dxcAppInsight -OSType "Windows" -Runtime "powershell" -FunctionVersion 2 -AlwaysON
$dxcObjFunctionApp = Get-AzFunctionApp -ResourceGroupName $dxcFunctionAppRGName -Name $dxcFunctionAppName

if ($dxcObjFunctionApp) 
    { 
     [bool]$FunctionAppExists = $true
    }
else
    {
    #Deploy FunctionApp if doesn't exit
    $dxcFunctionAppExists = $dxcObjFunctionApp = Deploy-FunctionApp -SubscriptionId $SubscriptionId  -Location $dxcWorkspaceRegion -ResourceGroupName $dxcFunctionAppRGName -Name $dxcFunctionAppName -StorageAccountName $dxcStorageAccountName -AppServicePlanName $dxcAppServicePlan -Sku "B1" -AppInsights $dxcAppInsight -OSType "Windows" -Runtime "powershell" -FunctionVersion 2 -AlwaysON
    $dxcObjFunctionApp = Get-AzFunctionApp -ResourceGroupName $dxcFunctionAppRGName -Name $dxcFunctionAppName
     If($dxcObjFunctionApp)
        {
        [bool]$FunctionAppExists = $true
        }
    else
        {
        [bool]$FunctionAppExists = $false
        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        Read-Host "`nPress 'ENTER'to exit the script........"
        exit
        }
   }
#Create an identity for it and then provide required access to it.
Write-Host "`n###############################################################"
Write-Host "STAGE4: FUNCTIONAPP IDENTITY AND ENVIRONMENT SETTINGS SECTION"
Write-Host "###############################################################`n"

if (!$dxcFunctionAppExists)
    {
    $dxcOutput =  az functionapp identity assign -g $dxcFunctionAppRGName -n $dxcFunctionAppName --role "Monitoring Contributor" --scope $dxcFunctionAppIdentityScope  | ConvertFrom-Json
    $error.Clear()
    if (!$dxcOutput) 
        { 
        Write-Host "WARNING:     Unable to provide necessary access to FunctionApp. You may not have 'Owner' rights to the subscription." -ForegroundColor Yellow
        Write-Host "             The script will continue to deploy but for proper functioning, some one with owner rights have to assign it the necessery permissions." -ForegroundColor Yellow
        Write-Host "             Please follow the direction in its wiki link to assign permission to this functionapp after deployment." -ForegroundColor Yellow
        }
    Else { Utility-DisplayInfo -dxcstr1 "INFORMATION: FunctionApp" -dxcstr2 $dxcFunctionAppName -dxcstr3 "has been provided Monitoring Contributor access to the Subscription." -ForegroundColor Green }
   }

#Set Environtment Variables to FunctionApp
if (!$dxcFunctionAppExists -or ($UpgradeEnvVariables -eq "Yes" ))
    {

    $function_extension_version = az functionapp config appsettings list --name $dxcFunctionAppName --resource-group $dxcFunctionAppRGName --query "[?name=='FUNCTIONS_EXTENSION_VERSION'].value" | ConvertFrom-Json
    if ($function_extension_version -ne "~3") 
        {
            Utility-DisplayInfo -dxcstr1 "INFORMATION: FunctionApp named" -dxcstr2 $dxcFunctionAppName -dxcstr3 "being updated to powershell 7"
            $AzFunctionAppStorageAccountKey = Get-AzStorageAccountKey -ResourceGroupName $dxcFunctionAppRGName -AccountName $dxcStorageAccountName | Where-Object { $_.KeyName -eq "Key1" } | Select-Object Value
            $AzFunctionAppStorageAccountConnectionString = "DefaultEndpointsProtocol=https;AccountName=$dxcStorageAccountName;AccountKey=$($AzFunctionAppStorageAccountKey.Value);EndpointSuffix=core.windows.net"
            az functionapp config appsettings set --name $dxcFunctionAppName --resource-group $dxcFunctionAppRGName --settings "AzureWebJobsStorage=$AzFunctionAppStorageAccountConnectionString"
            az functionapp config appsettings set --name $dxcFunctionAppName --resource-group $dxcFunctionAppRGName --settings "FUNCTIONS_EXTENSION_VERSION=~3"  
            az functionapp config appsettings set --name $dxcFunctionAppName --resource-group $dxcFunctionAppRGName --settings "FUNCTIONS_WORKER_RUNTIME=powershell"
            az functionapp config appsettings set --name $dxcFunctionAppName --resource-group $dxcFunctionAppRGName --settings "WEBSITE_NODE_DEFAULT_VERSION=~10"
            # Enable the ApplicationInsights -- Get the ApplicationInsights InstrumentationKey and then enable.
            $instrumentationKey = (Get-AzApplicationInsights -ResourceGroupName $dxcFunctionAppRGName -Name $dxcAppInsight).InstrumentationKey
            az functionapp config appsettings set --name $dxcFunctionAppName --resource-group $dxcFunctionAppRGName --settings "APPINSIGHTS_INSTRUMENTATIONKEY = $instrumentationKey"
            #az functionapp config appsettings set --name $dxcFunctionAppName --resource-group $dxcFunctionAppRGName --settings "WEBSITE_CONTENTAZUREFILECONNECTIONSTRING=$AzFunctionAppStorageAccountConnectionString"  
            #az functionapp config appsettings set --name $dxcFunctionAppName --resource-group $dxcFunctionAppRGName --settings "WEBSITE_CONTENTSHARE=$AzFunctionAppStorageAccountConnectionString"  
            #az functionapp config appsettings set --name $dxcFunctionAppName --resource-group $dxcFunctionAppRGName --settings $dxcFunctionAppName
            Set-AzResource -ResourceId "/subscriptions/$SubscriptionId/resourceGroups/$dxcFunctionAppRGName/providers/Microsoft.Web/sites/$dxcFunctionAppName/config/web" -UsePatchSemantics -Properties @{ powerShellVersion = '~7' } -Force
        }
    else 
        {
        Utility-DisplayInfo -dxcstr1 "INFORMATION: FunctionApp already has FUNCTIONS_EXTENSION_VERSION = ~3"
        } 

    Write-Host "`nINFORMATION: Settting up environment variable for the powershell function...." -ForegroundColor Green
    $dxcOutput = az functionapp config appsettings set --name $dxcFunctionAppName --resource-group $dxcFunctionAppRGName `
        --settings "AZURE_WORKSPACE_RG=$dxcResourceGroup" "SNOW_URI=$ServiceNowURL" "SNOW_USER=$ServiceNowUser" "SNOW_PASS=$ServiceNowUserPwd" "EVENT_PROCESSING_SCHEMA=$dxcEventProcessingSchema" | ConvertFrom-Json

    if (!$dxcOutput) 
        { 
        Write-Host "WARNING:     Unable to set environment variables to FunctionApp. Script will exit now." -ForegroundColor Yellow
        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        Read-Host "`nPress 'ENTER'to exit the script........"
        exit
        }
    Write-Host "INFORMATION: Environment variable setup completed successfully." -ForegroundColor Green
    }
else { Utility-DisplayInfo "INFORMATION: Skipping Environment variable setup as parameter" -dxcstr2 "dxcUpgradeEnvVariables" -dxcstr3 "is set to" -dxcstr4 "Auto" }

#Apply Security Settings
Write-Host "`nINFORMATION: Applying security settings for the Function App..." -ForegroundColor Green

$error.Clear()
New-AzResource -PropertyObject $dxcWebSecuritySettings -ResourceGroupName $dxcFunctionAppRGName -ResourceType "Microsoft.Web/sites/config" -ResourceName $dxcWebResource -ApiVersion 2015-08-01 -Force
New-AzResource -PropertyObject $dxcAuthSettings -ResourceGroupName $dxcFunctionAppRGName -ResourceType "Microsoft.Web/sites/config" -ResourceName $dxcAuthResource -ApiVersion 2015-08-01 -Force
#If ($httpsOnly) { $dxcOutput = az functionapp update  --name $dxcFunctionAppName --resource-group $dxcFunctionAppRGName --set httpsOnly=true }

If ($error -or (!$dxcOutput)) 
    {
    Write-Host "WARNING:     Failed to deploy some or all the security settngs, follow the below Wiki document to set the security settings manually if rest of the deployment is successfull." -ForegroundColor Yellow
    Write-Host "             https://confluence.dxc.com/pages/viewpage.action?pageId=207312130"
    }
else { Write-Host "INFORMATION: Security settings implemented successfully." -ForegroundColor Green }
## Update Tags to ASP ###

Start-Sleep -s 65

#Deploy Functions along with the necessery configuration
Write-Host "`n##########################################################"
Write-Host "STAGE5: FUNCTION DEPLOYMENT SECTION"
Write-Host "##########################################################`n"

if (!$dxcFunctionAppExists -or ($UpgradeFunctionCodes -eq "Yes" ))
    {
    Write-Host "INFORMATION: Deploying Functions, this may take few minutes..." -ForegroundColor Green
    #Copy-Item $dxcMetricFunctionZip $dxcZippedFunctionPath >$null

    if (Test-Path -Path $dxcZippedFunctionPath) {
        Remove-Item -Path $dxcZippedFunctionPath
    }
    
    Compress-Archive -path 'Functions/*' -destinationpath $dxcZippedFunctionPath -force

    $error.Clear()
    $dxcOutput = az functionapp deployment source config-zip -g $dxcFunctionAppRGName -n $dxcFunctionAppName --src $dxcZippedFunctionPath | ConvertFrom-Json
    Remove-Item -Path $dxcZippedFunctionPath -Force >$null

    if (!$dxcOutput) 
        { 
        Utility-DisplayWarning -dxcstr1 "WARNING:     Unable to deploy" -dxcstr2 $dxcZippedFunctionPath.Split("\")[-1] -dxcstr3 " . Script will exit now."
        Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
        Read-Host "`nPress 'ENTER'to exit the script........"
        exit
        }
    Utility-DisplayInfo -dxcstr1 "INFORMATION: Function from zip file" -dxcstr2 $dxcZippedFunctionPath.Split("\")[-1] -dxcstr3 "has been deployed successfully."
    }
else { Utility-DisplayInfo "INFORMATION: Skipping Function Code deployment as parameter" -dxcstr2 "dxcUpgradeFunctionCodes" -dxcstr3 "is set to" -dxcstr4 "Auto" }

#######################Tags deployment ########################################
$dxcTags = @{
    "dxcManaged" = "True"
    "dxcMonitored" = "False"
    "dxcConfigurationCheck" = ([System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId((Get-Date), 'UTC')).ToString("yyyyMMddTHHmmssZ")
}

$resources = $dxcAppServicePlan, $dxcAppInsight
foreach ($functionresources in $resources) { 
    Update-AzTag -ResourceId (Get-AzResource -Name $functionresources).ResourceId -Tag $dxcTags -Operation Merge
}

$MonitorTags = @{
    "dxcManaged" = "True"
    "dxcMonitored" = "True"
    "dxcConfigurationCheck" = ([System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId((Get-Date), 'UTC')).ToString("yyyyMMddTHHmmssZ")
}

$monitoredresources = $dxcStorageAccountName,$dxcFunctionAppName
foreach ($monitoredresource in $monitoredresources)
{
    Update-AzTag -ResourceId (Get-AzResource -Name $monitoredresource).ResourceId -Tag $MonitorTags -Operation Merge
}
#########################################################################
#Deploy ActionGroup with FunctionApp receiver actions.
Write-Host "`n##########################################################"
Write-Host "STAGE6: ACTION GROUP DEPLOYMENT SECTION"
Write-Host "##########################################################`n"
$error.Clear()
Get-AzActionGroup -ResourceGroupName $dxcResourceGroup -Name $dxcActionGroup >$null 

if ($error)
    {
    Utility-DisplayInfo -dxcstr1 "INFORMATION: Deploying" -dxcstr2 $dxcActionGroup -dxcstr3 "ActionGroup, this may take few minutes..."
    $dxcKeyListObject = az rest --method post --uri "https://management.azure.com/subscriptions/$SubscriptionId/resourceGroups/$dxcFunctionAppRGName/providers/Microsoft.Web/sites/$dxcFunctionAppName/host/default/listKeys?api-version=2018-11-01" | ConvertFrom-Json
    $dxcFunctionURI = "https://" + $dxcFunctionAppName + ".azurewebsites.net/api/Process-MetricAlerts?code=" + $dxcKeyListObject.functionKeys.default

    $dxcFunctionReceiver = New-AzActionGroupReceiver -Name "MetricFunction" -UseCommonAlertSchema -AzureFunctionReceiver -FunctionAppResourceId $dxcObjFunctionApp.id -HttpTriggerUrl $dxcFunctionURI -FunctionName "Process-MetricAlerts" 
    $error.Clear()
    Set-AzActionGroup -ResourceGroupName $dxcResourceGroup -Name $dxcActionGroup -ShortName (($dxcActionGroup.tolower()).replace("-ag-","")) -Receiver $dxcFunctionReceiver >$null

    if ($error) 
        { 
        Utility-DisplayWarning -dxcstr1 "WARNING:     Unable to deploy ActionGroup" -dxcstr2 $dxcActionGroup -dxcstr3 ". Script will exit now."
        Read-Host "`nPress 'ENTER'to exit the script........"
        }
    else { Utility-DisplayInfo -dxcstr1 "INFORMATION: Action Group" -dxcstr2 $dxcActionGroup -dxcstr3 "has been deployed successfully." }
    }
else { Utility-DisplayInfo -dxcstr1 "INFORMATION: ActionGroup" -dxcstr2 $dxcActionGroup -dxcstr3 "already exists." }
Write-Host "`n##########################################################"
Write-Host "STAGE7: FUNCTIONAPP ALERT DEPLOYMENT SECTION"
Write-Host "##########################################################`n"

Utility-DisplayInfo -dxcstr1 "INFORMATION: Run the below command in powershell 7.x console, from" -dxcstr2 "...\OnBoarding\Alerting\FunctionAppAlertDeployment\" -dxcstr3 "folder to deploy alerts for this FunctionApp"
Write-Host ".\deployFunctionAppAlerts.ps1 -functionAppName $dxcFunctionAppName -appInsightsName $dxcAppInsight -logAnalyticsWorkspaceName $LogAnalyticsWorkspaceName -subscriptionId $SubscriptionId -applicationName 'dxc-MetricAlert'"

Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
Write-Host "`n*****************End OF SCRIPT EXECUTION*****************"#>
