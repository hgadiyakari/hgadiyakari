
# Metric Alert Deployment

This folder contains the powershell file and artifacts that are used to deploy Metric alerts

## Jira Epic
https://jira.dxc.com/browse/AZR-8818

## Deployment
For more information on how to deploy Metric alerts see:
* https://confluence.dxc.com/display/CSA/AZR-12006+Create+function+app+to+manage+metric+alerts

## Members of this directory are:
* deployMetricAlertFunction.ps1		Main script to deploy Metric Alerts
* DeployFunction-MetricAlerts.zip	artifact file executed by main script

## Authors
* Santanu Sengupta
