# Azure Functions profile.ps1

if ($env:MSI_SECRET -and (Get-Module -ListAvailable Az.Accounts)) 
{
    Connect-AzAccount -Identity
}
