using namespace System.Net

# Input bindings are passed in via param block.
param($Request, $TriggerMetadata)

#VARIABLE DECLERATION
$ErrorActionPreference = "SilentlyContinue"
$WarningPreference = "SilentlyContinue"

#CHECK IF COMMON ALERT SCHEMA HAS BEEN ENABLED
if (-not(($Request.Body.SchemaId) -and ($Request.Body.SchemaId -eq "azureMonitorCommonAlertSchema")))
    {
    $ErrorActionPreference = "Continue"
    Write-Error "Common Alert Schema has not been enabled on the ActionGroup that has sent this alert. Terminating further processing of this alert."
    Exit
    }

#VARIABLE SECTION
$dxcSnowUser = $env:SNOW_USER
$dxcSnowPassword = $env:SNOW_PASS
$dxcSnowAPIUri = $env:SNOW_URI + "api/now/table/em_event"
$dxcEventProcessingSchema = $env:EVENT_PROCESSING_SCHEMA
$dxcMetricName = $Request.Body.Data.alertContext.condition.allOf[0].metricName
$filter = "[^.]+$"
$metricNamespaceValue = $Request.Body.Data.alertContext.condition.allOf.metricNamespace | select-string -Pattern $filter | % { $_.Matches } | Select-Object

$dxcMetricName = $metricNamespaceValue, $dxcMetricName -join "-"


#SET EVENT TYPE AND EVENT RESOURCE FOR EACH METRIC TYPE HERE. WHEN INSERTING A NEW METRIC, ENSURE YOU INSERT THE RESOURCE NAMESPACE FOLLOWED BY THE HYPHEN SYMBOL THEN THE METRIC NAME. 
switch($dxcMetricName)
    { 
    "DocumentDB/databaseAccounts-TotalRequests"                         { $dxcEventType = "Performance";        $dxcEventResource = "Cosmos DB Service";        Break }#CosmosDB
    "DocumentDB/databaseAccounts-ServerSideLatency"                     { $dxcEventType = "Latency";            $dxcEventResource = "Cosmos DB";                Break }#CosmosDB
    "DocumentDB/databaseAccounts-ServiceAvailability"                   { $dxcEventType = "Availability";       $dxcEventResource = "Cosmos DB Service";        Break }#CosmosDB
    "Percentage CPU"                                                    { $dxcEventType = "Performance";        $dxcEventResource = "CPU";                      Break }
    "Requests"                                                          { $dxcEventType = "Performance";        $dxcEventResource = "Web Requests";             Break }
    "Web/serverfarms-CpuPercentage"                                     { $dxcEventType = "Performance";        $dxcEventResource = "CPU";                      Break }
    "Web/serverfarms-MemoryPercentage"                                  { $dxcEventType = "Performance";        $dxcEventResource = "Memory";                   Break }
    "Network/loadBalancers-DipAvailability"                             { $dxcEventType = "Availability";       $dxcEventResource = "Backend Pool";             Break } #sLB
    "Network/loadBalancers-VipAvailability"                             { $dxcEventType = "Availability";       $dxcEventResource = "Virtual IP";               Break } #sLB
    "Network/loadBalancers-SnatConnectionCount"                         { $dxcEventType = "Performance";        $dxcEventResource = "Virtual IP";               Break } #sLB
    "DBforPostgreSQL/servers-active_connections"                        { $dxcEventType = "Performance";        $dxcEventResource = "Database";                 Break } #PostgreSQL
    "DBforPostgreSQL/servers-connections_failed"                        { $dxcEventType = "Availability";       $dxcEventResource = "Database";                 Break } #PostgreSQL
    "DBforPostgreSQL/servers-cpu_percent"                               { $dxcEventType = "Performance";        $dxcEventResource = "CPU";                      Break } #PostgreSQL
    "DBforPostgreSQL/servers-io_consumption_percent"                    { $dxcEventType = "Performance";        $dxcEventResource = "Server";                   Break } #PostgreSQL
    "DBforPostgreSQL/servers-memory_percent"                            { $dxcEventType = "Performance";        $dxcEventResource = "Memory";                   Break } #PostgreSQL
    "DBforPostgreSQL/servers-serverlog_storage_percent"                 { $dxcEventType = "Capacity";           $dxcEventResource = "Log Storage";              Break } #PostgreSQL
    "DBforPostgreSQL/servers-storage_percent"                           { $dxcEventType = "Capacity";           $dxcEventResource = "Storage";                  Break } #PostgreSQL
    "Storage/storageAccounts-Availability"                              { $dxcEventType = "Availability";       $dxcEventResource = "Storage";                  Break } #StorageAccountFileShare
    "Storage/storageAccounts-UsedCapacity"		                        { $dxcEventType = "Capacity";		    $dxcEventResource = "Storage";                  Break } #StorageAccountFileShare
    "Storage/storageAccounts-FileCapacity"                              { $dxcEventType = "Capacity";		    $dxcEventResource = "Storage";                  Break } #StorageAccountFileShare
    "DBforMySQL/servers-cpu_percent"                                    { $dxcEventType = "Performance";        $dxcEventResource = "CPU";                      Break } #MySQL
    "DBforMySQL/servers-memory_percent"                                 { $dxcEventType = "Performance";        $dxcEventResource = "Memory";                   Break } #MySQL
    "DBforMySQL/servers-io_consumption_percent"                         { $dxcEventType = "Performance";        $dxcEventResource = "Server";                   Break } #MySQL
    "DBforMySQL/servers-storage_percent"                                { $dxcEventType = "Capacity";           $dxcEventResource = "Storage";                  Break } #MySQL
    "DBforMySQL/servers-serverlog_storage_percent"                      { $dxcEventType = "Capacity";           $dxcEventResource = "Log Storage";              Break } #MySQL
    "DBforMySQL/servers-connections_failed"                             { $dxcEventType = "Availability";       $dxcEventResource = "Server";                   Break } #MySQL
    "container/nodes-memoryRssPercentage"                               { $dxcEventType = "Performance";		$dxcEventResource = "Memory";                   Break } #AKS Cluster Nodes
    "container/nodes-cpuUsagePercentage"                                { $dxcEventType = "Performance";		$dxcEventResource = "CPU";                      Break } #AKS Cluster Nodes
    "Sql/managedInstances-avg_cpu_percent"                              { $dxcEventType = "Performance";        $dxcEventResource = "CPU";                      Break } #SQL Managed Instance
    "Sql/managedInstances-storage_space_used_mb"                        { $dxcEventType = "Capacity";           $dxcEventResource = "Database";                 Break } #SQL Managed Instance
    "Network/azurefirewalls-FirewallHealth"                             { $dxcEventType = "Availability";		$dxcEventResource = "Firewall";          		Break } #FirewallHealthStatus
    "Network/applicationGateways-ApplicationGatewayTotalTime"           { $dxcEventType = "Performance";        $dxcEventResource = "Application GW";           Break } #AppGWv2
    "Network/applicationGateways-BackendResponseStatus"                 { $dxcEventType = "Performance";        $dxcEventResource = "Application GW Backend";   Break } #AppGWv2
    "ServiceBus/namespaces-ServerErrors"                                { $dxcEventType = "Availability";       $dxcEventResource = "Service Bus";              Break } #AzureServiceBus
    "ServiceBus/namespaces-UserErrors"                                  { $dxcEventType = "Application";        $dxcEventResource = "Service Bus";              Break } #AzureServiceBus
    "ServiceBus/namespaces-ThrottledRequests"                           { $dxcEventType = "Capacity";           $dxcEventResource = "Namespace";                Break } #AzureServiceBus
    "Network/applicationGateways-ApplicationGatewayTotalTime"           { $dxcEventType = "Performance";        $dxcEventResource = "Application GW";           Break } #AppGWv2
    "Network/applicationGateways-BackendResponseStatus"                 { $dxcEventType = "Performance";        $dxcEventResource = "Application GW Backend";   Break } #AppGWv2
    "Logic/workflows-RunFailurePercentage"                              { $dxcEventType = "Availability";       $dxcEventResource = "Workflow";                 Break } #AzureLogicApp
    "NetApp/netAppAccounts/capacityPools/volumes-VolumeConsumedSizePercentage"                                  {$dxcEventType = "Capacity";       $dxcEventResource = "Storage";                 Break} #NetAppVolume
    "EventHub/namespaces-IncomingMessages"                              { $dxcEventType = "Capacity";           $dxcEventResource = "Events";                   Break } #AzureEventHub
    "EventHub/namespaces-ServerErrors"                                  { $dxcEventType = "Availability";       $dxcEventResource = "Events";                   Break } #AzureEventHub
    "EventHub/namespaces-ThrottledRequests"                             { $dxcEventType = "Performance";        $dxcEventResource = "Events";                   Break } #AzureEventHub
    "EventGrid/topics-PublishFailCount"                                 { $dxcEventType = "Availability";        $dxcEventResource = "Events";                  Break } #AzureEventGrid
    "EventGrid/topics-DroppedEventCount"                                { $dxcEventType = "Performance";        $dxcEventResource = "Events";                   Break } #AzureEventGrid
    default                                                             { $dxcEventType = "Unknown";            $dxcEventResource = "Unknown"                         }
    }

#MAIN BODY OF THE SCRIPT
$dxcMetricDetails = $Request.Body.Data.alertContext.condition.allOf | ConvertTo-Json | Out-String
$dxcResourceId = $Request.Body.Data.essentials.alertTargetIDs[0]
$null, $null, $dxcSubscriptionId, $null, $dxcResourceGroup, $null, $null, $null, $dxcResource  = $dxcResourceId.Split('/')


$dxcEventDescription = @"
Alert : $($Request.Body.Data.essentials.alertRule)
Description : $($Request.Body.Data.essentials.description)
TimeGenerated : $($Request.Body.Data.essentials.firedDateTime)
AlertStatus : $($Request.Body.Data.essentials.monitorCondition)
MetricDetails : $($dxcMetricDetails)
ResourceGroup : $($dxcResourceGroup)
SubscriptionId : $($dxcSubscriptionId) 
Resource : $($dxcResource)
ResourceId : $($dxcResourceId)
eventType : $($dxcEventType)
eventResource : $($dxcEventResource)
eventFormat : MetricAlert
eventProcessingSchema : $($dxcEventProcessingSchema)
"@

           
$dxcEventBody = 
    @{
    source = "OMS"
    severity = switch ($Request.Body.Data.essentials.severity)
                    {
                    "Sev0"   { "1"; Break }
                    "Sev1"   { "2"; Break }
                    "Sev2"   { "3"; Break }
                    "Sev3"   { "4"; Break }
                    "Sev4"   { "5"; Break }
                    Default  { "0"        }
                    }
    type = $dxcEventType
    resource = $dxcEventResource
    event_class = "MetricAlert"
    node = $dxcResource
    description = $dxcEventDescription
    }

$dxcCredPair = "$($dxcSnowUser):$($dxcSnowPassword)"
$dxcEncodedCred = [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes($dxcCredPair))
$dxcHeaders = 
    @{
    'Authorization' = "Basic $($dxcEncodedCred)"
    'Content-Type' = "application/json"
    'Accept' = "application/json"
    }

$dxcJSONBody = $dxcEventBody | ConvertTo-Json
$dxcResponse = 
    try 
        { 
        (Invoke-Webrequest -Uri $dxcSnowAPIUri -Header $dxcHeaders -Method POST -Body $dxcJSONBody -ErrorAction Stop).BaseResponse 
        } 
    catch [System.Net.WebException] 
        {
        $ErrorActionPreference = "Continue" 
        Write-Error "An exception was caught while processing $($dxcMetricName) alert for $($dxcEventResource) of resourceID $($dxcResourceId) .Message: $($_.Exception.Message)"
        $_.Exception.Response 
        } 
 $dxcStatusCodeInt = [int]$Response.BaseResponse.StatusCode
 Write-Host "Status Code: $($dxcStatusCodeInt)"
