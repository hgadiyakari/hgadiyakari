param($Timer)

#VARIABLE DECLERATION
$ErrorActionPreference = "SilentlyContinue"
$WarningPreference = "SilentlyContinue"
[string]$dxcResourceGroup = $env:AZURE_WORKSPACE_RG
[string]$dxcStorageConnection = $env:AzureWebJobsStorage

[string]$dxcAGName = "DXC-AG-Metric"

#CHECK IF ACTIONGROUP EXISTS
$Error.Clear()
$dxcMetricAG = get-AzActionGroup -ResourceGroupName $dxcResourceGroup -Name $dxcAGName
$dxcMetricAGId = New-AzActionGroup -ActionGroupId $dxcMetricAG.Id
if ($Error) { 
$ErrorActionPreference = "Continue"
Write-Error "Unable to locate ActionGroup: $dxcAGName under ResourceGroup: $($dxcResourceGroup)"; Exit }

#CHECK IF STORAGE ACCOUNT IS ACCESSABLE
$dxcStorageContext = New-AzStorageContext -ConnectionString $dxcStorageConnection
$dxcStorageAccountName = $dxcStorageContext.StorageAccountName
if ($Error) {
$ErrorActionPreference = "Continue"
Write-Error "Unable to connect to Storage Account: $($dxcStorageAccountName) Check whether enviroment variable AzureWebJobsStorage contains correct connection string."; Exit }

#CHECK IF METRIC ALERT CONTAINER EXISTS
$alertFiles = Get-AzStorageBlob -Context $dxcStorageContext -Container "metric-alerts" -Blob "metricAlerts_*.json"
if ($Error) { 
$ErrorActionPreference = "Continue"
Write-Error "The FunctionApp storage account does not contain 'metric-alerts' storage container: $($dxcStorageAccountName) or the container is empty."; Exit }

#GET CUSTOM ALERT THRESHOLDS
[Object[]]$dxcCustomTableRows = Get-AzTableRow -table ((Get-AzStorageTable -Name "CustomAlerts" -Context $dxcStorageContext).CloudTable)
If (-not($dxcCustomTableRows)) { 
$ErrorActionPreference = "Continue"
Write-Error "'CustomAlerts' table is either unavailable or unaccessable under Storageaccount: $($dxcStorageAccountName)"; Exit }

#MANAGE METRIC ALERTS
ForEach ($AlertFile in $alertFiles)
    {
    #GET BLOBS AND SET ALERT VARIABLES
    Get-AzStorageBlobContent -Context $dxcStorageContext -Container "metric-alerts" -Blob $AlertFile.Name -Destination "." -Force >$null
    $dxcAlertObject = Get-Content "./$($AlertFile.Name)" | ConvertFrom-Json
    [string]$dxcResourceType = $dxcAlertObject.dxcResourceType
    [Object[]]$dxcManagedResources = Invoke-Expression $dxcAlertObject.dxcManagedResources
    try { 
        [Object[]]$dxcAllResources = Invoke-Expression $dxcAlertObject.dxcAllResources
    } catch {
        Write-Error "The query for dxcAllResources in file $($AlertFile.Name) errored. A null value would result, causing extraneous deletions. Exiting script."
        Exit
        }
    
    [Object[]]$dxcCreateAlertRules = $dxcAlertObject.dxcAlertArray
 
    #CLEAN-UP ORPHANED ALERT RULES
    [Object[]]$dxcResourceDeployedAlertRules = Get-AzMetricAlertRuleV2 | Where-Object {$_.TargetResourceType -match $dxcResourceType } | Where-Object {$_.Name -like "DXC-*"} | Select-Object Name, ResourceGroup, Scopes
    
    ForEach ($dxcResourceDeployedAlertRule in $dxcResourceDeployedAlertRules)
        {
        [bool]$dxcResourceExists = $false
        ForEach ($dxcAllResource in $dxcAllResources)
            {
            if ($dxcAllResource.Id -in $dxcResourceDeployedAlertRule.Scopes) { $dxcResourceExists = $true; Break }
            }
        if (-not($dxcResourceExists)) 
            { 
            $Error.Clear()
            
            Remove-AzMetricAlertRuleV2 -ResourceGroupName $dxcResourceDeployedAlertRule.ResourceGroup -Name $dxcResourceDeployedAlertRule.Name
            if ($Error) {
            $ErrorActionPreference = "Continue"
            Write-Error "Failed to Delete Alert Rule: $($dxcResourceDeployedAlertRule.Name) . Probable reasons are: Locked parent ResourceGroup or 'Deny Assignment' permissions set against the FunctionApp Identity." }
            else { Write-Host "Removed Alert: " $($dxcResourceDeployedAlertRule.Name) }
            }
        }
         
    #CREATE MISSING ALERT RULES
    ForEach ($dxcManagedResource in $dxcManagedResources)
        {
        $dxcManagedLocation = (Get-AzResource -ResourceId $dxcManagedResource.Id).Location
        [Object[]]$dxcResourceDeployedAlertRules = Get-AzMetricAlertRuleV2 -ResourceGroupName $dxcManagedResource.ResourceGroupName | Where-Object {$_.Scopes -match $dxcManagedResource.Id } | Select-Object Name, ResourceGroup, Scopes
        
        ForEach ($dxcCreateAlertRule in $dxcCreateAlertRules)
            { 
            [bool]$dxcDeployAlerts = $true
  
            [string]$dxcAlertName = $dxcCreateAlertRule.AlertName -replace '<ResourceName>', $dxcManagedResource.Name -replace '/','-'
            
            if ($dxcResourceDeployedAlertRules.Count -gt 0 ) 
                {
                ForEach ($dxcResourceDeployedAlertRule in $dxcResourceDeployedAlertRules)
                    {
                    if ($dxcAlertName -eq $dxcResourceDeployedAlertRule.Name)
                        { 
                        $dxcDeployAlerts = $false; Break
                        }
                    }
                }   
            If ($dxcDeployAlerts)
                {
                [string]$dxcAlertDescription = "Version:" + $dxcCreateAlertRule.AlertVersion + " " + $dxcCreateAlertRule.AlertDescription
                
                #SET METRIC NAMESPACE
                [string]$dxcNameSpace = $dxcCreateAlertRule.MetricNameSpace
                if(!$dxcNameSpace) {  $dxcNameSpace = $dxcResourceType }
                
                #SET ALERT THRESHOLD.
                [double]$dxcAlertThreshold = $dxcCreateAlertRule.Threshold

                [Object[]]$dxcSubscriptionThreshold = $dxcCustomTableRows | Where-Object { ( $_.ResourceType -match "Subscription" ) -and ( $_.RowKey -match $dxcCreateAlertRule.AlertName ) }
                If ( $dxcSubscriptionThreshold.Count -eq 1 ) { [double]$dxcAlertThreshold = $dxcSubscriptionThreshold.Threshold }
                
                [Object[]]$dxcResourceGroupThreshold = $dxcCustomTableRows | Where-Object { ( $_.ResourceType -match "ResourceGroup" ) -and ( $_.PartitionKey -match $dxcManagedResource.ResourceGroupName ) -and ( $_.RowKey -match $dxcCreateAlertRule.AlertName ) }
                If ( $dxcResourceGroupThreshold.Count -eq 1 ) { [double]$dxcAlertThreshold = $dxcResourceGroupThreshold.Threshold }

                [Object[]]$dxcResourceThreshold = $dxcCustomTableRows | Where-Object { ( $_.ResourceType -match $dxcResourceType ) -and ( $_.PartitionKey -match $dxcManagedResource.Name ) -and ( $_.RowKey -match $dxcCreateAlertRule.AlertName ) }
                If ( $dxcResourceThreshold.Count -eq 1 ) { [double]$dxcAlertThreshold = $dxcResourceThreshold.Threshold }

                Write-Host ($dxcManagedResource.Name) ($dxcCreateAlertRule.AlertName) $dxcAlertThreshold
                 
                #SET ALERT CONDITIONS   
                if ($dxcCreateAlertRule.Dimension1Name -and $dxcCreateAlertRule.Dimension1Value)
                    {
                    $Dimension1 = New-AzMetricAlertRuleV2DimensionSelection -DimensionName $dxcCreateAlertRule.Dimension1Name -ValuesToInclude $dxcCreateAlertRule.Dimension1Value
                    if ($dxcCreateAlertRule.Dimension2Name -and $dxcCreateAlertRule.Dimension2Value)
                        {
                        $Dimension2 = New-AzMetricAlertRuleV2DimensionSelection -DimensionName $dxcCreateAlertRule.Dimension2Name -ValuesToInclude $dxcCreateAlertRule.Dimension2Value
                        $AlertCondition = New-AzMetricAlertRuleV2Criteria -MetricName $dxcCreateAlertRule.MetricName -MetricNameSpace $dxcNameSpace -DimensionSelection $Dimension1,$Dimension2 -TimeAggregation $dxcCreateAlertRule.TimeAggregation -Operator $dxcCreateAlertRule.Operator -Threshold $dxcAlertThreshold
                        }
                    else { $AlertCondition = New-AzMetricAlertRuleV2Criteria -MetricName $dxcCreateAlertRule.MetricName -MetricNameSpace $dxcNameSpace -DimensionSelection $Dimension1 -TimeAggregation $dxcCreateAlertRule.TimeAggregation -Operator $dxcCreateAlertRule.Operator -Threshold $dxcAlertThreshold }
                    }
                else { $AlertCondition = New-AzMetricAlertRuleV2Criteria -MetricName $dxcCreateAlertRule.MetricName -MetricNameSpace $dxcNameSpace -TimeAggregation $dxcCreateAlertRule.TimeAggregation -Operator $dxcCreateAlertRule.Operator -Threshold $dxcAlertThreshold }
                
                #DEPLOY METRIC ALERT
                $dxcAlertDeploymentStatus = Add-AzMetricAlertRuleV2 -Name $dxcAlertName -Description $dxcAlertDescription -ResourceGroupName $dxcManagedResource.ResourceGroupName -ActionGroup $dxcMetricAGId -Severity $dxcCreateAlertRule.Severity -TargetResourceScope $dxcManagedResource.Id -TargetResourceType $dxcResourceType -TargetResourceRegion $dxcManagedLocation -WindowSize $dxcCreateAlertRule.WindowSize -Frequency $dxcCreateAlertRule.Frequency -Condition $AlertCondition
                }  
            } 
        if ($dxcDeployAlerts)
            {
            If ($dxcAlertDeploymentStatus) { Write-Host 'Deployed Alerts for: ' $dxcManagedResource.Id }
            else {
            $ErrorActionPreference = "Continue"
            Write-Error "Failed to deploy Alert on: $($dxcManagedResource.Id) . Probable reasons are: Locked Resource or Locked parent ResourceGroup. 'Deny Assignment' permissions set against the FunctionApp Identity."}
            }
        }
    }
