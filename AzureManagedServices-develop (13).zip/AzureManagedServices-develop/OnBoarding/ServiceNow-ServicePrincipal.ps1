#Requires -PSEdition Core
#Requires -Version 7.0
#Requires -Module @{ ModuleName = 'Az'; ModuleVersion = '2.5.0' }
<#
=========================================================================================================================
Required - Powershell Core 7.x, Powershell AZ Module 2.5 or greater
=========================================================================================================================
Change Management
Version				Date			Author				      Description
=========================================================================================================================
1.1				08/04/2020		David Williams			Added Parameters
1.2				03/02/2021		Thomas Richards			Set Expiry Date of Secret
2.0             07/23/2021      Thomas Richards         Add support for Lighthouse deployment
=========================================================================================================================
.SYNOPSIS
    Creates a new AD Application, key and credential for ServiceNow if one doesn't already exist
    Creates a new Service Principal for ServiceNow
    Grants Contributor access for the Service Principal to a single subscription

.PRE-REQUISITES
    APPLICATION ADMINISTRATOR permissions in the AD TENANT where the Service Principal will be created
    OWNER privileges in the SUBSCRIPTION in order to grant Contributor access to the subscription

#>

Param(
    [Parameter(Mandatory=$true)] [String]$SubscriptionID,
    [Parameter(Mandatory=$false)] [String]$KeyVaultName,
    [Parameter(ParameterSetName="Lighthouse")] [switch]$Lighthouse   #Switch to run Lighthouse deployment. This will not store SPN Key in key vault.
    )

#=====================================================================================================================
# CHECK ENVIRONMENT FOR NECESSARY MODULES
#=====================================================================================================================
$ModuleURL = "https://dxcazuretoolsdev.blob.core.windows.net/installers/DXCPowershellModules/DXCEnvCheck.psm1"
$LocalModule = $PSScriptRoot + "/DXCEnvCheck.psm1"
(New-Object System.Net.WebClient).DownloadFile($ModuleURL, $LocalModule)
Import-Module $LocalModule -WA 0
Remove-Item -Path $LocalModule

Check-AzureCLIVersion -dxcAZRequiredVersion 2.0.74

#=====================================================================================================================
# LOGIN SECTION
#=====================================================================================================================
Write-Host "WARNING:     You need the following permissions to run this script." -ForegroundColor Yellow 
Write-Host "APPLICATION ADMINISTRATOR "  -ForegroundColor Red -NoNewLine
Write-Host "permissions in the AD TENANT where the Service Principal will be created." -ForegroundColor Blue 
Write-Host "OWNER "   -ForegroundColor Red -NoNewLine
Write-Host "privileges in the SUBSCRIPTION in order to grant Contributor access to the subscription." -ForegroundColor Blue

Write-Host "`nINFORMATION: Please login to Azure." -ForegroundColor Green
$error.Clear()
Connect-AzAccount

if ($error) { 
    Write-Host "`nWARNING:     Unable to connect to Azure. Check your internet connection and verify authentication details." -ForegroundColor Yellow
    exit 
}
Write-Host "`nINFORMATION: Connected to Azure with provided authentication." -ForegroundColor Green 

#=====================================================================================================================
# Get the Object ID of the current user so access can be granted to the Key Vault if needed
#=====================================================================================================================

Write-Host "INFORMATION: Getting the Object ID of the current user so temporary access can be granted to the Key Vault if needed.`n" -ForegroundColor Green

#Get objectID of logged in user
$usertype = (get-azcontext).Account.Type
if($usertype -eq 'ServicePrincipal'){
    #get object id of spn
    $currentUserObjectID = (Get-AzADServicePrincipal -ServicePrincipalName ((Get-AzContext).Account.id)).id
}
elseif($usertype -eq 'User'){
    #get object of user
    $currentUserObject = (get-azaduser -UserPrincipalName (Get-AzContext).account)
	#if no user found, possibly guest/b2b account access, try getting object ID via Azure CLI commands instead
	If(!($currentuserobject)){
        Write-Host "User not matched on login name, connecting to AZ Cli to object ID"
        try{
            #try to run az commands to clear any connections
            az account clear
            #prompt to log in 
            if(!($tenantid)){
                $tenantid = Read-Host -Prompt "`nWARNING: you must provide the Tenant ID for the Azure AD that manages this subscription."
            }
            $result = (az login --tenant $tenantid)
            # get current user's object ID for granting access to keyvault
            $currentUserObjectID = (az ad signed-in-user show | ConvertFrom-Json).objectid
            $currentUserObject = "Object found"
        }
        catch{
        #If az commands fail, let user know to install az cli
        Write-Host "Azure CLI tools are required to run this script with CSP/Guest Logins to be able to find user's Object IDs to grant them permissions to add Keyvault Secrets, please install Azure CLI and retry"
        Write-Host "You can install it by running the following command as admin"
        Write-Host "Invoke-WebRequest -Uri https://aka.ms/installazurecliwindows -OutFile .\AzureCLI.msi; Start-Process msiexec.exe -Wait -ArgumentList '/I AzureCLI.msi /quiet'"
        }		
    }
    If(!($currentUserObject)){
        Write-Host "User object ID/GUID not found, please check your account, Exiting..." -ForegroundColor Red
        Exit
    }
    If(!($currentUserObjectID)){
        #If ObjectID not already retrieved then set it now.
        $currentUserObjectID = $currentUserObject[0].id
    }
}


#=====================================================================================================================
# GATHER VARIABLES / SET THE CONTEXT / CHECK THE KEYVAULT EXISTS
#=====================================================================================================================

$Context = Set-AzContext $SubscriptionID
if ($error) { 
    Write-Host "WARNING:     Invalid Subscription ID. Please make sure you have sufficient access to this Azure Subscription." -ForegroundColor Yellow 
    Write-Host "             Run the Powershell Command: " -ForegroundColor Yellow -NoNewLine 
    Write-Host "Login-AzAccount " -NoNewLine
    Write-Host "and login with your authentication details." -ForegroundColor Yellow
    Write-Host "             If you get error, you have access issues with the subscription." -ForegroundColor Yellow
    exit 
}
Write-Host "`nINFORMATION: Connected to Azure Subscription " -NoNewline -ForegroundColor Green
Write-Host $SubscriptionID -NoNewline -ForegroundColor Red
Write-Host " with provided authentication." -ForegroundColor Green 

# Check the Key Vault exists
If (($Lighthouse -eq $False) -and ($KeyVaultName.Length -gt 0)){
    $kvexists = Get-AzKeyVault -VaultName $KeyVaultName
    if($null -eq $kvexists){ 
        Write-Host "WARNING: Invalid Key Vault Name, please check the Key Vault " -ForegroundColor Yellow -NoNewline
        Write-Host $KeyVaultName  -ForegroundColor Red  -NoNewline
        Write-Host " exists in the subscription "  -ForegroundColor Yellow  -NoNewline
        Write-Host $SubscriptionID  -ForegroundColor Red  -NoNewline
        Write-Host " and rerun the script."  -ForegroundColor Yellow
        exit 
    }
}
elseif (($Lighthouse -eq $False) -and ($KeyVaultName.Length -eq 0)){
    Write-Host "ERROR: Parameter 'KeyVaultName' is required for standard deployment. `nExiting..." -ForegroundColor Red
    exit
}

#=====================================================================================================================
# SERVICE PRINCIPLE CHECK & CREATION / ADDITION OF ROLE DEFINITION IN THE SUBSCRIPTION
#=====================================================================================================================
$TenantID = Get-AzContext
$TenantID = $TenantID.Subscription.TenantID
$ServiceNowAppID = "servicenowapp"  + $TenantID.Substring(0,4)

Write-Host "`nINFORMATION: There should only be one App registration per AZURE AD TENANT. " -ForegroundColor Green
Write-Host "If the App Registration already exists it will be given the required access to the subscription." -ForegroundColor Green
Write-Host "The name for the App Registration/Service Principal in this AD Tenant is " -NoNewline -ForegroundColor Green
Write-Host $ServiceNowAppID"." -ForegroundColor Red


# Check whether the App Registration Exists
$AppRegExists = Get-AzADServicePrincipal -DisplayName $ServiceNowAppID

if (!$AppRegExists) { 
    Write-Host "`nINFORMATION: App Registration $ServiceNowAppID doesn't exist, creating it now..." -ForegroundColor Green
    # Create the App registration and Generate the Key
        
    # Constants
    $appURL = "http://" + $ServiceNowAppID

    $appSuffix = $SubscriptionID.Substring(0,4)
    $appURL  = $appURL  + $appSuffix

    # Function to create AES Key Ref: https://gist.github.com/ctigeek/2a56648b923d198a6e60
    function Create-AesManagedObject($key, $IV) {
        $aesManaged = New-Object "System.Security.Cryptography.AesManaged"
        $aesManaged.Mode = [System.Security.Cryptography.CipherMode]::CBC
        $aesManaged.Padding = [System.Security.Cryptography.PaddingMode]::Zeros
        $aesManaged.BlockSize = 128
        $aesManaged.KeySize = 256
        if ($IV) {
            if ($IV.getType().Name -eq "String") {
                $aesManaged.IV = [System.Convert]::FromBase64String($IV)
            }
            else {
                $aesManaged.IV = $IV
            }
        }
        if ($key) {
            if ($key.getType().Name -eq "String") {
                $aesManaged.Key = [System.Convert]::FromBase64String($key)
            }
            else {
                $aesManaged.Key = $key
            }
        }
        $aesManaged
    }

    function Create-AesKey() {
        $aesManaged = Create-AesManagedObject 
        $aesManaged.GenerateKey()
        [System.Convert]::ToBase64String($aesManaged.Key)
    }

    #Create the 44-character key value
    $keyValue = Create-AesKey
    $sskeyValue = ConvertTo-SecureString $keyValue -AsPlainText -Force
    # Key start date
    $startDate = Get-Date
    # Key end date
    $endDate = (Get-Date).AddYears(1)

    # The Microsoft recommended method for creating a Service Principle authenticated by a PSADCredential is to first create the application without credentials, 
    # then use the cmdlet New-AzADAppCredential to create the credential and attach it to the App
    Write-Host "`nINFORMATION: Creating the new AD Application - $ServiceNowAppID" -ForegroundColor Green
    $app = New-AzADApplication -DisplayName $ServiceNowAppID -HomePage "http://localhost" -IdentifierUris $appURL
    if ($error) { 
        Write-Host "`nWARNING: Creation of the AD Application failed.  Check you have sufficient permissions in the AD Tenant."  -ForegroundColor Yellow
        exit 
    }
    Write-Host "`nINFORMATION: The AD Application was created successfully." -ForegroundColor Green 

    # Create Credential (PSADCredential) and add it to the App using the ApplicationId
    Write-Host "`nINFORMATION: Creating the new AD Application credential." -ForegroundColor Green
    $psadCredential = New-AzADAppCredential -StartDate $startDate -EndDate $endDate -ApplicationId $app.ApplicationId -Password $sskeyValue
    
    # Creating the Service Principal, this will assign the Contributor role by default and assign the scope as this subscription
    Write-Host "`nINFORMATION: Creating the Service Principal, this will assign the Contributor role by default and assign the scope as this subscription." -ForegroundColor Green
    $ApplicationID = $app.ApplicationId
    $sp = New-AzADServicePrincipal -ApplicationId $ApplicationID

    if ($error) { 
        Write-Host "`nWARNING:Creation of the Service Principal failed.  Check you have sufficient permissions in the AD Tenant."  -ForegroundColor Yellow
        exit 
    }
    Write-Host "`nINFORMATION: The Service Principal was created successfully." -ForegroundColor Green 

    if ($Lighthouse -eq $False){
        # Write the AD Application secret to the Key Vault
        # Add current context user to keyvault access policy temporarily
        Set-AzKeyVaultAccessPolicy -VaultName $KeyVaultName -ObjectId $currentUserObjectID -PermissionsToSecrets get, set, list
        Write-Host "`nINFORMATION: Added" (Get-AzContext).Account "to" $KeyVaultName "Access Policy Temporarily" -ForegroundColor Green           
 
        # Add the secret
        $SecretName = "servicenowappkey"
        Write-Host "`nINFORMATION: Adding the App registration key secret $SecretName to the Key Vault $KeyVaultName" -ForegroundColor Green
        $result = Set-AzKeyVaultSecret -VaultName $keyvaultname -Name $SecretName -SecretValue $sskeyValue
        $sskeyValue = Get-AzKeyVaultSecret -VaultName $keyvaultname -Name $SecretName

        Write-Host "`nINFORMATION: Do you want to remove the SPN's access to the Vault named" $KeyVaultName -ForegroundColor Green 
        $RemovePrivs = (Read-Host -Prompt "(Y/N)?").ToUpper()
        if($RemovePrivs -eq 'Y'){
            #Remove current context user from keyvault access policy
            Write-Host "`nINFORMATION: Removed" (Get-AzContext).Account "rights from" $KeyVaultName "Access Policy " -ForegroundColor Green           
            Remove-AzKeyVaultAccessPolicy -VaultName $keyvaultname -ObjectId $currentUserObjectID
        }
        else {
          Write-Host "`nINFORMATION: Left" (Get-AzContext).Account "temporary rights on" $KeyVaultName "Access Policy " -ForegroundColor Green          
        }
    }
    else{
        $SecretName = "servicenowappkey"
        Write-Host "INFORMATION: Skipping Key Vault secret creation." -ForegroundColor Green
        Write-Host "`n`nIMPORTANT: Service Principal key is: $keyValue " -Backgroundcolor Red
        Write-Host "IMPORTANT: This key needs to be manually saved in the DXC Key Vault under the name: $secretName " -Backgroundcolor Red
    }
}
Else {
    Write-Host "`nINFORMATION: The App Registration $ServiceNowAppID already exists, assigning Contributor permissions to existing App Registration ..." -ForegroundColor Green
    $app = Get-AzADApplication -DisplayName $ServiceNowAppID
    New-AzRoleAssignment -ApplicationId $app.ApplicationId -RoleDefinitionName Contributor
    if ($error) { 
        Write-Host "WARNING:The App Registration $ServiceNowAppID already has Contributor access to the subscription, script will now exit."  -ForegroundColor Red
        exit 
    }
    $ApplicationID = $app.ApplicationId

    if ($Lighthouse -eq $False){
        # Write the AD Application secret to the Key Vault
        # Add current context user to keyvault access policy temporarily
        Set-AzKeyVaultAccessPolicy -VaultName $KeyVaultName -ObjectId $currentUserObjectID -PermissionsToSecrets get, set, list
        Write-Host "`nINFORMATION: Added" (Get-AzContext).Account "to" $KeyVaultName "Access Policy Temporarily" -ForegroundColor Green           
 
        # Obtain the secret from the Key Vault
        $SecretName = "servicenowappkey"
        $sskeyValue = Get-AzKeyVaultSecret -VaultName $keyvaultname -Name $SecretName
        if($null -eq $sskeyValue){ 
            Write-Host "`nWARNING:The secret couldn't be retrieved from the Key Vault, " -NoNewline -ForegroundColor Red 
            Write-Host "the App Registration key may need to be regenerated in the portal and added to the Keyvault manually.  The secret name is $SecretName."  -ForegroundColor Red
        }

        Write-Host "`nINFORMATION: Do you want to remove the access to the Vault named" $KeyVaultName -ForegroundColor Yellow  
        $RemovePrivs = (Read-Host -Prompt "(Y/N)?").ToUpper()
        if($RemovePrivs -eq 'Y'){
            #Remove current context user from keyvault access policy
            Write-Host "`nINFORMATION: Removed" (Get-AzContext).Account "rights from" $KeyVaultName "Access Policy " -ForegroundColor Green           
            Remove-AzKeyVaultAccessPolicy -VaultName $keyvaultname -ObjectId $currentUserObjectID
        }
        else {
            Write-Host "`nINFORMATION: Left" (Get-AzContext).Account "temporary rights on" $KeyVaultName "Access Policy " -ForegroundColor Green          
        }
    }
    elseif($Lighthouse -eq $True){
        Write-Host "It is not possible to read a secret of an existing service principal from a Key Vault using Lighthouse. Please check the Key Vault in the portal for the secret '$secretName' "
    }
}

# Output the results for use in configuring the subscription in ServiceNow

Write-Host "`nIMPORTANT: You need to record the following information which is required to configure the subscription in ServiceNow. " -ForegroundColor Yellow 
Write-Host "AD Tenant ID: " -ForegroundColor Blue -NoNewline
Write-Host $TenantID -ForegroundColor Red
Write-Host "Application ID: " -ForegroundColor Blue -NoNewline
Write-Host $ApplicationID -ForegroundColor Red
Write-Host "Secret / Key: " -ForegroundColor Blue -NoNewline
Write-Host $keyValue -ForegroundColor Red
    
Pause
    
# Disconnect the Azure Account
Write-Host "`n`nINFORMATION: Disconnecting the Azure Account." -ForegroundColor Green 
Disconnect-AzAccount
Disconnect-AzAccount
Write-Host "`nINFORMATION: Disconnected the Azure Account." -ForegroundColor Green 
