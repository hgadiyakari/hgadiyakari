﻿# Deploy Audit Tag Deployment

This folder contains the json files and powershell that are used to Audit potentially managed resources within a subscription.
This will deploy 3 Audit Policies, all combined under 1 Initiative with a Subscription-level Assignment.

## Jira Story
https://jira.dxc.com/browse/AZR-20516

## Deployment

Step 1. Create Repository on local machine.

Step 2. run the script .\DeployDXCTagsAuditPolicy.ps1 -SubscriptionId <YourSubscriptionId>

## Members of this directory are:
* DeployDXCTagsAuditPolicy.ps1	    	Main script to deploy audit policy
* dxcTaggingInitiative.json	    		ARM template called by main script
* dxcAllResourceTagAudit.json			ARM template called by main script
* dxcManagedAudit.json		        	ARM template called by main script
* dxcVMOnlyTagAudit.json    			ARM template called by main script

## Authors
* Thomas Richards
