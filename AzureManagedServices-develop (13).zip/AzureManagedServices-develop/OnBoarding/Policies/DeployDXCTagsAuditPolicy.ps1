#Requires -Version 7.0
#Requires -PSEdition Core
#Requires -Module @{ ModuleName = 'Az'; ModuleVersion = '5.9.0' }
<#
=========================================================================================================================
© DXC Technology, 2021. All rights reserved
=========================================================================================================================
Required - Powershell Core 7.0+, Powershell AZ Module 5.9 or greater
=========================================================================================================================
AUTHOR:  Thomas Richards
DATE:    05/26/2021
Version: 1.0
=========================================================================================================================
Change History
=========================================================================================================================
VERSION     AUTHOR              DATE            CHANGES
1.1         Thomas Richards     06/16/2021      Added support for dxcBackup on CosmosDB. Added new audit policy called dxcBackupTagAudit.json
1.2         Thomas Richards     07/28/2021      Fixed bug where subsequent subscriptions failed deployment
=========================================================================================================================
.SYNOPSIS
    Deploys (or updates) DXC Tagging Schema Policies and Initiative. Removes deprecated policy associated with deprecated tag "DXC_AutoDeploy" if applicable.
.DESCRIPTION
    .PARAMETER  SubscriptionID
    Specifies the Subscription ID of Subscription where the Policies are to be created.
#>

Param
(
  [Parameter(Mandatory=$true)] [String]$subscriptionId
)

$ErrorActionPreference = "Stop"

#################### Login #######################

$dxcModuleList = "DXCUtilityFunctions.psm1"
foreach ($dxcModule in $dxcModuleList)
{
    [String]$dxcModuleURL = "https://dxcazuretoolsdev.blob.core.windows.net/installers/DXCPowershellModules/" + $dxcModule
    [String]$dxcLocalModule = $PSScriptRoot + "\" + $dxcModule
    (New-Object System.Net.WebClient).DownloadFile($dxcModuleURL, $dxcLocalModule)
    Import-Module $dxcLocalModule -WA 0
    Remove-Item -Path $dxcLocalModule
}

#Connect to Tenant
Utility-LoginAZ -dxcSubscriptionId $SubscriptionId
$subscriptionResId = '/subscriptions/' + $subscriptionId


########## Check/Remove deprecated Policy ############

$deprecatedPolicies = "DXCAuditVMDeployTag", "DXCManagedTag", "DXCAuditDeployTag"

Write-Host "Checking for deprecated policies" -ForegroundColor Green

foreach ($policyName in $deprecatedPolicies) {
  

$existingPolicy = Get-AzPolicyDefinition -Name $policyName -ErrorAction SilentlyContinue
if ($existingPolicy.Count -gt 0) { 
  Write-Host "Existing deprecated policy found: $policyName. Removing policy definition and associated policy assignment." -ForegroundColor Green
  Remove-AzPolicyAssignment -Name $policyName -Scope $subscriptionResId -Confirm
  Remove-AzPolicyDefinition -Name $policyName
  Write-Host "Removed successfully." -ForegroundColor Green
 }
 else {
   Write-Host "No deprecated policy named $policyName found in subscription. Continuing." -ForegroundColor Green
 }
}
Write-Host "Completed deprecated policy check. Continuing..."

############# Add/update new policies #############

$newPolicies = "dxcManagedAudit", "dxcAllResourceTagAudit", "dxcVMOnlyTagAudit", "dxcBackupTagAudit"
Write-Host "Polices: $newPolicies" -ForegroundColor DarkGreen
$metadata = '{"category":"Tags","version":"1.1"}'

#dxcManagedAudit Policy
Write-Host "Adding dxcManagedAudit policy..."
$dxcManagedAuditpolicy = $PSScriptRoot + '\dxcManagedAudit.json'
$presentcheck = Get-AzPolicyDefinition -Name "dxcManagedAudit" -EA SilentlyContinue
if ($presentcheck.Count -gt 0) {
  Write-Host "dxcManagedAudit Audit Policy already exists, moving to next policy." -Foreground Yellow
}
else {
  New-AzPolicyDefinition -Name "dxcManagedAudit" -DisplayName "dxcManagedAudit" -Description "This policy checks all Resource types for the DXC tag dxcManaged, and well as compliant values." -Policy $dxcManagedAuditpolicy -Metadata $metadata -SubscriptionId $subscriptionId -EA Stop
  Write-Host "dxcManagedAudit Audit Policy added, moving to next policy." -ForegroundColor Green
}

#dxcAllResourceTagAudit
Write-Host "Adding dxcAllResourceTagAudit policy..."
$dxcAllResourceTagAuditpolicy = $PSScriptRoot + '\dxcAllResourceTagAudit.json'
$presentcheck2 = Get-AzPolicyDefinition -Name "dxcAllResourceTagAudit" -EA SilentlyContinue
if ($presentcheck2.Count -gt 0 ) {
  Write-Host "dxcAllResourceTagAudit Audit Policy already exists, moving to next policy." -Foreground Yellow
}
else {
  New-AzPolicyDefinition -Name "dxcAllResourceTagAudit" -DisplayName "dxcAllResourceTagAudit" -Description "This policy checks all Resource types containing the tag 'dxcManaged: true' for the DXC tags dxcMonitored and dxcConfigurationCheck, and well as compliant values.." -Policy $dxcAllResourceTagAuditpolicy -Metadata $metadata -SubscriptionId $subscriptionId -EA Stop
  Write-Host "dxcAllResourceTagAudit Audit Policy added, moving to next policy." -ForegroundColor Green
}

#dxcVMOnlyTagAudit
Write-Host "Adding dxcVMOnlyTagAudit policy..."
$dxcVMOnlyTagAuditpolicy = $PSScriptRoot + '\dxcVMOnlyTagAudit.json'
$presentcheck3 = Get-AzPolicyDefinition -Name "dxcVMOnlyTagAudit" -EA SilentlyContinue
if ($presentcheck3.Count -gt 0) {
  Write-Host "dxcVMOnlyTagAudit Audit Policy already exists, moving to next policy." -Foreground Yellow
}
else {
  New-AzPolicyDefinition -Name "dxcVMOnlyTagAudit" -DisplayName "dxcVMOnlyTagAudit" -Description "This policy checks Virtual Machines for the DXC tags dxcBackup, dxcPatchGroup and dxcEPAgent, and well as compliant values." -Policy $dxcVMOnlyTagAuditpolicy -Metadata $metadata -SubscriptionId $subscriptionId -EA Stop
  Write-Host "dxcVMOnlyTagAudit Audit Policy added, moving to next policy." -ForegroundColor Green
}

#dxcBackupTagAudit
Write-Host "Adding dxcBackupTagAudit policy..."
$dxcBackupTagAuditpolicy = $PSScriptRoot + '\dxcBackupTagAudit.json'
$presentcheck4 = Get-AzPolicyDefinition -Name "dxcBackupTagAudit" -EA SilentlyContinue
if ($presentcheck4.Count -gt 0) {
  Write-Host "dxcBackupTagAudit Audit Policy already exists, moving to next policy." -Foreground Yellow
}
else {
  New-AzPolicyDefinition -Name "dxcBackupTagAudit" -DisplayName "dxcBackupTagAudit" -Description "This policy checks resource Types containing dxcManaged=true that support dxcBackup for the DXC tag dxcBackup, and well as compliant values. Currently this only contains CosmosDB and associated databases." -Policy $dxcBackupTagAuditpolicy -Metadata $metadata -SubscriptionId $subscriptionId -EA Stop
  Write-Host "dxcBackupTagAudit Audit Policy added, moving to next policy." -ForegroundColor Green
}

Write-Host "All policies checked. `n`nChecking for Initiative..." -ForegroundColor Green
############# Create Initiative if not present ###########

$InitiativeName = "DXCTaggingInitiative"
$InitiativeAssignmentName = "DXCTaggingInitiativeAssignment"
$PolicySetDefinition = $PSScriptRoot + '\' + "dxcTaggingInitiative.json"

$existingInitiative = Get-AzPolicySetDefinition -Name $InitiativeName -ErrorAction SilentlyContinue
if ($existingInitiative.Count -gt 0) {
Write-Host "Found Initiative $InitiativeName, checking Assignment." -ForegroundColor Green

  $existingInitiativeAssignment =  Get-AzPolicyAssignment -Name $InitiativeAssignmentName -Scope $subscriptionResId -ErrorAction SilentlyContinue
  if ($existingInitiativeAssignment.Count -gt 0) {
    Write-Host "Initiative Scope already added. Skipping..." -ForegroundColor Yellow
  }
  else {
    Write-Host "Adding Policy Set Assignment." -ForegroundColor Green
    $Initiativedefinition = Get-AzPolicySetDefinition -Name $InitiativeName
    New-AzPolicyAssignment -Name $InitiativeAssignmentName -Scope $subscriptionResId -PolicySetDefinition $Initiativedefinition -DisplayName "DXC Tagging Initiative Assignment"
  }
}
else {
  Write-Host "No Initiative Found. Creating Initiative $InitiativeName." -ForegroundColor Green

  #Get Initiative from folder.
  #Replace each occurence of <<YourSubscriptionId>> with you subscriptionID
  ((Get-Content -path $PolicySetDefinition -Raw) -replace '<<YourSubscriptionId>>',$subscriptionId) | Set-Content -Path $PolicySetDefinition

  #Run Command to deploy Initiative
  New-AzPolicySetDefinition -Name $InitiativeName -ErrorAction stop -SubscriptionId $subscriptionId -Metadata $metadata -Description "Audits compliance with DXC tagging schema" -DisplayName $InitiativeName -PolicyDefinition $PolicySetDefinition 
  Write-Host "Definition Added. Adding Policy Assignment" -ForegroundColor Green
  $Initiativedefinition = Get-AzPolicySetDefinition -Name $InitiativeName
  New-AzPolicyAssignment -Name $InitiativeAssignmentName -Scope $subscriptionResId -PolicySetDefinition $Initiativedefinition -DisplayName "DXC Tagging Initiative Assignment"
Write-Host "Assignment added"
#Reverts changes made to initiative file
((Get-Content -path $PolicySetDefinition -Raw) -replace $subscriptionId,'<<YourSubscriptionId>>') | Set-Content -Path $PolicySetDefinition
}

########################################################

Write-Host "Script Complete" -ForegroundColor Green
