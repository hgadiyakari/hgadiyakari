﻿# Onboarding Directory

This folder contains the all DXC Azure artifacts for onboarding a customer. See each unerlying folder Readme.md file for further details on each component.

## Supported
Alerting
KeyVault
Policies
PowerShellModules

## Jira Epic
N/A

## Deployment
For more information on ServiceNow-ServicePrincipal.ps1, please see:
Section 3.3.3.8 of Onboarding guide

## Members of this directory are:
* ServiceNow-ServicePrincipal.ps1	Creates a new AD Application, key and credential for ServiceNow if one doesn't already exist
									Creates a new Service Principal for ServiceNow
									Grants Contributor access for the Service Principal to a single subscription

## Authors
Azure Engineering
