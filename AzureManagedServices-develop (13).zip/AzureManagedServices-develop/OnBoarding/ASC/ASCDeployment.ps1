## This file configures resources required for ASC enablement. 
## This includes the registration of all required resource providers.
## Configures ASC to use the standard customer's LA workspace and adds the ASC Standard Tier to the LA workspace 
## It configures ASC for standard tier for Virtual Machines and Storage Accounts

##Install AZ.Security Modules if they are not already installed on the system executing the script
#Install-Module -Name AZ.Security -Force 
#Install-Module -Name Az.Accounts -Force  
#Install-Module -Name Az.Resources -Force  

#Create Variable for Subscription ID, LA Workspace, LA Workspace Resource Group and Region of LA Workspace

[CmdletBinding(SupportsShouldProcess=$true)]
Param(
    [Parameter(Mandatory=$true)] [String]$SubID,
    [Parameter(Mandatory=$true)] [String]$LAworkspace,
    [Parameter(Mandatory=$true)] [String]$RG,
    [Parameter(Mandatory=$true)] [String]$Region,
    [Parameter(Mandatory=$true)] [String]$TenantID
)

#Create subscription scope and create Workspace resource ID for setting ASC to use specificed LA workspace
$Scope = "/subscriptions/"+ $SubID 
$WorkspaceID = $Scope +"/resourcegroups/"+ $RG +"/providers/microsoft.operationalinsights/workspaces/"+ $LAworkspace

#Connect to Tenant
Connect-AzAccount -TenantId $TenantID
set-azcontext -subscriptionid $SubID

#Register RP for Security to subscription
Write-Host "Registering security resource providers" -ForegroundColor Green
Register-AzResourceProvider -ProviderNamespace 'Microsoft.Security'
Register-AzResourceProvider -ProviderNamespace 'Microsoft.PolicyInsights'

#Configure ASC to use custom LA workspace with set command below
Write-Host "Setting up LA Workspace" -ForegroundColor Green
Set-AzSecurityWorkspaceSetting -Name "default" -Scope $Scope -WorkspaceId  $WorkspaceID 

#Configure LA Workspace to ASC standard Tier and add Security Center Solution Plug-in to LA Workspace
Set-AzOperationalInsightsIntelligencePack -ResourceGroupName $RG -WorkspaceName $LAworkspace -IntelligencePackName "Security" -Enabled $True 

# Create relative path to ASC ARM template and parameter file to use for enabling ASC at the standard Tier
$ascpricingdeploy = $PSScriptRoot + ".\ascpricingdeploy.json" 
$ascparamstandard = $PSScriptRoot + ".\ascpricingstandard.parameter.json"

# Create relative path to ARM template for continous export of ASC data to LA workspace
$ascexportconfig = $PSScriptRoot + ".\ascexportconfig.json"

# Deployment to Configure ASC Standard Tier for VMs, WebApps, SQL and Storage Accounts
Write-Host "Deploying and configuring Azure Security Center" -ForegroundColor Green
New-AzDeployment -location $Region -TemplateFile $ascpricingdeploy -TemplateParameterFile $ascparamstandard  

# Deployment to Configure continous export of ASC alerts and reccomendations to LA workspace
New-AzResourceGroupDeployment -ResourceGroupName $RG -TemplateFile $ascexportconfig -resourceGroupLocation $Region -WorkspaceResourceID $WorkspaceID

Write-Host "Azure Security Center has been successfully deployed!" -ForegroundColor Green
