#This script will configure the standard default policy for ASC

[CmdletBinding(SupportsShouldProcess=$true)]
Param(
    [Parameter(Mandatory=$true)] [String]$SubID,
    [Parameter(Mandatory=$true)] [String]$TenID
)

#Connect AZ Subscription
Connect-AzAccount -TenantId $TenID

#Execute Retrievetoken.ps1 to cache current token value
function Get-AzCachedAccessToken()
{
    $ErrorActionPreference = 'Stop'
  
    if(-not (Get-Module Az.Accounts)) {
        Import-Module Az.Accounts
    }
    $azProfile = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile
    if(-not $azProfile.Accounts.Count) {
        Write-Error "Ensure you have logged in before calling this function."    
    }
  
    $currentAzureContext = Get-AzContext
    $profileClient = New-Object Microsoft.Azure.Commands.ResourceManager.Common.RMProfileClient($azProfile)
    Write-Debug ("Getting access token for tenant" + $currentAzureContext.Tenant.TenantId)
    $token = $profileClient.AcquireAccessToken($currentAzureContext.Tenant.TenantId)
    $token.AccessToken
}

#place token value in variable
$token= Get-AzCachedAccessToken

#convert token to bearer token and place in variable
$authHeader = @{
    'Content-Type'='application/json'
    'Authorization'='Bearer '+ $token
}

#place ASC Rest API call body in variable the relative path is not working so it has been commented out and literial path is being used until this issue is resolved
$request = Get-Content (Join-Path $PSScriptRoot -ChildPath "\azpolicyeffects.json")

#place URi to subscription and ASC Default Policy in variable
$SubASCPolicyURI = 'https://management.azure.com/subscriptions/'+ $SubID +'/providers/Microsoft.Authorization/policyAssignments/SecurityCenterBuiltIn?api-version=2018-05-01'

#execute Put API Call to modify ASC default policies
Invoke-RestMethod -Method Put -Uri $SubASCPolicyURI -Headers $authHeader -Body $request





