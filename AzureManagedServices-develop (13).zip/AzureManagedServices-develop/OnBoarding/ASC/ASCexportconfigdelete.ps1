#This script will delete the security automation job that exports ASC to Log analytics workspace

#Create Variable for Subscription ID, Tenant ID and Resource Group

[CmdletBinding(SupportsShouldProcess=$true)]
Param(
    [Parameter(Mandatory=$true)] [String]$SubID,
    [Parameter(Mandatory=$true)] [String]$TenID,
    [Parameter(Mandatory=$true)] [String]$RG
    

)

#Connect AZ Subscription
Connect-AzAccount -TenantId $TenID

#Execute Retrievetoken.ps1 to cache current token value
function Get-AzCachedAccessToken()
{
    $ErrorActionPreference = 'Stop'
  
    if(-not (Get-Module Az.Accounts)) {
        Import-Module Az.Accounts
    }
    $azProfile = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile
    if(-not $azProfile.Accounts.Count) {
        Write-Error "Ensure you have logged in before calling this function."    
    }
  
    $currentAzureContext = Get-AzContext
    $profileClient = New-Object Microsoft.Azure.Commands.ResourceManager.Common.RMProfileClient($azProfile)
    Write-Debug ("Getting access token for tenant" + $currentAzureContext.Tenant.TenantId)
    $token = $profileClient.AcquireAccessToken($currentAzureContext.Tenant.TenantId)
    $token.AccessToken
}

#place token value in variable
$token= Get-AzCachedAccessToken

#convert token to bearer token and place in variable
$authHeader = @{
    'Content-Type'='application/json'
    'Authorization'='Bearer '+ $token
}

$SubASCExportConfigDeleteURI = 'https://management.azure.com/subscriptions/'+ $SubID +'/resourceGroups/'+ $RG +'/providers/Microsoft.Security/automations/ExportToWorkspace?api-version=2019-01-01-preview'

#execute Delete API Call to Delete security automation job for exporting ASC to LA workspace
Invoke-RestMethod -Method Delete -Uri $SubASCExportConfigDeleteURI -Headers $authHeader 
