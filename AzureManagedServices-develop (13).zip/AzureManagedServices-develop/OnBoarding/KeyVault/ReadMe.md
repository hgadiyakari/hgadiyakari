# Key Vault Onboarding Resources

This folder contains Scripts and ARM templates used for OnBoarding new subscriptions to the Managed Services for Azure offering  
  
<IMG SRC="images/Azure KeyVault_COLOR.png" width="40" height="40" align=left>

## Jira Epic
N/A - on old Jira

## Template list and purposes

- DXC-KeyVaultDeploy.ps1 \- This Powershell script will deploy a new KeyVault to the DXC Resource Group or if an existing vault is found it will offer the option to add keys to upgrade from the previous to latest offering version.
- DXCMaintKV.json - This template creates the DXC KeyVault to store local admin usernames and passwords for VMs and also secrets like DomainJoinUser, DomainJoinPass and Symantec Keys and IDs

## Switches

- -NewDeployment -- Performs a new deployment and adds all values to the Key Vault
- -Upgrade -- Upgrades an existing Key Vault and only adds the Symantec / OMS Integration secrets

  
## Deployment Instructions

 Requirements:

- The latest offering code Master branch from Github to your deployment environment (pc or cloud shell)  
- If running locally
- PowerShell Core 7.0 or later
- Az modules 2.4 or later
- AZ CLI (If the user running the command is a guest user in Azure AD, e.g. @dxc.com account as a guest in a CSP AAD)
- There may only be one keyvault in the resource group, or the script will error and exit.
- Follow the instructions in each section below.

### KeyVault

 Collect details for the below Parameters before proceeding:

- Subscription ID -> The subscription to deploy the KeyVault to
- tenantid -> The tenant ID of your user
- clientid, clientkey -> if you are going to run the script using a Service Principal Name, you will need to supply those values
- MaintenanceResourceGroup -> Name of the DXC Resource Group  
- Domain Join User -> AD User with permission to join a computer to Active directory Domain.  
- Domain Join Pass -> Password of that User account.  
- MMSasToken -> The SAS Token to access the Make Managed Templates (Obtain this from Azure Engineering Team)
- MMSasQAtoken -> The SAS token for Make Managed QA Templates (Obtain this from Azure Engineering Team)
- SymantecCustomerId,SymantecDomainId,SymantecClientId,SymantecClientSecretKey,SymantecCustomerSecretKey -> These should all have been obtained and recorded during onboarding if CWP  is to be used (which should be true for all new 2.4.0 or later clients, unless they have an exception)
- Crowdstrike CID -> From the Crowdstrike Portal (OPTIONAL For Crowdstrike installs only!  Requires Exception from offering leaders)
- CS Uninstall Password -> Choose a password that must be supplied in order to uninstall CrowdStrike from Windows VM. Note it down for future use by support team. (OPTIONAL For Crowdstrike installs only!  Requires Exception from offering leaders)
- The ITSM Integration User Name - For previously onboarded subscriptions you may need to contact the original onboarding engineer/architect for this info.
- The ITSM Integration User Password - For previously onboarded subscriptions you may need to contact the original onboarding engineer/architect for this info.
  
Once the above details are collected, execute the script as follows:  

### For Symantec CWP installations

Run the following command from powershell for a new deployment

```powershell
.\DXC-KeyVaultDeploy.ps1 -SubscriptionID $SubscriptionID -NewDeployment
```  

You will then be prompted to provide values for the parameters above such as domain credentials, tokens and security keys and IDs

The KeyVault deployment should then complete

```powershell
.\DXC-KeyVaultDeploy.ps1 -SubscriptionID $SubscriptionID
Supply values for the following parameters:
MaintenanceResourceGroup: azr9008-rg
DomainUser: 1
DomainPassword: *
MMSasToken: 3
MMSasQAtoken: 4
SecurityAgent: 5
SymantecCustomerId: 6
SymantecDomainId: 7
SymantecClientId: 8
SymantecClientSecretKey: 9
SymantecCustomerSecretKey: 10
ITSMIntegrationUser: 11
ITSMIntegrationPass: 12
INFORMATION: Connected to Azure Subscription 41de9402-bdbf-4272-83b5-c47919900bd6 with provided authentication.

INFORMATION: The DXC Resource Group Azure Monitor Workspace was found

INFORMATION: Creating New KeyVault named DXC-Maint-KV-435440 in azr9008-rg

INFORMATION: Deployment of KeyVault named DXC-Maint-KV-435440 in azr9008-rg completed successfully
KV deployed Successfully
```

### For Accounts which have an exception to be able to use Crowdstrike until they are ready to migrate to Symantec CWP

Run the following command from powershell

```powershell
Write-Host "Enter Crowdstrike Uninstall Password: ";$csuninstallsecurepw = (ConvertTo-SecureString (Read-Host) -AsPlainText -Force)
.\DXC-KeyVaultDeploy.ps1 -SubscriptionID $SubscriptionID -CSUninstallPassword $csuninstallsecurepw -CrowdstrikeID <INSERTCROWDSTRIKEID> -NewDeployment  
```

### NOTE: You will still need to enter values for Symantec CWP keys/IDs as these should be set up in anticipation of customer migrating in future
