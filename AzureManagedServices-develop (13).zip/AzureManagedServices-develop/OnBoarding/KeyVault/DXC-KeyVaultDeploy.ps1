#Requires -PSEdition Core
#Requires -Version 7.0

<#
Requires -Modules @{ ModuleName="Az"; ModuleVersion="2.4.0" }
=========================================================================================================================
Required - Powershell Core 7.0+, Powershell AZ Module 2.4 or greater
=========================================================================================================================
AUTHOR:  Chris Neale
DATE:    02/12/2019
Version: 1.2
Documentation: https://github.dxc.com/cloud/AzureOffering_ServiceNow/blob/master/DXCMaintRG/ReadMe.md
=========================================================================================================================
.SYNOPSIS
    Deploys (or upgrades) a KeyVault in a Customer Subscription to store DXC Config Items as secrets
.DESCRIPTION
    .PARAMETER  SubscriptionID
    Specifies the Subscription ID of Subscription where the KeyVault is to be created.
    .PARAMETER  clientID
		Application ID for Authentication with Service Principle Name.
    .PARAMETER  clientKey
		Application Key for Authentication with Service Principle Name.
    .PARAMETER  tenantID
		Tenant ID for Authentication with Service Principle Name.
    .PARAMETER  MaintenanceResourceGroup
		Specifies the Resource Group to Deploy the Keyvault to, this should already contain the Azure Monitor Workspace.
    .PARAMETER  CSUninstallPassword
		Specifies the Password to secure Windows Crowdstrike installs from unauthorised uninstallation.
    .PARAMETER  DomainUser
		Specifies the Username to use when joining Windows VMs to the domain.
    .PARAMETER  DomainPassword
		Specifies the password for the Domain Join user.
    .PARAMETER  DomainPassword
		Specifies the Object ID for the user or SPN that can read/write Secrets to the Keyvault.
    .PARAMETER  CrowdstrikeID
		Specifies the Crowdstrike Customer ID.
    .PARAMETER  MMSasToken
		Specifies the token to gain access to the make managed templates storage account.
    .PARAMETER  MMSasQAToken
    Specifies the token to gain access to the make managed QA templates storage account.
    .PARAMETER  SymantecCustomerId
    Specifies the Symantec Customer ID
    .PARAMETER  SymantecDomainId
    Specifies the Symantec DomainId
    .PARAMETER  SymantecClientId
    Specifies the Symanetc Client ID
    .PARAMETER  SymantecClientSecretKey
    Specifies the Symantec Client Key
    .PARAMETER  SymantecCustomerSecretKey
    Specifies the Customer Key.
    .PARAMETER  ITSMIntegrationUser
    Specifies the OMS UserName.
    .PARAMETER  ITSMIntegrationPass
    Specifies the OMS User Password.
#>

[CmdletBinding(SupportsShouldProcess=$true)]
Param
    (
        [Parameter(Mandatory=$true)] [string]$SubscriptionID,
        [Parameter(Mandatory=$false)] [string]$clientid,
        [Parameter(Mandatory=$false)] [string]$clientkey,
        [Parameter(Mandatory=$true)] [string]$tenantid,
        [Parameter(Mandatory=$true)] [string]$MaintenanceResourceGroup,
        [Parameter(ParameterSetName="NewDeployment")][Switch]$NewDeployment,
        [Parameter(ParameterSetName="Upgrade")][Switch]$Upgrade,
        [Parameter(ParameterSetName="NewDeployment",Mandatory=$false)] [SecureString]$CSUninstallPassword,
        [Parameter(ParameterSetName="NewDeployment",Mandatory=$true)] [String]$DomainUser,
        [Parameter(ParameterSetName="NewDeployment",Mandatory=$true)] [SecureString]$DomainPassword,
        [Parameter(ParameterSetName="NewDeployment",Mandatory=$false)] [string]$CrowdstrikeID,
        [Parameter(ParameterSetName="NewDeployment",Mandatory=$true)] [String]$MMSasToken,
        [Parameter(ParameterSetName="NewDeployment",Mandatory=$true)] [String]$MMSasQAtoken,
        [Parameter(ParameterSetName="Upgrade",Mandatory=$true)][Parameter(ParameterSetName="NewDeployment",Mandatory=$true)] [String]$SymantecCustomerId,
        [Parameter(ParameterSetName="Upgrade",Mandatory=$true)][Parameter(ParameterSetName="NewDeployment",Mandatory=$true)] [String]$SymantecDomainId,
        [Parameter(ParameterSetName="Upgrade",Mandatory=$true)][Parameter(ParameterSetName="NewDeployment",Mandatory=$true)] [String]$SymantecClientId,
        [Parameter(ParameterSetName="Upgrade",Mandatory=$true)][Parameter(ParameterSetName="NewDeployment",Mandatory=$true)] [String]$SymantecClientSecretKey,
        [Parameter(ParameterSetName="Upgrade",Mandatory=$true)][Parameter(ParameterSetName="NewDeployment",Mandatory=$true)] [String]$SymantecCustomerSecretKey,
        [Parameter(ParameterSetName="Upgrade",Mandatory=$true)][Parameter(ParameterSetName="NewDeployment",Mandatory=$true)] [String]$ITSMIntegrationUser,
        [Parameter(ParameterSetName="Upgrade",Mandatory=$true)][Parameter(ParameterSetName="NewDeployment",Mandatory=$true)] [String]$ITSMIntegrationPass
      )


#=====================================================================================================================
# CHECK ENVIRONMENT FOR NECESSARY MODULES
#=====================================================================================================================
$ModuleURL = "https://dxcazuretoolsdev.blob.core.windows.net/installers/DXCPowershellModules/DXCEnvCheck.psm1"
$LocalModule = $PSScriptRoot + "/DXCEnvCheck.psm1"
(New-Object System.Net.WebClient).DownloadFile($ModuleURL, $LocalModule)
Import-Module $LocalModule -WA 0
Remove-Item -Path $LocalModule

#=====================================================================================================================
# LOGIN SECTION
#=====================================================================================================================
$error.Clear()
# If SPN Details provided, Login with the details.
If ($clientid -and $clientkey -and $tenantid){ 
  # If SPN Details provided, Login with the details.
  $passwd = ConvertTo-SecureString $clientkey -AsPlainText -Force
  $pscredential = New-Object System.Management.Automation.PSCredential($clientid, $passwd)
  Connect-AzAccount -ServicePrincipal -Credential $pscredential -TenantId $tenantid   1>$null 2>$null 3>$null
  if ($error){
    Write-Host "`nERROR: Unable to connect to Azure. Check your Service Principal variables to ensure they are correct and valid." -ForegroundColor Red
    exit
  }
  else{
    Write-Host "`nINFORMATION: Connected to Azure with submitted Service Principal." -ForegroundColor Green
  }
}
Elseif ( (((Get-AzContext).Subscription.id) -ne $SubscriptionID) -or ((get-azcontext).type -eq 'ManagedService') ){
  Write-Host "`nINFORMATION: Please login to Azure Resource Manager." -ForegroundColor Green
  Connect-AzAccount

  if ($error) 
      { 
      Write-Host "WARNING: Unable to connect to Azure. Check your internet connection and verify authentication details." -ForegroundColor Yellow
      Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
      exit 
      $error.Clear()
      }
  Write-Host "INFORMATION: Connected to Azure with provided authentication." -ForegroundColor Green 
}
#Set the Context to the speicified subscription
Set-AzContext -SubscriptionId $SubscriptionID -EA SilentlyContinue -WA SilentlyContinue >$null
if ($error) 
{ 
Write-Host "WARNING: Invalid Subscription ID. Please make sure you have proper access to this Azure Subscription." -ForegroundColor Yellow 
exit 
}
Write-Host "INFORMATION: Connected to Azure Subscription " -NoNewline -ForegroundColor Green
Write-Host $SubscriptionID -NoNewline
Write-Host " with provided authentication." -ForegroundColor Green 

#Check for ResourceGroup
$rgexists = get-azresourcegroup -Name $MaintenanceResourceGroup -ea 0
if($null -eq $rgexists){
  Write-Host "`nERROR: The DXC Resource Group is not present, exiting" -ForegroundColor Red
  exit
}
#Check for Workspace
$wsexists = Get-AzOperationalInsightsWorkspace -ResourceGroupName $MaintenanceResourceGroup -ea 0
if($null -eq $wsexists){
  Write-Host "`nERROR: The DXC Workspace is not present, exiting" -ForegroundColor Red
  exit
}elseif($wsexists.count -gt 1){
  Write-Host "`nERROR: The DXC Resource Group contains more than one Azure Monitor Workspace, this is not supported, exiting" -ForegroundColor Red
  exit
}elseif($wsexists.count -eq 1){
  Write-Host "`nINFORMATION: The DXC Resource Group Azure Monitor Workspace was found" -ForegroundColor Green
}
#Get objectID of logged in user
$usertype = (get-azcontext).Account.Type
if($usertype -eq 'ServicePrincipal'){
  #get object id of spn
  $currentUserObjectID = (Get-AzADServicePrincipal -ServicePrincipalName ((Get-AzContext).Account.id)).id
}elseif($usertype -eq 'User'){
  #get object of user
  $currentUserObject = (get-azaduser -UserPrincipalName (Get-AzContext).account)
	#if no user found, possibly guest/b2b account access, try getting object ID via Azure CLI commands instead
	If(!($currentuserobject)){
    Write-Host "User not matched on login name, connecting to AZ Cli to object ID"
    try{
      #try to run az commands to clear any connections
      az account clear
      #prompt to log in 
      if(!($tenantid)){
        $tenantid = Read-Host -Prompt "`nWARNING: you must provide the Tenant ID for the Azure AD that manages this subscription "
      }
      $result = (az login --tenant $tenantid)
      # get current user's object ID for granting access to keyvault
      $currentUserObjectID = (az ad signed-in-user show | ConvertFrom-Json).objectid
      $currentUserObject = "Object found"
    }
    catch{
      #If az commands fail, let user know to install az cli
      Write-Host "Azure CLI tools are required to run this script with CSP/Guest Logins to be able to find user's Object IDs to grant them permissions to add Keyvault Secrets, please install Azure CLI and retry"
      Write-Host "You can install it by running the following command as admin"
      Write-Host "Invoke-WebRequest -Uri https://aka.ms/installazurecliwindows -OutFile .\AzureCLI.msi; Start-Process msiexec.exe -Wait -ArgumentList '/I AzureCLI.msi /quiet'"
    }
		
  }
  If(!($currentUserObject)){
    Write-Host "User object ID/GUID not found, please check your account, Exiting..."
    Exit
  }
  If(!($currentUserObjectID))
  {
    #If ObjectID not already retrieved then set it now.
    $currentUserObjectID = $currentUserObject[0].id
  }
}

#=====================================================================================================================
# VARIABLES SECTION
#=====================================================================================================================
$DXCRandomNo = Get-Random -Maximum 1000000
$KeyVaultName = "DXC-Maint-KV-" + $DXCRandomNo
$WorkspaceName = (Get-AzOperationalInsightsWorkspace -ResourceGroupName $MaintenanceResourceGroup).name 
$WorkspaceID = (Get-AzOperationalInsightsWorkspace -Name $WorkspaceName -ResourceGroupName $MaintenanceResourceGroup).CustomerId.Guid
$WorkspaceKey = (Get-AzOperationalInsightsWorkspaceSharedKey -Name $WorkspaceName -ResourceGroupName $MaintenanceResourceGroup -WarningAction 0).PrimarySharedKey
$WSKeySecure = ConvertTo-SecureString $WorkspaceKey -AsPlainText -Force
$SymantecClientSecretKeysecure = ConvertTo-SecureString $SymantecClientSecretKey -AsPlainText -Force
$SymantecCustomerSecretKeySecure = ConvertTo-SecureString $SymantecCustomerSecretKey -AsPlainText -Force
$SymantecCustomerIdSecure = ConvertTo-SecureString $SymantecCustomerId -AsPlainText -Force
$SymantecDomainIdSecure = ConvertTo-SecureString $SymantecDomainId -AsPlainText -Force
$SymantecClientIdSecure = ConvertTo-SecureString $SymantecClientId -AsPlainText -Force
$SecurityAgentUpgradeSecure = ConvertTo-SecureString 'crowdstrike' -AsPlainText -Force
$ITSMIntegrationUserSecure = ConvertTo-SecureString $ITSMIntegrationUser -AsPlainText -Force
$ITSMIntegrationPassSecure = ConvertTo-SecureString $ITSMIntegrationPass -AsPlainText -Force

If($NewDeployment){
  $MMSASTokenSecure = ConvertTo-SecureString $MMSasToken -AsPlainText -Force
  $MMSASQATokenSecure = ConvertTo-SecureString $MMSasQAtoken -AsPlainText -Force
}

#===================
# Validating Azure Environment
#===================
$KeyVaults = (Get-AzKeyVault -ResourceGroupName $MaintenanceResourceGroup)
$TotalKeyVaults = $KeyVaults.count
if($TotalKeyVaults -gt 1){
  Write-Host "`nERROR: There are multiple KeyVaults in the DXC Resource Group, this configuration is not supported, exiting" -ForegroundColor Red
  Exit
}elseif ($TotalKeyVaults -eq 1) {
  $KeyVaultName = $KeyVaults.VaultName
  Write-Host "`nWARNING: There is an existing KeyVault in the DXC Resource Group called" $KeyVaultName -ForegroundColor Yellow  
  Write-Host "`nINFORMATION: Confirm you want to upgrade the Vault named" $KeyVaultName -ForegroundColor Green  
  $UpgradeChoice = (Read-Host -Prompt "(Y/N)?").ToUpper()
  if($UpgradeChoice -eq 'Y'){
    Write-Host "`nINFORMATION: Upgrading Existing KeyVault named" $KeyVaults.VaultName "in" $MaintenanceResourceGroup -ForegroundColor Green      
  }else{
    Write-Host "`nWARNING: Upgrade cancelled at user request, exiting" $KeyVaultName -ForegroundColor Yellow  
    Exit  
  }
}


####################################
#Main Deployment/Upgrade of KeyVault
####################################
if($TotalKeyVaults -eq 0){
  ##################################
  #Check for attempt to upgrade non-existent keyvault
  ##################################
  if($Upgrade)
  {
  	Write-Host "`nERROR: There is no KeyVault to upgrade in the DXC Resource Group, this configuration is not supported, exiting" -ForegroundColor Red
  	Exit
  }
  
  #Check if CS values are null as we're doing CWP deployment.  If so set the values to blank and securityagent to symantec
  if(($null -eq $CrowdstrikeID ) -or ($CrowdstrikeID -eq '')){
    $SecurityAgent='symantec'
    $CSUninstallPassword= ConvertTo-SecureString ' ' -AsPlainText -Force
    $CrowdstrikeID="NULL"
  }
  else {
    $SecurityAgent='crowdstrike'
  }

  Write-Host "`nINFORMATION: Creating New KeyVault named" $KeyVaultName "in" $MaintenanceResourceGroup -ForegroundColor Green  
  ####################################
  #Perform fresh deployment
  ####################################
  $rgdeployment = New-AzResourceGroupDeployment -ResourceGroupName $MaintenanceResourceGroup `
           -TemplateFile ".\DXCMaintKV.json" `
           -vaults_DXC_Maint_KV_name $KeyVaultName -CSUninstallSecret $CSUninstallPassword `
           -DomainJoinUser $DomainUser -DomainJoinPass $DomainPassword `
	   -tenantId $tenantID `
           -AccessPolicyObjectID $currentUserObjectID -LogAnalyticsWorkspaceName $WorkspaceName `
           -LogAnalyticsWorkspaceId $WorkspaceID -LogAnalyticsWorkspaceKey $WSKeySecure `
           -CrowdstrikeCID $CrowdstrikeID  `
           -MakeManagedSasToken $MMSASTokenSecure -MakeManagedSasTokenqa $MMSASQATokenSecure `
           -SymantecCustomerId $SymantecCustomerId -SymantecDomainId $SymantecDomainId `
           -SymantecClientId $SymantecClientId -SymantecClientSecretKey $SymantecClientSecretKeysecure `
           -SymantecCustomerSecretKey $SymantecCustomerSecretKeySecure -SecurityAgent $SecurityAgent -ITSMIntegrationUser $ITSMIntegrationUserSecure -ITSMIntegrationPass $ITSMIntegrationPassSecure
           
  if($rgdeployment.ProvisioningState -eq 'Succeeded'){
    Write-Host "`nINFORMATION: Deployment of KeyVault named" $KeyVaultName "in" $MaintenanceResourceGroup "completed successfully" -ForegroundColor Green           
  } else {
    Write-Host "`nERROR: Deployment failed with status" $rgdeployment.ProvisioningState -ForegroundColor Red
  }
}elseif ($TotalKeyVaults -eq 1) {
  ####################################
  #Perform Upgrade to 2.4.0 from 2.3.9
  ####################################  

  #add current context user to keyvault access policy temporarily
  Set-AzKeyVaultAccessPolicy -VaultName $KeyVaultName -ObjectId $currentUserObjectID -PermissionsToSecrets get, set, list
  Write-Host "`nINFORMATION: Added" (Get-AzContext).Account "to" $KeyVaultName "Access Policy Temporarily" -ForegroundColor Green           
 
  #Add Keys to upgrade to 2.4.0
  Write-Host "`nINFORMATION: Adding Keys for Relase v2.4.0" (Get-AzContext).Account "to" $KeyVaultName  -ForegroundColor Green           
  $numSecretsBeforeRun = (Get-AzKeyVaultSecret -VaultName $keyvaultname).count
  $result = Set-AzKeyVaultSecret -VaultName $keyvaultname -Name SymantecCustomerId -SecretValue $SymantecCustomerIdSecure
  $result = Set-AzKeyVaultSecret -VaultName $keyvaultname -Name SymantecDomainId -SecretValue $SymantecDomainIdSecure
  $result = Set-AzKeyVaultSecret -VaultName $keyvaultname -Name SymantecClientId -SecretValue $SymantecClientIdSecure
  $result = Set-AzKeyVaultSecret -VaultName $keyvaultname -Name SymantecClientSecretKey -SecretValue $SymantecClientSecretKeysecure
  $result = Set-AzKeyVaultSecret -VaultName $keyvaultname -Name SymantecCustomerSecretKey -SecretValue $SymantecCustomerSecretKeySecure
  $result = Set-AzKeyVaultSecret -VaultName $keyvaultname -Name SecurityAgent $SecurityAgentUpgradeSecure
  $result = Set-AzKeyVaultSecret -VaultName $keyvaultname -Name ITSMIntegrationUser -SecretValue $ITSMIntegrationUserSecure
  $result = Set-AzKeyVaultSecret -VaultName $keyvaultname -Name ITSMIntegrationPass -SecretValue $ITSMIntegrationPassSecure

  $numSecretsAfterRun = (Get-AzKeyVaultSecret -VaultName $keyvaultname).count
  if(($numSecretsAfterRun - $numSecretsBeforeRun) -eq 8){
    Write-Host "`nINFORMATION: Required Secrets added" -ForegroundColor Green           
  }else {
    Write-Host ($numSecretsAfterRun - $numSecretsbeforeRun) "`n secrets added"
  }
  Write-Host "`nINFORMATION: Do you want to remove the SPN's access to the Vault named" $KeyVaultName -ForegroundColor Yellow  
  $RemovePrivs = (Read-Host -Prompt "(Y/N)?").ToUpper()
  if($RemovePrivs -eq 'Y'){
    #Remove current context user from keyvault access policy
    Write-Host "`nINFORMATION: Removed" (Get-AzContext).Account "temporary rights from" $KeyVaultName "Access Policy " -ForegroundColor Green           
    Remove-AzKeyVaultAccessPolicy -VaultName $keyvaultname -ObjectId $currentUserObjectID
  }else {
    Write-Host "`nINFORMATION: Left" (Get-AzContext).Account "temporary rights on" $KeyVaultName "Access Policy " -ForegroundColor Green          
  }
}
