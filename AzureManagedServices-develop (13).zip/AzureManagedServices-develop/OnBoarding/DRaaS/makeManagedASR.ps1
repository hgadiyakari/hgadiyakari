<#=======================================================================================================================
Required - Powershell Version 5.1, Powershell Azure module 5.0.0
=========================================================================================================================
AUTHOR:  Joczabeth Mu�oz 
DATE:    20/04/2021
Version: 7.0
Documentation: 
=========================================================================================================================
.SYNOPSIS
    Powershell script to configure Site Recovery to send logs to Log Analytics.
.DESCRIPTION
    .PARAMETER  dxcSubscriptionID
		Specifies the Subscription ID of Susbcription hosting the Log Analytics Workspace.
    .PARAMETER  dxcLogAnalyticsWorkspaceName
		Specifies the name Log Analytics Workspace used for connecting to DXC ServiceNow instance.
    .PARAMETER asrRecoveryVaultName
        Specifies the name of Recovery Vault used for the Azure Site Recovery Solution.
    .PARAMETER asrDiagnosticSettingName
        Specifies the name of the diagnostic setting configured into the ASR Recovery Vault
    .OPTIONAL PARAMETER  dxcAppID
		Application ID for Authentication with Service Principal Name.
    .OPTIONAL PARAMETER  dxcAppKey
		Application Key for Authentication with Service Principal Name.
    .OPTIONAL PARAMETER  dxcTenantID
		Tenant ID for Authentication with Service Principal Name.
	.OPTIONAL PARAMETER dxcManaged = "true"
		This will set the tag dxcManaged to the desired value. True is assumed.
	.OPTIONAL PARAMETER dxcMonitored = "true"
		This will set the tag dxcMonitored to the desired value and determing if OMS diagnostics are activated. True is assumed.

	Example execution
	.\makeManagedASR.ps1 -dxcSubscriptionID b47b134f-d1e7-4f79-8a4c-043a355acf6d -dxcLogAnalyticsWorkspaceName DXC-G2EA-b47b-loganalyticsWorkspace -asrRecoveryVaultName azr-21806 -asrDiagnosticSettingName azr21806diag
=======================================================================================================================#>

[CmdletBinding(SupportsShouldProcess=$true)]
Param
(
    [Parameter(Mandatory=$true)]  [String]$dxcSubscriptionID,
    [Parameter(Mandatory=$true)]  [String]$dxcLogAnalyticsWorkspaceName,
    [Parameter(Mandatory=$true)]  [String]$asrRecoveryVaultName,
    [Parameter(Mandatory=$true)]  [String]$asrDiagnosticSettingName,
    [Parameter(Mandatory=$false)] [String]$dxcAppID,
    [Parameter(Mandatory=$false)] [String]$dxcAppKey,
    [Parameter(Mandatory=$false)] [String]$dxcTenantID,
	[Parameter(Mandatory = $false)] [ValidateSet("true","false")] [String]$dxcManaged = "true",
    [Parameter(Mandatory = $false)] [ValidateSet("true","false")] [String]$dxcMonitored = "true"
)

#========================================================================================================================
# IMPORT CUSTOM MODULES AND CHECK POWERSHELL ENVIRONMENT
#========================================================================================================================
$dxcModuleList = "DXCEnvCheck.psm1", "DXCUtilityFunctions.psm1"

foreach ($dxcModule in $dxcModuleList)
{
    [String]$dxcModuleURL = "https://dxcazuretoolsdev.blob.core.windows.net/installers/DXCPowershellModules/" + $dxcModule
    [String]$dxcLocalModule = $PSScriptRoot + "\" + $dxcModule
    (New-Object System.Net.WebClient).DownloadFile($dxcModuleURL, $dxcLocalModule)
    Import-Module $dxcLocalModule -WA 0
    #Remove-Item -Path $dxcLocalModule
}
Check-PSVersion -dxcPSVersion 7.0
Check-AzModuleVersion -dxcAzModuleVersion 2.5.0

#========================================================================================================================
# MAIN BODY OF THE SCRIPT
#========================================================================================================================

#Login to Azure
if ($dxcAppKey) {
	Utility-LoginAZSpn -TenantId $dxcTenantID -SpnKey $dxcAppKey -ClientId $dxcAppID -SubscriptionId $dxcSubscriptionID
}
else {
	Utility-LoginAZ -dxcSubscriptionId $dxcSubscriptionID
    #Connect-AzAccount
    Set-AzContext -SubscriptionId $dxcSubscriptionID
}

#Collect Maintenance ResourceGroup and OMS Workspace Details.
if ($dxcMonitored -eq "true"){
	$dxcObjWorkspace = Get-AzOperationalInsightsWorkspace | Where-Object {$_.Name -Match $dxcLogAnalyticsWorkspaceName}
	If ($dxcObjWorkspace){
		[String]$dxcLogAnalyticsWorkspaceName = $dxcObjWorkspace.Name
	    [String]$dxcResourceGroup = $dxcObjWorkspace.ResourceGroupName
		[String]$dxcWorkspaceRegion = (($dxcObjWorkspace.location).ToLower()) -replace '\s',''
	    $dxcWorkspaceId = $dxcObjWorkspace.ResourceId
    
		Utility-DisplayInfo -dxcstr1 "INFORMATION: Loganalytics Workspace named" -dxcstr2 $dxcLogAnalyticsWorkspaceName -dxcstr3 "located under ResourceGroup" -dxcstr4 $dxcResourceGroup
	}
	else{
		Write-Host "WARNING:     Loganalytics Workspace not found. Please enter correct workspace name while running the script." -ForegroundColor Yellow
		Get-Variable -Name dxc* | Remove-Variable -EA 0 -WA 0
	    Read-Host "`nPress 'ENTER'to exit the script........"
		exit
	}
}

#Collect Recovery Vauld ID and RG #
$asrRecoveryVaultRG = (Get-AzRecoveryServicesVault -name $asrRecoveryVaultName).ResourceGroupName
$asrRecoveryVaultID = (Get-AzRecoveryServicesVault -name $asrRecoveryVaultName).ID
If ($asrRecoveryVaultID){
    Write-Host "INFORMATION: ASR Recovery Vault ID collected" -ForegroundColor Green
}
else {
    Write-Host "WARNING: ASR Recovery Vault ID not found. Please enter correct workspace name while running the scrip" -ForegroundColor Yellow
    Get-Variable -Name asr* | Remove-Variable -EA 0 -WA 0
    Read-Host "`nPress 'ENTER'to exit the script........"
    exit
}

#Send Site Recovery logs to Log Analytics if monitoring is desired. Turn off if not.####
$error.Clear() 
Write-Host "INFORMATION: Configuring Diagnostic Settings ... " -ForegroundColor Green
if ($dxcMonitored -eq "true"){
	Set-AzDiagnosticSetting -ResourceId $asrRecoveryVaultID -WorkspaceId $dxcWorkspaceID -Enabled $true -name $asrDiagnosticSettingName -category AzureBackupReport,CoreAzureBackup,AddonAzureBackupJobs,AddonAzureBackupAlerts,AddonAzureBackupPolicy,AddonAzureBackupStorage,AddonAzureBackupProtectedInstance,azuresiterecoveryjobs,AzureSiteRecoveryEvents,AzureSiteRecoveryReplicatedItems,AzureSiteRecoveryReplicationStats,AzureSiteRecoveryRecoveryPoints,AzureSiteRecoveryReplicationDataUploadRate,AzureSiteRecoveryProtectedDiskDataChurn -ErrorAction SilentlyContinue | Out-Null
	if ($error){
		Write-Host "*** ERROR: Diagnostic Settings deployment failed. For detailed error message, please check deployment error in the Resource Group from Azure Portal ***" -ForegroundColor Red
	}
	else{
		Write-Host "INFORMATION: Diagnostic Settings configued succesfully under Recovery Service Vault :" $asrRecoveryVaultName -ForegroundColor Green
	}
}
else{
	Remove-AzDiagnosticSetting -ResourceId $asrRecoveryVaultID
	if ($error){
		Write-Host "*** ERROR: Disabling Diagnostic Settings failed. For detailed error message, please check deployment error in the Resource Group from Azure Portal ***" -ForegroundColor Red
	}
	else{
		Write-Host "INFORMATION: Diagnostic Settings disabled successfully under Recovery Service Vault :" $asrRecoveryVaultName -ForegroundColor Green
	}
}

#Apply DXC Tags Schema
$error.Clear()
#Create date variable but do not set tag yet.
$dxcConfigurationCheck = Get-Date -Format "yyyyMMddTHHmmssZ" -asUTC
Write-Host "INFORMATION: Adding DXC Tags  ... " -ForegroundColor Green
$tags += @{dxcManaged="$dxcManaged";dxcMonitored="$dxcMonitored";dxcConfigurationCheck="$dxcConfigurationCheck"}
Update-AzTag -ResourceId $asrRecoveryVaultID -Tag $tags -Operation Merge -ErrorAction SilentlyContinue
if ($error){
    Write-Host "*** ERROR: DXC Tags deployment failed. For detailed error message, please check deployment error in the Resource Group from Azure Portal ***" -ForegroundColor Red
}
else{
    Write-Host "INFORMATION: DXC Tags applied succesfully under Recovery Service Vault :" $asrRecoveryVaultName -ForegroundColor Green
}
    
Write-Host "`n####################### END OF SCRIPT EXECUTION ###################################"