#Requires -PSEdition Core

<#
.SYNOPSIS
Deploys Azure Site Recovery

.DESCRIPTION
This powershell deploys and configures ASR within an Azure subscription and sets up replication on inputted VMs

PARAMETERS

.PARAMETER Subscription         
(Mandatory) The subscription ID this session is to be running under.  If 
not entered, then the default subscription for the type of login used will be used.
This does not apply if the user is prompted for a login.          

.PARAMETER ASRVaultResourceGroup
(Mandatory) name for the ASR resource group where the vault will reside. If the inputted ASRVaultResourceGroup doesn't exist, one will be created

.PARAMETER ASRVaultName
(Mandatory) name for the ASR vault to deploy. If the inputted ASRVaultName doesn't exist, one will be created

.PARAMETER PrimaryRegion
(Mandatory) Primary region for ASR

.PARAMETER RecoveryRegion
(Mandatory) Recovery region for ASR

.PARAMETER PolicyName
(Optional) Name for replication policy. If the inputted policy doesn't exist, one will be created

.PARAMETER LogStorageAccountName
(Mandatory) Name for cache/log storage account for replication logs. This is a standard storage account in the same Azure region as the virtual machine/s being replicated. The cache/log storage account is used to hold replication changes temporarily, before the changes are moved to the recovery Azure region. If the inputted LogStorageAccount doesn't exist, one will be created

.PARAMETER $LogStorageAccountResourceGroup
(Mandatory) Resource Group for the LogStorageAccount. If the inputted LogStorageAccountResourceGroup doesn't exist, one will be created

.PARAMETER TargetResourceGroup
(Mandatory) Resource Group Name where recovery occurs. If the inputted TargetResourceGroup doesn't exist, one will be created

.PARAMETER TargetVirtualNetworkResourceGroup
(Mandatory) Name of resource group for virtual network where recovery occurs

.PARAMETER TargetVirtualNetwork
(Mandatory) Name of virtual network where recovery occurs

.PARAMETER VMSelectionType
(Mandatory) criteria used to select the VMs
"RG:VMName" - Use comma delimited list of VMs to set up in ASR.
"RG" - Use Resource Group where all VMs within will be set up in ASR
"VNet" - Use VNet where all VMs within will be set up in ASR

.PARAMETER VMSelection
(Mandatory) criteria used to select the VMs
Based upon VMSelectionType, provide the relevent data for the VMs to be set up in ASR
"RG:VMName" - Comma delimited list of resourcegroupname:VMName to set up in ASR. I.e.- rg1:vm1,rg1:vm2,rg2:vm3, etc
"CSV" - Local CSV file with resourcegroupname:VMName in the same format as RG:VMName above - #TODO
"RG" - Resource Group Name where all VMs within will be set up in ASR
"VNet" - VNet Name where all VMs within will be set up in ASR

.PARAMETER dxcLogAnalyticsWorkspaceName
(Mandatory) Specifies the name Log Analytics Workspace used for connecting to DXC ServiceNow instance.

.PARAMETER asrDiagnosticSettingName
(Mandatory) Specifies the name of the diagnostic setting configured into the ASR Recovery Vault

Author:  Anthony Borucki
Date:    07/16/2021
Version: 1.0
Documentation: Initial version 

Example Script execution: 
.\deployASR.ps1 -Subscription b47b134f-d1e7-4f79-8a4c-043a355acf6d -ASRVaultResourceGroup tonyasrvaultrg -ASRVaultName asrtestvault1 -PrimaryRegion "centralus" -RecoveryRegion "eastus" -LogStorageAccountName asrlogstorage -LogStorageAccountResourceGroup tonytest -TargetResourceGroup tonytesttarget -TargetVirtualNetworkResourceGroup tonytesttarget -TargetVirtualNetwork VNetTarget -VMSelectionType RG -VMSelection tonytest -dxcLogAnalyticsWorkspaceName DXC-G2EA-b47b-loganalyticsWorkspace -asrDiagnosticSettingName azr21811diag
#>

Param(
	[Parameter(Mandatory=$true)] [String]$Subscription,
	[Parameter(Mandatory=$true)] [String]$ASRVaultResourceGroup,
	[Parameter(Mandatory=$true)] [String]$ASRVaultName,
	[Parameter(Mandatory=$true)] [String]$PrimaryRegion,
	[Parameter(Mandatory=$true)] [String]$RecoveryRegion,
	[Parameter(Mandatory=$false)] [String]$PolicyName = "ASRPolicy",
	[Parameter(Mandatory=$true)] [String]$LogStorageAccountName,
	[Parameter(Mandatory=$true)] [String]$LogStorageAccountResourceGroup,
	[Parameter(Mandatory=$false)] [ValidateSet("Premium_LRS","Standard_LRS","StandardSSD_LRS",IgnoreCase = $true)][String]$LogStorageAccountDiskType = "Standard_LRS",
	[Parameter(Mandatory=$true)] [String]$TargetResourceGroup,
	[Parameter(Mandatory=$true)] [String]$TargetVirtualNetworkResourceGroup,
	[Parameter(Mandatory=$true)] [String]$TargetVirtualNetwork,
#May consider using these after MVP
#TODO?
#	[Parameter(Mandatory=$false)] [ValidateSet("Premium_LRS","Standard_LRS","StandardSSD_LRS",IgnoreCase = $true)][String]$RecoveryReplicaDiskAccountType = "Standard_LRS",
#	[Parameter(Mandatory=$false)] [ValidateSet("Premium_LRS","Standard_LRS","StandardSSD_LRS",IgnoreCase = $true)][String]$RecoveryTargetDiskAccountType = "Standard_LRS",
	#VM related parameters
	[Parameter(Mandatory=$true)] [ValidateSet("RG:VMName","RG","VNet",IgnoreCase = $true)] [String] $VMSelectionType,
	[Parameter(Mandatory=$true)] [String]$VMSelection,
	#Make Managed for ASR parameters
	[Parameter(Mandatory=$true)]  [String]$dxcLogAnalyticsWorkspaceName,
    [Parameter(Mandatory=$true)]  [String]$asrDiagnosticSettingName,
	[Parameter(Mandatory=$false)][String]$artifactsdev = "False",
	[Parameter(Mandatory=$false)][String]$ArtifactsKeyVaultName = "DXC-EA2-Maint-Vault"
)

#Functions
#======================================
Function monitorJob($job)
{
	do {
		Start-Sleep -Seconds 5
		$job = Get-AzRecoveryServicesAsrJob -Job $job
		Write-Host "." -NoNewline
	} while ($job.State -ne "Succeeded" -and $job.State -ne "Failed" -and $job.State -ne "CompletedWithInformation")

	if ($job.State -eq "Failed") {
		$message = 'Job {0} failed for {1}' -f $job.DisplayName, $job.TargetObjectName
		Write-Output $message
		foreach ($er in $job.Errors) {
			foreach ($pe in $er.ProviderErrorDetails) {
				Write-Host $pe
			}
			foreach ($se in $er.ServiceErrorDetails) {
				Write-Host $se
			}
		}
		throw $message
	}
	Write-Host
}

#========================================================================================================================
# IMPORT CUSTOM MODULE
#========================================================================================================================
$dxcModuleList = "DXCUtilityFunctions.psm1"

foreach ($dxcModule in $dxcModuleList)
{
    [String]$dxcModuleURL = "https://dxcazuretoolsdev.blob.core.windows.net/installers/DXCPowershellModules/" + $dxcModule
    [String]$dxcLocalModule = $PSScriptRoot + "\" + $dxcModule
    (New-Object System.Net.WebClient).DownloadFile($dxcModuleURL, $dxcLocalModule)
    Import-Module $dxcLocalModule -WA 0
}

#Connect to Tenant
Utility-LoginAZ -dxcSubscriptionId $Subscription

$PrimaryRegion = $PrimaryRegion.Replace(' ', '').ToLower()
$RecoveryRegion = $RecoveryRegion.Replace(' ', '').ToLower()
$DeploymentScriptOutputs = @{}

#Code to display values to be used and allow the user to proceed or exit
write-host 
write-host "Below are the values to be used in the deployment and configuration of ASR. Please review before proceeding" -ForegroundColor Green
write-host 
write-host "Subscription = $Subscription"
write-host "ASRVaultResourceGroup = $ASRVaultResourceGroup"
write-host "ASRVaultName = $ASRVaultName"
write-host "PrimaryRegion = $PrimaryRegion"
write-host "RecoveryRegion = $RecoveryRegion"
write-host "PolicyName = $PolicyName"
write-host "LogStorageAccountName = $LogStorageAccountName"
write-host "LogStorageAccountResourceGroup = $LogStorageAccountResourceGroup"
write-host "TargetResourceGroup = $TargetResourceGroup"
write-host "TargetVirtualNetworkResourceGroup = $TargetVirtualNetworkResourceGroup"
write-host "TargetVirtualNetwork = $TargetVirtualNetwork"
#write-host "RecoveryReplicaDiskAccountType = $RecoveryReplicaDiskAccountType"
#write-host "RecoveryTargetDiskAccountType = $RecoveryTargetDiskAccountType"
write-host "VMSelectionType = $VMSelectionType"
write-host "VMSelection = $VMSelection"
write-host "dxcLogAnalyticsWorkspaceName = $dxcLogAnalyticsWorkspaceName"
write-host "asrDiagnosticSettingName = $asrDiagnosticSettingName"
write-host
write-host "Are these the values you wish to proceed with? (Y/y to proceed, or N/n to quit)" -ForegroundColor Green -NoNewline
$Proceed=read-host 
if ($Proceed -ne "Y" -and $Proceed -ne "y") {
	exit
}
write-host

#Main section of executable
#######################################3
#VM resolution
if ($VMSelectionType -ieq "RG:VMName"){
	$sourceVms = New-Object System.Collections.ArrayList
	$SplitVMs = $VMSelection.split(",")
	foreach($VMInfo in $SplitVMs){
		$SplitVMInfo = $VMInfo.split(":")
		$candidateSourceVm = Get-AzVM -resourcegroup $SplitVMInfo[0] -name $SplitVMInfo[1]
		#Check if VM is already in array. If so, don't add it again.
		$vmExistsInArray = $false
		foreach($sourceVm in $sourceVms){
			if($sourceVm.Id -eq $candidateSourceVm.Id){
				$vmExistsInArray = $true
			}
		}
		if(!$vmExistsInArray){
			$sourceVms.Add($candidateSourceVm) | out-null
		}
	}
}
#TODO - Sometime after MVP
elseif ($VMSelectionType -ieq "CSV"){

}
elseif ($VMSelectionType -ieq "RG"){
	$sourceVms = Get-AzVM -resourcegroup $VMSelection
	if ($sourceVms.count -gt 0){
		Write-Host "Below are the virtual machines in Resource Group $VMSelection that will be set up for replication" -ForegroundColor Green
	}
	else{
		Write-Host "There are no virtual machines in Resource Group $VMSelection. Exiting script." -ForegroundColor Red
		exit
	}
}
elseif ($VMSelectionType -ieq "VNet"){
	$sourceVms = New-Object System.Collections.ArrayList
	$VmSubnets = (Get-AzVirtualNetwork -name $VMSelection).Subnets
	#Loop thru each subnet
	foreach($VmSubnet in $VmSubnets){
		foreach($IpConfig in $VmSubnet.IpConfigurations){
			$SplitIpConfig = $IpConfig.Id.split("/")
			$candidateSourceVMId = (Get-AzNetworkInterface -resourcegroup $SplitIpConfig[4] -name $SplitIpConfig[8]).VirtualMachine.Id

			#Check if VM is already in array. If so, don't add it again.
			$vmExistsInArray = $false
			foreach($sourceVm in $sourceVms){
				if($sourceVm.Id -eq $candidateSourceVMId){
					$vmExistsInArray = $true
				}
			}
			if(!$vmExistsInArray){
				$SplitVmId = $candidateSourceVMId.split("/")
				$sourceVm = Get-AzVM -resourcegroup $SplitVmId[4] -name $SplitVmId[8]
				$sourceVms.Add($sourceVm) | out-null
			}
		}
	}
}

#VM Id Outputs
$VmsAllInPrimaryRegion = $true
$VmsNotRunning = $false
foreach($VM in $sourceVms){
	$VMLocation = $VM.Location
	if ($PrimaryRegion -ine $VMLocation){
#TODO? May be of interest after MVP to possible handle VM in multiple source/primary region. There will be implications!!!
		Write-Host "The VM immediately below in red is NOT in Primary Region $PrimaryRegion" -ForegroundColor Red
		$VmsAllInPrimaryRegion = $false
		Write-Host $VM.Id  -ForegroundColor Red
		Write-Host "Region = $VMLocation" -ForegroundColor Red
	}
	else{
		$VMDetail = Get-AzVM -resourcegroup $VM.ResourceGroupName -Name $VM.Name -Status
		foreach ($VMStatus in $VMDetail.Statuses){ 
			if($VMStatus.Code.Contains("PowerState")){
				$VMPowerState = $VMStatus.Code
			}
		}
		if ($VMPowerState -ne "PowerState/running"){
			$VmsNotRunning = $true
			Write-Host "VM below is NOT in a running state" -ForegroundColor Red
			Write-Host $VM.Id -ForegroundColor Red
		}
		else{
			Write-Host $VM.Id 
		}
	}
}
Write-Host
If ($VmsAllInPrimaryRegion -eq $false)
{
	Write-Host "One or more VMs listed above in red are not in the Primary Region $PrimaryRegion. All VMs must be in the same region and match the Primary Region inputted. Exiting..." -ForegroundColor Red
	exit
}
If ($VmsNotRunning -eq $true)
{
	Write-Host "One or more VMs are not in a running state and therefore cannot be set up for replication. Either exclude these VM/s from script execution or start VM/s and run script again. Exiting..." -ForegroundColor Red
	exit
}

write-host "Are these the VMs you wish to proceed with ASR set up on? (Y/y to proceed, or N/n to quit)" -ForegroundColor Green -NoNewline
$Proceed=read-host 
if ($Proceed -ne "Y" -and $Proceed -ne "y") {
	exit
}
write-host

#Validate parameters and create resources as needed
#Get or create ASRVaultResourceGroup
if (!(Get-AzResourceGroup -Name $ASRVaultResourceGroup -ErrorAction Ignore)){
	write-host "ASR Vault Resource Group $ASRVaultResourceGroup doesn't exist. Would you like to create it? (Y/y to proceed, or N/n to quit)" -ForegroundColor Yellow -NoNewline
	$Proceed=read-host 
	if ($Proceed -ne "Y" -and $Proceed -ne "y") {
		exit
	}
	write-host "Creating ASR Vault Resource Group $ASRVaultResourceGroup in recovery region $RecoveryRegion" -ForegroundColor Green
	try{
		New-AzResourceGroup -Name $ASRVaultResourceGroup -Location $RecoveryRegion -ErrorAction Stop
	}
	catch{
		write-host "Error Creating ASR Vault Resource Group $ASRVaultResourceGroup in recovery region $RecoveryRegion" -ForegroundColor Red
		$ErrorMessage = $_.Exception.Message
		write-host $ErrorMessage -ForegroundColor Red
		exit
	}
}
else{
	$ASRVaultResourceGroupRegion = (Get-AzResourceGroup -Name $ASRVaultResourceGroup).Location
	if ($RecoveryRegion -ine $ASRVaultResourceGroupRegion){
		write-host "Existing ASR Vault Resource Group $ASRVaultResourceGroup is in a different region ($ASRVaultResourceGroupRegion) than inputted RecoveryRegion = $RecoveryRegion. They must be the same. Exiting..." -ForegroundColor Red
		exit
	}
	write-host "ASR Vault Resource Group $ASRVaultResourceGroup exists. Will use existing Resource Group" -ForegroundColor Green
}

#Get or create ASR Vault
if (!(Get-AzRecoveryServicesVault -Name $ASRVaultName -ErrorAction Ignore)){
	write-host "ASR Vault $ASRVaultName doesn't exist. Would you like to create it? (Y/y to proceed, or N/n to quit)" -ForegroundColor Yellow -NoNewline
	$Proceed=read-host 
	if ($Proceed -ne "Y" -and $Proceed -ne "y") {
		exit
	}
	write-host "Creating ASR Vault $ASRVaultName in resource group $ASRVaultResourceGroup" -ForegroundColor Green
	try{
		New-AzRecoveryServicesVault -Name $ASRVaultName -ResourceGroupName $ASRVaultResourceGroup -Location $RecoveryRegion -ErrorAction Stop
	}
	catch{
		write-host "Error Creating ASR Vault $ASRVaultName in resource group $ASRVaultResourceGroup" -ForegroundColor Red
		$ErrorMessage = $_.Exception.Message
		write-host $ErrorMessage -ForegroundColor Red
		exit
	}
}
else{
	$ASRVaultRegion = (Get-AzRecoveryServicesVault -Name $ASRVaultName).Location
	if ($RecoveryRegion -ine $ASRVaultRegion){
		write-host "Existing ASR Vault $ASRVaultName is in a different region ($ASRVaultRegion) than inputted RecoveryRegion = $RecoveryRegion. They must be the same. Exiting..." -ForegroundColor Red
		exit
	}
	write-host "ASR Vault $ASRVaultName exists. Will use existing vault" -ForegroundColor Green
}

#Call Make Managed for ASR
Write-Host
Write-Host "Calling makeManagedASR.ps1 script to enable monitoring and tags on $ASRVaultName" -ForegroundColor Green
Write-Host "###############################################################################################" -ForegroundColor Green
#Artifact used - script and tokens to access
$ArtifactsStorageAccountName = "dxcazuretoolsdev"
$mmASRScriptContainerName = "installers"
$mmASRScript = "makeManagedASR.ps1"
#Get SAS token for make managed
$token = ""
if ($artifactsdev -eq "True") 
{
	Try {
		$secretvalue = Get-AzKeyVaultSecret -VaultName $ArtifactsKeyVaultName -Name makeMgdSasTokendev
		$token = [System.Net.NetworkCredential]::new("", $secretvalue.SecretValue).Password
	}
	Catch {
		$token = $null
	}
	if ($token -eq "" -or $null -eq $token) {
		write-host "makeMgdSasTokendev not found in key vault. Please fix this issue and re-run this script"
		Exit
	}
}
else
{
	Try {
		$secretvalue = Get-AzKeyVaultSecret -VaultName $ArtifactsKeyVaultName -Name makeMgdSasToken
		$token = [System.Net.NetworkCredential]::new("", $secretvalue.SecretValue).Password
	}
	Catch {
		$token = $null
	}
	if ($token -eq "" -or $null -eq $token) {
		write-host "makeMgdSasToken not found in key vault. Please fix this issue and re-run this script"
		Exit
	}
}
#Call to mmASR
$Ctx = New-AzStorageContext -StorageAccountName $ArtifactsStorageAccountName -SasToken $token
Get-AzStorageBlobContent -Blob $mmASRScript -Container $mmASRScriptContainerName -Context $Ctx

".\$mmASRScript -dxcSubscriptionID $Subscription -dxcLogAnalyticsWorkspaceName $dxcLogAnalyticsWorkspaceName -asrRecoveryVaultName $ASRVaultName -asrDiagnosticSettingName $asrDiagnosticSettingName" | Invoke-Expression
Write-Host "End of call to makeManagedASR.ps1 script to enable monitoring and tags on $ASRVaultName" -ForegroundColor Green
Write-Host "###############################################################################################" -ForegroundColor Green
Write-Host

# Setup the vault context.
Write-Host "Setting Vault context using vault $ASRVaultName under resource group $ASRVaultResourceGroup in subscription $Subscription." -ForegroundColor Green
Select-AzSubscription -SubscriptionId $Subscription
$vault = Get-AzRecoveryServicesVault -ResourceGroupName $ASRVaultResourceGroup -Name $ASRVaultName
Set-AzRecoveryServicesAsrVaultContext -vault $vault
Write-Host "Vault context set" -ForegroundColor Green
Write-Host

# Lookup and create replication fabrics if required.
$azureFabrics = get-asrfabric -ErrorAction Ignore
#Primary Fabric
$priFab = $azureFabrics | where {$_.FabricSpecificDetails.Location -like $PrimaryRegion}
if ($priFab -eq $null) {
	Write-Host "Primary Fabric does not exist. Creating Primary Fabric." -ForegroundColor Green
	$job = New-ASRFabric -Azure -Name $PrimaryRegion -Location $PrimaryRegion
	monitorJob $job
    $priFab = get-asrfabric -Name $PrimaryRegion
    Write-Host "Created Primary Fabric." -ForegroundColor Green
}
else{
	Write-Host "Primary Fabric for region $PrimaryRegion already exists. It will be re-used" -ForegroundColor Green
} 

#Recovery Fabric
$recFab = $azureFabrics | where {$_.FabricSpecificDetails.Location -eq $RecoveryRegion}
if ($recFab -eq $null) {
	Write-Host "Recovery Fabric does not exist. Creating Recovery Fabric" -ForegroundColor Green
	$job = New-ASRFabric -Azure -Name $RecoveryRegion -Location $RecoveryRegion
	monitorJob $job
	$recFab = get-asrfabric -Name $RecoveryRegion
	Write-Host "Created Recovery Fabric." -ForegroundColor Green
}
else{
	Write-Host "Recovery Fabric for region $RecoveryRegion already exists. It will be re-used" -ForegroundColor Green
} 

$message = "Primary Fabric - {0}" -f $priFab.Id
Write-Output $message
$message = "Recovery Fabric - {0}" -f $recFab.Id
Write-Output $message
Write-Host
$DeploymentScriptOutputs["PrimaryFabric"] = $priFab.Name
$DeploymentScriptOutputs["RecoveryFabric"] = $recFab.Name

# Setup the Protection Containers. Create if the protection containers do not already exist.
#Primary Container
$priContainer = Get-AzRecoveryServicesAsrProtectionContainer -Fabric $priFab
if ($priContainer -eq $null) {
	Write-Host "Primary Protection container does not exist. Creating Primary Protection Container" -ForegroundColor Green
	$job = New-AzRecoveryServicesAsrProtectionContainer -Name $priFab.Name.Replace(' ', '') -Fabric $priFab
	monitorJob $job
	$priContainer = Get-AzRecoveryServicesAsrProtectionContainer -Name $priFab.Name -Fabric $priFab
	Write-Host "Created Primary Protection Container" -ForegroundColor Green
}
else{
	Write-Host "Primary Protection Container for Primary Fabric already exists. It will be re-used" -ForegroundColor Green
} 

#Recovery Container
$recContainer = Get-AzRecoveryServicesAsrProtectionContainer -Fabric $recFab
if ($recContainer -eq $null) {
	Write-Host "Recovery Protection container does not exist. Creating Recovery Protection Container" -ForegroundColor Green
	$job = New-AzRecoveryServicesAsrProtectionContainer -Name $recFab.Name.Replace(' ', '') -Fabric $recFab
	monitorJob $job
	$recContainer = AzRecoveryServicesAsrProtectionContainer -Name $recFab.Name -Fabric $recFab
	Write-Host "Created Recovery Protection Container"
}
else{
	Write-Host "Recovery Protection Container for Recovery Fabric already exists. It will be re-used" -ForegroundColor Green
} 
$message = "Primary Protection Container {0}" -f $priContainer.Id
Write-Output $message
$message = "Recovery Protection Container {0}" -f $recContainer.Id
Write-Output $message
Write-Host
$DeploymentScriptOutputs["PrimaryProtectionContainer"] = $priContainer.Name
$DeploymentScriptOutputs["RecoveryProtectionContainer"] = $recContainer.Name

#Set up or get the policy for mapping
$policy = Get-AzRecoveryServicesAsrPolicy -Name $PolicyName -ErrorAction Ignore
if ($policy -eq $null) {
	Write-Host "Replication policy does not already exist. Creating Replication policy" -ForegroundColor Green 
#TODO - After MVP make the policy values parameters
	$job = New-AzRecoveryServicesAsrPolicy -AzureToAzure -Name $PolicyName -RecoveryPointRetentionInHours 2 -ApplicationConsistentSnapshotFrequencyInHours 1
	monitorJob $job
	$policy = Get-ASRPolicy -Name $PolicyName
	Write-Host "Created Replication policy $PolicyName"
}
else{
	Write-Host "ASR Policy $PolicyName already exists. It will be re-used" -ForegroundColor Green
} 

# Setup the protection container mapping. Create one if it does not already exist.
#Primary Container Mapping
$primaryProtectionContainerMapping =  Get-AzRecoveryServicesAsrProtectionContainerMapping -ProtectionContainer $priContainer | where {$_.TargetProtectionContainerId -like $recContainer.Id}
if ($primaryProtectionContainerMapping -eq $null) {
	Write-Host "Protection Container mapping does not already exist. Creating protection container" -ForegroundColor Green 
	$protectionContainerMappingName = $priContainer.Name +  'To' + $recContainer.Name
	$job = New-AzRecoveryServicesAsrProtectionContainerMapping -Name $protectionContainerMappingName -Policy $policy -PrimaryProtectionContainer $priContainer -RecoveryProtectionContainer $recContainer
	monitorJob $job
	$primaryProtectionContainerMapping = Get-AzRecoveryServicesAsrProtectionContainerMapping -Name $protectionContainerMappingName -ProtectionContainer $priContainer
	Write-Host "Created Primary Protection Container mapping $protectionContainerMappingName"   
}
else{
	Write-Host "Primary Protection Container mapping already exists. It will be re-used" -ForegroundColor Green
} 

#Reverse Container Mapping - To be used after MVP is released. Not currently used yet #TODO
$reverseContainerMapping = Get-AzRecoveryServicesAsrProtectionContainerMapping -ProtectionContainer $recContainer | where {$_.TargetProtectionContainerId -like $priContainer.Id}
if ($reverseContainerMapping -eq $null) {
	Write-Host "Reverse Protection container does not already exist. Creating Reverse protection container" -ForegroundColor Green 
	$reverseProtectionContainerMappingName = $recContainer.Name + 'To' + $priContainer.Name
	$job = New-AzRecoveryServicesAsrProtectionContainerMapping -Name $reverseProtectionContainerMappingName -Policy $policy -PrimaryProtectionContainer $recContainer -RecoveryProtectionContainer $priContainer
	monitorJob $job
	$reverseContainerMapping = Get-AzRecoveryServicesAsrProtectionContainerMapping -Name $reverseProtectionContainerMappingName -ProtectionContainer $recContainer    
	Write-Host "Created Recovery Protection Container mapping $reverseProtectionContainerMappingName" 
}
else{
	Write-Host "Reverse Protection Container mapping already exists. It will be re-used" -ForegroundColor Green
} 
$message = "Primary Protection Container Mapping {0}" -f $primaryProtectionContainerMapping.Id
Write-Output $message
$message = "Recovery Protection Container Mapping {0}" -f $reverseContainerMapping.Id
Write-Output $message
Write-Host

$DeploymentScriptOutputs['PrimaryProtectionContainerMapping'] = $primaryProtectionContainerMapping.Name
$DeploymentScriptOutputs['ReverseProtectionContainerMapping'] = $reverseContainerMapping.Name

#Get or create LogStorageAccount
if (!(Get-AzStorageAccount -ResourceGroupName $LogStorageAccountResourceGroup -Name $LogStorageAccountName -ErrorAction Ignore)){
	#Get or create LogStorageAccountResourceGroup
	if (!(Get-AzResourceGroup -Name $LogStorageAccountResourceGroup -ErrorAction Ignore)){
		write-host "Log Storage Account Resource Group $LogStorageAccountResourceGroup doesn't exist. Would you like to create it? (Y/y to proceed, or N/n to quit)" -ForegroundColor Yellow -NoNewline
		$Proceed=read-host 
		if ($Proceed -ne "Y" -and $Proceed -ne "y") {
			exit
		}
		write-host "Creating Log Storage Account Resource Group $LogStorageAccountResourceGroup in primary region $PrimaryRegion" -ForegroundColor Green
		try{
			New-AzResourceGroup -Name $LogStorageAccountResourceGroup -Location $PrimaryRegion -ErrorAction Stop
		}
		catch{
			write-host "Error Creating Log Storage Account Resource Group $LogStorageAccountResourceGroup in primary region $PrimaryRegion" -ForegroundColor Red
			$ErrorMessage = $_.Exception.Message
			write-host $ErrorMessage -ForegroundColor Red
			exit
		}
	}
	else{
		$LogStorageAccountResourceGroupRegion = (Get-AzResourceGroup -Name $LogStorageAccountResourceGroup).Location
		if ($PrimaryRegion -ine $LogStorageAccountResourceGroupRegion){
			write-host "Existing Log Storage Account Resource Group $LogStorageAccountResourceGroup is in a different region ($LogStorageAccountResourceGroupRegion) than inputted PrimaryRegion = $PrimaryRegion. They must be the same. Exiting..." -ForegroundColor Red
			exit
		}
		write-host "Log Storage Account Resource Group $LogStorageAccountResourceGroup exists. Will use existing Resource Group" -ForegroundColor Green
	}
	write-host "Log Storage Account $LogStorageAccountName doesn't exist. Would you like to create it? (Y/y to proceed, or N/n to quit)" -ForegroundColor Yellow -NoNewline
	$Proceed=read-host 
	if ($Proceed -ne "Y" -and $Proceed -ne "y") {
		exit
	}
	write-host "Creating Log Storage Account $LogStorageAccountName in resource group $LogStorageAccountResourceGroup in PrimaryRegion = $PrimaryRegion with SKU = $LogStorageAccountDiskType" -ForegroundColor Green
	try{
		New-AzStorageAccount -Name $LogStorageAccountName -ResourceGroupName $LogStorageAccountResourceGroup -Location $PrimaryRegion -SkuName $LogStorageAccountDiskType -Kind Storage -ErrorAction Stop
	}
	catch{
		write-host "Error Creating Log Storage Account $LogStorageAccountName in resource group $LogStorageAccountResourceGroup in PrimaryRegion = $PrimaryRegion with SKU = $LogStorageAccountDiskType" -ForegroundColor Red
		$ErrorMessage = $_.Exception.Message
		write-host $ErrorMessage -ForegroundColor Red
		exit
	}
}
else{
	$LogStorageAccountRegion = (Get-AzStorageAccount -ResourceGroupName $LogStorageAccountResourceGroup -Name $LogStorageAccountName).Location
	if ($PrimaryRegion -ine $LogStorageAccountRegion){
		write-host "Existing Log Storage Account $LogStorageAccountName is in a different region ($LogStorageAccountRegion) than inputted PrimaryRegion = $PrimaryRegion. They must be the same. Exiting..." -ForegroundColor Red
		exit
	}
	write-host "Log Storage Account $LogStorageAccountName exists. Will use existing Log Storage Account" -ForegroundColor Green
}
$LogStorageAccountId = (Get-AzStorageAccount -ResourceGroupName $LogStorageAccountResourceGroup -Name $LogStorageAccountName).Id
$message = "Log Storage Account {0}" -f $LogStorageAccountId
Write-Output $message
Write-Host

#Get or create TargetResourceGroup
if (!(Get-AzResourceGroup -Name $TargetResourceGroup -ErrorAction Ignore)){
	write-host "Target Resource Group $TargetResourceGroup doesn't exist. Would you like to create it? (Y/y to proceed, or N/n to quit)" -ForegroundColor Yellow -NoNewline
	$Proceed=read-host 
	if ($Proceed -ne "Y" -and $Proceed -ne "y") {
		exit
	}
	write-host "Creating Target Resource Group $TargetResourceGroup in recovery region $RecoveryRegion" -ForegroundColor Green
	try{
		New-AzResourceGroup -Name $TargetResourceGroup -Location $RecoveryRegion -ErrorAction Stop
	}
	catch{
		write-host "Error Creating Target Resource Group $TargetResourceGroup in recovery region $RecoveryRegion" -ForegroundColor Red
		$ErrorMessage = $_.Exception.Message
		write-host $ErrorMessage -ForegroundColor Red
		exit
	}
}
else{
	$TargetResourceGroupRegion = (Get-AzResourceGroup -Name $TargetResourceGroup).Location
	if ($RecoveryRegion -ine $TargetResourceGroupRegion){
		write-host "Existing Target Resource Group $TargetResourceGroup is in a different region ($TargetResourceGroupRegion) than inputted RecoveryRegion = $RecoveryRegion. They must be the same. Exiting..." -ForegroundColor Red
		exit
	}
	write-host "Target Resource Group $TargetResourceGroup exists. Will use existing Resource Group" -ForegroundColor Green
}
$TargetResourceGroupId = (Get-AzResourceGroup -Name $TargetResourceGroup).ResourceId
Write-Host

#Retrieve the virtual network that the first virtual machine in list is connected to. This will be used for creating a target virtual network if requested as well as for network mappings
#Get first network interface card(nic) of the virtual machine
$SplitNicArmId = $sourceVms[0].NetworkProfile.NetworkInterfaces[0].Id.split("/")
#Extract resource group name from the ResourceId of the nic
$NICRG = $SplitNicArmId[4]
#Extract resource name from the ResourceId of the nic
$NICname = $SplitNicArmId[-1]
#Get network interface details using the extracted resource group name and resource name
$NIC = Get-AzNetworkInterface -ResourceGroupName $NICRG -Name $NICname
#Get the subnet ID of the subnet that the nic is connected to
$PrimarySubnet = $NIC.IpConfigurations[0].Subnet
#Extract the resource ID of the Azure virtual network the nic is connected to from the subnet ID
$PrimaryNetworkId = (Split-Path(Split-Path($PrimarySubnet.Id))).Replace("\","/")

#Get or create Target Virtual Network 
if (!(Get-AzVirtualNetwork -Name $TargetVirtualNetwork -ResourceGroupName $TargetVirtualNetworkResourceGroup -ErrorAction Ignore)){
	#Get or create TargetVirtualNetworkResourceGroup
	if (!(Get-AzResourceGroup -Name $TargetVirtualNetworkResourceGroup -ErrorAction Ignore)){
		write-host "Target Virtual Network Resource Group $TargetVirtualNetworkResourceGroup doesn't exist. Would you like to create it? (Y/y to proceed, or N/n to quit)" -ForegroundColor Yellow -NoNewline
		$Proceed=read-host 
		if ($Proceed -ne "Y" -and $Proceed -ne "y") {
			exit
		}
		write-host "Creating Target Virtual Network Resource Group $TargetVirtualNetworkResourceGroup in recovery region $RecoveryRegion" -ForegroundColor Green
		try{
			New-AzResourceGroup -Name $TargetVirtualNetworkResourceGroup -Location $RecoveryRegion -ErrorAction Stop
		}
		catch{
			write-host "Error Creating Target Virtual Network Resource Group $TargetVirtualNetworkResourceGroup in recovery region $RecoveryRegion" -ForegroundColor Red
			$ErrorMessage = $_.Exception.Message
			write-host $ErrorMessage -ForegroundColor Red
			exit
		}
	}
	else{
		$TargetVirtualNetworkResourceRegion = (Get-AzResourceGroup -Name $TargetVirtualNetworkResourceGroup).Location
		if ($RecoveryRegion -ine $TargetVirtualNetworkResourceRegion){
			write-host "Existing Target Virtual Network Resource Group $TargetVirtualNetworkResourceGroup is in a different region ($TargetVirtualNetworkResourceRegion) than inputted RecoveryRegion = $RecoveryRegion. They must be the same. Exiting..." -ForegroundColor Red
			exit
		}
		write-host "Target Virtual Network Resource Group $TargetVirtualNetworkResourceGroup exists. Will use existing Resource Group" -ForegroundColor Green
	}
	write-host "Target Virtual Network $TargetVirtualNetwork doesn't exist. A new Target VNet will be created to match the existing source VNet below, only changing the RG, name and region it is located in." -ForegroundColor Yellow
	write-host $PrimaryNetworkId
	write-host "Would you like to create it? (Y/y to proceed, or N/n to quit)" -ForegroundColor Yellow -NoNewline
	$Proceed=read-host 
	if ($Proceed -ne "Y" -and $Proceed -ne "y") {
		exit
	}
	try{
		write-host "Exporting ARM template of Source Virtual Network" -ForegroundColor Green
		$SourceVNetSplit = $PrimaryNetworkId.split("/")
		$SourceVNetRG = $SourceVNetSplit[4]
		$SourceVNetName = $SourceVNetSplit[8]
		Export-AzResourceGroup -ResourceGroupName $SourceVNetRG -Resource $PrimaryNetworkId -IncludeParameterDefaultValue
		((Get-Content .\$SourceVNetRG.json -raw) -replace "`"defaultValue`": `"$SourceVNetName`"", "`"defaultValue`": `"$TargetVirtualNetwork`"")|Set-Content .\$SourceVNetRG.json
		((Get-Content .\$SourceVNetRG.json -raw) -replace "`"location`": `"$PrimaryRegion`"", "`"location`": `"$RecoveryRegion`"")|Set-Content .\$SourceVNetRG.json

		write-host "Creating Target Virtual Network $TargetVirtualNetwork in resource group $TargetVirtualNetworkResourceGroup in recovery region $RecoveryRegion" -ForegroundColor Green	
		New-AzResourceGroupDeployment -ResourceGroupName $TargetVirtualNetworkResourceGroup -TemplateFile .\$SourceVNetRG.json
	}
	catch{
		write-host "Error Creating Target Virtual Network $TargetVirtualNetwork in resource group $TargetVirtualNetworkResourceGroup in recovery region $RecoveryRegion" -ForegroundColor Red
		$ErrorMessage = $_.Exception.Message
		write-host $ErrorMessage -ForegroundColor Red
		exit
	}
}
else{
	$TargetVirtualNetworkResourceRegion = (Get-AzVirtualNetwork -Name $TargetVirtualNetwork -ResourceGroupName $TargetVirtualNetworkResourceGroup).Location
	if ($RecoveryRegion -ine $TargetVirtualNetworkResourceRegion){
		write-host "Existing Target Virtual Network $TargetVirtualNetwork is in a different region ($TargetVirtualNetworkResourceRegion) than inputted RecoveryRegion = $RecoveryRegion. They must be the same. Exiting..." -ForegroundColor Red
		exit
	}
	write-host "Target Virtual Network $TargetVirtualNetwork exists. Will use existing Target Virtual Network" -ForegroundColor Green
}

$TargetVirtualNetworkId = (Get-AzVirtualNetwork -Name $TargetVirtualNetwork -ResourceGroupName $TargetVirtualNetworkResourceGroup).Id
$message = "Target Virtual Network {0}" -f $TargetVirtualNetworkId
Write-Output $message
Write-Host

#Create network mappings, both primary to recovery as well as fail back mapping (not used in automation yet)
#===========================================
#Get or Create primary network mapping
$PrimaryNetworkMappingName = ($PrimaryNetworkId.split("/")[-1]+"to"+$TargetVirtualNetwork)
$PrimaryNetworkMapping = Get-AzRecoveryServicesAsrNetworkMapping -PrimaryFabric $priFab -Name $PrimaryNetworkMappingName -ErrorAction Ignore
if ($PrimaryNetworkMapping -eq $null) {
	Write-Host "Primary network mapping does not exist. Creating Primary network mapping - $PrimaryNetworkMappingName" -ForegroundColor Green
	$job = New-AzRecoveryServicesAsrNetworkMapping -AzureToAzure -Name $PrimaryNetworkMappingName -PrimaryFabric $priFab -PrimaryAzureNetworkId $PrimaryNetworkId -RecoveryFabric $recFab -RecoveryAzureNetworkId $TargetVirtualNetworkId
	monitorJob $job
	Write-Host "Created Primary network mapping" -ForegroundColor Green
}
else{
	Write-Host "Primary network mapping for Primary Fabric already exists. It will be re-used" -ForegroundColor Green
}
$PrimaryNetworkMappingId = (Get-AzRecoveryServicesAsrNetworkMapping -PrimaryFabric $priFab -Name $PrimaryNetworkMappingName).Id
$message = "Primary network mapping {0}" -f $PrimaryNetworkMappingId
Write-Output $message
Write-Host

#Get or Create recovery network mapping
#TODO. Mapping is done. But, it's not used anywhere in this scrpit yet as it's for failover to be done later
$RecoveryNetworkMappingName = ($TargetVirtualNetwork+"to"+$PrimaryNetworkId.split("/")[-1])
$RecoveryNetworkMapping = Get-AzRecoveryServicesAsrNetworkMapping -PrimaryFabric $recFab -Name $RecoveryNetworkMappingName -ErrorAction Ignore
if ($RecoveryNetworkMapping -eq $null) {
	Write-Host "Recovery network mapping does not exist. Creating Recovery network mapping - $RecoveryNetworkMappingName" -ForegroundColor Green
	$job = New-AzRecoveryServicesAsrNetworkMapping -AzureToAzure -Name $RecoveryNetworkMappingName -PrimaryFabric $recFab -PrimaryAzureNetworkId $TargetVirtualNetworkId -RecoveryFabric $priFab -RecoveryAzureNetworkId $PrimaryNetworkId
	monitorJob $job
	Write-Host "Created Recovery network mapping" -ForegroundColor Green
}
else{
	Write-Host "Recovery network mapping for Recovery Fabric already exists. It will be re-used" -ForegroundColor Green
}
$RecoveryNetworkMappingId = (Get-AzRecoveryServicesAsrNetworkMapping -PrimaryFabric $recFab -Name $RecoveryNetworkMappingName).Id
$message = "Recovery network mapping {0}" -f $RecoveryNetworkMappingId
Write-Output $message
Write-Host

# Start enabling replication for all the VMs.
Write-Host "Start enabling replication for all the VMs..." 
$enableReplicationJobs = New-Object System.Collections.ArrayList
foreach ($sourceVm in $sourceVms) {
	# Trigger Enable protection
	$vmName = $sourceVm.Name
	$vmResourceGroupName = $sourceVm.ResourceGroupName
	$vmId = $sourceVm.Id
	Write-Host "Enable protection to be triggered for $vmId using VM name $vmName as protected item ARM name" -ForegroundColor Green
	$diskList =  New-Object System.Collections.ArrayList

	$OsDiskAccountType = $sourceVm.StorageProfile.OsDisk.ManagedDisk.StorageAccountType
	$osDisk = New-AzRecoveryServicesAsrAzureToAzureDiskReplicationConfig -DiskId $sourceVm.StorageProfile.OsDisk.ManagedDisk.Id -LogStorageAccountId $LogStorageAccountId -ManagedDisk -RecoveryReplicaDiskAccountType $OsDiskAccountType -RecoveryResourceGroupId $TargetResourceGroupId -RecoveryTargetDiskAccountType $OsDiskAccountType          
	$diskList.Add($osDisk)| out-null

	foreach($dataDisk in $sourceVm.StorageProfile.DataDisks)
	{
		$DataDiskAccountType = $dataDisk.ManagedDisk.StorageAccountType
		$disk = New-AzRecoveryServicesAsrAzureToAzureDiskReplicationConfig -DiskId $dataDisk.ManagedDisk.Id -LogStorageAccountId $LogStorageAccountId -ManagedDisk  -RecoveryReplicaDiskAccountType $DataDiskAccountType -RecoveryResourceGroupId  $TargetResourceGroupId -RecoveryTargetDiskAccountType $DataDiskAccountType
		$diskList.Add($disk)| out-null
	}
	Write-Host "Enable protection being triggered"
	#This is the main meat of it all!
	$job = New-AzRecoveryServicesASRReplicationProtectedItem -AzureToAzure -Name $vmName -ProtectionContainerMapping $primaryProtectionContainerMapping -AzureVmId $vmId -AzureToAzureDiskReplicationConfiguration $diskList -RecoveryResourceGroupId $TargetResourceGroupId -RecoveryAzureNetworkId $TargetVirtualNetworkId
	$enableReplicationJobs.Add($job)| out-null
}

# Monitor each enable replication job
$AllJobsDone = $false
$TotalJobCount = $enableReplicationJobs.Count
$CurrentJobsRemainingCount = 0
Write-Host
Write-Host "There are $TotalJobCount jobs that have been launched to enable replication for $TotalJobCount VMs. Progress will be monitored below..." -ForegroundColor Yellow
Write-Host
do {
	$AllJobsDone = $true
	Start-Sleep -Seconds 20
	foreach ($job in $enableReplicationJobs) {
		$job = Get-AsrJob -Job $job
		if ($job.State -ne 'Succeeded' -and $job.State -ne 'Failed' -and $job.State -ne 'CompletedWithInformation'){
			$CurrentJobsRemainingCount++
			$AllJobsDone = $false
		}
	}
	Write-Host "$CurrentJobsRemainingCount enable replication jobs still executing out of $TotalJobCount total jobs..." -ForegroundColor Yellow
	$CurrentJobsRemainingCount = 0
} while ($AllJobsDone -eq $false)

Write-Host
Write-Host "All Enable Replication Jobs completed. Report:" -ForegroundColor Green
foreach ($job in $enableReplicationJobs) {
	Write-Host
	$job = Get-AsrJob -Job $job
	$targetObjectName = $job.TargetObjectName
	if ($job.State -eq "Succeeded") {
		$rpid = (Get-AzRecoveryServicesAsrReplicationProtectedItem -Name $targetObjectName -ProtectionContainer $priContainer).Id
		Write-Host "Enable replication job completed successfully for $rpid" -ForegroundColor Green
	}
	elseif ($job.State -eq "CompletedWithInformation") {
		$rpid = (Get-AzRecoveryServicesAsrReplicationProtectedItem -Name $targetObjectName -ProtectionContainer $priContainer).Id
		Write-Host "Enable replication job completed with addition information that should be reviewed for $rpid" -ForegroundColor Yellow
		Write-Host "Please check Site Recovery Job in ASR Vault $ASRVaultName for more details" -ForegroundColor Yellow
	}
	elseif($job.State -eq "Failed"){
		Write-Host "Enable replication job FAILED for $targetObjectName" -ForegroundColor Red
		foreach ($er in $job.Errors) {
			foreach ($pe in $er.ProviderErrorDetails) {
				Write-Host $pe
			}
			foreach ($se in $er.ServiceErrorDetails) {
				Write-Host $se
			}
		}
	}
}

# Log consolidated output.
Write-Output 'Infrastructure Details'
foreach ($key in $DeploymentScriptOutputs.Keys)
{
    $message = '{0} : {1}' -f $key, $DeploymentScriptOutputs[$key]
    Write-Output $message
}
Write-Host
Write-Host "ASR Deployment, configuration and enable replication of VMs completed. Initial replication of these VMs may still be running. View the Replicated Items in ASR Vault $ASRVaultName for more details." -ForegroundColor Green
