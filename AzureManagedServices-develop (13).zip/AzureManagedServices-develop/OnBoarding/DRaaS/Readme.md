﻿# DRaSS Readme

## Supported
Creates ASR vault and all other resources need to replicate VMs in a DR setup.

## Jira Epic
https://jira.dxc.com/browse/AZR-305

## Deployment
For more information on how to execute script, please see the DRaaS Solution Guide located:
https://confluence.dxc.com/display/CSA/Managed+Services+for+MS+Azure+DRaaS+Solution+Guide

## Members of this directory are:
deployASR.ps1		Deploys ASR and sets up VMs for replication
makeManagedASR.ps1	Sets up ASR Vault for DXC monitoring

## Authors
Azure Engineering - Anthony Borucki
