<#
.SYNOPSIS
    A Runbook for Azure VM shutdown schedule evaluation and Automation Job execution
    
.DESCRIPTION
    When shutdown schedule is evaluated, the parameters (VMName, ResourceGroup, Action) are passed to DXC-AutomationAccount-StartStopRunbookExec
.NOTES
    File Name      : DXC-VMStartStopRunbook.ps1
    Author         : Mažvydas Zabotka (mazvydas.zabotka@dxc.com)
    Prerequisite   : Azure Automation Account
    Copyright 2020 : DXC Technology
#>

$ConnectionName = "AzureRunAsConnection"
$Conn = Get-AutomationConnection -Name $ConnectionName
if ($Conn -eq $null)
{
    throw "Could not retrieve connection asset: $ConnectionName. Check that this asset exists in the Automation account."
}

## Testing purposes : warmup start time
$startJobTime = $(Get-Date).TimeofDay.Totalseconds

Add-AzAccount -ServicePrincipal -Tenant $Conn.TenantID -ApplicationId $Conn.ApplicationID -CertificateThumbprint $Conn.CertificateThumbprint
#$setTimeZone and $automationAccountRG variable values must be specified during the deployment of the solution using the deployment script or manually
$setTimeZone = ""
$automationAccountRG = ""
$automationAccountName = ""

# For throttling purposes if total running Automation jobs are nearing the Automation Account limits
$totalAutomationJobs = 0
Function Convert-TimeZone {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        $setTimeZone,
        [Parameter(Mandatory = $false)]
        [String]$dayTimeVar
    )

    $tempDate = Get-Date
    $modifiedTz = [System.TimeZoneInfo]::FindSystemTimeZoneById("$setTimeZone")
    $CurrentTime = [System.TimeZoneInfo]::ConvertTime($tempDate, $modifiedTz)
    if ($dayTimeVar -match "Format") {
        $formatString = $dayTimeVar.replace('-Format ','')
        $CurrentTime = Get-Date $CurrentTime -Format $formatString
    }
    elseif ($dayTimeVar) {
        if ($dayTimeVar -match "DayOfWeek") {
            $CurrentTime = (Get-Date $CurrentTime).DayOfWeek
        }
    }
    return $CurrentTime
}

## Used to output logging time in correct time zone for tracking purposes

Function Get-Time {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [String]$setTimeZone
    )
    $tempDate = Get-Date
    $modifiedTz = [System.TimeZoneInfo]::FindSystemTimeZoneById("$setTimeZone")
    $CurrentTime = [System.TimeZoneInfo]::ConvertTime($tempDate, $modifiedTz)
    $date = Get-Date $CurrentTime -Format HH:mm:ss
    return $date
}

# Used to format an error message and send it to Log Analytics
Function Format-Error {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $true)]
        $invalidTaggedVMs,
        [Parameter(Mandatory = $false)]
        $automationJobError
    )
    $invalidTaggedVMs | ForEach-Object {
        $VMName = $_.Name
        $pattern = "subscriptions/(.*)/resourceGroups"
        $vmResourceId = ($_).Id
        $subscriptionId = [regex]::match($vmResourceId, $pattern).Groups[1].Value
        if ($automationJobError) {
            $errorMsg = $automationJobError
        }
        else {
            $errorMsg = "Virtual machine $($_.Name) has invalid dxcAutoShutdownSchedule tag value(s). Syntax example: 00 15 * * * 8h . For full scheduling documentation please refer to the Azure offering documentation."
        }
        $errorLAData = "$VMName,$subscriptionId,$vmResourceId,$errorMsg"
        write-error -Message $errorLAData
    }
}
## Function checks number of concurrent Automation jobs and performs the throttling dynamically
Function Start-ThrottleJobs {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [int]$totalAutomationJobs,
        [Parameter(Mandatory = $true)]
        $setTimeZone,
        [Parameter(Mandatory = $true)]
        $automationAccountRG,
        [Parameter(Mandatory = $true)]
        $automationAccountName
    )

    ## Testing purposes: print out number of concurrent running jobs
    $runningJobCount = $($(Get-AzAutomationJob -ResourceGroupName $automationAccountRG -AutomationAccountName $automationAccountName -runbookname "DXC-VMStartStopRunbookExec" | Where-Object {$_.Status -eq "Running"}).Count)
    $queuedJobCount = $($(Get-AzAutomationJob -ResourceGroupName $automationAccountRG -AutomationAccountName $automationAccountName -runbookname "DXC-VMStartStopRunbookExec" | Where-Object {$_.Status -eq "Queued"}).Count)
    if($totalAutomationJobs -ge 190) {
      $concurrentAutomationJobs = $runningJobCount + $queuedJobCount
      if ($concurrentAutomationJobs -ge 190) {
          do {
              Write-Output -InputObject "[$(Get-Time $setTimeZone)] Performing throttling, as $concurrentAutomationJobs Automation Jobs are close to 200 concurrent job limit. Please wait until some of the jobs are cleared ..."
              start-sleep -seconds 10
          }
          while ((Get-AzAutomationJob -ResourceGroupName $automationAccountRG -AutomationAccountName $automationAccountName -runbookname "DXC-VMStartStopRunbookExec" | Where-Object {$_.Status -eq "Running"}).Count -gt 180)
	  }  
    }
}

# Creates DXC-VMStartStopRunbookExec job and executes Start/Stop action
Function Start-AutomationJob {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $true)]
        $Action,
        [Parameter(Mandatory = $true)]
        $VM,
        [Parameter(Mandatory = $true)]
        $setTimeZone,
        [Parameter(Mandatory = $true)]
        $automationAccountRG,
        [Parameter(Mandatory = $true)]
        $automationAccountName
    )
    $VMName = $VM.Name
    $VMPowerState = $VM.PowerState
    $VMResourceGroup = $VM.ResourceGroupName
    
    if ($VMPowerState -match "running" -and $Action -eq "Stop") {
        Write-Output -InputObject "[$(Get-Time $setTimeZone)] $VMName is running. [Action]: Stopping." 
        $params = @{"VMName"="$VMName";"ResourceGroup"="$VMResourceGroup";"Action"="Stop"}
        try {
            ## Executes a Stop action on a VM by calling a DXC-VMStartStopRunbookExec Runbook with a Stop parameter
             Start-AzAutomationRunbook -AutomationAccountName $automationAccountName -ResourceGroupName $automationAccountRG –Name "DXC-VMStartStopRunbookExec" –Parameters $params
            ## One second delay to avoid quick spool up of Automation jobs
            Start-Sleep -seconds 1
        }
        catch {
            $errorMessage = $_.Exception.Message
            Format-Error $VMName $errorMessage
            #throw "Exception: $errorMessage"
        }
        finally {
            write-output -InputObject "[$(Get-Time $setTimeZone)] The VM $VMName Stop action has been initiated."
            ## Counts total executed jobs and performs throttling if neccessary
            $totalAutomationJobs++
             Start-ThrottleJobs $totalAutomationJobs $setTimeZone $automationAccountRG $automationAccountName
        }
    }
    elseif ($VMPowerState -match "stopped|deallocated" -and $Action -eq "Stop") {
        Write-Output -InputObject "[$(Get-Time $setTimeZone)] VM $VMName is under shutdown schedule and it is deallocated. Skipping..." 
    }
    elseif ($VMPowerState -match "stopped|deallocated" -and $Action -eq "Start") {
        Write-Output -InputObject "[$(Get-Time $setTimeZone)] The $VMName is stopped. [Action]: Starting." 
        $params = @{"VMName"="$VMName";"ResourceGroup"="$VMResourceGroup";"Action"="Start"}
        try {
            ## Executes a Stop action on a VM by calling a DXC-VMStartStopRunbookExec Runbook with a Start parameter
            Start-AzAutomationRunbook –AutomationAccountName "DXC-AutomationAccount-VMStartStop" -ResourceGroupName $automationAccountRG –Name "DXC-VMStartStopRunbookExec" –Parameters $params
            ## One second delay to avoid quick spool up of Automation jobs
            Start-Sleep -seconds 1
        }
        catch {
            $errorMessage = $_.Exception.Message
            Format-Error $VMName $errorMessage
            #throw "Exception: $errorMessage"
        }
        finally {
            Write-Output -InputObject "[$(Get-Time $setTimeZone)] The VM $VMName Start action has been initiated."
            ## Counts total executed jobs and performs throttling if neccessary
            $totalAutomationJobs++
            Start-ThrottleJobs $totalAutomationJobs $setTimeZone $automationAccountRG

        }
    }
    elseif ($VMPowerState -match "running" -and $Action -eq "Start") {
        Write-Output -InputObject "[$(Get-Time $setTimeZone)] VM $VMName is running. No actions required, skipping..."
    }
}

# Performs the cron schedule validation against current time
Function Test-CronSchedule {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $true)]
        $formattedSchedule
    )
    $tempArray = @()
    $tempScheduleVar = ""
    [int]$i=0
    $formattedSchedule -split '\s' | ForEach-Object {
        $i++
        $tempScheduleVar += "$_ "
        if($i -ge 5) {
            $tempArray += $tempScheduleVar
            $tempScheduleVar = ''
            $i = 0
        } 
    }
        write-output -InputObject "$($temparray.Count)"
    ##It is likely a string, therefore, it just checks the first schedule and skips the other
    $tempArray | ForEach-Object {
        ## Each schedule values are separated by a space delimiter. Splitting by space to get specific schedule values
        $vmScheduleArray = $_.Split(' ')
        if ($vmScheduleArray[0] -match '\d:\d') {
            try {
                Get-Date $vmScheduleArray[0] | Out-Null
            }
            catch {
                $errorMessage = $_.Exception.Message
                Format-Error $VM $errorMessage
            }
            finally {
                $vmShutdownStart = [int](Get-Date $vmScheduleArray[0]).TimeOfDay.TotalMinutes
            }
        }
        elseif ($vmScheduleArray[0] -eq "allDay") {
            $vmShutdownStart = [int](Get-Date 00:00).TimeOfDay.TotalMinutes
        }
        # --- *Start of* Month and monthday reservation for future releases --- #
        $vmScheduledDayOfMonth = $vmScheduleArray[1]
        $vmScheduledMonth = $vmScheduleArray[2]
        # --- *End of* Month and monthday reservation for future releases --- #
        $vmScheduledWeekDay = $vmScheduleArray[3]
        if ($vmScheduleArray[4] -eq 'untilNextDay') {
            [int]$vmShutdownEnd = (Get-Date 23:59).TimeOfDay.TotalMinutes
            [int]$vmShutdownEndAnyDay = (Get-Date 23:59).TimeOfDay.TotalMinutes
            [int]$vmDowntimeEnd = (Get-Date 23:59).TimeOfDay.TotalMinutes
        }
        elseif ($vmScheduleArray[4] -match '\d\w') {
            [int]$vmShutdownEnd = $vmScheduleArray[4].Replace('h','')
            [int]$vmShutdownEnd = $vmShutdownEnd*60
		[int]$vmDowntimeEnd = $vmShutdownEnd + $vmShutdownStart
            [int]$vmShutdownEndAnyDay = (Get-Date 23:59).TimeOfDay.TotalMinutes
            
        }
        Write-Output $vmShutdownStart $vmShutdownEnd

        if (($vmScheduleArray[4] -eq 'untilNextDay' -or ((Convert-TimeZone $setTimeZone "-Format ddd") -match $vmScheduledWeekDay.Replace(',','|'))) `
        -and ((((((Convert-TimeZone $setTimeZone DayOfWeek) -match $vmScheduledWeekDay.Replace(',','|') -or ((Convert-TimeZone $setTimeZone "-Format ddd") -match $vmScheduledWeekDay.Replace(',','|'))) -and ((Convert-TimeZone $setTimeZone "-Format dd") -match $vmScheduledDayOfMonth.Replace(',','|'))) `
        -and ((($vmScheduleArray[0] -eq "allDay" <#-or $vmScheduleArray[4] -match '\d\w' #>) -and [int](Convert-TimeZone $setTimeZone).TimeOfDay.TotalMinutes -in $vmShutdownStart..$vmDowntimeEnd))) `
        -or ((((Convert-TimeZone $setTimeZone "-Format ddd") -match $vmScheduledWeekDay.Replace(',','|')) -and $vmScheduleArray[4] -eq 'untilNextDay' -and ((Convert-TimeZone $setTimeZone "-Format dd") -match $vmScheduledDayOfMonth.Replace(',','|'))) `
        -and ([int](Convert-TimeZone $setTimeZone).TimeOfDay.TotalMinutes -in $vmShutdownStart..$vmShutdownEndAnyDay)) `
        -or ((((Convert-TimeZone $setTimeZone DayOfWeek) -match $vmScheduledWeekDay.Replace(',','|') -and ((Convert-TimeZone $setTimeZone "-Format dd") -match $vmScheduledDayOfMonth.Replace(',','|')))`
        -and ([int](Convert-TimeZone $setTimeZone).TimeOfDay.TotalMinutes -in $vmShutdownStart..$vmShutdownEnd)) -and ((Convert-TimeZone $setTimeZone "-Format dd") -match $vmScheduledDayOfMonth.Replace(',','|'))))) `
        -and ((Convert-TimeZone $setTimeZone "-Format MMM") -match $vmScheduledMonth.Replace(',','|'))) {

            return "Stop"
            break
        
        }
        elseif ($vmScheduleArray[4] -match '\d\w' -and $vmScheduledWeekDay.Split(',').Count -ge 1 ) {
            $vmScheduledWeekDay.Split(',') | ForEach-Object { 
                $previousSunday = ((Convert-TimeZone $setTimeZone).AddDays(-1 * (Convert-TimeZone $setTimeZone DayOfWeek))).Date
                $scheduledDate = $previousSunday.AddDays([int][dayofweek] $_)
                $vmShutdownStartSchedule = $scheduledDate.AddMinutes($vmShutdownStart)
               if ([int]((Convert-TimeZone $setTimeZone) - $vmShutdownStartSchedule).TotalMinutes -le $vmShutdownEnd -and ((Convert-TimeZone $setTimeZone) -gt $vmShutdownStartSchedule) -and ((Convert-TimeZone $setTimeZone "-Format MMM") -match $vmScheduledMonth.Replace(',','|')) -and ((Convert-TimeZone $setTimeZone "-Format ddd") -match $vmScheduledWeekDay.Replace(',','|')) -and ((Convert-TimeZone $setTimeZone "-Format dd") -match $vmScheduledDayOfMonth.Replace(',','|')))   {  

                    return "Stop"
                    break

                }
                else {
                    $vmScheduledDayOfMonth.Split(',') | ForEach-Object {
                       if ((([int]((Convert-TimeZone $setTimeZone).TimeofDay.TotalMinutes) + ([int](Convert-TimeZone $setTimeZone "-Format dd") * 24*60)) -in (([int]$_*24*60) + $vmShutdownStart)..(([int]$_*24*60) + $vmShutdownStart + $vmShutdownEnd) -and ((Convert-TimeZone $setTimeZone "-Format MMM") -match $vmScheduledMonth.Replace(',','|')) <#-and ((Convert-TimeZone $setTimeZone "-Format ddd") -match $vmScheduledWeekDay.Replace(',','|'))#>)) {
                            return "Stop"
                            break
                       }
                       else {
                            return "Start"
                            break 
                       }
                    }

                }
            }          
        }
       elseif(($vmScheduleArray[4] -eq 'untilNextDay' -or ((Convert-TimeZone $setTimeZone "-Format ddd") -match $vmScheduledWeekDay.Replace(',','|'))) `
        -and (((((Convert-TimeZone $setTimeZone DayOfWeek) -match $vmScheduledWeekDay.Replace(',','|') -or ((Convert-TimeZone $setTimeZone "-Format ddd") -notmatch $vmScheduledWeekDay.Replace(',','|'))) -or (Convert-TimeZone $setTimeZone DayOfWeek) -notmatch $vmScheduledWeekDay.Replace(',','|') -or ((Convert-TimeZone $setTimeZone "-Format ddd") -notmatch $vmScheduledWeekDay.Replace(',','|'))) `
        -or ((([int](Convert-TimeZone $setTimeZone).TimeOfDay.TotalMinutes -notin $vmShutdownStart..$vmShutdownEndAnyDay -and (Convert-TimeZone $setTimeZone DayOfWeek) -notmatch $vmScheduledWeekDay.Replace(',','|')) -or ([int](Convert-TimeZone $setTimeZone).TimeOfDay.TotalMinutes -notin $vmShutdownStart..$vmShutdownEndAnyDay -and (Convert-TimeZone $setTimeZone DayOfWeek) -match $vmScheduledWeekDay.Replace(',','|'))) `
        -or (([int](Convert-TimeZone $setTimeZone).TimeOfDay.TotalMinutes -notin $vmShutdownStart..$vmShutdownEnd -and (Convert-TimeZone $setTimeZone DayOfWeek) -notmatch $vmScheduledWeekDay.Replace(',','|')) -or ([int](Convert-TimeZone $setTimeZone).TimeOfDay.TotalMinutes -notin $vmShutdownStart..$vmShutdownEnd -and (Convert-TimeZone $setTimeZone DayOfWeek) -match $vmScheduledWeekDay.Replace(',','|'))))))) {
            
            return "Start"
            break            
        
        }
        else {
            Format-Error $VM "Virtual Machine $($VM.Name) does not fall under any of cron validation conditions. Please submit the VM Name, cron scheduler, Automation Job output to a programmer for further investigation."
        }      
    }
    }


# Converts weekday span, separated by '-' symbol to Get-Date readable format
Function Get-Dayspan {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $true)]
        $dayrange,
        [Parameter(Mandatory = $true)]
        $VM
    )
    $days = @("Sun","Mon","Tue","Wed","Thu","Fri","Sat","Sun")
    $startingDay = [int]$dayrange.Split('-')[0]
    $endingDay = [int]$dayrange.Split('-')[1]
    if ($startingDay -gt $endingDay) {
        Format-Error $VM "The VM $($VM.Name) cron day range parameter is incorrect. Starting day should be less or equal to ending day. 00 15 * * 1-2 8h or 00 15 * * 1-5. For full scheduling documentation please refer to the Azure offering documentation. "
        break
    }
    for ($startingDay ; $startingDay -le $endingDay ; $startingDay++) {
        $dayspan += "$($days[$startingDay]),"
    }
    return $dayspan.Substring(0,$dayspan.Length-1)+' '
}

Function Get-Monthspan {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $true)]
        $monthrange,
        [Parameter(Mandatory = $true)]
        $VM
    )
    $months = @("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Dec")
    $startingMonth = [int]$monthrange.Split('-')[0]
    $endingMonth = [int]$monthrange.Split('-')[1]
    if ($startingMonth -gt $endingMonth) {
        Format-Error $VM "The VM $($VM.Name) cron month range parameter is incorrect. Starting month should be less or equal to ending month. 00 15 * 9-12 1-5 8h or 00 15 * 1-9 1-5. For full scheduling documentation please refer to the Azure offering documentation. "
        break
    }
    for ($startingMonth ; $startingMonth -le $endingMonth ; $startingMonth++) {
        $Monthspan += "$($months[$startingMonth-1]),"
    }
    return $Monthspan.Substring(0,$Monthspan.Length-1)+' '
}
Function Get-MonthDayspan {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $true)]
        $monthdayrange,
        [Parameter(Mandatory = $true)]
        $VM
    )
    $MonthDaySpan = ""
    $monthDays = 1..31
    $startingMonthDay = $monthdayrange.Split('-')[0]
    $endingMonthDay = $monthdayrange.Split('-')[1]
    if ($startingMonthDay -notin $monthDays -or $endingMonthDay -notin $monthDays) {
        Format-Error $VM "The VM $($VM.Name) cron month day range parameter is incorrect. The starting month day and/or ending month days falls out of 1..31 days range. Example for cron scheduler: 00 15 25-26 * * 8h or 00 15 1-28 * *. For full scheduling documentation please refer to the Azure offering documentation. "
        return
    }
    if ($startingMonthDay -gt $endingMonthDay) {
        Format-Error $VM "The VM $($VM.Name) cron month day range parameter is incorrect. Starting month day should be less or equal to ending month. 00 15 25-26 * * 8h or 00 15 14-28 * *. For full scheduling documentation please refer to the Azure offering documentation. "
        return
    }
    ($startingMonthDay..$endingMonthDay) | ForEach-Object {
        $MonthDaySpan += "$_,"
    }
    return $MonthDaySpan.Substring(0,$MonthDaySpan.Length-1)+' '
}


# Reads VM Cron schedule and converts it into Get-Date readable format
Function Format-CronSchedule {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $true)]
        [PSObject]$unformattedScheduleList,
        [Parameter(Mandatory = $true)]
        $VM
    )
    ## Store array list of VM schedules - useful if there is more than one
    $minuteCronSchedule = New-Object -TypeName "System.Collections.ArrayList"
    $hourCronSchedule = New-Object -TypeName "System.Collections.ArrayList"
    $monthDayCronSchedule = New-Object -TypeName "System.Collections.ArrayList"
    $monthCronSchedule = New-Object -TypeName "System.Collections.ArrayList"
    $weekdayCronSchedule = New-Object -TypeName "System.Collections.ArrayList"
    $durationCronSchedule = New-Object -TypeName "System.Collections.ArrayList"
    $formattedCronSchedule = New-Object -TypeName "System.Collections.ArrayList"
   
    ## Split the string into Minutes, Hours, DaysOfMonth, Months, DaysOfWeek, Schedule Durations
    $unformattedScheduleList | ForEach-Object {
        ## Temporary string for formatted schedule per entry before storing it to $formattedCronSchedule 
        # We need a simple array, because we need to perform addition, trimming, etc, which is harder to accomplish using ArrayLists
        $tempCronSchedule =""
        $minuteCronSchedule = $_.Split(' ')[0]
        $hourCronSchedule = $_.Split(' ')[1]
        $monthDayCronSchedule = $_.Split(' ')[2]
        $monthCronSchedule = $_.Split(' ')[3]
        $weekdayCronSchedule = $_.Split(' ')[4]
        if ($_.Split(' ')[5] -match '\d\w') {
            $durationCronSchedule = $_.Split(' ')[5]
        }
        else {
            $durationCronSchedule = "untilNextDay"
        }
        
        if ($minuteCronSchedule -eq '*' -and $hourCronSchedule -eq '*') {
            $tempCronSchedule += 'allDay '
        }
        elseif ($minuteCronSchedule -eq '*' -and $hourCronSchedule -match '\d') {
            $tempCronSchedule += "$hourCronSchedule"+":00 "
        }
        elseif ($minuteCronSchedule -match '\d' -and $hourCronSchedule -match '\d') {
            $tempCronSchedule += $hourCronSchedule+':'+$minuteCronSchedule+' '
        }
        else {
            Format-Error $VM "The virtual machine does not have valid minute and/or hour schedule syntax. Syntax example: 00 15 * * * 8h . For full scheduling documentation please refer to the Azure offering documentation."
            return
        }

        if ($monthDayCronSchedule -eq '*') {
            [int]$i = 1
            for ($i; $i -lt 31; $i++) {
                $tempCronSchedule += "$i,"
            }
            $tempCronSchedule = $tempCronSchedule.Substring(0,$tempCronSchedule.Length-1)+' '
        } elseif ($monthDayCronSchedule -match '\d-\d') {
            #write-output -InputObject $(Get-MonthDayspan $monthDayCronSchedule $VM )
            $tempCronSchedule += Get-MonthDayspan $monthDayCronSchedule $VM 
        } elseif ($monthDayCronSchedule -match '\d') {
            $tempCronSchedule += "$monthDayCronSchedule "
        } else {
            Format-Error $VM "The virtual machine does not have valid month day schedule syntax. Currently specifying specific month day is not supported. Please use '*' symbol as a workaround instead. This feature will be supported in future. Syntax example: 00 15 * * * 8h . For full scheduling documentation please refer to the Azure offering documentation."
            return
        }

        ## Convert Month Cron value(s) to PS Get-Date readable format
        if ($monthCronSchedule -match ',') {
            $monthCronSchedule = $monthCronSchedule.Split(',')
        }
        $monthCronSchedule | ForEach-Object {
            switch ($_) {
                '1' {$tempCronSchedule += "Jan,"}
                '2' {$tempCronSchedule += "Feb,"}
                '3' {$tempCronSchedule += "Mar,"}
                '4' {$tempCronSchedule += "Apr,"}
                '5' {$tempCronSchedule += "May,"}
                '6' {$tempCronSchedule += "Jun,"}
                '7' {$tempCronSchedule += "Jul,"}
                '8' {$tempCronSchedule += "Aug,"}
                '9' {$tempCronSchedule += "Sep,"}
                '10' {$tempCronSchedule += "Oct,"}
                '11' {$tempCronSchedule += "Nov,"}
                '12' {$tempCronSchedule += "Dec,"}
                '*' {$tempCronSchedule += "Jan,Feb,Mar,Apr,May,Jun,Jul,Aug,Sep,Oct,Nov,Dec "}
                {$_ -match '\d-\d'} {$tempCronSchedule += Get-Monthspan $_ $VM}
                default {Format-Error $VM "The virtual machine does not have valid month schedule syntax. Syntax example: 00 15 * 1,2 * 8h . For full scheduling documentation please refer to the Azure offering documentation."
            return}
            }
        }
        ## Trim the last character, ends month value(s)
        $tempCronSchedule = $tempCronSchedule.Substring(0,$tempCronSchedule.Length-1)+' '

        if ($weekdayCronSchedule -match ',') {
            $weekdayCronSchedule = $weekdayCronSchedule.Split(',')
        }
        ## Convert Days of Week Cron value(s) to PS Get-Date readable format
        $weekdayCronSchedule | ForEach-Object {
            switch ($_) {
                '0' {$tempCronSchedule += "Sun,"}
                '1' {$tempCronSchedule += "Mon,"}
                '2' {$tempCronSchedule += "Tue,"}
                '3' {$tempCronSchedule += "Wed,"}
                '4' {$tempCronSchedule += "Thu,"}
                '5' {$tempCronSchedule += "Fri,"}
                '6' {$tempCronSchedule += "Sat,"}
                '7' {$tempCronSchedule += "Sun,"}
                '*' {$tempCronSchedule += "Sun,Mon,Tue,Wed,Thu,Fri,Sat "}
                {$_ -match '\d-\d'} {$tempCronSchedule += Get-Dayspan $_ $VM}
                default {Format-Error $VM "The virtual machine does not have valid weekday schedule syntax. Syntax example: 00 15 * * 1,2 8h or 00 15 * * 1-2 8h For full scheduling documentation please refer to the Azure offering documentation."
            return}
            }
        }
        ## Trim the last character, ends Days of Week value(s)
        $tempCronSchedule = $tempCronSchedule.Substring(0,$tempCronSchedule.Length-1)+' '
        $tempCronSchedule += "$durationCronSchedule"
        ## Store Get-Date readable schedule(s) into an ArrayList
        $formattedCronSchedule.Add($tempCronSchedule)
    }
    ## Return formatted schedules without enumeration
    write-output -NoEnumerate "$formattedCronSchedule"
}

$VMs=Get-AzVM -Status | Where-Object {$_.Tags["dxcAutoShutdownSchedule"] -and $_.Tags["dxcAutoShutdownSchedule"].Split(';')[0] -eq "Enabled" }
foreach ($VM in $VMs) {
    $unformattedScheduleList=($($($VM.Tags["dxcAutoShutdownSchedule"]).Replace('Enabled;','')).Split(';'))
    #Write-Output -inputobject "$unformattedScheduleList this is unformatted list"
    $scheduleValidationParam = New-Object -TypeName "System.Collections.ArrayList"
    $formattedSchedule = Format-CronSchedule $unformattedScheduleList $VM | Where-Object {$_.Length -gt 1 -and $_ -ne ''} | ForEach-Object { 
       $scheduleValidationParam.Add($_)
    }

# Calls a Stop/Start action based on Format-CronSchedule function output
    $returnAction = Test-CronSchedule $scheduleValidationParam
    if ($returnAction -match "Stop|Start") {
        try {
            Start-AutomationJob $returnAction $VM $setTimeZone $automationAccountRG $automationAccountName
        }
        catch {
            $errorMessage = $_.Exception.Message
            Format-Error $($VM.Name) $errorMessage
        }
        finally {
            Write-Output "The VM $($VM.Name) is a candidate for $returnAction"
        }
    }
    else {
        Format-Error $VM "$($VM.Name) did not receive Start or Stop action. Please submit $($VM.Name) cron schedule and Automation Job output logs to programmer for further investigation."
    }
}
$endJobTime = $(Get-Date).TimeofDay.Totalseconds
## Provides a summary of the Automation job
if ($totalAutomationJobs -lt 1) {
    Write-Output "There were no jobs to run. Finishing."
    write-output "[$(Get-Time $setTimeZone)] The Runbook job has finished in $([int]$($endJobTime - $startJobTime)) seconds."
}
else {
    Write-Output -InputObject "Total Start/Stop jobs executed: $totalAutomationJobs"
    write-output "[$(Get-Time $setTimeZone)] The Runbook job has finished in $([int]$($endJobTime - $startJobTime)) seconds."
}

# If VM dxcAutoShutdownSchedule tag dos not contain Enabled or Disabled value, perform alerting
$invalidTaggedVMs = ($(Get-AzVM -Status | Where-Object {$_.Tags["dxcAutoShutdownSchedule"] -and $_.Tags["dxcAutoShutdownSchedule"].Split(';')[0] -ne "Enabled" -and $_.Tags["dxcAutoShutdownSchedule"].Split(';')[0] -ne "Disabled" }))
if ($invalidTaggedVMs) {
    Format-Error $invalidTaggedVMs
}
