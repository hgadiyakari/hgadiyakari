<#
.SYNOPSIS
    Azure VM Start-Stop operations execution Runbook
.DESCRIPTION
    Parameters (VMName, ResourceGroup, Action) passed from DXC-AutomationAccount-VMStartStopRunbook to this runbook
    Based on Action (Start/Stop), this runbook performs an Action against a VM, which name is stored in parameter VMName in Resource Group, which name is stored
    in parameter ResourceGroup
.NOTES
    File Name      : DXC-VMStartStopRunbookExec.ps1
    Author         : Mažvydas Zabotka (mazvydas.zabotka@dxc.com)
    Prerequisite   : Azure Automation Account
    Copyright 2020 - DXC Technology
#>

param(
  [Parameter(Mandatory = $true)]
  [String]$VMName,
  [Parameter(Mandatory = $true)]
  [String]$ResourceGroup,
  [Parameter(Mandatory = $true)]
  [String]$Action
)
$ConnectionName = 'AzureRunAsConnection'
$Conn = Get-AutomationConnection -Name $ConnectionName
if (!$Conn)
{
  throw "Could not retrieve connection asset: $ConnectionName. Check that this asset exists in the Automation account."
}
Connect-AzAccount -ServicePrincipal -Tenant $Conn.TenantID -ApplicationId $Conn.ApplicationID -CertificateThumbprint $Conn.CertificateThumbprint

## Defines the timezone against which Start/Stop operations run
$setTimeZone = ""

## Expected Virtual Machine state yet unknown, early initialization
$Global:expectedVMState =""

## How much time in seconds VM is allowed to Start or Stop before alerting
$jobDurationTarget = 900

## Used to output logging time in correct time zone for tracking purposes
Function Get-Time {
  param (
      [Parameter(Mandatory = $true)]
      [String]$setTimeZone
  )
  $tempDate = Get-Date
  $modifiedTz = [System.TimeZoneInfo]::FindSystemTimeZoneById("$setTimeZone")
  $CurrentTime = [System.TimeZoneInfo]::ConvertTime($tempDate, $modifiedTz)
  $date = Get-Date $CurrentTime -Format HH:mm:ss
  return $date
}

## Start/Stop job tracker for validation purposes
Function Start-VMStartStopValidation {
  [CmdletBinding()]
  Param(
    [Parameter(Mandatory = $true)]
    $startJobTime,
    [Parameter(Mandatory = $true)]
    $VMName,
    [Parameter(Mandatory = $true)]
    $expectedVMState,
    [Parameter(Mandatory = $true)]
    $Action,
    [Parameter(Mandatory = $true)]
    $jobDurationTarget,
    [Parameter(Mandatory = $true)]
    [String]$setTimeZone
  )

  write-output -InputObject "[$(Get-Time $setTimeZone)] $VMName expected VM status is $expectedVMState"
  write-output -InputObject "[$(Get-Time $setTimeZone)] $VMName $Action target duration is $jobDurationTarget seconds"
  do 
  {
    $timeNow = $(Get-Date).TimeofDay.Totalseconds
    [int]$diff = $timeNow - $startJobTime
    write-output -InputObject "[$(Get-Time $setTimeZone)] The job is running for $diff seconds"
    if (($timeNow - $startJobTime) -gt $jobDurationTarget) 
    {
      $pattern = "subscriptions/(.*)/resourceGroups"
      $vmResourceId = (Get-AzVM -Name $VMName).Id
      $subscriptionId = [regex]::match($vmResourceId, $pattern).Groups[1].Value
      if ($Action -eq "Start") {
        $errorMsg =  "The VM $VMName $Action job duration has exceeded $jobDurationTarget seconds. Please validate the VM startup manually."
      }
      elseif ($Action -eq "Stop") {
        $errorMsg =  "The VM $VMName $Action job duration has exceeded $jobDurationTarget seconds. Please validate the VM deallocation manually."
      }
      $errorMessage = "Error"
      $VMNameMod = $VMName.Replace("Start-VMStartStopValidation : ","")
      $errorLAData = "$VMNameMod,$subscriptionId,$vmResourceId,$errorMsg,$errorMessage"
      return $errorLAData
      break
    }
    Start-Sleep -Seconds 10
  }
  while ($(Get-AzVM -Name $VMName -status).PowerState -notmatch $expectedVMState)
}

# Executes Start/Stop action, sent by DXC-VMStartStopRunbook against a VM
Function Start-VMStartStopAction {
  [CmdletBinding()]
  Param(
    [Parameter(Mandatory = $true)]
    $VMName,
    [Parameter(Mandatory = $true)]
    $ResourceGroup,
    [Parameter(Mandatory = $true)]
    $Action,
    [Parameter(Mandatory = $true)]
    $setTimeZone
  )

  if ($Action -eq 'Start') 
  {
      try 
      {
        Write-Output -InputObject "[$(Get-Time $setTimeZone)] Starting VM $VMName"
        Start-AzVM -ResourceGroupName $ResourceGroup -Name $VMName -nowait
      }
      catch
      {
        $errorMessage = $_.Exception.Message
        $pattern = "subscriptions/(.*)/resourceGroups"
        $vmResourceId = (Get-AzVM -Name $VMName).Id
        $subscriptionId = [regex]::match($vmResourceId, $pattern).Groups[1].Value
        $errorMsg =  "The runbook has failed to start on $VMName."
        $errorLAData = "$VMName,$subscriptionId,$vmResourceId,$errorMsg,$errorMessage"
        return $errorLAData
      }
      finally 
      {
        Write-Output -InputObject "[$(Get-Time $setTimeZone)] The VM VMName $Start action has been initiated."
        $Global:expectedVMState = "Running"
      }
    }
  elseif ($Action -eq 'Stop') 
  {
    try 
    {
      Write-Output -InputObject "[$(Get-Time $setTimeZone)] Stopping VM $VMName"
      Stop-AzVM -ResourceGroupName $ResourceGroup -Name $VMName -Force -nowait
    }
    catch 
    {
      $errorMessage = $_.Exception.Message
      $pattern = "subscriptions/(.*)/resourceGroups"
      $vmResourceId = (Get-AzVM -Name $VMName).Id
      $subscriptionId = [regex]::match($vmResourceId, $pattern).Groups[1].Value
      $errorMsg =  "The runbook has failed to stop on $VMName."
      $errorLAData = "$VMName,$subscriptionId,$vmResourceId,$errorMsg,$errorMessage"
      return $errorLAData
    }
    finally 
    {
      Write-Output -InputObject "[$(Get-Time $setTimeZone)] The VM $VMName Stop action has been initiated."
      $Global:expectedVMState = "Deallocated"
    }
  }
}

$outputStartStop = Start-VMStartStopAction $VMName $ResourceGroup $Action $setTimeZone

# Performs alerting if there is failed VM Start/Stop operation
if ($outputStartStop -match "failed") {
  Write-Error -Message "$($outputStartStop[$_.Count -1])"
  $additionalInformation = "There are errors in this job. Please refer to Errors tab."
}

# VM status validation job start time
$startJobTime = $(Get-Date).TimeofDay.Totalseconds

## call a function for job validation
$outputStartStopvalidation = Start-VMStartStopValidation $startJobTime $VMName $expectedVMState $Action $jobDurationTarget $setTimeZone

# Performs alerting if there is prolonged VM startup
if ($outputStartStopvalidation -match "exceeded") {
  Write-Error -Message "$($outputStartStopvalidation[$_.Count -1])"
  $additionalInformation = "There are errors in this job. Please refer to Errors tab."
}

$endJobTime = $(Get-Date).TimeofDay.Totalseconds

write-output -InputObject "[$(Get-Time $setTimeZone)] The VM $VMName action $Action job has finished in $([int]$($endJobTime - $startJobTime)) seconds."

# Presents the user information that there are errors - asking to refer to Error tab
if ($additionalInformation) {
  write-output -InputObject "[$(Get-Time $setTimeZone)] $additionalInformation."
}
