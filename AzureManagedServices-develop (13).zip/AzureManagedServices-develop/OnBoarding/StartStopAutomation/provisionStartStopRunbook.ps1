<#
.SYNOPSIS
    A Runbook for Azure VM shutdown schedule evaluation and Automation Job execution
    
.DESCRIPTION
    When shutdown schedule is evaluated, the parameters (VMName, ResourceGroup, Action) are passed to DXC-AutomationAccount-StartStopRunbookExec
.NOTES
    File Name      : provisionStartStopRunbook.ps1
    Author         : Mažvydas Zabotka (mazvydas.zabotka@dxc.com)
    Prerequisite   : Azure Automation Account
    Copyright 2020 : DXC Technology
#>
Param(
    # Customer Azure Subscription Id
    [Parameter(Mandatory = $true)]
    $subId,
    # Resource Group Name to deploy the Automation Account to
    [Parameter(Mandatory = $true)]
    $resourceGroupName,
    # Time zone ID
    [Parameter(Mandatory = $true)]
    $selectedTz,
    # Log Analytics Workspace name
    [Parameter(Mandatory = $true)]
    $workspaceName,
    # Action - Deploy, Update, Remove solution
    [Parameter(Mandatory = $true)]
    $Action,
    # Automation Account name
    [Parameter(Mandatory = $true)]
    $automationAccountName,
    #DXC maintenance RG name
    [Parameter(Mandatory = $true)]
    $DXCMaintRGName

)

# Variable initialization part
$runbookVersion = "1.1"
$requiredModuleList = "Az.Accounts, Az.Automation, Az.Compute"
$requiredModules = $requiredModuleList -split (',') -replace (" ")
$runbookTags = @{"service"="vmstartstop"}
#$automationAccountName = "DXC-AutomationAccount-VMStartStop"
#$global:resourceGroupName = ""
$runbookName = "DXC-VMStartStopRunbook"
$global:installRequired = ""
$execRunbookName = "DXC-VMStartStopRunbookExec"
$runbookScheduleNames = @("DXC-VMStartStopRunbook-Schedule-0","DXC-VMStartStopRunbook-Schedule-30")
$runbookPath = ".\DXC-VMStartStopRunbook.ps1"
$execRunbookPath = ".\DXC-VMStartStopRunbookExec.ps1"
$alertRuleJSONPath = ".\alerts-vmstartstop.json"
$alertRuleName = "DXC-Minor-StartStopVMExecution"
$eventProcessingSchema = "3.0"
# End of variable initialization part

# Runbook files and alert rule file validation
if (!$(Test-Path $runbookPath) -or !$(Test-Path $execRunbookPath) -or !$(Test-Path $alertRuleJSONPath)) {
    Write-Host "`n Error: Please validate if $runbookName, $execRunbookName and $alertRuleJSONPath location and name is correct. Expected: $($(get-location).ToString())\$runbookName.ps1 ($runbookName.ps1 should be in the same directory as the provisioning script). Breaking.  " -ForegroundColor Red
    break
} else {
    Write-Host " `n Precheck: $runbookName, $execRunbookName and $alertRuleJSONPath exist. `n" -ForegroundColor Green
}

$subscriptions=$subId
$global:subscriptionId = $subId
Select-AzSubscription -subscriptionId $subId

# Checks if there is any LA workspace matching 'loganalyticsWorkspace', else, the user will be prompted to enter the workspace name
Function Validate-LAWorkspace {
    [CmdletBinding()]
    Param (
        [Parameter(Mandatory = $true)]
        $subscriptionId,
        [Parameter(Mandatory = $true)]
        $LAName
    )
 #   Select-AzSubscription -subscriptionId $subscriptionId | Out-Null
    if (!$(Get-AzResource -ResourceType "Microsoft.OperationalInsights/workspaces" | Where-Object {$_.Name -eq "$LAName"})) {

        do {
            Write-Host "`n Unable to find valid Log Analytics workspace." -ForegroundColor Red
            $LAName = Read-Host "Please specify the Log Analytics workspace name"
        } while (!$(Get-AzResource -ResourceType "Microsoft.OperationalInsights/workspaces" | Where-Object {$_.Name -eq "$LAName"}))
        
    }
    Write-Host "Log Analytics workspace $LAName is valid `n"
    $workspace = (Get-AzResource -ResourceType "Microsoft.OperationalInsights/workspaces" | Where-Object {$_.Name -eq "$LAName"})
    $Global:workspaceId = [String]$workspace.ResourceId 
    $Global:workspaceName = [String]$workspace.Name 
    $Global:LAResourceGroup = [String]$workspace.ResourceGroupName 
    $Global:LAWorkspaceRegion = [String](($workspace.location).ToLower()) -replace '\s','' 

}

Function FindOrCreateKeyvault ([string]$ResourceGroupName, [string]$UniqueID, [string]$LAWorkspaceRegion, [string]$DXCMaintRGName){
	##############################################################################################################
	#Searches RG supplied in DXCMaintRGName for a KeyVault to use
	#If it finds one it uses that, if not it creates a keyvault there using the AutomationAccountName
	##############################################################################################################
    Write-Host "Checking for KeyVault presence in $DXCMaintRGName"
    $GetKeyVault = Get-AzKeyVault -ResourceGroupName $DXCMaintRGName | Select-Object -ExpandProperty VaultName -First 1
    if (!($GetKeyVault)) {
        Write-Host "No Keyvault found in $DXCMaintRGName, looking in $ResourceGroupName..."
        $GetKeyVault = Get-AzKeyVault -ResourceGroupName $ResourceGroupName | Select-Object -ExpandProperty VaultName -First 1
	    if (!($GetKeyVault)) {
		    $keyVaultName = ("DXC-Maint-" + [Guid]::NewGuid().ToString().Substring(0,4) + "-KV")
		    Write-Host -Message "Key Vault not found. Creating the Key Vault $keyVaultName in $ResourceGroupName"
            $KeyVaultCreateResult = New-AzKeyVault -VaultName $keyVaultName -ResourceGroupName $ResourceGroupName -Location $LAWorkspaceRegion
		    if (!$KeyVaultCreateResult) {
			    Write-Host -Message "Key Vault $keyVaultName creation failed. Please fix and continue"
			    return
		    }
		    Start-Sleep -s 15     
	    }
	    Else{
		    $keyVaultName = $GetKeyVault
        }
    }
    else {
        $keyVaultName = $GetKeyVault   
    }
	Return $keyVaultName
}
Function GenerateCertFromKeyVault ([string]$CertName,[int]$LifetimeMonths,[string]$KVaultName ){
	#Log Progress
	Write-Host "Generating the cert using Keyvault...$KVaultName"


	#Set variables
	$certSubjectName = "cn=" + $CertName
	$PfxCertPlainPasswordForRunAsAccount = [Guid]::NewGuid().ToString().Substring(0, 8) + "!" 
	$PfxCertPathForRunAsAccount = Join-Path ./ ($CertName + ".pfx")

	$Policy = New-AzKeyVaultCertificatePolicy -SecretContentType "application/x-pkcs12" -SubjectName $certSubjectName  -IssuerName "Self" -ValidityInMonths $LifetimeMonths -ReuseKeyOnRenewal
	$AddAzureKeyVaultCertificateStatus = Add-AzKeyVaultCertificate -VaultName $KVaultName -Name $CertName -CertificatePolicy $Policy 

	While ($AddAzureKeyVaultCertificateStatus.Status -eq "inProgress") {
		Start-Sleep -s 10
		$AddAzureKeyVaultCertificateStatus = Get-AzKeyVaultCertificateOperation -VaultName $KVaultName -Name $CertName
	}

	if ($AddAzureKeyVaultCertificateStatus.Status -ne "completed") {
		Write-Host -Message "Key vault cert creation is not sucessfull and its status is: $status.Status" 
	}

	$secretRetrieved = Get-AzKeyVaultSecret -VaultName $KVaultname -Name $CertName
    $secretValueText = '';
    $ssPtr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($secretRetrieved.SecretValue)
    try {
        $secretValueText = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($ssPtr)
        }finally {
        [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ssPtr)
        }
    $secretByte = [Convert]::FromBase64String($secretValueText)
    $certCollection = New-Object -TypeName System.Security.Cryptography.X509Certificates.X509Certificate2($secretByte, "", "Exportable,PersistKeySet")
    $type = [System.Security.Cryptography.X509Certificates.X509ContentType]::Pfx
    $pfxFileByte = $certCollection.Export($type, $PfxCertPlainPasswordForRunAsAccount)
	[System.IO.File]::WriteAllBytes($PfxCertPathForRunAsAccount, $pfxFileByte)

	$CertObject = "" | Select-Object -Property Path,PlainPass
	$CertObject.Path = $PfxCertPathForRunAsAccount
	$CertObject.PlainPass = $PfxCertPlainPasswordForRunAsAccount
	Return $CertObject
}

Function CreateServicePrincipal([string]$PfxCertPath, [string]$PfxCertPlainPass, [string]$AppName, [string]$SubID){
	########################################################
	# Create SP to run jobs as
	########################################################
	Write-Host "Creating service principal..."

	$PfxCert = New-Object -TypeName System.Security.Cryptography.X509Certificates.X509Certificate2 -ArgumentList @($PfxCertPath, $PfxCertPlainPass)    
	$keyValue = [System.Convert]::ToBase64String($PfxCert.GetRawCertData())
	$KeyId = [Guid]::NewGuid() 
	$startDate = Get-Date
	$endDate = (Get-Date $PfxCert.GetExpirationDateString()).AddDays(-1)

	# Use Key credentials and create AAD Application
	$Application = New-AzADApplication -DisplayName $ApplicationDisplayName -HomePage ("http://" + $applicationDisplayName) -IdentifierUris ("http://" + $KeyId)
	$result = New-AzADAppCredential -ApplicationId $Application.ApplicationId -CertValue $keyValue -StartDate $startDate -EndDate $endDate 
	$result = New-AzADServicePrincipal -ApplicationId $Application.ApplicationId 

	# Sleep here for a few seconds to allow the service principal application to become active (should only take a couple of seconds normally)
	Start-Sleep -s 15

	$NewRole = $null
	$Retries = 0;
	While ($NewRole -eq $null -and $Retries -le 6) {
		$result = New-AzRoleAssignment -RoleDefinitionName Contributor -ServicePrincipalName $Application.ApplicationId -scope ("/subscriptions/" + $subscriptionId) -ErrorAction SilentlyContinue
		Start-Sleep -s 10
		$NewRole = Get-AzRoleAssignment -ServicePrincipalName $Application.ApplicationId -ErrorAction SilentlyContinue
		$Retries++;
	}
    return $PfxCert,$Application
}
# Displays user the Deployment, Removal, Documentation menu and allows selection
Function Start-Menu {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $true)]
        $runbookVersion,
        [Parameter(Mandatory = $true)]
        $runbookPath,
        [Parameter(Mandatory = $true)]
        $execRunbookPath,
        [Parameter(Mandatory = $true)]
        $subscriptions,
        [Parameter(Mandatory = $true)]
        $automationAccountName,
        [Parameter(Mandatory = $false)]
        $validationResult,
        [Parameter(Mandatory = $true)]
        $requiredModules,
        [Parameter(Mandatory = $true)]
        $runbookName,
        [Parameter(Mandatory = $true)]
        $execRunbookName,
        [Parameter(Mandatory = $true)]
        $runbookTags,
        [Parameter(Mandatory = $true)]
        $runbookScheduleNames,
        [Parameter(Mandatory = $true)]
        $resourceGroupName,
        [Parameter(Mandatory = $true)]
        $selectedTz,
        [Parameter(Mandatory = $true)]
        $workspaceName,
        [Parameter(Mandatory = $true)]
        $Action
    )
        if ($Action -match 'Install|Deploy|Remove|Update|Uninstall') {
        switch ($Action) {
            {$_ -match 'Install|Deploy|Update'} {
                Validate-LAWorkspace $subscriptions $workspaceName
                Set-RunbookTZRG $runbookPath $execRunbookPath $subscriptions $resourceGroupName $selectedTz $automationAccountName
                $validationResult = validateAutomationAccount $subscriptions $automationAccountName
                if ($validationResult) {
                    installAutomationAccount $validationResult $resourceGroupName $automationAccountName
                    automationAccountModuleValidationAndInstallation $subscriptions $resourceGroupName $automationAccountName $requiredModules
                    updateInstallPowerShellRunbook $subscriptions $resourceGroupName $automationAccountName $runbookName $execRunbookName $runbookTags $runbookScheduleNames $runbookPath $execRunbookPath $runbookVersion
                    Deploy-AlertRule $LAResourceGroup $workspaceName $LAWorkspaceRegion $runbookVersion $alertRuleJSONPath $alertRuleName
                } else {
                    Deploy-AlertRule $LAResourceGroup $workspaceName $LAWorkspaceRegion $runbookVersion $alertRuleJSONPath $alertRuleName
                    automationAccountModuleValidationAndInstallation $subscriptions $resourceGroupName $automationAccountName $requiredModules
                    updateInstallPowerShellRunbook $subscriptions $resourceGroupName $automationAccountName $runbookName $execRunbookName $runbookTags $runbookScheduleNames $runbookPath $execRunbookPath $runbookVersion
                }
            }
            {$_ -match 'Remove|Uninstall'} {
                Validate-LAWorkspace $subscriptions $workspaceName
                Start-SolutionRemoval $subscriptionId $LAResourceGroup $alertRuleName
            }
            default {Start-Menu $runbookVersion $runbookPath $execRunbookPath $subscriptions $automationAccountName $validationResult $requiredModules $runbookName $execRunbookName $runbookTags $runbookScheduleNames $resourceGroupName $selectedTz $workspaceName}        }
    }
}

Function checkUserInput {
    [CmdletBinding()]
    $userChoice = Read-Host "Do you want to continue? Type 'Y' for Yes, 'N' for No."
    if ($userChoice -eq 'Y') {
        return 1
    } elseif ($userChoice -eq 'N') {
        Write-Verbose "You have chosen to quit the script execution. Quitting." -Verbose
        pause 5
        break
    } else {
        Write-Verbose 'Invalid key registered. Valid options are: "Y" for Yes, you would like to continue and "N" for No, you would like to quit.' -Verbose
        checkUserInput
    }
}

# Alert rule and Automation Account removal function
Function Start-SolutionRemoval {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $True)]
        $subscriptionId,
        [Parameter(Mandatory = $True)]
        $LAResourceGroup,
        [Parameter(Mandatory = $True)]
        $alertRuleName
    )
    Select-AzSubscription -SubscriptionId $subscriptionId
    
    Write-Host "The VM StartStop solution is now going to be removed ... `n" -ForegroundColor Red
    if (Get-AzScheduledQueryRule -Name $alertRuleName -ResourceGroupName $LAResourceGroup) {
        Write-Host "Removing alert Rule $alertRuleName" -ForegroundColor Yellow
        Remove-AzScheduledQueryRule -Name $alertRuleName -ResourceGroupName $LAResourceGroup
    }
    Write-Host "Searching for Automation Account ..." -NoNewline -ForegroundColor DarkYellow
    $automationAccount = Get-AzAutomationAccount | Where-Object {$_.AutomationAccountName -eq "DXC-AutomationAccount-VMStartStop"}
    if ($automationAccount) {
        Write-Host " Automation Account DXC-AutomationAccount-VMStartStop found. Removing..." -ForegroundColor Green -NoNewline
        Remove-AzAutomationAccount -ResourceGroupName $automationAccount.ResourceGroupName -Name $automationAccount.AutomationAccountName -Force
        if (!$(Get-AzAutomationAccount | Where-Object {$_.AutomationAccountName -eq "DXC-AutomationAccount-VMStartStop"})) {
            Write-Host " OK" -ForegroundColor Green
        } else {
            Write-Host "Automation Account removal has failed. Please perform the removal manually." -ForegroundColor Red
        }
    } else {
        Write-Host "Nothing to remove in this subscription. Please select another subscription and run the removal again." -ForegroundColor Yellow
    }
}
# Validates if the Resource Group entered by the user is valid
Function Set-ResourceGroup {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $true)]
        $subscriptions,
        [Parameter(Mandatory = $true)]
        $resourceGroupName
    )
        Write-Host "Validating Resource Group $resourceGroupName ..." -ForegroundColor Yellow -NoNewline
    if (Get-AzResourceGroup -Name $resourceGroupName) {
        Write-Host " OK" -ForegroundColor Green
        Write-Host "Resource Group name $resourceGroupName is valid. " -ForegroundColor Yellow
        return (Get-AzResourceGroup -Name $resourceGroupName).ResourceGroupName
    } else {
        write-Host "Resouce Group name $userChoice is invalid and/or does not exist in subscription. " -ForegroundColor Red
        Set-ResourceGroup $subscriptions $resourceGroupName
        break
    }
    return (Get-AzResourceGroup -Name $resourceGroupName).ResourceGroupName
}

 # Get user input for time zone selection and setup Runbooks with RG and TZ variables
function Set-RunbookTZRG {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $true)]
        $RunbookPath,
        [Parameter(Mandatory = $true)]
        $execRunbookPath,
        [Parameter(Mandatory = $true)]
        $subscriptions,
        [Parameter(Mandatory = $true)]
        $resourceGroupName,
        [Parameter(Mandatory = $true)]
        $selectedTz,
        [Parameter(Mandatory = $true)]
        $automationAccountName
    )
    $global:resourceGroupName = Set-ResourceGroup $subscriptions $resourceGroupName
    #$selectedTz = Select-TimeZone
    $tzPattern = '$setTimeZone = ""'
    $rgPattern = '$automationAccountRG = ""'
    $acNamePattern = '$automationAccountName = ""'
    $setRg = '$automationAccountRG = '+ """$resourceGroupName"""
    $setTz = '$setTimeZone = "'+$selectedTz+'"'
    $setAcName = '$automationAccountName = '+ """$automationAccountName"""
    Write-Host "`n Setting up Resource Group and TimeZone variables to Runbooks ..." -NoNewline
    (Get-Content $execRunbookPath).Replace($tzPattern,$setTz) | Set-Content $execRunbookPath
    (Get-Content $runbookPath).Replace($rgPattern,$setRg).Replace($tzPattern,$setTz) | Set-Content $RunbookPath
    (Get-Content $runbookPath).Replace($rgPattern,$setRg).Replace($acNamePattern,$setAcName) | Set-Content $RunbookPath
    Write-Host " OK" -ForegroundColor Green
}

# Checks if the Automation Account is installed, if not - add it for install required list
function validateAutomationAccount {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $true)]
        $subscriptions,
        [Parameter(Mandatory = $true)]
        $automationAccountName
    )
    # variable init to store list of Automation Accounts to be installed
    foreach ($subscription in $subscriptions) {
        Write-Host "Validating $automationAccountName in subscription $subscription ..." -ForegroundColor Yellow
        $validateAutomationAccount = Get-AzAutomationAccount -ResourceGroupName $resourceGroupName -Name $automationAccountName -ErrorAction SilentlyContinue
        if (!$validateAutomationAccount) {
            write-Host "Detected that automation account $automationAccountName does not exist. `n" -foregroundcolor Yellow
            $global:installRequired += $subscription 
        } else {
            Write-Host "Detected that automation account $automationAccountName already exists. Checking for updates... `n" -foregroundcolor Yellow
        }
    }
    return $installRequired
}

# Function to install Automation Account and register the Automation Account to Diagnostics
function installAutomationAccount {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $true)]
        $validationResult,
        [Parameter(Mandatory = $true)]
        $resourceGroupName,
        [Parameter(Mandatory = $true)]
        $automationAccountName
    )

    if ($validationResult.Count -lt 1) {
        Write-Host "The Automation account $($automationAccountName) already exists. Running Module validations... " -ForegroundColor Yellow
    } else {
        foreach ($subscription in $validationResult) {
            Select-AzSubscription -Subscriptionid $subscription  | Out-Null
            Write-Host "Automation account $($automationAccountName) in subscription $($subscription) does not exist. Creating ..." -ForegroundColor Yellow -NoNewline
            $rgLocation = $(Get-AzResourceGroup -name $resourceGroupName).Location
            New-AzAutomationAccount -Name $automationAccountName -Location $rgLocation -ResourceGroupName $resourceGroupName | Out-Null
        }
    }
    if (Get-AzAutomationAccount -ResourceGroupName $resourceGroupName -Name $automationAccountName) {
        Write-Host " OK" -ForegroundColor Green
    }
    
    Write-Host "Registering Microsoft.Insights Resource Provider ..."
    Register-AzResourceProvider -ProviderNamespace Microsoft.Insights | Out-Null
    Write-Host "Associating the Automation Account with Azure Monitor . Getting Automation Account and LA Workspace IDs ..." -ForegroundColor Yellow -NoNewline
    
    Write-Host " OK" -ForegroundColor Green
    Write-Host "Enabling diagnostic logs for Automation Account ... `n" -ForegroundColor Yellow
    $resourceId = (Get-AzResource -ResourceType "Microsoft.Automation/automationAccounts" -Name $automationAccountName).ResourceId
    Set-AzDiagnosticSetting -ResourceId $resourceId -WorkspaceId $workspaceId -Enabled 1 | Out-Null
    Write-Host " OK" -ForegroundColor Green


}
# Install/Update Automation Account modules
function automationAccountModuleValidationAndInstallation {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $true)]
        $subscriptions,
        [Parameter(Mandatory = $true)]
        $resourceGroupName,
        [Parameter(Mandatory = $true)]
        $automationAccountName,
        [Parameter(Mandatory = $true)]
        $requiredModules
    )

    foreach ($subscription in $subscriptions) {
        #Select-AzSubscription -Subscriptionid $subscription
        foreach ($azmodule in $requiredModules) {
            $foundmodule = Find-Module -Name $azmodule
            Write-host "`n Sit back until we install the required modules for you... `n" -ForegroundColor Gray
            $azmoduleValidation = Get-AzAutomationModule -AutomationAccountName $automationAccountName -Name $foundmodule.Name -ResourceGroupName $resourceGroupName -ErrorAction SilentlyContinue
            if (!$azmoduleValidation) {
                Write-host "`n $azmodule is not installed in Automation Account $automationAccountName in subscription $subscription. This might take a while..." -ForegroundColor Gray
                $foundmodule = Find-Module -Name $azmodule
                $uri = $foundmodule.RepositorySourceLocation + "/package/" + $foundmodule.Name + "/" + $foundmodule.Version
                New-AzAutomationModule -ResourceGroupName $resourceGroupName -AutomationAccountName $automationAccountName -Name $foundmodule.Name -ContentLinkUri $uri | Out-Null
                do  {
                    Write-Host "Progress: Module $azmodule state" -nonewline
                    Write-Host " $($(Get-AzAutomationModule -AutomationAccountName $automationAccountName -Name $foundmodule.Name -ResourceGroupName $resourceGroupName).ProvisioningState)" -ForegroundColor Yellow
                    Start-Sleep -Milliseconds 20000
                    } while ($(Get-AzAutomationModule -AutomationAccountName $automationAccountName -Name $foundmodule.Name -ResourceGroupName $resourceGroupName).ProvisioningState -notmatch "Succeeded|Failed")
                Write-Host "Progress: Module $azmodule in automation account $automationAccountName processing has been finished. " -ForegroundColor Green
            } else {
                Write-Host "$azmodule is installed in Automation Account $automationAccountName in subscription $subscription. Checking for updated modules..." -ForegroundColor Gray
                $installedModule = Get-AzAutomationModule -AutomationAccountName $automationAccountName -Name $foundmodule.Name -ResourceGroupName $resourceGroupName
                $installedModuleVersion = $($installedModule.Version).ToString()
                $azmoduleInformation = Find-Module -Name $azmodule
                $azmoduleVersion = $($azmoduleInformation.version).ToString()

                if ($installedModuleVersion -lt $azmoduleVersion) {
                    Write-Host "An outdated module $azmodule has been found on $automationAccountName in subscription $subscription. This might take a while. " -ForegroundColor Gray
                    Write-host "`n Sit back until we update the modules for you... `n" -ForegroundColor Gray 
                    $foundmodule = Find-Module -Name $azmodule
                $uri = $foundmodule.RepositorySourceLocation + "/package/" + $foundmodule.Name + "/" + $foundmodule.Version
                New-AzAutomationModule -ResourceGroupName $resourceGroupName -AutomationAccountName $automationAccountName -Name $foundmodule -ContentLinkUri $uri | Out-Null
                    do {
                        Write-Host "Progress: Module $azmodule state" -nonewline
                        Write-Host " $($(Get-AzAutomationModule -AutomationAccountName $automationAccountName -Name $azmodule -ResourceGroupName $resourceGroupName).ProvisioningState)" -ForegroundColor Yellow
                        Start-Sleep -Milliseconds 20000
                    } while ($(Get-AzAutomationModule -AutomationAccountName $automationAccountName -Name $azmodule -ResourceGroupName $resourceGroupName).ProvisioningState -ne "Succeeded")
                    Write-Host "Progress: Module $azmodule in automation account $automationAccountName has been updated successfully. " -ForegroundColor Green
                } else {
                    Write-Host "Module $azmodule on $automationAccountName in subscription $subscriptions is up-to-date. No action required." -ForegroundColor Yellow
                }
            }
        }
    }
}

# Import/Update Powershell Runbooks based on their version and assign the schedulers
function updateInstallPowerShellRunbook {
    [CmdletBinding()]
    Param (
        [Parameter(Mandatory = $true)]
        $subscriptions,
        [Parameter(Mandatory = $true)]
        $resourceGroupName,
        [Parameter(Mandatory = $true)]
        $automationAccountName,
        [Parameter(Mandatory = $true)]
        $runbookName,
        [Parameter(Mandatory = $true)]
        $execRunbookName,
        [Parameter(Mandatory = $true)]
        $runbookTags,
        [Parameter(Mandatory = $true)]
        $runbookScheduleNames,
        [Parameter(Mandatory = $true)]
        $runbookPath,
        [Parameter(Mandatory = $true)]
        $execRunbookPath,
        [Parameter(Mandatory = $true)]
        $runbookVersion
    )
    if (!$(Get-AzAutomationRunbook -ResourceGroupName $resourceGroupName -AutomationAccountName $automationAccountName -Name $runbookName -ErrorAction SilentlyContinue) -or !$(Get-AzAutomationRunbook -ResourceGroupName $resourceGroupName -AutomationAccountName $automationAccountName -Name $execRunbookName -ErrorAction SilentlyContinue)) 
    {
        Write-Host "`n Runbook $runbookName or $execRunbookName on $automationAccountName in subscription $subscriptions does not exist. Deploying... `n" -ForegroundColor Yellow
        Write-Host "Creating Runbook $runbookName ..." -NoNewline -ForegroundColor Yellow
        New-AzAutomationRunbook -AutomationAccountName $automationAccountName -Name $runbookName -ResourceGroupName $resourceGroupName -LogProgress $true -LogVerbose $true -Type PowerShell | Out-Null
        Write-Host "importing Runbook $runbookName ..." -NoNewline -ForegroundColor Yellow
        Import-AzAutomationRunbook -Path $runbookPath -Tags $runbookTags -ResourceGroup $resourceGroupName -AutomationAccountName $automationAccountName -Type PowerShell -Description $runbookVersion -Published -Force | Out-Null
        Write-Host " OK `n" -ForegroundColor Green
        Write-Host "Creating Runbook $execRunbookName ..." -NoNewline -ForegroundColor Yellow
        New-AzAutomationRunbook -AutomationAccountName $automationAccountName -Name $execRunbookName -ResourceGroupName $resourceGroupName -LogProgress $true -LogVerbose $true -Type PowerShell | Out-Null
        Write-Host "importing Runbook $execRunbookName ..." -NoNewline -ForegroundColor Yellow
        Import-AzAutomationRunbook -Path $execRunbookPath -Tags $runbookTags -ResourceGroup $resourceGroupName -AutomationAccountName $automationAccountName -Type PowerShell -Description $runbookVersion -Published -Force | Out-Null
        Write-Host " OK `n" -ForegroundColor Green
        Write-Host "Deploying and assigning schedulers to $runbookName" -NoNewline -ForegroundColor Yellow
        [int]$schedulerTime = 120
        $startTime = [string]$(Get-Date).Hour +":00"
        $runbookScheduleNames | ForEach-Object {
            New-AzAutomationSchedule -AutomationAccountName $automationAccountName -Name $_ -ResourceGroupName $resourceGroupName -StartTime $($(Get-Date $startTime).AddMinutes($schedulerTime)) -HourInterval 1 | Out-Null
            Register-AzAutomationScheduledRunbook -AutomationAccountName $automationAccountName -ResourceGroupName $resourceGroupName -RunbookName $runbookName -ScheduleName $_ | Out-Null
            [int]$schedulerTime += 30
        }
        Write-Host " OK" -ForegroundColor Green
        
        if ($(Get-AzAutomationRunbook -ResourceGroupName $resourceGroupName -AutomationAccountName $automationAccountName -Name $runbookName -ErrorAction SilentlyContinue) `
        -and $(Get-AzAutomationRunbook -ResourceGroupName $resourceGroupName -AutomationAccountName $automationAccountName -Name $execRunbookName -ErrorAction SilentlyContinue)) {
            Write-Host " `n Runbook $runbookName on $automationAccountName in subscription $subscriptions has been deployed successfully. `n" -ForegroundColor Green
        } else {
            Write-Host " `n Error: The automation Account Runbook deployment has been unsuccessful." -ForegroundColor Red
        }

    }
    else {
        Write-Host "`n Runbook $runbookName on $automationAccountName in subscription $subscriptions exists. Checking for an updated version ..." -ForegroundColor DarkGreen
        if ($(Get-AzAutomationRunbook -ResourceGroupName $resourceGroupName -AutomationAccountName $automationAccountName -Name $runbookName -ErrorAction SilentlyContinue).Description -lt $runbookVersion `
        -or $(Get-AzAutomationRunbook -ResourceGroupName $resourceGroupName -AutomationAccountName $automationAccountName -Name $execRunbookName -ErrorAction SilentlyContinue).Description -lt $runbookVersion) {
            Write-Host "Updating Runbook $runbookName ..." -NoNewline -ForegroundColor Yellow
            Import-AzAutomationRunbook -Path $runbookPath -Tags $runbookTags -ResourceGroup $resourceGroupName -AutomationAccountName $automationAccountName -Type PowerShell -Description $runbookVersion -Published -Force | Out-Null
            Write-Host " OK" -ForegroundColor Green
            Write-Host "Updating Runbook $execRunbookName ..." -NoNewline -ForegroundColor Yellow
            Import-AzAutomationRunbook -Path $execRunbookPath -Tags $runbookTags -ResourceGroup $resourceGroupName -AutomationAccountName $automationAccountName -Type PowerShell -Description $runbookVersion -Published -Force | Out-Null
            Write-Host " OK" -ForegroundColor Green
            if ($(Get-AzAutomationRunbook -ResourceGroupName $resourceGroupName -AutomationAccountName $automationAccountName -Name $runbookName -ErrorAction SilentlyContinue).Description -eq $runbookVersion `
            -and $(Get-AzAutomationRunbook -ResourceGroupName $resourceGroupName -AutomationAccountName $automationAccountName -Name $execRunbookName -ErrorAction SilentlyContinue).Description -eq $runbookVersion) {
                Write-Host "The Runbooks have been successfully updated to version $runbookVersion" -ForegroundColor Green
            }
        } else {
            Write-Host "No updates are available. Skipping." -ForegroundColor Yellow
        }
    }

}
# Function to deploy alert rule
Function Deploy-AlertRule {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $true)]
        $LAResourceGroup,
        [Parameter(Mandatory = $true)]
        $workspaceName,
        [Parameter(Mandatory = $true)]
        $LAWorkspaceRegion,
        [Parameter(Mandatory = $true)]
        $runbookVersion,
        [Parameter(Mandatory = $true)]
        $alertRuleJSONPath,
        [Parameter(Mandatory = $true)]
        $alertRuleName
    )
    Write-Host "Deploying $alertRuleName Alert Rule..."
    try {
        New-AzResourceGroupDeployment -Name $alertRuleName -ResourceGroupName $LAResourceGroup -TemplateFile $alertRuleJSONPath -eventProcessingSchema $eventProcessingSchema -omsWorkspaceName $workspaceName -omsWorkspaceLocation $LAWorkspaceRegion -alertVersion $runbookVersion
    }
    catch {
        $_.Exception.Message
    }
    finally {
        Write-Host "The StartStopVMAlertRule Alert Rule has been successfully deployed to $LAResourceGroup resource group"
    }

}
# GUI to allow the user to select the time zone
Function Get-TZ {
    Param(
        [Parameter(Mandatory = $true)]
        $selectedTz
    )
    if ((Get-TimeZone -ListAvailable | Where-Object {$_.id -eq $selectedTz})){
    Write-Host "The time zone $selectedTz is valid."
    return $selectedTz
    }
    else {
        $selectedTz = Read-Host "Please input a correct time zone. For a full list of time zones, please refer to https://docs.microsoft.com/en-us/windows-hardware/manufacture/desktop/default-time-zones"
        Get-TZ $selectedTz
    }
}
# Main Function to start up the script
Function Start-Script {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $true)]
        $runbookVersion,
        [Parameter(Mandatory = $true)]
        $runbookPath,
        [Parameter(Mandatory = $true)]
        $execRunbookPath,
        [Parameter(Mandatory = $true)]
        $subscriptions,
        [Parameter(Mandatory = $true)]
        $automationAccountName,
        [Parameter(Mandatory = $false)]
        $validationResult,
        [Parameter(Mandatory = $true)]
        $requiredModules,
        [Parameter(Mandatory = $true)]
        $runbookName,
        [Parameter(Mandatory = $true)]
        $execRunbookName,
        [Parameter(Mandatory = $true)]
        $runbookTags,
        [Parameter(Mandatory = $true)]
        $runbookScheduleNames,
        [Parameter(Mandatory = $true)]
        $resourceGroupName,
        [Parameter(Mandatory = $true)]
        $selectedTz,
        [Parameter(Mandatory = $true)]
        $workspaceName,
        [Parameter(Mandatory = $true)]
        $Action
    )
    #checkUserInput
    # Display menu
    Start-Menu $runbookVersion $runbookPath $execRunbookPath $subscriptions $automationAccountName $validationResult $requiredModules $runbookName $execRunbookName $runbookTags $runbookScheduleNames $resourceGroupName $selectedTz $workspaceName $Action
    if ($global:resourceGroupName) {
      #  $selfSignedCertPassword = [System.Web.Security.Membership]::GeneratePassword(16,2)
      #  Create-AzureRunAsAccount $global:resourceGroupName $automationAccountName "VMStartStop" $subscriptionId $false $selfSignedCertPassword
        Write-Host "`n Resetting Runbooks to their original state..." -NoNewline
        # Resets the Runbook Timezone and Resource Group variables to the original values for reuse
        $rgLine = Get-Content $runbookPath | Select-String -Pattern "\`$automationAccountRG = " | Select -ExpandProperty line
        $tzLine = Get-Content $runbookPath | Select-String -Pattern "\`$setTimeZone = " | Select -ExpandProperty line
        $acNameLine = Get-Content $runbookPath | Select-String -Pattern "\`$automationAccountName = " | Select -ExpandProperty line
        $rgPattern = '$automationAccountRG = ""'
        $tzPattern = '$setTimeZone = ""'
        $acNamePattern = '$automationAccountName = ""'
        (Get-Content $runbookPath).Replace($rgLine,$rgPattern).Replace($tzLine,$tzPattern).Replace($acNameLine,$acNamePattern) | Set-Content $RunbookPath
        $tzLine = Get-Content $execRunbookPath | Select-String -Pattern "\`$setTimeZone = " | Select -ExpandProperty line
        (Get-Content $execRunbookPath).Replace($tzLine,$tzPattern) | Set-Content $execRunbookPath
        Write-Host " OK" -ForegroundColor Green
    }
}

# Start the script.
Start-Script $runbookVersion $runbookPath $execRunbookPath $subscriptions $automationAccountName $validationResult $requiredModules $runbookName $execRunbookName $runbookTags $runbookScheduleNames $resourceGroupName $selectedTz $workspaceName $Action
[String] $ApplicationDisplayName = "$AutomationAccountName"
[int] $NoOfMonthsUntilExpired = 36
$CertifcateAssetName = "AzureRunAsCertificate"
$CertificateName = $AutomationAccountName + $CertifcateAssetName
Write-Output "1 - Finding or Creating Keyvault"
$NameOfKeyVault = FindOrCreateKeyvault -ResourceGroupName $resourceGroupName -UniqueID $AutomationAccountName -LAWorkspaceRegion $LAWorkspaceRegion -DXCMaintRGName $DXCMaintRGName
write-output $NameOfKeyVault
##############################################################################################################
Write-Output "2 - Generating Certificate $CertificateName"
$CertDetails = GenerateCertFromKeyVault -CertName $CertificateName -LifetimeMonths 12 -KVaultName $NameOfKeyVault
##############################################################################################################
Write-Output "3 - Creating Service Principal"
$spOutputs = CreateServicePrincipal -PfxCertPath $CertDetails.Path -PfxCertPlainPass $CertDetails.PlainPass -AppName $ApplicationDisplayName -SubID $SubscriptionId
$spPfxCert = $spOutputs[0]
$Application = $spOutputs[1]
##############################################################################################################
Write-Output "4b - Creating Certificate in the Automation Account Asset..."
# Create the automation certificate asset
$CertPassword = ConvertTo-SecureString $CertDetails.PlainPass -AsPlainText -Force   
$result = New-AzureRmAutomationCertificate -ResourceGroupName $resourceGroupName -automationAccountName $AutomationAccountName -Path $CertDetails.Path -Name $CertifcateAssetName -Password $CertPassword -Exportable  | write-verbose

##############################################################################################################
# Populate the ConnectionFieldValues
$ConnectionTypeName = "AzureServicePrincipal"
$ConnectionAssetName = "AzureRunAsConnection"
$ApplicationId = $Application.ApplicationId 
$SubscriptionInfo = Get-AzSubscription -SubscriptionId $subid
$TenantID = $SubscriptionInfo | Select-Object TenantId -First 1
$Thumbprint = $spPfxCert.Thumbprint
$ConnectionFieldValues = @{"ApplicationId" = $ApplicationID; "TenantId" = $TenantID.TenantId; "CertificateThumbprint" = $Thumbprint; "SubscriptionId" = $SubscriptionId} 

############################################################################################################################################
# Create a Automation connection asset named AzureRunAsConnection in the Automation account. This connection uses the service principal.   
Write-Output "4c - Creating Connection in the Automation Account Asset..."
$connectionFieldValues
write-host "break"
$result = New-AzAutomationConnection -ResourceGroupName $resourceGroupName -automationAccountName $AutomationAccountName -Name $connectionAssetName -ConnectionTypeName $connectionTypeName -ConnectionFieldValues $connectionFieldValues 
Remove-Item -Path ./$automationAccountName$CertifcateAssetName.pfx  


Write-Host "Script has finished. "
pause
