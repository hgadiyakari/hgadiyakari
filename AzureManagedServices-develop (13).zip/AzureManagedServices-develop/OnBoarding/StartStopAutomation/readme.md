[Update] Confluence Spike link:

https://confluence.dxc.com/display/CSA/AZR-15074+-+Add+Support+for+Monthly+schedules+and+develop+non-interactive+deployment

Jira Spike:

https://jira.dxc.com/browse/AZR-15074

If the RunAsAccount does not deploy:

manually create the Run As Account in the automation account and will all work as expected.
