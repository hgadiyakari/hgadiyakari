# ExpressRoute Circuit deploy

### Template information
- expressroutecircuitdeploy.json
- Template for deploying New ExpressRouteCircuit and New ExpressRouteGateway and setups their diagnostic settings for Log Analytics integration

### Requirements to deploy template:
  - All objects must be in the same subscription
  - Every Name should be provided by requester and according to client standards
  - vNet Resource Group, vNet, ExpressRouteCircuit and New ExpressRouteGateway must be in the same Location 
  - Resources must be created(or present) prior this deployment:
    - Resource Group for ExpressRouteCircuit and ExpressRouteGateway (Resource Group can be the same as vNET RG)
    - vNet Resource Group, vNet and GatewaySubnet (subnet must be Gateway type, no other gateways can be pressent)
    - Log Analytics Resource Group and Log Analytics Workspace

### Steps to fill in template:
1. Select <b>Subscription</b>, this is mandatory and should be the same for all components in this template.
2. Select <b>Resource group</b> for ExpressRouteCircuit and ExpressRouteGateway
3. Select <b>Location</b> for ExpressRouteCircuit and ExpressRouteGateway
4. Enter information that is starting with Express Route for ExpressRoute Circuit
5. Enter information that is starting with Gateway for ExpressRoute Gateway
6. New Public IP address name (leave default for automatic code to work or change as per client naming standards)
7. <b>Log Analytics workspace name</b>
8. <b>Log Analytics resource group</b>
Next step: 'Accept Terms and Conditions', press Purchace(deploy) button

<IMG SRC=expressroutecircuitdeploy.png>
