# DXC CPS Azure Healthcare Cloud Hub Blueprint

### Overview

This document explains how to import and publish the hub blueprint. Steps to deploy Hub blueprint noted below.

##### Step 1 - Pre-Deployment

Install necessary modules

```
Install-Module -Name Az.Blueprint -Scope CurrentUser
```

##### Step 2 - Create a user-assigned managed identity

Create a user-assigned managed identity to run the blueprint

```
Install-Module -Name Az.ManagedServiceIdentity -AllowClobber -Scope CurrentUser
Import-Module Az.ManagedServiceIdentity
enable-azurermalias
New-AzResourceGroup BluePrintMI "West Central US"
$myUAI = New-AzUserAssignedIdentity -ResourceGroupName BluePrintMI -Name BluePrintMI
New-AzRoleAssignment -ObjectId $myUAI.PrincipalId -RoleDefinitionName Owner

```

#####  Step 3 - Blueprint Deployment

```
#Import Azure Blueprint Module
Import-Module Az.Blueprint

#Login to Powershell 
Connect-AzAccount -UseDeviceAuthentication

#Set your working subscription
Set-AzContext -SubscriptionId xxxxxxx-xxxxxxx-xxxxxxx-xxxxxxx-xxxxxxx

#Import the Blueprint from your current blueprint directory where you have Blueprint.json
Import-AzBlueprintWithArtifact -Name ExampleBP -SubscriptionId xxxxxxx-xxxxxxx-xxxxxxx-xxxxxxx-xxxxxxx -InputPath "C:\Users\..."  .

#Set varibale to publish the blueprint 
$bp = Get-AzBlueprint -name "DevArchetypesHubBlueprint" -ManagementGroupId "xxxxxxx-xxxxxxx-xxxxxxx-xxxxxxx-xxxxxxx"

#Publish version 1.0
Publish-AzBlueprint -Blueprint $bp -Version 1.0
```

##### Update Parameters in the blueprint 

Navigate to the blueprint section in the Azure portal, Edit the Hub blueprint to update the necessary parameter values. Save the blueprint as a draft and publish a new version.

Assign blueprint and select User assigned managed identity that was assigned during previous steps. Click Assign to deploy the blueprint.

NOTE: The tag parameter in "az-hub-rg-tag" accepts the following format. 
{"Owner":"exampleowner@<area>email.com"}

This will create an 'Owner' tag and the associated value will be 'exampleowner@<area>email.com'.
