# Management Blueprint
This blueprint creates 1 VNet, 3 subnets, 2 Jump servers, 2 empty VMs for Active Directory, 1 NSG, UDR route to hub FW and peering back to the hub VNet.

The 'example-parameters' file can be used as a reference to help fill in the parameters required. The 'NSG-parameters' file can be amended and copied directly into the 'networksecuritygroupsettings' parameters found in the 'Amgmt' template before deploying the blueprint.

## Example deployment using PS

1. Login first with Connect-AzAccount if not using Cloud Shell

```Connect-AzAccount```

2. Install the Azure Blueprints module from PowerShell Gallery

```Install-Module -Name Az.Blueprint```

3. Set your working subscription

```Set-AzContext -SubscriptionId "xxxxxxx-xxxxxxx-xxxxxxx-xxxxxxx-xxxxxxx```

4. Import blueprint to Azure from your local directory

```Import-AzBlueprintWithArtifact -Name XXXXXXXXXX -SubscriptionId XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX -InputPath C:\XXXX\XXXX```

5. Publish a new version of the blueprint definition so it can be assigned

- Get the blueprint we imported 
```$bp = Get-AzBlueprint -SubscriptionId XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX -Name TestBP ```
- Publish version 1.0
```Publish-AzBlueprint -Blueprint $bp -Version 1.0```


