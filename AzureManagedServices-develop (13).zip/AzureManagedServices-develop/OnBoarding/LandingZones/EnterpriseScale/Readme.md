
# Enterprise Scale Landing Zone

This folder contains the artifacts to deploy the DXC implementation of Microsoft's Enterprise Scale Landing Zone (ESLZ) based on their Cloud Adoption Framework (CAF)
More details can be found here

https://docs.microsoft.com/en-us/azure/cloud-adoption-framework/ready/enterprise-scale/

and here

https://docs.microsoft.com/en-us/azure/cloud-adoption-framework/


## Example Blueprint deployment using Powershell

1. Install necessary modules for Blueprint deployment

```Install-Module -Name Az.Blueprint```

```Install-Module -Name Az.ManagedService Identity -AllowPrerelease```
 
2. Set active subscription
```Set-AzContext -SubscriptionId```
 
3. Create resource group and managed identity
```New-AzResourceGroup -Name bpidentity -Location uksouth```

```New-AzUserAssignedIdentity -ResourceGroupName bpidentity -Name bpuser```
 
4. Get object id of managed Identity
```Get-AzADServicePrincipal -DisplayName bpuser```
 
5. Set 'Owner' permission to subscription/s
```New-AzRoleAssignment -ObjectId xxxxxx-xxxx-xxxx-xxxx-xxxxxxx -RoleDefinitionName owner```


Now managed identity and permissions are in place, we are ready to import the blueprint into Azure and assign it.

5. Login
```Connect-AzAccount```
 
6. Import blueprint to Azure from your local directory
```Import-AzBlueprintWithArtifact -Name XXXXXXXXXX -SubscriptionId XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX -InputPath C:\XXXX\XXXX```
 
7. Get the blueprint we imported
```Import-AzBlueprintWithArtifact -Name XXXXXXXXXX -SubscriptionId XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX -InputPath C:\XXXX\XXXX```
 
8. Publish
```Publish-AzBlueprint -Blueprint $bp -Version 1.0```
