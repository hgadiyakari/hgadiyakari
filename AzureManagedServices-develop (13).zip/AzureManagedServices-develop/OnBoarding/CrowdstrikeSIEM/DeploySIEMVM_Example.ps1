<#
	.SYNOPSIS
		Provided for test purposes.
	.NOTES
		Author:	Graham Masters
		Date:	2021/04/06
#>

$ErrorActionPreference = "stop"
$PSDefaultParameterValues['Out-File:Encoding'] = 'ascii'

###########################################
# Set these parameters

$TenantId 			= "<update this>"		# Update this variable
$SubscriptionID 		= "<update this>"		# Update this variable
$DeploymentLocation		= "EastUS"

$CustomerCompanyCode 		= "MS4A"			# Example

$MaintenanceResourceGroup 	= "DXC-Maint-RG"		# MS4A Standard

$scriptpath 			= "<update this>"		# Update this variable  e.g. C:\scripts\test

# 
$vnetname			= "DXC-MS4A-eus-vnet"	# Example
$subnetname			= "DXC-MS4A-eus-snet"	# Example
$DiagStgName			= "dxcms4aeus1a96st"	# Example

$SIEMRootUser			= "csadmin"		# Update this variable as required
$SIEMRPass			= ConvertTo-SecureString "<update this>" -AsPlainText -Force   # Update this variable

$SIEMCID			= "D37C5F63236A4FE69DEABB9893DCF41D-D3" # Example test environment
$SIEMAPICLIENTID		= "apiclientid"		# Example test environment
$SIEMAPICLIENTSECRET		= "apiclientsecret" 	# Example test environment
$SIEMAPPID			= "csappid"		# Example test environment

$HostIp				= "null"		# Option (a) If = "null" then sieminstaller.sh will ignore and set send_to_syslog_server = false.
							# Option (b) If set to a v4 IP (e.g. = "10.58.0.4") sieminstaller.sh will set host ip and syslog_server = true

$CSSiemVMTemplateFile 		= "$scriptpath\crowdstrikeSiemVM.json"

#$dxcLogAnalyticsWorkspaceName = "..." 			#Optionally set this here or allow the logic below to set this

#
###########################################

try {
	Connect-AzAccount  -Tenant $TenantId -Subscription $SubscriptionID
	
	if ($null -eq $dxcLogAnalyticsWorkspaceName) {
		$dxcLogAnalyticsWorkspaceName = 'DXC-' + $CustomerCompanyCode + '-' + $SubscriptionID.Substring(0,4) + '-loganalyticsWorkspace'
	}
	
	$WorkspaceID = (Get-AzOperationalInsightsWorkspace -Name $dxcLogAnalyticsWorkspaceName -ResourceGroupName $MaintenanceResourceGroup).CustomerId.Guid
	$WorkspaceKey = (Get-AzOperationalInsightsWorkspaceSharedKey -Name $dxcLogAnalyticsWorkspaceName -ResourceGroupName $MaintenanceResourceGroup).PrimarySharedKey

	<#
	# This type of logic is required for CIS images 
	$template = Get-Content -Raw -Path $CSSiemVMTemplateFile | ConvertFrom-Json
	Get-AzMarketplaceTerms -Publisher $template.resources.plan.publisher -Product $template.resources.plan.product -Name $template.resources.plan.name | Set-AzMarketplaceTerms -Accept
	#>
	
	$SIEMvmName = "DXC-$CustomerCompanyCode-Siem"

	New-AzResourceGroupDeployment -ResourceGroupName $MaintenanceResourceGroup `
		-TemplateFile $CSSiemVMTemplateFile `
		-rootUsername $SIEMRootUser -rootPassword $SIEMRPass  `
		-vmName $SIEMvmName -vmLocation $DeploymentLocation `
		-existingBootDiagStorageResourceGroup $MaintenanceResourceGroup `
		-existingBootDiagStorageName $DiagStgName  -existingvNetResourceGroup $MaintenanceResourceGroup `
		-existingvNetName $vNetName -subnetName $SubnetName `
		-workspaceId $WorkspaceID -workspaceKey $WorkspaceKey  `
		-csCID $SIEMCID -csAPIclientID $SIEMAPICLIENTID `
		-csAPIclientSecret  $SIEMAPICLIENTSECRET  -csAPPid $SIEMAPPID `
		-csForwardToHost $HostIp
} catch {
	$_
	Write-Error "Siem VM creation failed[-1]"
	exit -1
}
