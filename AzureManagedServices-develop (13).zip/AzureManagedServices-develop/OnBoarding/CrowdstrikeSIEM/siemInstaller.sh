#!/bin/bash
# ----------------------------------------------------------
# Purpose:   SIEM Connector Installer
# Author:    Chris Neale
# Date:      3rd September 2020
#
# Updated:   Graham Masters
# Date:      19th March 2021
# Change     Added optional parameters for forwarding host, port and protocol
# ----------------------------------------------------------
usage ()
{
  echo 'Usage : sieminstaller.sh <appid> <apiclientid> <apiclientsecret> [-h <host ip address>|<host fqdn>|null|<empty> [-p <port>|null|<empty>] [-t udp|tcp|null|<empty>]]'
}

if [[ $# -ge 3 && $1 != -* && $2 != -* && $3 != -* ]]; then
  APPID=$1
  APICLIENTID=$2
  APICLIENTSECRET=$3
  shift 3
else
  usage
  exit 1
fi

# defaults
LOGFILE="/var/tmp/CSfalcon.log"
CFGFILE="/opt/crowdstrike/etc/cs.falconhoseclient.cfg"

while [[ $# -gt 0 ]]; do
key="$1"
case $key in
    -h|--host)
    if [[ ! $2 =~ -.*|null ]]; then
		HOST="$2"
		shift # past argument
	elif [[ $2 = null ]];then
		shift # past argument
	fi
    shift # past value
    ;;
    -p|--port)
    if [[ $2 =~ [0-9]+ ]]; then
		PORT="$2"
		shift # past argument
	elif [[ $2 = null ]];then
		shift # past argument
	fi
    shift # past value
    ;;
    -t|--protocol)
    if [[ $2 =~ udp|tcp ]]; then
      PROTOCOL="$2"
      shift # past argument
    elif [[ ! $2 =~ -.* ]]; then # other text such as -t null or -t foo.  Ignore and skip over it
		shift
	fi
	
    shift # past value
    ;;
    -c|--configurationfile)
    if [[ ! $2 =~ -.* ]]; then
	  CFGFILE=$2
      shift # past argument
    fi
    shift # past value
    ;;
    -l|--logfile)
    if [[ ! $2 =~ -.* ]]; then
      LOGFILE=$2
	  shift # past argument
    fi
    shift # past value
    ;;
    *)    # unknown option
    usage
	exit 1
    ;;
esac
done



echo "################################################################" >> ${LOGFILE}
echo "Deployment date and Time: `date`" >> ${LOGFILE}
echo "################################################################" >> ${LOGFILE}

echo "APPID: ${APPID}"  			>> ${LOGFILE}
echo "APICLIENTID: ${APICLIENTID}"  >> ${LOGFILE}
echo "HOST: ${HOST}"  				>> ${LOGFILE}
echo "PORT: ${PORT}"  				>> ${LOGFILE}
echo "PROTOCOL: ${PROTOCOL}"  		>> ${LOGFILE}


# Setting variables
SIEMURL="https://dxcazuretoolsdev.blob.core.windows.net/installers/SiemConnector/cs.falconhoseclient-2.4.0+001-1.el7.x86_64.rpm"
SIEMRPM="cs.falconhoseclient-2.4.0+001-1.el7.x86_64.rpm"

# Download and install SIEM RPM
 
# Download SIEM Connector
wget -O ${SIEMRPM} ${SIEMURL}
ErrorCode="$?"
echo "Primary Download Operation retcode (${ErrorCode})" >> ${LOGFILE}

# Install SIEM Connector
sudo rpm -Uvh ${SIEMRPM}

# Configure SIEM Connector

# Update Logging configuration to output_format=syslog, rotate_file=true, max_backups=5
sudo sed -e 's/output_format = json/output_format = syslog/' -e 's/max_backups = 10/max_backups = 5/' -i ${CFGFILE}
# Update api client id and secret and also AppID
sudo sed -e "s/client_id =/client_id = ${APICLIENTID}/" -e "s/client_secret =/client_secret = ${APICLIENTSECRET}/" -e "s/app_id = SIEM-Connector-v2.0.0/app_id = ${APPID}/" -i ${CFGFILE}

# Update log forwarding
if  [ $HOST ]; then
	sudo sed -r "s/send_to_syslog_server *= *false/send_to_syslog_server = true/" -i ${CFGFILE}
	sudo sed -r "s/^host *= *.+$/host = ${HOST}/" -i ${CFGFILE}
else
	sudo sed -r "s/send_to_syslog_server *= *true/send_to_syslog_server = false/" -i ${CFGFILE}
fi
if  [ $PORT ]; then
	sudo sed -r "s/^port *= *[0-9]* *$/port = ${PORT}/" -i ${CFGFILE}
fi
if  [ $PROTOCOL ]; then
	sudo sed  -r "s/^protocol = (udp|tcp) *$/protocol = ${PROTOCOL}/" -i ${CFGFILE}
fi


# Start the SIEM Connector
sudo service cs.falconhoseclientd start
