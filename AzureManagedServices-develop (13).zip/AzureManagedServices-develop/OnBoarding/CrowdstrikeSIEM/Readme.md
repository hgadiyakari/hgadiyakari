# Onboarding Resources

This folder contains ARM templates used for OnBoarding new subscriptions to the Managed Services for Azure offering  
  
<IMG SRC="images/Azure Virtual Network_COLOR.png" width="40" height="40" align=left>
<IMG SRC="images/Network Security Group_COLOR.png" width="40" height="40" align=left>
<IMG SRC="images/Azure Virtual Machine_COLOR.png" width="40" height="40">

## Template list and purposes

- crowdstrikeSiemVnetNsg.json - This template creates, or updates, the vNet, Subnet and NSG to which the SIEM Connector VM is deployed
- crowdstrikeSiemVM.json - This template creates the RedHat Linux VM which runs the Crowdstrike SIEM Connector application to pull logs down from Crowdstrike.com
- siemInstaller.sh - This script installs and configures the SIEM connector  

## Deployment Instructions

 Requirements:

- **Powershell Core 7.x and the AZ Modules**  
 If you do not have those, download and install them from Microsoft.  
 Powershell Core runs on Linux as well as Windows.  
 Both are also available in Azure Cloud Shell.  
- Download the latest offering code Master branch from Github to your deployment environment (pc or cloud shell)  
- Follow the instructions in each section below.

### SIEM Connector Deployment (VNET+NSG+VM)

#### Step1: Deploy the virtual network and Network Security Group for SIEM VM

By default, the SIEM vNet uses the 
* Name DXC-Maint-Vnet
* Address range 10.100.0.0/24
* Subnet 10.100.1.0/24
* Subnet name DXC-SIEM-Subnet_10.100.1.x_24
  
  
If there is already any vNet in the onboarding subscription whose address range conflicts with this range, then you need to change the address range in the below variables.  
Execute the below lines in the PowerShell.  The default values for the template will be used, unless you specify otherwise

```powershell
New-AzResourceGroupDeployment -ResourceGroupName "DXC-Maint-RG" -TemplateFile "crowdstrikeSiemVnetNsg.json" -location "eastus"  
```

Note:    The destination IP addresses used by the Network Security Group were obtained from the following  
URL:   <https://falcon.crowdstrike.com/support/documentation/20/falcon-sensor-for-linux-deployment-guide#ipaddresses>
 

#### Step2a: Create SIEM VM - Option a) Default

Collect details for the below Parameters before proceeding by following the onboarding guide.  You should already have these.  
The run the command after replacing the values with those of your client.
 
NOTE: SIEMAPPID is a unique identifier for this SIEM connector < 18 characters

```powershell
$TenantId           = "<TenantId here>"                 # If context required
$Subscription       = "Subscription name or ID here"    # If context required

$SIEMRootUser       = "<rootusername here>"
$SIEMRootPass       = "<root password here>"
$SIEMCID            = "<CrowdStrike CID here>"
$SIEMAPICLIENTID    = "<CrowdStrike API CLIENT ID here>"
$SIEMAPICLIENTSECRET = "<CrowdStrike API CLIENT SECRET here>"
$SIEMAPPID          = "<CrowdStrike APP ID here>"
$SIEMvmName         = "<Customer Code here>-Siem"
$WorkspaceID        = "<Log Analytics Workspace ID here>"
$WorkspaceKey       = "<Log analytics Workspace Key Here"
$MaintenanceResourceGroup = "DXC-Maint-RG"
$diagstgname        = "<Diagnostic Storage account here>"
$vnetname           = "<Siem Vnet name here>"
$subnetname         = "<Siem subnet name here>"
$DeploymentLocation = "<Azure Region to deploy the server into>"
$SIEMRPass          = ConvertTo-SecureString $SIEMRootPass -AsPlainText -Force

# If connection and context required:
Connect-AzAccount  -Tenant $TenantId -Subscription $Subscription

New-AzResourceGroupDeployment -ResourceGroupName $MaintenanceResourceGroup `
-TemplateFile "crowdstrikeSiemVM.json" `
-rootUsername $SIEMRootUser -rootPassword $SIEMRPass  `
-vmName $SIEMvmName -vmLocation $DeploymentLocation `
-existingBootDiagStorageResourceGroup $MaintenanceResourceGroup `
-existingBootDiagStorageName $DiagStgName  -existingvNetResourceGroup $MaintenanceResourceGroup `
-existingvNetName $vNetName -subnetName $SubnetName `
-workspaceId $WorkspaceID -workspaceKey $WorkspaceKey  `
-csCID $SIEMCID -csAPIclientID $SIEMAPICLIENTID `
-csAPIclientSecret  $SIEMAPICLIENTSECRET  -csAPPid $SIEMAPPID
```

#### Step2b: Create SIEM VM - Option b) with log forwarding

Use this option if it is required to fork the CrowdStrike Falcon hose output so that the output is also sent to another SIEM such as ArcSight.  With this option the logs are recorded to the output file for collection by OMS as before, but are also forwarded to the specified SIEM Server.

At least one piece of additional information is required:
    -   IP address of the SIEM server that will receive the CEF input
Optionally:
    - Port number.  If not specified this defaults to 514
    - Protocol (udp|tcp).  If not specified ther default is udp

Example

```powershell
... as above
$SiemServerIP       = "<IP address here>"
...
New-AzResourceGroupDeployment -ResourceGroupName $MaintenanceResourceGroup `
-TemplateFile "crowdstrikeSiemVM.json" `
-rootUsername $SIEMRootUser -rootPassword $SIEMRPass  `
-vmName $SIEMvmName -vmLocation $DeploymentLocation `
-existingBootDiagStorageResourceGroup $MaintenanceResourceGroup `
-existingBootDiagStorageName $DiagStgName  -existingvNetResourceGroup $MaintenanceResourceGroup `
-existingvNetName $vNetName -subnetName $SubnetName `
-workspaceId $WorkspaceID -workspaceKey $WorkspaceKey  `
-csCID $SIEMCID -csAPIclientID $SIEMAPICLIENTID `
-csAPIclientSecret  $SIEMAPICLIENTSECRET  -csAPPid $SIEMAPPID `
-csForwardToHost $SiemServerIP
```
