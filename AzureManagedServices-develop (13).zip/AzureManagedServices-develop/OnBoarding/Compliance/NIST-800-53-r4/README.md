## Details of the NIST SP 800-53 R4 Regulatory Compliance

The following link details how the Azure Policy Regulatory Compliance built-in initiative definition maps to compliance domains and controls in NIST SP 800-53 R4.
https://docs.microsoft.com/en-us/azure/governance/policy/samples/nist-sp-800-53-r4

## Deployment Manual

Install necessary modules for Blueprint deployment and create managed identity
```
#Install Blueprint Powershell Module
Install-Module -Name Az.Blueprint -Scope CurrentUser
Install-Module -Name Az.ManagedServiceIdentity -AllowPrerelease

#Connect to Azure Account
Connect-AzAccount -UseDeviceAuthentication
 
#Set active subscription
Set-AzContext -SubscriptionId
 
#Create resource group and managed identity

New-AzResourceGroup -Name <enter bp RG name> -Location <enter AZ location>
New-AzUserAssignedIdentity -ResourceGroupName <enter bp RG name created above> -Name <enter bp identity name>
 
#Get object id of managed Identity
Get-AzADServicePrincipal -DisplayName <enter bp identity name created above>
 
#Set 'Owner' permission to subscription
New-AzRoleAssignment -ObjectId xxxxxx-xxxx-xxxx-xxxx-xxxxxxx -RoleDefinitionName owner

#The newly created managed identity will be used during blueprint assignment
```
Now managed identity and permissions are in place, we are ready to import the blueprint into Azure and assign it.

```

#Login to Azure 
Connect-AzAccount -UseDeviceAuthentication

#Set your working subscription
Set-AzContext -SubscriptionId "xxxxxxx-xxxxxxx-xxxxxxx-xxxxxxx-xxxxxxx"

#Import blueprint to Azure from your local directory
Import-AzBlueprintWithArtifact -Name xxxxxx -SubscriptionId XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX -InputPath 'C:\XXXX\XXXX'

#Get the blueprint we imported
$bp = Get-AzBlueprint -SubscriptionId XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX -Name xxxxxx
 
#Publish
Publish-AzBlueprint -Blueprint $bp -Version 1.0
```

# Prerequisite for NIST Blueprint Assignment

Before assigning published NIST Blueprint  to a subscription you should to have the followings created even if you don’t have deployed the resources in question ex: SQL DB , VMSS etc.,. This will ensure in future if such resources are deployed appropriate NIST controls will be  applied. 
-	Log Analytics workspace for Linux VM Scale Sets (VMSS)
-	Log Analytics workspace for Linux VMs
-	Log Analytics workspace for Windows VM Scale Sets (VMSS)
-	Log Analytics workspace for Windows VMs
-	Resource group name for storage account for SQL server auditing
-	Storage account prefix for network security group diagnostics
  	This prefix will be combined with the network security group location to form the created storage account name.
-	Resource group  for storage account to support network security group diagnostics

Refer to the Artifact parameters table in the provided link for more details   https://docs.microsoft.com/en-us/azure/governance/blueprints/samples/nist-sp-800-53-r4


# Assign NIST Blueprint
Navigate to the Blueprint section in the Azure portal, Select the above published NIST 800-53 blueprint.
Select Assign
 
 1.	Populate the Azure region 
 ![Algorithm schema](./BPAssignment-1.png)
 
 
 
 2.Select the user assigned managed Identity that was created in previous steps
 ![Algorithm schema](./BPAssignment-2.png)
 
 
 
 3.Populated the NIST polcy related parameters and Assign
 
 
 
 
 
 
 

