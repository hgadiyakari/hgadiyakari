# This script willunzip given file to given destination
param(
    $source,
    $destination
)

# This function will return root folder of a zipped archive
# ----------------------------------------------------------
Function Get-ZIPRootFolder([string] $File) {
    if(-not (Test-Path $File)) { return "" } # return blank string if given file doesn't exist

    # Get reference to first item in given zip file and then split path to get parent
    $ZipEntry1 = ([System.IO.Compression.ZipFile]::OpenRead($File).Entries[0].FullName)
    return (Split-Path -Path $ZipEntry1)
}

# This function will uncompress given ZIP file
# --------------------------------------------
function Expand-ZIPFile($File, $Destination) {
    $zipRootFolder = ''
    #[Reflection.Assembly]::LoadWithPartialName('System.IO.Compression.FileSystem') | Out-Null
    add-type -AssemblyName System.IO.Compression.FileSystem

    Write-Verbose "Trying to expand $File into $Destination folder" -Verbose

    # Extract WC zip file ($file) into given folder
    try {
        $zr = Get-ZIPRootFolder -File $File

        # check if the folder-to-be-extracted already exist. delete if exists as it will throw errors
        if((Test-Path -Path "$Destination\$zr")) {
            Remove-Item -Path "$Destination\$zr" -Recurse -Force
        }

        # Extract contents of ZIP file now
        [System.IO.Compression.ZipFile]::ExtractToDirectory($File,$Destination)        
        
        Write-Verbose "Extracted $File into $Destination\$zr folder" -Verbose
        return "$Destination\$zr" # return path of extracted zip root adjacent to destination
    }
    catch {
        Write-Verbose "Error trying to extract contents of $File into $Destination folder" -Verbose
        Write-Verbose "$($_.Exception.Message)" -Verbose
        return $null # retun null as unable to expand zip file
    }
}

# call function perform extraction
$ret = Expand-ZIPFile -File $source -Destination $destination
if($ret -eq $null) { # errors occured
    return 'error_extracting'
    exit 1
}
else {
    return $ret
    exit 0
}

